# P66 — Complete buffered-drain sealing for passive PCAPNG evidence (22 October 2026)

P66 fixes a reproduced P65 finalization bug: the recorder was closed after sniffer shutdown **but before draining queued TCP segments and processing the protocol consumer**. A failure during that final drain could not be represented as lost evidence. P66 introduces a two-phase shutdown: `quiesce()` stops the sniffer and closes the queue without finalizing the PCAPNG; `capture_bounded_sample()` drains and audits the remaining polls, then `stop()` finalizes. Failure during final drain is now written as positive PCAPNG loss metadata; the existing parser rejects such a capture. Direct `stop()` compatibility and idempotency are preserved. Normal `check`/`setup` exercise four recording smoke scenarios. **93/93 isolated regression modules and 1,586 tests PASS**; focused **78 tests + 29 subtests PASS**; `check`/`setup` PASS; `start` intentionally BLOCKED (40) with verified incident ZIP. No current-client/Windows proof, Canonical admission or physical input. Optional raw recording stays OFF by default and remains private, with zero runtime capture files packaged. Details: `docs/P66_POST_STOP_DRAIN_EVIDENCE_SEALING.md` and `verification/P66_offline_acceptance_receipt.json`. Roadmap scope remains **92% subjective**, verified full live mission **0%**; only root operator BATs are `setup.bat` and `start.bat`.

---

# P65 — Fail-closed interrupted passive capture evidence (22 October 2026)

P65 fixes a reproduced P64 lifecycle bug: polling, wire-consumer or sniffer-stop exceptions could finalize an opted-in PCAPNG without representing the interrupted observation window. P65 marks those windows incomplete and writes positive PCAPNG loss metadata before finalizing; the existing research parser rejects such evidence. Premature stop before start is also incomplete. Normal complete samples remain `RECORDED_UNCERTIFIED`, never a proof of driver completeness. Automatic `check`/`setup` now exercise three recording cases. **92/92 isolated regression modules, 1,580 tests PASS**; `check`/`setup` PASS, `start` intentionally BLOCKED (40), incident ZIP verified. Raw capture remains OFF by default, private, and excluded from incident/release ZIPs; current-client/Windows acceptance still unverified. Details: `docs/P65_CAPTURE_INTERRUPTION_LOSS_SEALING.md` and `verification/P65_offline_acceptance_receipt.json`. Roadmap estimate stays **92% subjective**, full live CRA/ENU acceptance **0%**. Only root operator commands: `setup.bat`, `start.bat`.

---

# P64 — Consent-gated Windows passive PCAPNG evidence acquisition (22 October 2026)

P64 adds the previously missing **read-only Windows sample → saved actual packet bytes** path needed for future current-client protocol research. Raw packet retention is **OFF by default**, enabled only by adding `"save_raw_evidence": true` under `capture` in `config/user.json`; it also requires the existing explicit server-ports/interface/Windows-window/Npcap/Scapy checks. A bounded `.pcapng` is written only into ignored `runtime/evidence/` (never into a debug or release ZIP), with a synthetic Ethernet header when source frames have only L3; explicit callback/queue/recorder gaps write positive PCAPNG loss metadata so incomplete samples fail the P62 parser. Because these bytes contain IP endpoints and potentially sensitive app traffic, inspect privately before sharing. **Real Windows capture remains unverified; saved packet evidence does not prove driver completeness, current-client semantics, identity, or gameplay authority.** P64's full regression inventory is **91/91 modules, 1,573 tests passed**. `check`/`setup` PASS; `start` intentionally BLOCKED (40) with verified incident ZIP. See `docs/P64_OPT_IN_WINDOWS_PASSIVE_PCAPNG_EVIDENCE_ACQUISITION.md` and `verification/P64_offline_acceptance_receipt.json`. Subjective roadmap coverage **92%** (unchanged), verified live CRA/ENU mission acceptance **0%**. Operator BATs remain `setup.bat` and `start.bat` only.

---

# P63 — Crash-safe PCAPNG section boundaries (22 October 2026)

P63 closes a structural integrity gap in the P62 PCAPNG research parser. Previously both the packet decoder and packet-count reader could accept orphan blocks without a Section Header, unsupported SHB versions, and blocks beyond/short of an explicitly declared Section Length. A capture might therefore look coherent even though its section framing was corrupt. Both readers now use a single bounded `_pcapng_blocks` iterator that validates required SHB presence, section-local byte order, version 1.0, declared section length (excluding the header), block trailer/size, exact block boundaries, and mixed-endian multi-section transition. Unknown length (-1) stays supported. Automatic fail-closed P63 smoke runs in normal `check`/`setup`. **90/90 source-bound isolated modules, 1,556 tests PASS**; focused **162 tests PASS**. `check`/`setup` PASS, `start` BLOCKED intentionally (40), incident ZIP verified. Historical research only; no current-client/character authority, Canonical admission or physical input. Details: `docs/P63_PCAPNG_SECTION_BOUNDARY_INTEGRITY.md` and `verification/P63_offline_acceptance_receipt.json`. Subjective roadmap coverage remains **92%**; live CRA/ENU full acceptance **0%**. Only root operator commands: `setup.bat` and `start.bat`.

---

# P62 — PCAPNG recorded packet-loss evidence integrity (22 October 2026)

P62 fixes a reproduced silent-loss failure in the saved-capture research pipeline: P61 parsed enhanced packets, legacy packet blocks, and interface statistics blocks, but ignored packet-loss metadata. A coherent-looking selected TCP trace could therefore coexist with an explicit positive capture-drop count. P62 now rejects nonzero `epb_dropcount` (EPB option 4), `isb_ifdrop`/`isb_osdrop` (ISB options 5/7), and legacy packet block `Drops Count`, including delayed interface statistics and other capture interfaces. It validates bounded option lengths, duplicate counters, interface references, per-section endianness and rejects malformed statistics. Packet-count research cannot bypass the same metadata audit. Unknown counts remain unknown; missing/zero loss counters do **not** prove driver completeness. A synthetic fail-closed P62 smoke runs during normal `check`/`setup`. **89/89 source-bound isolated test modules, 1,539 methods PASS**; focused **112 tests and 22 subtests PASS**. `check`/`setup` PASS; `start` intentionally BLOCKED exit 40 with validated incident ZIP. No current-client certification, Canonical commits, or physical input. See `docs/P62_REPORTED_PCAPNG_PACKET_LOSS_INTEGRITY.md` and `verification/P62_offline_acceptance_receipt.json`. Subjective roadmap coverage remains **92%**; complete live CRA/ENU mission acceptance **0%**. Only `setup.bat` and `start.bat` are operator launchers.

# P61 — IPv6 fragmented-TCP capture completeness (22 October 2026)

P61 fixes a reproduced PCAPNG parsing defect: non-initial IPv6 TCP fragments lack TCP ports, but the existing parser could misread fragment payload as port bytes and silently omit traffic. Fragment offsets/M flags and reserved bits now prevent unclassifiable TCP-bearing fragments from being represented as absent; ordinary unrelated IPv6 traffic remains out of selected TCP scope. P50 flow inventory and P59 file-backed evidence checks fail closed, with an automatic synthetic fragment check during `check`/`setup`. **88/88 isolated modules and 1,522 methods PASS**; focused **194 tests +22 subtests PASS**; `check`/`setup` PASS; `start` intentionally BLOCKED exit 40 with valid incident ZIP. Historical research only; no IPv6 live support, current-client authority, Canonical writes or physical input. See `docs/P61_IPV6_FRAGMENT_TRANSPORT_EVIDENCE_INTEGRITY.md` and `verification/P61_offline_acceptance_receipt.json`. Roadmap estimate stays **92% subjective**; verified live mission **0%**. Only `setup.bat` and `start.bat` remain operator launchers.

---

# P60 — Correct packet-local wire provenance in multi-flow PCAPNG (22 October 2026)

P60 fixes a reproduced provenance bug in P6: `WireMessage.message_index` was derived from the **global** message counter, so unrelated TCP flow traffic could change the source index for a packet on a different account socket. It is now the **packet-local ordinal**; total counts remain global. Two interleaved flows can be independently corroborated against the same PCAPNG through P59. Automatic `check`/`setup` smoke added. **87/87 isolated modules, 1,508 tests PASS**; `check`/`setup` PASS; `start` correctly refuses live operation (exit 40). Old global-index research selectors must be regenerated from capture, not silently migrated. Historical protocol research remains non-authoritative; full live CRA/ENU acceptance **0%**, subjective roadmap estimate **92%**. See `docs/P60_PACKET_LOCAL_MESSAGE_PROVENANCE_INTEGRITY.md` and `verification/P60_offline_acceptance_receipt.json`. Only root operator BAT files: `setup.bat`, `start.bat`.

---

# P59 — Capture-backed wire cross-check (22 October 2026)

P59 cross-checks P58 untrusted admission claims against a **real saved PCAPNG** using the existing capture parser and historical P6 wire framing. The selected flow's message bytes, TCP generation, packet ordinal, message index, protocol build and capture file SHA must agree; missing/extra wire messages and changed file content are explicitly quarantined. This is a file-correspondence proof only, **not** driver-origin attestation, modern-client certification, character ownership, semantic authority, or gameplay input. **86/86 isolated modules, 1,504 tests PASS**; check/setup PASS; start correctly blocked (40). Full details: `docs/P59_CAPTURE_BACKED_WIRE_PROVENANCE_CROSSCHECK.md`. Roadmap estimate 92% subjective; complete live CRA/ENU acceptance 0%. Only `setup.bat` and `start.bat` remain operator launchers.

---

# P57 continuation point

Start from the P57 complete ZIP. It fixes SQLite schema bootstrap/migration atomicity and guards synthetic journal schema layout and fresh WAL concurrency. The P56 receipts, P55 batch transactions and P54 identity research remain distinct, with **no current-build/live Canonical admission**. Reference `docs/P57_SQLITE_SCHEMA_CRASH_ATOMIC_BOOTSTRAP.md`, `verification/P57_offline_acceptance_receipt.json`, and `src/anka_canonical/journal.py`. Do not add operator BATs beyond `setup.bat` / `start.bat`. Keep gameplay `start` blocked until independent Windows/current-client/live acceptance has been completed.

---

# ANKA_NEXT — P56 source-bound Canonical batch receipts

P56 extends P55's synthetic transactional journal with a durable **source-bound batch receipt**: one upstream logical batch is now atomically tied to its exact event range, event payload digest, final hash-chain tip and projection. Exact retries are idempotent even after lost COMMIT acknowledgement; batch/source relabelling, receipt tampering and adoption of unreceipted events fail closed. The synthetic ledger migrates v1→v2 under a serialized writer lock. Historical/current protocol drafts still cannot enter this path. **83/83 isolated modules, 1,449 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). Roadmap estimate remains 92%; verified live CRA/ENU acceptance remains 0%. See `docs/P56_SOURCE_BOUND_BATCH_RECEIPTS_AND_SCHEMA_V2.md` and `verification/P56_offline_acceptance_receipt.json`.

---

# ANKA_NEXT — P55 transactional Canonical batch/fencing foundation

P55 ports the strongest transactional-live-truth invariant from the old R5.198 design into ANKA_NEXT's cleaner **synthetic-only** Canonical journal: one logical event batch is fully reduced before durable insertion, journal + projection commit together, and any ambiguous COMMIT acknowledgement or failed rollback **fences the writer until close/reopen + replay**. `append_fixture` now uses the same batch path. Historical/current protocol drafts still cannot enter this store and no input authority exists. **82/82 isolated modules, 1,433 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). See `docs/P55_TRANSACTIONAL_CANONICAL_BATCH_AND_COMMIT_FENCING.md`. Roadmap estimate remains 92%; verified live CRA/ENU acceptance remains 0%.

---

# ANKA_NEXT — P54 historical process/flow/character/fight-actor continuity

P54 extends the P53 historical identity chain through P45/P46 fight observations: a historical `jnj` character/actor witness must match the same exact flow, transport generation, build and ordered fight actor evidence before the chain is reported as research-consistent. A new two-account aggregate composes stable Windows process/socket candidates → historical character → historical fight actor without exposing private identifiers or inventing cross-flow ordering. **81/81 isolated modules, 1,411 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). This is historical research only, not current-client identity or gameplay authority. See `docs/P54_HISTORICAL_PROCESS_FLOW_CHARACTER_ACTOR_CONTINUITY.md`.

---

# ANKA_NEXT — P53 HISTORICAL CHARACTER/FLOW/PROCESS IDENTITY (21 October 2026)

P53 recovers the R5.198 Dofus 3.7.10.10 `jnj` world-name local-actor witness and composes it with P51/P52 stable Windows TCP-owner candidates. The old source contains a `jns` name-matching code path but its registry does not declare `LOCAL_ACTOR`; P53 therefore keeps `jns` non-certifying. Exact historical source/manifest hashes are checked during `check`/`setup`. A clean synthetic two-character/two-process result is still **historical candidates only**: zero current character witnesses, zero account binding, zero Canonical commits and zero physical input. **80/80 isolated test modules, 1,387 tests passed**; `check`/`setup` PASS; `start` intentionally exits 40 and its incident ZIP verifies. Read `docs/P53_HISTORICAL_CHARACTER_FLOW_PROCESS_IDENTITY.md` and `verification/P53_offline_acceptance_receipt.json`. Roadmap estimate remains 92% (subjective); real current-client CRA/ENU acceptance remains 0%. Only `setup.bat` and `start.bat` are root operator commands.

---

# ANKA_NEXT — P52 MULTI-CLIENT PROCESS/SOCKET TOPOLOGY (21 October 2026)

P52 connects the existing two-boundary Windows process/flow evidence into a privacy-safe **multi-account candidate topology** audit: duplicate TCP selectors cannot masquerade as two accounts, a process with two sockets counts as one process, and mismatched/ambiguous owners stay explicit. Uses existing P51 validation, preserving its output contract. A 3-case P52 smoke runs in existing `check`/`setup` (no extra BAT). **78/78 isolated modules, 1,356 tests passed**; `check`/`setup` PASS; `start` intentionally blocks (exit 40), incident ZIP integrity PASS. No authentic Windows/CRA/ENU identity, verified modern protocol, Canonical commits or input authority. Roadmap scope estimate 92% (subjective), complete live CRA/ENU acceptance 0%. Read `docs/P52_MULTI_ACCOUNT_SOCKET_PROCESS_TOPOLOGY.md` and `verification/P52_offline_acceptance_receipt.json`. Only `setup.bat` and `start.bat` remain root operators.

---

# ANKA_NEXT — P51 WINDOWS FLOW OWNERSHIP STABILITY (21 October 2026)

P51 fixes a real passive-ingress attribution issue: the before/after TCP-table intersection could hide a contradictory owner that disappeared between snapshots and incorrectly report a unique provisional flow/process hint. The now lossless two-boundary join rejects duplicated or conflicting endpoint owners, PID/HWND/process-generation changes, unexpected executable images, geometry or minimization changes, stale scan intervals, and incomplete inventories. It emits only privacy-safe counts, **never** verified CRA/ENU identity or gameplay permission. Normal `check`/`setup` exercise three offline consistency cases. **77/77 modules and 1,336 tests passed**, check/setup PASS, `start` intentionally blocked (exit 40), incident ZIP verified. Read `docs/P51_WINDOWS_TCP_OWNER_SNAPSHOT_STABILITY.md` and `verification/P51_offline_acceptance_receipt.json`. Subjective historical roadmap 92%, real live CRA/ENU acceptance 0%. Only root operator BAT files remain `setup.bat` and `start.bat`.

---

# ANKA_NEXT — P49 CURRENT RELEASE (21 October 2026)

P49 adds a **real saved-PCAPNG → P4 Capture → P6 Protocol → P47 historical replay** research entry point. It keeps missing driver-drop accounting and account/window identity **explicitly unverified**: even if coherent historical messages decode, the file-level report is `BLOCKED_EVIDENCE`, with zero Canonical commits and zero physical input. `check`/`setup` now verify this safety behavior automatically. No protocol build is certified as current. **Only root BAT files: `setup.bat` and `start.bat`.**

Verification: selected capture/protocol tests **342 PASS + 119 subtests**; separate architecture/diagnostics/integration selection **128 PASS + 32 subtests** (overlapping); `check`/`setup` PASS; `start` deliberately exits 40 and its incident bundle verifies. The broad combined suite is **incomplete** due to execution limits. Subjective roadmap coverage remains **92%**; full live-fight acceptance remains **0%**. Details: `docs/P49_SAVED_PCAPNG_HISTORICAL_REPLAY_UNCERTAINTY.md` and `verification/P49_offline_acceptance_receipt.json`.

---

# ANKA_NEXT — P48 CURRENT RELEASE (21 October 2026)

P48 connects **real CapturePoll/TCP segment bytes → existing P6 ProtocolInspector framing → P47 historical lifecycle/combat replay**, all in an `anka_app` *research-only* composition adapter. It detects transport gaps, unknown driver-loss visibility, source-generation changes, incomplete frames, unmapped messages, foreign flows and two independently reproduced silent/exception failure cases. The new P48 smoke is included in normal `check`/`setup`. See `docs/P48_CAPTURE_TRANSPORT_TO_HISTORICAL_RESEARCH.md` and `verification/P48_offline_acceptance_receipt.json`.

**Offline evidence:** 84 focused tests +24 subtests and a wider 557-test/142-subtest selection pass, `check`/`setup` PASS; broader full suite not verified. `start` is still intentionally blocked (exit 40) and diagnostic ZIP verifies. No current-client adapter, Canonical authority, or physical input. Exactly `setup.bat` and `start.bat` remain operator BAT commands. Estimated development-scope coverage 92% (subjective); live full-fight acceptance 0%.

---

# ANKA_NEXT — P47 CURRENT RELEASE (21 October 2026)

P47 integrates P45 lifecycle and P46 combat research decoding into **one bounded, single-flow historical server-wire replay**. Unknown obfuscated messages and unsupported combat actions now remain visible as explicit evidence gaps; duplicated/reordered source cursors, wrong flows/generations and corrupted fields block the research receipt. A clean subset of decoded events can no longer hide missing wire observations in this integrated API. P47's tiny independent smoke runs automatically in `check` and `setup`.

**All outcomes remain research-only.** Historical build 3.7.10.10 is not a certified current-client adapter; no synthetic observation authorizes Canonical commits, spell success, victory, or physical input. `start` remains intentionally blocked (exit 40). The new 28-test P47 suite and 101-test P45–P47 decoder group pass; the full 69-module regression inventory was **not completed** due to timeouts. See `docs/P47_HISTORICAL_WIRE_STREAM_REPLAY_AND_EVIDENCE_GAP_AUDIT.md` and `verification/P47_offline_acceptance_receipt.json`. Subjective development scope **91%**, real complete live-fight acceptance **0%**. Only root BATs: `setup.bat` and `start.bat`.

---

# ANKA_NEXT — P46 CURRENT RELEASE (21 October 2026)

P46 adds **research-only historical Dofus 3.7.10.10 combat wire observations** for `jsq/300` spell records, `jsq/5` push, `jsq/4` teleport and `jwp` result boundaries, plus P45↔P46 same-flow turn/cast causal audit. **No damage, AP/MP settlement, spell success or victory is inferred.** The Kernel, original reference assets, game input and live safety gates remain untouched.

**Verification:** 67/67 modules and 1,231 unittest methods independently passed (66 modules/1,220 in a resumable independent module inventory; the slow P37 verifier module separately passed 11). `check`/`setup` PASS; architecture and 165 assets PASS; `start` intentionally exit 40, incident ZIP validated. **Current-client live fight acceptance 0%.** Estimated engineering scope 91% (subjective, not quality). Root user BATs: `setup.bat`, `start.bat` only.

Read `docs/P46_HISTORICAL_COMBAT_OBSERVATIONS_AND_CROSS_FAMILY_CAUSAL_AUDIT.md` and `verification/P46_offline_acceptance_receipt.json` for exact evidence, limitations, and next gate. The underlying historical source code never executes, and no current-client adapter is certified.

---

# ANKA_NEXT — Current project guidance (P43)

**Current complete ZIP baseline: P43.** Read `docs/P43_CASE_LEVEL_COMPARISON_LINEAGE_AND_RESULT_CONSISTENCY.md` and `verification/P43_offline_acceptance_receipt.json` first. P43 adds a per-case opaque binding and result-consistency checks to the P42 archive-level protocol comparison, preventing same-capability CRA/ENU research rows from being accidentally mixed. Independent reproducer: 7 new tests failed on P42; all 9 P43 tests passed after correction. Focused 353 tests +17 subtests PASS; full module-isolated 61 modules /1,138 tests PASS; check/setup PASS, start intentionally exit 40 with verified incident ZIP. Only `setup.bat`/`start.bat` are operator entrypoints. Weighted scope estimate remains 88% (subjective), real live-fight acceptance 0%. No protocol adapter activated or gameplay authority permitted.

---

# ANKA_NEXT — Current project guidance (P42)

**P42 is the current complete source baseline.** `docs/P42_EXACT_PROTOCOL_COMPARISON_PROVENANCE_BINDING.md` and `verification/P42_offline_acceptance_receipt.json` document the latest changes. P42 binds protocol comparison results to the exact evidence ZIP/build/adapter; stale or mixed research comparisons cannot inflate matched capability counts. Eight new tests, 344 focused tests + 17 subtests, and **all 60 isolated test modules / 1,129 unittest tests passed**. `check`/`setup` PASS; `start` intentionally exits 40; incident ZIP PASS. Exactly `setup.bat` and `start.bat` for normal operation, no dashboard. Subjective implementation coverage 88%, live CRA/ENU accepted 0%. No modern-client protocol evidence or physical-input authority exists. Preserve this research-only boundary.

---

# ANKA_NEXT — Project guidance (updated through P41)

**Current baseline:** the complete P41 project ZIP (contains the full prior P38/P37 project). Its actual source code and tests are authoritative. Start with `docs/P39_TARGET_CONTEXT_INTEGRITY.md`, `verification/P39_offline_acceptance_receipt.json`, `docs/P38_CAUSAL_OBSERVATION_WINDOW_HARDENING.md` and `verification/P38_offline_acceptance_receipt.json`; prior P37 history remains below. Read `docs/P37_CHECKPOINTED_RECOVERABLE_VERIFICATION.md`, `docs/P36_TARGET_EFFECT_CONFOUNDER_AUDIT_AND_MODULE_ISOLATION.md`, `IMPLEMENTATION_STATUS.md`, `docs/TARGET_ARCHITECTURE_V2.md`, `verification/P37_offline_acceptance_receipt.json`, and `src/anka_app/readiness.py` before making changes.


P41 fixes two independently reproduced research-only errors: same-cell position
refreshes were overclassified as movement; and one wire packet could be counted
repeatedly for the same role/capability by changing oracle IDs. The new P41
regressions preserve genuine movement ambiguity, cross-role source independence,
and legitimate multi-field messages. **All 59 module-isolated test files / 1,121
test methods passed**, and the P28–P41 focused gate passed 336 tests plus
12 subtests. `check` and `setup` PASS; `start` still refuses live execution
with exit 40 and a verified incident bundle. Modern-client acceptance remains
0%, and estimated roadmap coverage 88% (not a quality score). No separate
handoff or extra operator BAT was introduced. Full details:
`docs/P41_CELL_TRANSITION_AND_PROTOCOL_CLAIM_INTEGRITY.md` and
`verification/P41_offline_acceptance_receipt.json`.

---


## Purpose and hard requirements

The goal remains reliable CRA leader + ENU follower autonomous Dofus missions. This release is an **offline research and test-infrastructure milestone**, **not** a connected or live-ready bot.

- Exactly **two root operator BAT launchers**: `setup.bat` and `start.bat`. No dashboard or extra demo, test, audit, debug or capture BAT commands.
- Only routine editable settings: `config/user.json`. Preserve 13 separate source packages (11 systems + `anka_contracts` + `anka_app`). Preserve unchanged stand-alone `anka_game_kernel`, calibration and static-data reuse; 165 assets verified.
- Current-build protocol mappings and genuine independent witness evidence are missing. Never promote synthetic/research Canonical drafts, guessed cast damage or HP/AP/MP deltas into action authority.
- No real input; `start` deliberately blocks with `LIVE_RUNTIME_NOT_IMPLEMENTED` exit 40. Never bypass these controls. Preserve unique action identity, no blind retry after uncertain send and GPT-friendly sanitized diagnostics.
- Protocol updates approximately every two weeks must remain adapter-local where semantics are unchanged, with independently qualified evidence and regression tests.
- Next development must prioritize current-client semantics, authentic witnessed outcomes and eventual production Canonical admission, not more cosmetic files, launchers, or synthetic scoring.

## P40 implementation

- Current ZIP includes the **full P39 baseline** plus content-hash source-independence guards in P28 evidence-pack intake. A duplicated selected message or oracle assertion cannot be relabeled as a separate CRA/ENU research witness. Different real source observations remain admitted only as untrusted research; genuine account binding is still unverified.
- New tests 11 PASS; selected protocol/reconstruction/architecture gate 305 tests + 12 subtests PASS; check/setup PASS; start intentionally blocked (exit 40); complete one-process suite unverified.
- Full details in `docs/P40_CROSS_ACCOUNT_EVIDENCE_SOURCE_INDEPENDENCE.md` and `verification/P40_offline_acceptance_receipt.json`.
- Development roadmap estimate 88% unchanged; complete live acceptance 0%. No separate continuation handoff.

## P39 implementation

- Continued the P36/P38 *research-only* P36 target-effect audit with two narrow source-grounded improvements: cell witnesses across a completed turn become `STALE_OBSERVATION`; distinct before-cast target cell changes confound MP-window deltas. Does **not** make spell effects proven, activate hardware or change Canonical state.
- Eight independent tests and enhanced existing `setup` smoke; details and actual checks in `docs/P39_TARGET_CONTEXT_INTEGRITY.md` and `verification/P39_offline_acceptance_receipt.json`.
- Development roadmap estimate remains **88%**, complete current-client live-fight acceptance **0%**.
- Only `setup.bat` and `start.bat`; no extra handoff artifact.

## P37 implementation

- `src/anka_app/verification_runner.py`: immutable input+environment fingerprint; atomic resumable module test checkpoint, bounded batch support and process-tree timeout handling. CLI `verify` uses `runtime/verification/module_checkpoint.json` without a new user BAT.
- `tests/test_p37_checkpointed_verification.py`: 11 new tests with corruption, staleness, false-pass, interrupted-process and inherited-pipe cases.
- P36 target-effect research remains unchanged and research-only.
- **Verified:** 153 focused tests PASS, `check` PASS (13 source packages/247 audited Python files/165 assets), `setup` PASS, bounded `start` exits 40 as designed, `test_protocol_architecture` 4 PASS on its own.
- **Full 54-module test suite:** INCOMPLETE within outer execution limit; do not claim full PASS. An earlier interrupted run checkpointed 10 modules; the document states this limitation. No current-client Windows or Dofus live acceptance.
- **Estimated roadmap coverage:** 88% (subjective coverage only). **Complete live CRA+ENU fight acceptance:** 0%.

## Resume instructions

1. Inspect source + exact P37 receipt and verify SHA/content and 2 BAT operators.
2. Re-run targeted P36/P37 regression and architecture gates before editing a system.
3. The checkpointed test verifier is a developer-only Python feature. It stores checkpoints under `runtime/` and rejects stale inputs; `verify_isolated(...,module_isolation=True,checkpoint_path=...,max_new_modules=N)` supports bounded batches without false PASS.
4. Continue current-build protocol semantic research **only with real independent evidence**. If none is supplied, work on a high-value bounded safety/verification dependency, label limitations honestly and preserve existing authority gates.
5. Produce an updated **complete replacement ZIP** preserving all prior project files (except generated cache/runtime/venv); document exact tests, missing evidence, source hashes and distinct estimated development/live acceptance percentages.


## P50 continuation state
P50 adds `anka_app.historical_pcapng_inventory` and its offline setup smoke. It selects read-only per-flow research observations from immutable PCAPNG evidence without attributing any flow to CRA/ENU or promoting Canonical state. The module-isolated verifier completed all 75 tests modules (1,306 methods); original P49 files are preserved. See `docs/P50_PCAPNG_MULTIFLOW_DISCOVERY_AND_EXACT_SNAPSHOT_SELECTION.md` and the P50 receipt. Only `setup.bat`/`start.bat` are operator launchers; live startup remains intentionally blocked. Next challenge: independent modern protocol and Windows account/socket/window witnesses.

## Latest P58 snapshot — read first

P58 adds only a read-only `Canonical` admission rehearsal with untrusted evidence contract and adversarial tests. It cannot promote historical or self-declared current-client claims. The full 85-module/1,491-test isolated inventory passed on fingerprint `02712e6027b60bef6c83e7fa1a8832e2584437e55e639b798f9c769ee5a7fc75`. See `docs/P58_UNTRUSTED_CANONICAL_ADMISSION_REHEARSAL.md` and `verification/P58_offline_acceptance_receipt.json`. No extra BAT launchers, no dashboard, live `start` remains blocked.

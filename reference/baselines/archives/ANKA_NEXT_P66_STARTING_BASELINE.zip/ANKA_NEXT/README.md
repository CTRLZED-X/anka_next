# P66 — Complete buffered-drain sealing for passive PCAPNG evidence (22 October 2026)

P66 fixes a reproduced P65 finalization bug: the recorder was closed after sniffer shutdown **but before draining queued TCP segments and processing the protocol consumer**. A failure during that final drain could not be represented as lost evidence. P66 introduces a two-phase shutdown: `quiesce()` stops the sniffer and closes the queue without finalizing the PCAPNG; `capture_bounded_sample()` drains and audits the remaining polls, then `stop()` finalizes. Failure during final drain is now written as positive PCAPNG loss metadata; the existing parser rejects such a capture. Direct `stop()` compatibility and idempotency are preserved. Normal `check`/`setup` exercise four recording smoke scenarios. **93/93 isolated regression modules and 1,586 tests PASS**; focused **78 tests + 29 subtests PASS**; `check`/`setup` PASS; `start` intentionally BLOCKED (40) with verified incident ZIP. No current-client/Windows proof, Canonical admission or physical input. Optional raw recording stays OFF by default and remains private, with zero runtime capture files packaged. Details: `docs/P66_POST_STOP_DRAIN_EVIDENCE_SEALING.md` and `verification/P66_offline_acceptance_receipt.json`. Roadmap scope remains **92% subjective**, verified full live mission **0%**; only root operator BATs are `setup.bat` and `start.bat`.

---

# P65 — Fail-closed interrupted passive capture evidence (22 October 2026)

P65 fixes a reproduced P64 lifecycle bug: polling, wire-consumer or sniffer-stop exceptions could finalize an opted-in PCAPNG without representing the interrupted observation window. P65 marks those windows incomplete and writes positive PCAPNG loss metadata before finalizing; the existing research parser rejects such evidence. Premature stop before start is also incomplete. Normal complete samples remain `RECORDED_UNCERTIFIED`, never a proof of driver completeness. Automatic `check`/`setup` now exercise three recording cases. **92/92 isolated regression modules, 1,580 tests PASS**; `check`/`setup` PASS, `start` intentionally BLOCKED (40), incident ZIP verified. Raw capture remains OFF by default, private, and excluded from incident/release ZIPs; current-client/Windows acceptance still unverified. Details: `docs/P65_CAPTURE_INTERRUPTION_LOSS_SEALING.md` and `verification/P65_offline_acceptance_receipt.json`. Roadmap estimate stays **92% subjective**, full live CRA/ENU acceptance **0%**. Only root operator commands: `setup.bat`, `start.bat`.

---

# P64 — Consent-gated Windows passive PCAPNG evidence acquisition (22 October 2026)

P64 adds the previously missing **read-only Windows sample → saved actual packet bytes** path needed for future current-client protocol research. Raw packet retention is **OFF by default**, enabled only by adding `"save_raw_evidence": true` under `capture` in `config/user.json`; it also requires the existing explicit server-ports/interface/Windows-window/Npcap/Scapy checks. A bounded `.pcapng` is written only into ignored `runtime/evidence/` (never into a debug or release ZIP), with a synthetic Ethernet header when source frames have only L3; explicit callback/queue/recorder gaps write positive PCAPNG loss metadata so incomplete samples fail the P62 parser. Because these bytes contain IP endpoints and potentially sensitive app traffic, inspect privately before sharing. **Real Windows capture remains unverified; saved packet evidence does not prove driver completeness, current-client semantics, identity, or gameplay authority.** P64's full regression inventory is **91/91 modules, 1,573 tests passed**. `check`/`setup` PASS; `start` intentionally BLOCKED (40) with verified incident ZIP. See `docs/P64_OPT_IN_WINDOWS_PASSIVE_PCAPNG_EVIDENCE_ACQUISITION.md` and `verification/P64_offline_acceptance_receipt.json`. Subjective roadmap coverage **92%** (unchanged), verified live CRA/ENU mission acceptance **0%**. Operator BATs remain `setup.bat` and `start.bat` only.

---

# P63 — Crash-safe PCAPNG section boundaries (22 October 2026)

P63 closes a structural integrity gap in the P62 PCAPNG research parser. Previously both the packet decoder and packet-count reader could accept orphan blocks without a Section Header, unsupported SHB versions, and blocks beyond/short of an explicitly declared Section Length. A capture might therefore look coherent even though its section framing was corrupt. Both readers now use a single bounded `_pcapng_blocks` iterator that validates required SHB presence, section-local byte order, version 1.0, declared section length (excluding the header), block trailer/size, exact block boundaries, and mixed-endian multi-section transition. Unknown length (-1) stays supported. Automatic fail-closed P63 smoke runs in normal `check`/`setup`. **90/90 source-bound isolated modules, 1,556 tests PASS**; focused **162 tests PASS**. `check`/`setup` PASS, `start` BLOCKED intentionally (40), incident ZIP verified. Historical research only; no current-client/character authority, Canonical admission or physical input. Details: `docs/P63_PCAPNG_SECTION_BOUNDARY_INTEGRITY.md` and `verification/P63_offline_acceptance_receipt.json`. Subjective roadmap coverage remains **92%**; live CRA/ENU full acceptance **0%**. Only root operator commands: `setup.bat` and `start.bat`.

---

# P62 — PCAPNG recorded packet-loss evidence integrity (22 October 2026)

P62 fixes a reproduced silent-loss failure in the saved-capture research pipeline: P61 parsed enhanced packets, legacy packet blocks, and interface statistics blocks, but ignored packet-loss metadata. A coherent-looking selected TCP trace could therefore coexist with an explicit positive capture-drop count. P62 now rejects nonzero `epb_dropcount` (EPB option 4), `isb_ifdrop`/`isb_osdrop` (ISB options 5/7), and legacy packet block `Drops Count`, including delayed interface statistics and other capture interfaces. It validates bounded option lengths, duplicate counters, interface references, per-section endianness and rejects malformed statistics. Packet-count research cannot bypass the same metadata audit. Unknown counts remain unknown; missing/zero loss counters do **not** prove driver completeness. A synthetic fail-closed P62 smoke runs during normal `check`/`setup`. **89/89 source-bound isolated test modules, 1,539 methods PASS**; focused **112 tests and 22 subtests PASS**. `check`/`setup` PASS; `start` intentionally BLOCKED exit 40 with validated incident ZIP. No current-client certification, Canonical commits, or physical input. See `docs/P62_REPORTED_PCAPNG_PACKET_LOSS_INTEGRITY.md` and `verification/P62_offline_acceptance_receipt.json`. Subjective roadmap coverage remains **92%**; complete live CRA/ENU mission acceptance **0%**. Only `setup.bat` and `start.bat` are operator launchers.

# P61 — IPv6 fragmented-TCP capture completeness (22 October 2026)

P61 fixes a reproduced PCAPNG parsing defect: non-initial IPv6 TCP fragments lack TCP ports, but the existing parser could misread fragment payload as port bytes and silently omit traffic. Fragment offsets/M flags and reserved bits now prevent unclassifiable TCP-bearing fragments from being represented as absent; ordinary unrelated IPv6 traffic remains out of selected TCP scope. P50 flow inventory and P59 file-backed evidence checks fail closed, with an automatic synthetic fragment check during `check`/`setup`. **88/88 isolated modules and 1,522 methods PASS**; focused **194 tests +22 subtests PASS**; `check`/`setup` PASS; `start` intentionally BLOCKED exit 40 with valid incident ZIP. Historical research only; no IPv6 live support, current-client authority, Canonical writes or physical input. See `docs/P61_IPV6_FRAGMENT_TRANSPORT_EVIDENCE_INTEGRITY.md` and `verification/P61_offline_acceptance_receipt.json`. Roadmap estimate stays **92% subjective**; verified live mission **0%**. Only `setup.bat` and `start.bat` remain operator launchers.

---

# P60 — Correct packet-local wire provenance in multi-flow PCAPNG (22 October 2026)

P60 fixes a reproduced provenance bug in P6: `WireMessage.message_index` was derived from the **global** message counter, so unrelated TCP flow traffic could change the source index for a packet on a different account socket. It is now the **packet-local ordinal**; total counts remain global. Two interleaved flows can be independently corroborated against the same PCAPNG through P59. Automatic `check`/`setup` smoke added. **87/87 isolated modules, 1,508 tests PASS**; `check`/`setup` PASS; `start` correctly refuses live operation (exit 40). Old global-index research selectors must be regenerated from capture, not silently migrated. Historical protocol research remains non-authoritative; full live CRA/ENU acceptance **0%**, subjective roadmap estimate **92%**. See `docs/P60_PACKET_LOCAL_MESSAGE_PROVENANCE_INTEGRITY.md` and `verification/P60_offline_acceptance_receipt.json`. Only root operator BAT files: `setup.bat`, `start.bat`.

---

# P59 — Capture-backed wire cross-check (22 October 2026)

P59 cross-checks P58 untrusted admission claims against a **real saved PCAPNG** using the existing capture parser and historical P6 wire framing. The selected flow's message bytes, TCP generation, packet ordinal, message index, protocol build and capture file SHA must agree; missing/extra wire messages and changed file content are explicitly quarantined. This is a file-correspondence proof only, **not** driver-origin attestation, modern-client certification, character ownership, semantic authority, or gameplay input. **86/86 isolated modules, 1,504 tests PASS**; check/setup PASS; start correctly blocked (40). Full details: `docs/P59_CAPTURE_BACKED_WIRE_PROVENANCE_CROSSCHECK.md`. Roadmap estimate 92% subjective; complete live CRA/ENU acceptance 0%. Only `setup.bat` and `start.bat` remain operator launchers.

---

# ANKA_NEXT — P57 SQLite crash-atomic schema startup

P57 fixes a reproducible partial-database creation failure in the **synthetic-only** Canonical journal: it now creates the entire schema and version marker within a real SQLite transaction, validates exact existing table/index contracts, refuses unsafe unversioned partial schemas, protects v1 migration, and handles bounded concurrent WAL startup contention. The synthetic fault test runs automatically in `check`/`setup`. See `docs/P57_SQLITE_SCHEMA_CRASH_ATOMIC_BOOTSTRAP.md` and `verification/P57_offline_acceptance_receipt.json`. Live start remains blocked; only `setup.bat` and `start.bat` are root operator commands.

---

# ANKA_NEXT — P56 source-bound Canonical batch receipts

P56 extends P55's synthetic transactional journal with a durable **source-bound batch receipt**: one upstream logical batch is now atomically tied to its exact event range, event payload digest, final hash-chain tip and projection. Exact retries are idempotent even after lost COMMIT acknowledgement; batch/source relabelling, receipt tampering and adoption of unreceipted events fail closed. The synthetic ledger migrates v1→v2 under a serialized writer lock. Historical/current protocol drafts still cannot enter this path. **83/83 isolated modules, 1,449 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). Roadmap estimate remains 92%; verified live CRA/ENU acceptance remains 0%. See `docs/P56_SOURCE_BOUND_BATCH_RECEIPTS_AND_SCHEMA_V2.md` and `verification/P56_offline_acceptance_receipt.json`.

---

# ANKA_NEXT — P55 transactional Canonical batch/fencing foundation

P55 ports the strongest transactional-live-truth invariant from the old R5.198 design into ANKA_NEXT's cleaner **synthetic-only** Canonical journal: one logical event batch is fully reduced before durable insertion, journal + projection commit together, and any ambiguous COMMIT acknowledgement or failed rollback **fences the writer until close/reopen + replay**. `append_fixture` now uses the same batch path. Historical/current protocol drafts still cannot enter this store and no input authority exists. **82/82 isolated modules, 1,433 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). See `docs/P55_TRANSACTIONAL_CANONICAL_BATCH_AND_COMMIT_FENCING.md`. Roadmap estimate remains 92%; verified live CRA/ENU acceptance remains 0%.

---

# ANKA_NEXT — P54 historical process/flow/character/fight-actor continuity

P54 extends the P53 historical identity chain through P45/P46 fight observations: a historical `jnj` character/actor witness must match the same exact flow, transport generation, build and ordered fight actor evidence before the chain is reported as research-consistent. A new two-account aggregate composes stable Windows process/socket candidates → historical character → historical fight actor without exposing private identifiers or inventing cross-flow ordering. **81/81 isolated modules, 1,411 tests PASS**; `check`/`setup` PASS; `start` remains intentionally blocked (exit 40). This is historical research only, not current-client identity or gameplay authority. See `docs/P54_HISTORICAL_PROCESS_FLOW_CHARACTER_ACTOR_CONTINUITY.md`.

---

# ANKA_NEXT — P53 historical identity-chain research

P53 adds a hash-pinned, research-only Dofus 3.7.10.10 `jnj` character identity witness and composes it with the existing stable Windows process/socket candidate topology. It explicitly refuses to treat the old `jns` implementation as an identity capability because the historical registry does not declare `LOCAL_ACTOR` for that handler. Full isolated offline verification: **80 modules / 1,387 tests PASS**. This does **not** certify the current client or enable gameplay; `start.bat` remains intentionally blocked. See `docs/P53_HISTORICAL_CHARACTER_FLOW_PROCESS_IDENTITY.md`.

---

# ANKA_NEXT — P52 MULTI-CLIENT PROCESS/SOCKET TOPOLOGY (21 October 2026)

P52 connects the existing two-boundary Windows process/flow evidence into a privacy-safe **multi-account candidate topology** audit: duplicate TCP selectors cannot masquerade as two accounts, a process with two sockets counts as one process, and mismatched/ambiguous owners stay explicit. Uses existing P51 validation, preserving its output contract. A 3-case P52 smoke runs in existing `check`/`setup` (no extra BAT). **78/78 isolated modules, 1,356 tests passed**; `check`/`setup` PASS; `start` intentionally blocks (exit 40), incident ZIP integrity PASS. No authentic Windows/CRA/ENU identity, verified modern protocol, Canonical commits or input authority. Roadmap scope estimate 92% (subjective), complete live CRA/ENU acceptance 0%. Read `docs/P52_MULTI_ACCOUNT_SOCKET_PROCESS_TOPOLOGY.md` and `verification/P52_offline_acceptance_receipt.json`. Only `setup.bat` and `start.bat` remain root operators.

---

# ANKA_NEXT — P51 WINDOWS FLOW OWNERSHIP STABILITY (21 October 2026)

P51 fixes a real passive-ingress attribution issue: the before/after TCP-table intersection could hide a contradictory owner that disappeared between snapshots and incorrectly report a unique provisional flow/process hint. The now lossless two-boundary join rejects duplicated or conflicting endpoint owners, PID/HWND/process-generation changes, unexpected executable images, geometry or minimization changes, stale scan intervals, and incomplete inventories. It emits only privacy-safe counts, **never** verified CRA/ENU identity or gameplay permission. Normal `check`/`setup` exercise three offline consistency cases. **77/77 modules and 1,336 tests passed**, check/setup PASS, `start` intentionally blocked (exit 40), incident ZIP verified. Read `docs/P51_WINDOWS_TCP_OWNER_SNAPSHOT_STABILITY.md` and `verification/P51_offline_acceptance_receipt.json`. Subjective historical roadmap 92%, real live CRA/ENU acceptance 0%. Only root operator BAT files remain `setup.bat` and `start.bat`.

---

# ANKA_NEXT — P49 CURRENT RELEASE (21 October 2026)

P49 adds a **real saved-PCAPNG → P4 Capture → P6 Protocol → P47 historical replay** research entry point. It keeps missing driver-drop accounting and account/window identity **explicitly unverified**: even if coherent historical messages decode, the file-level report is `BLOCKED_EVIDENCE`, with zero Canonical commits and zero physical input. `check`/`setup` now verify this safety behavior automatically. No protocol build is certified as current. **Only root BAT files: `setup.bat` and `start.bat`.**

Verification: selected capture/protocol tests **342 PASS + 119 subtests**; separate architecture/diagnostics/integration selection **128 PASS + 32 subtests** (overlapping); `check`/`setup` PASS; `start` deliberately exits 40 and its incident bundle verifies. The broad combined suite is **incomplete** due to execution limits. Subjective roadmap coverage remains **92%**; full live-fight acceptance remains **0%**. Details: `docs/P49_SAVED_PCAPNG_HISTORICAL_REPLAY_UNCERTAINTY.md` and `verification/P49_offline_acceptance_receipt.json`.

---

# ANKA_NEXT — P48 CURRENT RELEASE (21 October 2026)

P48 connects **real CapturePoll/TCP segment bytes → existing P6 ProtocolInspector framing → P47 historical lifecycle/combat replay**, all in an `anka_app` *research-only* composition adapter. It detects transport gaps, unknown driver-loss visibility, source-generation changes, incomplete frames, unmapped messages, foreign flows and two independently reproduced silent/exception failure cases. The new P48 smoke is included in normal `check`/`setup`. See `docs/P48_CAPTURE_TRANSPORT_TO_HISTORICAL_RESEARCH.md` and `verification/P48_offline_acceptance_receipt.json`.

**Offline evidence:** 84 focused tests +24 subtests and a wider 557-test/142-subtest selection pass, `check`/`setup` PASS; broader full suite not verified. `start` is still intentionally blocked (exit 40) and diagnostic ZIP verifies. No current-client adapter, Canonical authority, or physical input. Exactly `setup.bat` and `start.bat` remain operator BAT commands. Estimated development-scope coverage 92% (subjective); live full-fight acceptance 0%.

---

# ANKA_NEXT — P47 CURRENT RELEASE (21 October 2026)

P47 integrates P45 lifecycle and P46 combat research decoding into **one bounded, single-flow historical server-wire replay**. Unknown obfuscated messages and unsupported combat actions now remain visible as explicit evidence gaps; duplicated/reordered source cursors, wrong flows/generations and corrupted fields block the research receipt. A clean subset of decoded events can no longer hide missing wire observations in this integrated API. P47's tiny independent smoke runs automatically in `check` and `setup`.

**All outcomes remain research-only.** Historical build 3.7.10.10 is not a certified current-client adapter; no synthetic observation authorizes Canonical commits, spell success, victory, or physical input. `start` remains intentionally blocked (exit 40). The new 28-test P47 suite and 101-test P45–P47 decoder group pass; the full 69-module regression inventory was **not completed** due to timeouts. See `docs/P47_HISTORICAL_WIRE_STREAM_REPLAY_AND_EVIDENCE_GAP_AUDIT.md` and `verification/P47_offline_acceptance_receipt.json`. Subjective development scope **91%**, real complete live-fight acceptance **0%**. Only root BATs: `setup.bat` and `start.bat`.

---

# ANKA_NEXT — P46 CURRENT RELEASE (21 October 2026)

P46 adds **research-only historical Dofus 3.7.10.10 combat wire observations** for `jsq/300` spell records, `jsq/5` push, `jsq/4` teleport and `jwp` result boundaries, plus P45↔P46 same-flow turn/cast causal audit. **No damage, AP/MP settlement, spell success or victory is inferred.** The Kernel, original reference assets, game input and live safety gates remain untouched.

**Verification:** 67/67 modules and 1,231 unittest methods independently passed (66 modules/1,220 in a resumable independent module inventory; the slow P37 verifier module separately passed 11). `check`/`setup` PASS; architecture and 165 assets PASS; `start` intentionally exit 40, incident ZIP validated. **Current-client live fight acceptance 0%.** Estimated engineering scope 91% (subjective, not quality). Root user BATs: `setup.bat`, `start.bat` only.

Read `docs/P46_HISTORICAL_COMBAT_OBSERVATIONS_AND_CROSS_FAMILY_CAUSAL_AUDIT.md` and `verification/P46_offline_acceptance_receipt.json` for exact evidence, limitations, and next gate. The underlying historical source code never executes, and no current-client adapter is certified.

---

> **Current offline release: P45.** Recovered immutable historical decoder provenance and a read-only Dofus 3.7.10.10 round/turn/Ready research adapter. `start.bat` remains intentionally blocked; this ZIP is not a live bot. Read `IMPLEMENTATION_STATUS.md` and `docs/P45_HISTORICAL_FIGHT_LIFECYCLE_AND_PROVENANCE.md`.

---

# P44 — source-integrity-protected read-only native bridge research

The archived R5.198 Unity/BepInEx source is preserved under `native/unity_bridge/` and its files are hash-verified by `setup.bat` / `check`. A new read-only `anka_client` loopback bridge probe can compare an independently observed Windows process generation and 560-cell coordinate snapshot against map/window/camera signatures; **it cannot certify a character, authorize clicking, install the plugin, or activate gameplay.** Windows acceptance and exact-build protocol certification are still pending. See `docs/P44_READ_ONLY_NATIVE_UNITY_BRIDGE_INTEGRATION.md`.

---

# ANKA_NEXT — P43 current release

Research-only protocol comparison now checks case-level provenance and result consistency, complementing P42's exact archive/build/adapter binding. Full 61-module offline inventory /1,138 tests passes; check/setup pass, start intentionally blocks with exit 40. Only root `setup.bat` and `start.bat`, no dashboard or separate user verification launchers. **No current-client live acceptance**. Read `docs/P43_CASE_LEVEL_COMPARISON_LINEAGE_AND_RESULT_CONSISTENCY.md` for changes, limitations and exact evidence.

---

# ANKA_NEXT — P42 offline protocol-evidence integrity

**Current release P42:** comparison results are now bound to the exact evidence archive hash, declared build and adapter before capability research coverage can be counted. All 60 isolated test modules / 1,129 tests and P28–P42 focused 344 tests + 17 subtests passed. `check` and `setup` PASS; `start` deliberately blocks live gameplay with exit 40. The complete project remains offline-only. Only `setup.bat` and `start.bat` are operator commands. Technical details: `docs/P42_EXACT_PROTOCOL_COMPARISON_PROVENANCE_BINDING.md` and `verification/P42_offline_acceptance_receipt.json`. No separate continuation handoff.

---

# ANKA_NEXT — P41 offline improvements

P41 fixes two independently reproduced research-only errors: same-cell position
refreshes were overclassified as movement; and one wire packet could be counted
repeatedly for the same role/capability by changing oracle IDs. The new P41
regressions preserve genuine movement ambiguity, cross-role source independence,
and legitimate multi-field messages. **All 59 module-isolated test files / 1,121
test methods passed**, and the P28–P41 focused gate passed 336 tests plus
12 subtests. `check` and `setup` PASS; `start` still refuses live execution
with exit 40 and a verified incident bundle. Modern-client acceptance remains
0%, and estimated roadmap coverage 88% (not a quality score). No separate
handoff or extra operator BAT was introduced. Full details:
`docs/P41_CELL_TRANSITION_AND_PROTOCOL_CLAIM_INTEGRITY.md` and
`verification/P41_offline_acceptance_receipt.json`.

---

## P40 — Source-independent protocol research evidence

The protocol-update research intake rejects reusing **one selected network message** or **one oracle assertion** as distinct CRA/ENU coverage by changing the declared role or aliasing evidence filenames. Normal independent source observations remain research-only, never live certification. See `docs/P40_CROSS_ACCOUNT_EVIDENCE_SOURCE_INDEPENDENCE.md`. Focused offline gate: 304 selected tests + 12 subtests PASS; full suite incomplete; live integration unimplemented. Only `setup.bat` and `start.bat` are operator entrypoints.

# Current status — P39 (offline research only)

The P39 complete project preserves P38 and adds turn-scoped target-cell witness expiry and pre-cast MP-movement confounder tests. See `docs/P39_TARGET_CONTEXT_INTEGRITY.md` and `verification/P39_offline_acceptance_receipt.json`. The game is **not live-ready**: `start` remains deliberately blocked; current-build CRA/ENU packets, real window/calibration acceptance, authoritative event admission and physical execution remain unverified. Only `setup.bat` and `start.bat` are operator commands.

---

> **Current milestone: P38 — research observation-window causal guards.** See `docs/P38_CAUSAL_OBSERVATION_WINDOW_HARDENING.md`, `IMPLEMENTATION_STATUS.md` and `verification/P38_offline_acceptance_receipt.json`. Still offline research, with live input blocked. Only root `setup.bat` and `start.bat` are operator BATs. Historical milestone notes below are retained unchanged.

> **Current milestone: P37 (offline verification infrastructure).** See `00_READ_FIRST_NEXT_CHAT.md`, `docs/P37_CHECKPOINTED_RECOVERABLE_VERIFICATION.md` and `verification/P37_offline_acceptance_receipt.json`. Live action remains deliberately blocked. Only `setup.bat` and `start.bat` are operator BATs.

# CURRENT MILESTONE: P36 (21 October 2026)

**Start here:** `00_READ_FIRST_NEXT_CHAT.md`, `IMPLEMENTATION_STATUS.md`, `docs/P36_TARGET_EFFECT_CONFOUNDER_AUDIT_AND_MODULE_ISOLATION.md`. Offline research only; `start.bat` remains intentionally blocked. Only two root operator BAT launchers: `setup.bat` and `start.bat`. The remainder of this README retains historical milestone notes.

---

**Current milestone:** P34 research reconstruction-coverage and unsupported spell-effect audit. See [`docs/P34_RECONSTRUCTION_COVERAGE_AND_UNSUPPORTED_EFFECTS.md`](docs/P34_RECONSTRUCTION_COVERAGE_AND_UNSUPPORTED_EFFECTS.md). Operator commands remain only `setup.bat` and `start.bat`. No live gameplay input.

**P31:** Added bounded research-only fight-event schema-2 adapters, exact-source oracle comparisons and single-stream turn chronology checks. No current-build mapping or live activation. See `docs/P31_FIGHT_EVENT_RESEARCH_AND_ORACLE_COMPARISON.md`.

## P30 — locally reviewed protocol research recipes

New exact-build AP/MP/HP wire mappings can be compared using reviewed, hash-pinned local JSON recipes. Evidence ZIPs cannot execute or install recipes. See `docs/P30_DECLARATIVE_RESEARCH_PROTOCOL_ADAPTERS.md`. No current-build adapter is certified and `start.bat` remains blocked. Only `setup.bat` and `start.bat` are operator commands.

# ANKA_NEXT — P26 Passive Startup Capture Diagnostics

**Offline development build. NOT ready for live Dofus execution.**

## Windows operation: only two commands

1. Run **`setup.bat`** once to install dependencies, validate JSON settings, verify the preserved game-data assets and run a deterministic cross-system diagnostic smoke test.
2. Edit **`config/user.json`** for player names and mission settings, then run **`start.bat`**. It checks system boundaries, records outstanding live-readiness blockers and currently **refuses physical gameplay** (`LIVE_RUNTIME_NOT_IMPLEMENTED`, exit code 40). Do not interpret a successful offline rehearsal as readiness to play.

There are **no other root `.bat` commands**, demo launchers, or dashboard. Diagnostics are created automatically under `runtime/runs/<run-id>/`, including a GPT-friendly incident ZIP when startup is blocked. Review local paths and data before sharing bundles.

Python 3.13 is required on Windows. The underlying launcher is internal at `tools/windows/_entry.bat`; it runs bootstrap checks even if Python dependencies fail and records an early-stage log.

## P26 read-only network readiness (NEW)

On Windows, `start.bat` now attempts a **single, capped 10-second passive network sample** only when `config/user.json` explicitly configures both known authorized game server ports and the local capture interface, Scapy is installed, and a configured game-window candidate exists. `setup.bat` conditionally installs the optional Scapy dependency for this configuration; Npcap is still an external driver requiring independent Windows validation. This writes only privacy-limited transport counters and process-hint categories to the existing startup incident ZIP—**not raw packet data**. It cannot decode the current client or enable gameplay, and `start.bat` still exits 40. See `docs/P26_PASSIVE_STARTUP_CAPTURE_EVIDENCE.md`.

## P24 improvements

P24 replaces the one-process developer test runner with an automatically inventoried, eight-shard, isolated verification gate. Every test module must be executed exactly once; missing tests, hangs, failed tests or suspicious success output are treated as failures. The shard, source modules and last available test output appear in structured incident diagnostics. This adds **no new operator commands**. See `docs/P24_ISOLATED_VERIFICATION_AND_EVIDENCE_DIAGNOSTICS.md`. The intermittent host/runtime slowdown is not claimed permanently resolved.

## P23 improvements

Historical `Capture → Protocol → Semantic → Canonical research` audits now **withhold** provisional candidates until the final transport audit passes. A later TCP gap, unfinished frame, reset, mapped-schema drift, forged source coordinate, or resource limit causes a diagnostic quarantine without mutating Live State or enabling input. Benign unknown message types are recorded without discarding clean known evidence. See `docs/P23_CAPTURE_FINALITY_AND_SEMANTIC_PROVENANCE.md`.

## P22 improvements

P22 adds exact event-level source linkage between the durable synthetic Canonical journal and CRA/ENU Coordination. Turn starts/ends and both fight-start observations must reference their original hash-audited journal event, not merely agree with a final actor snapshot. The permanent negative suite now covers missing, reused and orphaned evidence IDs. These link checks run before Decision or fake Execution. **Synthetic linkage never certifies global cross-account chronology or live input.** See `docs/P22_CAUSAL_EVENT_PROVENANCE_OFFLINE.md`.

## P21 improvements

Automated import-boundary audit protects the independent packages against inadvertent cross-system coupling. Evidence-based readiness blockers now appear automatically in startup diagnostics, and the full historical twelve-scenario fault matrix is a permanent developer regression test. See `docs/P21_AUTOMATED_ARCHITECTURE_GATES_AND_LIVE_READINESS.md`.

## P20 implemented

The P20 cross-system regression in `src/anka_app/integrated_offline.py` connects the *actual offline implementations*:

`Canonical journal → replay-verified Live State → CRA/ENU Coordination → Workflow outcome accounting → Kernel-backed Decision research → independent synthetic-only Execution fixture → durable outcome settlement`

It checks that a party-level turn handoff agrees with the state snapshots, that exact session/account/fight generations match, and that failures block downstream fake dispatch. Its negative scenarios include missing end-turn confirmation, conflicting owners, stale ENU state, wrong fight, lost focus, missing outcome, post-dispatch exceptions and duplicate dispatch attempts.

The execution fixture is **not derived from the Decision research report**, which does not grant action authority. The fake driver cannot produce OS mouse/keyboard input. Synthetic ACCEPTED outcomes never certify current-client server acceptance. This is an anti-regression laboratory, not a live runtime.

`setup.bat` automatically exercises a positive handoff and a deliberately broken handoff; the expected negative test does not create a misleading operator incident. The complete twelve-scenario fault matrix runs in internal developer tests, not every time you start the application. `start.bat` reports missing live prerequisites and refuses input without wasting time on synthetic fights.

## Developer verification — not operator commands

Tests are kept in `tests/`. Developers can run them with `PYTHONPATH=src python -m pytest -q tests` (or use the internal `python -m anka_app.cli verify`). These are not additional `.bat` commands that operators need to learn.

Earlier milestone documents in `docs/` are historical; any BAT commands named there were removed from the root in P20. They are not current operator instructions.

## Remaining live blockers

- Real Windows/Npcap and current-client process ↔ account association verification.
- Current-build protocol semantic certification and authoritative Canonical admission.
- Actual multi-account Live State, modern spell/equipment verification, FightAI and production Workflow.
- Windows focus/calibration revalidation, real physical execution and independent server outcome observation.
- End-to-end real CRA/ENU battle/turn acceptance, including recoverable failures.

Preserved kernel, static data, calibration reference and original R5.198 source provenance remain separate. P20 makes **no claim of end-to-end live-fight readiness**.

## P25 host evidence

`setup.bat` and `start.bat` automatically generate read-only host-readiness diagnostics as described in `docs/P25_PASSIVE_WINDOWS_HOST_READINESS.md`. This does not certify game capture or authorize any input. No dashboard or additional BAT commands are required.

## P27 passive wire diagnostics

When Windows capture is explicitly configured, `start.bat` now also performs bounded *in-memory* protocol wire inspection after capture. It reports only sanitized counters, **not** packet payloads, and never enables gameplay. Current-client semantic certification and real Windows/Npcap acceptance remain pending. See `docs/P27_IN_MEMORY_WIRE_DIAGNOSTICS.md`.

## P28: protocol update evidence packages

Protocol changes can be staged as bounded, hashed evidence ZIPs in
`protocol_updates/`. Ordinary `setup.bat` inspects them read-only and adds a
privacy-minimized qualification-intake report. This does **not** activate a
new adapter or certify current-client gameplay. See
`docs/P28_PROTOCOL_EVIDENCE_INTAKE.md`. The only operator BAT scripts remain
`setup.bat` and `start.bat`.


## P29 — exact-source protocol comparisons (research only)

`setup.bat` now compares pinned, explicit-source observations from staged evidence packs with **locally registered** historical semantics when the exact build matches. Reports identify mismatching field names, not values. Unavailable modern adapters remain unavailable; no package is activated, no authoritative Canonical state is written, and no physical input is enabled. Only `setup.bat` and `start.bat` are user-facing. See `docs/P29_PROTOCOL_ORACLE_COMPARISON.md`.

## P32 — protocol research evidence quality matrix

When a protocol evidence ZIP is staged in `protocol_updates/`, the normal `setup.bat` automatically reports per-capability comparison results, missing evidence, claimed role coverage and exact-source/witness gaps. A matching research matrix cannot certify current-client semantics, actual account identity, or gameplay authority. See `docs/P32_PROTOCOL_CAPABILITY_ACCEPTANCE_MATRIX.md`. No extra BAT commands are needed.


P35 research evidence-window reconciliation: see `docs/P35_CAUSAL_SNAPSHOT_RECONCILIATION_RESEARCH.md`. No live action enabled.


### P50: multi-flow PCAPNG research discovery
Saved captures can now be inventoried into privacy-preserving TCP flow candidates. A selected historical replay is pinned to the exact capture SHA, flow list and packet counts. No result proves which account/character owns a TCP flow; all results remain offline research. See `docs/P50_PCAPNG_MULTIFLOW_DISCOVERY_AND_EXACT_SNAPSHOT_SELECTION.md`. The full 75-module regression inventory passed (1,306 tests). `start.bat` remains blocked pending real current-client acceptance.

## P58 — Research-only Canonical admission rehearsal

P58 adds bounded per-packet byte/capture provenance and a read-only admission consistency audit (`anka_contracts.admission` and `anka_canonical.admission_review`). Every result remains uncertified and journal-denied, including structurally consistent “current-build” claims. Permanent adversarial tests and a `check`/`setup` smoke verify the boundary. Details: `docs/P58_UNTRUSTED_CANONICAL_ADMISSION_REHEARSAL.md`. **No live state admission or Windows-input integration has been enabled.**

import json
from hashlib import sha256
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from anka_observability.api import LocalDiagnostics,NullDiagnostics
from anka_observability.bundle import verify_incident
from anka_observability.redaction import sanitize
from anka_contracts.diagnostics import DiagnosticEvent,now_utc

class TestDiagnostics(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name);self.obs=LocalDiagnostics(self.root,max_recent=3)
    def test_contract_accepts_version_and_requires_valid_events(self):
        event=DiagnosticEvent(1,'id','setup.stage_started','INFO',now_utc(),1,1,'inv',payload={})
        self.assertEqual(DiagnosticEvent.from_dict(event.to_dict()),event)
        with self.assertRaises(ValueError):DiagnosticEvent(2,'id','setup.stage_started','INFO',now_utc(),1,1,'inv',payload={})
        with self.assertRaises(ValueError):DiagnosticEvent(1,'id','bad event name','INFO',now_utc(),1,1,'inv',payload={})
    def test_observer_non_authoritative_interface(self):
        self.assertEqual(self.obs.record('setup.stage_started'),'RECORDED')
        self.assertEqual(NullDiagnostics().emit(None),'UNAVAILABLE')
        self.assertEqual(json.loads((self.obs.folder/'events.jsonl').read_text().splitlines()[0])['event_name'],'setup.stage_started')
    def test_bounded_memory_and_drop_count(self):
        for i in range(20):self.obs.record('debug.sample',payload={'seq':i})
        self.assertEqual(len(self.obs.recent),3)
        self.assertEqual(self.obs.recent[-1]['payload']['seq'],19)
    def test_disk_limit_loss_is_explicit(self):
        obs=LocalDiagnostics(self.root, max_journal_bytes=1)
        self.assertEqual(obs.record('setup.stage_started'),'DROPPED')
        self.assertEqual(obs.dropped,1)
    def test_sanitization_nested(self):
        self.obs.record('setup.stage_failed',severity='ERROR',payload={'credentials':{'token':'supersecret'},'free_text':'Bearer abcdef0123456789'})
        text=(self.obs.folder/'events.jsonl').read_text()
        self.assertNotIn('supersecret',text)
        self.assertNotIn('abcdef0123456789',text)
        self.assertIn('[REDACTED]',text)
    def test_bundle_verifies_and_claims_missing_evidence(self):
        self.obs.record('coordination.owner_not_proven',severity='ERROR',failure_code='TURN_OWNER_UNPROVEN',boundary='coordination.ready_to_first_turn')
        path=self.obs.export_incident('TURN_OWNER_UNPROVEN',boundary='coordination.ready_to_first_turn')
        self.assertEqual(verify_incident(path)['status'],'PASS')
        with ZipFile(path) as z:
            diag=json.loads(z.read('diagnosis.json'))
            matrix=json.loads(z.read('evidence_matrix.json'))
            self.assertEqual(diag['confidence'],'UNDETERMINED')
            self.assertEqual(matrix['sections']['execution'],'MISSING')
            self.assertFalse(json.loads(z.read('manifest.json'))['raw_protocol_included'])
    def test_corrupt_manifest_checksum_is_detected(self):
        path=self.obs.export_incident('FAULT_INJECTION',boundary='test.bundle')
        with ZipFile(path) as z:files={name:z.read(name) for name in z.namelist()}
        files['diagnosis.json']=b'CORRUPTED'+files['diagnosis.json']
        with ZipFile(path,'w',ZIP_DEFLATED) as z:
            for name,blob in files.items():z.writestr(name,blob)
        result=verify_incident(path)
        self.assertEqual(result['status'],'FAIL')
        self.assertTrue(any('BAD_CHECKSUM' in s for s in result['errors']))
    def test_zip_path_traversal_rejected(self):
        path=self.obs.export_incident('FAULT_INJECTION',boundary='test.bundle')
        with ZipFile(path, 'a') as z:z.writestr('../injected.txt','malicious')
        self.assertEqual(verify_incident(path)['status'],'FAIL')
    def test_failure_of_observer_cannot_crash_business(self):
        self.obs.available=False
        self.assertEqual(self.obs.record('setup.stage_failed',severity='ERROR'),'UNAVAILABLE')
        self.assertFalse((self.obs.folder/'events.jsonl').exists())
    def test_unclean_start_state_detectable(self):
        self.assertEqual(json.loads((self.obs.folder/'run_state.json').read_text())['state'],'RUNNING')
        self.obs.finish('BLOCKED')
        self.assertEqual(json.loads((self.obs.folder/'run_state.json').read_text())['state'],'BLOCKED')
    def test_sanitize_plain_text_path(self):
        value=sanitize('Found C:\\Users\\dell\\private.txt token=bigsecret')
        self.assertNotIn('dell',value)
        self.assertNotIn('bigsecret',value)

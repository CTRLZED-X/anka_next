import ast
import json
from pathlib import Path
import subprocess
import sys
import unittest
from anka_app.cli import ROOT,_manifest_check

class TestFoundation(unittest.TestCase):
    def test_reused_kernel_available_without_legacy_platform(self):
        import anka_game_kernel
        self.assertTrue(hasattr(anka_game_kernel,'GameKernel'))
        self.assertTrue((ROOT/'src/anka_game_kernel/data/spell_mechanics/verified_spells.json').exists())
        self.assertEqual(_manifest_check()['integrity'],'PASS')
    def test_all_proposed_packages_are_separate(self):
        for name in ('capture','protocol','canonical','live_state','decision','execution','coordination','workflow','client','observability'):
            self.assertTrue((ROOT/'src'/f'anka_{name}'/'__init__.py').is_file())
    def test_kernel_not_dependent_on_app(self):
        for f in (ROOT/'src/anka_game_kernel').rglob('*.py'):
            tree=ast.parse(f.read_text())
            imports=[getattr(x,'module','') or '' for x in ast.walk(tree) if isinstance(x,ast.ImportFrom)]
            self.assertFalse(any(s.startswith(('anka_app','anka_observability','anka_execution')) for s in imports),f.name)
    def test_start_safely_blocked_and_exported(self):
        proc=subprocess.run([sys.executable,'-m','anka_app.cli','start'],cwd=ROOT,capture_output=True,text=True,timeout=25)
        self.assertEqual(proc.returncode,40)
        self.assertIn('ANKA_FAILURE=LIVE_RUNTIME_NOT_IMPLEMENTED',proc.stdout)
        lines=dict(line.split('=',1) for line in proc.stdout.splitlines() if '=' in line)
        self.assertTrue(Path(lines['ANKA_BUNDLE']).exists())
    def test_synthetic_replay_never_physically_sends(self):
        proc=subprocess.run([sys.executable,'-m','anka_app.cli','replay'],cwd=ROOT,capture_output=True,text=True,timeout=25)
        self.assertEqual(proc.returncode,0)
        self.assertIn('"physical_input_sent": false',proc.stdout)
    def test_no_real_input_drivers_in_foundation(self):
        risky=['pyautogui','win32api','win32gui','pynput','ctypes.windll','SendInput','SetCursorPos','mouse_event']
        for dirname in ('anka_app','anka_observability','anka_contracts'):
            for path in (ROOT/'src'/dirname).rglob('*.py'):
                content=path.read_text()
                for token in risky:self.assertNotIn(token,content,path.name)

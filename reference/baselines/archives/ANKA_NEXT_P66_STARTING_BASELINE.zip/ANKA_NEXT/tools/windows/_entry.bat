@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0..\.."
rem Stage 0 runs in cmd.exe; it does not require Python or installed packages.
set "ANKA_BOOTDIR=%CD%\runtime\bootstrap"
if not exist "%ANKA_BOOTDIR%" mkdir "%ANKA_BOOTDIR%" 2>nul
if not exist "%ANKA_BOOTDIR%" set "ANKA_BOOTDIR=%TEMP%\ANKA_NEXT\bootstrap"
if not exist "%ANKA_BOOTDIR%" mkdir "%ANKA_BOOTDIR%" 2>nul
set "ANKA_BOOTLOG=%ANKA_BOOTDIR%\inv_%RANDOM%_%RANDOM%.log"
>"%ANKA_BOOTLOG%" echo STAGE=BAT_ENTERED
>>"%ANKA_BOOTLOG%" echo LOCAL_START=%DATE% %TIME%
>>"%ANKA_BOOTLOG%" echo OPERATION=%~1
set "PYTHONPATH=%CD%\src"
set "ANKA_PYTHON="
where py >nul 2>nul
if not errorlevel 1 (
    py -3.13 -V >nul 2>nul
    if not errorlevel 1 set "ANKA_PYTHON=py -3.13"
)
if not defined ANKA_PYTHON (
    where python >nul 2>nul
    if not errorlevel 1 set "ANKA_PYTHON=python"
)
if not defined ANKA_PYTHON (
    >>"%ANKA_BOOTLOG%" echo STAGE=PYTHON_NOT_FOUND
    echo ANKA_STATUS=BLOCKED
    echo ANKA_FAILURE=PYTHON_NOT_FOUND
    echo ANKA_BOOTLOG=%ANKA_BOOTLOG%
    exit /b 40
)
>>"%ANKA_BOOTLOG%" echo STAGE=PYTHON_FOUND
if /I "%~1"=="setup" (
    %ANKA_PYTHON% -c "import sys;sys.exit(0 if sys.version_info[:2]==(3,13) else 1)" >nul 2>nul
    if errorlevel 1 (
        >>"%ANKA_BOOTLOG%" echo STAGE=PYTHON_VERSION_UNSUPPORTED
        echo ANKA_STATUS=BLOCKED
        echo ANKA_FAILURE=PYTHON_VERSION_UNSUPPORTED
        echo ANKA_BOOTLOG=%ANKA_BOOTLOG%
        exit /b 40
    )
    if not exist ".venv\Scripts\python.exe" (
        >>"%ANKA_BOOTLOG%" echo STAGE=CREATE_VENV
        %ANKA_PYTHON% -m venv ".venv" >>"%ANKA_BOOTLOG%" 2>&1
        if errorlevel 1 goto SETUP_DEPENDENCY_FAILED
    )
    >>"%ANKA_BOOTLOG%" echo STAGE=INSTALL_DEPENDENCIES
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements-p1.txt" >>"%ANKA_BOOTLOG%" 2>&1
    if errorlevel 1 goto SETUP_DEPENDENCY_FAILED
    rem Only opt in to optional capture dependencies when user.json explicitly
    rem configures both an interface and one or more server ports. No third
    rem operator command is necessary. Missing Npcap is diagnosed at start.
    ".venv\Scripts\python.exe" -c "import json,sys;cfg=json.load(open('config/user.json',encoding='utf8')).get('capture',{});sys.exit(0 if cfg.get('server_ports') and cfg.get('interface') else 1)" >nul 2>nul
    if not errorlevel 1 (
        >>"%ANKA_BOOTLOG%" echo STAGE=INSTALL_CONFIGURED_CAPTURE_DEPENDENCIES
        ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements-windows-capture.txt" >>"%ANKA_BOOTLOG%" 2>&1
        if errorlevel 1 >>"%ANKA_BOOTLOG%" echo STAGE=OPTIONAL_CAPTURE_DEPENDENCY_INSTALL_FAILED
    )
)
if exist ".venv\Scripts\python.exe" set "ANKA_PYTHON=.venv\Scripts\python.exe"
%ANKA_PYTHON% -m anka_app.cli %* >>"%ANKA_BOOTLOG%" 2>&1
set "ANKA_EXIT=%errorlevel%"
>>"%ANKA_BOOTLOG%" echo EXIT_CODE=%ANKA_EXIT%
type "%ANKA_BOOTLOG%"
echo ANKA_BOOTLOG=%ANKA_BOOTLOG%
exit /b %ANKA_EXIT%

:SETUP_DEPENDENCY_FAILED
>>"%ANKA_BOOTLOG%" echo STAGE=DEPENDENCY_INSTALL_FAILED
%ANKA_PYTHON% "tools\bootstrap_failure.py" DEPENDENCY_INSTALL_FAILED >>"%ANKA_BOOTLOG%" 2>&1
>>"%ANKA_BOOTLOG%" echo EXIT_CODE=40
set "ANKA_FAILURE=DEPENDENCY_INSTALL_FAILED"
echo ANKA_STATUS=BLOCKED
echo ANKA_FAILURE=%ANKA_FAILURE%
type "%ANKA_BOOTLOG%"
echo ANKA_BOOTLOG=%ANKA_BOOTLOG%
exit /b 40

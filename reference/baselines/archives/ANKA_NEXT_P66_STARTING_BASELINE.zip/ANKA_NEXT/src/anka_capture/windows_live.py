"""Optional read-only Npcap/Scapy capture adapter for Windows.

Never sends packets, never requests mouse input, never writes raw packets.
Sampled only when start is explicitly configured; live acceptance still PENDING.
"""
from __future__ import annotations
import os
import secrets
from hashlib import sha256
from time import monotonic_ns
from typing import Callable
from anka_contracts.capture import CapturePoll
from anka_capture.api import validate_ports
from anka_capture.live import BoundedSegmentQueue, LiveCaptureAudit
from anka_contracts.capture import CapturedTcpSegment


class WindowsLiveCapture:
    def __init__(self, *, interface:str, server_ports:tuple[int,...],
                 source_generation:str|None=None, sniffer_factory=None,
                 max_segments:int=1024, max_bytes:int=4*1024*1024,
                 require_windows:bool=True, evidence_recorder=None):
        validate_ports(server_ports)
        if require_windows and os.name!='nt':raise RuntimeError('LIVE_CAPTURE_WINDOWS_REQUIRED')
        if not isinstance(interface,str) or not 1<=len(interface)<=255 or interface.strip()!=interface or any(ord(ch)<32 for ch in interface):
            raise ValueError('CAPTURE_INTERFACE_INVALID')
        self.interface=interface
        self.ports=tuple(server_ports)
        self.generation=source_generation or secrets.token_hex(12)
        self.queue=BoundedSegmentQueue(source_generation=self.generation,max_segments=max_segments,max_bytes=max_bytes)
        self._flow_salt=secrets.token_bytes(32)
        self._flow_keys:dict[str,tuple[str,int,str,int]]={}
        self._max_flow_keys=4096
        self._sniffer_factory=sniffer_factory
        self._sniffer=None
        self._evidence_recorder=evidence_recorder
        self._raw_evidence_receipt=None
        self._started=False
        self._stopped=False
        self._frame_no=0
        self._rejected_frames=0
        self._unsupported_frames=0
        self._capture_interrupted=False

    def _ensure_factory(self):
        if self._sniffer_factory is None:
            try:
                from scapy.all import AsyncSniffer
                from scapy.all import conf
            except ImportError as exc:
                raise RuntimeError('SCAPY_NOT_INSTALLED_OPTIONAL_CAPTURE_DEPENDENCY') from exc
            if not getattr(conf,'use_pcap',False):
                raise RuntimeError('NPCAP_PCAP_BACKEND_NOT_ENABLED')
            self._sniffer_factory=AsyncSniffer

    def ingest_fields(self, *, src:str,dst:str,sport:int,dport:int,seq:int,
                      flags:int,payload:bytes):
        """Ingress contract used by Scapy callback and deterministic tests."""
        self._frame_no+=1
        if self._stopped or not self._started:return False
        try:
            if not (isinstance(src,str) and isinstance(dst,str) and
                    type(sport) is int and type(dport) is int and 0<=sport<=65535 and 0<=dport<=65535):
                raise ValueError('INVALID_ENDPOINT')
            if (sport in self.ports)==(dport in self.ports):
                # Both/none => direction ambiguous. Never guess.
                raise ValueError('PORT_DIRECTION_AMBIGUOUS')
            if type(seq) is not int or not 0<=seq<2**32 or type(flags) is not int or not 0<=flags<=255 or not isinstance(payload,bytes):
                raise ValueError('TCP_FRAME_INVALID')
            if not payload and not (flags & 0x07):return True
            direction='server_to_client' if sport in self.ports else 'client_to_server'
            key=(dst,dport,src,sport) if direction=='server_to_client' else (src,sport,dst,dport)
            token=sha256(self._flow_salt+repr(key).encode('utf8')).hexdigest()[:24]
            if token not in self._flow_keys and len(self._flow_keys)>=self._max_flow_keys:
                raise ValueError('CAPTURE_FLOW_CAPACITY_EXCEEDED')
            self._flow_keys[token]=key
            return self.queue.push(CapturedTcpSegment(token,direction,seq,payload,self._frame_no,flags))
        except (ValueError,TypeError):
            self._rejected_frames+=1
            self.queue.push(None)  # count as observable loss, not silent skip
            return False

    def ingest_packet(self, packet)->None:
        """Scapy callback. Keep imports local; no dependency in offline runs."""
        try:
            from scapy.layers.inet import IP, TCP
            if not packet.haslayer(IP) or not packet.haslayer(TCP):
                self._unsupported_frames+=1
                self.queue.push(None)
                if self._evidence_recorder is not None:
                    self._evidence_recorder.mark_incomplete()
                return
            ip=packet[IP];tcp=packet[TCP]
            accepted=self.ingest_fields(src=str(ip.src),dst=str(ip.dst),sport=int(tcp.sport),dport=int(tcp.dport),
                               seq=int(tcp.seq),flags=int(tcp.flags),payload=bytes(tcp.payload))
            if self._evidence_recorder is not None:
                if not accepted:
                    self._evidence_recorder.mark_incomplete()
                # Some Npcap interfaces expose IP packets without Ethernet. A
                # synthetic L2 header is explicitly non-origin attestation.
                from scapy.layers.l2 import Ether
                frame=(bytes(packet[Ether]) if packet.haslayer(Ether) else
                       b'\x00'*12 + b'\x08\x00' + bytes(ip))
                if not self._evidence_recorder.record(frame):
                    self.queue.push(None)  # capture completeness is now uncertain
        except Exception:
            # Unsupported frames or parser exceptions are recorded as a loss,
            # not ignored (including selected-port IPv6 frames).
            self._rejected_frames+=1
            self.queue.push(None)
            if self._evidence_recorder is not None:
                self._evidence_recorder.mark_incomplete()

    def mark_capture_interrupted(self)->None:
        """Seal an abnormal observation window as incomplete, at most once.

        A normally drained sample may still be uncertified, but a failed poll,
        consumer, or sniffer shutdown must never leave a zero-gap raw artifact.
        This deliberately does not contain exception details or private data.
        """
        if not self._capture_interrupted:
            self._capture_interrupted=True
            if self._evidence_recorder is not None:
                self._evidence_recorder.mark_incomplete()

    def start(self)->None:
        if self._started or self._stopped:raise RuntimeError('CAPTURE_ALREADY_STARTED_OR_STOPPED')
        expression='tcp and ('+' or '.join('port '+str(p) for p in self.ports)+')'
        try:
            self._ensure_factory()
            self._sniffer=self._sniffer_factory(iface=self.interface,filter=expression,
                                               store=False,prn=self.ingest_packet)
            self._started=True
            self._sniffer.start()
        except Exception as exc:
            self.queue.close()
            self._started=False
            self._stopped=True
            if self._evidence_recorder is not None:
                try:
                    self.mark_capture_interrupted()
                    self._raw_evidence_receipt=self._evidence_recorder.close()
                except Exception:
                    pass  # original startup failure remains authoritative
            raise RuntimeError('LIVE_CAPTURE_START_FAILED') from exc

    def poll(self, *,max_segments:int,timeout_seconds:float):
        if not self._started:raise RuntimeError('LIVE_CAPTURE_NOT_STARTED')
        return self.queue.poll(max_segments=max_segments,timeout_seconds=timeout_seconds)

    def quiesce(self)->None:
        """Stop the packet source, but leave research evidence open for drain audit.

        Callers that consume buffered segments must finish verifying those
        segments before finalizing the PCAPNG. Direct ``stop()`` remains the
        one-step shutdown API for existing callers.
        """
        if self._stopped:return
        self._stopped=True
        if not self._started:
            self.mark_capture_interrupted()
        try:
            if self._sniffer is not None and self._started:
                self._sniffer.stop()
        except BaseException:
            self.mark_capture_interrupted()
            raise
        finally:
            self.queue.close()

    def stop(self)->None:
        """Idempotently quiesce and seal evidence after all consumers finish."""
        try:
            self.quiesce()
        finally:
            if self._evidence_recorder is not None and self._raw_evidence_receipt is None:
                self._raw_evidence_receipt=self._evidence_recorder.close()

    def flow_keys_for_attribution(self)->dict[str,tuple[str,int,str,int]]:
        """In-memory only; do NOT serialize, expose to diagnostics or write ZIPs."""
        return self._flow_keys.copy()

    def safe_stats(self)->dict:
        stats=self.queue.stats()
        return {'accepted_segments':stats.accepted_total,'queued_segments':stats.queued_segments,
                'queue_drop_total':stats.dropped_total,'invalid_frames':stats.invalid_total,
                'rejected_frames':self._rejected_frames,
                'unsupported_frames':self._unsupported_frames,
                'driver_loss_visibility':'UNKNOWN','account_binding_verified':False,
                'physical_input_sent':False,
                'raw_evidence':self._raw_evidence_receipt}


def capture_bounded_sample(*,interface:str, server_ports:tuple[int,...],
                           duration_seconds:int=10, observer=None,
                           factory=None,require_windows:bool=True,
                           source=None, on_poll:Callable[[CapturePoll],None]|None=None)->dict:
    if type(duration_seconds) is not int or not 1<=duration_seconds<=60:
        raise ValueError('CAPTURE_DURATION_INVALID')
    live=source or WindowsLiveCapture(interface=interface,server_ports=server_ports,
                                        sniffer_factory=factory,require_windows=require_windows)
    audit=LiveCaptureAudit()
    try:
        live.start()
        deadline=monotonic_ns()+duration_seconds*1_000_000_000
        while monotonic_ns()<deadline:
            interval=min(.25,max(0,(deadline-monotonic_ns())/1e9))
            poll=live.poll(max_segments=256,timeout_seconds=interval)
            audit.observe(poll)
            if on_poll is not None:on_poll(poll)
        # The sniffer is stopped, but the recorder stays open until all
        # buffered observations and their consumers have been audited. If a
        # final poll fails, the P65 interruption seal can still be persisted.
        quiesce=getattr(live,'quiesce',None)
        if callable(quiesce):
            quiesce()
        else:
            live.stop()  # legacy/test source without split shutdown
        while True:
            poll=live.poll(max_segments=256,timeout_seconds=0)
            audit.observe(poll)
            if on_poll is not None:on_poll(poll)
            if poll.exhausted:break
    except BaseException:
        # A failed read or downstream consumer can cut the observation window
        # short. Seal any opt-in PCAPNG as incomplete before source cleanup.
        mark=getattr(live,'mark_capture_interrupted',None)
        if callable(mark):
            mark()
        raise
    finally:
        live.stop()
    receipt=audit.receipt()
    receipt['capture_source']='WINDOWS_NPCAP_EXPERIMENTAL'
    receipt['live_capture_equivalent']=False
    receipt['driver_loss_visibility']='UNKNOWN'
    receipt['host_acceptance']='PENDING'
    receipt.update(live.safe_stats())
    if observer is not None:
        observer.record('capture.live_sample_completed',boundary='capture.read_only_live',
                        payload=receipt)
    return receipt

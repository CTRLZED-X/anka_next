"""Windows TCP endpoint->PID snapshot (read only). No account ownership claims.

Uses documented GetExtendedTcpTable TCP_TABLE_OWNER_PID_CONNECTIONS for IPv4.
A single snapshot is a *hint*, never proof of a persistent window/account link.
"""
from __future__ import annotations
import os
import socket
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TcpEndpoint:
    local_ip: str
    local_port: int
    remote_ip: str
    remote_port: int
    pid: int
    state: int


class WindowsTcpOwnership:
    def snapshot(self)->tuple[TcpEndpoint,...]:
        if os.name!='nt':raise RuntimeError('TCP_OWNER_TABLE_WINDOWS_ONLY')
        import ctypes
        from ctypes import wintypes
        class Row(ctypes.Structure):
            _fields_=[('state',wintypes.DWORD),('local_addr',wintypes.DWORD),
                      ('local_port',wintypes.DWORD),('remote_addr',wintypes.DWORD),
                      ('remote_port',wintypes.DWORD),('pid',wintypes.DWORD)]
        lib=ctypes.WinDLL('iphlpapi',use_last_error=True)
        get=lib.GetExtendedTcpTable
        get.argtypes=[ctypes.c_void_p,ctypes.POINTER(wintypes.DWORD),wintypes.BOOL,
                      wintypes.ULONG,ctypes.c_int,wintypes.ULONG]
        get.restype=wintypes.DWORD
        size=wintypes.DWORD(0)
        # AF_INET = 2; TCP_TABLE_OWNER_PID_CONNECTIONS = 4
        first=get(None,ctypes.byref(size),False,2,4,0)
        if first not in (0,122):raise RuntimeError('TCP_OWNER_TABLE_QUERY_FAILED')
        if not 4<=size.value<=8*1024*1024:raise RuntimeError('TCP_OWNER_TABLE_SIZE_INVALID')
        buf=ctypes.create_string_buffer(size.value)
        ret=get(buf,ctypes.byref(size),False,2,4,0)
        if ret:raise RuntimeError('TCP_OWNER_TABLE_QUERY_FAILED')
        count=ctypes.c_uint32.from_buffer_copy(buf.raw[:4]).value
        if count>100000 or 4+count*ctypes.sizeof(Row)>size.value:
            raise RuntimeError('TCP_OWNER_TABLE_CORRUPT')
        result=[]
        for index in range(count):
            r=Row.from_buffer_copy(buf.raw,4+index*ctypes.sizeof(Row))
            port=lambda v:int.from_bytes(int(v).to_bytes(4,'little')[:2],'big')
            ip=lambda v:socket.inet_ntoa(int(v).to_bytes(4,'little'))
            result.append(TcpEndpoint(ip(r.local_addr),port(r.local_port),ip(r.remote_addr),port(r.remote_port),int(r.pid),int(r.state)))
        return tuple(result)


def correlate_flows(flows:dict[str,tuple[str,int,str,int]],
                    endpoints:tuple[TcpEndpoint,...],window_pids:dict[int,str])->dict:
    """Metadata-only, conservative attribution for read-only diagnostics.

    window_pids: PID -> stable process generation identifier from independent
    Windows window inventory. Even unique matches are PROVISIONAL because TCP
    table and window snapshots aren't atomic; live class verification is absent.
    """
    counts={'PROVISIONAL':0,'AMBIGUOUS':0,'UNMATCHED':0}
    candidates={}
    for token,key in flows.items():
        matches=[row for row in endpoints if (row.local_ip,row.local_port,row.remote_ip,row.remote_port)==key
                 and row.pid in window_pids and row.state==5]
        matched={(row.pid,window_pids[row.pid]) for row in matches}
        status='PROVISIONAL' if len(matched)==1 else 'AMBIGUOUS' if len(matched)>1 else 'UNMATCHED'
        counts[status]+=1
        candidates[token]={'status':status,'candidate_count':len(matched)}
    return {'status':'NOT_ATTESTED','counts':counts,'candidates':candidates,'account_binding_verified':False}

# anka_execution — P18/P19 offline boundary

This package **cannot** operate the game. No Windows input driver, physical
cursor integration, certified game observations, or executable planner contract
is present. It provides a small, independently testable transactional model:

- `prepare` stores a unique synthetic action intent and fingerprint.
- `mark_dispatch_boundary` commits an **uncertain** send boundary, never an input.
- Only a causally scoped synthetic outcome fixture can settle to CONFIRMED or REJECTED.
- `INCONCLUSIVE` remains uncertain and automatic retry is forbidden.
- `cancel_before_dispatch` works **only before** dispatch uncertainty.
- A single global uncertain dispatch gate prevents concurrent action dispatch.
- `audit_all` checks append-only event hash chain, projection parity and evidence table.

The returned reports are always `synthetic_only=True`, `actionable=False`,
`physical_input_permitted=False`. Live adapters will require separate,
current-build certified contracts and acceptance tests in future milestones.

P19 extends this package only with a **fake** driver, fixture window-feed,
preflight/re-attestation checks, and crash-safe orchestration. These modules
make zero system input calls, require exact fake driver objects, and cannot
enable live execution. See `docs/P19_OFFLINE_FAKE_DRIVER_EXECUTION_INTEGRATION.md`.

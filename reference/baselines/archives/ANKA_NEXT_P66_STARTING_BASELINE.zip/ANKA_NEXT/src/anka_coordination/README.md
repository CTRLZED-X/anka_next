# anka_coordination

P9 pending: turn ownership, Ready/join barriers.

Not implemented in P0/P1. No live behavior is claimed.

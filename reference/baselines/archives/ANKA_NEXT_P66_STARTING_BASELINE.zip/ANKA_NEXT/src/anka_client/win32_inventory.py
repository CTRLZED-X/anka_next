"""Read-only Windows top-level window discovery; NO keyboard/mouse/control.

Uses stdlib Win32 ctypes with explicit pointer signatures for x64 correctness.
Do not invoke on non-Windows systems. Per-window errors are explicit and result
in a fail-closed inventory, never silent skipping of a configured client.
"""
from __future__ import annotations
import os
import ntpath
from time import monotonic_ns
import re
from anka_contracts.client import WindowObservation, WindowScan


class NativeWindowsInventory:
    def __init__(self, character_names: tuple[str,...] = ()):
        if os.name != 'nt':
            raise RuntimeError('WINDOW_DISCOVERY_REQUIRES_WINDOWS')
        self.character_names=tuple(character_names)
        import ctypes
        from ctypes import wintypes as wt
        self.c=ctypes;self.wt=wt
        self.user=ctypes.WinDLL('user32',use_last_error=True)
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.user.EnumWindows.argtypes=[ctypes.WINFUNCTYPE(wt.BOOL,wt.HWND,wt.LPARAM),wt.LPARAM]
        self.user.EnumWindows.restype=wt.BOOL
        self.user.IsWindowVisible.argtypes=[wt.HWND];self.user.IsWindowVisible.restype=wt.BOOL
        self.user.GetWindowTextLengthW.argtypes=[wt.HWND];self.user.GetWindowTextLengthW.restype=ctypes.c_int
        self.user.GetWindowTextW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int];self.user.GetWindowTextW.restype=ctypes.c_int
        self.user.IsIconic.argtypes=[wt.HWND];self.user.IsIconic.restype=wt.BOOL
        self.user.GetWindowThreadProcessId.argtypes=[wt.HWND,ctypes.POINTER(wt.DWORD)];self.user.GetWindowThreadProcessId.restype=wt.DWORD
        self.user.GetClientRect.argtypes=[wt.HWND,ctypes.POINTER(wt.RECT)];self.user.GetClientRect.restype=wt.BOOL
        self.kernel.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];self.kernel.OpenProcess.restype=wt.HANDLE
        self.kernel.CloseHandle.argtypes=[wt.HANDLE];self.kernel.CloseHandle.restype=wt.BOOL
        self.kernel.GetProcessTimes.argtypes=[wt.HANDLE,ctypes.POINTER(wt.FILETIME),ctypes.POINTER(wt.FILETIME),ctypes.POINTER(wt.FILETIME),ctypes.POINTER(wt.FILETIME)]
        self.kernel.GetProcessTimes.restype=wt.BOOL
        self.kernel.QueryFullProcessImageNameW.argtypes=[wt.HANDLE,wt.DWORD,wt.LPWSTR,ctypes.POINTER(wt.DWORD)]
        self.kernel.QueryFullProcessImageNameW.restype=wt.BOOL
        self.get_dpi=getattr(self.user,'GetDpiForWindow',None)
        if self.get_dpi is not None:
            self.get_dpi.argtypes=[wt.HWND];self.get_dpi.restype=wt.UINT

    def _inspect(self,hwnd:int,title:str)->WindowObservation:
        c=self.c;wt=self.wt
        pid=wt.DWORD(0)
        if not self.user.GetWindowThreadProcessId(hwnd,c.byref(pid)) or not pid.value:
            raise OSError('PROCESS_ID_UNAVAILABLE')
        h=self.kernel.OpenProcess(0x1000,False,pid.value)
        if not h:raise OSError('PROCESS_OPEN_FAILED')
        try:
            buf=c.create_unicode_buffer(4096); length=wt.DWORD(len(buf))
            if not self.kernel.QueryFullProcessImageNameW(h,0,buf,c.byref(length)):
                raise OSError('PROCESS_IMAGE_UNAVAILABLE')
            ft=[wt.FILETIME() for _ in range(4)]
            if not self.kernel.GetProcessTimes(h,*(c.byref(x) for x in ft)):
                raise OSError('PROCESS_GENERATION_UNAVAILABLE')
            created=(int(ft[0].dwHighDateTime)<<32)|int(ft[0].dwLowDateTime)
        finally:
            self.kernel.CloseHandle(h)
        rect=wt.RECT()
        if not self.user.GetClientRect(hwnd,c.byref(rect)):
            raise OSError('CLIENT_RECT_UNAVAILABLE')
        dpi=int(self.get_dpi(hwnd)) if self.get_dpi else None
        return WindowObservation(int(hwnd),int(pid.value),created,ntpath.basename(buf.value),title,
                                 int(rect.right-rect.left),int(rect.bottom-rect.top),dpi if dpi and dpi>0 else None,
                                 bool(self.user.IsIconic(hwnd)))

    def scan(self)->WindowScan:
        c=self.c;wt=self.wt
        results=[];errors=[]
        cb_type=c.WINFUNCTYPE(wt.BOOL,wt.HWND,wt.LPARAM)
        @cb_type
        def visit(hwnd,_):
            try:
                if not self.user.IsWindowVisible(hwnd):return True
                n=self.user.GetWindowTextLengthW(hwnd)
                if n<=0 or n>2048:return True
                buf=c.create_unicode_buffer(n+1)
                self.user.GetWindowTextW(hwnd,buf,n+1)
                title=buf.value.strip()
                # Only plausible Dofus titles are inspected. Character-only titles
                # without Dofus are currently unverified and cannot be discovered.
                if not title or not ('dofus' in title.casefold() or any(
                    re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',title,re.IGNORECASE) for name in self.character_names)):
                    return True
                results.append(self._inspect(int(hwnd),title))
            except Exception as exc:
                errors.append('WINDOW_INSPECTION_FAILED:'+type(exc).__name__)
            return True
        ok=self.user.EnumWindows(visit,0)
        if not ok:errors.append('ENUM_WINDOWS_FAILED')
        return WindowScan(monotonic_ns(),tuple(sorted(results,key=lambda w:(w.pid,w.hwnd))),tuple(errors))

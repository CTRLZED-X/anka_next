"""Defense-in-depth sanitization before disk and before export.

This is not proof of perfect secrecy: only allowlisted diagnostic attributes should
be emitted. Never pass raw packets, tokens or arbitrary environment dumps to it.
"""
from __future__ import annotations
import re
import math
from typing import Any

SENSITIVE_KEYS={'password','passwd','secret','token','credential','authorization','cookie','session_key','api_key','raw_packet','pcap','private_key'}
_REDACTIONS=(
    (re.compile(r'(?i)(?:[a-z]:\\|/)(?:users|home)\\?/?[^\\/\s\"\']+'), '[LOCAL_USER_PATH]'),
    (re.compile(r'(?i)\b(?:bearer\s+)[a-z0-9._~+/-]+'), '[AUTH_TOKEN]'),
    (re.compile(r'(?i)\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}\b'), '[EMAIL]'),
    (re.compile(r'(?i)\b(?:password|token|api[_-]?key|authorization|secret)\s*[=:]\s*[^\s,;]+'), '[REDACTED_CREDENTIAL]'),
)


def sanitize(obj:Any, depth:int=0)->Any:
    if depth>5:return '[NESTING_LIMIT]'
    if isinstance(obj,dict):
        return {str(k)[:64]:('[REDACTED]' if str(k).casefold() in SENSITIVE_KEYS else sanitize(v,depth+1)) for k,v in list(obj.items())[:50]}
    if isinstance(obj,(list,tuple)):
        return [sanitize(x,depth+1) for x in list(obj)[:40]]
    if isinstance(obj,str):
        value=obj[:1024]
        for pattern,replacement in _REDACTIONS:value=pattern.sub(replacement,value)
        return value
    if type(obj) is float and not math.isfinite(obj):return '[NONFINITE_FLOAT]'
    if obj is None or type(obj) in (int,float,bool):return obj
    return '[UNSERIALIZABLE]'

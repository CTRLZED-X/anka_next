"""Passive local observer. No game kernel, network or execution imports."""
from __future__ import annotations
from collections import deque
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
from threading import RLock
from time import monotonic_ns
from uuid import uuid4
import json

from anka_contracts.diagnostics import DiagnosticEvent, now_utc
from anka_observability.redaction import sanitize

class NullDiagnostics:
    def emit(self,event:DiagnosticEvent)->str:
        return 'UNAVAILABLE'

class LocalDiagnostics:
    """Best-effort bounded recorder; NEVER an authoritative gameplay ledger."""
    def __init__(self,root:Path,*,run_id:str|None=None,invocation_id:str|None=None,max_recent:int=1000,max_journal_bytes:int=2097152):
        self.root=Path(root)
        self.invocation_id=invocation_id or 'inv-'+uuid4().hex
        self.run_id=run_id or 'run-'+uuid4().hex
        self.folder=self.root/'runs'/self.run_id
        self.max_journal_bytes=max_journal_bytes
        self.recent=deque(maxlen=max_recent)
        self._seq=0
        self.dropped=0
        self.errors=[]
        self._lock=RLock()
        self.available=True
        try:
            self.folder.mkdir(parents=True,exist_ok=False)
            (self.folder/'run_state.json').write_text(json.dumps({'run_id':self.run_id,'state':'RUNNING','started_utc':now_utc()},indent=2)+'\n',encoding='utf8')
        except OSError as exc:
            self.available=False
            self.errors.append(type(exc).__name__)

    def record(self,name:str,severity:str='INFO',*,boundary:str|None=None,failure_code:str|None=None,payload:dict|None=None,**ids)->str:
        """Application convenience facade; all events still use versioned DTOs."""
        with self._lock:
            self._seq+=1;seq=self._seq
            try:
                event=DiagnosticEvent(1,'evt-'+uuid4().hex,name,severity,now_utc(),monotonic_ns(),seq,self.invocation_id,self.run_id,
                     failure_code=failure_code,boundary=boundary,payload=sanitize(payload or {}),**ids)
            except (TypeError,ValueError):
                self.dropped+=1
                return 'DROPPED'
            return self.emit(event)

    def emit(self,event:DiagnosticEvent)->str:
        """Bounded, sanitized, observational. Failures NEVER change application authority."""
        if not self.available:return 'UNAVAILABLE'
        with self._lock:
            try:
                obj=sanitize(event.to_dict())
                encoded=json.dumps(obj,sort_keys=True,ensure_ascii=True,separators=(',',':'))+'\n'
                if len(encoded)>8192:
                    self.dropped+=1;return 'DROPPED'
                self.recent.append(obj)
                path=self.folder/'events.jsonl'
                if (path.stat().st_size if path.exists() else 0)+len(encoded.encode())>self.max_journal_bytes:
                    self.dropped+=1
                    # Keep ring evidence available; no unbounded disk usage.
                    return 'DROPPED'
                with path.open('a',encoding='utf8') as out:out.write(encoded)
                return 'RECORDED'
            except (OSError,ValueError,TypeError) as exc:
                self.dropped+=1
                self.errors.append(type(exc).__name__)
                return 'UNAVAILABLE'

    def finish(self,state:str='CLOSED') -> None:
        if state not in ('CLOSED','BLOCKED','FAILED'):raise ValueError('INVALID_FINAL_STATE')
        try:
            if self.available:
                (self.folder/'run_state.json').write_text(json.dumps({'run_id':self.run_id,'state':state,'finished_utc':now_utc(),'dropped_events':self.dropped},indent=2)+'\n',encoding='utf8')
        except OSError:self.errors.append('RUN_STATE_WRITE_FAILED')

    def export_incident(self,code:str,*,boundary:str,detail:str='') -> Path:
        from anka_observability.bundle import export_incident
        return export_incident(self,code,boundary=boundary,detail=detail)

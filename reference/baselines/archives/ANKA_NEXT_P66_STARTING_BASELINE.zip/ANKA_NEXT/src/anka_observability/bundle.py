"""Deterministic-per-input, bounded, locally generated GPT-friendly evidence bundle."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
from uuid import uuid4
from zipfile import ZipFile, ZIP_DEFLATED
import json
import re
from anka_contracts.diagnostics import now_utc
from anka_observability.redaction import sanitize

BUNDLE_SCHEMA=1
EVIDENCE_STATUS=('PRESENT','PARTIAL','MISSING','NOT_APPLICABLE')
CRITICAL_SECTIONS=('bootstrap','configuration','identity','capture','protocol','canonical','live_state','coordination','decision','execution','outcome')


def _serialized(data:object)->bytes:
    return (json.dumps(sanitize(data),sort_keys=True,ensure_ascii=True,indent=2)+'\n').encode('utf8')


def _diagnosis(code:str,boundary:str,detail:str, observer)->dict:
    # These are hypotheses, not source-proven root causes.
    return {'schema_version':1,'failure_code':sanitize(code),'first_observed_boundary':sanitize(boundary),
        'finding_status':'HYPOTHESIS_NOT_VERIFIED','confidence':'UNDETERMINED',
        'explanation':sanitize(detail), 'candidate_causes':[],
        'evidence_ids':[e['event_id'] for e in observer.recent if e.get('severity') in ('ERROR','CRITICAL','SAFETY')][-20:],
        'observer_dropped_events':observer.dropped,'observer_errors':observer.errors[-10:],
        'missing_information':'This bounded bundle cannot by itself certify live game state, root causes, or server outcomes.'}


def export_incident(observer,code:str,*,boundary:str,detail:str='')->Path:
    if not re.fullmatch(r'[A-Z][A-Z0-9_]{2,80}',code):raise ValueError('INVALID_INCIDENT_CODE')
    id_='incident-'+uuid4().hex
    folder=observer.folder/'incidents';folder.mkdir(parents=True,exist_ok=True)
    path=folder/(id_+'.zip')
    evidence={key:'MISSING' for key in CRITICAL_SECTIONS}
    if 'setup' in boundary or 'startup' in boundary:evidence['bootstrap']='PARTIAL'
    if 'config' in boundary:evidence['configuration']='PARTIAL'
    if 'client' in boundary or 'identity' in boundary:
        evidence['identity']='PARTIAL'
    if any(str(event.get('event_name','')).startswith('client.') for event in observer.recent):
        evidence['identity']='PARTIAL'
    diagnostic=_diagnosis(code,boundary,detail,observer)
    bounded_events=list(observer.recent)[-250:]
    timeline=b''.join(_serialized(e).rstrip(b'\n')+b'\n' for e in bounded_events)
    if len(timeline)>128*1024:
        timeline=timeline[-128*1024:]
        # cut incomplete leading line after byte clipping
        timeline=timeline[timeline.index(b'\n')+1:] if b'\n' in timeline else b''
        evidence['bootstrap']='PARTIAL' if evidence['bootstrap']=='PARTIAL' else evidence['bootstrap']
    artifacts={
        'diagnosis.json':_serialized(diagnostic),
        'evidence_matrix.json':_serialized({'schema_version':1,'sections':evidence,'note':'MISSING means no verified evidence was collected for that section during this invocation; never invent it.'}),
        'timeline.jsonl':timeline,
        'GPT_READ_FIRST.md':(f'# ANKA diagnostic incident\n\n**Code:** {code}\n\n**First observed boundary:** {sanitize(boundary)}\n\n'
                 f'**Diagnostic status:** UNDETERMINED (hypothesis, not verified root cause).\n\n'
                 f'{sanitize(detail)}\n\n'
                 'The evidence matrix declares absent sections. This bundle cannot by itself certify physical input or Dofus server outcomes.\n').encode('utf8')
    }
    manifest={'schema_version':BUNDLE_SCHEMA,'incident_id':id_,'run_id':observer.run_id,
              'created_utc':now_utc(),'source':'P1_OFFLINE_FOUNDATION','files':{},
              'raw_protocol_included':False,'external_upload':False,
              'completeness':'PARTIAL', 'dropped_events':observer.dropped}
    for name,content in artifacts.items():
        manifest['files'][name]={'sha256':sha256(content).hexdigest(),'bytes':len(content)}
    with ZipFile(path,'w',compression=ZIP_DEFLATED) as z:
        for name,data in artifacts.items():z.writestr(name,data)
        z.writestr('manifest.json',_serialized(manifest))
    return path


def verify_incident(path:Path)->dict:
    """Read-only ZIP integrity check; reject traversal, undeclared files and mismatched hashes."""
    errors=[]
    with ZipFile(path) as z:
        names=z.namelist()
        if len(set(names))!=len(names):errors.append('DUPLICATE_ZIP_ENTRIES')
        if len(names)>50:errors.append('TOO_MANY_ENTRIES')
        for name in names:
            if name.startswith('/') or '\\' in name or '..' in name.split('/'):
                errors.append('UNSAFE_ZIP_PATH:'+name)
        if 'manifest.json' not in names:raise ValueError('MISSING_MANIFEST')
        if z.getinfo('manifest.json').file_size>65536:raise ValueError('OVERSIZED_MANIFEST')
        if sum(i.file_size for i in z.infolist())>3*1024*1024:
            raise ValueError('OVERSIZED_BUNDLE_UNCOMPRESSED')
        m=json.loads(z.read('manifest.json'))
        if m.get('schema_version')!=1:errors.append('SCHEMA_MISMATCH')
        declared=m.get('files',{})
        if set(names)-{'manifest.json'}!=set(declared):errors.append('MANIFEST_FILE_SET_MISMATCH')
        for name,receipt in declared.items():
            if name not in names:continue
            if z.getinfo(name).file_size>1024*1024:
                errors.append('OVERSIZED_FILE:'+name)
                continue
            data=z.read(name)
            if len(data)>1024*1024:errors.append('OVERSIZED_FILE:'+name)
            if receipt.get('sha256')!=sha256(data).hexdigest() or receipt.get('bytes')!=len(data):
                errors.append('BAD_CHECKSUM:'+name)
        if len(z.read('manifest.json'))>65536:errors.append('OVERSIZED_MANIFEST')
        if 'evidence_matrix.json' in names:
            matrix=json.loads(z.read('evidence_matrix.json'))
            if set(matrix.get('sections',{}))!=set(CRITICAL_SECTIONS):errors.append('INCOMPLETE_EVIDENCE_MATRIX')
            if any(x not in EVIDENCE_STATUS for x in matrix['sections'].values()):errors.append('BAD_EVIDENCE_STATUS')
    return {'status':'PASS' if not errors else 'FAIL','errors':errors}

"""P3 public read-only client inventory contracts.

A title is a search hint, NEVER an attestation. The observed process generation
must match independent canonical/bridge identity evidence to bind an account.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class WindowObservation:
    hwnd: int
    pid: int
    process_created_100ns: int  # Windows FILETIME, not Unix seconds
    executable_name: str
    title: str
    client_width: int
    client_height: int
    dpi: int | None
    minimized: bool


@dataclass(frozen=True, slots=True)
class WindowScan:
    observed_monotonic_ns: int
    windows: tuple[WindowObservation, ...]
    errors: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CharacterEvidence:
    # Supplied by a separately validated protocol/bridge source, not a title.
    source: str                    # LIVE_PROTOCOL or UNITY_BRIDGE
    character_name: str
    breed: str                     # CRA or ENUTROF currently supported
    hwnd: int
    pid: int
    process_created_100ns: int
    observed_monotonic_ns: int


@dataclass(frozen=True, slots=True)
class AccountBinding:
    name: str
    state: str
    reason: str
    generation_id: str | None = None
    hwnd: int | None = None
    pid: int | None = None
    breed: str | None = None
    evidence_source: str | None = None
    # The new project has neither current-build cert nor live slot binding.
    input_certified: bool = False


class WindowInventory(Protocol):
    def scan(self) -> WindowScan: ...


class CharacterEvidenceProvider(Protocol):
    def snapshot(self) -> tuple[CharacterEvidence, ...]: ...

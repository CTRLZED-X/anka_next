"""P8 synthetic state-event contract; no production/live admission authority.

Real protocol observations must undergo independent current-build certification in a
future milestone. This class is deliberately NOT an adapter for CanonicalDraft.
"""
from __future__ import annotations
from dataclasses import dataclass,field
from typing import Literal

StateKind=Literal['FIGHT_STARTED','ACTOR_SEEN','ACTOR_RESOURCE_SET','ACTOR_HP_SET',
                  'ACTOR_POSITION_SET','ACTOR_COOLDOWNS_SET','TURN_STARTED','TURN_ENDED','FIGHT_ENDED']
KINDS=frozenset({'FIGHT_STARTED','ACTOR_SEEN','ACTOR_RESOURCE_SET','ACTOR_HP_SET',
 'ACTOR_POSITION_SET','ACTOR_COOLDOWNS_SET','TURN_STARTED','TURN_ENDED','FIGHT_ENDED'})

@dataclass(frozen=True,slots=True)
class OfflineStateEvent:
    """Typed synthetic event for exercising the journal/reducer, NEVER live input."""
    event_id:str
    session_id:str
    account_id:str
    account_generation:int
    fight_id:str
    sequence:int
    kind:StateKind
    actor_id:int|None=None
    resource:str|None=None
    value:int|None=None
    maximum:int|None=None
    cooldowns:tuple[tuple[int,int],...]=()
    origin: str=field(default='SYNTHETIC_FIXTURE_ONLY',init=False)

    def __post_init__(self):
        def token(value,max_len=100):
            return isinstance(value,str) and 0<len(value)<=max_len and all(c.isascii() and (c.isalnum() or c in '_-.') for c in value)
        if not all(token(x) for x in (self.event_id,self.session_id,self.account_id,self.fight_id)):
            raise ValueError('STATE_EVENT_IDENTITY_INVALID')
        if type(self.account_generation) is not int or self.account_generation<0 or type(self.sequence) is not int or self.sequence<=0:
            raise ValueError('STATE_EVENT_ORDER_INVALID')
        if self.kind not in KINDS:raise ValueError('STATE_EVENT_KIND_INVALID')
        needs_actor=self.kind in {'ACTOR_SEEN','ACTOR_RESOURCE_SET','ACTOR_HP_SET','ACTOR_POSITION_SET','ACTOR_COOLDOWNS_SET','TURN_STARTED','TURN_ENDED'}
        if needs_actor!=(self.actor_id is not None):raise ValueError('STATE_EVENT_ACTOR_INVALID')
        if self.actor_id is not None and (type(self.actor_id) is not int or self.actor_id==0 or abs(self.actor_id)>=2**63):
            raise ValueError('STATE_EVENT_ACTOR_INVALID')
        if self.kind=='ACTOR_RESOURCE_SET':
            if self.resource not in ('AP','MP','RANGE') or type(self.value) is not int or not 0<=self.value<=200:
                raise ValueError('STATE_EVENT_RESOURCE_INVALID')
        elif self.kind=='ACTOR_HP_SET':
            if type(self.value) is not int or type(self.maximum) is not int or not 0<=self.value<=self.maximum<=1_000_000_000:
                raise ValueError('STATE_EVENT_HP_INVALID')
        elif self.kind=='ACTOR_POSITION_SET':
            if type(self.value) is not int or not 0<=self.value<=100000:
                raise ValueError('STATE_EVENT_CELL_INVALID')
        elif self.kind=='ACTOR_COOLDOWNS_SET':
            if len(self.cooldowns)>200 or len(set(s for s,_ in self.cooldowns))!=len(self.cooldowns) or any(type(s) is not int or s<=0 or type(n) is not int or not 0<=n<=1000 for s,n in self.cooldowns):
                raise ValueError('STATE_EVENT_COOLDOWNS_INVALID')
        if self.kind not in ('ACTOR_RESOURCE_SET','ACTOR_HP_SET','ACTOR_POSITION_SET') and self.value is not None:
            raise ValueError('STATE_EVENT_EXTRANEOUS_VALUE')
        if self.kind!='ACTOR_RESOURCE_SET' and self.resource is not None:raise ValueError('STATE_EVENT_EXTRANEOUS_RESOURCE')
        if self.kind!='ACTOR_HP_SET' and self.maximum is not None:raise ValueError('STATE_EVENT_EXTRANEOUS_MAXIMUM')
        if self.kind!='ACTOR_COOLDOWNS_SET' and self.cooldowns:raise ValueError('STATE_EVENT_EXTRANEOUS_COOLDOWNS')


@dataclass(frozen=True,slots=True)
class OfflineBatchEnvelope:
    """P56 synthetic-only source receipt for one logical state-event batch.

    ``source_digest`` identifies the exact upstream synthetic observation batch.
    The journal binds it atomically to the event payloads and projection update.
    This is deliberately not a current-client or live admission credential.
    """
    batch_id:str
    source_digest:str
    events:tuple[OfflineStateEvent,...]
    origin:str=field(default='SYNTHETIC_FIXTURE_ONLY',init=False)

    def __post_init__(self):
        token=lambda value: isinstance(value,str) and 0<len(value)<=120 and all(c.isascii() and (c.isalnum() or c in '_-.') for c in value)
        if not token(self.batch_id):raise ValueError('STATE_BATCH_ID_INVALID')
        if not isinstance(self.source_digest,str) or len(self.source_digest)!=64 or any(c not in '0123456789abcdef' for c in self.source_digest):
            raise ValueError('STATE_BATCH_SOURCE_DIGEST_INVALID')
        if not isinstance(self.events,tuple) or not 1<=len(self.events)<=2048 or any(not isinstance(e,OfflineStateEvent) for e in self.events):
            raise ValueError('STATE_BATCH_EVENTS_INVALID')

"""Transport-only P4 contracts. No protocol message semantics or account assertions.

Raw payloads exist only transiently in memory for a future decoder; they are not
serializable by the public capture-receipt API or emitted to diagnostics.
"""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class CapturedTcpSegment:
    flow_id: str = field(repr=False)
    direction: str
    seq: int
    payload: bytes = field(repr=False)
    packet_number: int
    tcp_flags: int = 0

    def __post_init__(self) -> None:
        if self.direction not in ('server_to_client', 'client_to_server'):
            raise ValueError('INVALID_CAPTURE_DIRECTION')
        if type(self.seq) is not int or not 0 <= self.seq < 2**32:
            raise ValueError('INVALID_TCP_SEQUENCE')
        if type(self.packet_number) is not int or self.packet_number < 1:
            raise ValueError('INVALID_PACKET_NUMBER')
        if not isinstance(self.payload, bytes):
            raise ValueError('INVALID_PAYLOAD_TYPE')
        if not isinstance(self.flow_id, str) or not self.flow_id:
            raise ValueError('INVALID_FLOW_ID')
        if type(self.tcp_flags) is not int or not 0 <= self.tcp_flags <= 255:
            raise ValueError('INVALID_TCP_FLAGS')

    @property
    def syn(self) -> bool:
        return bool(self.tcp_flags & 0x02)

    @property
    def rst(self) -> bool:
        return bool(self.tcp_flags & 0x04)

    @property
    def fin(self) -> bool:
        return bool(self.tcp_flags & 0x01)


@dataclass(frozen=True, slots=True)
class CapturePoll:
    """Future live-source boundary: bounded batches with explicit loss evidence.

    The actual Windows/Npcap backend is deliberately NOT implemented in P4.
    When dropped > 0 or overflowed is true, consumers must never infer
    transport completeness from observed packets alone.
    """
    source_generation: str
    segments: tuple[CapturedTcpSegment,...] = field(repr=False)
    dropped: int
    overflowed: bool
    exhausted: bool
    driver_drop_visibility: str = "UNKNOWN"

    def __post_init__(self) -> None:
        if not self.source_generation:
            raise ValueError('SOURCE_GENERATION_REQUIRED')
        if not isinstance(self.segments, tuple) or len(self.segments)>4096:
            raise ValueError('POLL_BATCH_TOO_LARGE')
        if type(self.dropped) is not int or self.dropped < 0:
            raise ValueError('POLL_DROPPED_COUNT_INVALID')
        if type(self.overflowed) is not bool or type(self.exhausted) is not bool:
            raise ValueError('POLL_BOOLEAN_INVALID')
        if self.driver_drop_visibility not in ("UNKNOWN", "AVAILABLE_CLEAN", "AVAILABLE_DROPPED"):
            raise ValueError("INVALID_DRIVER_DROP_VISIBILITY")

    @property
    def transport_evidence_complete(self) -> bool:
        # This is a *necessary* condition, never sufficient to certify a stream.
        return self.dropped == 0 and not self.overflowed

    @property
    def live_loss_accounting_complete(self) -> bool:
        """Stronger live guarantee: driver loss accounting must also be known."""
        return self.transport_evidence_complete and self.driver_drop_visibility == "AVAILABLE_CLEAN"

"""Stable Canonical v1 draft contracts. Historical candidates have NO mutation authority.

A draft represents evidence with explicit provenance, not an authoritative fact.  Its
immutable shape deliberately does not depend on any protocol version or parser.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal

FactKind = Literal['ACTOR_RESOURCE_ABSOLUTE','ACTOR_HP_ABSOLUTE','ACTOR_COOLDOWN_SNAPSHOT']
_ALLOWED_KINDS = frozenset({'ACTOR_RESOURCE_ABSOLUTE','ACTOR_HP_ABSOLUTE','ACTOR_COOLDOWN_SNAPSHOT'})
_ALLOWED_RESOURCES = frozenset({'AP','MP','RANGE'})
_MAX_RESOURCE = {'AP':200,'MP':200,'RANGE':200}

@dataclass(frozen=True,slots=True)
class EvidenceRef:
    protocol_build: str
    adapter_id: str
    wire_name: str
    packet_number: int
    transport_generation: int
    flow_digest: str
    schema_revision: int = 1
    message_index: int = 0

    def __post_init__(self):
        if not self.protocol_build or len(self.protocol_build)>80:raise ValueError('CANONICAL_BUILD_INVALID')
        if not self.adapter_id or len(self.adapter_id)>96:raise ValueError('CANONICAL_ADAPTER_INVALID')
        if not self.wire_name.isascii() or not self.wire_name.replace("_", "").isalnum() or not 1<=len(self.wire_name)<=96:raise ValueError('CANONICAL_WIRE_INVALID')
        if type(self.packet_number) is not int or self.packet_number<0:raise ValueError('CANONICAL_PACKET_INVALID')
        if type(self.transport_generation) is not int or self.transport_generation<0:raise ValueError('CANONICAL_GENERATION_INVALID')
        if len(self.flow_digest)!=64 or any(c not in '0123456789abcdef' for c in self.flow_digest):raise ValueError('CANONICAL_FLOW_DIGEST_INVALID')
        if type(self.message_index) is not int or self.message_index<0:raise ValueError('CANONICAL_MESSAGE_INDEX_INVALID')
        if self.schema_revision!=1:raise ValueError('CANONICAL_SCHEMA_UNSUPPORTED')

@dataclass(frozen=True,slots=True)
class CanonicalDraft:
    """Immutable evidence draft. Every field is explicit, including missing context.

    No game state code is allowed to treat this as an admitted canonical event.
    """
    kind: FactKind
    actor_id: int
    evidence: EvidenceRef
    resource: str|None = None
    value: int|None = None
    maximum: int|None = None
    cooldowns: tuple[tuple[int,int], ...] = ()
    authority: str = field(default='HISTORICAL_CANDIDATE_ONLY',init=False)

    def __post_init__(self):
        if self.kind not in _ALLOWED_KINDS:raise ValueError('CANONICAL_KIND_UNSUPPORTED')
        if type(self.actor_id) is not int or self.actor_id==0 or not -(2**63)<self.actor_id<2**63:raise ValueError('CANONICAL_ACTOR_INVALID')
        if self.kind=='ACTOR_RESOURCE_ABSOLUTE':
            if self.resource not in _ALLOWED_RESOURCES or type(self.value) is not int or not 0<=self.value<=_MAX_RESOURCE[self.resource] or self.maximum is not None or self.cooldowns:
                raise ValueError('CANONICAL_RESOURCE_INVALID')
        elif self.kind=='ACTOR_HP_ABSOLUTE':
            if self.resource is not None or type(self.value) is not int or type(self.maximum) is not int or not 0<=self.value<=self.maximum<=1_000_000_000 or self.cooldowns:
                raise ValueError('CANONICAL_HP_INVALID')
        elif self.kind=='ACTOR_COOLDOWN_SNAPSHOT':
            if self.resource is not None or self.value is not None or self.maximum is not None or len(self.cooldowns)>200:
                raise ValueError('CANONICAL_COOLDOWN_INVALID')
            ids=set()
            for spell,remaining in self.cooldowns:
                if type(spell) is not int or spell<=0 or type(remaining) is not int or not 0<=remaining<=1000 or spell in ids:
                    raise ValueError('CANONICAL_COOLDOWN_INVALID')
                ids.add(spell)

@dataclass(frozen=True,slots=True)
class CanonicalAdmission:
    """Quarantine decision; no flag in this type permits changing live state."""
    status: str
    accepted_for_research: tuple[CanonicalDraft,...]
    reasons: tuple[str,...]
    committed_events: int = 0
    live_state_revision: int|None = None

    def __post_init__(self):
        if self.status not in ('STAGED_UNCERTIFIED','QUARANTINED','EMPTY') or self.committed_events!=0 or self.live_state_revision is not None:
            raise ValueError('CANONICAL_ADMISSION_AUTHORITY_FORBIDDEN')

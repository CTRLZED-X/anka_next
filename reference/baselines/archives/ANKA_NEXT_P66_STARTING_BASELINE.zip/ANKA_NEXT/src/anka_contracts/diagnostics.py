"""Public, observer-only diagnostic contract. No imports of application systems."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any
import re

SEVERITIES = frozenset({'DEBUG','INFO','WARNING','ERROR','CRITICAL','SAFETY','SETTLEMENT'})
EVIDENCE_CLASSES = frozenset({'AUTHORITY_COMMITTED','OBSERVED_EXTERNAL','DERIVED','HEURISTIC','MISSING','STALE'})
EVENT_NAME = re.compile(r'^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$')


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')


@dataclass(frozen=True, slots=True)
class DiagnosticEvent:
    schema_version: int
    event_id: str
    event_name: str
    severity: str
    occurred_utc: str
    monotonic_ns: int
    producer_seq: int
    invocation_id: str
    run_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_event_id: str | None = None
    account_id: str | None = None
    client_generation: str | None = None
    fight_id: str | None = None
    turn_epoch: int | None = None
    action_id: str | None = None
    attempt_id: str | None = None
    canonical_revision: int | None = None
    protocol_build: str | None = None
    failure_code: str | None = None
    boundary: str | None = None
    evidence_class: str = 'DERIVED'
    payload: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.schema_version != 1: raise ValueError('UNSUPPORTED_DIAGNOSTIC_SCHEMA')
        if not EVENT_NAME.fullmatch(self.event_name): raise ValueError('INVALID_EVENT_NAME')
        if self.severity not in SEVERITIES: raise ValueError('INVALID_SEVERITY')
        if self.evidence_class not in EVIDENCE_CLASSES: raise ValueError('INVALID_EVIDENCE_CLASS')
        if not (self.event_id and self.invocation_id): raise ValueError('MISSING_IDENTITY')
        if self.producer_seq < 0 or self.monotonic_ns < 0: raise ValueError('INVALID_CLOCK')
        if not isinstance(self.payload, dict): raise ValueError('INVALID_EVENT_PAYLOAD')
        if self.turn_epoch is not None and self.turn_epoch < 0: raise ValueError('INVALID_EPOCH')

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str,Any]) -> 'DiagnosticEvent':
        return cls(**data)

"""P12 immutable, non-executable decision PROBE contracts.

A preview cannot be passed as a physical-input command. No credential,
window address, mouse coordinate, input primitive or execution authority exists.
"""
from __future__ import annotations
from dataclasses import dataclass


def token(s: str) -> bool:
    return type(s) is str and 1 <= len(s) <= 100 and s.isascii() and all(
        c.isalnum() or c in '_.-' for c in s)


@dataclass(frozen=True, slots=True)
class CastProbe:
    session_id: str
    account_id: str
    account_generation: int
    fight_id: str
    minimum_revision: int
    actor_id: int
    spell_id: int
    grade: int
    target_cell: int

    def __post_init__(self) -> None:
        if not all(map(token,(self.session_id,self.account_id,self.fight_id))):
            raise ValueError('DECISION_SCOPE_INVALID')
        valid = (
            type(self.account_generation) is int and self.account_generation >= 0
            and type(self.minimum_revision) is int and self.minimum_revision >= 1
            and type(self.actor_id) is int and self.actor_id != 0 and abs(self.actor_id) < 2**63
            and type(self.spell_id) is int and self.spell_id > 0
            and type(self.grade) is int and 1 <= self.grade <= 10
            and type(self.target_cell) is int and 0 <= self.target_cell <= 100000
        )
        if not valid:raise ValueError('DECISION_PROBE_INVALID')


@dataclass(frozen=True, slots=True)
class CastProbeReport:
    status: str
    scope: CastProbe
    reasons: tuple[str, ...]
    missing_kernel_inputs: tuple[str, ...]
    observed_revision: int | None
    static_spell_name: str | None
    static_ap_cost: int | None
    kernel_legality: str
    # Contract deliberately has no physical-action fields or executable plan.
    preview_only: bool = True
    actionable: bool = False
    authoritative: bool = False

    def to_dict(self) -> dict:
        return {
            'status':self.status,'probe':{
                'session_id':self.scope.session_id,'account_id':self.scope.account_id,
                'account_generation':self.scope.account_generation,
                'fight_id':self.scope.fight_id,'minimum_revision':self.scope.minimum_revision,
                'actor_id':self.scope.actor_id,'spell_id':self.scope.spell_id,
                'grade':self.scope.grade,'target_cell':self.scope.target_cell},
            'reasons':list(self.reasons),'missing_kernel_inputs':list(self.missing_kernel_inputs),
            'observed_revision':self.observed_revision,'static_spell_name':self.static_spell_name,
            'static_ap_cost':self.static_ap_cost,'kernel_legality':self.kernel_legality,
            'preview_only':True,'actionable':False,'authoritative':False,
            'physical_input_permitted':False,
        }

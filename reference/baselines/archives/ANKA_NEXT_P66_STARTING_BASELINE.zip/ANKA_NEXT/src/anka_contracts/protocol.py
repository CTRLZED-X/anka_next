"""Stable P6 wire-observation contracts: no game-state mutations or raw evidence in exports."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict


@dataclass(frozen=True, slots=True)
class WireMessage:
    direction: str
    name: str
    body: bytes = field(repr=False)
    packet_number: int = 0
    flow_key: str = field(default='', repr=False)
    generation: int = 0
    message_index: int = 0

    def __post_init__(self):
        if self.direction not in ('server_to_client', 'client_to_server'):
            raise ValueError('PROTOCOL_DIRECTION_INVALID')
        if not isinstance(self.name,str) or not 1<=len(self.name)<=96 or not self.name.isascii() or not self.name.replace('_','').isalnum():
            raise ValueError('PROTOCOL_MESSAGE_NAME_INVALID')
        if not isinstance(self.body,bytes) or len(self.body)>2_000_000:
            raise ValueError('PROTOCOL_BODY_INVALID')
        if type(self.packet_number) is not int or self.packet_number<0:
            raise ValueError('PROTOCOL_PACKET_INVALID')
        if type(self.generation) is not int or self.generation<0:
            raise ValueError('PROTOCOL_GENERATION_INVALID')
        if type(self.message_index) is not int or self.message_index<0:
            raise ValueError('PROTOCOL_MESSAGE_INDEX_INVALID')


@dataclass(frozen=True, slots=True)
class ProtocolFinding:
    category: str
    name: str
    direction: str
    packet_number: int
    capability: str = 'UNASSIGNED'
    reason: str = ''

    def __post_init__(self):
        if self.category not in ('CATALOG_OBSERVED_ONLY','UNKNOWN_WIRE','DIRECTION_MISMATCH','CONTRACT_VIOLATION'):
            raise ValueError('PROTOCOL_FINDING_INVALID')


@dataclass(frozen=True, slots=True)
class ProtocolReceipt:
    schema_version: int
    adapter_id: str
    requested_build: str
    adapter_build: str
    status: str
    selected_segments: int
    framed_messages: int
    classified_observations: int
    unknown_messages: int
    direction_mismatches: int
    invalid_frames: int
    quarantined_streams: int
    unanchored_streams: int
    packet_loss_reported: bool
    account_identity_certified: bool = False
    canonical_events_emitted: int = 0
    gameplay_capabilities_certified: bool = False
    physical_input_sent: bool = False
    findings: tuple[ProtocolFinding,...] = ()

    def to_dict(self) -> dict:
        obj=asdict(self)
        # No IP, payload, endpoint, raw source path or account name is ever available.
        return obj

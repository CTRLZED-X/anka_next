"""P21 automated architecture-boundary audit (no game or input imports).

The explicit allow-list is deliberately owned by the composition package.  It
is an architectural contract, not an import resolver; additions require review.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path

SYSTEM_IMPORTS: dict[str, frozenset[str]] = {
    'anka_contracts': frozenset(),
    'anka_game_kernel': frozenset(),
    'anka_client': frozenset({'anka_contracts'}),
    'anka_capture': frozenset({'anka_contracts'}),
    'anka_protocol': frozenset({'anka_contracts'}),
    'anka_canonical': frozenset({'anka_contracts'}),
    'anka_live_state': frozenset({'anka_contracts'}),
    'anka_decision': frozenset({'anka_contracts', 'anka_game_kernel'}),
    'anka_coordination': frozenset({'anka_contracts'}),
    'anka_workflow': frozenset({'anka_contracts'}),
    'anka_execution': frozenset({'anka_contracts'}),
    'anka_observability': frozenset({'anka_contracts'}),
    'anka_app': frozenset({
        'anka_contracts', 'anka_game_kernel', 'anka_client', 'anka_capture',
        'anka_protocol', 'anka_canonical', 'anka_live_state', 'anka_decision',
        'anka_coordination', 'anka_workflow', 'anka_execution', 'anka_observability',
    }),
}


@dataclass(frozen=True)
class ArchitectureAudit:
    packages: int
    modules: int
    violations: tuple[str, ...]

    @property
    def status(self) -> str:
        return 'PASS' if not self.violations else 'FAIL'

    def to_dict(self) -> dict:
        return {'status': self.status, 'packages': self.packages,
                'modules': self.modules, 'violations': list(self.violations)}


def audit_source_boundaries(src: Path) -> ArchitectureAudit:
    """Enforce code-level imports, including constant-string dynamic imports.

    Unknown packages and parser errors are failures. No import is executed and
    no external dependency is needed; safe during setup on Windows.
    """
    src = Path(src)
    failures: list[str] = []
    names = {p.name for p in src.iterdir() if p.is_dir() and p.name.startswith('anka_')} if src.is_dir() else set()
    for name in sorted(set(SYSTEM_IMPORTS) - names):
        failures.append(f'ARCH_PACKAGE_MISSING:{name}')
    for name in sorted(names - set(SYSTEM_IMPORTS)):
        failures.append(f'ARCH_UNREVIEWED_PACKAGE:{name}')
    inspected = 0
    for package in sorted(names):
        for path in sorted((src/package).rglob('*.py')):
            inspected += 1
            relative = path.relative_to(src).as_posix()
            try:
                root = ast.parse(path.read_text(encoding='utf-8'), filename=relative)
            except (SyntaxError, UnicodeError, OSError) as error:
                failures.append(f'ARCH_SOURCE_UNREADABLE:{relative}:{type(error).__name__}')
                continue
            for node in ast.walk(root):
                targets: list[str] = []
                if isinstance(node, ast.Import):
                    targets = [item.name.split('.')[0] for item in node.names]
                elif isinstance(node, ast.ImportFrom):
                    if node.level:
                        # A relative import may not escape its owning system.
                        parts = path.relative_to(src).parts[:-1]
                        if node.level > len(parts):
                            failures.append(f'ARCH_RELATIVE_ESCAPE:{relative}:{node.lineno}')
                        continue
                    targets = [(node.module or '').split('.')[0]]
                elif isinstance(node, ast.Call) and node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    function = node.func
                    if (isinstance(function, ast.Name) and function.id == '__import__') or (
                        isinstance(function, ast.Attribute) and function.attr == 'import_module'
                        and isinstance(function.value, ast.Name) and function.value.id == 'importlib'
                    ):
                        targets = [node.args[0].value.split('.')[0]]
                for target in targets:
                    if target in names and target != package and target not in SYSTEM_IMPORTS.get(package, frozenset()):
                        failures.append(f'ARCH_FORBIDDEN_IMPORT:{relative}:{node.lineno}:{package}->{target}')
    return ArchitectureAudit(len(names), inspected, tuple(sorted(set(failures))))

"""P25 passive host-evidence probe for setup/start (not an input authority).

The host report contains only categorical diagnostics and aggregate counts. It
never stores window titles, paths, IP addresses, ports, characters or packet data.
Windows-specific backends are injected for reproducible non-Windows testing.
"""
from __future__ import annotations

from importlib.util import find_spec
import os
from typing import Callable

from anka_app.configuration import RunConfiguration
from anka_client.api import ClientInspection


def probe_host(config: RunConfiguration, *, platform: str | None = None,
               inventory_factory: Callable | None = None,
               tcp_snapshot: Callable | None = None,
               scapy_available: Callable[[], bool] | None = None) -> dict:
    """Collect *observations only*; exceptions become stable, typed gaps.

    A successful probe NEVER certifies account identity, packet completeness,
    calibration, gameplay compatibility or input readiness.
    """
    system = os.name if platform is None else platform
    issues: list[str] = []
    report = {
        'status': 'READ_ONLY_UNCERTIFIED',
        'platform': 'WINDOWS' if system == 'nt' else 'NON_WINDOWS',
        'account_count': len(config.players),
        'candidate_windows': 0,
        'account_binding_states': [],
        'identity_issues': [],
        'geometry_reference_matches': 0,
        'geometry_issues': [],
        'tcp_ownership': 'NOT_CHECKED',
        'tcp_candidate_processes': 0,
        'capture': {
            'ports_configured': bool(config.capture.server_ports),
            'interface_configured': bool(config.capture.interface),
            'scapy_installed': False,
            'npcap_driver': 'NOT_VERIFIED',
            'driver_loss_visibility': 'UNKNOWN',
        },
        'live_certified': False,
        'account_binding_verified': False,
        'calibration_certified': False,
        'physical_input_permitted': False,
    }
    if system != 'nt':
        issues.append('HOST_WINDOWS_ACCEPTANCE_NOT_PERFORMED')
        report['tcp_ownership'] = 'WINDOWS_ONLY'
        report['issues'] = issues
        return report

    if not config.capture.server_ports:
        issues.append('CAPTURE_SERVER_PORTS_UNCONFIGURED')
    if not config.capture.interface:
        issues.append('CAPTURE_INTERFACE_UNCONFIGURED')
    try:
        installed = scapy_available() if scapy_available is not None else find_spec('scapy') is not None
        # Only optional module presence is checked; Npcap/driver completeness
        # is impossible to prove without an actual bounded capture trial.
        report['capture']['scapy_installed'] = installed is True
        if not installed:
            issues.append('CAPTURE_OPTIONAL_SCAPY_NOT_INSTALLED')
    except Exception:
        issues.append('CAPTURE_DEPENDENCY_PROBE_FAILED')

    candidate_pids: set[int] = set()
    try:
        if inventory_factory is None:
            from anka_client.win32_inventory import NativeWindowsInventory
            inventory_factory = NativeWindowsInventory
        inventory = inventory_factory(tuple(p.name for p in config.players))
        inspected = ClientInspection(inventory).inspect(tuple(p.name for p in config.players))
        report['candidate_windows'] = inspected['observed_windows']
        candidate_pids = {b['pid'] for b in inspected['bindings']
                          if type(b.get('pid')) is int and b['pid'] > 0}
        report['account_binding_states'] = [b['state'] for b in inspected['bindings']]
        report['identity_issues'] = [b['reason'] for b in inspected['bindings']]
        geometries = inspected['geometry'].values()
        report['geometry_reference_matches'] = sum(bool(g['observationally_matching_size']) for g in geometries)
        report['geometry_issues'] = sorted({issue for g in inspected['geometry'].values() for issue in g['issues']})
        if inspected['scan_errors']:
            issues.append('WINDOW_INVENTORY_INCOMPLETE')
        if any(b['state'] != 'IDENTITY_MATCHED' for b in inspected['bindings']):
            issues.append('WINDOW_CHARACTER_IDENTITY_UNATTESTED')
        # Even IDENTITY_MATCHED from an injected provider is NOT live certified.
        if not inspected['live_character_provider']:
            issues.append('CURRENT_BUILD_IDENTITY_PROVIDER_UNAVAILABLE')
    except Exception:
        issues.append('WINDOW_INVENTORY_PROBE_FAILED')

    # An endpoint ownership table is only a momentary process hint. Never
    # expose row addresses, endpoint tuples, PIDs or local account strings.
    try:
        if tcp_snapshot is None:
            from anka_capture.windows_flows import WindowsTcpOwnership
            tcp_snapshot = WindowsTcpOwnership().snapshot
        rows = tcp_snapshot()
        report['tcp_candidate_processes'] = len({r.pid for r in rows
                                                 if getattr(r, 'state', None) == 5
                                                 and r.pid in candidate_pids})
        report['tcp_ownership'] = 'PROVISIONAL_PROCESS_HINT_ONLY'
    except Exception:
        report['tcp_ownership'] = 'UNAVAILABLE'
        issues.append('WINDOWS_TCP_OWNER_TABLE_UNAVAILABLE')
    # Do not mark absence of TCP connections as an error: game need not be open
    # when the operator runs setup.
    report['issues'] = sorted(set(issues))
    return report

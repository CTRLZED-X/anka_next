# R5.153 — Controlled Zone-200 Pilot Evidence & Strategy-Routing Hardening

## Purpose

R5.153 is the first milestone after the R5.152 foundation-readiness audit. It does **not** change combat execution or tactical policy. Its job is to make the first real level-200 pilot scientifically useful and safe:

1. prove from runtime evidence whether the fights were actually level-200 encounters;
2. prevent an accidental long/unbounded pilot;
3. bind the exact pilot configuration to the exported incident package;
4. route the next GPT/developer to the correct change surface after the run;
5. preserve the rule that a few successful fights can never auto-certify arbitrary level-200 mastery.

## Changes

### Encounter evidence

Debug export now writes `analysis/zone_200_encounters.json`.

The report groups FightAI decision traces by `fight_instance_id` and records observed enemy levels, static ids, maps and evidence coverage. A fight is marked `validated_level_200` only when evidence contains either:

- an enemy explicitly observed at exact level 200; or
- one of the exact bundled Sufokia capability-profile static ids that are already documented as accepted level-200 evidence (`4455`, `4456`, `4457`, `4461`).

It never infers level from a zone name, mission label, monster name or tactical prior. Encounter identity is diagnostic evidence only and does not authorize mechanics.

Applied retrospectively to `runtime(20261001-233620)`, the new analyzer sees five fights, complete observed enemy levels around 16–20, and **zero** validated level-200 fights. This proves that lower-zone success is not promoted into level-200 evidence.

### Bounded pilot preflight

`zone200_pilot.bat` and `anka_platform.zone200_pilot` add a passive pilot gate. The gate requires:

- party mode and at least two active controllers;
- capture enabled;
- a 3–5 win target;
- no more than five attempts;
- stop-on-loss and stop-on-unknown;
- active FightAI profiles with enabled spells;
- arbitrary-zone map data configured;
- normal static foundation readiness.

The command starts/adopts Script Studio, records the pilot contract, then runs the existing passive live preflight. It does **not** launch combat by itself.

### Pilot intent

A successful pilot preflight writes `runtime/pilot/intent.json` containing the exact `config.yaml` SHA-256, budget, accounts, route/monster range, protocol adapter and no-manual-combat-input contract.

Debug export includes it as `pilot/intent.json` so post-run analysis can prove what was requested for that exact run.

### Post-run routing

`analysis/zone_200_readiness.json` now distinguishes:

- foundation failure → repair only the owning foundation layer;
- lower-zone-only evidence → run the controlled level-200 pilot before drawing tactical conclusions;
- real level-200 evidence + complete one-bundle diagnostics → freeze foundation by default and iterate in FightAI/TeamStrategy/evidence-backed tactical knowledge.

The report contains `strategy_iteration.post_run_route`, `recommended_change_surface` and `freeze_foundation_by_default`.

### Generic autonomous certification remains fail-closed

Even three or more validated level-200 fights do not automatically set `generic_autonomous_zone_200_certified=true`. Diverse encounter observations are necessary evidence but not sufficient certification. A future explicit certification artifact is required in addition to complete combat truth and foundation safety.

## What R5.153 deliberately does not change

- physical mouse/keyboard ownership;
- ExecutionService transaction semantics;
- ControlAuthority;
- PartyCombatController turn ownership;
- campaign lifecycle;
- Canonical State semantics;
- Kernel legality;
- TacticalPolicy/TeamStrategy behavior;
- R5.151 delayed-confirmation reconciliation.

The foundation remains frozen by default unless new live evidence proves a foundation contract failure.

## Remaining level-200 truth gaps

The existing explicit gaps remain:

- exact tackle/lock mechanics;
- generic effect apply/refresh/stack/expire/remove lifecycle;
- comprehensive enemy dynamic HP/AP/MP truth;
- summon capacity/lineage semantics;
- unknown monster-specific mechanics and states;
- protocol-version drift must remain guarded rather than assumed equivalent.

These unknowns remain fail-closed. They are not bypassed by the pilot tooling.

## Next live step

On Windows:

1. fresh-extract the R5.153 ZIP;
2. open the selected Dofus clients;
3. run `zone200_pilot.bat`;
4. only if it prints `ZONE200_PILOT=READY_TO_LAUNCH_FROM_SCRIPT_STUDIO`, press Launch once in Script Studio;
5. run a bounded 3–5 fight level-200 pilot with no manual combat input;
6. send the single resulting runtime/debug package.

Post-run analysis should first read `pilot/intent.json`, `analysis/zone_200_encounters.json`, `analysis/zone_200_readiness.json`, `analysis/foundation_health.json`, `fight_ai/FIGHT_SUMMARY.json`, `fight_ai/DECISION_TRACES.jsonl`, `fight_ai/ACTION_OUTCOMES.jsonl` and `fight_ai/ACTION_EFFECTS.jsonl`.

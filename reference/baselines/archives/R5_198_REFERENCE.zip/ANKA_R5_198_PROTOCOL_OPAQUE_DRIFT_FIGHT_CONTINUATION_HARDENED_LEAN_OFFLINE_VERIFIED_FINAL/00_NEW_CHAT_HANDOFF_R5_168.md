# R5.168 New-Chat Handoff

## Current workspace

This workspace is **R5.168 — Dofus 3.6.12.16 Protocol Integration**. Start with `R5_168_NEW_PROTOCOL_3_6_12_16_INTEGRATION.md`, then inspect the new adapter and its local evidence package.

Active adapter: `dofus_3_6_12_16`.

Primary implementation:

- `src/anka_platform/protocol/adapters/dofus_3_6_12_16/adapter.py`
- `src/anka_platform/protocol/adapters/dofus_3_6_12_16/manifest.py`
- `src/anka_platform/protocol/adapters/dofus_3_6_12_16/evidence/`
- `tests/r5168/`

The historical `dofus_3_6_10_10` decoder remains intact. Shared runtime layers now consume revision-neutral `protocol_decoder_ready` / `protocol_decoder_mode` rather than hard-coding the historical `R4` label.

## What is already integrated

The observed 3.6.12.16 world/fight path is decoded into the existing canonical contract, including world/group snapshots and motion; map direction; fight roster/placement/turns; local identity; HP/max HP/AP/MP/range; shield and erosion; spells/cooldowns; effects/states and exact removal; summon creation/control; damage/heal/death/push/teleport; normal turn end; fight terminal state.

CRA/ENU supplied captures replay with zero unclassified controlled messages and no transform failures. Their supplied stat screenshots are reproduced at fight bootstrap (CRA 2047 HP / 7 AP / 3 MP; ENU 2045 HP / 7 AP / 3 MP).

## Do not weaken these boundaries

Do not invent follower join semantics from the old protocol. `FIGHT_JOIN` and `JOIN_FIGHT_REQUEST` remain unsupported until a controlled follower-join capture exists. Do not turn screenshots into packet-aligned ORACLE evidence. Do not let new wire names leak into FightAI, Kernel, or execution-policy logic.

## Verification

Read `verification/R5_168_OFFLINE_VERIFICATION.md` and `verification/r5_168_live_decoding/LIVE_DECODING_REPORT.md`.

Offline status: verified. Full two-account Windows/Dofus live acceptance: pending evidence.

## Final cleanup/gates

The revision-neutral slot compatibility path has been hardened for simultaneous old/new adapter registration. Generic join diagnostics/comments no longer depend on historical raw wire names. The current bounded regression gates pass, including 242 combined R5.168/architecture/protocol/live-state/contracts/core tests, 89 party tests, the 187-pass retained R5.157-R5.168 release line (11 historical metadata skips), and the focused 8-test slot/registry regression. The live-decoding verifier intentionally remains BLOCKED on exactly seven proof/evidence boundaries; this is the expected fail-closed release state until follower-join evidence and the remaining ORACLE-strength proofs are supplied.

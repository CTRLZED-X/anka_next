# ANKA R5.167 — New Chat Handoff

## Current authority

Workspace checkpoint: `ANKA_PLATFORM_R5_167_PROTOCOL_POLICY_ISOLATION_WORKER_RECOVERY_ARCHITECTURE_HARDENING_WINDOWS_LIVE_CANDIDATE`.

Read this file first, then `R5_167_PROTOCOL_POLICY_ISOLATION_WORKER_RECOVERY_ARCHITECTURE_HARDENING.md`, `PROTOCOL_UPGRADE_GUIDE.md`, `FIGHT_POLICY_CHANGE_GUIDE.md`, `PROJECT_STATUS.json`, `PROJECT_CONTEXT.json`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md`.

R5.167 inherits R5.166 runtime behavior and the previously successful five-fight foundation. This release primarily hardens extension boundaries and disposable-component recovery; Windows/Dofus live acceptance for the new architecture candidate remains PENDING.

## Protocol rule

A future Dofus wire change belongs in a new `protocol/adapters/<id>/` package and its manifest. The manifest owns raw names, field mapping, stable semantic request bindings, slot dialect, capabilities, persistence migration and certified compatibility rules. Add one explicit registry registration, select the adapter in SessionPlan/config, certify it from fresh evidence, then run the architecture/current gates. If canonical contract major remains compatible, do not rewrite FightAI/Kernel/party/campaign/execution.

## FightAI rule

Treat FightAI as a replaceable policy plugin. Implement the core FightPolicy/TeamStrategy ports, register at product composition, consume `PlannerInvocationContext`, and return core `FightDecision` values only. Policies never send physical input and never own Canonical State/campaign lifecycle.

## Recovery rule

Recover disposable components, not stateful authorities by duplication. `SESSION_ONLY` worker crashes are bounded-restartable. Network continuity/reconnect and execution uncertainty retain their existing safe reconciliation. Canonical/Execution authorities remain singular to avoid split brain. A parent-process crash requires safe restart/reconciliation; automatic in-flight resurrection is not certified.

## Mandatory architecture check

Run `python tools/verify_foundation_architecture.py`. A PASS requires zero static import cycles and no protocol/FightAI/input ownership leaks.

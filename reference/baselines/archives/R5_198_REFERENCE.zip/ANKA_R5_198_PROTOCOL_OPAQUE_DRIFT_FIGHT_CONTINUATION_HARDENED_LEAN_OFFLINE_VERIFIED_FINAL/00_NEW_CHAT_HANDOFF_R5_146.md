# ANKA R5.146 — New-chat handoff

## Current candidate

`ANKA_PLATFORM_R5_146_COMBAT_SURVIVABILITY_COMPLETE_ACTION_COVERAGE_INPUT_CAUSALITY_L200_TRUTH_GATES_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus live acceptance: **PENDING**. Do not call this a final/live-certified release from offline tests alone.

## Why R5.146 exists

R5.145 blocked again in `runtime(20260928-020313)`: ENU END_TURN became physically `UNCERTAIN` after foreground changed during/after the click. The runtime correctly refused an immediate duplicate input but incorrectly escalated the quarantine into fight/campaign failure. The same runtime also proved that CRA could END_TURN with 7 AP after deep evaluation of only 5/22 spells.

## R5.146 systemic changes

* Structured physical uncertainty for CAST/MOVE/END_TURN is passively reconciled instead of immediately killing the fight.
* No new input is emitted while reconciliation is pending.
* Windows click diagnostics record foreground at DOWN/UP/settle boundaries and identify unexpected HWNDs where possible.
* FightAI records cheap whole-bar coverage separately from deep Kernel evaluation.
* Deep coverage rescue runs before expensive MOVE/sequence depth.
* Planner END_TURN with AP remaining is not tactically certified while spells remain deeply unevaluated.
* Very low-value MOVE is rejected outside danger modes to reduce needless click risk.
* `ENEMY_SIDE` is correctly recognized by level-200 readiness telemetry.
* Current/default Sufokia farming missions are 5 wins / 10 attempts, `stop_on_loss=false`, `stop_on_unknown=false`; the explicitly named legacy mission/config remain strict compatibility paths.

## Authority boundaries that must remain

Strategy proposes; Kernel/canonical truth authorizes; ExecutionService owns physical input. Do not bypass latest-state admission, ControlAuthority, exact window/process generation, or uncertainty fences to improve liveness. Recovery means passive observation and bounded safe fallback, not blind retry.

## Important remaining L200 blockers

Exact tackle/lock, authoritative summon capacity/lineage, complete enemy dynamic HP/AP/MP, complete state/effect lifecycle and target-zone monster mechanics are not universally certified. Do not guess them inside FightAI.

## First files to read

1. `R5_146_COMBAT_SURVIVABILITY_COMPLETE_ACTION_COVERAGE_INPUT_CAUSALITY_L200_TRUTH_GATES_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `src/anka_platform/execution/service.py`
5. `src/anka_platform/core/fight/controller.py`
6. `src/anka_platform/fight_ai/tactical_policy.py`
7. `src/anka_platform/execution/windows.py`
8. `src/anka_platform/fight_ai/telemetry/trace.py`
9. `tests/r5146/`

## Next live test evidence to inspect

For every uncertain action: action ID, physical phase diagnostics, unexpected foreground identity, reconciliation observations, turn owner/turn index, protocol request if available, and whether another physical input occurred before closure. For every CRA/ENU turn: cheap/deep spell coverage, unevaluated spell keys, candidates, selected utility, movement materiality and END_TURN certification.

## Final full-chain audit corrections

After the first R5.146 package was built, the exact ZIP was audited end-to-end again. The final audited candidate additionally ensures:

* coverage-incomplete or unavailable planner budget can never be converted into an outer-layer fallback END_TURN;
* FightAI receives its full configured search budget from actual policy start;
* uncertain CAST observations are durably correlated to the physical origin action;
* passive combat recovery has a 45-second active-fight watchdog horizon for natural handoff;
* the Script Studio default `sufokia_farm` mission uses the resilient budget;
* empty-cell AoE centers are not starved by occupied-cell shortlist ordering.

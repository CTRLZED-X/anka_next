# R5.180 — Transactional Live Truth & Failure Isolation Foundation

R5.180 is a runtime-foundation hardening release over the verified R5.179 reproducibility baseline. Its purpose is to prevent partial live-truth commits, decoder/canonical split-brain, ambiguous failure attribution, silent configuration mistakes, and compatibility fallbacks that can hide real software defects.

## Structural changes

- `CanonicalStateStore.append_batch()` reduces one logical event batch first, then writes journal rows, terminal fight evidence and checkpoints in one SQLite transaction;
- any persistence-stage exception explicitly rolls back and fences the store instance; ambiguous commit acknowledgement is reconciled only by reopen/replay;
- `LiveIngestionService` checkpoints version-local adapter context before transform and restores it whenever transform/reduction/persistence does not become canonical truth;
- protocol transform failures, protocol-context checkpoint/restore failures, canonical reducer/sequence failures, persistence failures and existing store fences have separate failure codes and health fields;
- live preflight, reliability health and Windows certification block on canonical/context fences even when packets remain fresh;
- `CampaignRuntimeController` no longer falls back to a legacy fight-generation heuristic when the real lifecycle authority raises, and bootstrap compatibility uses callable-signature inspection instead of swallowing internal `TypeError`;
- operator configuration is schema-versioned, duplicate-key checked and `extra="forbid"`; sealed setup requires Python 3.13.x exactly;
- incident failure codes are normalized to the registered vocabulary and incident/export shutdown races are deterministic;
- architecture verification disables unrelated pytest plugin autoload, supports named groups and bounds timed-out subprocess trees.

## Preserved authority

- Canonical State remains semantic live-truth authority;
- the Game Kernel remains deterministic mechanics/legality authority;
- FightAI remains policy/decision logic and cannot send physical input;
- `ExecutionService` remains physical-input authority;
- `InputArbiter` remains the cross-account physical-input lease;
- protocol wire details remain confined to versioned protocol packages behind `CanonicalEventEnvelope`.

## Fail-closed recovery rule

A canonical durability failure is not treated as an ordinary transform error and is not followed by more packet consumption. The affected store/runtime generation is fenced. Recovery requires a reopen/replay boundary that reconciles durable journal state before live truth can resume.

## Live acceptance

R5.180 is offline-foundation work until a bounded Windows/Dofus run proves the new transaction/failure boundaries under real timing. Live acceptance remains **PENDING**.

# R5.156 — Live-Decoding / Canonical-Truth Certification

## Objective

R5.156 makes protocol updates a bounded, evidence-driven operation instead of a repeated live-debug cycle.

After a Dofus protocol change, GPT may update the versioned protocol adapter/wire profile from PCAPNG + context evidence. The rest of ANKA must continue to depend on stable semantic contracts. A single certification command then proves whether the current code supplies every blocking live truth required by world control, party/fight lifecycle, FightAI, latest-state admission, execution settlement and recovery.

The certification target is **not packet coverage**. It is the downstream Canonical Truth contract.

## Command

From the project root:

```bat
verify_live_decoding.bat
```

For one current-build evidence package:

```bat
verify_live_decoding.bat C:\evidence\fight_01
```

For several controlled captures of the same exact adapter/build/decoder identity:

```bat
verify_live_decoding.bat C:\evidence\fight_01 C:\evidence\fight_02 C:\evidence\world_01
```

The command returns exit code `0` only when status is `READY`. `BLOCKED` and `INSUFFICIENT_EVIDENCE` return non-zero.

## Outputs

`runtime/live_decoding/LIVE_DECODING_REPORT.md` is the concise human report.

`runtime/live_decoding/LIVE_DECODING_REPORT.json` is the complete machine-readable assessment.

`runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json` is intentionally **GPT-oriented**, not user-oriented. It contains the first violated boundary, structured requirement data, exact evidence locators when available, build/evidence identities, likely owner paths, falsification-safe next action and an additional-capture recipe when the existing evidence cannot decide the semantic.

`runtime/live_decoding/LIVE_DECODING_CERTIFICATE.json` binds the result to the exact protocol implementation hash, Live Truth Contract hash, client-build certification, active evidence identity/set hash, regression corpus, architecture boundary audit and coverage result. A certificate is authorizing only when `status == READY`.

`runtime/live_decoding/` is intentionally mutable and excluded from `PACKAGE_MANIFEST.json`. Running certification with new evidence must not dirty or invalidate the immutable delivery package. Use `--output-dir` only when an explicit alternate artifact location is required.

## Evidence package

New evidence should contain `LIVE_DECODING_EVIDENCE.json`. See `docs/reference/LIVE_DECODING_EVIDENCE_TEMPLATE.json`.

The manifest supplies identity that must not be guessed from protocol traffic: exact observed client build, adapter id, game-server ports, per-account TCP flow, client-instance identity, optional oracle-member identity, optional expected spell-loadout fingerprint and controlled outbound semantic assertions.

A controlled wire assertion identifies an exact packet and the expected stable semantic fields. This is required to certify current-build request causality such as CAST, MOVE, END_TURN, WORLD_ATTACK, JOIN_FIGHT and READY. Merely seeing a familiar raw wire name is not sufficient.

Independent bridge snapshots are optional at the evidence-package level but are required to promote ORACLE-level truths. The oracle never mutates Canonical State.

## Anti-false-green rules

1. Fresh current-build evidence is the only proof source for current-build semantics. Historical/bundled evidence is regression evidence only.
2. Several evidence packages can be unioned only when adapter id, exact client build and decoder hash agree. Mixed builds are rejected.
3. Exact client-build identity is mandatory for fresh certification. Guarded compatibility cannot produce READY.
4. Unknown/unclassified messages, transform failures, provenance failures, controlled wire-assertion failures and oracle mismatches block certification.
5. `NOT_EVIDENCED` means collect evidence first. It must never be promoted by guessing a packet meaning.
6. Coverage percentage never authorizes a run. One missing blocking semantic keeps status non-READY even at 99%.
7. The verifier validates its own Live Truth Contract against the canonical event schema and oracle comparators before blaming decoder code.
8. Raw packet names/layouts must stay behind the protocol boundary. Control-path imports of protocol internals, raw message-name queries and adapter literals are architecture failures.
9. Protocol regression evidence is hash-linked. A historical full-capture report remains usable only when a certified decoder-successor chain reaches the current decoder hash.
10. Every repaired semantic should gain a deterministic falsification regression before recertification.

## Stable wire-semantic boundary

Execution now consumes `ProtocolWireSemantic` (`CAST_REQUEST`, `MOVE_REQUEST`, `END_TURN_REQUEST`, `WORLD_ATTACK_REQUEST`, `JOIN_FIGHT_REQUEST`, `READY_REQUEST`) rather than knowing Dofus raw message names or protobuf field numbers. The active `ProtocolWireProfile` owns those details. Spell-slot dialect resolution likewise goes through the protocol registry instead of a hard-coded adapter id.

This means a future wire rename/layout change should normally be repaired inside the versioned protocol profile/adapter and evidence, while FightAI, Kernel, party orchestration and execution continue to consume stable semantic contracts.

## Current R5.156 baseline truth

The retained R5.155 evidence intentionally does **not** produce a false READY. The current baseline reports three blocking gaps:

- `LT-ERODED_HP`: implementation gap. The previous manifest advertised this too broadly; the current decoder exposes erosion/max-HP-loss evidence, but ANKA does not yet have a fully certified authoritative `eroded_hp` truth path for the configured mechanics that depend on it.
- `LT-FIGHT_IDENTITY`: proof gap. Existing retained full-capture report predates field-level statistics needed by the new verifier.
- `LT-STATES`: evidence gap. State semantics are declared/consumed, but retained evidence does not exercise `actor_states_observed` strongly enough for this new gate.

This is deliberate. R5.156 is a truth gate, not a mechanism for making the current package look green.

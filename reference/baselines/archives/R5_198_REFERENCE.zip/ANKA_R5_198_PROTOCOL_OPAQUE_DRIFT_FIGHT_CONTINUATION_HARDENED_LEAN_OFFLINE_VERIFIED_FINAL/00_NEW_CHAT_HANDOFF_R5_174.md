# New Chat Handoff — R5.174

Current workspace: **ANKA R5.174 — Startup Authority / Protocol Foundation Hardening**.

R5.174 starts from R5.173 and the failed live runtime `runtime(20261012-175827)`. The visible symptom was again “Launch does nothing.” This time the exact source-level failure was a duplicated startup-policy interpretation: bootstrap-expected canonical/projection gaps were allowed in `runtime_health`, then rejected again from `account.blockers`. The worker therefore never started even though world bootstrap was `READY` for `[7,-12] -> RIGHT -> [8,-12]`.

## R5.174 invariants

- startup blocker meaning has **one authority**: `src/anka_platform/party/startup_policy.py`;
- bootstrap decisions use explicit phases and normalized blocker classifications rather than independent string whitelists;
- every known blocker has typed metadata; any new/unregistered blocker fails closed and is diagnosed as `STARTUP_BLOCKER_UNCLASSIFIED`;
- the exact October 12 R5.173 live preflight is a committed regression fixture and must reach `RUNTIME_REQUIRED`, not `PENDING_LAUNCH_STALLED`;
- `PartyRuntimeManager.refresh_projection_authority()` is a generation-safe, input-free diagnostic facade; a stale/faulted generation cannot be refreshed as authoritative;
- diagnostics expose startup policy facts and distinguish a bootstrap-gate mismatch from downstream consequences;
- protocol compatibility is adapter-manifest/capability based. Client build drift (currently observed 3.7.8.7 against adapter baseline 3.6.12.16) remains **unproven**, not silently certified and not automatically blamed for startup starvation;
- FightAI, Kernel, normal ExecutionService readiness and physical-input ownership are not relaxed by bootstrap policy;
- inherited R5.173 terminal `FAILED_TO_START` + authorization consumption + ControlAuthority disarm remains mandatory;
- inherited R5.173 projection authority remains the structurally verified 560-cell runtime grid; entity actions still require strict EntityId/CellId/runtime agreement;
- Unity bridge identity remains contract **4** / plugin **2.2.75** because R5.174 changes Python startup/control/diagnostic policy, not the bridge wire/binary contract.

Windows/Dofus live acceptance remains **PENDING**. The next live run must either advance from pending Launch into the launched runtime/bootstrap path or fail safely with phase-specific, centrally classified evidence.

# R5.182 — Durable Execution, Diagnostic Truth & Verification Foundation

R5.182 is a focused pre-live foundation release built on sealed R5.181/R5.180 behavior. It does not redesign FightAI, Kernel mechanics, protocol capabilities, or physical-input ownership.

## What changed

- `ExecutionSafetyStore` now uses explicit SQLite transactions, rollback and a write-health fence for every safety mutation.
- Game-affecting physical sends are durably **prepared before delivery**. A process crash after delivery but before semantic settlement therefore leaves a restart-visible obligation instead of permission for a blind retry.
- Diagnostics V2 chooses the Canonical DB for the account that owns the incident whenever account lanes are available; the chosen account/path is recorded in the bundle summary/environment.
- Post-fight execution reconciliation no longer catches `TypeError` as a compatibility signal. Signature compatibility is decided before the production call.
- Per-account lifecycle and cross-account input leases expose owner age and use bounded fail-closed waiting. A waiter never steals or force-releases an existing lease.
- `tools/gpt_current_verify.py` runs the declared current gate in bounded per-target isolation and records PASS/FAIL/TIMEOUT instead of relying on one unbounded aggregate pytest command.
- Python package metadata now matches the sealed `3.13.x` contract. Setup can use an optional SHA-256-verified local runtime wheelhouse when one is present.

## Non-goals

R5.182 does not claim that the Dofus client, bridge, capture stack, or the five remaining ORACLE live truths are certified. It does not change combat policy weights or protocol wire assumptions simply to make live readiness look green.

## Live acceptance

After offline verification is sealed, use a fresh extraction, run `setup.bat` with Dofus closed, require all readiness checks, then run one bounded Script Studio Apply -> Launch. The run should deliberately collect independent evidence for world map, local actor identity, actor cell, AP and MP.

# ANKA R5.148 — New-chat handoff

## Current candidate

`ANKA_PLATFORM_R5_148_COMBAT_FOUNDATION_CONTRACTS_STATE_AUTHORITY_FIGHTAI_ISOLATION_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus live acceptance: **PENDING**. Offline verification does not replace live certification.

## Why R5.148 exists

`runtime(20260929-213532)` completed 5 wins in 5 attempts, but a forensic architecture pass showed that successful fights were hiding foundation coupling: the combat controller consumed TacticalPolicy-private progress telemetry, combat-frame freshness mixed semantic state with observation revisions, recovery/action state was represented in several vocabularies, and core combat modules still imported concrete FightAI helpers.

R5.148 is therefore a foundation milestone, not a strategy-tuning milestone.

## R5.148 changes

- core-owned `FightDecision` executable contract;
- core-owned typed planner disposition/progress/failure/dependency contract;
- one core-owned `PlannerInvocationContext`; current DecisionService no longer inspects concrete planner signatures; legacy signatures are adapted in one compatibility invoker;
- no TacticalPolicy candidate-audit dependency in `PartyCombatController`;
- dummy planner passes real DecisionService -> controller -> execution without `tactical_trace`;
- neutral `core/fight` and `core/ports` have no concrete FightAI imports;
- rich FightAI telemetry is injected from composition and remains non-authoritative;
- semantic combat-state hash separated from provenance/watermark hash;
- incomplete effect multiplicity remains fail-closed;
- typed `CombatActionOutcome` normalizes execution results;
- typed `PendingCombatTransaction` correlates reconciliation by `origin_action_id` **and owning account lane**;
- planner recovery uses typed dispositions for current producers, with old reason parsing quarantined to legacy compatibility;
- team tactical placement moved from core into FightAI;
- lifecycle classifier moved to core, with scripting compatibility re-export; FightWorkflow historical latches now live in one `FightWorkflowLifecycleMemory`;
- generic registry compatibility is preserved while every policy selected into a current `SessionPlan` is port-validated during compile/preflight;
- concrete policy composition moved outside neutral `core.registry`;
- turn heartbeat is durably journaled as a non-click execution action;
- inherited `ActorState` positional compatibility regression repaired.

## Authority split to preserve

```text
protocol/canonical state = observed live truth
Kernel                  = deterministic mechanics/legality
FightAI                  = replaceable proposal/planning brain
PartyCombatController    = turn orchestration/recovery
ExecutionService         = sole physical-input authority
Campaign/FightWorkflow   = lifecycle authority
observability            = evidence only, never permission
```

## First files to read

1. `R5_148_COMBAT_FOUNDATION_CONTRACTS_STATE_AUTHORITY_FIGHTAI_ISOLATION_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `src/anka_platform/core/fight/decision_contract.py`
5. `src/anka_platform/core/fight/planner_contract.py`
6. `src/anka_platform/core/fight/action_outcome.py`
7. `src/anka_platform/core/fight/action_transaction.py`
8. `src/anka_platform/core/fight/combat_frame.py`
9. `src/anka_platform/core/fight/controller.py`
10. `src/anka_platform/core/fight/recovery.py`
11. `tests/r5148/`

## Known explicit blockers before serious L200 rollout

Exact tackle/lock, authoritative effect/state lifecycle, complete enemy dynamic HP/AP/MP, summon capacity/lineage, and verified target-zone enemy capability packs remain incomplete. FightAI strategy can evolve more safely after R5.148, but these mechanics/evidence gaps still limit correct high-complexity tactical reasoning.

## Live acceptance target

A fresh Windows/Dofus run must show that the typed/pluggable foundation preserves R5.147 behavior: normal CRA/ENU actions, bounded planner liveness, heartbeat journaling, no stale-decision storm from provenance-only churn where semantics are unchanged, correct reconciliation correlation, and uninterrupted multi-fight campaign continuity.

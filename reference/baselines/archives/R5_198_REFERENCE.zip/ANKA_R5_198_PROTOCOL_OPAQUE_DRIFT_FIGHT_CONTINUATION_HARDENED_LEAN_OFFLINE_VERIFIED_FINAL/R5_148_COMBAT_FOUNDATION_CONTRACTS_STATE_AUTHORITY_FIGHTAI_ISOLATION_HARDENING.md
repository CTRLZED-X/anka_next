# R5.148 — Combat Foundation Contracts, State Authority & FightAI Isolation

R5.148 is a behavior-preserving foundation refactor driven by the successful `runtime(20260929-213532)` forensic pass. That run completed 5/5 fights, but it exposed hidden architectural coupling that would make future FightAI replacement unsafe even when live behavior looked healthy.

## Primary objective

FightAI must be a replaceable planner behind stable platform contracts. Core combat orchestration must not know TacticalPolicy internals, candidate-audit schemas, tactical threat models, or concrete telemetry builders. Physical input, canonical state, Kernel legality, turn lifecycle and recovery remain authoritative outside FightAI.

## Contract boundary

```text
Canonical/party evidence
  -> CombatDecisionFrame
  -> FightPolicy port
  -> FightDecision + PlannerResult
  -> PartyCombatController
  -> latest-state admission
  -> ExecutionService
  -> settlement/reconciliation
```

`FightDecision` and planner orchestration types are now owned by `core/fight`, not by `fight_ai`. `fight_ai.models` is a compatibility re-export for historical imports. `PlannerInvocationContext` is also core-owned; `FightDecisionService` invokes the current planner port without concrete signature inspection, while one compatibility invoker adapts historical signatures.

`PlannerResult` carries one typed disposition:

- `ACTION_READY`
- `CONTINUE_PLANNING`
- `WAIT_EXTERNAL`
- `NO_MATERIAL_ACTION`
- `FAULT`

with typed failure class/progress/dependency metadata. Human-readable reason strings are diagnostic for current producers; recovery semantics no longer depend on TacticalPolicy-specific reason names.

## FightAI isolation

- `PartyCombatController` no longer reads `tactical_trace.candidate_generation_audit`.
- Current policies expose generic planner progress; one quarantined compatibility adapter reads historical R5.147 direct-dict telemetry only for archived regression inputs.
- A dummy planner with no TacticalPolicy trace passes the real DecisionService -> controller -> execution path.
- `PolicyRegistry.register_fight()` validates the runtime-checkable `FightPolicy` port. The generic registry remains backward-compatible for historical namespaces, while `SessionCompiler` validates every selected fight/passive/team/placement policy against its core port before producing an executable plan.
- Concrete product policy construction lives in `anka_platform.policy_composition`, not in neutral `core.registry`.
- Neutral `core/fight` and `core/ports` contain no concrete `anka_platform.fight_ai` imports.
- Rich FightAI telemetry is injected by composition (`ScriptRuntimeHost`) and cannot authorize execution.
- The tactical CRA/ENU team-placement planner moved from neutral core into `fight_ai` because its roles/threat/capability model is tactical implementation, not platform foundation.

## Decision state versus evidence provenance

R5.147 used a single combat-frame fingerprint that mixed tactical semantics with observation watermarks. In the triggering successful runtime, 53 decisions were marked stale and 45 were invalidated only by new effect-observation traffic.

R5.148 splits:

- `semantic_fingerprint`: decision-relevant state;
- `provenance_fingerprint`: source revisions/watermarks/instance provenance.

New evidence alone no longer implies a different decision state. Real changes to positions/resources/states/effects/cooldowns/modifiers/casts still invalidate a proposal.

Effect multiplicity remains fail-closed. Because the live effect lifecycle is incomplete, R5.148 does **not** assume repeated identical effect rows are harmless duplicates: unresolved multiplicity stays semantic until authoritative stack/refresh/remove/expiry rules are known.

## Action/recovery authority

- Execution raw results normalize through `CombatActionOutcome` (`ACCEPTED`, `RECONCILING`, `AWAITING_SETTLEMENT`, `REJECTED_NOT_SENT`, `PHYSICAL_UNCERTAIN`, `CONTROL_FAILURE`, `FAILED`, ...).
- Controller turn-local reconciliation state is represented by one `PendingCombatTransaction` keyed by ExecutionService `origin_action_id` and owning account lane, rather than several unrelated fields.
- A reconciliation observation carrying the wrong action id is fenced as `COMBAT_RECONCILIATION_CORRELATION_MISMATCH` before it can affect the turn.
- Current planner recovery consumes typed disposition/failure classes. Legacy reason-token parsing remains quarantined for historical compatibility inputs only.
- ExecutionService remains the sole physical-input authority; R5.148 does not create another executor.

## Lifecycle ownership

The partial-party lifecycle classifier was moved from `scripting/` to `core/fight/lifecycle.py`; the old scripting module is only a compatibility re-export. `FightWorkflow` historical latches are consolidated in one `FightWorkflowLifecycleMemory`, so generation/reset state is mutated together rather than through independent booleans. Production lifecycle authority remains `CampaignRuntimeController` + `FightWorkflow`; the classifier is a deterministic state helper/legacy-certification surface, not a competing action owner.

The historical body in `party_square_6_8_five_fights.py` is retained for legacy/manual contexts, but production contexts immediately delegate to parent `party_campaign_step`. Do not modify the legacy path to change current production campaign behavior.

## Observability

`TURN_ACTIVITY_HEARTBEAT` is now journaled as a first-class execution action with stable action id and runtime correlation. Its record explicitly states `physical_click=false` and physical send state. A future runtime package can therefore prove whether inactivity defense ran.

## Kernel compatibility seam

R5.148 also repairs an inherited positional-constructor regression in `ActorState`: newer `cooldown_unknown_spell_ids` no longer sits inside the historical positional field prefix. This restores older replay/regression fixtures without weakening type checks. Kernel workspace identity stays `0.1.0a59 / R10J Single-Cell Cast Decision Query`.

## Explicit non-goals / remaining L200 blockers

R5.148 does not claim universal level-200 readiness. Still unresolved from authoritative live truth are exact tackle/lock, complete effect/state apply-refresh-stack-expire-remove semantics, complete enemy dynamic HP/AP/MP, summon capacity/lineage and verified capability packs for chosen level-200 zones.

## Acceptance principle

A replacement planner must be able to CAST/MOVE/END_TURN through the normal controller/execution/recovery chain without exposing TacticalPolicy telemetry or requiring controller modifications. Foundation failures must be attributable to typed contracts/state-machine boundaries rather than hidden reason-string conventions.

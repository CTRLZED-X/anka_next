# R5.152 — Zone-200 Foundation Readiness, Action-Effect Forensics & Hot-Path Hardening

## Scope

R5.152 is a systemic readiness pass based on `runtime(20261001-233620)` from R5.151. It does **not** claim that the current Cra/Enutrof strategy can autonomously solve arbitrary level-200 encounters. It separates three questions that must never be conflated:

1. Is the runtime/orchestration foundation safe enough to enter a controlled level-200 pilot?
2. Is the combat truth complete enough to let a policy reason about every level-200 mechanic?
3. Is the current tactical policy itself proven strong enough for arbitrary level-200 fights?

Only the first can be a candidate for readiness from the present evidence. Questions 2 and 3 remain explicitly evidence-gated.

## Live evidence audited

The R5.151 live run completed 5/5 wins, 0 losses, 0 unknowns, with no terminal campaign or mission failure. Capture generation remained clean, required account identity remained verified, and ControlAuthority was not unexpectedly disarmed.

The run nevertheless exposed important readiness facts:

- 133 FightAI action outcomes were correlated to fight identity; none were missing `fight_instance_id`.
- 83 CAST outcomes settled.
- one turn still contained multiple confirmed MOVE actions; R5.150's confirmed-turn history was present, proving this is now policy behavior rather than executor path-cell clicking or history loss.
- 18 stale-frame replans occurred and effect-payload expansion was observed 93 times.
- the largest observed actor effect payload reached 87 instances with semantic multiplicity 34.
- all 1,236 live `actor_effects_observed` events were partial observations; no complete generic effect lifecycle was observed.
- enemy `static_id` was available, but enemy max HP/AP/MP truth was not generally available to FightAI; local HP/max HP was present in only a minority of decision frames.
- six unclassified protocol observations (`ilv`, `ilz`) were preserved without inferred semantics. They occurred around campaign completion. The adapter/client version relationship remains `VERSION_DRIFT_GUARDED` rather than silently treated as an exact protocol match.
- the latest successful run did not live-exercise R5.151's delayed-confirmation reconciliation path; that behavior remains offline-regression-backed but still needs a naturally delayed live occurrence for live certification.
- CRA's first Ready interaction continued to show no outbound semantic Ready request in all five fights, while the bounded second attempt produced the request. R5.152 does not invent a Dofus-side cause; it preserves the evidence and bounded retry.

## Root-cause repairs and foundation changes

### 1. Planner-neutral combat-truth availability

`core/fight/combat_truth.py` introduces `CombatTruthAvailability` and `assess_combat_truth()`.

The contract tells any current or replacement FightPolicy exactly which observations are known/complete and which remain blockers. It is owned by neutral core, not by TacticalPolicy. Future FightAI code therefore does not have to reverse-engineer Canonical-State conventions or silently map UNKNOWN to zero.

The contract currently surfaces, among other things:

- local HP/max HP/AP/MP availability,
- local summon-count availability,
- local state/effect completeness,
- enemy HP/max HP/AP/MP/static-id completeness,
- enemy state/effect completeness,
- maximum effect payload and semantic multiplicity,
- effect-payload expansion,
- exact tackle/lock unsupported status,
- structured blocker codes.

This contract is added to `PlannerInvocationContext`; it does not grant execution authority and does not manufacture mechanics.

### 2. Event-backed per-CAST effect evidence

Snapshot delta alone was not sufficient for future strategy learning: the old summary could report zero observed damage despite many settled casts because absolute HP snapshots were incomplete.

R5.152 derives `fight_ai/ACTION_EFFECTS.jsonl` from already-captured per-account Canonical events. For each settled CAST it opens a bounded evidence window from the server-confirmed cast revision until the next local primitive/turn end.

High-confidence damage/healing is attributed only when the protocol event explicitly says `source_actor_id == local_actor_id`. Other state/resource/displacement observations are retained as bounded evidence but are **not** claimed as caused by the cast.

Applied retrospectively to the supplied R5.151 bundle, this produced:

- 83/83 settled CAST records covered,
- 3,399 observed enemy damage with explicit local-source evidence,
- 407 observed enemy max-HP loss,
- 60 observed ally damage,
- no fabricated effects where the confirmed revision is absent.

This is post-hoc strategy evidence only. It never changes live execution or Kernel legality.

### 3. Zone-200 readiness is now machine-readable and non-sensational

`analysis/zone_200_readiness.json` separates:

- `foundation_ready_for_controlled_zone_200_pilot`, and
- `generic_autonomous_zone_200_certified`.

A lower-zone 5/5 campaign can support foundation evidence but can never certify arbitrary level-200 tactical competence. Generic autonomous certification requires explicit future level-200 encounter evidence and complete enough combat truth.

A controlled-pilot verdict requires clean campaign completion, verified identity/capture continuity, guarded protocol compatibility, complete FightAI correlation, complete settled-cast effect evidence, and a launch-time Windows certification snapshot. Missing launch certification blocks the verdict rather than being ignored.

### 4. Launch-time Windows certification is preserved

R5.151 could export the *current* deep Windows certificate rather than the exact snapshot that authorized Launch. A certificate disappearing later could therefore be confused with an uncertified launch.

R5.152 stores the launch-time certification in a dedicated checkpoint and exports it separately. Later lifecycle checkpoint rewrites cannot erase this evidence.

### 5. Stable window identity avoids unnecessary desktop enumeration

The identity authority remains exact `HWND -> PID -> process creation time`. A stable bound HWND can therefore prove the same process generation without enumerating every desktop window on every health check.

R5.152 uses a direct bound-HWND generation proof first and falls back to full `EnumWindows` only when the bound HWND cannot be queried and replacement evidence is needed. This preserves identity safety while reducing avoidable hot-path stalls.

The live slow-step audit showed multiple causes, not one:

- some ~4s samples were exact Windows enumeration,
- some were intentional server-confirmation settlement waits,
- one was synchronous diagnostic JSONL writing.

R5.152 does not remove intentional confirmation waits.

### 6. Full FightAI traces are no longer synchronously duplicated

The run store previously wrote a large full FightAI trace into several streams. Individual traces could exceed 200 KB; replay rows exceeded 100 KB. One captured multi-second stack was blocked while writing duplicated forensic JSONL.

R5.152:

- keeps one dedicated full decision trace,
- strips the nested full trace from the generic decision stream and stores a correlation reference,
- stops synchronously writing a second full replay copy on the combat hot path,
- derives replay records during debug export from the canonical decision trace.

The diagnostic evidence remains available, but observability is less able to steal time from a live turn.

### 7. Effect completeness now fails closed correctly

The reducer used to preserve `effects_complete=True` after a later partial effect update. That was unsafe because generic effect expiry/removal is not certified.

R5.152 makes completeness describe the current observation. A partial effect update retains observed instances but downgrades `effects_complete=False`. No expiry/removal is invented.

## Future FightAI / TeamStrategy modification boundary

The intended extension surface is now explicit:

- `fight_ai/` — tactical scoring, target selection, positioning, spell choice, combinations, search/planning and diagnostics;
- `fight_ai/tactical/team_strategy.py` or a replacement TeamStrategy implementation — team objectives and cooperation;
- combat profile/configuration/knowledge data where mechanics are evidence-backed;
- Kernel mechanics only when protocol/static evidence proves a missing deterministic rule.

A normal strategy iteration should **not** modify:

- `ExecutionService`, Windows input or cursor delivery,
- ControlAuthority/input leasing,
- PartyCombatController turn ownership or transaction quarantine,
- campaign/session lifecycle,
- protocol generation binding,
- world/fight workflow ownership,
- Canonical State semantics merely to make a strategy easier.

A permanent architecture test scans the whole `fight_ai` package and fails if it imports execution, Windows/input, campaign, scripting, party orchestration or web/session-control layers. Core also remains independent from concrete FightAI.

## What remains deliberately unresolved

These are not silently patched or guessed:

1. generic effect/state apply-refresh-stack-expire-remove lifecycle;
2. exact tackle/lock mechanics;
3. comprehensive enemy max-HP/AP/MP truth;
4. local summon capacity and full summon lineage/capacity semantics;
5. unknown monster-specific target zones/states/mechanics not present in evidence;
6. current client/adapter version drift and unclassified messages;
7. R5.151 delayed-confirmation reconciliation still requires live exercise;
8. current TacticalPolicy/TeamStrategy has not been proven across diverse level-200 encounters.

## Readiness conclusion

R5.152 is designed to be a **controlled zone-200 pilot candidate**, not a declaration of generic autonomous level-200 tactical readiness.

The correct next milestone is a bounded R5.152 live pilot. If the launch-time certification, identity/capture continuity, action-effect coverage and campaign safety gates remain clean, the project can begin collecting level-200 encounter evidence. Future strategy changes should then stay inside the guarded policy surface while the foundation is frozen by default.

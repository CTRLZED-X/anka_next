@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Python environment is missing. Run setup.bat first.
  exit /b 2
)
if not exist "config.yaml" (
  echo ERROR: config.yaml is missing. Copy config.yaml.example to config.yaml and verify paths.
  exit /b 2
)

echo ADVANCED_DIAGNOSTIC_ONLY: Normal live use requires only start.bat or run_anka.bat without flags.
echo This file expects the ANKA server to already be running.
echo.
echo === ANKA STATIC / PROTOCOL READINESS ===
.venv\Scripts\python.exe -m anka_platform.cli readiness --config config.yaml
if errorlevel 1 (
  echo.
  echo LIVE_PREFLIGHT=BLOCKED_STATIC_READINESS
  exit /b 3
)

echo.
echo === PASSIVE LIVE CHAIN READINESS ===
echo This check sends no Dofus input. Open the required Dofus clients first, then start ANKA.
echo Party mode resolves each exact client bridge through the running platform; no fixed bridge port is assumed.
.venv\Scripts\python.exe -m anka_platform.live_preflight --config config.yaml
if errorlevel 1 (
  echo.
  echo LIVE_PREFLIGHT=BLOCKED
  echo Do not run Script Studio physical automation yet.
  echo Inspect Dashboard 1 and Dashboard 2, then run debug.bat if the platform recorded a failure.
  exit /b 5
)

echo.
echo LIVE_PREFLIGHT=READY_FOR_CONTROLLED_LIVE_TEST
exit /b 0

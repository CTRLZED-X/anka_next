# ANKA R5.189 — New Chat Handoff

**Release:** R5.189 — Fight Geometry Authority Foundation  
**Platform:** `0.1.0a137`  
**Status:** **OFFLINE VERIFIED**  
**Windows/Dofus live acceptance:** **PENDING**

## Current authority

Read `PROJECT_STATUS.json`, `R5_189_FIGHT_GEOMETRY_AUTHORITY_FOUNDATION.md`, `verification/R5_189_OFFLINE_VERIFICATION.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md` before changing runtime behavior.

## Important live history

R5.188 successfully reached a shared CRA+ENU fight. Protocol decoded PLACEMENT and subsequent ACTIVE/turn truth, but placement never clicked because semantic fight MapId `190711810` was not present as Mapuse geometry. The source world map `190581250` at `[8,-12]` had valid 560-cell geometry and the exact protocol placement cells. Repeated `PROJECTION_MAP_MISMATCH` eventually caused Dofus timer auto-start and downstream `PREPARATION_AUTO_STARTED_INCOMPLETE`.

## R5.189 solution

`src/anka_platform/integration/fight_geometry.py` owns the fight-instance-scoped geometry binding. Semantic fight MapId stays Canonical truth. No global alias is created. ProjectionSync, ExecutionService fight-cell projection, KernelContextAdapter, FightAI policies, action admission and scripting analysis consume the same bound geometry.

Placement liveness now counts deterministic input-free map/geometry failures per account/fight, so target changes or CRA/ENU interleaving cannot hide a systemic blocker.

## Preserve these boundaries

Canonical State remains semantic live truth. ExecutionService remains the only public physical-input authority. InputArbiter remains the cross-account input lease. Protocol structures remain inside versioned adapters. Unknown geometry fails closed. Do not weaken Ready acknowledgement merely because Dofus auto-started on its timer.

## Next step

Use a fresh R5.189 extraction. With Dofus closed run `setup.bat`; then `start.bat`, Script Studio, Apply once, Launch once. Use CRA+ENU and a bounded fight. Expected progression is fight entry -> geometry binding -> placement -> Ready -> ACTIVE -> first FightAI decision. On any failure preserve the complete runtime/debug package before patching.

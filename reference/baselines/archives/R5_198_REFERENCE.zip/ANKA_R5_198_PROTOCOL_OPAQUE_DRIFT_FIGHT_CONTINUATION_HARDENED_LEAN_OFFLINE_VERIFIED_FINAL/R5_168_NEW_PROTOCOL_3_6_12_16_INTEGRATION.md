# R5.168 — Dofus 3.6.12.16 Protocol Integration

## Purpose

R5.168 integrates the evidence-backed Dofus 3.6.12.16 live protocol behind the existing protocol-adapter boundary while preserving the R5.167 architecture, FightAI, deterministic Kernel, execution policy, and historical 3.6.10.10 decoder.

The migration is intentionally semantic rather than wire-name driven:

`TCP -> framing/Any extraction -> revision adapter -> canonical events/state -> existing downstream layers`

No FightAI or Kernel rule is allowed to depend directly on new obfuscated wire names.

## Active adapter

- Active protocol adapter: `dofus_3_6_12_16`
- Certified client build declared by its manifest: `3.6.12.16`
- Historical adapter `dofus_3_6_10_10` remains registered and its `adapter.py + r4.py` decoder bytes remain at the R5.163 certified hash.
- Static game-data version remains independently configured; protocol revision and static mechanics pack are not conflated.

## Integrated live truth

The new adapter covers the observed world/fight path: full and incremental world snapshots, monster groups and movement, map identity and transition direction, fight identity/roster/placement, local/principal actor identity, current/max HP, AP/MP/range characteristics, eroded HP, shield state/absorption, rounds/turns/normal turn end, spell loadout/casts/cooldowns, exact effect-instance lifecycle, states, pushes/teleports, summon creation/control, death, challenge traffic, fight terminal state, and observed XP/result traffic.

Important authority rules are preserved: server movement result wins, `jti` replaces cooldown state atomically, `juu` owns exact effect removal, authoritative server cast identity owns the caster, and AP/MP characteristic snapshots reconcile action deltas rather than being double-applied.

## New-protocol evidence

Evidence is co-located with the adapter at:

`src/anka_platform/protocol/adapters/dofus_3_6_12_16/evidence/`

It includes both supplied PCAPNGs, CRA/ENU stat-oracle screenshots, spell evidence, movement evidence, unresolved-wire inventory, coverage gaps, and the reverse-engineering report.

The supplied CRA and ENU PCAPNGs replay through the production adapter with zero unclassified controlled messages and no transform failures. The R5.168 regression suite verifies the 22-slot loadouts, 21 observed CRA spell casts, summon-controlled ENU casts, HP/AP/MP/stat baselines, effect/state lifecycle, shield absorption, erosion, legal placement, map direction, and actor-matching `jup` turn termination.

## Deliberate fail-closed boundary

Full two-account live acceptance is **not certified yet** because the supplied captures are solo fights and therefore contain no follower `JOIN_FIGHT_REQUEST` lifecycle. The new manifest deliberately omits `FIGHT_JOIN` and `JOIN_FIGHT_REQUEST` instead of reusing an old wire name.

The live-decoding verifier also requires packet-aligned ORACLE proof for local actor, world map, actor cell, AP and MP. These truths are decoded and replay correctly, and the supplied screenshots corroborate the 7 AP / 3 MP baselines, but screenshots are not falsely promoted to packet-aligned ORACLE evidence.

See the adapter-local `COVERAGE_GAPS.md` and `verification/r5_168_live_decoding/LIVE_DECODING_REPORT.md` for the exact remaining blockers.

## Verification status

Offline integration is verified. Windows/Dofus live acceptance remains `PENDING`.

The retained release-line regression gate R5.157-R5.168 passes with historical-release skips only. Architecture verification is PASS. Focused protocol/live-state/party/application/certification suites pass. The live-decoding gate is expectedly BLOCKED only at the explicitly unsupported follower-join and ORACLE-strength evidence boundaries; it is not bypassed.

## Next evidence capture

The only critical new protocol capture required for full multi-account admission is a short two-account sequence:

1. CRA attacks a visible monster group.
2. ENU sees the same fight and clicks **Rejoindre**.
3. Both accounts reach placement.
4. Both click **Prêt**.
5. At least the first combat turn begins.

If possible, include packet-aligned bridge/oracle state at the same time so the remaining ORACLE-strength certification fields can be promoted from FIELD/EVENT evidence without guessing.

## Revision-neutral compatibility hardening

During the final integration pass, registering both protocol manifests exposed an old compatibility assumption in the default spell-slot helper: it attempted to pick a single default adapter. R5.168 now resolves the compatibility mapping across all registered manifests and returns it only when they agree; otherwise it fails closed. The retained and new manifests currently agree on the two-row 22-slot UI mapping, so higher layers remain revision-neutral without silently choosing a protocol.

Follower-join execution/reducer diagnostics were also made protocol-neutral. Raw historical wire names remain confined to the historical adapter/evidence package; no new 3.6.12.16 wire name is allowed to become an execution-policy dependency.

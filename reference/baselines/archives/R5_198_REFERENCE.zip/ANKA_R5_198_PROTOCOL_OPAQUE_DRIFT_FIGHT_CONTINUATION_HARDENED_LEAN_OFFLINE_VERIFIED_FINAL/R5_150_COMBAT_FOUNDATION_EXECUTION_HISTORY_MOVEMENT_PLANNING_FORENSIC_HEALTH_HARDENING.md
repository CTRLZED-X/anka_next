# R5.150 — Combat Foundation: Execution History, Movement Planning & Forensic Health

## Objective

Make the combat platform stable enough that future work can concentrate on FightAI, TeamStrategy and tactical policy without re-opening synchronization, action ownership, movement execution or diagnostic plumbing on every strategy change.

## Runtime evidence used

`runtime(20261001-001631)` completed 5/5 fights. That successful run still exposed systemic inefficiencies: 8 turns contained multiple MOVE decisions (max 7), all five CRA first Ready interactions produced no outbound READY_REQUEST before a bounded second attempt, 30 decisions were safely rejected as stale combat frames, 107 effect-payload expansion anomalies and 26 lookahead truncations were recorded, and the old FightAI outcome export lacked fight-instance correlation.

## Root causes and repairs

### 1. Same-turn execution history was lost at the planner boundary

The controller knew a MOVE had been accepted, but a later planner slice rebuilt context without that confirmed movement. The neutral planner contract now carries `ConfirmedTurnExecutionHistory` containing only semantically confirmed current-turn actions. This state is orchestration truth and never mutates Canonical State. Future planners can be replaced while receiving the same stable history port.

### 2. Reachable MOVE candidates were biased nearest-first

TacticalPolicy sorted reachable cells nearest-first and then capped the list. A far legal destination could disappear even though the executor could reach it in one MOVE. The bound now samples deterministically across all distance bands. Execution itself was already correct: a regression locks one physical click on the selected final cell; intermediate path cells remain Kernel semantics only.

### 3. Safe post-slot CAST rejection was misclassified

A CAST may physically click the spell slot, prove no semantic cast request occurred, neutralize the UI and authorize quarantine/replan. That shape is now `SEMANTIC_REJECTED_SAFE` instead of generic FAILED. Physical uncertainty is still fenced.

### 4. Diagnostics were complete but difficult to consume

Large run-store streams were recursively embedded in `summary.json` and also exported as JSONL. R5.150 makes summary an index over external raw evidence and adds `analysis/foundation_health.json`. It reports Ready retry patterns, planned/confirmed movement fragmentation, stale-frame and team-convergence waits, planner latency/budget pressure, effect-payload growth, lookahead truncation and FightAI outcome correlation.

### 5. Stale decisions lacked an explanation

The stale safety gate previously exposed only changed fingerprints. `CombatFrameAssembler.semantic_drift_for_snapshots()` now compares the exact semantic payload used by the safety fingerprint and emits a bounded field-level delta. This is diagnostic only and cannot authorize input.

### 6. Ready retry needed causal labeling, not a guessed fix

The incident proves certain physical CRA clicks with no outbound Ready request, followed by successful bounded retries. It does not prove why. Ready actions now carry attempt/sequence/first-global-interaction evidence. The safe rule remains: activate on a separate tick, require stable foreground, click once, observe semantic evidence, and retry only when the request is proven absent.

### 7. Passive reconciliation history must use Canonical evidence, never lane-container state

The final regression review caught an R5.150-only implementation error before packaging: the new confirmed-action history attempted to obtain a revision from the tuple of required party lanes when a previously uncertain MOVE/CAST became reconciled. That would crash exactly on a recovery path. The repaired path uses the reconciliation's authoritative `canonical_revision` when available and otherwise the freshly captured required-lane snapshot revision. A permanent regression test covers this transition.

## Foundation contract for future FightAI work

A future GPT/developer may replace tactical policy, TeamStrategy or scoring while preserving these interfaces:

1. Read immutable Canonical/CombatDecisionFrame game truth.
2. Use the Kernel for legality/mechanics.
3. Read `ConfirmedTurnExecutionHistory` for commands already confirmed this turn.
4. Return typed FightDecision/PlannerResult only.
5. Never send input or infer success.
6. Let PartyCombatController own turn liveness/recovery/quarantine.
7. Let ExecutionService own physical input and settlement.
8. Use exported traces/outcomes/foundation health for strategy reverse-engineering.

This means policy experimentation should no longer require changes to input, synchronization or lifecycle code merely to remember prior movement or access forensic evidence.

## Intentionally unresolved / do not guess

- exact tackle/lock semantics;
- complete effect apply/refresh/stack/expire/remove lifecycle;
- universal enemy HP/AP/MP truth;
- summon capacity/lineage semantics;
- unverified target-zone mechanics;
- semantic meaning of unknown protocol messages without certification.

Repeated effect instances remain preserved because multiplicity can be semantically real until lifecycle authority is proven.

## Verification status

Offline candidate. Exactly 995 completed, non-overlapping tests passed in the final bounded verification groups used for this hardening pass; the current quick gate is 209/209 before manifest freeze. Aggregates that exceeded the environment timeout/transport window are explicitly not counted. Windows/Dofus live acceptance is PENDING.

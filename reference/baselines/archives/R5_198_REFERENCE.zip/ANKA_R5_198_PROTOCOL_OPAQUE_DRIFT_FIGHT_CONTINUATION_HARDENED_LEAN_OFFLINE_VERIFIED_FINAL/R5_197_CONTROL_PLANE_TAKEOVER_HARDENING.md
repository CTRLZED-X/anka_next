# ANKA R5.197 — Control-Plane Takeover Hardening

## Why R5.197 exists

The captured Windows startup package from 2026-10-16 showed a deterministic failure before a new server was spawned. Port 8000 was still owned by an older, healthy ANKA R5.195 control plane (PID 9236). R5.196 correctly classified the HTTP identity as a stale ANKA installation and selected `REPLACE`, but it skipped listener discovery because HTTP identity had succeeded. Windows CIM process metadata for PID 9236 was unavailable, so the termination safety gate had neither process-generation metadata nor listener correlation and refused takeover without actually invoking `taskkill`. The final status `STALE_REPLACE_FAILED` therefore described the outcome but hid the real reason: termination had not been authorized or attempted.

R5.197 repairs the ownership model rather than weakening it. It never turns replacement into “kill whatever owns port 8000.”

## Ownership and takeover contract

For the configured control-plane endpoint, Windows startup now gathers HTTP ANKA identity and actual LISTENING ownership independently. A stale control plane is replaceable only through one of two positive authorities:

1. **Process-generation authority** — PID plus creation time/path/command metadata identify the expected old ANKA process, with an immediate generation recheck before termination.
2. **Correlated HTTP/listener authority** — when Windows process metadata is unavailable, the recognized ANKA HTTP identity PID must equal the exclusive listening PID. HTTP identity and listener ownership are then re-read immediately before termination and must still agree.

A foreign listener, multiple/conflicting listener PIDs, HTTP/listener PID mismatch, changed schema-3 server instance, or unknown ownership remains fail-closed.

## Windows metadata degradation

CIM/WMI is no longer a single point of failure. If the primary metadata query fails, ANKA falls back to `Get-Process` for process generation/name/path/start time. If both metadata surfaces are unavailable, takeover can still proceed only through the double-checked HTTP+exclusive-listener authority above.

## Race convergence

Two starts can observe the same stale process concurrently. R5.197 re-observes after termination failure and after stale-process removal. If another start already removed the target, startup continues from FREE. If another current ANKA instance has already won the bind race, it is adopted. Unknown/foreign ownership still blocks. This prevents a harmless process-not-found race from becoming `STALE_REPLACE_FAILED`.

## Server generation identity

`/api/meta/server` identity schema is now 3 and carries a fresh `server_instance_id` plus `server_started_utc`. The instance token is generated once per server process and is checked when available during takeover revalidation. This provides a future process-generation signal independent of CIM without trusting stale disk state.

## Diagnostics

Startup ownership evidence now records listener PIDs even when HTTP identity succeeds, metadata-probe degradation, takeover authority, pre-kill rechecks, whether termination was actually attempted, taskkill return code/stdout/stderr, and post-termination ownership. The console surfaces takeover authority/status on failure. A future startup debug ZIP should therefore distinguish “not authorized,” “kill command failed,” “target already gone,” “foreign listener,” and “bind race won by another current ANKA instance.”

## Offline simulation

The zero-input systemic suite now includes stale-control-plane takeover authority. It proves matching ANKA HTTP/listener ownership can be authorized, mismatched/foreign ownership is rejected, and a schema-3 instance change fails closed. No physical keyboard or mouse input is emitted.

## Live boundary still pending

R5.197 is an offline-verified candidate only after the release gates pass. Windows acceptance is still required to prove the real stale R5.195/R5.196 process can be replaced under the user's host permissions and that the newly spawned/adopted server owns port 8000. The existing bounded CRA+ENU fight acceptance then remains the next gameplay boundary.

# R5.184 — Multi-Account Evidence Completeness Foundation

R5.184 is a focused certification-integrity release built on R5.183. It does **not** redesign Campaign, FightAI, Kernel, Canonical State, or physical execution. Its purpose is to make the next CRA+ENU Windows/Dofus live acceptance incapable of becoming green from partial, circular, malformed, misaligned, or transport-damaged evidence.

## Confirmed defects fixed

### 1. Partial multi-account replay could falsely certify

R5.183 reported undeclared selected-port Dofus flows but did not make them blocking. A two-flow CRA+ENU capture could therefore be declared as one account and still report `certified=true`.

R5.184 inventories **raw selected-port TCP flows before protocol decoding**. Any payload-bearing selected-port flow that is not declared in the evidence manifest blocks certification, including a flow whose Dofus framing/decoding fails. A decoder failure can no longer hide an undeclared client lane.

### 2. ORACLE proof could be aggregate instead of per controlled lane

R5.183 validated oracle provenance and member identity, but a field match from one declared account could satisfy aggregate proof. R5.184 requires a unique `oracle_member_id` for every declared controlled account and evaluates proof per account. CRA can never satisfy ENU's proof and vice versa.

### 3. Static values could satisfy transition-based live-truth contracts

The live-truth contract requires behavioral evidence, not lucky static equality. R5.184 enforces the promised transitions:

- World MapId: at least two distinct independently matched MapIds per declared account.
- Local ActorId: independently matched actor identity per declared account.
- Actor CellId: independently matched local movement **and** movement/displacement of at least one separately identified non-local actor per declared account.
- AP: independently matched owned-turn sequence showing AP loss and a later recovery/reset per declared account.
- MP: independently matched owned-turn sequence showing MP loss and a later recovery/reset per declared account.

One static matching snapshot cannot promote these transition-based truths to ORACLE strength.

### 4. Oracle field types were too permissive

Python truthiness/coercion could let malformed JSON such as `"is_my_turn": "false"` behave like a true boolean. R5.184 requires actual JSON booleans/integers for certification fields and rejects malformed packet indexes, actor rows and duplicate actor identities.

### 5. Evidence JSON could be ambiguous

Certification JSON now rejects duplicate object keys, non-finite numeric constants and unknown manifest/schema keys. Proof artifacts no longer use permissive “last value wins” parsing.

### 6. Same-packet wire messages could overwrite one another

The replay assertion index previously stored a single decoded message per `(account, packet)` key. R5.184 stores all same-packet messages and evaluates assertions against the correct binding/value candidate.

### 7. PCAPNG packet indexes could drift from capture-wide frame numbers

Unsupported interfaces/link types and some packet-block forms did not always advance the packet counter. Later Dofus packets could therefore receive indexes smaller than the real capture frame number, breaking independent oracle alignment.

R5.184 advances the capture-wide packet index for every packet record and supports/validates Enhanced Packet Blocks, Simple Packet Blocks and legacy Packet Blocks. Interface IDs reset per Section Header Block, including multi-section and mixed-endian captures. Undefined interfaces, malformed/truncated blocks and invalid captured/original lengths fail closed.

### 8. Offline replay did not carry live framing health into certification

The live capture runtime already tracks transport/framing health, but offline evidence replay discarded important diagnostics. R5.184 exposes replay transport diagnostics and blocks certification on dropped framing bytes or unresolved TCP reassembly gaps. A corrupted/mid-gap capture cannot silently resynchronize and certify.

### 9. Release-gate resume evidence did not bind every production artifact

The bounded verifier's surface digest previously omitted several production/release inputs. R5.184 binds resumed PASS rows to source/tests/tools **and** operational scripts, missions, profiles, Unity bridge sources, docs/reference assets and game/static data. Changing one of those artifacts invalidates previously checkpointed PASS evidence.


### 10. Certification could ignore selected transport it cannot reproduce

Offline replay and the live Scapy edge now agree on the supported production transport boundary. Packet-bearing unsupported PCAPNG link types fail closed. Selected-port IPv6 TCP is rejected explicitly because the current live runtime only consumes IPv4 `IP/TCP`; it can no longer disappear from offline completeness checks or live backend health. Selected-port fragmented IPv4 TCP is also rejected because byte-exact production-equivalent reassembly is not implemented for IP fragments.

Windows/Npcap transmit-offload artifacts with IPv4 `total_length=0` are handled conservatively from the captured bytes after the packet is identified as selected traffic, so unrelated host-offload traffic does not create a false failure.

### 11. Initial stream acquisition and established framing loss were conflated

Attaching to an already-open Dofus TCP connection can legitimately begin in the middle of a protocol frame. Framing bytes discarded **before the first valid Ankama envelope** are now recorded as `frame_acquisition_dropped_bytes` but do not permanently poison runtime health. Once a flow establishes valid semantic framing, its drop baseline freezes and any later framing loss contributes to `frame_safety_dropped_bytes` / top-level `dropped_frame_bytes` and remains fail-closed for execution.

### 12. Terminal capture observations were over-classified as corruption

A bounded PCAP can stop while the next protocol frame is incomplete, and retained real captures also contain complete transport frames that are not Ankama Any envelopes. `framing_buffered_bytes` at EOF and `empty_envelope_frames` remain explicit diagnostics, but they are not global blockers by themselves. Actual framing byte loss and unresolved TCP reassembly gaps remain blocking.

### 13. ORACLE JSON strictness now covers every nested row

ORACLE `snapshot_id` and `member_id` must be actual JSON strings. Unknown keys are rejected at the record, `received`, `snapshot`, `self`, and actor-row levels. Numeric/string coercion or misspelled fields can no longer silently turn into misleading sparse-evidence results.

### 14. A second controlled connection cannot hide before payload

Raw selected-port completeness now treats an undeclared SYN as evidence of a new selected connection even when no payload has arrived yet. An old FIN/RST-only tail does not by itself create a new-lane claim, but a new connection or payload-bearing flow must be explicitly mapped.

## Preserved boundaries

R5.184 preserves R5.182 durable input preparation, restart fencing, diagnostic Canonical-source integrity and stuck-owner behavior, plus R5.183 independent-oracle provenance and evidence-package classification. Canonical State remains semantic truth, Projection remains geometry/UI evidence, and protocol-specific wire semantics remain inside the versioned adapter.

## Remaining limitation

Offline verification cannot prove the actual user Windows environment, bridge load, Dofus client compatibility, process/flow ownership or the five remaining independent MapId / ActorId / CellId / AP / MP truths. The next step remains a small evidence-producing CRA+ENU Windows acceptance, not a long unattended run.

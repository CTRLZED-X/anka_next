> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# Current workspace — R5.198 Protocol Opaque Drift / Fight Continuation Hardening

Start with `docs/CURRENT.md`, `00_NEW_CHAT_HANDOFF_R5_198.md`, `R5_198_PROTOCOL_OPAQUE_DRIFT_FIGHT_CONTINUATION_HARDENING.md`, `PROJECT_STATUS.json`, and `LIVE_ACCEPTANCE.md`.

R5.198 inherits R5.197 safe Windows control-plane takeover and R5.196 turn-readiness/multi-account simulation. It repairs the captured combat stop after CRA's first successfully settled spell by admitting only exact observed `icl`/`icw` opaque fingerprints with zero Canonical mutation. Changed variants remain fail-closed. Windows/Dofus continuation acceptance remains pending.

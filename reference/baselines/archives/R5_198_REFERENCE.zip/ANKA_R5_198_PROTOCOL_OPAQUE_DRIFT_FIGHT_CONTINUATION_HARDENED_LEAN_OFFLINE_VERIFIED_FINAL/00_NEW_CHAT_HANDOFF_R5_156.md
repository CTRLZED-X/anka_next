# NEW CHAT HANDOFF — R5.156

## Current objective

R5.156 adds a permanent post-protocol-update certification boundary. Future Dofus protocol work should be performed from PCAP/context evidence inside the versioned protocol layer, then certified with `verify_live_decoding.bat` before any normal live mission is used as a decoder test.

## First command after protocol integration

```bat
verify_live_decoding.bat <evidence-folder> [more-evidence-folders...]
```

Read `runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json` first when status is not READY. That file is GPT-oriented. Do not infer missing packet semantics from the human report.

## Non-negotiable rules

- Fresh build proof comes only from fresh supplied evidence; old evidence is regression-only.
- Do not accept guarded-version compatibility as exact-build certification.
- Do not use raw Dofus message names/protobuf layouts outside `anka_platform.protocol`.
- Do not treat event presence as field correctness; respect FIELD/ORACLE/CAUSAL proof levels.
- Do not implement `NOT_EVIDENCED` semantics from guesses. Follow the capture recipe.
- Do not make a downstream FightAI/execution patch when the first failing boundary is protocol/canonical truth.
- Re-run certification after every decoder/profile/contract change. Certificate hash must match the final code/evidence subject.

## New architecture

`ProtocolWireProfile` owns CAST/MOVE/END_TURN/WORLD_ATTACK/JOIN_FIGHT/READY raw identities and fields. Execution consumes only `ProtocolWireSemantic`.

`current_project_live_truth_contract()` represents the union of live truths needed by the current world, lifecycle, combat, FightAI, admission, settlement and recovery layers.

Versioned `LIVE_DECODING_EVIDENCE.json` provides exact client build and out-of-band account-flow identity, optional packet-aligned bridge oracles and controlled outbound request assertions.

The certification engine performs production-chain replay, historical regression hash validation, current-build proof isolation, canonical field/oracle checks, controlled wire causality checks, architecture isolation audit, exact build certification and GPT diagnosis.

## Current baseline

The retained R5.155 evidence produces `BLOCKED`, not a manufactured READY. Current gaps are authoritative `ERODED_HP`, field-level proof for `FIGHT_IDENTITY`, and retained evidence for `STATES`. See the generated GPT debug for machine-oriented details.

## Where to read

1. `R5_156_LIVE_DECODING_CERTIFICATION.md`
2. `docs/architecture/live_decoding_certification.md`
3. `runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json`
4. `src/anka_platform/protocol/live_truth_contract.py`
5. `src/anka_platform/protocol/wire_semantics.py`
6. `tools/verify_live_decoding.py`

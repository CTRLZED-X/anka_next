# NEW CHAT HANDOFF — R5.157

## Current objective

R5.157 makes live-decoding certification protocol-independent and exhaustive over the current Canonical Contract. Future protocol work should change the versioned adapter/wire profile from evidence, not downstream behavior, then prove the exact build against the stable Live Decoding Reference.

## First command after protocol integration

```bat
verify_live_decoding.bat <evidence-folder> [more-evidence-folders...]
```

When status is not `READY`, read `runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json` first. It is designed for GPT, not for the operator.

## Authorities

1. `docs/reference/LIVE_DECODING_REFERENCE_V1.json` — protocol-independent reference snapshot.
2. `src/anka_platform/protocol/live_decoding_reference.py` — source authority for that snapshot.
3. `src/anka_platform/protocol/live_truth_contract.py` — downstream proof requirements.
4. `docs/architecture/live_decoding_certification.md` — certification architecture.
5. `R5_157_PROTOCOL_INDEPENDENT_LIVE_DECODING_REFERENCE.md` — release delta.

## Non-negotiable rules

- Fresh build semantics are proven only by fresh exact-build evidence; historical evidence is regression-only.
- Every REQUIRED canonical reference event must be observed and every decision-critical field must be proven KNOWN before READY.
- Controlled canonical assertions must match expected values when declared; populated-but-wrong fields are failures.
- All 24 protocol capabilities and all 6 stable outbound wire semantics remain inside the blocking reference.
- Raw Dofus names/field layouts remain behind the protocol boundary.
- Do not implement `NOT_EVIDENCED` semantics from guesses; use the capture recipe.
- A new canonical event/capability/wire semantic requires an explicit reference update/version decision; silent omission is a verifier defect.
- Percentage never overrides a blocker.

## Current baseline

The retained evidence is intentionally non-READY because it predates the stronger R5.157 field/value proof model. This is expected. Build a golden current-protocol corpus with controlled scenarios rather than weakening the verifier to make old evidence green.

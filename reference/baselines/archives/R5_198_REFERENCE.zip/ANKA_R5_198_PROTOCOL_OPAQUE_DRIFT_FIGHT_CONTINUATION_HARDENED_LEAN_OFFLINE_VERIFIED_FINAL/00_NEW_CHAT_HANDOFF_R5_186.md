# ANKA R5.186 — New Chat Handoff

**Current release:** R5.186 — Entity Resolution, Control Atomicity & Diagnostic Causality Foundation  
**Protocol adapter:** `dofus_3_6_12_16` unchanged.  
**Offline verification:** VERIFIED.  
**Windows/Dofus live acceptance:** PENDING.

Read `PROJECT_STATUS.json`, `R5_186_ENTITY_RESOLUTION_CONTROL_DIAGNOSTIC_CAUSALITY_FOUNDATION.md`, `verification/R5_186_OFFLINE_VERIFICATION.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, and `WINDOWS_LIVE_RUNBOOK.md`.

## Live incident that triggered R5.186

R5.185 fixed the first-tick startup failure: CRA and ENU both performed the RIGHT bootstrap map transition and established authoritative MapId. World target acquisition then failed because the Unity resolver correctly found roots such as `/entities/Entity -20002` but refined them upward to the shared `/entities` ancestor at `(0,0)`, which mapped to CellId 328. Canonical State had the correct group cells (for example 415 and 151), so Execution safely refused to click. The same mismatch repeated until mission timeout.

## R5.186 invariants

- Entity interaction anchors are exact entity roots or descendants, never shared ancestors. Current-build roots named `Entity <signed-id>` are supported for monsters and players, with one exact-name scene scan per resolution pass.
- Fight-entry projection uses the verified 560-cell runtime grid rather than requiring literal `cell::<id>` GameObjects, and actor roots cannot be selected as join targets.
- Canonical EntityId/CellId plus nearest runtime-grid CellId agreement remains mandatory.
- Repeated all-target projection mismatch is bounded and terminal with precise ownership; no blind minute-long loop.
- Control Authority is run-bound before worker process start.
- Input-free focus failure may recover only with unchanged client identity.
- Current incident discovery authority requires process + map/coordinate generation match.
- Recovered transient failures cannot hide the later terminal root, and precise lower-layer roots are never overwritten by generic campaign wrappers.
- Normal account switching remains HWND/PID-owned; AutoHotkey is optional legacy fallback only.
- Protocol decoding and FightAI were not changed for this incident.

## Next action

Perform one bounded R5.186 CRA+ENU live run from a fresh extraction. `setup.bat` must install bridge plugin 2.2.76 / projection authority `ENTITY_SUBTREE_RUNTIME_GRID_V3`. Preserve the entire runtime/debug package whether the run succeeds or fails.

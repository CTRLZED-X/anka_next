# ANKA R5.196 — Turn Handoff + Systemic Simulation Hardening

**Status:** OFFLINE_VERIFIED candidate; bounded Windows/Dofus live acceptance remains pending for external behavior that cannot be proven offline.

## Why R5.196 exists

The 2026-10-16 CRA+ENU runtime reached the same fight, completed placement/Ready, entered ACTIVE combat, and identified CRA as the authoritative first-turn owner. It then stalled before any combat action because R5.195 required AP and MP observations strictly newer than `TURN_STARTED`. The server had already supplied valid unchanged AP/MP immediately before turn-start and did not redundantly emit them afterward, so the safety check could never become ready. FightAI repeatedly planned the same captured frame until the campaign failed.

R5.196 fixes the causal model instead of relaxing settlement safety. Every accepted semantic turn now freezes its own resource freshness floor: `FIGHT_ACTIVE` for the first turn, the immediately preceding authoritative `TURN_ENDED` for a proven handoff, and the current `TURN_STARTED` itself when a handoff boundary is missing. Post-action CAST/MOVE settlement stays strict.

## Root causes repaired

1. Turn-start AP/MP freshness was tied to packet order rather than the semantic handoff window.
2. Repeated FightAI invocation happened before a readiness condition that execution was guaranteed to reject.
3. A later actor could have reused an old global TURN_ENDED watermark after a missing handoff event.
4. A delayed duplicate TURN_STARTED could reopen an already-ended turn.
5. Preflight compared Unity's resolved geometry map to the semantic fight MapId even though R5.195 intentionally separated those authorities.
6. Incident protocol previews were bounded and could be truncated, but offline replay treated those previews as complete protobuf bytes.
7. Incident evidence accounting could under-report canonical evidence stored in per-account journals.
8. Script-level incident terminalization could hide a registered lower-layer root code under generic `SCRIPT_TERMINAL_FAILURE`.
9. The runtime client build is 3.7.11.11 while the certified active adapter remains 3.7.10.10; positive observed semantics replay cleanly, but exact-build negative-absence claims remain fail-closed.

## Turn-readiness contract

- First turn: unchanged AP/MP may be used only when observed after the exact fight ACTIVE boundary.
- Proven handoff: unchanged AP/MP may be used only when observed after the immediately preceding TURN_ENDED.
- Missing TURN_ENDED / uncertain transition: the new turn becomes `POST_TURN_STRICT` and requires fresh resources after the current TURN_STARTED.
- Duplicate observation of the same semantic turn never moves the resource floor forward.
- A delayed duplicate of an already-ended turn cannot reopen it.
- A short stability probe confirms the same readiness evidence on a second poll before planning when the accepted baseline precedes TURN_STARTED; unrelated canonical revisions do not reset the probe.
- Readiness is checked before window activation and before FightAI, so a synchronization wait emits no input and does not repeatedly plan the same frame.

## Exact incident replay

R5.196 distinguishes two evidence classes:

- `protocol_window.jsonl`: bounded forensic previews, which may be truncated;
- `capture/raw_capture.pcapng`: full raw capture, when embedded.

For `runtime(20261016-152128).zip` the embedded PCAP replays through the production-equivalent TCP reassembler/framer and the active protocol adapter with:

- 439 decoded gameplay messages;
- CRA mapped flow: 226 messages, 0 unclassified, 0 transform/reducer failures, 0 dropped/buffered/pending bytes;
- ENU mapped flow: 213 messages, 0 unclassified, 0 transform/reducer failures, 0 dropped/buffered/pending bytes;
- unrelated port-6337 framing residue reported separately and not attributed to either gameplay lane;
- the clipped 4-KiB `juo` journal previews explicitly retained as `PARTIAL` window fidelity rather than parsed as complete messages;
- account canonical journals used only to reconstruct the exact live revision timeline when needed.

The captured CRA failure frame is canonical revision 979. AP/MP were observed at revision 959 and fight ACTIVE began at revision 428. R5.196 evaluates that exact captured frame as READY under `FIGHT_ACTIVE_WINDOW`, directly proving the original deadlock repair.

## Zero-input live-environment simulator

R5.196 adds a permanent systemic suite plus `simulate_live.bat`. The suite emits no physical mouse/keyboard input and currently covers:

1. captured runtime/incident replay;
2. valid first-turn pre-TURN_STARTED AP/MP ordering;
3. stale pre-ACTIVE resources rejected;
4. two-account CRA→ENU convergence and handoff;
5. missing TURN_ENDED fails closed;
6. delayed duplicate TURN_STARTED ignored;
7. bounded turn-start synchronization stall with no planner/input;
8. strict post-action resource settlement;
9. semantic-vs-geometry Projection preflight;
10. runtime health fence/recovery;
11. protocol-version drift negative-evidence safety;
12. full zero-input CRA action → handoff → ENU action → fight end → world re-entry lifecycle;
13. reducer world re-entry after fight end.

Use:

```text
simulate_live.bat
simulate_live.bat "C:\path\to\runtime.zip"
```

The second form first replays the supplied incident/runtime evidence and then runs the synthetic systemic scenarios.

## What simulation cannot replace

The simulator can repeatedly exercise captured protocol bytes, Canonical transitions, multi-account convergence, geometry, Kernel/FightAI/admission logic, recovery rules, and synthetic execution state machines. It cannot invent server packets never captured, prove Unity rendered an unseen state, prove HWND/focus behavior, or prove Windows/Dofus accepted a real mouse event. Those boundaries still require a bounded live run once; after capture, their deterministic evidence becomes reusable regression input.

## Next live boundary

R5.196 is intended for one bounded CRA+ENU acceptance run starting from the now-repaired first live ACTIVE turn. The primary external proof still needed is real combat action delivery/semantic settlement and subsequent real turn handoff under the 3.7.11.11 client. If a new live-only boundary fails, the resulting runtime ZIP should be replayed through `simulate_live.bat` before any new patch cycle.

## Bounded full-gate execution verification

The R5.196 full verification gate no longer runs the entire `tests/execution` directory as one indivisible pytest process. Every execution test module is an explicit gate target. This preserves complete execution coverage while making timeout isolation, checkpoint/resume, and root-cause localization deterministic; one slow or environment-sensitive module can no longer hide the status of the rest of execution verification.

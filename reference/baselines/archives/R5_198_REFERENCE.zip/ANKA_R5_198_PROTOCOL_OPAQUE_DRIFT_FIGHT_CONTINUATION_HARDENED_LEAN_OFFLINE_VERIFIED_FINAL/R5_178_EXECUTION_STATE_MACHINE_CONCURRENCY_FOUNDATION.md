# R5.178 — Execution State-Machine & Concurrency Foundation

R5.178 is a behavior-preserving execution/concurrency hardening release over R5.177. It does not transfer
physical-input authority, relax Canonical State/Kernel/admission gates, or change FightAI policy.

The release separates complete per-account operation sequencing from mutable execution-state locking.
`ExecutionLifecycleGate` serializes an account operation through post-result control/diagnostic processing;
`ExecutionService._lock` remains the narrow mutable-state lock; the shared `InputArbiter` remains the
cross-account physical UI authority. Result observability therefore no longer participates in the mutable
execution lock order, while a later action still cannot overtake a critical result before control fencing.

Runtime operation dispatch is now described by immutable `RuntimeOperationSpec` contracts instead of a
large public dispatch branch. An input-free `ExecutionOperationTracker` exposes lifecycle phase and an
atomic arbiter snapshot, allowing Diagnostics V2 to identify in-flight execution/lock contention even when
no final action result has yet been committed.

See `docs/architecture/EXECUTION_STATE_MACHINE.md` and `docs/architecture/CONCURRENCY_OWNERSHIP.md`.

Windows/Dofus live acceptance remains pending.

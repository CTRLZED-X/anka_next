# ANKA Platform R5.139 — Cast Transaction, UI Neutrality & Protocol Negative-Evidence Hardening

Checkpoint: `ANKA_PLATFORM_R5_139_CAST_TRANSACTION_UI_NEUTRALITY_PROTOCOL_NEGATIVE_EVIDENCE_HARDENING_WINDOWS_LIVE_CANDIDATE`

Status: **OFFLINE VERIFIED CANDIDATE**. Windows/Dofus live acceptance remains **PENDING**.

## Why R5.139 exists

R5.138 repaired the two failures proven by `runtime(20260926-130218)`: generic directional FORK geometry and semantic target-actor integrity. A pre-live systemic audit then found four contract gaps that could still create a misleading or unsafe real-client CAST sequence even when R5.138 legality was correct:

1. after a spell-slot click, a PRE_TARGET abort could replan without proving the Dofus UI had left spell-targeting mode;
2. the click projection used for the semantic target was resolved before PRE_SLOT and could therefore be stale after PRE_TARGET authorization;
3. absence of outbound `jrj` could be interpreted as client-local rejection without proving that the observed Dofus build was certified for that negative semantic contract;
4. standalone `live_preflight.bat` did not consume authoritative execution `launch_blockers`, so it could report READY while the actual Launch gate would refuse control.

These were found by source/contract inspection before the next live run. They are not asserted as observed Dofus failures.

## Systemic repair

### 1. CAST is now an explicit multi-phase physical transaction

The physical path is:

```text
neutral UI
  -> target preflight projection (no input)
  -> PRE_SLOT latest-state admission
  -> SPELL_SLOT_CLICK
  -> PRE_TARGET latest-state semantic admission
  -> fresh SPELL_TARGET_CLICK projection
  -> exact authorization-revision recheck
  -> SPELL_TARGET_CLICK
  -> semantic/server settlement
  -> terminal state
```

A projection acquired before slot selection is only a preflight safety check. It is never reused as the semantic target click.

### 2. Every post-slot safe abort must prove UI neutrality

Once `SPELL_SLOT_CLICK` is sent, any safe abort before semantic target input must send `ESC` to the same foreground-bound Dofus window and prove the cancel input was sent. This covers PRE_TARGET rejection/UNKNOWN, fight/turn change, projection failure/staleness, and proven client-local cast rejection.

If neutralization cannot be sent with certainty, the action becomes `UNCERTAIN` and the durable execution fence remains fail-closed. The controller may not silently replan into MOVE/another CAST while spell-selection state is unknown.

### 3. Fresh projection is bound to PRE_TARGET authorization

After PRE_TARGET admission succeeds, ANKA resolves `SPELL_TARGET_CLICK` again. Before target input, the Canonical revision must still equal the revision authorized by PRE_TARGET. Any advancement invalidates the click, neutralizes the selected spell, and replans.

### 4. Negative semantic evidence is exact-build qualified

`CLIENT_CAST_REJECTED` may use absence of outbound `jrj` only when the observed client build is explicitly certified for that message semantic. R5.139 currently certifies the known `dofus_3_6_10_10` adapter only for observed client version `3.6.10.10` and message `jrj`.

Observed newer builds such as `3.6.12.16` remain **UNCERTAIN** for negative absence unless a separate compatibility contract certifies them. Positive semantic/server evidence remains usable; only the stronger negative inference is build-gated.

### 5. Physical-input diagnostics expose CAST phases

`analysis/physical_input_ledger.jsonl` expands a CAST transaction into phase rows when phase evidence is available:

- `SPELL_SLOT_CLICK`
- `SPELL_TARGET_CLICK`
- `UI_NEUTRALIZE`

Rows preserve send state, target/projection coordinates where applicable, reason, map revision and runtime generation. This allows one runtime package to answer whether a spell was still selected before a later physical click.

### 6. Standalone live preflight mirrors launch safety

`assess_party_preflight_payload()` now consumes account-scoped `launch_blockers`. `live_preflight.bat` therefore cannot report `READY_FOR_CONTROLLED_LIVE_TEST` when unresolved execution uncertainty would make the authoritative ApplicationService launch gate reject the session.

## Invariants

- `ExecutionService` remains the sole physical-input authority.
- No semantic target click may reuse the pre-slot preflight projection.
- After slot selection, no safe replan is allowed until UI-neutralization is positively sent; otherwise execution is UNCERTAIN/fenced.
- PRE_TARGET authorization and the actual target click must share the same Canonical revision.
- Negative absence of a protocol message can prove client-local rejection only for an explicitly certified observed client build/message contract.
- Newer observed client builds may not inherit an older adapter's negative absence semantics by assumption.
- Positive server/canonical evidence remains stronger than negative inference.
- R5.138 semantic target-actor admission, generic FORK geometry, enemy-benefit blocker and move-reversal guard remain preserved.

## Regression coverage

`tests/r5139/` directly proves:

- fresh post-PRE_TARGET projection is the point physically clicked;
- Canonical advancement after projection aborts and neutralizes before replan;
- observed `3.6.12.16` cannot convert absent `jrj` into certified client rejection;
- authoritative `launch_blockers` make standalone live preflight not-ready;
- safe post-slot PRE_TARGET UNKNOWN replans rather than same-revision retry/stall;
- CAST physical ledger exposes slot, target and neutralization phases;
- the bound Windows input driver can issue ESC and report the observed client build.

Inherited R5.135–R5.138 and execution/party/core-fight/protocol/live-state/projection/observability gates remain mandatory.

## Live acceptance still required

Offline verification cannot prove the real Dofus UI-selection semantics, projection/calibration, client timing, packet behavior or Windows focus timing. Use a fresh extracted R5.139 package and stop at the first autonomous failure. Do not manually join, Ready, move, cast or repair the run before exporting diagnostics.

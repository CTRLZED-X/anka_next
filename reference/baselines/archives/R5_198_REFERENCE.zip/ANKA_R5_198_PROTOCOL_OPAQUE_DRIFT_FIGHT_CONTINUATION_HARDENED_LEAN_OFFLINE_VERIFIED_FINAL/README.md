> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# ANKA Platform — R5.198

**Current candidate:** R5.198 — Protocol Opaque Drift / Fight Continuation Hardening. Offline verification is the release gate; Windows/Dofus live acceptance remains pending.

- platform: `0.1.0a146`
- active protocol: `dofus_3_7_10_10`
- package profile: lean runtime, no raw protocol evidence
- normal Windows setup: non-editable runtime install
- local live-environment simulation: `simulate_live.bat`

## Normal Windows use

1. Run `setup.bat` as the one-time setup for a fresh extraction or after source/protocol changes. Close Dofus before setup.
2. Run `start.bat` for normal use. It opens Script Studio, and ANKA automatically discovers Dofus clients without fixed character names.

## Current focus

The captured R5.197 fight entered successfully and CRA's first CAST settled authoritatively. The stop happened afterward because newly observed opaque server wires (`icl`, `icw`) were not yet catalogued and correctly triggered the generic fail-closed `PROTOCOL_UNCLASSIFIED_ACTIVE` health fence.

R5.198 repairs that boundary without weakening protocol safety: only the exact observed direction + payload size + SHA-256 fingerprints are admitted as zero-event opaque traffic; any changed variant remains unclassified and blocks. Raw PCAP proves decoder behavior, while durable account Canonical journals independently reconstruct exact live revisions for incident reassessment.

R5.197 safe control-plane takeover and R5.196 turn/handoff systemic simulation remain inherited. Read `docs/CURRENT.md` and `00_NEW_CHAT_HANDOFF_R5_198.md` first.

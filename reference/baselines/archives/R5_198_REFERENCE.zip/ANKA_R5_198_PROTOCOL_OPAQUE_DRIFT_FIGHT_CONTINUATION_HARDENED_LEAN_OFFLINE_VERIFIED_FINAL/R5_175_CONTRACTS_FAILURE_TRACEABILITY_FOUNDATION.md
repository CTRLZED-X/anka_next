# R5.175 — Contracts, Failure Authority & Traceability Foundation

## Why this release exists

R5.174 fixed the repeated pre-worker startup deadlock by centralizing startup blocker semantics.  A deeper
project audit showed that the same structural risk still existed at project scale: failure codes, retry rules,
control disposition, attribution and diagnostic interpretation were spread across several components; protocol
transform errors still had string-based compatibility paths; correlation data was commonly mutable/untyped;
and incident export could lose the first causal evidence if the heavy exporter itself failed.

R5.175 strengthens those foundations without performing a high-risk rewrite of fight/execution behavior.

## 1. Project-wide failure authority

`anka_platform.contracts.failure_registry` is the explicit failure vocabulary and metadata authority.  The
observability `FailureCode` contract is derived from it; control retry/fencing and diagnostic attribution consume
it; and the architecture verifier scans production AST for literal failure emitters that are not registered.
Unknown future failures therefore cannot silently acquire accidental retry/control semantics.

## 2. Immutable correlation context

`CorrelationContext` provides stable session/run/request/operation/account/runtime-generation identity across
control and execution boundaries.  Existing mappings remain accepted during incremental migration, but authority
identity is normalized into one immutable contract before use.

## 3. Protocol Adapter SDK foundation

Protocol transform failures now carry typed category/capability/wire-semantic/adapter metadata.  The active
versioned adapter dispatches through a reusable `ProtocolHandlerRegistry`, creating a stable seam for later
capability-module decomposition.  Higher layers still consume canonical events/state and no raw protocol names
are introduced above the adapter boundary.

## 4. Diagnostics V2 foundation

Incident handling synchronously writes a minimal crash envelope before asynchronous ZIP export.  The envelope
contains correlation/control/failure-contract evidence needed to identify the first broken boundary even if the
heavy exporter later fails.  Debug bundles now include the failure-registry snapshot and a diagnostic-section
manifest whose completeness states distinguish COMPLETE, MISSING, ERROR and NOT_APPLICABLE.

## 5. Concurrency/fault isolation

Incident records are copied before publication to shared state, eliminating a race where readers could observe a
partially mutated record while control fencing completed.  Crash-envelope temporary files are incident-unique.
The project now documents mutable-state/concurrency ownership and required race scenarios explicitly.

## 6. Reproducibility evidence

Each runtime debug context carries an environment fingerprint (Python/runtime/platform and important package
versions).  This does not yet replace a fully locked Windows dependency environment; it gives future incidents a
reproducible dependency fingerprint and establishes the boundary for the later lockfile/release milestone.

## 7. Hidden robustness fixes

Slot-based protocol diagnostic dataclasses are serialized through explicit `to_dict()`/dataclass-aware paths
instead of relying on `.__dict__`, avoiding failures precisely when replay/dashboard diagnostics are needed.

## Deliberately deferred

R5.175 does not rewrite the ~7k-line ExecutionService, the large tactical policy, or CanonicalStateReducer.  Those
components first need characterization/decomposition slices behind the strengthened contracts.  The active
protocol adapter is not yet fully split into capability files; R5.175 supplies the handler/typed-error SDK seam for
that work.

## Live acceptance

Windows/Dofus live acceptance remains pending.  R5.175 is intended to make the next failure—if any—more isolated,
traceable and reproducible while preserving R5.174 startup authority and all existing physical-input fences.

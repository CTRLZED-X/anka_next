# ANKA R5.164 — Fight Lifecycle, Pointer Trajectory & Forensic Hardening

## Why this release exists

R5.164 is driven by `runtime(20261004-200708).zip` plus the user-supplied `TrajectoryLab_v2` reference.

The live mission did **not** stop because the configured five-win target was misread. The authoritative campaign budget ended with `wins=4`, `attempts=4`, `target_wins=5`, `max_attempts=10`, and every one of the four committed wins returned `CONTINUE`. The run stopped later because the parent campaign remained in `LAUNCHING_FIGHT` until `MISSION_TIMEOUT`.

The causal chain was:

1. Fight `327` ended after the fourth confirmed win.
2. CRA's final End Turn had been physically sent, but its same-fight turn-transition evidence had not settled before terminal fight disappearance.
3. The durable `COMBAT_END_TURN` uncertainty fence survived the fight boundary.
4. The first post-fight WORLD action saw that old combat fence as generic `ACTION_UNCERTAIN_FENCE`.
5. Incident handling revoked process-wide physical control.
6. Later world-launch calls were correctly denied as `CONTROL_AUTHORITY_DISARMED`, but R5.163 treated those consequence denials as temporary acquisition blockers and kept polling until the campaign watchdog surfaced the less useful `MISSION_TIMEOUT`.

This is a lifecycle/authority bug, not an off-by-one counter and not a FightAI strategy failure.

## Systemic lifecycle repairs

- `ExecutionService` passively reconciles structured MOVE/CAST/END_TURN combat uncertainty before interpreting a durable fence as a generic unsafe condition.
- Terminal fight disappearance is explicit evidence that generation-scoped End Turn/CAST/MOVE uncertainty may be retired without any physical retry.
- `CONFIRMED_UNSETTLED` fight movement/cast AP/MP obligations are also retired after authoritative fight exit, preventing a resource-settlement fence from poisoning world re-entry or a later campaign.
- `PartyMissionController.reconcile_post_fight_execution_safety()` sweeps every required account before world re-entry. It is input-free and fail-closed for generic/non-reconcilable safety state.
- `CampaignRuntimeController` owns a dedicated `POST_FIGHT_EXECUTION_SAFETY` phase before WORLD input after a committed CONTINUE outcome.
- Session-end and next-campaign preflight also reconcile terminal fight-scoped safety, covering the final target win where there is intentionally no world re-entry step.
- `CONTROL_AUTHORITY_DISARMED` is terminal at campaign disposition, so a physically impossible campaign does not poll until a watchdog timeout.
- At the incident layer, an already-disarmed control result is observe-only: it cannot recursively disarm the same lease and overwrite/flood the original causal revocation evidence.
- `ControlAuthorityStore` preserves `disarm_root_event`, `last_disarm_event`, and `first_denial_after_disarm` outside the bounded authorization-history ring.
- `RunBudget` validates that win/loss/unknown/aborted counters are non-negative, sum exactly to `attempts`, and cannot exceed the configured win target.

## Fight accounting diagnostics

`CampaignRuntimeController` now keeps a compact authoritative `fight_outcome_history` separate from high-frequency recent polling. This prevents repeated acquisition/settlement rows from evicting the actual mission history.

New debug analysis `analysis/campaign_progress_health.json` exposes:

- confirmed wins and configured target;
- attempts/max attempts and next attempt ordinal;
- each committed fight instance and ordinal;
- WIN/LOSS/UNKNOWN/ABORTED outcome;
- CONTINUE/STOP decision and stop reason;
- post-fight world re-entry requirement;
- lifecycle phase and terminal failure.

The R5.163 incident would therefore say explicitly: **4/5 confirmed wins, target not reached, next attempt 5, continuation expected**, followed by the true execution/control failure.

## Pointer-motion inspection and TrajectoryLab integration

The R5.163 pointer system already had important safety strengths: exact endpoint arrival, minimum-jerk forward progression, bounded maximum step, late correction, semantic re-admission, input-interference detection, and safe endpoint variation restricted to caller-certified points.

The live R5.163 evidence nevertheless showed timing that was too aggressive for deliberate human pointing: many 400–580 px motions completed around 90–160 ms, and unique-coordinate delivery frequently approached roughly 280–330 Hz. Geometry looked smooth, but speed/density was mechanically brisk.

R5.164 retains the safe minimum-jerk along-chord progression and integrates the useful **shape concepts** from `TrajectoryLab_v2`:

- correlated low-frequency lateral knots rather than one simple arc;
- several smooth lateral direction changes on medium/long motions;
- a tiny tapered micro-wobble generated coherently, not independent frame noise;
- endpoint tapering and exact final coordinate;
- a bounded late corrective submovement.

The browser lab's forward jitter is deliberately **not** copied because ANKA's monotonic minimum-jerk forward progression is safer and avoids accidental backward/oscillating target approach.

Current default timing is distance-sensitive and remains responsive. Across 100 deterministic seeds:

| Chord distance | Median planned duration | Mean max lateral deviation | Median direction changes | Median planned emission density |
|---:|---:|---:|---:|---:|
| 100 px | 99 ms | 1.34 px | 1 | 108 Hz |
| 300 px | 159 ms | 7.17 px | 3 | 170 Hz |
| 500 px | 218 ms | 12.06 px | 4 | 197 Hz |
| 800 px | 307 ms | 17.05 px | 4 | 225 Hz |
| 1200 px | 426 ms | 19.14 px | 4 | 244 Hz |

No artificial mid-motion pauses or independent random shaking were added. Hover/click dwell remains owned by the higher-level interaction transaction, where it can be correlated with focus and semantic admission.

Pointer diagnostics are schema v3 and now include planned/actual chord speed, lateral knot count, lateral direction changes, micro-wobble amplitude, knot irregularity, path length/tortuosity, planned/actual emission rate, exact arrival, safe endpoint variation and transaction timing.

## What remains deliberately separate

R5.164 does **not** claim level-200 tactical perfection. FightAI spell selection, target prioritization, threat valuation, positioning and team sequencing remain the next optimization phase. The foundation repaired here is the runtime substrate those policies depend on: exact fight lifecycle, multi-account safety, transaction causality, world re-entry, input authority and diagnostics.

## Live acceptance target

The next Windows/Dofus run should prove:

1. wins progress 1→2→3→4→5 exactly once per terminal fight;
2. after wins 1–4, a terminal End Turn/MOVE/CAST fence is passively reconciled before any new WORLD input;
3. the fifth confirmed win returns `TARGET_WINS_REACHED` and stops without attempting fight #6;
4. session-end cleanup leaves no stale fight-scoped execution fence for the next mission;
5. no `CONTROL_AUTHORITY_DISARMED` consequence loop degrades into `MISSION_TIMEOUT`;
6. pointer motion remains exact and stable while visibly following the correlated multi-bend profile at reasonable speed;
7. one debug package contains `campaign_progress_health`, control-authority root cause, pointer-motion health, action convergence, account/turn ownership, action results and recovery boundaries sufficient to diagnose any remaining live defect.

**Release status: offline-verified Windows live candidate. Windows/Dofus live acceptance remains PENDING.**

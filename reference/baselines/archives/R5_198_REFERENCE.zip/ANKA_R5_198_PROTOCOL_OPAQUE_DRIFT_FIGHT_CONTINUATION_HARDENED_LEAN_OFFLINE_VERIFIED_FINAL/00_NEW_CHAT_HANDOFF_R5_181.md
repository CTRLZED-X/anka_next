# ANKA R5.181 new-chat handoff

Current checkpoint: **R5.181 Windows Setup & Live Readiness Hardening**.

Start with `docs/CURRENT.md`, `PROJECT_STATUS.json`, `R5_181_WINDOWS_SETUP_LIVE_READINESS_HARDENING.md`, `R5_180_TRANSACTIONAL_LIVE_TRUTH_FOUNDATION.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, `LIVE_ACCEPTANCE.md`, and `WINDOWS_LIVE_RUNBOOK.md`.

R5.181 preserves the R5.180 transactional live-truth foundation and changes the Windows setup boundary: normal `setup.bat` installs only runtime + capture dependencies, while pytest and developer tooling live behind optional `setup_dev.bat`. Dependency installation uses bounded retries and writes a standalone DNS/network probe on failure so connectivity faults are not confused with ANKA defects.

Windows/Dofus live acceptance remains **PENDING** until a fresh Windows extraction completes `setup.bat`, bridge verification, startup/preflight, and one bounded live Launch.

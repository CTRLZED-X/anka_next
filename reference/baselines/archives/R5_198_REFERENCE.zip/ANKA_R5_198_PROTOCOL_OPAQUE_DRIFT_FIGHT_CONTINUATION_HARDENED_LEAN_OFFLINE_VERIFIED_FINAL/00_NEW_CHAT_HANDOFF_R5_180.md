# ANKA R5.180 new-chat handoff

Current checkpoint: **R5.180 Transactional Live Truth & Failure Isolation Foundation**.

Start with `docs/CURRENT.md`, `PROJECT_STATUS.json`, `R5_180_TRANSACTIONAL_LIVE_TRUTH_FOUNDATION.md`, `docs/architecture/TRANSACTIONAL_LIVE_TRUTH.md`, `docs/architecture/PROTOCOL_ADAPTER_SDK.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, and `LIVE_ACCEPTANCE.md`.

R5.180 changes runtime failure/commit boundaries. One classified raw protocol message is staged through the versioned adapter, reduced as one canonical event batch, and persisted atomically. The adapter runtime context is checkpointed before transform and restored if transform, reduction, or canonical persistence does not become authoritative truth. A persistence ambiguity fences the Canonical State store/runtime generation until reopen/recovery establishes one coherent history.

R5.180 also hardens typed authority failures, strict configuration parsing/schema versioning, registered failure vocabulary, incident shutdown races, and bounded/deterministic verification. It does **not** move physical-input authority out of `ExecutionService`, does not weaken `InputArbiter`, and does not leak raw protocol semantics into Campaign/FightAI/Kernel/Execution.

Windows/Dofus live acceptance is **PENDING**. Do not run the next meaningful live test until R5.180 offline verification is sealed.

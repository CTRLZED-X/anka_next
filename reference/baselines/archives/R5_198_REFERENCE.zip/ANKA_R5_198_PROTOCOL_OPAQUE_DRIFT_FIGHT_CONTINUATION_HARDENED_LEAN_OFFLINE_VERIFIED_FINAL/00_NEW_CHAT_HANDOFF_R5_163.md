# ANKA R5.163 — New Chat Handoff

## Current authority

Workspace checkpoint: `ANKA_PLATFORM_R5_163_IDENTITY_AUTHORITY_PROJECTION_ACQUISITION_FORENSIC_HARDENING_WINDOWS_LIVE_CANDIDATE`.

Start with this file, then read `PROJECT_STATUS.json`, `PROJECT_CONTEXT.json`, `R5_163_IDENTITY_AUTHORITY_PROJECTION_ACQUISITION_FORENSIC_HARDENING.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md`.

The sealed runtime diagnostic identity remains R5.115 / platform `0.1.0a122`. The workspace Kernel remains R10J / `0.1.0a59`. Do not relabel those compatibility identities until their own release rules allow it.

## Incident that created R5.163

Runtime `runtime(20261004-122209)(1).zip` ended at shared fight entry with `actor_ownership` conflict. Both CRA and ENU had canonical local actor `496260153637`, even though live `JYM` roster evidence identifies ENU/Sosoking as `477764256037`. The bad shared identity came from weak `JPQ -> JPW` transition correlation whose rank/source was lost when serialized into Canonical State.

The same run was slow before the terminal failure because world acquisition repeatedly selected group `-20003` despite 98 safe pre-input `ENTITY_MISMATCH` blockers. Another eligible group existed. Later `WORLD_INTERACTION_SETTLING` polls were passive and did not resend the accepted click.

FightAI was not the root cause: no legitimate tactical decision ran before the ownership barrier stopped the fight.

## R5.163 invariants

1. Provisional local identity is not authoritative local identity.
2. Rank < 20 never owns an active combat actor and never labels `world.player_actor_id`.
3. Legacy R5.162 unranked R4 identity journal rows are migrated conservatively on replay; v1 checkpoints cannot resurrect the old bug.
4. All active-combat ownership consumers use the centralized identity-authority resolver.
5. Strong exact-name JYM roster evidence may repair a weak transition candidate for that configured account.
6. World entity projection is preflighted before focus/input, then revalidated again under the input lease before the physical click.
7. Candidate failover is allowed only with explicit `physical_send_state=NOT_SENT` and a safe target-specific blocker.
8. Exhausted candidates return one bounded scan plus backoff rather than tight-loop reacquisition.
9. Passive settlement remains observe-only; uncertain/sent input is never treated like a clean pre-input miss.
10. If authoritative identity is corrected, stale world position tied to the previous actor is invalidated until fresh position evidence arrives.
11. Debug bundles separately expose identity authority/collisions and action convergence loops; their identity report replays the reducer's authority rule and their settlement report excludes ordinary retry backoff.

## Primary code hotpaths

- `src/anka_platform/local_fighter_identity.py`
- `src/anka_platform/contracts/canonical_events.py`
- `src/anka_platform/contracts/canonical_state.py`
- `src/anka_platform/live_state/reducer.py`
- `src/anka_platform/live_state/store.py`
- `src/anka_platform/protocol/adapters/dofus_3_6_10_10/r4.py`
- `src/anka_platform/protocol/loader.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/party/evidence.py`
- `src/anka_platform/core/fight/`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/settlement.py`
- `src/anka_platform/observability/exporter.py`

## Primary regression

`tests/r5163/test_r5163_systemic_identity_projection_hardening.py`

It freezes the actual R5.162 failure shape, including the live JYM roster payload, weak-identity hydration, duplicate provisional ownership, migration from an old SQLite checkpoint/journal, pre-focus projection rejection, explicit no-send candidate failover, bounded all-candidate backoff, world-actor non-labeling, and one-bundle identity/convergence diagnostics.

## Next live test

Normal workflow remains `setup.bat` once on a fresh extraction, then `start.bat` -> Script Studio -> Launch.

The next Windows/Dofus run is an R5.163 acceptance run. Do not call R5.163 final until the live bundle proves correct per-account authoritative fighter ids, no ownership collision, bounded world-target convergence, no unsafe duplicate input, and progression into real combat decisions.

**Current status: offline verified; Windows/Dofus live acceptance PENDING; final_release=false.**

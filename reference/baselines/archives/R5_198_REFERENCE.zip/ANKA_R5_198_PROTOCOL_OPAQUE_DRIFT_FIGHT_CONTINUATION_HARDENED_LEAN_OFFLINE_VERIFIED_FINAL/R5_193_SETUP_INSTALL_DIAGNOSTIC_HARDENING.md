# R5.193 — Setup Install + Diagnostic Hardening

## Objective

R5.193 preserves the R5.192 protocol and combat runtime while repairing the setup failure observed on Windows and hardening the entire setup/install/pre-start boundary so the next failure is either prevented or captured with enough evidence to diagnose without another blind test cycle.

## Confirmed incident root cause

The observed setup reached a successful non-editable wheel install and dependency baseline, then `runtime_install_contract.py` received no `--record` argument. The affected batch commands passed `%~dp0` as a quoted native-process directory argument. `%~dp0` ends with a backslash, which is unsafe at a Windows native argv boundary immediately before more arguments because the quote/backslash sequence can cause later tokens to be absorbed into the preceding argument. The same argument shape also affected setup-environment recording earlier in the run.

R5.193 normalizes project-root authority once after `cd /d "%~dp0"` using `%CD%`, exports it as `ANKA_PROJECT_ROOT`, and stops forwarding quoted trailing-backslash `%~dp0` directory values to Python tools.

## Installed-runtime authority

The runtime-install contract is now schema 2. It does not only fingerprint source files; it also discovers the installed `anka_platform` and `anka_game_kernel` package roots in the active interpreter and compares the complete runtime payload against the source payload. A non-editable installation is accepted only when file sets and content digests match. Source edits, protocol edits, incomplete wheel contents, stale site-packages, or an outdated contract all fail closed before server startup.

Normal setup removes transient `build/` and `src/*.egg-info` artifacts created by wheel construction after preserving the install return code. Developer setup does the same. VS Code/Pylance analysis and file watchers exclude those generated surfaces in addition to `.venv`, runtime and large static-data directories.

## Setup evidence and failure reporting

Setup now records a stage marker and durable logs for setup environment, pip installation, runtime-install binding, protocol-upgrade verification, control-plane preflight, UI contract and static readiness. The rich startup-debug exporter includes these artifacts plus a compact setup summary.

A stdlib-only fallback exporter can create `runtime/startup/setup_failure_debug.zip` even when `anka_platform` is unavailable because package installation/import failed. This closes the most important diagnostic blind spot at the exact point where setup previously failed.

## Existing-server / port ownership

The uploaded incident evidence also showed an older R5.185 ANKA server still listening on port 8000 while R5.192 setup was running. R5.193 adds a non-mutating control-plane preflight during setup. It clearly reports FREE, current ANKA, stale/other positively identified ANKA, or unresolved port ownership. Setup does not kill anything. `start.bat` remains the authority that safely adopts/replaces only positively identified ANKA ownership and refuses unresolved foreign ownership.

## Start-time diagnostics

`start.bat` persists runtime-install and protocol-upgrade verification logs. If either blocks before the server can start, ANKA automatically produces a startup debug bundle and prints its path. A source/protocol update can therefore no longer leave the user with only a console line and no incident package.

## Protocol boundary

R5.193 intentionally does not alter the R5.192 `dofus_3_7_10_10` live-decoding semantics, canonical-state model, FightAI, party synchronization, geometry authority, or physical-input ownership. Protocol-upgrade isolation/provenance/scenario gates remain mandatory and are regression-tested.

## Acceptance boundary

Offline acceptance requires R5.193 setup/install/diagnostic tests, R5.192 protocol-upgrade tests, inherited architecture and runtime regressions, release integrity, engineering guardrails, protocol-upgrade verification, the current quick gate, a non-editable wheel/source-payload smoke test, and a valid immutable package manifest. Real Windows setup and Dofus live acceptance remain external gates until the delivered ZIP is rerun on the target machine.

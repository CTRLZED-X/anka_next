# R5.151 — Latency Reconciliation, Foundation Readiness & Strategy Isolation Hardening

## Objective

Use the first R5.150 Windows/Dofus runtime as an adversarial foundation audit rather than assuming that offline verification proves live robustness. The goal is to make slow or delayed network confirmation a bounded reconciliation problem instead of a mission-killing event, while preserving the architecture needed for future GPT/developer work to modify or replace FightAI and TeamStrategy without touching physical input, synchronization, lifecycle ownership or Canonical truth.

## Live evidence used

The audit used `runtime(20261001-213501)`, which contains two campaign attempts. The first completed two fights before a world transition was physically sent but the destination map was not confirmed inside the short execution settlement window. The second completed three fights before a CRA CAST emitted its exact semantic outbound `jrj` request but no server-confirmed cast arrived inside the short confirmation window.

The package does **not** prove Internet latency or packet loss by itself: game TCP connections remained established and the bundle does not contain authoritative RTT/loss telemetry. What it does prove is that authoritative confirmation arrived too late for the local bounded settlement window, and R5.150 converted that latency/uncertainty into a global control disarm. Slow Internet is therefore a plausible trigger, but the confirmed foundation defect was the platform's reaction to delayed truth.

The second run is especially important. Immediately after `ACTION_CONFIRM_TIMEOUT`, ControlAuthority was globally disarmed with reason `INCIDENT:ACTION_CONFIRM_TIMEOUT`; the next ordinary CRA action was then denied as `CONTROL_AUTHORITY_DISARMED`. In other words, R5.150 already knew how to wait for causal evidence, but the incident layer revoked the permission needed for the campaign to remain alive. A recoverable late-confirmation condition was amplified into terminal mission failure.

## Root causes and repairs

### 1. Short settlement timeout was incorrectly equivalent to terminal execution uncertainty

A physical/semantic request can be definitely sent while server confirmation is merely late. R5.151 separates the two conditions:

- `COMBAT_CAST_CAUSALITY_PENDING`
- `WORLD_TRANSITION_CAUSALITY_PENDING`
- `FIGHT_PLACEMENT_CAUSALITY_PENDING`

These conditions enter a passive reconciliation state. The exact transaction remains quarantined, no duplicate input is allowed, and the outer workflow/campaign watchdog owns eventual terminality. The short action window remains short for responsiveness; it is no longer used as evidence that the mission itself is unrecoverable.

Generic or contradictory uncertainty is still fail-closed. `ACTION_CONFIRM_TIMEOUT` without the required structured causality remains a hard fence, and a fresh authoritative world map that differs from the requested destination becomes `WORLD_TRANSITION_TARGET_MISMATCH` rather than being silently accepted or retried.

### 2. Incident export and ControlAuthority had contradictory semantics

R5.150 could open an incident for an action awaiting late evidence and then globally disarm control even though the transaction reconciliation path required the campaign to keep polling Canonical State. R5.151's failure-disposition layer classifies only the structured pending-latency codes as `RECOVER_IN_PLACE` with `freeze_control=false`. They do not trigger a critical incident/control disarm merely for being late.

This does **not** relax physical safety. While reconciliation is pending, the original transaction owns its action lane, `input_quarantined=true`, and `physical_retry_allowed=false`.

### 3. World-transition reconciliation existed but only helped too late

The platform already contained conservative world-transition reconciliation for terminal cleanup/preflight. Active campaign execution did not use it before declaring the workflow terminal. R5.151 makes active readiness consult the same causality state. A delayed intended destination retires the pending transaction without another click. Remaining on the source map continues waiting. A fresh different destination is an explicit causality mismatch and fences control.

### 4. Fight placement and fight launch needed the same latency contract

Placement now follows the same rule: one physical placement click, then passive confirmation. A later authoritative local-cell update confirms the transaction without a second click.

For `launch_fight`, positive semantic acceptance permanently closes the duplicate-click gate. If fight creation is still pending after the inner settlement window, the transaction remains `IN_PROGRESS` under the parent campaign watchdog rather than becoming terminal. If semantic coverage is insufficient to prove acceptance or rejection, the action also remains passive and quarantined; only certified negative evidence may authorize a bounded retry.

### 5. Semantic-send evidence was being degraded during cast reconciliation

If the exact outbound `jrj` request has already been observed, a later `WAITING` reconciliation record must retain that fact. R5.151 preserves `semantic_cast_send_state=OBSERVED` and the request evidence while awaiting server confirmation. This prevents future debug packages from incorrectly turning known send causality back into UNKNOWN.

## Verification of the R5.150 foundation goals

### FightAI / TeamStrategy are genuinely replaceable policy layers

The architecture audit confirms that the `anka_platform.fight_ai` package does not directly import ExecutionService, Windows/input control, CampaignRuntimeController, scripting, party orchestration or web/session-control layers. A permanent AST architecture regression now scans the entire FightAI package and fails if one of those runtime-control dependencies is introduced.

Future policy code receives stable contracts: immutable combat/Cannonical projections, Kernel legality, team strategy interfaces, and `PlannerInvocationContext.confirmed_turn_history`. It returns typed decisions. PartyCombatController owns turn liveness/recovery/quarantine, and ExecutionService remains the only physical-input authority.

### The movement concern is now a policy problem, not a foundation problem

The R5.150 live runtime proves that confirmed movement history is reaching later planner slices: `confirmed_prior_move_count` advances 0 -> 1 -> 2 on repeated same-turn moves. Execution still performs one final-cell click for each selected MOVE. Therefore remaining multi-MOVE turns are tactical choices/scoring behavior, not cell-by-cell path clicking or lost controller history. A future GPT can change this behavior entirely inside policy/scoring without modifying execution.

### One runtime package is now sufficient for useful diagnosis

The new package exposed the causal chain for both failures: exact action transaction, physical send state, semantic request state, ControlAuthority transition, campaign phase, pending transaction, planner frame, and failure disposition. `summary.json` is compact rather than recursively embedding the entire run, while raw evidence remains available in dedicated streams. This satisfies the core forensic goal much better than older releases.

## Remaining live observations that are not foundation regressions

- CRA Ready still often needs a bounded second interaction because the first click has no outbound semantic Ready request. R5.150/R5.151 diagnostics prove the sequence but do not yet prove why. Do not invent a cause.
- Some turns still contain multiple confirmed MOVE decisions. The planner now knows the prior moves, so this belongs to tactical policy quality.
- Stale combat frames still occur under nontrivial planner latency, but they are rejected before input and carry semantic-drift explanations.
- Effect payloads can grow substantially (up to 90 instances in this runtime, with repeated semantic signatures). Because the generic effect apply/refresh/stack/expire/remove lifecycle is not yet authoritative, do **not** deduplicate by heuristic. This is an important level-200 truth/performance milestone.

## Level-200 readiness assessment

R5.151 is intended to make the **foundation ready for strategy iteration**, not to claim universal level-200 combat correctness. The platform is structurally ready for future FightAI/TeamStrategy work after one live validation of the new latency reconciliation path. Arbitrary level-200 readiness remains unproven because the following truth/mechanics areas are still incomplete:

- exact tackle/lock semantics;
- complete effect apply/refresh/stack/expire/remove lifecycle;
- comprehensive dynamic enemy HP/AP/MP truth;
- summon capacity and summon-lineage semantics;
- broader target-zone and monster-specific mechanics;
- broad encounter-diversity validation of the tactical policy.

These must be certified from authoritative evidence, not guessed in FightAI.

## Recommended next milestone

1. Fresh-extract the exact R5.151 ZIP on Windows.
2. Run a bounded autonomous CRA+ENU campaign, ideally including naturally variable/slow network conditions but no manual combat input.
3. Verify that delayed CAST/world/placement/launch confirmation enters `RECONCILING`/`IN_PROGRESS`, emits no duplicate physical input, keeps ControlAuthority armed, and eventually either reconciles from fresh Canonical truth or terminates only through the outer watchdog.
4. Verify a fresh contradictory destination still hard-fences.
5. If this passes, freeze the combat foundation and begin the **Zone-200 Combat Truth & Strategy Iteration** milestone. Future strategy work should normally be confined to FightAI, TeamStrategy, tactical knowledge/configuration and Kernel truth extensions backed by evidence.

## Verification status

Offline candidate. R5.151 source-level/bounded regression verification is complete; the final package report records the exact completed gates. Windows/Dofus live acceptance of the new latency reconciliation behavior is **PENDING**.

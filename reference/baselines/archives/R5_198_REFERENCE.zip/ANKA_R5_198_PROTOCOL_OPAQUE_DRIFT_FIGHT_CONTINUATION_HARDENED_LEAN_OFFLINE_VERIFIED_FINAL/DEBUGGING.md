> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# R5.198 debugging priority

For a fight stop after an action, first prove whether the action itself settled. Then inspect runtime-health blockers and the protocol unknown inventory before changing FightAI or Execution.

For protocol drift, preserve and compare: wire name, direction, exact payload size, SHA-256, account/flow, raw PCAP replay classification, transform/reducer failures, and the first critical Canonical frame. Never infer gameplay semantics merely because a message can be safely classified as exact opaque traffic.

Run `simulate_live.bat <runtime-or-incident.zip>` to reproduce captured evidence without physical input. R5.198 reports raw-PCAP decoder fidelity separately from Canonical-journal exact-revision reconstruction, so a bounded capture cannot manufacture missing historical revisions.

For startup failures, the inherited R5.197 control-plane diagnostics remain authoritative through `runtime/startup/last_startup_debug.zip`.

# NEW CHAT HANDOFF — ANKA Platform R5.143

Current checkpoint: `ANKA_PLATFORM_R5_143_COMBAT_LIVENESS_FAILURE_DISPOSITION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus live acceptance: **PENDING**. This is not a final production release.

## Current objective

Stabilize the fight foundation so local/recoverable combat defects do not terminate the entire mission. Only uncertain physical input, client/window/control identity loss, contradictory generation state, or similarly unsafe conditions may fence control. Once this is live-proven, development should move primarily to a modular CRA+ENU FightAI suitable for eventual level-200 zones.

## Triggering live evidence

Primary evidence: `runtime(20260927-172212)`.

The terminal chain was:

1. ENU attempted Bêche des Anciens.
2. Physical target click was sent.
3. Exact-client protocol evidence certified that no semantic CAST request left the client.
4. UI neutralization succeeded.
5. Execution returned `CLIENT_CAST_REJECTED`, `safe_replan=true`, `quarantine_candidate=true`.
6. Fight recovery correctly chose exclusion/replan.
7. The global incident callback nevertheless disarmed `ControlAuthority` merely because the diagnostic was run-correlated.
8. The next combat action failed `CONTROL_AUTHORITY_DISARMED`, terminating the mission.

R5.143 fixes that cross-layer contradiction.

## R5.143 changes

- New `src/anka_platform/observability/failure_disposition.py`.
- Forensics and control fencing are separate decisions.
- Certified `CLIENT_CAST_REJECTED` is recoverable only with complete negative-causality + UI-neutralization proof.
- Unknown/uncertain live failures remain fail-closed.
- `web/app.py` applies the shared disposition at the actual `ControlAuthorityStore` boundary.
- FightAI exceptions before input are contained to the turn and fall back to END_TURN through ExecutionService.
- Malformed FightAI decisions are validated before input and contained the same way.
- Tactical candidate audit now gives every configured spell an explicit per-cycle disposition instead of allowing silent disappearance.

## Important unresolved foundation work

1. **Protocol/state recertification**: configured adapter is `dofus_3_6_10_10`, supplied live client was 3.6.12.16. Do not invent live AP/MP/PO from equipment.
2. **Range/state completeness**: the supplied run showed large-scale `LEGAL_CAST_CELLS_INDETERMINATE`, mainly missing `combat_stats.range_bonus`, plus summon/state evidence gaps.
3. **Interaction viability**: preserve the distinction between Kernel-legal cast cells and reliably interactable rendered client targets; rejected equivalent AoE centres should be quarantined/replanned, not mission-terminal.
4. **FightAI modularization**: split the large tactical policy into team planner, candidate generator, utility model, sequence planner and conservative fallback policy before level-200 strategy becomes complex.
5. **CRA+ENU strategy**: only after state truth is stable, improve multi-turn buffs, range/power setup, MP/range control, displacement, cooldown planning, target prioritization and team combinations.
6. **Enemy capability model**: level-200 zones require monster-specific/generic capability evidence beyond the current broad threat approximation.

## Current safety invariants

- ExecutionService is the sole physical-input authority.
- Canonical State owns semantics; projection/Unity cannot invent combat truth.
- Kernel UNKNOWN remains UNKNOWN.
- Possible/uncertain physical input is a hard fence.
- Recoverable no-semantic-input actions are turn-local and bounded.
- The campaign must not depend on its outer watchdog to escape a local FightAI loop.

## Verification already completed for this workspace

- R5.143 + R5.140–R5.142 affected combat/FightAI/observability group: completed passes in bounded runs.
- Direct `ControlAuthorityStore` regressions prove recoverable cast rejection preserves the run and uncertain input disarms it.
- Python `compileall` for `src` + `tests`: PASS.
- Any aggregate command that timed out is explicitly not counted.

Read next:

1. `R5_143_COMBAT_LIVENESS_FAILURE_DISPOSITION_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `R5_142_COMBAT_ACTION_CONTRACT_QUARANTINE_TURN_LIVENESS_HARDENING.md`
4. `R5_141_SPELL_TARGET_INTERACTION_ACTION_INTENT_SEQUENCE_PLANNING_HARDENING.md`
5. `ARCHITECTURE.md`
6. `DEBUGGING.md`

# R5.167 Protocol / Policy Isolation, Worker Recovery & Architecture Hardening

## Objective

R5.167 is an architecture-readiness pass on top of R5.166. It does not change the proven five-fight lifecycle or pointer profile. It makes future protocol replacement and FightAI replacement narrower, removes static dependency cycles, adds bounded recovery for the disposable session worker, and makes architectural ownership executable/verifiable rather than only documented.

## Protocol replaceability

Protocol-specific wire names, request bindings, slot mapping, capabilities, legacy identity replay rules and certified opaque-version compatibility now live in the versioned adapter manifest. Generic Canonical State and forensic code dispatch through adapter-owned callbacks instead of naming the current Dofus dialect.

A normal future protocol change therefore consists of a new adapter package plus one explicit registry registration, fresh live-decoding certification, configuration selection and tests. If the canonical contract major remains compatible, Kernel/FightPolicy/party/campaign/execution should not need semantic rewrites.

## Fight-policy replaceability

Production composition uses release-neutral `build_default_policy_registry()`. Runtime foundation packages (`core`, `party`, `campaign`, `execution`, `scripting`) do not import concrete `fight_ai` implementations. FightAI-specific decision tracing is injected at the application composition root.

A replacement active policy consumes the stable core port:

`decide(kernel, snapshot, local_actor_id, profile, *, planner_context) -> FightDecision`

`PlannerInvocationContext` supplies the decision deadline, team objective, excluded/quarantined action fingerprints, confirmed same-turn execution history and structured combat-truth availability. Execution independently re-admits and validates the returned primitive before physical input.

## Recovery and single-authority design

R5.167 does not attempt to create duplicate authorities. CanonicalStateStore, CampaignRuntimeController/CampaignEngine, ExecutionService/InputArbiter and PointerMotionService remain intentional single authorities because duplicating them would create split-brain or duplicate-input risk. The design target is **single authority without single unrecoverable failure**.

The thin `SESSION_ONLY` script worker is now disposable: an unexpected process exit can be restarted a bounded number of times from its immutable source copy while campaign/state/execution ownership remains in the parent process. Manual scripts are never automatically replayed. Stateful/possibly-sent physical actions are never replayed by worker recovery.

A full parent application-process crash remains a deliberate hard recovery boundary: durable Canonical/Execution safety evidence permits a safe restart/reconciliation, but automatic in-flight campaign resurrection is not yet certified and would be unsafe to fake.

## Capture health

Scapy backend status now distinguishes configured capture from the observed AsyncSniffer running state and exposes `unexpected_stop`. This makes passive capture-thread failure visible immediately; `status()` itself never restarts capture or authorizes input.

## Architecture verifier

`python tools/verify_foundation_architecture.py` verifies:

- zero static `anka_platform` import cycles;
- no concrete protocol-adapter imports leaking outside the protocol package;
- no concrete FightAI imports in runtime foundation packages;
- no executable Win32 physical-input implementation outside execution;
- campaign worker remains `SESSION_ONLY`;
- bounded session-worker restart support exists;
- production policy composition is release-neutral;
- registered protocol manifests satisfy required contracts.

It writes `verification/foundation_architecture_report.json` and also documents intentional authority/recovery boundaries and extension contracts.

## Scope intentionally not rewritten

The large safety-critical ExecutionService and PartyMissionController were not split merely to reduce file size. Their concentration is technical debt, but wholesale refactoring without a demonstrated ownership defect would increase live risk. Replaceability is enforced at stable ports/composition boundaries instead.

Pointer motion remains the R5.165/R5.166 TrajectoryLab-v2-safe correlated-knot/minimum-jerk implementation. FightAI tactical quality remains a separate next-stage concern.

## Remaining hard boundary

R5.167 is an offline candidate. Windows/Dofus live acceptance remains pending. The parent application process is still an intentional fail-closed boundary; automatic crash-resume of an in-flight campaign is not claimed.

# ANKA R5.196 — New Chat Handoff

## Current candidate

R5.196 is the current offline-verified turn-readiness, multi-account handoff, evidence-replay, and systemic-simulation hardening candidate. It inherits R5.195 fight-entry geometry/placement protections. Windows/Dofus acceptance remains pending only for behavior that cannot be proven from captured evidence or zero-input simulation.

## Latest runtime root cause

`runtime(20261016-152128).zip` reached ACTIVE combat. CRA's first-turn snapshot at canonical revision 979 had AP=7 and MP=3 last observed at revision 959; fight ACTIVE began at revision 428. R5.195 incorrectly demanded AP/MP newer than TURN_STARTED revision 979, so unchanged resources could never satisfy readiness and the same CAST was replanned/blocked repeatedly.

## R5.196 repair

Turn-start resources are now validated against a frozen causal per-turn floor: ACTIVE for the first turn, immediate prior TURN_ENDED for a proven handoff, or strict current TURN_STARTED when handoff evidence is missing. The readiness gate runs before window activation and FightAI. Post-action settlement remains strict.

Additional hardening includes delayed duplicate-turn rejection, last-ended actor/turn watermarks, semantic-vs-geometry preflight correction, root failure preservation, per-account canonical evidence accounting, explicit truncated-preview handling, and exact embedded-PCAP replay.

## Local simulation

Run `simulate_live.bat` for synthetic zero-input systemic scenarios, or pass a runtime/incident ZIP to replay captured evidence first. The 2026-10-16 runtime passes exact raw PCAP replay for both gameplay flows and the 13-scenario systemic suite with `physical_input_emitted=false`.

## Protocol note

The observed client title is 3.7.11.11 while the active certified adapter remains `dofus_3_7_10_10`. The supplied raw PCAP's mapped gameplay flows transform without unclassified messages or reducer failures. Exact-build negative-absence claims remain fail-closed until 3.7.11.11 is independently certified; do not patch Campaign/FightAI/Execution for protocol drift.

## Next live milestone

Bounded CRA+ENU run: first real ACTIVE combat action → semantic settlement → CRA→ENU handoff → ENU action → fight end/world re-entry. Preserve the resulting runtime ZIP if an uncaptured boundary fails.

# ANKA R5.198 — Protocol Opaque Drift / Fight Continuation Hardening

## Captured failure

The supplied R5.197 runtime reached combat successfully. CRA's first CAST was server-confirmed and settled; the run stopped only afterward. Both gameplay flows then observed a previously unseen server wire `icw`, and the active fail-closed protocol health policy promoted that unknown traffic to sticky `PROTOCOL_UNCLASSIFIED_ACTIVE`. The next otherwise-valid combat action was therefore rejected with `ACTION_BLOCKED_READINESS` and the mission terminated under `LIVE_TRUTH_RUNTIME_HEALTH_BLOCKED`.

The same raw capture also contains one earlier unknown server wire, `icl`. Across the complete mapped CRA+ENU gameplay PCAP these are the only wire names absent from the active catalog.

## Repair boundary

R5.198 does not weaken RuntimeHealthFence and does not patch Campaign, FightAI, or Execution around protocol failure. The active adapter admits only the exact observed `icl` and `icw` variants as **catalog-only opaque traffic**:

- direction must match the observed server-to-client direction;
- payload size must match exactly;
- payload SHA-256 must match exactly;
- transform output is empty;
- Canonical State is not mutated;
- no gameplay meaning is inferred;
- any changed payload/direction remains unclassified and therefore fail-closed.

This reuses the adapter's existing exact opaque-evidence mechanism rather than creating a general ignore list.

## Forensic replay hardening

Raw PCAP and Canonical journals now have explicit, separate authority. Raw PCAP proves TCP framing, wire classification, adapter transformation, and reducer behavior for bytes that were actually captured. Per-account Canonical journals reconstruct the exact persisted live revision when capture bootstrap does not cover all pre-existing Canonical history. Incident replay no longer forces raw capture to manufacture an exact revision it cannot prove.

For this incident, full CRA+ENU raw gameplay replay after the R5.198 catalog update has zero unclassified messages and zero transform/reducer failures. The exact live failure frame can also be reconstructed from the durable account journal; its former `PROTOCOL_UNCLASSIFIED_ACTIVE` blocker is cleared by the repaired adapter policy.

## Safety retained

Protocol client-build drift remains explicit: the observed client identifies as 3.7.11.11 while the active certified adapter identity remains 3.7.10.10. Positive observed traffic may be accepted under exact evidence, but R5.198 does not claim exact-build negative-absence certification or silently broaden protocol compatibility.

# ANKA Platform R5.140 — Combat Frame, Feasibility, Recovery & Tactical Foundation Hardening

Checkpoint: `ANKA_PLATFORM_R5_140_COMBAT_FRAME_FEASIBILITY_RECOVERY_TACTICAL_FOUNDATION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Status during development freeze: **OFFLINE VERIFICATION IN PROGRESS**. Windows/Dofus live acceptance remains **PENDING**.

## Why R5.140 exists

R5.139 hardened the two-stage CAST physical transaction. The next autonomous Windows/Dofus runtime, `runtime(20260926-195951)`, proved that the remaining dominant failure was not a spell-click or general account-control failure.

Fight 385 produced repeated FightAI decisions that were acceptable to the planner but returned `CAST_ADMISSION_UNKNOWN` before any physical input. Cra repeated the same no-input Carreaux/Sentinelle choices until its turns were consumed and the mission eventually stopped. Enu independently completed CAST -> MOVE -> MOVE -> END_TURN, proving that account/window control remained functional.

The systemic root causes were:

1. FightAI built a cross-account semantic view with certified side/team relations, while latest-state execution admission could rebuild Kernel context from a weaker local-only lane.
2. no-input admission uncertainty used generic retry/stall behavior, so an unchanged frame could deterministically select the same impossible-to-certify action many times;
3. tactical damage magnitude ignored the verified `absolute` amount unit, making normal damaging Cra/Enu spells score as damage magnitude zero;
4. normal MOVE planning/admission used weaker geometry/reachability contracts than the Kernel's strict movement projection;
5. raw diagnostics captured the evidence but did not automatically identify planner/admission contradictions or classify no-input admission failures correctly.

R5.140 fixes these architectural boundaries generically. It does not introduce Carreaux, Sentinelle, map-cell or Sufokia-specific runtime branches.

## 1. Immutable CombatDecisionFrame

`src/anka_platform/core/fight/combat_frame.py` introduces `CombatFrameAssembler` and frozen `CombatDecisionFrame`.

A frame:

- captures each required account lane exactly once;
- converges required lanes by semantic fight epoch rather than globally ordering lane revisions;
- overlays only peer-certified cross-account side/team evidence;
- preserves raw lane snapshots separately from the semantic owner view;
- records the per-account revision vector and stable frame identity;
- fails closed on conflicting/non-converged team evidence.

FightAI and execution admission use the same frame-assembly contract. Execution still captures a fresh frame immediately before physical input; it never trusts the planner frame as a substitute for latest-state admission.

## 2. Feasibility is separate from tactical utility

Tactical scoring no longer treats incomplete effect semantics as a penalty that a high tactical score can overcome.

For executable CAST candidates:

- cast-area legality must be deterministic/complete;
- `preview_cast` must be legal;
- ordered effect projection must be complete;
- missing inputs exclude the candidate from the executable pool;
- affected actors come only from Kernel-certified `eligible_actor_ids`.

Latest-state `FightActionAdmissionService` remains the final authority before physical input.

## 3. Typed turn recovery

`src/anka_platform/core/fight/recovery.py` introduces explicit failure classes and recovery directives rather than a single retry/stall concept.

Important behavior:

- `CAST_ADMISSION_UNKNOWN` / `MOVE_ADMISSION_UNKNOWN` with **NOT_SENT** input receive a bounded evidence refresh;
- if the same frame/action remains unprovable, the candidate is excluded for the current turn and FightAI replans;
- repeated recoverable planner uncertainty can fall back to the normal certified END_TURN transaction;
- deterministic admission rejection quarantines/excludes the action rather than retrying it blindly;
- possible/uncertain physical input remains fenced and can never be hidden by END_TURN fallback.

The safety hierarchy is therefore:

```text
normal legal action
 -> alternate legal action
 -> bounded evidence refresh
 -> exclude/quarantine + replan
 -> certified END_TURN fallback
 -> next turn
 -> stop only when causality/control/fight state is genuinely unsafe
```

## 4. MOVE uses Kernel feasibility

Normal tactical MOVE candidates must pass deterministic `kernel.movement_projection.project_move_to` feasibility.

Execution then performs fresh latest-state MOVE admission before clicking, followed by the same final-revision anti-TOCTOU check used by the physical transaction boundary.

This prevents geometry-only reachability from being mislabeled as fully certified movement when lock/tackle or another required mechanic is unknown.

## 5. Tactical damage valuation repaired

The spell feature catalog now treats verified `absolute` damage/lifesteal amounts as real damage magnitude, in addition to legacy flat/unspecified units.

This repairs the live profile defect where damaging Cra/Enu spells could have `has_damage=true` but `base_damage_signal=0`.

Longer-term richer damage/resistance/lethality projection remains a Kernel/outcome-model concern; R5.140 does not guess unknown combat values.

## 6. Combat diagnostics improved

R5.140 adds/exports evidence for:

- combat-frame id, team epoch and lane revision vector;
- combat-frame capture time, policy time and trace-build time;
- typed recovery directives;
- admission UNKNOWN before any physical input;
- repeated same-frame action behavior;
- zero damage signal for a damaging spell;
- suspicious effect-payload expansion;
- correct causal attribution to `COMBAT_ACTION_ADMISSION / FIGHT_ACTION_ADMISSION` when no physical action was sent.

Future runtime packages should distinguish planning/admission inconsistency from settlement/input failure instead of blaming a later wrapper boundary.

## 7. Preserved invariants

- `ExecutionService` remains the only physical-input authority.
- UNKNOWN never becomes optimistic TRUE.
- Canonical revision numbers remain lane-local and are never globally ordered across Cra/Enu.
- PREPARATION identity never authorizes ACTIVE combat.
- Every physical primitive settles before the next physical primitive.
- uncertain input causality is fenced; fallback END_TURN is forbidden in that state.
- R5.139 post-slot UI neutralization and fresh PRE_TARGET target projection remain mandatory.
- R5.138 semantic target-actor integrity and generic AoE/FORK geometry remain mandatory.
- no production branch is keyed to the incident spell IDs/cells.

## 8. Direct regression coverage

`tests/r5140/` covers the new contracts, including:

- cross-account side relation overlay without mutating raw account lanes;
- the same semantic frame consumed by FightAI/admission;
- real-Kernel reproduction of the live planner/admission asymmetry class;
- bounded no-input admission recovery and current-turn candidate exclusion;
- safe END_TURN fallback for repeated recoverable planner uncertainty;
- nonrecoverable profile/control errors do not use that fallback;
- absolute damage magnitude is visible for Cra/Enu damaging spells;
- MOVE admission is latest-state Kernel certified;
- anomalies and causal attribution identify admission-before-input failures.

All inherited R5.135–R5.139 safety regressions remain mandatory.

## 9. Live acceptance still required

Offline verification cannot prove Dofus timing, UI focus/projection, real protocol timing, or whether all real fight states provide the semantic evidence expected by the new frame contract.

The next Windows/Dofus acceptance must prove that:

```text
Cra + Enu converge on one fight frame
 -> both act
 -> planner and admission agree on normal legal casts
 -> no unchanged no-input candidate loop consumes a turn
 -> recoverable no-input uncertainty chooses another action or END_TURN
 -> MOVE admission remains deterministic
 -> input uncertainty still fences
 -> fight terminates
 -> canonical outcome commits once
 -> both accounts return to world
 -> next fight starts
```

Do not manually repair the run. Preserve the first autonomous failure package.

## 10. Final structural refinements added during implementation

The implementation phase tightened the design further after compatibility testing exposed two important distinctions.

### Semantic decision fingerprint

A `CombatDecisionFrame` now carries a deterministic semantic fingerprint built from the required lanes' decision-critical fight facts rather than raw snapshot revision numbers alone. After FightAI finishes, `FightDecisionService` captures a fresh frame and rejects the decision as `DECISION_STALE_COMBAT_FRAME` if HP/cell/AP/MP/range/effect/cooldown/loadout/actor/team/turn semantics changed while planning. A raw revision advance with unchanged decision semantics does not by itself invalidate the decision.

This closes same-turn stale-decision races without globally ordering Cra and Enu revisions.

### One shared action-feasibility interpreter

`src/anka_platform/integration/action_feasibility.py` defines `KernelActionFeasibilityService` and the tri-state `ActionFeasibility` contract. Tactical planning and latest-state CAST/MOVE admission now interpret Kernel projections through the same seam.

Execution legality and outcome completeness are intentionally separate:

- an externally targeted tactical cast is fail-closed until the named actor's Kernel-certified impact is known;
- a mechanically legal self/support cast may remain legally executable even when a generic post-cast outcome/lifetime projection is incomplete;
- FightAI still requires sufficiently complete outcome evidence before assigning effect-dependent tactical utility.

This prevents a high tactical score from overriding missing legality while also avoiding the opposite failure mode where stronger admission accidentally disables legal support spells.

### No recomputation on unchanged no-input UNKNOWN

After the first `CAST_ADMISSION_UNKNOWN` / `MOVE_ADMISSION_UNKNOWN` with no physical input, the controller stores the exact attempted primitive and the full required-lane revision vector. If the next evidence-refresh poll has the same vector, it quarantines that primitive for the turn without calling FightAI or execution again. Only genuinely new evidence causes the candidate to be reconsidered.

This directly removes the approximately two-second repeated full-planning loop observed in fight 385.

### Explicit failure taxonomy

Combat controller results now distinguish recoverable action failure, invalid FightAI decision, temporary state uncertainty, decoder/state synchronization delay, executor failure, account-control failure, uncertain physical input and permanent combat failure. The taxonomy is diagnostic and recovery-oriented; it does not weaken existing causality fences.

### Rejected-candidate diagnostics

The tactical trace now includes a bounded `candidate_generation_audit` containing rejection counts plus a capped sample of rejected CAST/MOVE probes. Reasons include insufficient AP, indeterminate legal-cell queries, Kernel feasibility UNKNOWN/ILLEGAL, incomplete target impact, tactical hard rejection and strict MOVE uncertainty. The audit is copied into the dedicated candidate forensic stream and can emit a feasibility-rejection-burst anomaly without serializing an unbounded search tree.

# ANKA Platform R5.139 — New Chat Handoff

## 1. Current authority

This is the human-readable handoff for continuing the current workspace without rediscovering the project.

Current checkpoint:

`ANKA_PLATFORM_R5_139_CAST_TRANSACTION_UI_NEUTRALITY_PROTOCOL_NEGATIVE_EVIDENCE_HARDENING_WINDOWS_LIVE_CANDIDATE`

Current state:

- offline/systemic verification: **PASS**;
- Windows/Dofus live acceptance: **PENDING**;
- final production release: **NO**;
- behavioral parent: R5.138;
- sealed historical runtime identity: R5.115 / platform `0.1.0a122` by design;
- Kernel identity: `0.1.0a58`, `R10I Runtime Spell Readiness Contracts`.

Read in this order:

1. `00_NEW_CHAT_HANDOFF_R5_139.md`
2. `R5_139_CAST_TRANSACTION_UI_NEUTRALITY_PROTOCOL_NEGATIVE_EVIDENCE_HARDENING.md`
3. `R5_138_TACTICAL_IMPACT_GEOMETRY_CAST_TARGET_INTEGRITY_HARDENING.md`
4. `PROJECT_STATUS.json`
5. `PROJECT_CONTEXT.json`
6. `verification/R5_139_OFFLINE_VERIFICATION.md`
7. `ARCHITECTURE.md`
8. `DEBUGGING.md`
9. `WINDOWS_LIVE_RUNBOOK.md`

Do not rewrite architecture without new evidence. Preserve current authority boundaries.

## 2. Goal and team

ANKA is an independent Windows/Dofus multi-account automation platform. It must remain deterministic, fail-closed and diagnosable.

Immediate mission:

- Cra `Curseni`: leader, required `ACTIVE_CONTROLLER`;
- Enutrof `Sosoking`: required `ACTIVE_CONTROLLER`;
- both enter the same fight, place, Ready, act cooperatively, terminate, return to world and continue;
- mission `sufokia_farm_tactical_v1`;
- start `[7,-12]`, route cycle `R D L U`;
- target groups 6–8;
- default bounded campaign 5 attempts / 5 target wins, stop on loss or unknown.

Longer term: arbitrary level-200 areas and additional passive/front-guard accounts while Cra+Enu remain the active tactical core.

## 3. Non-negotiable architecture

```text
Network/client evidence
 -> Canonical State per account
 -> party semantic synchronization
 -> FightAI proposes one primitive
 -> Kernel evaluates deterministic mechanics/legality
 -> FightActionAdmissionService revalidates latest state
 -> ExecutionService is sole physical-input authority
 -> canonical settlement / packet causality
 -> replan
```

Rules:

- Canonical State owns live semantic truth.
- Kernel owns deterministic mechanics, not live state.
- FightAI proposes; it never owns physical input.
- Every primitive settles before another primitive is planned/executed.
- Unknown evidence stays UNKNOWN/fail-closed.
- Per-account Canonical revisions are lane-local and never globally ordered.
- PREPARATION causal identity cannot authorize ACTIVE combat.
- Never repair incidents with generic hard-coded spell/cell IDs.

## 4. R5.138 preserved baseline

R5.138 repaired `runtime(20260926-130218)`:

- generic FORK geometry is the real forward directional three-prong primitive;
- `target_actor_id` survives FightAI -> controller -> execution;
- PRE_SLOT/PRE_TARGET require Kernel-certified intended-actor effect eligibility;
- geometry occupancy alone is not effect eligibility;
- immediate same-turn A->B->A move reversal is blocked;
- confirmed enemy AP/MP/range/heal/shield benefit is a hard blocker;
- terminal FightAI decision and cast causality are exported.

Do not reintroduce a fake non-walkable rule for empty-cell AoE targeting.

## 5. R5.139 change

A pre-live audit found a CAST transaction gap after slot selection. R5.139 hardens the generic family rather than patching a spell.

Current CAST contract:

```text
preflight projection
 -> PRE_SLOT
 -> SPELL_SLOT_CLICK
 -> PRE_TARGET
 -> fresh SPELL_TARGET_CLICK projection
 -> unchanged authorization revision
 -> SPELL_TARGET_CLICK
 -> settlement
```

After the slot click, any safe abort must send/prove `ESC` UI-neutralization before replan. If neutralization is uncertain, execution becomes UNCERTAIN and remains fenced.

Negative `jrj` absence can classify `CLIENT_CAST_REJECTED` only when the **observed** client build is certified for that negative semantic contract. `dofus_3_6_10_10` + observed `3.6.10.10` is certified; an observed build such as `3.6.12.16` is not automatically certified and therefore remains UNCERTAIN for negative absence.

`analysis/physical_input_ledger.jsonl` now exposes `SPELL_SLOT_CLICK`, `SPELL_TARGET_CLICK` and `UI_NEUTRALIZE` phases.

Standalone live preflight now consumes authoritative `launch_blockers`.

## 6. Important hotpaths

Application/orchestration:
- `src/anka_platform/application/service.py`
- `src/anka_platform/core/session_compiler.py`
- `src/anka_platform/campaign/runtime.py`
- `src/anka_platform/core/fight/workflow.py`
- `src/anka_platform/party/mission.py`

Fight entry/team:
- `src/anka_platform/local_fighter_identity.py`
- `src/anka_platform/party/shared_fight.py`
- `src/anka_platform/core/fight/entry_coordinator.py`
- `src/anka_platform/core/fight/controller.py`

FightAI/Kernel:
- `src/anka_platform/core/fight/decision_service.py`
- `src/anka_platform/fight_ai/tactical_policy.py`
- `src/anka_game_kernel/mechanics/aoe/service.py`
- `src/anka_game_kernel/mechanics/targeting/service.py`
- `src/anka_game_kernel/mechanics/casting/service.py`
- `src/anka_platform/integration/kernel_context.py`

Execution/admission/protocol:
- `src/anka_platform/execution/fight_action_admission.py`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/windows.py`
- `src/anka_platform/execution/settlement.py`
- `src/anka_platform/execution/control_authority.py`
- `src/anka_platform/protocol/compatibility.py`
- `src/anka_platform/protocol/adapters/dofus_3_6_10_10/r4.py`

Diagnostics:
- `src/anka_platform/observability/exporter.py`
- `src/anka_platform/observability/run_store.py`
- `DEBUGGING.md`

Note: the old R5.138 handoff named `src/anka_platform/execution/transactions.py`; that file does not exist. Do not search for it as an authority hotpath.

## 7. Next task

Mandatory next proof is a fresh Windows/Dofus R5.139 bounded live acceptance. Offline tests cannot prove real UI-selection semantics, projection/calibration, focus timing or packet behavior.

Success path:

```text
Launch once
 -> leader fight
 -> Enu joins
 -> placement/Ready converge before timeout
 -> FIGHT_ACTIVE
 -> Cra+Enu both act
 -> R5.138 target/FORK invariants hold
 -> post-slot abort, if any, is neutralized before replan
 -> semantic target click uses fresh post-PRE_TARGET projection
 -> uncertified build negative absence remains UNCERTAIN
 -> fight terminal
 -> one canonical outcome commit
 -> both return to world
 -> next fight
 -> continue to configured stop condition
```

Do not manually help the automation during acceptance.

## 8. Debug package priority

At first autonomous failure preserve the first complete runtime/incident package. Inspect:

- lifecycle boundary matrix/transition trace;
- control authority history;
- physical input ledger;
- execution action/settlement/fence evidence;
- fight entry/preflight/reconciliation;
- Cra/Enu canonical events;
- protocol capture window/unknown inventory;
- FightAI decision/team-plan/candidate/outcome/consequence/anomaly/replay evidence.

For CAST reconstruct:

```text
FightAI candidate + target_actor_id
 -> Kernel affected_cells / eligible_actor_ids
 -> PRE_SLOT
 -> SPELL_SLOT_CLICK
 -> PRE_TARGET
 -> fresh projection
 -> authorization-revision check
 -> SPELL_TARGET_CLICK or UI_NEUTRALIZE
 -> outbound semantic request
 -> server confirmation/consequences
 -> settlement
```

Do not infer a bad/non-walkable cell from visual appearance alone.

## 9. Deliberate remaining conservative boundaries

- Controlled summons remain fail-closed when maximum summon capacity is not authoritative.
- Generic active-effect expiry/removal remains conservative where universal evidence is incomplete.
- `kernel.maps_directory` may still depend on the validated external Maps dataset on the Windows machine; this is data-location dependency, not an Ankabot runtime/API dependency.
- Windows/Dofus live acceptance remains PENDING until a fresh R5.139 run proves the transaction against the real client.

## 10. Packaging rules

- Windows + VS Code target.
- One ZIP, exactly one top-level project folder.
- Never package runtime, `.venv`, caches or unrelated temp data.
- Rebuild `PACKAGE_MANIFEST.json` after immutable changes.
- Compile source/tests and run current + affected parent regressions.
- Independently extract final ZIP and verify context/manifest/current release again.
- Keep live acceptance PENDING until actual Windows/Dofus evidence succeeds.

# ANKA R5.195 — New Chat Handoff

## Current candidate

R5.195 is the fight-entry geometry and incident-replay hardening candidate derived from the sealed R5.194 parent. Windows/Dofus live acceptance is still pending.

## Latest live incident

`runtime(20261015-174148).zip` proved both CRA and ENU entered the same fight (`279`) and reached PLACEMENT. No placement input was emitted. The first terminal boundary was `FIGHT_GEOMETRY_UNAVAILABLE` because current-build legal placement cells `317`, `330`, and `439` contradicted old static Mapuse fight-walkability flags.

## R5.195 repairs

- current canonical placement legality can override stale static walkability only inside the current fight generation;
- global static Kernel maps are never mutated;
- CharacteristicId `0` is representable for current fight bootstrap characteristic truth;
- production step-driven placement now consumes the same joint team plan as the synchronous compatibility path;
- CRA/ENU placement truth must converge before planning/input;
- unknown local placement cell/side waits input-free instead of becoming a terminal target failure;
- incident replay/shadow simulation is a permanent project subsystem;
- placement clicks have a final pre-mouse-down semantic/projection guard so phase/side/occupancy/projection drift during smooth pointer travel produces retryable `NOT_SENT` evidence rather than an unsafe click;
- current-release incident attestations are part of the immutable release-gate surface, so changed replay evidence cannot reuse stale resumed PASS rows.
- FightAI normal-policy decisions reuse one composite spell-decision service per invocation instead of rebuilding it across the 22-spell CRA profile; bounded-decision coverage is included in the quick release gate.
- release-verifier descendant-cleanup coverage is scheduler-robust, so a busy verification host cannot fail the release merely because the synthetic child did not spawn within a one-second precondition window.

## Offline replay tool

Run:

```text
python tools/replay_live_incident.py <runtime-or-incident.zip> --output replay.json
```

It emits no physical input. For the latest runtime, the captured chain passes protocol/canonical/shared-fight/geometry/Kernel/Projection/team-placement. A clearly labeled deterministic continuation then passes placement+Ready+ACTIVE, real FightAI returns a CRA MOVE to cell 202, and real action admission accepts path `[216, 202]`.

The capture itself ends in PLACEMENT. Synthetic continuation is not live evidence.

## Main R5.195 hotpaths

- `src/anka_platform/integration/fight_geometry.py`
- `src/anka_platform/integration/kernel_context.py`
- `src/anka_game_kernel/contexts/fight.py`
- `src/anka_game_kernel/domain/ids.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/placement_pre_down.py`
- `src/anka_platform/party/placement_coordination.py`
- `src/anka_platform/simulation/incident_replay.py`
- `src/anka_platform/simulation/preparation_shadow.py`
- `src/anka_platform/fight_ai/normal_policy.py`
- `tools/replay_live_incident.py`
- `tests/r5195/`

## Safety invariants

Canonical State remains semantic live truth. ExecutionService remains the only physical-input authority. InputArbiter remains the cross-account lease. Protocol wire semantics stay inside versioned adapters. Fight-scoped geometry overlays must never mutate or globally alias static maps. A synthetic replay result must never be represented as live server/Unity/input proof.

## Next live milestone

One bounded CRA+ENU acceptance run should test the first boundary absent from the capture: placement click acceptance -> Ready acknowledgements -> ACTIVE -> first real action settlement. If it fails, preserve the runtime ZIP and replay it offline before changing code.

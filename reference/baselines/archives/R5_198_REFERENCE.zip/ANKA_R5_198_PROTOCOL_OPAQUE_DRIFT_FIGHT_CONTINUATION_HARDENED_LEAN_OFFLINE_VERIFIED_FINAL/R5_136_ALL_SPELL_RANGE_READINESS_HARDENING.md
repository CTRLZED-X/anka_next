# R5.136 — All-Spell Readiness + Live Range/PO Hardening

R5.136 is a narrow successor to R5.135. It does not introduce a new combat runtime, a new input path, or any dependency on external bot frameworks. It audits the complete configured Cra + Enutrof combat bars and closes the generic live Range/PO evidence gap found during that audit.

## Why this checkpoint exists

R5.135 repaired the fight-343 stale-cooldown defect generically, but a full 44-spell audit exposed a separate integration issue affecting many modifiable-range spells: R4 publishes live Range/PO as characteristic `19`, while the Kernel context previously depended mainly on `CanonicalActorSnapshot.range_bonus`. A certified `jxh` characteristic-19 update could therefore exist in Canonical characteristic evidence without reaching the Kernel range input.

That defect is not specific to one spell. Of the 44 configured Cra + Enutrof grades, 31 have modifiable range.

## Configured bar audit

The current active profiles contain exactly:

- Cra: 22 enabled spells;
- Enutrof: 22 enabled spells;
- total: 44 configured grades.

The selected Static/Kernel grades contain:

- 44 AP-cost constraints;
- 29 positive per-turn limits;
- 14 positive per-target limits;
- 15 recast intervals;
- 3 initial cooldowns;
- 1 state criterion;
- 3 summon spells;
- 31 modifiable-range spells (Cra 16, Enutrof 15).

R5.136 adds a permanent regression that exercises every applicable readiness-rule instance across the complete configured bars. The current matrix contains 109 explicit readiness checks.

## Range/PO contract

For R4 live evidence:

- characteristic `19` is the certified Range/PO total when explicitly observed;
- `jxh` characteristic-19 updates emit both the generic characteristic observation and `FightStatsObserved.range_bonus`;
- an explicitly present characteristic-19 value in a `juo` actor snapshot is promoted the same way;
- `KernelContextAdapter` also consumes characteristic-19 from the canonical characteristic ledger when the convenience `range_bonus` field is absent, so old/replayed streams remain usable;
- absence of characteristic `19` is **not** interpreted as zero.

This keeps range legality fail-closed while allowing all 31 modifiable-range configured spells to consume one actor-level authoritative PO input rather than spell-specific range hacks.

## Spell-readiness architecture remains generic

No configured spell ID is special-cased in the readiness or execution admission path. Every CAST still passes through:

1. live/Static readiness (`LiveSpellReadinessService`);
2. deterministic Kernel legality;
3. `FightActionAdmissionService` immediately before slot input;
4. a second admission immediately before target input;
5. `ExecutionService`, the sole physical-input authority.

Cooldown, initial cooldown, AP, per-turn, per-target, state and target identity are shared rule families, not spell-name logic.

## Mechanics completeness

The bundled Kernel mechanics pack resolves the selected configured grade for all 44 spells. `KernelSpellFeatureCatalog` reports complete tactical mechanics for all configured grades. The per-spell mechanics suites remain the authority for geometry/effects/displacement/control behavior.

## Deliberate safety boundaries

Three configured Enutrof spells are summons: Sac Animé, Pelle Animée and Malle Animée. R5.136 does not invent a maximum summon capacity. Current summon count is certified, but maximum capacity is not yet an authoritative live input, so summon admission remains `UNKNOWN` / fail-closed when that capacity is required.

Likewise, a missing Range/PO observation is not silently converted to `0`. Fixed-range spells can continue to operate; modifiable-range legality remains incomplete until authoritative PO evidence exists.

These are explicit safety boundaries, not spell-specific readiness bugs.

## Independence

ANKA remains independent. External bot documentation/projects may inspire terminology or test scenarios, but production source and `pyproject.toml` contain no Ankabot runtime/API/documentation dependency.

## Live acceptance target

A Windows/Dofus R5.136 run should prove:

- cooldown/per-turn/per-target restrictions remain enforced across the whole bar;
- `jxh` characteristic-19 evidence updates Kernel range for the corresponding actor;
- a modifiable-range spell can be evaluated with the updated PO rather than remaining artificially UNKNOWN;
- no missing PO or summon-capacity evidence is guessed;
- Cra/Enu semantic-epoch synchronization and R5.135 two-stage admission remain intact.

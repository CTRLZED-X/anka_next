# R5.172 — Projection / Entity Resolution Hardening

## Live incident that motivated this release

The October 11 R5.171 Windows run successfully loaded bridge `2.2.73`, bound CRA and ENU processes, decoded live protocol traffic, recovered canonical map `190580738`, discovered the runtime `CustomGridGenerator`, and produced a structurally valid 560-cell projection. Launch nevertheless remained queued because party preflight globally required actor GameObjects named `entity_character_<entityId>`.

Current Dofus 3.7.7.6 no longer exposed those historical exact names. The live bridge therefore reported zero actor anchors even though protocol, grid, camera, map, capture and process identity were healthy. No physical input was sent.

Historical discovery evidence also showed why merely restoring a name lookup would be unsafe: monster-group root transforms could be tens or hundreds of world units away from the canonical CellId even when the player root happened to line up. Root object identity and clickable visual position are separate questions.

## R5.172 architectural repair

### 1. Projection geometry is certified independently

Startup projection authority no longer depends on arbitrary actor object names. It requires:

- authoritative canonical MapId / bridge map identity;
- runtime-discovered Dofus 560-cell converter with the existing finite/distinct semantic probe;
- gameplay camera and Dofus window;
- complete 560-cell projected table;
- at least two exact, active rendered `GraphicCells/cell::<id>` anchors that agree with the selected runtime cell converter and viewport.

Legacy actor-anchor counters remain diagnostic only.

### 2. Entity interaction is a separate action-time authority

Actions that name a concrete EntityId still fail closed. A centralized resolver now combines:

- canonical EntityId + current CellId;
- historical exact-name lookup only as a compatibility hint;
- signed hierarchy identity tokens, including negative world-group IDs such as `-20003`;
- reflected runtime numeric identity evidence;
- active-scene filtering;
- related visual children / renderer bounds;
- the exact active `cell::<CellId>` anchor;
- nearest-cell and planar-distance checks;
- viewport checks;
- uniqueness/ambiguity rejection.

The root Transform is never trusted merely because its object name looks correct.

### 3. Same authority is used by the real action boundary

`ProjectionService` and `ExecutionService` consume the same entity resolver. If identity/cell association cannot be proven, the result becomes `PROJECTION_ENTITY_UNVERIFIED`, physical send state remains `NOT_SENT`, and no window focus/click is authorized.

Cell-only movement/projection does not pay the entity-identity requirement.

### 4. Pending Launch can recover projection without input

When the only launch blockers are projection/cell-anchor convergence blockers, the pending-launch service can force a fresh canonical projection sync, request bounded bridge discovery, refresh health, and retry preflight. This path sends no physical input and is rate-limited to avoid a 0.5-second scan storm.

### 5. Multi-account discovery is process-scoped

CRA and ENU share one BepInEx config directory. The previous fixed discovery filename was therefore last-writer-wins. The bridge now writes:

`DofusCoordinateBridge.discovery.<PID>.json`

Debug export retains every process-scoped discovery and selects the candidate whose PID + process start time matches the bound process. Legacy fixed discovery files remain readable only for compatibility.

### 6. Discovery freshness is explicit

Diagnostics use the payload `generated_at_utc` rather than ZIP/file-copy mtime and compare process identity when available. Old scene evidence is marked `STALE` / `STALE_IDENTITY_MISMATCH` instead of silently appearing current.

### 7. First-time identity scans have their own timeout budget

A simple CellId lookup keeps the short normal HTTP budget. Entity/fight-entry resolution can reflect a larger Unity scene, so it receives a bounded 10-second Python client budget and 12-second Unity main-thread dispatch budget. Timeout is reported as resolver-not-ready, not as whole-bridge disappearance.

### 8. Protocol-health recovery initialization is hardened

A partially restored/legacy `LiveTransportRuntime` now backfills newer schema-drift and unknown-wire latch fields before applying transform health. Recovery can no longer crash with `AttributeError` simply because a newer sticky latch was absent on the restored object.

## Diagnostics objective

If the next Dofus build still prevents entity resolution, the first failed entity-target action automatically requests a bounded current scene discovery. The debug package contains the process-scoped discovery files, canonical entity/cell context, reflected candidates, exact-cell evidence, candidate rejection reasons, bridge/process identity and artifact freshness. The goal is one useful live failure package instead of repeated screenshot -> patch cycles.

## Safety rules retained

R5.172 does **not**:

- weaken Canonical State or Kernel legality;
- infer unknown protocol semantics;
- click a ground cell as a fallback for an unproven monster entity;
- retry a physical action whose send state is uncertain;
- accept inactive/stale Unity actor or cell objects;
- reintroduce Dofus-specific compile-time bridge DLL names;
- claim the five remaining packet-aligned ORACLE live-truth proofs are complete.

## Windows acceptance target

Fresh extraction -> `setup.bat` -> `start.bat` -> Script Studio -> Launch.

Expected startup behavior is that healthy cell projection can reach READY even if historical actor names are absent. When a concrete monster-group interaction is needed, entity identity must be proven then. If that cannot be proven, no click is sent and the resulting debug bundle should contain fresh per-process Unity discovery evidence.


## Additional systemic regressions closed during full-gate verification

The broad retained-release gate exposed several issues outside the immediate October 11 projection symptom. They were repaired at their authority boundaries rather than waived as historical-test noise:

- **Current-checkpoint recognition:** the project-context validator now recognizes R5.171/R5.172 and points the current-release hot path at `tests/r5172/`. Older release metadata checks no longer misclassify the current candidate as unsupported.
- **Portable bounded patrol readiness:** the configured four-map patrol no longer depends on a machine-specific arbitrary `Maps` directory. Readiness now proves every configured patrol coordinate and every loop edge directly from bundled `gamedata/Mapuse`. A missing optional external map library is a warning that arbitrary-zone expansion is unavailable, not a blocker for the fully bundled current route.
- **Windows operator contract:** documentation again states that `setup.bat` is a one-time setup step and that `start.bat` automatically detects available Dofus clients rather than requiring fixed character names.
- **Protocol-health recovery initialization:** partially restored legacy transport objects backfill newer schema-drift latch fields before health application, preventing a recovery-time `AttributeError`.
- **Entity resolver timeout attribution:** expensive first-time live identity scans have separate bounded client/Unity-dispatch budgets; a resolver timeout remains fail-closed and is not misreported as total bridge disappearance.

These checks are intentionally broader than the original Launch deadlock because the goal of R5.172 is that the next live run either succeeds or produces precise, current, process-scoped evidence at the actual failing boundary.

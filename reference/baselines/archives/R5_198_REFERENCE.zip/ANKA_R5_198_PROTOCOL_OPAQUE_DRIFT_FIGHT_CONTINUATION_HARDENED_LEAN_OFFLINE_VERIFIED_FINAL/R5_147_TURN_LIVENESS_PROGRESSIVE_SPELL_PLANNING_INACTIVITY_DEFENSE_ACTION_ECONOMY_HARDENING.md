# R5.147 — Turn Liveness, Progressive Spell Planning, Inactivity Defense & Action Economy

R5.147 is the systemic successor to R5.146. It is driven by `runtime(20260929-151057)` and the observed Dofus **Inactivité** modal. The runtime proved that CRA turn ownership and window activation were correct, yet CRA could spend entire turns producing no game action because repeated `SPELL_COVERAGE_INCOMPLETE` decisions restarted expensive search on the same semantic frame.

## Root cause closed

R5.146 correctly stopped certifying END_TURN when most spells were deeply unevaluated, but treated incomplete planner computation like missing external game evidence. The controller waited and retried; the planner restarted from the beginning; the battlefield had no reason to change; CRA could therefore self-deadlock for the whole turn.

R5.147 makes planner progress explicit:

- computational coverage/budget exhaustion is a planner-degraded replan, not evidence uncertainty;
- rejected/no-material spell work is retained across semantically identical frames;
- raw Canonical revision churn does not erase planner progress;
- AP/MP, positions, states/effects, action quarantine, turn identity and tactical-objective changes invalidate stale progress;
- ordinary incomplete coverage remains a non-terminal same-frame replan; only a proven planner no-progress/wall-clock stall may sacrifice the current turn through the normal certified END_TURN path, never the mission.

## Candidate-first Kernel legality

The old hot path could enumerate legality over all 560 combat cells for each spell, and safe-probe recovery could repeat that work. R5.147 adds `SpellDecisionService.evaluate_cast_cell(...)` and changes tactical planning to propose semantically relevant target cells first, then ask the Kernel about those exact cells.

Correctness remains fail-safe:

- direct enemy, ally/support and self targets are preserved;
- empty-cell AoE centers around relevant actors remain represented;
- free-cell mobility/summon surfaces retain every distance-plausible empty target, not a nearest-N sample;
- incomplete/unknown proposal mechanics fall back conservatively rather than declaring legal actions absent;
- the Kernel remains the legality authority and the optimization never bypasses ExecutionService admission.

## Turn liveness / inactivity defense

After exact account/window activation, each authoritative controlled turn may emit one `TURN_ACTIVITY_HEARTBEAT` through ExecutionService. It is a **cursor move only**, never a click and never a character MOVE. It is fenced by ControlAuthority, runtime health, exact-window activation, the input arbiter, pending settlement and uncertain-input quarantine.

This heartbeat is defense-in-depth. The primary fix is still planner liveness: CRA must act rather than merely keep the client awake.

The project intentionally does **not** click the Dofus inactivity modal by hard-coded screen coordinates. The current Unity bridge does not expose a sufficiently certified semantic identity for that exact modal. A modal-click recovery must wait for a trustworthy UI detector or fresh live evidence that prevention is insufficient.

## Tactical/action-economy hardening

- MOVE receives an early protected planning slice so CAST enumeration cannot starve repositioning.
- Spell evaluation order is influenced by tactical mode (setup, survival, burst/control) so relevant setup/support tools are not permanently hidden behind static spell priority.
- Serial MOVE actions receive an execution-complexity penalty; tiny positioning gains must justify another physical transaction.
- Existing R5.146 incomplete-coverage END_TURN protection remains intact for ordinary partial search; R5.147 adds a separate liveness fuse for proven planner stalls (default 5 slices / ~9 s, or repeated zero coverage progress).
- Existing physical-uncertainty quarantine/reconciliation remains intact; heartbeat is forbidden behind that fence.

## Offline regression target

The synthetic CRA stress state uses the complete configured 22-spell bar and eight enemies. R5.147 deeply evaluates 22/22 spells inside the decision budget and proves the 1-AP range setup option is evaluated and competes with damage/control actions instead of being hidden behind early slots. Progressive-slice tests additionally prove that later slices continue on unseen spells and resume inside one large target surface rather than restarting after harmless revision churn.

## Remaining explicit boundaries

R5.147 is not universal level-200 tactical certification. Exact tackle/lock, authoritative summon capacity/lineage, complete enemy dynamic HP/AP/MP truth, complete state/effect lifecycle and target-zone-specific monster mechanics remain explicit blockers. Inactivity-modal semantic detection is also not claimed.

## Live acceptance

The next Windows/Dofus run must prove that CRA and ENU receive one safe turn heartbeat at most, no repeated same-frame slot-1/target-1 restart occurs, useful CAST/MOVE candidates remain reachable under budget pressure, ordinary incomplete coverage replans progressively, only a proven planner stall can invoke the bounded turn-only END_TURN liveness fuse, no heartbeat/input crosses an uncertainty fence, and the campaign continues after recoverable planner degradation. Preserve the first complete runtime/debug package at any failure.

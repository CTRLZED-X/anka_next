# NEW CHAT HANDOFF — R5.162

Current workspace: **R5.162 Resource Causality, Pointer Interaction, Ready & Forensic Hardening**.

## Read first
1. `R5_162_RESOURCE_CAUSALITY_POINTER_INTERACTION_READY_FORENSIC_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `DEBUGGING.md`
5. `TESTING.md`
6. `LIVE_ACCEPTANCE.md`

## Why R5.162 exists
The R5.161 live runtime `runtime(20261003-231729).zip` completed **5/5 fights**, proving that the broad campaign/combat foundation is healthy, but it exposed three remaining acceptance failures and one forensic weakness:

- two CRA movement attempts were planned from stale remaining MP after a prior server-confirmed move;
- the first Ready interaction of every fight still produced no outbound Ready request even after the 3.75 s post-placement settle;
- R5.161 paths met the numeric ~2% curvature target but could still look like one mathematically clean arc;
- mutable window-driver diagnostics could still overwrite evidence unless every physical boundary committed its own immutable snapshot.

## R5.162 authority rules
- Canonical State owns observed game truth.
- Kernel owns deterministic legality/mechanics.
- FightAI owns tactical preference only.
- ExecutionService owns physical input and final live re-admission.
- A confirmed action whose decision-critical resources are not causally settled keeps the physical-action fence active.
- Exact certified endpoint safety outranks visual randomness.
- No arbitrary pixel jitter is added to a cell or spell target.

## Pointer Interaction V2
Keep the R5.161-calibrated primary curvature close to the operator sample instead of exaggerating every path. V2 adds a bounded late corrective submovement near the target, coherent timing asymmetry, and explicit model-version diagnostics. Randomness is chosen once per movement; there is no frame jitter. Very short corrections remain nearly straight. The final endpoint remains exact and the emitted-step contract remains <=24 px.

## Resource settlement rule
A newer AP/MP revision with the same pre-action value is **not** sufficient to settle a confirmed resource-spending action. Settlement requires either explicit resource-change evidence after the server-confirmed action or a newer authoritative numeric value below the pre-action baseline. MOVE and CAST use the same causal contract. Both the production runtime API and the typed compatibility movement API retain a pending-settlement fence until this condition is satisfied.

## Ready rule
The existing 3.75 s post-placement settle remains. Only the **first Ready interaction of the fight** adds a small default 0.35 s hover-only prime at the verified Ready control, then re-checks the exact fight/actor/semantic state before sending one click. This is not an extra click and does not weaken the bounded semantic retry logic.

## Live status
**OFFLINE VERIFIED CANDIDATE. Windows/Dofus R5.162 acceptance is PENDING.**

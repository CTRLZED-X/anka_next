# R5.185 — Startup / Launch / Window Ownership Foundation

**Status:** verification pending  
**Protocol assumption:** keep `dofus_3_6_12_16`; do not infer a protocol rewrite from the client version alone.

## Why R5.185 exists

The first real R5.184 Launch failed before FightAI or physical combat input. Pending Launch correctly decided that a launched runtime was required to acquire the initial Canonical MapId, but `CampaignRuntimeController` ran steady-state continuity first. `CANONICAL_STATE_NOT_CURRENT_SESSION` was therefore treated as fatal before the bootstrap designed to create the first Canonical baseline could execute.

The same incident also exposed three adjacent reliability defects: startup recovery was a broad boolean preflight bypass, the recovery decision was emitted under a different key than diagnostics consumed, and account switching blindly preferred configured F7/F8 AutoHotkey keys even though ANKA already owns exact HWND/PID identities. Runtime `__version__` also disagreed with package/release metadata.

## Implemented repairs

1. **Bootstrap-before-continuity under a narrow startup health gate.** The first map bootstrap may run before steady-state continuity only when every current health blocker is classified `EXPECTED_GAP` by the centralized startup blocker registry. Unknown/new, transport, schema, identity and execution faults still fail closed.
2. **Preflight-bound runtime recovery permit.** `RUNTIME_REQUIRED` can start a worker only when the second preflight contains no blocker that was absent from the passively approved blocker surface.
3. **Recovery evidence preservation.** Launch events now publish the canonical `recovery` field (with the historical alias retained), including the bound permit.
4. **Self-contained account switching.** Exact HWND/PID Win32 focus is primary. Configured activation hotkeys are ignored by default; a legacy external-hotkey fallback must be explicitly opted into.
5. **Release identity coherence.** `pyproject.toml`, `RELEASE_MANIFEST.json`, and runtime `anka_platform.__version__` are aligned, and release integrity checks all three.
6. **No protocol rewrite.** The supplied current-client map-transition capture replays through the existing adapter with zero unclassified/transform failures and the correct known MapIds, so R5.185 keeps the adapter unchanged.

## Next live acceptance

Use a fresh R5.185 extraction. Do not start `window.ahk`. From the configured start map, Apply/Launch once. The first campaign tick must reach `STARTUP / WORLD_MAP_BOOTSTRAP`, direct window activation must target the bound account HWND/PID, and the resulting map transition must establish Canonical MapId before normal continuity/world progression. Preserve the complete runtime package on either success or failure.

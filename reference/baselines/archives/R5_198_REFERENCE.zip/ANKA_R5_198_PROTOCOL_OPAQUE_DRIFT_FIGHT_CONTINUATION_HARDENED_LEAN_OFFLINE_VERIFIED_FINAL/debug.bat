@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    echo ANKA_SETUP_REQUIRED: run setup.bat once.
    exit /b 2
)
.venv\Scripts\python.exe -m anka_platform.cli debug export --last --config config.yaml
if errorlevel 1 exit /b %errorlevel%
echo.
echo Party-aware immutable debug bundle created under runtime\debug\incident_*.zip
endlocal

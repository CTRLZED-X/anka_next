@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

if not exist ".venv\Scripts\python.exe" (
  echo LIVE_CAPTURE_INSPECT=BLOCKED_ENVIRONMENT
  echo ERROR: Sealed Python environment is missing. Run setup.bat first.
  exit /b 2
)

set "PYTHONPATH=%CD%\src;%CD%"
".venv\Scripts\python.exe" tools\inspect_live_capture.py %*
exit /b %ERRORLEVEL%

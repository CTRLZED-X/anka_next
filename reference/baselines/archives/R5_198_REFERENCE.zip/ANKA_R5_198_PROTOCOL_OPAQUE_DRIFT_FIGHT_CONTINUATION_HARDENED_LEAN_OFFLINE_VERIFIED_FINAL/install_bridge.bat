@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

echo ANKA Unity Bridge Installer
echo ==============================

for %%P in (Dofus.exe DofusBeta.exe) do (
  tasklist /FI "IMAGENAME eq %%P" 2>nul | find /I "%%P" >nul
  if not errorlevel 1 (
    echo ERROR: %%P is running.
    echo Close Dofus completely before installing or replacing the bridge.
    exit /b 3
  )
)

if not defined BEPINEX_PATH (
  if defined LOCALAPPDATA if exist "%LOCALAPPDATA%\Ankama\Dofus-dofus3\BepInEx\" set "BEPINEX_PATH=%LOCALAPPDATA%\Ankama\Dofus-dofus3\BepInEx"
)
if not defined BEPINEX_PATH (
  if defined LOCALAPPDATA if exist "%LOCALAPPDATA%\Ankama\Dofus\BepInEx\" set "BEPINEX_PATH=%LOCALAPPDATA%\Ankama\Dofus\BepInEx"
)
if not defined BEPINEX_PATH (
  echo ERROR: BepInEx was not found in the standard Dofus folders.
  echo Set it explicitly, then rerun:
  echo   set "BEPINEX_PATH=C:\path\to\Dofus\BepInEx"
  exit /b 2
)

for %%I in ("%BEPINEX_PATH%") do set "BEPINEX_PATH=%%~fI"
echo BEPINEX_PATH=%BEPINEX_PATH%

if not exist "%~dp0unity_bridge\BUILD_BRIDGE.bat" (
  echo ERROR: unity_bridge\BUILD_BRIDGE.bat is missing. Extract the complete ANKA ZIP again.
  exit /b 2
)
if not exist "%~dp0tools\write_bridge_install_record.ps1" (
  echo ERROR: tools\write_bridge_install_record.ps1 is missing. Extract the complete ANKA ZIP again.
  exit /b 2
)
if not exist "%~dp0tools\write_bridge_environment_record.ps1" (
  echo ERROR: tools\write_bridge_environment_record.ps1 is missing. Extract the complete ANKA ZIP again.
  exit /b 2
)
if not exist "%~dp0runtime\" mkdir "%~dp0runtime" >nul 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\write_bridge_environment_record.ps1" -BepInExPath "%BEPINEX_PATH%" -OutputPath "%~dp0runtime\bridge_environment.json"
if errorlevel 1 (
  echo BRIDGE_ENVIRONMENT_RECORD=FAILED
) else (
  echo BRIDGE_ENVIRONMENT_RECORD=READY
  echo BRIDGE_ENVIRONMENT_RECORD_PATH=%~dp0runtime\bridge_environment.json
)

rem A new attempt must never inherit a stale successful install authority.
if exist "%~dp0runtime\bridge_install.json" del /q "%~dp0runtime\bridge_install.json" >nul 2>nul
if exist "%~dp0runtime\bridge_install.json" (
  echo ERROR: Could not invalidate the previous bridge install record.
  exit /b 2
)

call "%~dp0unity_bridge\BUILD_BRIDGE.bat"
if errorlevel 1 goto :bridge_build_failed

set "INSTALLED_DLL=%BEPINEX_PATH%\plugins\DofusCoordinateBridge\DofusCoordinateBridge.dll"
if not exist "%INSTALLED_DLL%" goto :bridge_build_failed
if not exist "%~dp0runtime\" mkdir "%~dp0runtime" >nul 2>nul
if not exist "%~dp0runtime\" goto :bridge_record_failed

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\write_bridge_install_record.ps1" -BepInExPath "%BEPINEX_PATH%" -InstalledDll "%INSTALLED_DLL%" -OutputPath "%~dp0runtime\bridge_install.json"
if errorlevel 1 goto :bridge_record_failed
if not exist "%~dp0runtime\bridge_install.json" goto :bridge_record_failed

echo.
echo BRIDGE_INSTALL_RECORD=READY
echo BRIDGE_INSTALL=SUCCESS
echo BRIDGE_INSTALL_RECORD_PATH=%~dp0runtime\bridge_install.json
echo Next: run start.bat to open Script Studio.
echo ANKA will automatically discover available Dofus windows and bind selected accounts when you press Launch.
echo Use run_anka.bat only when you deliberately want the explicit Windows certification/compatibility path.
exit /b 0

:bridge_record_failed
echo.
echo BRIDGE_INSTALL_RECORD=FAILED
echo BRIDGE_INSTALL=FAILED
echo ERROR: The bridge DLL may have been installed, but ANKA could not create its verified install record.
exit /b 1

:bridge_build_failed
echo.
echo BRIDGE_INSTALL=FAILED
exit /b 1

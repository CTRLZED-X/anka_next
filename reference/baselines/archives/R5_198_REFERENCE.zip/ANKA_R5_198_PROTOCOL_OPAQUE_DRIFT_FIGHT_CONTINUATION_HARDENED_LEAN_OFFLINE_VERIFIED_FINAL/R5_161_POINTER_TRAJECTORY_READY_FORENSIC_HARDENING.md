# R5.161 — Pointer Trajectory, Ready & Forensic Hardening

## Scope
This pass is driven by the R5.160 runtime `runtime(20261003-175125).zip` and the operator's sample of manually drawn point-to-point mouse trajectories. The objective is systemic reliability: fix the first failed boundary, retain existing authority contracts, and make one future runtime bundle sufficient to diagnose remaining live issues.

## What the live run proved
The campaign completed **5/5 wins**, with no terminal mission failure. Capture generation remained clean and the planner completed without budget overruns. This is not evidence of a global combat-foundation failure.

The same run still showed persistent quality/reliability defects:

1. **Pointer curvature was too weak.** The R5.160 pointer ledger contained 87 visible motion records with 100% exact arrival, but primary lateral amplitude had a median of only about 0.11 px and a p95 under 5 px. Replaying the V1 planner over live distances produced a median maximum chord deviation around 0.8%, while the operator's 43 manual samples centered around roughly 2.1%.
2. **`max_step_pixels` was not actually guaranteed.** Sampling by `distance/max_step` ignored that minimum-jerk forward velocity peaks at 1.875x its average normalized velocity. Representative medium/long plans could therefore emit ~44–45 px jumps despite a 24 px setting.
3. **Initial Ready interaction remained systematically early.** CRA's first Ready attempt failed to emit `READY_REQUEST` in all five fights; the later bounded retry succeeded. The pattern is consistent with a post-placement Ready-UI interactivity delay, not a random combat failure.
4. **Pointer diagnostics were incomplete.** The live action stream contained 107 logical CAST results, but the R5.160 pointer-health exporter recovered pointer evidence for only a small subset because it queried mutable driver diagnostics after later focus/identity/settlement work had overwritten the physical-motion record.
5. **MOVE contained latent CAST-only PRE_DOWN state.** A duplicated safe-endpoint branch inside `_move_fight` referenced CAST-specific `pre_down_cast_block` state. The preceding MOVE branch normally made it unreachable, but the duplicate was structurally unsafe.

## Pointer trajectory redesign
R5.161 keeps minimum-jerk forward progression because the desired motion is smooth slow-fast-slow, not noisy wandering. The lateral shape is changed from a signed uniform sample through zero to a distance-banded coherent model:

- under ~24 px: effectively straight;
- 24–160 px: curvature ramps smoothly with distance;
- medium/long travel: primary maximum lateral deviation is selected between approximately 1.2% and 3.0% of the chord, capped at 16 px;
- a smaller second low-frequency bend adds mild asymmetric correction without frame-level noise;
- random sign, magnitude, timing skew and correction are selected once per movement;
- exact start and exact target remain mathematical invariants.

This deliberately does **not** copy the most extreme hand-drawn samples. The operator sample is calibration evidence, not a command to maximize zig-zag. The production target is a small coherent curve that resembles ordinary aimed hand motion while keeping the pointer path bounded and reliable.

### Calibration check
The 43 operator-drawn trajectories were measured against their own start-to-end chords. Median maximum perpendicular deviation was about **2.14%**, mean about **2.60%**, p95 about **5.04%**, with the visible examples spanning approximately **0.82-5.30%**. This supported increasing the old near-zero median curvature, but not turning every movement into a visibly wavy path. Independent R5.161 sweeps place representative medium/long trajectories around a ~2% median chord deviation while preserving a hard 16 px absolute cap.

### Spatial continuity fix
The planner now budgets samples against the minimum-jerk peak derivative plus curvature/rounding margin. The normal bounded plan budget is increased to 512 samples and the long-distance duration ceiling to 0.75 s; this does not change the timing of the sub-700 px motions observed in the supplied R5.160 client, but it keeps 4K-class cross-screen plans within the 24 px emitted-step contract. The actual maximum emitted step and effective emission rate are persisted in diagnostics. If an extreme target still cannot satisfy `max_step_pixels` inside the bounded plan budget, planning fails closed with `INPUT_POINTER_PLAN_UNSAFE` **before the cursor moves** rather than silently violating the contract.

## Endpoint safety is unchanged
No arbitrary pixel jitter is added to a cell/spell target. The Unity projection bridge currently certifies an exact point and, in current evidence, does not provide multiple certified safe alternatives. Therefore R5.161 varies the **path**, not the click destination. Safe endpoint variation remains enabled only when the bridge supplies multiple certified points.

## Ready timing hardening
The default Ready UI quiescence is increased from 1.25 s to 2.75 s while retaining the 1.00 s control settle. This changes the configured effective post-placement settle from 2.25 s to **3.75 s** before normal Ready arming. Measured from the final placement confirmation in the supplied R5.160 runtime, CRA's failed first Ready sends occurred at about **3.48-3.61 s**, ENU's first successful Ready sends at about **4.72-4.87 s**, and CRA's successful retries at about **5.95-6.05 s**. The added 1.50 s therefore moves the normal first interaction beyond the observed dead interval while preserving the existing bounded retry/semantic-confirmation path.

Ready action diagnostics now export placement age plus the control-settle, UI-quiescence and effective-settle values so a future bundle can distinguish timing, focus and semantic causes without guessing.

## Physical-input forensic hardening
Driver `debug_status()` is mutable. R5.161 no longer treats a later snapshot as authoritative evidence for an earlier click.

ExecutionService now snapshots pointer/input evidence immediately after the relevant physical send boundary and stores it in the action result for:

- CAST spell-slot click;
- CAST target click;
- combat MOVE;
- END_TURN;
- placement;
- heartbeat;
- existing Ready/join/launch evidence paths where available.

The pointer exporter prefers this explicit evidence and uses ambient mutable state only as a backwards-compatibility fallback. Duplicate explicit observability rows are de-duplicated without ever falling back to stale ambient driver state. Pointer-health schema v2 records the evidence source and actual path geometry: max chord deviation, deviation fraction, path length and tortuosity. It also distinguishes planned emission density from the rate actually achieved during the motion, so scheduler delay cannot be mistaken for planner intent.

This fixes a major one-bundle diagnostic weakness: the next incident package can show what pointer path actually belonged to each physical phase instead of whatever the input driver happened to report later. In particular, CAST target-pointer evidence is captured before PRE_DOWN abort neutralization, so a correct `NOT_SENT` mouse-DOWN decision can coexist with durable evidence of the smooth target-pointer travel that already occurred.

## Defects intentionally not "fixed" by guessing
The R5.160 run still reports incomplete level-200 truth such as HP/max-HP, enemy AP/MP, effect/state lifecycle, summon capacity and exact tackle/lock mechanics. Those remain explicit truth gaps. Repeated effect payload instances are not deduplicated because authoritative apply/refresh/stack/expire/remove lifecycle semantics are still incomplete.

Likewise, semantic frame drift that actually changed relevant combat facts remains a valid fail-close result. R5.161 does not weaken semantic/projection PRE_DOWN guards to reduce such blocks.

## Next live acceptance criteria
A single controlled R5.161 run should demonstrate all of the following:

- medium/long paths visibly curve but remain bounded; very short paths remain nearly straight;
- no click is sent after focus/interference/PRE_DOWN failure;
- all successful pointer transactions arrive exactly at the certified endpoint;
- CRA and ENU first Ready interactions produce outbound Ready semantics without the systematic first-CRA miss;
- the pointer ledger contains explicit boundary evidence for both phases of successful CAST transactions and for MOVE/END_TURN/placement/Ready/launch/join where physically exercised;
- campaign/network continuity semantics remain unchanged;
- any remaining problem has a precise first-missing boundary and durable evidence in the same runtime bundle.

## Live status
**OFFLINE CANDIDATE ONLY. Windows/Dofus acceptance is PENDING.**

# R5.144 — Fight Foundation, State Interaction & Team-AI Hardening

## Purpose

R5.144 is the second foundation pass after R5.143. It preserves the R5.142/R5.143 action-contract, quarantine, failure-disposition and turn-liveness rules, then addresses the live evidence gaps that were starving FightAI and making otherwise recoverable client interaction failures too expensive.

The release is intentionally a **Windows/Dofus live candidate**, not a claim of production or level-200 tactical certification. Live acceptance remains mandatory.

## Trigger evidence

The primary trigger is `runtime(20260927-172212)` plus the supplied level-200 CRA and ENU DofusLab builds.

Confirmed evidence driving this release:

- recoverable client-side cast rejection must not kill the mission (fixed in R5.143 and preserved here),
- baseline Range/PO can be absent even though later characteristic-19 updates are authoritative current totals,
- missing local-player/summon classification unnecessarily blocked ally-support spells,
- equivalent Kernel-legal empty AoE centres are not equally reliable physical click surfaces,
- partial/live-required outcome projection could hide a tactically certified required impact,
- several CRA support/trade-off spells were not represented by a sufficiently semantic utility model,
- build affinity belonged in configuration, not hardcoded policy role logic,
- minimum-range increases must not be scored as if they were maximum-range reach,
- all configured spells must retain explicit per-cycle disposition evidence.

## Foundation changes

### 1. Certified cross-account player identity

For synchronized required account lanes in the same fight, each lane's authoritative local actor ID may certify that actor as a PLAYER/non-summon in the decision-only combat frame. This does not infer identity from appearance or team color and does not replace Canonical State authority.

This removes false ally/summon ambiguity for support spells such as CRA Tirs Éloignés while keeping contradictory identity fail-closed.

### 2. Strictly bounded client-validation probe

A new safe-probe contract may resolve only two narrow UNKNOWN families:

- missing modifiable Range/PO baseline: planning/admission may test `range_bonus = 0` as a **client-validation baseline**, without claiming it is live truth;
- incomplete states for a criterion composed exclusively of `state absent` requirements: planning/admission may test the absence assumption without claiming Canonical completeness.

The probe never overrides a strict REJECTED result and never guesses unknown AP, cooldowns, summon capacity, target identity, positive hidden-state requirements, effect semantics or uncertain physical input.

The same assumptions are serialized in FightDecision and independently reconstructed/revalidated at PRE_SLOT/PRE_TARGET admission. A mismatch fails closed.

Probe metadata is deliberately excluded from canonical ActionKey identity. A rejected probed action therefore cannot evade same-turn quarantine by being relabeled STRICT.

### 3. Legal target vs physical interaction preference

Kernel legality remains authoritative. R5.144 adds a non-authoritative interaction preference only after a cell is already Kernel-legal:

1. occupied actor cell — neutral preference; never penalized by walkability,
2. empty fight-walkable cell — preferred,
3. empty non-walkable/unknown cell — neutral/less preferred.

This is a tie-break/utility term, not a new legality rule. It addresses the live Bêche des Anciens pattern without banning valid spell cells.

### 4. Required-impact certification under incomplete outcome projection

ActionIntent-required actor/effect orders can now be certified independently from unrelated live-required outcome details. A candidate remains executable only when every required impact step is present and sufficiently certified. Missing/uncertain required impacts remain UNKNOWN.

This prevents unrelated historical/live outcome inputs from erasing an otherwise certified tactical target effect.

### 5. Mechanics-driven buff/trade-off utility

FightAI now consumes certified effect semantics instead of spell-ID exceptions for offensive characteristic buffs and debuffs. Positive self/ally offensive effects and enemy offensive debuffs receive explicit utility. A harmful self effect may be treated as a certified trade-off only when it is solely a negative Range effect paired with a certified positive offensive self buff.

This makes Tirs Puissants eligible through its actual mechanics (+Power/+crit/+pushback damage with -Range trade-off) without introducing a Tirs-Puissants-specific branch.

Sentinelle likewise receives setup utility from certified distance-damage/Range effects while reveal-only effects no longer fabricate enemy focus-fire evidence.

### 6. Range-bound semantics

`SPELL_RANGE_CHANGE(maximum, +N)` is reach support.

`SPELL_RANGE_CHANGE(minimum, +N)` creates a dead zone and is tracked as `minimum_range_increase`, a tactical cost rather than support.

This allows Tirs Éloignés to value its maximum-range gain while pricing its minimum-range increase instead of adding both together as a pure bonus.

### 7. Build-aware but legality-independent scoring

Combat profiles now expose `preferred_damage_elements`.

Current live profiles:

- CRA: `water`, `earth`
- ENU: `water`

This is static strategy metadata derived from the supplied builds. It influences damage ranking only. It never supplies live AP/MP/PO, current characteristics, cooldowns, resistances, target legality or other runtime truth.

### 8. Tactical target correctness and MP-steal semantics

Only actors receiving a certified material hostile effect may become tactical enemy targets/ActionIntent impacts. Incidental reveal/support effects no longer inflate focus-fire or target identity. MP steal is treated as material MP control.

### 9. Preserved mission-liveness boundary

R5.143 remains authoritative for failure disposition:

- certified no-semantic-request client cast rejection -> forensic capture + quarantine/replan/turn recovery,
- pre-input FightAI exception/malformed decision -> contained to the turn and normal-gated END_TURN fallback,
- uncertain physical input/control/window/generation identity -> hard fence and reconcile; never blindly continue.

## Deliberately unsupported / fail-closed

R5.144 does **not** pretend the following are solved:

- controlled summon turns are not owned end-to-end, so summon-producing actions remain non-scoring/fail-closed where required;
- unknown summon capacity is not probed;
- exact tackle/lock movement remains unsupported where the Kernel reports that limitation;
- arbitrary state add/remove valence is not guessed;
- complex mixed team trade-offs such as Avarice, Corruption and Retraite Anticipée still require richer semantic/team-horizon policy before level-200 certification;
- the adaptive enemy capability catalog is not yet a complete level-200 monster-mechanics knowledge base.

These limitations are intentional safety boundaries, not silent planner omissions.

## FightAI architecture direction

R5.144 keeps the replaceable policy registry/boundary and moves new logic into dedicated modules rather than growing spell-ID branches inside execution:

- `tactical/buff_utility.py` — certified buff/trade-off semantics,
- `tactical/interaction.py` — physical target-surface preference,
- `integration/safe_cast_probe.py` — bounded incomplete-evidence probe contract,
- `integration/action_feasibility.py` — required-impact certification,
- `tactical/spell_features.py` — Kernel-derived tactical feature catalog.

`TacticalPolicyV1` remains the current policy orchestrator and is still larger than the desired long-term planner decomposition. The next strategy-focused generation can replace/refactor it behind the existing FightAI contract without changing Kernel or ExecutionService authority.

## Live acceptance focus

A fresh Windows/Dofus run must prove:

1. a certified `CLIENT_CAST_REJECTED` does not disarm ControlAuthority;
2. the rejected ActionKey is quarantined and the same turn replans or safely END_TURNs;
3. next-turn ownership advances and the campaign remains alive;
4. an unknown baseline Range spell may use only the bounded base-range probe and is revalidated again at execution;
5. the 44 configured spell dispositions remain visible;
6. Tirs Éloignés/Tirs Puissants/Sentinelle can appear as candidates when mechanics and current state permit;
7. equivalent legal AoE target cells prefer reliable walkable empty anchors without banning actor/non-walkable legal targets;
8. uncertain physical input still fences.

Windows/Dofus live acceptance remains **PENDING** until those conditions are demonstrated from a fresh runtime package.


## Final offline verification

The final working tree passes the bounded release lineage from R5.116 through R5.144 and the fight-critical execution, party, protocol, state, observability, projection, integration, application, web, platform/startup and scripting groups recorded in `verification/R5_144_OFFLINE_VERIFICATION.md`. Oversized timed-out aggregate commands are explicitly excluded from pass evidence. Windows/Dofus live acceptance remains pending.

> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# R5.198 current architecture delta

The authority model is unchanged: Canonical State owns semantic live truth; Kernel owns deterministic mechanics; FightAI proposes semantic actions; ExecutionService is the only physical-input authority; InputArbiter serializes cross-account input; Projection owns UI/geometry evidence; versioned protocol adapters own wire semantics.

## Exact opaque wire boundary

Unknown protocol traffic remains a fail-closed runtime-health condition. The adapter may classify an observed message as catalog-only opaque only when direction, payload size, and SHA-256 exactly match sealed evidence. Such a message transforms to zero Canonical events and cannot influence gameplay state. A changed variant immediately falls back to unclassified traffic.

## Evidence authority split

Raw PCAP owns byte fidelity, TCP reassembly/framing, wire classification, adapter transformation, and reducer proof for captured bytes. Durable per-account Canonical journals own exact persisted live-revision reconstruction where capture bootstrap does not contain the entire prior Canonical history. Incident replay reports these evidence classes separately instead of conflating them.

## Inherited boundaries

R5.197 control-plane takeover remains fail-closed and R5.196 causal resource floors, CRA→ENU handoff protection, semantic/geometry separation, strict post-action settlement, and zero-input systemic simulation remain authoritative.

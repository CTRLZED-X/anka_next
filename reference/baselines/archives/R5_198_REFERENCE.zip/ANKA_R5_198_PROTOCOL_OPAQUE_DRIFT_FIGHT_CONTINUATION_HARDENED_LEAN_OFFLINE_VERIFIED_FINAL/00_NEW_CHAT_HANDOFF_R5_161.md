# NEW CHAT HANDOFF — R5.161

Current workspace: **R5.161 Pointer Trajectory, Ready & Forensic Hardening**.

## Read first
1. `R5_161_POINTER_TRAJECTORY_READY_FORENSIC_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `DEBUGGING.md`
5. `TESTING.md`
6. `LIVE_ACCEPTANCE.md`

## Why R5.161 exists
The R5.160 live session `runtime(20261003-175125).zip` reached **5/5 wins** and showed that the foundation is substantially healthier, but it also exposed four concrete defects that should be fixed before another acceptance run:

- medium/long pointer travel is still visually too straight because the signed lateral amplitude was sampled through zero and capped too conservatively;
- `max_step_pixels` was not a true emitted-step bound under the peak derivative of the minimum-jerk curve;
- CRA's first Ready click repeatedly produced no outbound `READY_REQUEST`, while the later retry succeeded;
- pointer forensics sampled mutable driver state after semantic settlement, so most physical CAST trajectories were absent from the exported pointer ledger.

A latent MOVE PRE_DOWN copy/paste block referencing CAST-only state was also removed.

## Authority rules retained
- Canonical State owns observed game truth.
- Game Kernel owns deterministic legality/mechanics.
- FightAI/TeamStrategy owns tactical preference only.
- ExecutionService owns physical input and final live re-admission.
- One possible/sent physical transaction must reconcile before another is authorized.
- Exact endpoint safety outranks visual randomness.
- Network continuity remains parent-owned and fail-closed under R5.158.

## New pointer rule
Use coherent per-motion randomness, not per-frame jitter. Short corrections are almost straight; medium/long moves receive a bounded smooth bend selected once for the trajectory. Preserve minimum-jerk slow-fast-slow progression and exact endpoint arrival. Do not invent target-coordinate noise. The planner records actual maximum emitted step/effective emission rate and fails closed before movement if an extreme target cannot satisfy the configured spatial-step contract within its bounded sample budget.

## Ready rule
The default post-placement settle is now **3.75 s** (1.00 s control settle + 2.75 s UI quiescence), after which the existing per-window arming and semantic Ready confirmation/retry state machine remains authoritative. In the supplied R5.160 run, failed first CRA sends occurred ~3.48-3.61 s after final placement confirmation and the first successful ENU sends ~4.72-4.87 s, so the extra margin is evidence-driven. Do not replace this with blind repeated clicks.

## Current acceptance status
Source-tree offline verification is **PASS (1,206/1,206 current-gate tests)**. Windows/Dofus live acceptance remains **PENDING**. The next live bundle must prove first-attempt Ready semantics and explicit per-phase pointer evidence, not merely show that the campaign eventually wins.

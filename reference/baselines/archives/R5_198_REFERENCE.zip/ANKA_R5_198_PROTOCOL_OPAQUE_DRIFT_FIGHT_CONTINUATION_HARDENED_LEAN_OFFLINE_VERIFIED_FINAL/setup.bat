@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

echo ========================================
echo ANKA COMPLETE ONE-TIME SETUP
echo ========================================
echo.

if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
set "SETUP_STAGE=PREFLIGHT"
> "runtime\environment\setup_stage.txt" echo STAGE=PREFLIGHT

for %%P in (Dofus.exe DofusBeta.exe) do (
  tasklist /FI "IMAGENAME eq %%P" 2>nul | find /I "%%P" >nul
  if not errorlevel 1 (
    echo SETUP_PREFLIGHT=FAILED
    echo ERROR: Close Dofus completely before running setup.bat.
    goto :setup_failed
  )
)
echo SETUP_PREFLIGHT=READY

set "BASE_PYTHON="

set "SETUP_STAGE=PYTHON"
> "runtime\environment\setup_stage.txt" echo STAGE=PYTHON
echo [1/6] Python 3.13.x
py -3.13 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>nul
if not errorlevel 1 set "BASE_PYTHON=py -3.13"
if not defined BASE_PYTHON (
  python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>nul
  if not errorlevel 1 set "BASE_PYTHON=python"
)
if not defined BASE_PYTHON (
  echo PYTHON_VERSION=FAILED
  echo ERROR: This sealed release requires Python 3.13.x.
  echo Install Python 3.13 x64, then rerun setup.bat.
  goto :setup_failed
)
echo PYTHON_VERSION=READY

echo.
echo [1b/6] Sealed release identity
if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
%BASE_PYTHON% tools\verify_release_integrity.py --sealed --json-output runtime\environment\release_integrity.json
if errorlevel 1 (
  echo RELEASE_INTEGRITY=FAILED
  echo ERROR: This extracted ANKA release is internally inconsistent. Do not install dependencies from it.
  echo RELEASE_INTEGRITY_RECORD=%~dp0runtime\environment\release_integrity.json
  goto :setup_failed
)
echo RELEASE_INTEGRITY=READY

echo.
echo [1c/6] Unity bridge source preflight
%BASE_PYTHON% tools\verify_unity_bridge_source.py --json-output runtime\environment\bridge_source_preflight.json
if errorlevel 1 (
  echo BRIDGE_SOURCE_PREFLIGHT=FAILED
  echo ERROR: The shipped Unity bridge source failed its compile-risk/static contract preflight.
  echo BRIDGE_SOURCE_PREFLIGHT_RECORD=%~dp0runtime\environment\bridge_source_preflight.json
  goto :setup_failed
)
echo BRIDGE_SOURCE_PREFLIGHT=READY

echo.
set "SETUP_STAGE=VENV"
> "runtime\environment\setup_stage.txt" echo STAGE=VENV
echo [2/6] Virtual environment
if exist ".venv\Scripts\python.exe" (
  .venv\Scripts\python.exe -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>nul
  if errorlevel 1 (
    echo Existing .venv uses an unsupported or broken Python. Recreating it...
    rmdir /s /q ".venv"
    if exist ".venv\" (
      echo VENV=FAILED
      echo ERROR: Could not remove the generated .venv directory.
      goto :setup_failed
    )
  )
)
if not exist ".venv\Scripts\python.exe" (
  %BASE_PYTHON% -m venv ".venv"
  if errorlevel 1 (
    echo VENV=FAILED
    echo ERROR: Python could not create .venv.
    goto :setup_failed
  )
)
.venv\Scripts\python.exe -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,13) else 1)" >nul 2>nul
if errorlevel 1 (
  echo VENV=FAILED
  echo ERROR: .venv did not validate as Python 3.13.x.
  goto :setup_failed
)
echo VENV=READY
.venv\Scripts\python.exe tools\write_setup_environment.py --project-root "%ANKA_PROJECT_ROOT%" --output runtime\environment\setup_environment.json
if errorlevel 1 echo SETUP_ENVIRONMENT_RECORD=WARNING

echo.
set "SETUP_STAGE=DEPENDENCIES"
> "runtime\environment\setup_stage.txt" echo STAGE=DEPENDENCIES
echo [3/6] ANKA dependencies and capture support
.venv\Scripts\python.exe -m pip --version >nul 2>nul
if errorlevel 1 (
  echo DEPENDENCIES=FAILED
  echo ERROR: The Python 3.13 virtual environment does not contain a working pip installer.
  goto :setup_failed
)
set "ANKA_PIP_SOURCE="
if exist "requirements\wheelhouse\WHEELHOUSE_MANIFEST.json" (
  .venv\Scripts\python.exe tools\build_runtime_wheelhouse.py --verify >nul 2>nul
  if errorlevel 1 (
    echo DEPENDENCIES=FAILED
    echo ERROR: Local runtime wheelhouse exists but failed SHA-256 verification.
    goto :setup_failed
  )
  set "ANKA_PIP_SOURCE=--no-index --find-links=requirements\wheelhouse"
  echo DEPENDENCY_SOURCE=VERIFIED_LOCAL_WHEELHOUSE
) else (
  echo DEPENDENCY_SOURCE=PYPI_OR_LOCAL_PIP_CACHE
)
.venv\Scripts\python.exe -m pip install --log runtime\environment\pip_install.log --disable-pip-version-check --retries 2 --timeout 45 %ANKA_PIP_SOURCE% "setuptools==82.0.1"
if errorlevel 1 (
  echo DEPENDENCIES=FAILED
  echo ERROR: Could not install the release-pinned setuptools build backend.
  if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
  .venv\Scripts\python.exe tools\dependency_network_probe.py --output runtime\environment\dependency_network.json
  echo If DEPENDENCY_NETWORK=DNS_FAILED, fix Internet/DNS and rerun setup.bat.
  goto :setup_failed
)
.venv\Scripts\python.exe -m pip install --log runtime\environment\pip_install.log --disable-pip-version-check --retries 2 --timeout 45 %ANKA_PIP_SOURCE% --no-build-isolation -c "requirements\anka-constraints.txt" ".[capture]"
set "ANKA_RUNTIME_INSTALL_RC=%ERRORLEVEL%"
if exist "build" rmdir /s /q "build" >nul 2>nul
for /d %%D in ("src\*.egg-info") do if exist "%%~fD" rmdir /s /q "%%~fD" >nul 2>nul
if not "%ANKA_RUNTIME_INSTALL_RC%"=="0" (
  echo DEPENDENCIES=FAILED
  echo ERROR: ANKA live/runtime dependency installation failed against the current release exact-version constraints.
  echo Developer/test packages such as pytest are NOT required by setup.bat.
  echo Normal setup uses a non-editable runtime install to avoid editor/language-server coupling.
  if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
  .venv\Scripts\python.exe tools\dependency_network_probe.py --output runtime\environment\dependency_network.json
  echo If DEPENDENCY_NETWORK=DNS_FAILED, fix Internet/DNS and rerun setup.bat; no project/runtime state was launched.
  goto :setup_failed
)
.venv\Scripts\python.exe -c "import fastapi,pydantic,scapy,uvicorn,yaml; import anka_platform,anka_game_kernel" >nul 2>nul
if errorlevel 1 (
  echo DEPENDENCIES=FAILED
  echo ERROR: Installed ANKA dependencies could not be imported.
  goto :setup_failed
)
.venv\Scripts\python.exe -m anka_platform.setup_verify dependency-baseline --baseline requirements\DEPENDENCY_BASELINE.json --output runtime\environment\dependency_baseline.json
if errorlevel 1 (
  echo DEPENDENCIES=FAILED
  echo ERROR: Installed dependency versions do not match the current release baseline.
  echo DEPENDENCY_BASELINE_RECORD=%~dp0runtime\environment\dependency_baseline.json
  goto :setup_failed
)
echo DEPENDENCIES=READY
echo DEPENDENCY_BASELINE=READY
set "SETUP_STAGE=RUNTIME_INSTALL_CONTRACT"
> "runtime\environment\setup_stage.txt" echo STAGE=RUNTIME_INSTALL_CONTRACT
.venv\Scripts\python.exe tools\runtime_install_contract.py write --root "%ANKA_PROJECT_ROOT%" --record runtime\environment\runtime_install_contract.json --mode NON_EDITABLE_RUNTIME > runtime\environment\runtime_install_contract.log 2>&1
set "RUNTIME_INSTALL_RC=%ERRORLEVEL%"
type runtime\environment\runtime_install_contract.log
if not "%RUNTIME_INSTALL_RC%"=="0" (
  echo RUNTIME_INSTALL_CONTRACT=FAILED
  echo ERROR: ANKA could not bind the installed runtime to this exact source/protocol release.
  goto :setup_failed
)
echo RUNTIME_INSTALL_CONTRACT=READY

set "SETUP_STAGE=PROTOCOL_UPGRADE_CONTRACT"
> "runtime\environment\setup_stage.txt" echo STAGE=PROTOCOL_UPGRADE_CONTRACT
.venv\Scripts\python.exe tools\verify_protocol_upgrade_contract.py --json-output runtime\environment\protocol_upgrade_contract.json > runtime\environment\protocol_upgrade_contract.log 2>&1
set "PROTOCOL_UPGRADE_RC=%ERRORLEVEL%"
type runtime\environment\protocol_upgrade_contract.log
if not "%PROTOCOL_UPGRADE_RC%"=="0" (
  echo PROTOCOL_UPGRADE_CONTRACT=FAILED
  echo ERROR: Active protocol package failed the release upgrade contract.
  goto :setup_failed
)
echo PROTOCOL_UPGRADE_CONTRACT=READY

echo.
echo [3a/6] Existing ANKA control-plane ownership preflight
set "SETUP_STAGE=CONTROL_PLANE_PREFLIGHT"
> "runtime\environment\setup_stage.txt" echo STAGE=CONTROL_PLANE_PREFLIGHT
.venv\Scripts\python.exe tools\control_plane_preflight.py --config config.yaml --output runtime\environment\control_plane_preflight.json
if errorlevel 1 echo CONTROL_PLANE_PREFLIGHT=WARNING
echo Setup does not terminate or replace any existing server; start.bat remains the ownership authority.

echo.
echo [3b/6] Server supervisor process/quoting self-test
.venv\Scripts\python.exe -m anka_platform.server_supervisor --self-test --runtime runtime
if errorlevel 1 (
  echo SERVER_SUPERVISOR_SELF_TEST=FAILED
  echo ERROR: ANKA could not validate the current Python/Windows process ownership model.
  echo SELF_TEST_REPORT=%~dp0runtime\startup\supervisor_self_test.json
  goto :setup_failed
)
echo SERVER_SUPERVISOR_SELF_TEST=READY

echo.
set "SETUP_STAGE=BRIDGE"
> "runtime\environment\setup_stage.txt" echo STAGE=BRIDGE
echo [4/6] Unity bridge build, install, and identity record
if not exist "%~dp0runtime\" mkdir "%~dp0runtime" >nul 2>nul
set "BRIDGE_ATTEMPT_LOG=%~dp0runtime\bridge_install_attempt.log"
call "%~dp0install_bridge.bat" > "%BRIDGE_ATTEMPT_LOG%" 2>&1
set "BRIDGE_INSTALL_RC=%ERRORLEVEL%"
type "%BRIDGE_ATTEMPT_LOG%"
if not "%BRIDGE_INSTALL_RC%"=="0" (
  echo BRIDGE_INSTALL=FAILED
  echo BRIDGE_INSTALL_ATTEMPT_LOG=%BRIDGE_ATTEMPT_LOG%
  goto :setup_failed
)
if not exist "%~dp0runtime\bridge_install.json" (
  echo BRIDGE_INSTALL=FAILED
  echo ERROR: runtime\bridge_install.json was not created.
  goto :setup_failed
)
.venv\Scripts\python.exe -m anka_platform.setup_verify bridge-record "%~dp0runtime\bridge_install.json"
if errorlevel 1 (
  echo BRIDGE_INSTALL=FAILED
  goto :setup_failed
)
echo BRIDGE_RECORD=READY
echo BRIDGE_INSTALL=READY

echo.
set "SETUP_STAGE=STATIC_MAPS"
> "runtime\environment\setup_stage.txt" echo STAGE=STATIC_MAPS
echo [5/6] Patrol Mapuse + CellId static readiness
.venv\Scripts\python.exe -m anka_platform.setup_verify patrol-maps --config config.yaml --output runtime\map_readiness\static_patrol_index.json
if errorlevel 1 (
  echo PATROL_MAP_READINESS=FAILED
  goto :setup_failed
)
echo PATROL_MAP_READINESS=READY

echo.
echo [5b/6] Packaged script UI/calibration contract
.venv\Scripts\python.exe -m anka_platform.setup_verify ui-contract --config config.yaml
if errorlevel 1 (
  echo UI_CONTRACT_READINESS=FAILED
  goto :setup_failed
)
echo UI_CONTRACT_READINESS=READY

echo.
set "SETUP_STAGE=STATIC_READINESS"
> "runtime\environment\setup_stage.txt" echo STAGE=STATIC_READINESS
echo [6/6] ANKA static readiness
.venv\Scripts\python.exe -m anka_platform.cli readiness --config config.yaml
if errorlevel 1 (
  echo STATIC_READINESS=FAILED
  goto :setup_failed
)
echo STATIC_READINESS=READY

set "SETUP_STAGE=SUCCESS"
> "runtime\environment\setup_stage.txt" echo STAGE=SUCCESS
echo.
echo ========================================
echo SETUP=SUCCESS
echo ========================================
echo One-time setup is complete.
echo Normal use from now on:
echo   1. Run start.bat.
echo   2. Script Studio opens immediately; Dofus clients may already be open or may be opened afterward.
echo   3. ANKA automatically discovers available Dofus windows and exact process generations.
echo   4. In Script Studio choose the mission and detected accounts, customize the session, then press Launch once.
echo   5. ANKA freezes that exact plan, waits for readiness if needed, and starts automatically.
echo Explicit release/compatibility Windows certification remains available through run_anka.bat.
exit /b 0

:setup_failed
set "FAILED_STAGE=%SETUP_STAGE%"
if not defined FAILED_STAGE set "FAILED_STAGE=UNKNOWN"
if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
> "runtime\environment\setup_failure_stage.txt" echo FAILED_STAGE=%FAILED_STAGE%
echo.
echo ========================================
echo SETUP=FAILED
echo SETUP_FAILED_STAGE=%FAILED_STAGE%
echo ========================================
if exist ".venv\Scripts\python.exe" (
  echo Collecting setup failure diagnostics...
  if exist "config.yaml" .venv\Scripts\python.exe -m anka_platform.startup_debug --config config.yaml --output runtime\startup\setup_failure_debug.zip >nul 2>nul
  if not exist "runtime\startup\setup_failure_debug.zip" .venv\Scripts\python.exe tools\export_setup_failure_debug.py --root "%ANKA_PROJECT_ROOT%" --output runtime\startup\setup_failure_debug.zip --stage "%FAILED_STAGE%" >nul 2>nul
  if exist "runtime\startup\setup_failure_debug.zip" echo SETUP_FAILURE_DEBUG=%ANKA_PROJECT_ROOT%\runtime\startup\setup_failure_debug.zip
  if exist "runtime\bridge_environment.json" echo BRIDGE_ENVIRONMENT_RECORD=%ANKA_PROJECT_ROOT%\runtime\bridge_environment.json
)
echo Fix the error shown above, then rerun setup.bat.
exit /b 1

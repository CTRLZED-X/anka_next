# R5.133 Generic Level-200 Ranged-Control Systemic Hardening

Checkpoint: `ANKA_PLATFORM_R5_133_GENERIC_L200_RANGED_CONTROL_SYSTEMIC_HARDENING_WINDOWS_LIVE_CANDIDATE`

Status: offline candidate; Windows/Dofus live acceptance pending.

## Purpose

R5.133 is the evidence-driven successor to the R5.132 tactical foundation. It uses the two supplied live runtime bundles to separate runtime blockers from tactical-quality questions, fixes those blockers at their ownership boundaries, and generalizes the Cra Water/Earth + Enutrof Water/MP controller so its core reasoning does not require Sufokia monster profiles.

The fight controller remains deterministic and explainable. Canonical State is live truth, Kernel legality/effect projection is the admission gate, the tactical layer selects one primitive action, `PartyCombatController` sequences it, and `ExecutionService` remains the only physical-input authority.

## Live evidence and root causes

### `runtime(20260924-204206)`

- The run did **not** execute `ranged_control_v1` / `tactical_v1`. The compiled plan used `sufokia_farm`, `normal_farm`, active `normal` policies, and no team strategy. Empty `fight_ai/*` streams were therefore configuration/activation evidence, not proof that the tactical planner made bad decisions.
- The mission blocker was `LIVE_SPELL_BAR_MISMATCH` on Cra before the next tactical action.
- Six Cra mismatches were not unrelated spells. Every one was a certified sibling in Kernel `SpellVariants.json`: `32459→32443`, `32439→32444`, `32458→32427`, `32457→32445`, `32472→32474`, `32475→32469`.
- Enutrof's configured bar matched.

R5.133 keeps live-bar verification fail-closed, but a configured spell may resolve to the currently equipped spell only when Kernel variant-family evidence proves the relation and the live grade is usable. The resulting effective combat profile uses the **live equipped spell mechanics**. Unrelated IDs still block.

### `runtime(20260924-210209)`

- The completed fights again used the legacy normal stack, so they are not evidence about `tactical_v1` quality.
- Fight `56` exposed a bounded multi-account preparation convergence race: Cra had reached `ACTIVE` while Enu's Canonical lane was roughly 1.6 seconds behind. The next Enu events contained the missing Ready acknowledgement and `ACTIVE`, but the parent had already treated the temporary skew as terminal.
- Across fight entries, a pre-armed Enu Ready lane could lose foreground when a Cra retry became eligible. This repeatedly produced recoverable `READY_PREARMED_FOREGROUND_LOST` and increased preparation latency.

R5.133 adds bounded preparation convergence only where semantic Ready evidence exists, and a pre-armed Ready account owns the Ready lane until send/invalidate/timeout. Safety is not weakened: convergence timeout and missing semantic evidence remain fail-closed.

### Dofus 3.6.12 wire drift

The live client reported Dofus `3.6.12.16` while the selected adapter remains `dofus_3_6_10_10`. The proven terminal `jwe` shape still appeared and decoded. A different mid-fight `jwe` shape used repeated field `5` plus field `6=-1`; it is not the certified result boundary. R5.133 accepts only that exact observed collision as opaque/non-mutating compatibility traffic. It does **not** invent result semantics, and any other unknown `jwe` shape remains fail-closed.

A separate health-latch repair preserves every transform failure historically while allowing the active `CAPTURE_ERROR` latch to clear only after later authoritative Canonical progress proves the stream recovered.

## Generic level-200 tactical architecture

The production default `ranged_control_v1` strategy and team placement now start with an **empty adaptive enemy capability catalog**. The Sufokia capability YAML remains an optional evidence pack that may be injected explicitly; it is not required by the planner.

Unknown monsters use:

1. Canonical geometry, HP/AP/MP, turn order and observed elemental resistances;
2. Kernel spell legality/effects/projection;
3. conservative generic reach/pressure priors;
4. bounded confidence-weighted live observations learned from confirmed casts and damage geometry;
5. no monster-name or monster-ID branches in tactical code.

Learned evidence may widen defensive attention but never override Kernel truth or authorize input.

## Cra + Enu cooperation hardening

R5.133 extends the R5.132 foundation with these generic invariants:

- **Core-vs-guard separation:** only active Cra/Enu core actors drive survival, protected-actor pressure and tactical emergency modes. Passive guards cannot hijack team strategy because they are low HP or targeted.
- **Whole-duo pressure:** enemy priority and movement evaluate pressure against both Cra and Enu, not only the current actor.
- **Large-group aggregation:** 5–8 moderate enemies accumulate pressure; the controller no longer discards all but the single worst enemy.
- **Calibrated distance pressure:** aggregation no longer makes eight distant enemies look like a permanent emergency.
- **Stable shared focus:** Cra finisher opportunities are separate from the Enu control target; shared primary target has hysteresis and switches only for materially more urgent pressure.
- **Tactical modes with action gates:** `SURVIVE`, `SAVE_ALLY`, `BREAK_PINCER`, `FULL_RETREAT`, and `ESCAPE_AND_CONTROL` suppress ordinary greedy actions when a certified protective/control action exists, with fail-safe fallback if none exists.
- **Cast-before-unnecessary-move:** useful certified AP expenditure remains preferred unless movement is a real survival exit or materially unlocks a stronger action.
- **Enu controller override:** high shared threat can force a materially better MP/AP/displacement control opportunity ahead of ordinary damage.
- **Adjacent disengagement:** a legal useful push/control cast can be preferred before spending movement when immediate geometry warrants it.
- **Unified safe-state geometry:** pincer, reply pressure, movement and placement use one calibrated threat model while pincer detection preserves close two-sided geometry.
- **Front geometry:** the planner penalizes creating enemies between Cra and Enu and can reward removing that split.
- **Resistance-aware damage choice:** Canonical elemental resistance characteristics 33–37 are forwarded into Kernel actor stats and affect ranking only when actually observed; unknown resistance is neutral.
- **Verified support actions:** only unambiguous positive AP/MP/range support proven by Kernel effect resolution receives setup value. Unknown state semantics remain unclaimed.
- **Sign-aware resource control:** positive enemy AP/MP changes can never masquerade as control; MP-control value is bounded by known remaining resource and uncertainty is explicit.
- **Whole-team placement:** opening formation uses the same generic/adaptive pressure model and shared learned evidence as in-fight reasoning.

## Passive front guards

`front_guard_v1` remains a PASSIVE policy, not a third control-authority mode. It never casts. Its movement is conservative geometric interception/protection only; otherwise it ends turn.

R5.133 intentionally does **not** claim that standing in front blocks a ranged monster. Such a claim requires certified path/attack projection that is not universally available.

## Fight Intelligence and long-run hardening

- Every tactical activation identifies resolved mission, policy set, team strategy and roles so a future debug cannot confuse legacy and tactical behavior.
- Decision traces preserve candidates, score components, strongest rejected alternatives, planner overrides, truncation and tactical anomalies.
- Canonical consequences correlate the selected action to the next certified state. Same-turn consequences receive stronger causal attribution; turn-boundary observations are explicitly weaker.
- Replay remains execution-free and deterministic.
- Enemy memory, de-duplication, local observations, fight-local target memory and pending consequence state are bounded for long campaigns.
- Pending final-action telemetry is retired on terminal fight/campaign evidence instead of leaking across fights.

## Deliberately unsupported / deferred

### Reliable kill sequences

The SUFOKIA reference has a reliable-kill solver using conservative damage bounds. ANKA's current Kernel certifies legality and structured effects but does not yet provide a sufficiently proven final live damage estimator for this purpose. R5.133 therefore treats low-HP enemies as finisher opportunities but never claims guaranteed lethal damage.

### Controlled Enutrof summons

The reference controls animated summons. ANKA currently binds combat turn ownership to account-local actors. A summon controller would require an explicit controlled-actor ownership contract, turn correlation and input settlement changes. R5.133 does not bypass those boundaries.

## Zone independence vs world mission defaults

The **fight AI** is zone-independent by construction. The shipped `sufokia_farm` mission still contains Sufokia route defaults because world mission configuration is a separate concern. Directional route start/directions and target monster range remain configurable in Script Studio. `sufokia_farm` now selects the tactical stack by default; `sufokia_farm_legacy` is the explicit rollback path.

## Live acceptance boundary

Offline verification cannot prove universal level-200 mastery. The next live run must prove that:

1. `sufokia_farm` resolves to `tactical_ranged_control_v1`, `ranged_control_v1`, `tactical_v1` for active Cra/Enu, and `front_guard_v1` for passive extras;
2. no legitimate verified Cra variant is rejected by the live bar, while unrelated spells still block;
3. Ready convergence survives normal account-lane skew without permitting input before semantic readiness;
4. Cra/Enu decisions show shared focus/control intent and bounded latency in real 1–8 monster fights;
5. multi-fight continuation, stop/relaunch, post-fight settlement and input authority remain intact;
6. `fight_ai/` evidence explains the active strategy and every material choice well enough to turn live mistakes into replay regressions.

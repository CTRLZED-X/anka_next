# R5.173 — Startup / Protocol / Projection Foundation Hardening

## Why this release exists

The October 12 runtime showed a systemic pre-campaign failure. Capture had traffic and classified protocol messages, both clients were bound, and the Unity bridge discovered a complete 560-cell runtime grid, yet Launch never progressed. No FightAI decision or physical input was sent.

R5.173 repairs the foundation rather than adding a symptom-specific bypass.

## 1. Startup bootstrap liveness

The world-map bootstrap is allowed when the only missing runtime-health evidence is the first current-session canonical observation that the bootstrap itself is designed to create. This exception is deliberately narrow. Protocol schema drift, transform errors, stale traffic, process/window identity faults and unrelated runtime-health blockers remain fail-closed.

## 2. Pending Launch is a bounded terminal lifecycle

The backend stall watchdog can atomically win the Launch transition boundary. A terminal pre-start stall becomes `FAILED_TO_START`, the Launch authorization is consumed, physical control is disarmed, and diagnostics are exported from that safe state. A stale watchdog observation cannot shut down a run that already started.

## 3. Structural runtime-grid projection authority

The bridge already discovers and validates a complete 560-cell runtime coordinate source. R5.173 makes that structural grid the projection authority. Literal Unity object names such as `GraphicCells/cell::<id>` remain useful diagnostics when present but cannot globally block startup because Unity naming is not a stable protocol.

Entity interactions are still stronger than cell projection. They require a live resolved TargetEntityId, canonical CellId agreement, nearest runtime-grid CellId agreement, process/map generation continuity and viewport-safe coordinates. Ambiguous entity evidence remains `NOT_SENT`. Bridge discovery and retained forensic evidence remain process-scoped by Dofus PID so CRA/ENU cannot overwrite one another.

## 4. Protocol upgrade foundation

Protocol wire logic remains inside versioned adapter packages. Runtime diagnostics now record classified-message counts, classified messages that emitted zero canonical events, their message-name distribution, opaque compatibility traffic, observed Dofus client version, adapter certified builds, and a typed canonical-starvation diagnosis. This separates “capture began after the useful baseline event” from real transform/schema drift.

## 5. Bridge identity

Because projection authority semantics changed, the bridge contract is bumped to 4 and plugin version to 2.2.75 with projection authority `STRUCTURAL_RUNTIME_GRID_V2`. Setup rejects an older installed bridge rather than silently running mismatched source/binary behavior.

## Live acceptance

Offline verification cannot prove the Windows/Dofus/IL2CPP environment. The next acceptance run must therefore either progress through startup normally or fail-stop with one complete diagnostic package. Live acceptance remains pending until that test succeeds.

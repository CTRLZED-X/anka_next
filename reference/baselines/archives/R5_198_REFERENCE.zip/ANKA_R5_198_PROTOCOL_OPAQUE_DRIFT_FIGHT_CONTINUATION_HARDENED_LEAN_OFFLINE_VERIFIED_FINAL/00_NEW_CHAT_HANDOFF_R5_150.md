# New chat handoff — R5.150

## Read first

1. `R5_150_COMBAT_FOUNDATION_EXECUTION_HISTORY_MOVEMENT_PLANNING_FORENSIC_HEALTH_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `ARCHITECTURE.md`
5. `DEVELOPMENT_RULES.md`
6. `DEBUGGING.md`
7. `TESTING.md`

## Current architecture rule

Keep five authorities separate: Canonical State = observed truth; Kernel = deterministic legality; FightAI/TeamStrategy = replaceable policy; PartyCombatController/FightWorkflow = orchestration/liveness/recovery; ExecutionService = sole physical-input/settlement authority.

R5.150 adds one crucial neutral seam: `PlannerInvocationContext.confirmed_turn_history`. It tells a policy which CAST/MOVE/END_TURN actions are already semantically confirmed in the exact current turn. Do not put this information into Canonical State and do not let a policy read controller internals.

## Movement rule

Do not implement cell-by-cell clicking. The Kernel may compute paths, but a policy chooses the final legal destination and ExecutionService projects/clicks that final cell once. If movement still appears fragmented, inspect multiple MOVE decisions in `analysis/foundation_health.json`, planner history, and scoring—not the physical path driver first.

## Debug workflow for future strategy improvement

After a live campaign, start with `analysis/foundation_health.json`, `fight_ai/FIGHT_SUMMARY.json`, `fight_ai/DECISION_TRACES.jsonl`, `fight_ai/CANDIDATES.jsonl`, `fight_ai/ACTION_OUTCOMES.jsonl`, and `execution/actions_enriched.jsonl`. Stale decisions should include `decision_semantic_drift`; outcomes/actions should carry fight/round/turn/frame correlation. Use these to reverse-engineer missed tactical opportunities before touching foundation code.

## Current live status

The source incident completed 5/5 fights. R5.150 itself has not yet had Windows/Dofus live acceptance. Next milestone is a fresh-extracted live soak to measure whether multi-MOVE fragmentation drops and to collect the newly added Ready/semantic-drift/correlation evidence.

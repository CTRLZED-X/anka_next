# ANKA R5.182 — Complete New-Chat Handoff

**Release:** R5.182 — Durable Execution, Diagnostic Truth & Verification Foundation  
**Date:** 2026-10-13  
**Status:** **OFFLINE VERIFIED**  
**Windows / Dofus live acceptance:** **PENDING**  
**Working rule:** **Work manually and locally. Do not use GitHub. Do not assume a previous conclusion is correct without checking the current source/evidence.**

---

## 1. Why this file exists

This is the primary continuation document for a new ChatGPT conversation or a new engineering session.

The project has a long hardening history (R5.132 → R5.182). A new chat should **not rediscover the whole project from zero** and should **not repeat earlier debugging cycles**. Start here, then read the small set of current-authority files listed below.

The current goal is not “make one live bug disappear.” The goal is to preserve a strong software foundation so that future live failures are:

- detected early,
- contained,
- attributable to the correct subsystem,
- safe with respect to physical input,
- easy to investigate from one evidence bundle,
- and fixable without protocol details leaking into unrelated layers.

Do not claim the project is bug-free or fully live certified. R5.182 is **offline verified and ready for a bounded evidence-producing Windows/Dofus acceptance once Windows setup/readiness is green**.

---

## 2. Read these files first

Read in this order:

1. `PROJECT_STATUS.json` — current status authority and current invariants.
2. `R5_182_DURABLE_EXECUTION_DIAGNOSTIC_VERIFICATION_FOUNDATION.md` — what R5.182 changed and why.
3. `verification/R5_182_OFFLINE_VERIFICATION.md` — actual offline evidence and limitations.
4. `verification/R5_182_QUICK_GATE.json` — machine-readable bounded gate result.
5. `docs/CURRENT.md` — current documentation pointer.
6. `ARCHITECTURE.md` — authority/boundary model.
7. `DEBUGGING.md` — incident/debug evidence model.
8. `TESTING.md` — current verification approach.
9. `WINDOWS_LIVE_RUNBOOK.md` — Windows startup/setup procedure.
10. `LIVE_ACCEPTANCE.md` — what must be true for a live acceptance.
11. `PROTOCOL_UPGRADE_GUIDE.md` — protocol-change containment rules.
12. `DEVELOPMENT_RULES.md` — rules that future changes must preserve.

Historical release documents are useful as evidence/history, but **current R5.182 authority beats old wording when they conflict**.

---

## 3. Current release identity

Current workspace checkpoint:

`ANKA_PLATFORM_R5_182_DURABLE_EXECUTION_DIAGNOSTIC_VERIFICATION_FOUNDATION_WINDOWS_LIVE_CANDIDATE`

Platform version:

`0.1.0a130`

Active live protocol adapter:

`dofus_3_6_12_16`

Canonical contract major:

`1`

Workspace Kernel:

- Python package version: `0.1.0a59`
- checkpoint: `R10J Single-Cell Cast Decision Query`

Some older manifest fields intentionally preserve the sealed R5.115 compatibility identity. Do not treat that historical compatibility metadata as the current workspace Kernel identity.

---

## 4. High-level architecture to preserve

The system is intentionally layered:

```text
Operator / Script Studio
        ↓
Application / SessionCompiler
        ↓
Frozen SessionPlan
        ↓
Explicit Apply + Launch authorization
        ↓
ControlAuthorityStore
        ↓
CampaignRuntimeController
        ↓
WorldWorkflow / FightWorkflow
        ↓
PartyMissionController / PartyCombatController
        ↓
FightDecisionService
        ↓
FightAI + deterministic Kernel
        ↓
ExecutionService
        ↓
ExecutionLifecycleGate
        ↓
InputArbiter
        ↓
Windows physical input
```

Independent live truth returns through:

```text
Dofus traffic
   ↓
packet capture / TCP reconstruction
   ↓
versioned protocol adapter
   ↓
staged adapter runtime context
   ↓
CanonicalEventEnvelope batch
   ↓
CanonicalStateStore atomic transaction
   ↓
CanonicalSnapshot
   ↓
World / Fight / AI / Execution settlement / diagnostics
```

### Non-negotiable authority rules

1. **Canonical State is semantic live truth.**
2. **A successful mouse/keyboard API call is not proof that Dofus accepted the action.**
3. **Projection/Unity evidence gives geometry/UI location, not game semantic truth.**
4. **ExecutionService is the single public physical-input authority.**
5. **InputArbiter is the cross-account physical-input lease.**
6. **FightAI proposes strategy; it cannot physically execute actions.**
7. **Kernel owns deterministic game mechanics/legality, not live orchestration.**
8. **Raw protocol structures must stay inside versioned protocol adapters.**
9. **Protocol changes must adapt to the canonical contract, not force changes across Campaign/FightAI/Execution.**
10. **Unknown/uncertain safety conditions fail closed.**

---

## 5. What R5.180 fixed and R5.182 builds on

R5.180 fixed a critical Canonical State durability defect.

Before R5.180, one protocol message could emit multiple canonical events and persistence/checkpoint failure could create divergence between:

- decoder inference state,
- SQLite journal,
- in-memory Canonical snapshot,
- and restart checkpoint recovery.

R5.180 introduced:

- atomic canonical event batches,
- explicit SQLite rollback,
- Canonical store fencing after ambiguous failure,
- staged/rollbackable protocol runtime context,
- separate protocol-vs-canonical failure classification,
- strict configuration parsing,
- safer authority fallback behavior.

**Do not weaken these guarantees.**

---

## 6. What R5.181 fixed and R5.182 builds on

R5.181 hardened Windows setup after a real user failure where normal setup attempted to download `pytest` and failed on DNS/network access to `files.pythonhosted.org`.

R5.181 changed normal setup so:

- `setup.bat` installs runtime + capture dependencies only,
- pytest/developer tooling is moved to optional `setup_dev.bat`,
- normal setup does not unnecessarily downgrade pip,
- Python is explicitly sealed to 3.13.x,
- dependency DNS/network failure gets explicit diagnostics,
- stale R5.179 setup messages were corrected.

R5.182 preserves those setup rules.

---

## 7. What R5.182 implemented

R5.182 focuses on **physical-action safety durability, diagnostic truth integrity, stuck-owner containment, and deterministic verification**.

### 7.1 Durable ExecutionSafetyStore

The execution safety store now uses explicit SQLite transaction semantics rather than best-effort commits.

It includes:

- explicit transaction begin,
- commit,
- rollback on failure,
- sticky write-health fencing when durability becomes ambiguous,
- prevention of abandoned write transactions that could lock Canonical State,
- refusal of later safety mutations/input when the store is unhealthy.

This closes a previously confirmed failure class where a failed safety commit could disappear after restart or leave SQLite locked.

### 7.2 Write-ahead physical-input obligation

Game-affecting physical input is now **durably prepared before the driver is allowed to send it**.

Conceptually:

```text
prepare durable physical-input obligation
        ↓
preparation durable?
   NO ─────────> DO NOT SEND INPUT
        ↓ YES
send physical input
        ↓
result/semantic reconciliation
        ↓
confirmed safe terminal state
        ├─ replace/clear obligation safely
        └─ otherwise keep durable uncertainty/settlement obligation
```

A crash after physical delivery but before normal semantic settlement can no longer silently erase the fact that ANKA may have acted.

R5.182 also closes keyboard/UI-neutralization paths so ESC/game-affecting keyboard input does not bypass the common safety wrapper.

### 7.3 Diagnostic Canonical-source integrity

Previously, `DebugBundleExporter` could be constructed while the app only had the fallback global `runtime/anka.db`. Later, dynamic account lanes (`runtime/accounts/<account>/anka.db`) could become authoritative, but Diagnostics V2/root-cause reasoning could still use the startup fallback DB.

R5.182 changes diagnostics to use the **incident-owning account Canonical database** when dynamic account lanes exist.

The diagnostic bundle identifies the Canonical source used for reasoning.

This is important for failures such as:

> “ANKA requested an action and apparently nothing happened.”

A GPT investigation should now reason from the same account truth that controlled the live action.

### 7.4 Compatibility dispatch hardening

Do not infer interface compatibility by invoking a production authority and catching `TypeError`.

R5.182 removes the remaining post-fight reconciliation pattern of:

```python
try:
    call(reason=x)
except TypeError:
    call(x)
```

Compatibility is determined before invocation so an internal production bug cannot cause a second call.

### 7.5 Stuck-owner fail-closed behavior

Both serialization layers are protected:

- per-account `ExecutionLifecycleGate`,
- shared cross-account `InputArbiter`.

Waits are bounded by stuck-owner policy.

If an owner is stuck:

- later work is refused/fenced,
- diagnostics expose the owner/age/operation,
- the original lease is **not stolen or force-released**.

Never “fix” a stuck owner by releasing the lock under it; that could permit two physical actors to run concurrently.

### 7.6 Deterministic verification authority

The current verifier is now bounded per declared target and isolated from unrelated pytest plugins/process state.

Key behavior:

- each target runs in deterministic isolation,
- progress is checkpointed after each target,
- PASS results can be resumed only when bound to the unchanged verification surface,
- target results are explicit (PASS/FAIL/TIMEOUT/NOT_RUN semantics),
- orphan/background processes are cleaned using run-scoped identity,
- one historical slow target cannot hide the rest of the release evidence.

---

## 8. Current offline verification evidence

R5.182 is marked **OFFLINE VERIFIED**.

The final R5.182 quick gate records:

- **52/52 target groups PASS**
- **770 passed tests**
- **54 intentional historical skips**
- **0 required FAIL**
- **0 required TIMEOUT**

Machine result is stored in:

`verification/R5_182_QUICK_GATE.json`

Additional current checks include:

- Python `compileall` over `src`, `tests`, `tools`: PASS
- project-context checker: READY
- release-integrity checker: READY
- foundation architecture verifier: PASS
- no static import cycles
- no protocol leak into FightAI/Campaign/Kernel/Execution
- no FightAI physical-input ownership leak
- no physical-input authority leak
- current protocol SDK/capability checks: PASS
- current emitted production failure-code registration checks: PASS
- focused R5.182 fault-injection tests: PASS

Important: offline verification does **not** prove current Windows/Dofus runtime compatibility.

---

## 9. Protocol status and the five remaining evidence gaps

The active protocol adapter remains:

`dofus_3_6_12_16`

Current retained protocol evidence is strong:

- required reference event coverage: **100%**
- required semantic coverage: **100%**
- required critical-field coverage: **100%**
- evidence coverage: **100%**

But required live-truth certification remains approximately:

**88.37%**

Status:

`INSUFFICIENT_EVIDENCE`

Five independent ORACLE-strength gaps remain:

1. **world map / MapId**
2. **local actor identity** for CRA/ENU
3. **actor cell / CellId**
4. **current AP**
5. **current MP**

These are **evidence gaps, not proven decoder defects**.

Do not patch protocol decoding speculatively just to make the certificate green.

The next bounded live acceptance should deliberately collect independent evidence for these five truths.

---

## 10. Current live-readiness verdict

### Offline engineering foundation

**READY / VERIFIED for R5.182 scope.**

### Windows/Dofus live acceptance

**PENDING.**

### Fully unattended / zone-200 certification

**NOT YET CLAIMED.**

The correct next live step is a **small bounded evidence-producing acceptance**, not a long unattended farming run.

---

## 11. Exact next Windows workflow

Use a **fresh extraction** of the R5.182 ZIP.

### Step 1 — close Dofus

Do not install/reconfigure the bridge while Dofus is running.

### Step 2 — run

`setup.bat`

Require the setup output/readiness records to show the expected dependency, bridge, map/static, and UI readiness.

Do **not** run `setup_dev.bat` for normal live use. Developer/test dependencies are optional.

### Step 3 — if dependency installation fails

Inspect:

`runtime/environment/dependency_network.json`

If DNS/network is the problem, do not change FightAI/protocol/runtime code to “fix” it.

R5.182 supports an optional SHA-256-verified local runtime wheelhouse, but this packaged build does **not** contain a synthetic wheelhouse because the build environment did not have working PyPI DNS. In its absence, setup uses bounded Internet/local-pip-cache fallback.

### Step 4 — start normal application

`start.bat`

Normal authoritative workflow is:

```text
setup.bat
  ↓
start.bat
  ↓
Script Studio
  ↓
Apply
  ↓
explicit Launch
```

Do not require old special pilot scripts for normal operation.

### Step 5 — bounded acceptance

Use:

- required accounts only,
- small mission/route,
- bounded attempts,
- bounded fight count,
- no repeated blind Launch clicks,
- automatic incident/debug bundle preservation on failure.

The main purpose of this run is to prove real Windows/runtime boundaries and collect the five missing independent protocol truths.

---

## 12. What to collect if anything fails live

Do not immediately patch the symptom.

Preserve the generated incident/debug evidence first.

A useful investigation should answer:

1. What SessionPlan was active?
2. Which account/client generation owned the action?
3. What was the Canonical revision/state before the decision?
4. Which policy made the decision?
5. What Kernel/admission validation passed or failed?
6. Was the execution lifecycle lease acquired?
7. Was the InputArbiter lease acquired?
8. Was a durable physical-input obligation prepared?
9. Was physical input actually attempted?
10. What did the driver return?
11. What live protocol evidence arrived afterward?
12. Did Canonical State settle the action?
13. Did the safety obligation clear, become settlement, or remain uncertain?
14. Did recovery run?
15. Which boundary is the first proven divergence?

Do not diagnose only from screenshots if the incident bundle/canonical/protocol evidence exists.

---

## 13. Important historical failure patterns to avoid

### 13.1 Do not fix only the visible symptom

Past cycles often looked like:

```text
live test
  ↓
visible symptom
  ↓
local patch
  ↓
next live test
  ↓
related failure appears one layer later
```

Always trace the invariant end to end.

### 13.2 Do not treat clicks as success

Input delivery is only a physical attempt.

Success/settlement requires semantic/canonical evidence.

### 13.3 Do not mix protocol semantics into FightAI/Campaign/Execution

Protocol changes belong inside versioned protocol capability modules and must continue producing the stable canonical-event contract.

### 13.4 Do not use exception-driven compatibility

Never call an authority, catch `TypeError`, and then retry another signature.

### 13.5 Do not steal stuck leases

Stuck owner → diagnose/fence/refuse.

Never force-release an active physical-input lease.

### 13.6 Do not weaken uncertainty fences for continuity

Continuing blindly is worse than stopping with precise evidence when an input may have been sent.

### 13.7 Do not weaken protocol-certification requirements just to claim readiness

The five ORACLE gaps exist because independent proof is still missing.

---

## 14. Important user/project operational context

The practical target remains robust multi-account Dofus automation, especially CRA + ENU fight behavior and later level-200 zones.

Important account/team context historically used by the project:

- CRA leader: `Curseni`, level 200
- ENU follower: `Sosoking`, level 200
- additional accounts can be passive/shield roles
- CRA is primarily eau/terre damage + map control
- ENU is primarily eau / retrait PM + support

Known historical live symptoms included:

- ENU not joining or joining late,
- Ready state stalls,
- CRA/ENU taking no action,
- turn handoff problems,
- invalid spell range/target/cell attempts,
- clicks requiring more PM than available,
- casting toward non-walkable/invalid cells,
- focus loss,
- fight count/target-wins continuation issues,
- Internet interruption and resume problems,
- launch button apparently doing nothing,
- protocol changes requiring new evidence.

Do not assume any one historical symptom is still present in R5.182. Use current evidence before making runtime changes.

---

## 15. Project structure / subsystem navigation

Main runtime package:

`src/anka_platform/`

Deterministic game mechanics:

`src/anka_game_kernel/`

Important conceptual areas include:

- application/session/bootstrap
- campaign/runtime lifecycle
- party/world/fight coordination
- protocol capture/adapters/canonical transformation
- Canonical State
- FightAI/policies
- deterministic Kernel
- execution/Windows input/safety
- projection/Unity bridge
- observability/diagnostics
- Script Studio/web control plane
- setup/certification/release verification

Before changing a subsystem, identify:

- who owns the state,
- who owns the decision,
- who owns execution,
- what the stable interface is,
- what evidence proves success/failure.

---

## 16. Areas that should NOT be redesigned without new evidence

Preserve these unless a specific defect justifies change:

- Canonical State authority
- Canonical contract major
- R5.180 atomic Canonical batching
- staged protocol runtime context
- protocol adapter SDK/capability isolation
- RuntimeHealthFence
- ExecutionService as single public physical-input authority
- InputArbiter cross-account lease
- Kernel mechanics truth
- FightAI/Execution separation
- ControlAuthorityStore
- explicit SessionPlan
- passive pending Launch behavior
- strict config validation
- write-ahead physical-input obligations
- prepared-input restart fencing
- dynamic per-account diagnostics Canonical-source selection
- stuck-owner fail-closed behavior

Do not perform a large `ExecutionService`/FightAI rewrite merely for code cleanliness before current live evidence demands it.

---

## 17. Deferred / future structural work

These can still provide value later but are **not current blockers**:

1. Incremental internal decomposition of `ExecutionService` while preserving one public authority.
2. Decomposition of large party/fight controller functions.
3. Further internal decomposition of the legacy exporter.
4. Move historical shared test helpers into `tests/support/`.
5. Consolidate historical Markdown documentation.
6. Optimize repeated Kernel reconstruction if future routes require runtime map promotion.
7. Ship a real Windows CPython-3.13 runtime wheelhouse when dependency wheels can be obtained/verified in a network-capable build environment.

Do not combine all of these into one release.

---

## 18. Current R5.182 release evidence summary

Current authoritative offline verification file:

`verification/R5_182_OFFLINE_VERIFICATION.md`

Current gate file:

`verification/R5_182_QUICK_GATE.json`

Current status authority:

`PROJECT_STATUS.json`

Current package manifest:

`PACKAGE_MANIFEST.json`

Expected current status:

```text
R5.182 OFFLINE VERIFIED
Windows/Dofus live acceptance PENDING
five ORACLE protocol evidence gaps remain
```

If these files disagree, stop and investigate release coherence before changing runtime code.

---

## 19. Recommended workflow for the next ChatGPT session

### If the user says “continue working” before a live run

1. Read this handoff.
2. Read `PROJECT_STATUS.json` and R5.182 offline verification.
3. Confirm the exact artifact is R5.182.
4. Do not reopen already-solved architectural questions without contrary evidence.
5. Focus on Windows setup/live readiness or the exact new evidence supplied by the user.

### If the user supplies setup logs

Classify first:

- dependency/DNS,
- Python version,
- bridge/BepInEx,
- static data/maps,
- UI/server startup,
- Dofus process identity.

Do not touch fight logic for an installation problem.

### If the user supplies a live incident/debug bundle

Trace boundaries in order:

```text
session/control
→ client identity
→ capture
→ protocol transform
→ Canonical State
→ world/fight lifecycle
→ decision
→ legality/admission
→ durable input preparation
→ physical delivery
→ semantic acceptance
→ settlement/recovery
```

Find the **first proven divergence**, not the last visible symptom.

### If the user supplies new PCAP/protocol evidence

Keep changes inside the versioned protocol adapter/capability layer unless evidence proves a canonical-contract problem.

Re-run capability certification and live-decoding evidence verification after changes.

---

## 20. Final continuation state

R5.182 represents the current strongest foundation in this project history.

Its main engineering advances are:

- transactional Canonical live truth,
- staged protocol inference,
- durable physical-action write-ahead safety,
- restart-safe uncertainty fencing,
- correct account-specific diagnostic truth,
- bounded stuck-owner containment without lease theft,
- strict configuration,
- isolated protocol architecture,
- deterministic bounded verification,
- runtime/dev setup separation.

The next meaningful step is **not another broad refactor**.

It is:

> **Run the fresh R5.182 artifact on the user’s Windows environment, complete setup/readiness, then perform one small bounded evidence-producing live acceptance designed to verify the remaining real-environment boundaries and collect the five missing ORACLE-strength protocol truths.**

If that run fails, preserve the incident bundle and diagnose the first boundary divergence before implementing anything.

**Do all work locally/manual unless the user explicitly changes that instruction. Do not use GitHub.**

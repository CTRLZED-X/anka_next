# ANKA R5.165 — New Chat Handoff

## Current authority

Workspace checkpoint: `ANKA_PLATFORM_R5_165_LIVE_TRUTH_READY_RECOVERY_TRAJECTORY_HARDENING_WINDOWS_LIVE_CANDIDATE`.

Start with this file, then read `PROJECT_STATUS.json`, `PROJECT_CONTEXT.json`, `R5_165_LIVE_TRUTH_READY_RECOVERY_TRAJECTORY_HARDENING.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md`.

The sealed runtime diagnostic identity remains R5.115 / platform `0.1.0a122`. The workspace Kernel remains R10J / `0.1.0a59`.

## Incident that created R5.165

`runtime(20261004-222408).zip` terminated in fifth-fight preparation with `READY_REQUEST_RETRY_EXHAUSTED` for CRA. The evidence does not support a total internet outage: ENU remained healthy and emitted/received Ready protocol traffic. CRA's inbound gameplay flow nevertheless lagged the same Ready acknowledgement by about 4.3 seconds while its outgoing side remained current. R5.164 had no short directional transport hold, so the Ready retry budget could expire first. CRA also had physical Ready clicks with positively absent outbound `jyo`, requiring a UI/client recovery path independent of transport recovery.

## R5.165 invariants

1. Per-account server→client gameplay continuity is evaluated independently from outgoing/account-wide traffic.
2. A short directional live-truth stall pauses physical child progress and the campaign watchdog; it never grants a duplicate action.
3. Recovery requires a stable healthy interval before automation resumes.
4. Ready recovery is allowed only after an input-free protocol probe proves the previous Ready request absent.
5. Ready recovery is bounded, cooldown-spaced, re-arms the target window, performs a click-free pointer re-entry, and re-admits semantics before clicking.
6. Unknown/possibly-sent actions remain observe-only.
7. Reconnect flow replacement requires stale/terminal old flow plus demonstrably fresh replacement evidence.
8. Historical FIN/RST from an earlier 4-tuple generation cannot poison the current TCP generation.
9. Pointer geometry follows the useful TrajectoryLab_v2 correlated-knot/tapered-wobble style but retains monotonic minimum-jerk progression and exact safe endpoint arrival.
10. Debug convergence reporting distinguishes transaction-local passive settlement from actual retry loops.

## Primary hotpaths

- `src/anka_platform/reliability.py`
- `src/anka_platform/campaign/continuity.py`
- `src/anka_platform/campaign/runtime.py`
- `src/anka_platform/campaign/engine.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/pointer_motion.py`
- `src/anka_platform/observability/exporter.py`
- `src/anka_platform/application/composition.py`
- `src/anka_platform/scripting/host.py`

Primary regression: `tests/r5165/test_r5165_systemic_hardening.py`.

## Next live test

Normal workflow remains `setup.bat` once on a fresh extraction, then `start.bat` → Script Studio → Launch. The next run is the R5.165 Windows/Dofus live acceptance run. If a transient connectivity/client stall occurs, expect a bounded HOLD/RECOVERING episode and resumption rather than an immediate mission stop. Hard/uncertain failures remain fail-closed by design.

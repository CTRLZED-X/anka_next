# R5.192 — Protocol Upgrade + Setup Resilience Foundation

## Objective

R5.192 preserves the verified R5.191/R5.190 runtime behavior while hardening two recurring failure classes: Windows/VS Code setup instability and protocol-update regressions that leak across subsystem boundaries.

## Setup/runtime installation

Normal `setup.bat` now installs ANKA non-editably. Project-owned files are located through explicit `ANKA_PROJECT_ROOT` authority rather than assuming the Python package lives inside the extracted source tree. `setup_dev.bat` remains optional and uses setuptools `editable_mode=compat` for path-based editable behavior.

The shipped VS Code settings point analysis at `./src`, exclude `.venv`, runtime and large game-data directories, and do not depend on dynamic editable-install analysis. Setup writes `runtime/environment/setup_environment.json` plus the pip log so future Pylance/setup failures include the interpreter and extension context needed for diagnosis.

After installation, `runtime_install_contract.py` records an exact digest of the runtime source tree, platform version and active protocol adapter. `start.bat` verifies this record before starting ANKA. If GPT/source integration changed after setup, startup blocks and asks for setup to be rerun instead of silently using stale site-packages code.

## Version-local protocol isolation

`dofus_3_7_10_10` now owns its adapter facade, runtime context, capability declaration, handler modules and wire catalog. It no longer subclasses or imports the concrete `dofus_3_6_12_16` implementation. Historical adapters remain frozen for replay compatibility.

Generic runtime layers no longer embed registered raw wire names. They use stable `ProtocolWireSemantic` operations and diagnostics resolve the active raw mapping dynamically from the selected manifest.

## Upgrade certification contract

`tools/verify_protocol_upgrade_contract.py` blocks a protocol release unless:

- `config.yaml` and `config.yaml.example` select the same active adapter;
- the active adapter is version-local and imports no other concrete adapter;
- all registered raw wire vocabulary stays inside the protocol boundary;
- declared capabilities have current-build provenance metadata;
- the required cross-capability scenario contract is present;
- current game-data compatibility is explicitly recorded;
- the active adapter attestation is certified and all bound file hashes match.

Capability provenance may be `VERIFIED` or `PARTIAL`; partial semantics remain visible rather than being promoted to exact certainty. Current outbound End Turn request identity remains explicitly pending. Server turn-completion authority is preserved; no speculative opcode was invented.

## Scenario contract

The current adapter records scenario-level evidence for world-to-fight entry, party create/join, world/fight MapId separation, placement/Ready, Ready/first-turn, movement/resource reconciliation, cast/resource/damage/cooldown, End Turn/next-owner and fight-end/world re-entry. Scenarios still requiring bounded current live proof stay marked `PENDING`.

## Static game-data compatibility

`gamedata/COMPATIBILITY.json` separates current protocol-build support from static-data provenance. The bundled pack can be accepted for the configured automation scope without claiming every 3.6.10.10 static definition is identical to 3.7.10.10.

## Acceptance boundary

Offline acceptance requires the R5.192 tests, release integrity, protocol-upgrade contract, engineering guardrails, architecture checks, current quick gate and package manifest to pass. Windows/Dofus live acceptance remains pending and still requires one bounded CRA+ENU fight end to end.

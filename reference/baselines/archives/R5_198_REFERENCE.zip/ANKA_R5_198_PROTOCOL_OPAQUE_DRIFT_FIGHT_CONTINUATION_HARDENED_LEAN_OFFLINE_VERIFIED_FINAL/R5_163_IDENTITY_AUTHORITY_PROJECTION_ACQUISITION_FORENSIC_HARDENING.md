# R5.163 — Identity Authority, Projection Acquisition & Forensic Hardening

## Why this release exists

R5.163 is driven by the Windows/Dofus runtime `runtime(20261004-122209)(1).zip`. The run did not reach a legitimate FightAI turn. It first spent substantial time repeatedly attempting to acquire a monster group whose Unity projection was returning `ENTITY_MISMATCH`, then stopped at fight entry because CRA and ENU appeared to own the same actor id.

This pass treats those symptoms as failures of authority/convergence contracts, not as isolated FightAI bugs.

## Confirmed incident facts

- Shared fight id: `942`.
- CRA and ENU both reached fight entry with canonical local actor `496260153637`.
- The real ENU actor is `477764256037` (`Sosoking-[Fry]`).
- The weak identity originated from a `JPQ -> JPW` transition correlation. The R4 decoder already considered that evidence provisional, but the old `LocalPlayerObserved` event discarded its source/rank before Canonical State reduced it.
- Hydration could then make the persisted weak value look like normal local identity on restart.
- The same runtime contains strong `JYM` roster evidence mapping `Curseni -> 496260153637` and `Sosoking-[Fry] -> 477764256037`.
- FightAI emitted no legitimate decisions before the terminal ownership conflict.
- Before fight entry, 98 `launch_fight` requests were blocked by the same projection `ENTITY_MISMATCH` for group `-20003`; another candidate group was available.
- One physical launch click was eventually accepted. The later ~45 `WORLD_INTERACTION_SETTLING` observations were passive settlement polls and did not resend that click.

## Root causes

### 1. Identity evidence lost its authority level at the protocol/canonical boundary

`JPQ -> JPW` is useful transition evidence but is not ownership proof in a party client because the actor can be a foreign party member. R5.162's decoder tracked that internally, yet `LocalPlayerObserved` persisted only the actor id. The reducer therefore had no way to distinguish a rank-10 transition guess from a strong local-character observation.

This was an architectural contract loss: weak evidence and authoritative state shared one field.

### 2. Persistence could amplify weak identity across restarts

A simple checkpoint-version bump would not have been sufficient. Existing R5.162 journal rows contain unranked `local_player_observed` events, so replaying those rows could recreate the bad authoritative state even after ignoring an old snapshot checkpoint.

### 3. Active combat consumers assumed that any known local actor id was authoritative

Several downstream paths read the canonical local actor directly. That made the system depend on every upstream producer being perfect instead of making ownership authority explicit at the consumption boundary.

### 4. World target acquisition lacked candidate-level convergence semantics

A pre-input `ENTITY_MISMATCH` was safe but target-specific. R5.162 repeatedly retried the same candidate instead of trying the next eligible group or backing off after a bounded scan.

### 5. Projection rejection occurred too late in the physical-input pipeline

`ExecutionService._launch_fight` acquired the global input lease/focus before resolving a projection condition that could be rejected without any physical interaction. Repeated safe blockers therefore caused unnecessary focus/acquisition churn.

### 6. Pre-input failures did not carry enough transaction truth

Projection blockers did not consistently serialize `physical_send_state`, structured projection status/stage, and current-action input evidence. That made it harder to prove from one bundle that a blocked attempt sent no click, and could allow stale driver diagnostics to be confused with the current action.

## Systemic repairs

### Authoritative versus provisional local identity

Canonical State now stores two explicit tiers:

- authoritative local identity (`local_player_actor_id`, source, rank, observation revision);
- provisional local identity (actor, source, rank, observation revision).

Evidence below the authoritative threshold never populates `world.player_actor_id` and cannot participate in active-combat ownership. If stronger evidence corrects an already-authoritative actor id, the reducer also invalidates the old `world.player_cell_id` until position evidence for the corrected actor arrives; it never manufactures a new-actor/old-cell pair.

The decoder now preserves identity source/rank on every `LocalPlayerObserved` event. Current R4 ranking includes transition evidence at rank 10, hydrated authoritative compatibility at rank 20, exact configured-name `JYM` roster evidence at rank 32, `KSN` at rank 35 and `KTH` at rank 40.

`JYM` local-character recovery uses exact configured character-name matching, with only the known `-[...]` suffix form accepted; it does not use fuzzy substring ownership.

### Central authority resolution

`anka_platform.local_fighter_identity` is now the single authority for deciding whether a canonical local actor is strong enough for combat ownership. Controller, decision service, placement, team observation, execution, settlement, party evidence and outcome coordination use that authority rather than independently interpreting a raw actor field.

A preparation-only, exact-generation overlay can still be used for placement/Ready when causal evidence permits it, but it does not mutate Canonical State or become active-combat ownership proof.

### Upgrade-safe legacy migration

Canonical state checkpoint version is now 2. R5.162 v1 checkpoints are ignored and rebuilt from the journal.

Legacy unranked R4 identity events are migrated centrally from wire provenance. `jpw`, `jpo` and old ambiguous `jva` observations remain conservative/provisional; certified stronger sources retain stronger authority. Direct reducer replay and SQLite recovery use the same mapping, so they cannot disagree about legacy evidence.

After recovery, a v2 checkpoint is written so subsequent startups do not repeatedly replay the same old journal solely because of the version transition.

### Projection preflight before focus/input

World `launch_fight` resolves the entity/cell projection before acquiring the global input lease or focusing the Dofus window. `ENTITY_MISMATCH`, `OUTSIDE_VIEWPORT` and UI occlusion can therefore be rejected with `physical_send_state=NOT_SENT` before touching the physical-input channel.

The projection is still resolved again under the input lease before the actual click. The optimization does not weaken the final-send safety boundary.

### Bounded candidate failover and backoff

Party target acquisition can advance to the next candidate only when all of the following are true:

- the action is blocked before input;
- the result explicitly proves `physical_send_state=NOT_SENT`;
- the blocker is target-specific and safely retryable (`ENTITY_MISMATCH`, `OUTSIDE_VIEWPORT`, or UI occlusion).

Missing send proof is treated as unknown and stops failover. If every candidate is temporarily unavailable, one bounded scan is returned as `WORLD_TARGET_CANDIDATES_UNAVAILABLE` with a minimum backoff instead of immediately rescanning at roughly 4 Hz.

### One-bundle forensic clarity

The exporter now adds:

- `analysis/identity_authority.json` — authoritative/provisional identity observations by account, including legacy migration, reducer-equivalent acceptance/rejection semantics, and cross-account provisional/authoritative collision classification;
- `analysis/action_convergence_health.json` — repeated pre-input blocker groups and genuinely passive settlement polling groups, without mislabeling ordinary retry backoff as settlement.

Explicit `NOT_SENT` results return `NO_CURRENT_ACTION_INPUT` rather than inheriting mutable diagnostics from an earlier click transaction.

True authoritative cross-account ownership conflict is attributed separately as `LOCAL_FIGHTER_IDENTITY_CONFLICT` / `PROTOCOL_IDENTITY` rather than being blurred with tactical failures.

## What was deliberately not changed

- FightAI strategy was not redesigned; the incident failed before a legitimate tactical turn.
- Kernel mechanics authority was not weakened.
- SharedFightManager's duplicate-authoritative-ownership barrier was not relaxed. The bad upstream evidence is fixed instead.
- Passive post-click settlement was not converted into blind resend behavior.
- Input uncertainty still fails closed. Candidate failover requires explicit proof that no physical send happened.
- Windows/Dofus live acceptance is not inferred from offline tests.

## Live acceptance target

The next Windows run should prove all of the following from one bundle:

1. CRA resolves authoritatively to `496260153637` and ENU to `477764256037` (or the correct current live ids), with any transition candidates retained only as provisional evidence.
2. No cross-account authoritative ownership collision reaches fight entry.
3. A moving/stale monster-group projection does not cause repeated focus churn or repeated same-candidate scans; a safe second candidate is tried in the same acquisition step when available.
4. A `NOT_SENT` projection blocker never carries stale prior-click evidence as the current transaction.
5. One accepted launch click remains fenced while world/fight settlement converges; no duplicate physical launch is emitted.
6. Combat reaches real FightAI decisions so any remaining tactical/runtime defects are independently observable.
7. The exported identity-authority and convergence reports are sufficient to classify any remaining failure from the single runtime/debug package.

**Release status: offline-verified Windows live candidate. Windows/Dofus live acceptance remains PENDING.**

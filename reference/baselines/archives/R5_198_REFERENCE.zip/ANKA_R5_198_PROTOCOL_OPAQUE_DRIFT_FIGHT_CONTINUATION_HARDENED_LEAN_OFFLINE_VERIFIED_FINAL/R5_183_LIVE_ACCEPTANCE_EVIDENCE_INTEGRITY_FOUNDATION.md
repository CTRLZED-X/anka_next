# R5.183 — Live Acceptance Evidence Integrity & Oracle Certification Foundation

**Date:** 2026-10-14  
**Parent:** R5.182 Durable Execution, Diagnostic Truth & Verification Foundation  
**Status:** OFFLINE VERIFIED candidate; Windows/Dofus live acceptance remains PENDING.

## Objective

R5.183 does not redesign FightAI, Kernel, Canonical State, ExecutionService ownership, or the active `dofus_3_6_12_16` protocol semantics. It hardens the evidence path used to decide whether the five remaining live truths are genuinely certified.

The release prevents a dangerous false-positive class: values originating from ANKA Canonical State and then forwarded through ProjectionSync must never be treated as an independent ORACLE proving that same Canonical State.

## Implemented changes

1. `LiveDecodingEvidenceManifest` requires explicit oracle provenance whenever `oracle_snapshots` are supplied. Provenance must identify an allowed independent source kind, a collector, packet-index alignment, and `canonical_independent=true`.
2. Oracle records fail closed on malformed JSON/object shape, missing/duplicate snapshot IDs, invalid packet alignment, undeclared members, missing self-state, or zero comparable truth fields.
3. Oracle packet indices are validated against the complete PCAPNG packet-record count, not only packet numbers that happened to decode into Dofus messages.
4. Certification distinguishes evidence-integrity failures, replay/transform failures, actual Canonical-vs-oracle mismatches, and non-comparable oracle evidence. Bad evidence is not blamed on protocol decoding.
5. Explicitly supplied but invalid evidence packages produce `LIVEDEC-EVIDENCE-PACKAGE` / `BLOCKED`, rather than being downgraded to ordinary sparse evidence.
6. `verify_live_decoding.bat` and `inspect_live_capture.bat` use the sealed project `.venv` rather than an arbitrary `python` on PATH.
7. `tools/inspect_live_capture.py` inventories capture-wide packet counts, exact flow IDs/ranges/directions and top wire names without guessing account identity.
8. The current evidence/scenario templates target `dofus_3_6_12_16`, contain no fake placeholder assertions, and document independent-oracle requirements.
9. The current-release integrity checker is release-neutral instead of being hard-coded to R5.182.

## Preserved authority boundaries

- Canonical State remains semantic game truth.
- Projection/Unity remains geometry/UI evidence and cannot self-certify Canonical semantics.
- Protocol-specific wire structures remain in versioned adapters.
- ExecutionService remains the sole public physical-input authority.
- InputArbiter remains the cross-account physical-input lease.
- R5.182 durable prepared-input and restart fencing remain unchanged.

## Current live-certification boundary

The offline replay/reference evidence remains strong, but Windows/Dofus live acceptance is still pending. The five independent ORACLE-strength truths remain:

- world MapId;
- local actor identity for CRA/ENU;
- actor CellId;
- current AP;
- current MP.

These remain evidence gaps, not demonstrated decoder defects. R5.183 deliberately does not weaken the certificate to make them green.

## Next step

On a fresh Windows extraction: run `setup.bat`, then `start.bat`; keep control disarmed until explicit Launch. Capture the bounded CRA+ENU acceptance, inventory it with `inspect_live_capture.bat`, bind flows to accounts using independent process/account evidence, provide packet-aligned independent oracle snapshots, then run `verify_live_decoding.bat`. Preserve the incident/debug bundle on any runtime failure and repair the first proven boundary divergence.

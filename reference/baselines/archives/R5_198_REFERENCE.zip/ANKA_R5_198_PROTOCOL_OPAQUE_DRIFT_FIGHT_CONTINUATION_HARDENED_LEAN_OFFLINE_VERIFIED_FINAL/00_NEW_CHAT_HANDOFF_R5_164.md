# ANKA R5.164 — New Chat Handoff

## Current authority

Workspace checkpoint: `ANKA_PLATFORM_R5_164_FIGHT_LIFECYCLE_POINTER_TRAJECTORY_FORENSIC_HARDENING_WINDOWS_LIVE_CANDIDATE`.

Start with this file, then read `PROJECT_STATUS.json`, `PROJECT_CONTEXT.json`, `R5_164_FIGHT_LIFECYCLE_POINTER_TRAJECTORY_FORENSIC_HARDENING.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md`.

The sealed runtime diagnostic identity remains R5.115 / platform `0.1.0a122`. The workspace Kernel remains R10J / `0.1.0a59`. Those compatibility identities are unchanged.

## Incident that created R5.164

`runtime(20261004-200708).zip` completed four distinct confirmed wins (fight ids `967`, `968`, `326`, `327`) with campaign budget `wins=4`, `attempts=4`, `target_wins=5`, `max_attempts=10`. The mission did not stop from win accounting. After fight `327`, CRA retained a sent-but-unsettled `COMBAT_END_TURN` fence. The next WORLD launch saw a generic uncertainty fence, incident handling disarmed physical control, subsequent launch attempts were denied, and the parent eventually surfaced `MISSION_TIMEOUT` while still expecting fight #5.

R5.164 fixes the generation-boundary cleanup and consequence loop instead of changing the counter.

## R5.164 invariants

1. A confirmed fight outcome is counted exactly once; all outcome counters must sum to attempts.
2. `target_wins=5` stops only when confirmed wins reach 5; 4/5 remains CONTINUE.
3. Fight-scoped MOVE/CAST/END_TURN uncertainty is passively reconciled at authoritative fight exit before world re-entry.
4. Fight-scoped AP/MP settlement obligations are irrelevant after the originating fight is gone and are retired without input.
5. The final winning fight receives the same terminal cleanup at session end/preflight even though no world re-entry follows it.
6. An already-disarmed control lease is terminal for campaign progress but cannot recursively disarm itself at the incident layer.
7. The causal disarm root is retained outside bounded high-frequency authorization history.
8. Pointer paths keep exact endpoint/safe-endpoint contracts and monotonic minimum-jerk forward progression.
9. Medium/long pointer paths use correlated smooth lateral knots + tapered micro-wobble + bounded correction, inspired by TrajectoryLab_v2 without copying unsafe forward jitter.
10. Diagnostics preserve authoritative fight history separately from noisy polling and expose mission progress plus trajectory shape/timing metrics.

## Primary hotpaths

- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/pointer_motion.py`
- `src/anka_platform/execution/control_authority.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/party/coordinator.py`
- `src/anka_platform/campaign/runtime.py`
- `src/anka_platform/campaign/disposition.py`
- `src/anka_platform/observability/failure_disposition.py`
- `src/anka_platform/observability/exporter.py`

Primary regression: `tests/r5164/test_r5164_systemic_hardening.py`.

## Next live test

Normal workflow remains `setup.bat` once on a fresh extraction, then `start.bat` → Script Studio → Launch. The next run is an R5.164 live acceptance run. The foundation is offline verified; Windows/Dofus timing and current live behavior remain PENDING until that run.

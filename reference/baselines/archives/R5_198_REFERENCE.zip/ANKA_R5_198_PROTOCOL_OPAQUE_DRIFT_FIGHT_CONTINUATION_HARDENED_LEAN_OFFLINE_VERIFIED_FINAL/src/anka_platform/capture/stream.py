from __future__ import annotations

from anka_platform.protocol.protobuf import read_varint

class TcpStreamReassembler:
    def __init__(self): self.expected_seq=None; self.pending=[]
    def reset(self,expected_seq=None): self.expected_seq=expected_seq; self.pending=[]
    def feed(self,seq:int,payload:bytes)->bytes:
        if not payload: return b''
        if self.expected_seq is None: self.expected_seq=seq
        end=seq+len(payload)
        if end<=self.expected_seq: return b''
        if seq<self.expected_seq:
            payload=payload[self.expected_seq-seq:]; seq=self.expected_seq
        self._insert(seq,payload)
        out=[]
        while self.pending and self.pending[0][0] <= self.expected_seq:
            start,chunk=self.pending.pop(0)
            if start<self.expected_seq:
                trim=self.expected_seq-start
                if trim>=len(chunk): continue
                chunk=chunk[trim:]
            out.append(chunk); self.expected_seq += len(chunk)
        return b''.join(out)
    def _insert(self,seq,payload):
        intervals=sorted([*self.pending,(seq,payload)],key=lambda x:x[0]); merged=[]
        for start,data in intervals:
            if not merged: merged.append((start,data)); continue
            ps,pd=merged[-1]; pe=ps+len(pd)
            if start>pe: merged.append((start,data)); continue
            overlap=pe-start
            if overlap>=len(data): continue
            merged[-1]=(ps,pd+data[max(0,overlap):])
        self.pending=merged

class LengthPrefixedFrameDecoder:
    def __init__(self,max_frame_size=2_000_000): self.buffer=bytearray(); self.max_frame_size=max_frame_size; self.dropped_bytes=0
    def feed(self,payload:bytes)->list[bytes]:
        self.buffer.extend(payload); out=[]
        while self.buffer:
            length,pos=read_varint(bytes(self.buffer),0)
            if length is None: break
            if length<=0 or length>self.max_frame_size:
                del self.buffer[:1]; self.dropped_bytes+=1; continue
            end=pos+length
            if len(self.buffer)<end: break
            out.append(bytes(self.buffer[pos:end])); del self.buffer[:end]
        return out

from __future__ import annotations

import ipaddress
import struct
from pathlib import Path

from anka_platform.capture.models import CapturedTcpSegment


def _reject_selected_ipv6_tcp(packet: bytes, offset: int, server_ports: set[int]) -> None:
    """Fail closed when evidence contains selected-port IPv6 TCP traffic.

    The current Windows live capture backend only admits Scapy IPv4 ``IP/TCP``
    packets into ANKA. Treating IPv6 game traffic as absent during offline replay
    would therefore certify a transport path production cannot consume.
    """
    if len(packet) < offset + 40:
        raise ValueError("invalid/truncated IPv6 packet in certification capture")
    ip = packet[offset:]
    if ip[0] >> 4 != 6:
        raise ValueError("invalid IPv6 version in certification capture")
    payload_len = int.from_bytes(ip[4:6], "big")
    end = 40 + payload_len if payload_len else len(ip)
    if len(ip) < end:
        raise ValueError("truncated IPv6 payload in certification capture")
    ip = ip[:end]
    next_header = int(ip[6])
    cursor = 40
    # Common IPv6 extension headers. Parsing them here is only for determining
    # whether a selected TCP port is present; live runtime support remains absent.
    while next_header in {0, 43, 44, 51, 60}:
        if next_header == 44:  # Fragment header
            if len(ip) < cursor + 8:
                raise ValueError("truncated IPv6 fragment header in certification capture")
            next_header = int(ip[cursor])
            cursor += 8
            continue
        if len(ip) < cursor + 2:
            raise ValueError("truncated IPv6 extension header in certification capture")
        following = int(ip[cursor])
        if next_header == 51:  # Authentication Header: (Hdr Ext Len + 2) * 4
            size = (int(ip[cursor + 1]) + 2) * 4
        else:
            size = (int(ip[cursor + 1]) + 1) * 8
        if size <= 0 or len(ip) < cursor + size:
            raise ValueError("truncated IPv6 extension payload in certification capture")
        next_header = following
        cursor += size
    if next_header != 6:
        return
    if len(ip) < cursor + 4:
        raise ValueError("truncated IPv6 TCP header in certification capture")
    sport = int.from_bytes(ip[cursor:cursor + 2], "big")
    dport = int.from_bytes(ip[cursor + 2:cursor + 4], "big")
    if sport in server_ports or dport in server_ports:
        raise ValueError(
            "selected-port IPv6 TCP traffic is unsupported by the current live capture runtime; "
            "do not certify this evidence as equivalent to the production transport path"
        )


def _ethernet_ipv4_tcp(packet:bytes,packet_number:int,server_ports:set[int])->CapturedTcpSegment|None:
    if len(packet)<14: return None
    offset=14
    ethertype=int.from_bytes(packet[12:14],'big')
    if ethertype in {0x8100,0x88A8}:
        if len(packet)<18: return None
        ethertype=int.from_bytes(packet[16:18],'big'); offset=18
    if ethertype == 0x86DD:
        _reject_selected_ipv6_tcp(packet, offset, server_ports)
        return None
    if ethertype!=0x0800: return None
    if len(packet)<offset+20:
        raise ValueError('invalid/truncated IPv4 packet in certification capture')
    captured_ip=packet[offset:]
    version_ihl=captured_ip[0]
    if version_ihl>>4 != 4: return None
    ihl=(version_ihl & 0x0F)*4
    if ihl<20 or len(captured_ip)<ihl:
        raise ValueError('invalid/truncated IPv4 header in certification capture')
    if captured_ip[9]!=6: return None

    fragment_field=int.from_bytes(captured_ip[6:8],'big')
    fragment_offset=fragment_field & 0x1FFF
    more_fragments=bool(fragment_field & 0x2000)
    if fragment_offset:
        # A non-initial TCP fragment no longer contains the ports, so offline
        # replay cannot prove whether it belongs to a selected Dofus flow.
        raise ValueError('non-initial fragmented IPv4 TCP prevents certification completeness')

    # The first fragment / normal datagram contains the TCP ports. Inspect them
    # before enforcing payload-length details so unrelated host-offload traffic
    # (for example TLS packets with IPv4 total_length=0 in Npcap captures) does
    # not invalidate Dofus evidence.
    if len(captured_ip)<ihl+4:
        raise ValueError('invalid/truncated TCP ports in certification capture')
    captured_tcp=captured_ip[ihl:]
    sport=int.from_bytes(captured_tcp[0:2],'big'); dport=int.from_bytes(captured_tcp[2:4],'big')
    if sport not in server_ports and dport not in server_ports:
        return None
    if more_fragments:
        raise ValueError('fragmented selected-port IPv4 TCP is unsupported for certification replay')

    total_len=int.from_bytes(captured_ip[2:4],'big')
    if total_len == 0:
        # Windows/Npcap may expose transmit-offload packets before the NIC fills
        # the IPv4 total-length field. The bytes are still present in the capture;
        # use the captured frame length for selected traffic rather than treating
        # this known host-offload representation as truncation.
        total_len=len(captured_ip)
    if total_len<ihl or len(captured_ip)<total_len:
        raise ValueError('invalid/truncated selected-port IPv4 payload in certification capture')
    ip=captured_ip[:total_len]  # exclude Ethernet padding: critical for byte-exact stream reconstruction
    src=str(ipaddress.IPv4Address(ip[12:16])); dst=str(ipaddress.IPv4Address(ip[16:20]))
    tcp=ip[ihl:]
    if len(tcp)<20: raise ValueError('invalid/truncated selected-port TCP header in certification capture')
    data_offset=(tcp[12]>>4)*4
    if data_offset<20 or len(tcp)<data_offset: raise ValueError('invalid selected-port TCP data offset in certification capture')
    seq=int.from_bytes(tcp[4:8],'big')
    flags=int(tcp[13])
    payload=bytes(tcp[data_offset:])
    if not payload and not (flags & (0x01 | 0x02 | 0x04)): return None
    if sport in server_ports:
        direction='server_to_client'; server=f'{src}:{sport}'; client=f'{dst}:{dport}'
    else:
        direction='client_to_server'; server=f'{dst}:{dport}'; client=f'{src}:{sport}'
    return CapturedTcpSegment(flow_id=f'{client}<->{server}',direction=direction,seq=seq,payload=payload,packet_number=packet_number,tcp_flags=flags)


def read_pcapng_tcp_segments(path:str|Path,*,server_ports:set[int])->list[CapturedTcpSegment]:
    raw=Path(path).read_bytes()
    pos=0; endian='<'; linktypes:dict[int,int]={}; segments=[]; packet_number=0
    while pos+12<=len(raw):
        block_type_bytes=raw[pos:pos+4]
        if block_type_bytes==b'\x0a\x0d\x0d\x0a':
            if pos+12>len(raw): break
            bom=raw[pos+8:pos+12]
            if bom==b'\x4d\x3c\x2b\x1a': endian='<'
            elif bom==b'\x1a\x2b\x3c\x4d': endian='>'
            else: raise ValueError('invalid PCAPNG byte-order magic')
            total=struct.unpack_from(endian+'I',raw,pos+4)[0]
        else:
            block_type=struct.unpack_from(endian+'I',raw,pos)[0]
            total=struct.unpack_from(endian+'I',raw,pos+4)[0]
        if total < 12 or total % 4 != 0 or pos + total > len(raw):
            raise ValueError('invalid/truncated PCAPNG block')
        trailing_total=struct.unpack_from(endian+'I',raw,pos+total-4)[0]
        if trailing_total != total:
            raise ValueError('PCAPNG block length trailer mismatch')
        block_type=0x0A0D0D0A if block_type_bytes==b'\x0a\x0d\x0d\x0a' else struct.unpack_from(endian+'I',raw,pos)[0]
        if block_type == 0x0A0D0D0A:
            if total < 28:
                raise ValueError('invalid/truncated PCAPNG section header')
            # PCAPNG interface ids are scoped to a section and restart at zero.
            # Keeping linktypes from a previous section can misclassify packets in
            # multi-section captures and therefore corrupt packet/flow evidence.
            linktypes.clear()
        body=raw[pos+8:pos+total-4]
        if block_type == 1:
            if len(body) < 8:
                raise ValueError('invalid/truncated PCAPNG interface description')
            interface_id=len(linktypes); linktypes[interface_id]=struct.unpack_from(endian+'H',body,0)[0]
        elif block_type == 6:
            # Packet numbers in oracle evidence are capture-wide frame numbers.
            # Advance for every packet record. Packet-bearing link types that the
            # production-equivalent replay cannot parse are rejected below rather
            # than silently omitted from certification evidence.
            if len(body) < 20:
                raise ValueError('invalid/truncated PCAPNG enhanced packet block')
            packet_number += 1
            interface_id=struct.unpack_from(endian+'I',body,0)[0]
            if interface_id not in linktypes:
                raise ValueError('PCAPNG enhanced packet references unknown interface')
            cap_len=struct.unpack_from(endian+'I',body,12)[0]
            original_len=struct.unpack_from(endian+'I',body,16)[0]
            if cap_len > original_len or cap_len > len(body)-20:
                raise ValueError('invalid/truncated PCAPNG enhanced packet data')
            packet=body[20:20+cap_len]
            linktype = linktypes.get(interface_id)
            if linktype != 1:
                raise ValueError(f'unsupported PCAPNG linktype {linktype} on packet record; certification completeness cannot be proven')
            segment=_ethernet_ipv4_tcp(packet,packet_number,server_ports)
            if segment is not None: segments.append(segment)
        elif block_type == 3:
            if len(body) < 4:
                raise ValueError('invalid/truncated PCAPNG simple packet block')
            packet_number += 1
            if 0 not in linktypes:
                raise ValueError('PCAPNG simple packet requires interface 0')
            linktype = linktypes.get(0)
            if linktype != 1:
                raise ValueError(f'unsupported PCAPNG linktype {linktype} on simple packet record; certification completeness cannot be proven')
            original_len=struct.unpack_from(endian+'I',body,0)[0]
            packet=body[4:4+min(original_len,len(body)-4)]
            segment=_ethernet_ipv4_tcp(packet,packet_number,server_ports)
            if segment is not None: segments.append(segment)
        elif block_type == 2:
            # Obsolete Packet Block is still legal PCAPNG and may be emitted by
            # conversion tools. It must participate in capture-wide numbering.
            if len(body) < 20:
                raise ValueError('invalid/truncated PCAPNG packet block')
            packet_number += 1
            interface_id=struct.unpack_from(endian+'H',body,0)[0]
            if interface_id not in linktypes:
                raise ValueError('PCAPNG packet references unknown interface')
            cap_len=struct.unpack_from(endian+'I',body,12)[0]
            original_len=struct.unpack_from(endian+'I',body,16)[0]
            if cap_len > original_len or cap_len > len(body)-20:
                raise ValueError('invalid/truncated PCAPNG packet data')
            packet=body[20:20+cap_len]
            linktype = linktypes.get(interface_id)
            if linktype != 1:
                raise ValueError(f'unsupported PCAPNG linktype {linktype} on packet record; certification completeness cannot be proven')
            segment=_ethernet_ipv4_tcp(packet,packet_number,server_ports)
            if segment is not None: segments.append(segment)
        pos += total
    if pos != len(raw):
        raise ValueError('invalid/truncated PCAPNG trailing bytes')
    return segments


def pcapng_packet_count(path: str | Path) -> int:
    """Return the number of packet records in a PCAPNG file.

    Packet numbering in the evidence/oracle contract is the capture-wide packet
    index, not merely the index of packets that happened to decode as Dofus TCP.
    Keeping this parser here ensures oracle alignment is checked against the same
    PCAPNG block semantics as live-decoding replay.
    """
    raw = Path(path).read_bytes()
    pos = 0
    endian = "<"
    packet_count = 0
    while pos + 12 <= len(raw):
        block_type_bytes = raw[pos:pos + 4]
        if block_type_bytes == b"\x0a\x0d\x0d\x0a":
            bom = raw[pos + 8:pos + 12]
            if bom == b"\x4d\x3c\x2b\x1a":
                endian = "<"
            elif bom == b"\x1a\x2b\x3c\x4d":
                endian = ">"
            else:
                raise ValueError("invalid PCAPNG byte-order magic")
        total = struct.unpack_from(endian + "I", raw, pos + 4)[0]
        if total < 12 or total % 4 != 0 or pos + total > len(raw):
            raise ValueError("invalid/truncated PCAPNG block")
        trailing_total = struct.unpack_from(endian + "I", raw, pos + total - 4)[0]
        if trailing_total != total:
            raise ValueError("PCAPNG block length trailer mismatch")
        block_type = (
            0x0A0D0D0A
            if block_type_bytes == b"\x0a\x0d\x0d\x0a"
            else struct.unpack_from(endian + "I", raw, pos)[0]
        )
        body = raw[pos + 8:pos + total - 4]
        if block_type == 0x0A0D0D0A and total < 28:
            raise ValueError("invalid/truncated PCAPNG section header")
        if block_type == 1 and len(body) < 8:
            raise ValueError("invalid/truncated PCAPNG interface description")
        if block_type == 6:
            if len(body) < 20:
                raise ValueError("invalid/truncated PCAPNG enhanced packet block")
            cap_len = struct.unpack_from(endian + "I", body, 12)[0]
            original_len = struct.unpack_from(endian + "I", body, 16)[0]
            if cap_len > original_len or cap_len > len(body) - 20:
                raise ValueError("invalid/truncated PCAPNG enhanced packet data")
            packet_count += 1
        elif block_type == 3:
            if len(body) < 4:
                raise ValueError("invalid/truncated PCAPNG simple packet block")
            packet_count += 1
        elif block_type == 2:
            if len(body) < 20:
                raise ValueError("invalid/truncated PCAPNG packet block")
            cap_len = struct.unpack_from(endian + "I", body, 12)[0]
            original_len = struct.unpack_from(endian + "I", body, 16)[0]
            if cap_len > original_len or cap_len > len(body) - 20:
                raise ValueError("invalid/truncated PCAPNG packet data")
            packet_count += 1
        pos += total
    if pos != len(raw):
        raise ValueError("invalid/truncated PCAPNG trailing bytes")
    return packet_count


def read_dofus_messages_with_diagnostics(path: str | Path, *, server_ports: set[int]):
    """Decode Dofus messages and retain transport/framing integrity diagnostics.

    Certification must not silently ignore bytes discarded while trying to
    recover frame boundaries. The live runtime already exposes this condition;
    offline evidence replay must preserve the same truth.
    """
    from collections import defaultdict
    from anka_platform.capture.envelope import extract_any_messages
    from anka_platform.capture.framing import LengthPrefixedFrameDecoder
    from anka_platform.capture.tcp_stream import TcpStreamReassembler
    from anka_platform.protocol.models import RawProtocolMessage

    streams = defaultdict(TcpStreamReassembler)
    decoders = defaultdict(LengthPrefixedFrameDecoder)
    frame_number = 0
    capture_id = Path(path).stem
    output = []
    dropped_by_key: dict[tuple[str, str], int] = defaultdict(int)
    frame_count_by_key: dict[tuple[str, str], int] = defaultdict(int)
    empty_frame_count_by_key: dict[tuple[str, str], int] = defaultdict(int)

    for segment in read_pcapng_tcp_segments(path, server_ports=server_ports):
        key = (segment.flow_id, segment.direction)
        if segment.syn:
            streams[key] = TcpStreamReassembler()
            decoders[key] = LengthPrefixedFrameDecoder()
        if not segment.payload:
            continue
        seq = int(segment.seq) + (1 if segment.syn else 0)
        contiguous = streams[key].feed(seq, segment.payload)
        if not contiguous:
            continue
        decoder = decoders[key]
        before_dropped = int(decoder.dropped_bytes)
        frames = decoder.feed(contiguous)
        dropped_by_key[key] += int(decoder.dropped_bytes) - before_dropped
        for frame in frames:
            frame_number += 1
            frame_count_by_key[key] += 1
            extracted = extract_any_messages(frame)
            if not extracted:
                empty_frame_count_by_key[key] += 1
            for name, payload in extracted:
                output.append(RawProtocolMessage(
                    direction=segment.direction,
                    name=name,
                    payload=payload,
                    frame_number=frame_number,
                    packet_number=segment.packet_number,
                    source='live',
                    capture_id=capture_id,
                    flow_id=segment.flow_id,
                ))

    all_keys = set(streams) | set(decoders) | set(dropped_by_key) | set(frame_count_by_key)
    flow_diagnostics = {}
    for flow_id, direction in sorted(all_keys):
        key = (flow_id, direction)
        stream = streams[key]
        decoder = decoders[key]
        flow_diagnostics[f"{flow_id}|{direction}"] = {
            "flow_id": flow_id,
            "direction": direction,
            "framed_frames": int(frame_count_by_key.get(key, 0)),
            "empty_envelope_frames": int(empty_frame_count_by_key.get(key, 0)),
            "framing_dropped_bytes": int(dropped_by_key.get(key, 0)),
            "framing_buffered_bytes": len(decoder.buffer),
            "reassembly_pending_intervals": len(stream.pending),
            "reassembly_duplicate_segments": int(stream.duplicate_segments),
            "reassembly_overlap_segments": int(stream.overlap_segments),
        }
    diagnostics = {
        "framing_dropped_bytes": sum(int(row["framing_dropped_bytes"]) for row in flow_diagnostics.values()),
        "framing_buffered_bytes": sum(int(row["framing_buffered_bytes"]) for row in flow_diagnostics.values()),
        "reassembly_pending_intervals": sum(int(row["reassembly_pending_intervals"]) for row in flow_diagnostics.values()),
        "framed_frames": sum(int(row["framed_frames"]) for row in flow_diagnostics.values()),
        "empty_envelope_frames": sum(int(row["empty_envelope_frames"]) for row in flow_diagnostics.values()),
        "flows": flow_diagnostics,
    }
    return tuple(output), diagnostics


def read_dofus_messages(path: str | Path, *, server_ports: set[int]):
    """Decode a PCAPNG through the same transport boundary used by live capture."""
    messages, _diagnostics = read_dofus_messages_with_diagnostics(path, server_ports=server_ports)
    return messages


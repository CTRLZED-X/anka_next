from __future__ import annotations

from collections import defaultdict
import time
from datetime import datetime, timezone
from threading import RLock

from anka_platform.capture.envelope import extract_any_messages
from anka_platform.capture.framing import LengthPrefixedFrameDecoder
from anka_platform.capture.models import CapturedTcpSegment
from anka_platform.capture.tcp_stream import TcpStreamReassembler
from anka_platform.live_state.store import CanonicalStateStore
from anka_platform.protocol.adapter import ProtocolAdapter
from anka_platform.protocol.models import RawProtocolMessage
from anka_platform.capture.service import LiveIngestionService


class LiveTransportRuntime:
    """Stateful transport -> versioned adapter -> confirmed-state bridge."""
    def __init__(self,adapter:ProtocolAdapter,store:CanonicalStateStore,*,capture_id:str='live',account_id:str|None=None,client_instance_id:str|None=None,observability=None,critical_debug_export=None)->None:
        self.adapter=adapter
        self.store=store
        self.capture_id=capture_id
        self.account_id=account_id
        self.client_instance_id=client_instance_id
        self.ingestion=LiveIngestionService(adapter,store,client_instance_id=client_instance_id,observability=observability,critical_debug_export=critical_debug_export)
        self._streams=defaultdict(TcpStreamReassembler)
        self._frames=defaultdict(LengthPrefixedFrameDecoder)
        self._active_keys=set()
        # Framing may attach in the middle of an already-open TCP stream. Bytes
        # discarded before the first valid Ankama envelope are acquisition
        # resynchronization, not evidence of corruption after semantic framing
        # has been established. The baseline freezes at first valid message; only
        # later drops contribute to the execution-safety health signal.
        self._flow_frame_drop_baseline: dict[tuple[str, str], int] = {}
        self._frame_number=0
        self._lock=RLock()
        # Capture framing/ingestion may legitimately hold _lock while protocol
        # transforms and canonical-store writes complete. Health/status readers
        # must never wait behind that work: they use a separate, tiny metrics
        # lock containing only scalar snapshot state.
        self._status_lock=RLock()
        self._dropped_frame_bytes=0
        self._protocol_dialect=str(getattr(self.adapter,'protocol_dialect','UNKNOWN') or 'UNKNOWN')
        self._protocol_decoder_ready=bool(getattr(self.adapter,'protocol_decoder_ready',False))
        self._protocol_decoder_mode=str(getattr(self.adapter,'protocol_decoder_mode',getattr(self.adapter,'adapter_id','UNKNOWN')) or 'UNKNOWN')
        self._local_actor_id=getattr(self.adapter,'local_actor_id',None)
        self._local_actor_identity_source=str(getattr(self.adapter,'local_actor_identity_source','NONE') or 'NONE')
        self._local_actor_identity_rank=int(getattr(self.adapter,'local_actor_identity_rank',0) or 0)
        self.segment_count=0
        self.message_count=0
        self.canonical_event_count=0
        self.classified_message_count=0
        self.zero_event_message_count=0
        self.opaque_compatibility_count=0
        self._zero_event_message_names: dict[str, int] = defaultdict(int)
        self._canonical_event_kinds: dict[str, int] = defaultdict(int)
        self._transform_failure_capabilities: dict[str, int] = defaultdict(int)
        self.transform_failure_count=0
        self.canonical_state_failure_count=0
        self.canonical_ingestion_halt_count=0
        self.canonical_state_failure_active=False
        self.last_canonical_state_failure_code: str|None=None
        self.last_canonical_state_failure_stage: str|None=None
        self.last_canonical_state_failure_detail: str|None=None
        self.last_canonical_state_failure_monotonic: float|None=None
        self.last_canonical_state_failure_utc: str|None=None
        self.protocol_context_failure_count=0
        self.protocol_context_failure_active=False
        self.last_protocol_context_failure_code: str|None=None
        self.last_protocol_context_failure_stage: str|None=None
        self.last_protocol_context_failure_detail: str|None=None
        self.last_protocol_context_failure_monotonic: float|None=None
        self.last_protocol_context_failure_utc: str|None=None
        self.unprocessed_message_count=0
        self.unclassified_count=0
        # Preserve bounded aggregate identity for unknown outer wire types.  The
        # old runtime exposed only the most recent free-form detail string, which
        # forced incident analysis to reopen packet windows just to learn which
        # opcode blocked startup.  This counter is diagnostic-only and never
        # assigns gameplay semantics.
        self._unclassified_message_names: dict[str, int] = defaultdict(int)
        # A completely unknown outer wire type is revision drift just as surely
        # as an unknown action id inside a known server action envelope.  Known opaque
        # compatibility traffic is filtered by LiveIngestionService before it
        # reaches this counter, so a remaining unclassified message is sticky
        # execution-safety evidence for this runtime generation.
        self.protocol_unclassified_active=False
        self.last_unclassified_detail: str|None=None
        self.last_unclassified_monotonic: float|None=None
        self.last_unclassified_utc: str|None=None
        # ``last_error`` is the *active* transform-health latch consumed by
        # readiness. Historical failures are retained separately so a single
        # version-drift packet cannot poison all later healthy canonical progress.
        self.last_error: str|None=None
        self.last_transform_failure_detail: str|None=None
        self.last_transform_failure_category: str|None=None
        self.last_transform_failure_capability: str|None=None
        self.last_transform_failure_wire_semantic: str|None=None
        self.last_transform_failure_adapter_id: str|None=None
        self.last_transform_failure_monotonic: float|None=None
        self.last_transform_failure_utc: str|None=None
        # Schema/action drift means the selected revision adapter encountered a
        # shape it is not certified to interpret. Unlike an ordinary transient
        # transform failure, later unrelated canonical traffic must not silently
        # reopen physical automation. A fresh runtime/adapter is required after
        # the protocol evidence and decoder are updated.
        self.protocol_schema_drift_active=False
        self.protocol_schema_drift_count=0
        self.last_protocol_schema_drift_detail: str|None=None
        self.last_protocol_schema_drift_monotonic: float|None=None
        self.last_protocol_schema_drift_utc: str|None=None
        self.transform_recovery_count=0
        self.last_segment_monotonic: float|None=None
        self.last_segment_utc: str|None=None
        self.last_message_monotonic: float|None=None
        self.last_message_utc: str|None=None
        self.last_canonical_event_monotonic: float|None=None
        self.last_canonical_event_utc: str|None=None
        # Per-flow diagnostics prevent one still-active auxiliary connection from
        # masking a stalled game flow in account-wide freshness metrics. Values
        # are copied under _status_lock; status() never touches reassembly locks.
        self._flow_metrics: dict[tuple[str, str], dict] = {}

    def _ensure_protocol_health_latches(self) -> None:
        """Backfill protocol-health fields for restored/legacy runtime objects.

        Normal construction initializes these fields in ``__init__``.  Recovery,
        migration and focused diagnostics can legitimately hydrate an older or
        partially constructed runtime object, though; health handling must fail
        closed on protocol evidence instead of crashing because a newly-added
        latch attribute is absent.
        """
        defaults = {
            'protocol_unclassified_active': False,
            'last_unclassified_detail': None,
            'last_unclassified_monotonic': None,
            'last_unclassified_utc': None,
            'protocol_schema_drift_active': False,
            'protocol_schema_drift_count': 0,
            'last_protocol_schema_drift_detail': None,
            'last_protocol_schema_drift_monotonic': None,
            'last_protocol_schema_drift_utc': None,
            'last_error': None,
            'last_transform_failure_detail': None,
            'last_transform_failure_category': None,
            'last_transform_failure_capability': None,
            'last_transform_failure_wire_semantic': None,
            'last_transform_failure_adapter_id': None,
            'last_transform_failure_monotonic': None,
            'last_transform_failure_utc': None,
            'transform_recovery_count': 0,
            'canonical_state_failure_count': 0,
            'canonical_ingestion_halt_count': 0,
            'canonical_state_failure_active': False,
            'last_canonical_state_failure_code': None,
            'last_canonical_state_failure_stage': None,
            'last_canonical_state_failure_detail': None,
            'last_canonical_state_failure_monotonic': None,
            'last_canonical_state_failure_utc': None,
            'protocol_context_failure_count': 0,
            'protocol_context_failure_active': False,
            'last_protocol_context_failure_code': None,
            'last_protocol_context_failure_stage': None,
            'last_protocol_context_failure_detail': None,
            'last_protocol_context_failure_monotonic': None,
            'last_protocol_context_failure_utc': None,
            'unprocessed_message_count': 0,
        }
        for name, value in defaults.items():
            if not hasattr(self, name):
                setattr(self, name, value)
        if not hasattr(self, '_unclassified_message_names'):
            self._unclassified_message_names = defaultdict(int)

    def _apply_transform_health(self, report) -> None:
        """Update sticky protocol-health latches while preserving history.

        Readiness consumes ``last_error`` as an active transform fault. A normal
        transform failure may recover after later healthy canonical progress, but
        schema drift and truly unclassified wire traffic stay latched for the
        runtime generation.  Caller holds ``_status_lock`` in the live path;
        tests may call this method directly before the runtime is shared.
        """
        self._ensure_protocol_health_latches()
        unclassified=tuple(getattr(report,'unclassified_messages',()) or ())
        if unclassified:
            for unknown in unclassified:
                key = f'{unknown.name}|{unknown.direction}'
                self._unclassified_message_names[str(key)] += 1
            item=unclassified[-1]
            now=time.monotonic()
            now_utc=datetime.now(timezone.utc).isoformat()
            self.protocol_unclassified_active=True
            self.last_unclassified_detail=(
                f'PROTOCOL_UNKNOWN_MESSAGE: name={item.name} direction={item.direction} '
                f'frame={item.frame_number}'
            )
            self.last_unclassified_monotonic=now
            self.last_unclassified_utc=now_utc
        canonical_failures=tuple(getattr(report,'canonical_state_failures',()) or ())
        context_failures=tuple(getattr(report,'protocol_context_failures',()) or ())
        if report.transform_failures:
            failures = tuple(report.transform_failures)
            details = tuple(str(item.detail) for item in failures)
            latest = failures[-1]
            detail = details[-1]
            now = time.monotonic()
            now_utc = datetime.now(timezone.utc).isoformat()
            self.last_error = detail
            self.last_transform_failure_detail = detail
            self.last_transform_failure_category = str(getattr(latest, "category", "") or "") or None
            self.last_transform_failure_capability = str(getattr(latest, "capability", "") or "") or None
            self.last_transform_failure_wire_semantic = str(getattr(latest, "wire_semantic", "") or "") or None
            self.last_transform_failure_adapter_id = str(getattr(latest, "adapter_id", "") or "") or None
            self.last_transform_failure_monotonic = now
            self.last_transform_failure_utc = now_utc
            drift_failures = tuple(
                item for item in failures
                if bool(getattr(item, "is_schema_drift", False))
                or str(getattr(item, "category", "") or "") == "SCHEMA_DRIFT"
                # Backward-compatible ingestion of persisted/legacy fixtures.
                or str(getattr(item, "detail", "") or "").startswith("ProtocolSchemaDriftError:")
            )
            if drift_failures:
                self.protocol_schema_drift_active = True
                self.protocol_schema_drift_count += len(drift_failures)
                self.last_protocol_schema_drift_detail = str(drift_failures[-1].detail)
                self.last_protocol_schema_drift_monotonic = now
                self.last_protocol_schema_drift_utc = now_utc
        elif (
            report.canonical_event_count
            and self.last_error is not None
            and not self.protocol_schema_drift_active
            and not self.canonical_state_failure_active
            and not self.protocol_context_failure_active
        ):
            self.last_error = None
            self.transform_recovery_count += 1

        # Persistence and protocol-context recovery failures outrank ordinary
        # transform failures. A single report can contain both (for example, a
        # transform exception followed by a failed context restore). Preserve
        # the most safety-critical owner as the headline error while retaining
        # the transform details in their dedicated fields.
        if canonical_failures:
            latest=canonical_failures[-1]
            now=time.monotonic()
            now_utc=datetime.now(timezone.utc).isoformat()
            self.canonical_state_failure_active=True
            self.last_canonical_state_failure_code=str(getattr(latest,'failure_code','CANONICAL_STATE_FAILURE') or 'CANONICAL_STATE_FAILURE')
            self.last_canonical_state_failure_stage=str(getattr(latest,'stage','unknown') or 'unknown')
            self.last_canonical_state_failure_detail=str(getattr(latest,'detail','') or '')
            self.last_canonical_state_failure_monotonic=now
            self.last_canonical_state_failure_utc=now_utc
            self.last_error=(
                f'{self.last_canonical_state_failure_code}: '
                f'{self.last_canonical_state_failure_detail}'
            )
        if context_failures:
            latest=context_failures[-1]
            now=time.monotonic()
            now_utc=datetime.now(timezone.utc).isoformat()
            self.protocol_context_failure_active=True
            self.last_protocol_context_failure_code=str(getattr(latest,'failure_code','PROTOCOL_CONTEXT_FAILURE') or 'PROTOCOL_CONTEXT_FAILURE')
            self.last_protocol_context_failure_stage=str(getattr(latest,'stage','unknown') or 'unknown')
            self.last_protocol_context_failure_detail=str(getattr(latest,'detail','') or '')
            self.last_protocol_context_failure_monotonic=now
            self.last_protocol_context_failure_utc=now_utc
            self.last_error=(
                f'{self.last_protocol_context_failure_code}: '
                f'{self.last_protocol_context_failure_detail}'
            )

    def feed_segment(self,segment:CapturedTcpSegment)->None:
        with self._lock:
            now=time.monotonic()
            now_utc=datetime.now(timezone.utc).isoformat()
            key=(segment.flow_id,segment.direction)
            if segment.syn:
                # New TCP sequence space for this directional 4-tuple. Reset both
                # reassembly and framing state before accepting any new bytes.
                # This is essential for reconnect-after-outage continuity.
                self._streams[key]=TcpStreamReassembler()
                self._frames[key]=LengthPrefixedFrameDecoder()
                self._active_keys.discard(key)
                self._flow_frame_drop_baseline.pop(key, None)
                with self._status_lock:
                    prior=dict(self._flow_metrics.get(key) or {})
                    self._flow_metrics[key]={
                        'flow_id':str(segment.flow_id),
                        'direction':str(segment.direction),
                        'connection_generation':int(prior.get('connection_generation') or 0)+1,
                        'connection_reset_count':int(prior.get('connection_reset_count') or 0)+1,
                        'last_connection_start_monotonic':now,
                        'last_connection_start_utc':now_utc,
                        'syn_count':int(prior.get('syn_count') or 0)+1,
                        'rst_count':int(prior.get('rst_count') or 0),
                        'fin_count':int(prior.get('fin_count') or 0),
                    }
            if segment.rst or segment.fin:
                with self._status_lock:
                    control=dict(self._flow_metrics.get(key) or {})
                    control.setdefault('flow_id',str(segment.flow_id))
                    control.setdefault('direction',str(segment.direction))
                    if segment.rst:
                        control['rst_count']=int(control.get('rst_count') or 0)+1
                        control['last_reset_monotonic']=now
                        control['last_reset_utc']=now_utc
                    if segment.fin:
                        control['fin_count']=int(control.get('fin_count') or 0)+1
                        control['last_fin_monotonic']=now
                        control['last_fin_utc']=now_utc
                    self._flow_metrics[key]=control
            if not segment.payload:
                return
            with self._status_lock:
                self.segment_count += 1
                self.last_segment_monotonic=now
                self.last_segment_utc=now_utc
            stream=self._streams[key]
            effective_seq=int(segment.seq)+(1 if segment.syn else 0)
            contiguous=stream.feed(effective_seq,segment.payload)
            pending_bytes=sum(len(chunk) for _seq, chunk in stream.pending)
            first_pending_seq=(stream.pending[0][0] if stream.pending else None)
            first_gap_bytes=(
                max(0, int(first_pending_seq)-int(stream.expected_seq))
                if first_pending_seq is not None and stream.expected_seq is not None
                else 0
            )
            with self._status_lock:
                metrics=dict(self._flow_metrics.get(key) or {})
                metrics.update({
                    'flow_id':str(segment.flow_id),
                    'direction':str(segment.direction),
                    'segment_count':int(metrics.get('segment_count') or 0)+1,
                    'payload_bytes':int(metrics.get('payload_bytes') or 0)+len(segment.payload),
                    'last_segment_monotonic':now,
                    'last_segment_utc':now_utc,
                    'expected_seq':stream.expected_seq,
                    'pending_interval_count':len(stream.pending),
                    'pending_bytes':int(pending_bytes),
                    'first_gap_bytes':int(first_gap_bytes),
                    'duplicate_segments':int(stream.duplicate_segments),
                    'overlap_segments':int(stream.overlap_segments),
                })
                if contiguous:
                    metrics['contiguous_bytes']=int(metrics.get('contiguous_bytes') or 0)+len(contiguous)
                    metrics['last_contiguous_monotonic']=now
                    metrics['last_contiguous_utc']=now_utc
                self._flow_metrics[key]=metrics
            if not contiguous:
                return
            for frame in self._frames[key].feed(contiguous):
                with self._status_lock:
                    self._frame_number += 1
                    frame_number=int(self._frame_number)
                extracted=extract_any_messages(frame)
                if not extracted:
                    continue
                if key not in self._active_keys:
                    self._flow_frame_drop_baseline[key]=int(self._frames[key].dropped_bytes)
                self._active_keys.add(key)
                message_now=time.monotonic()
                message_utc=datetime.now(timezone.utc).isoformat()
                with self._status_lock:
                    self.last_message_monotonic=message_now
                    self.last_message_utc=message_utc
                messages=tuple(RawProtocolMessage(
                    direction=segment.direction,
                    name=name,
                    payload=payload,
                    frame_number=frame_number,
                    packet_number=segment.packet_number,
                    source='live',
                    capture_id=self.capture_id,
                    flow_id=segment.flow_id,
                    account_id=self.account_id,
                    client_instance_id=self.client_instance_id,
                ) for name,payload in extracted)

                # This can include protocol transformation and canonical-store IO.
                # Deliberately do not hold _status_lock while it runs.
                report=self.ingestion.ingest_many(messages)
                canonical_now=time.monotonic() if report.canonical_event_count else None
                canonical_utc=datetime.now(timezone.utc).isoformat() if report.canonical_event_count else None
                with self._status_lock:
                    self.message_count += report.message_count
                    flow_metrics=dict(self._flow_metrics.get(key) or {})
                    flow_metrics['message_count']=int(flow_metrics.get('message_count') or 0)+int(report.message_count)
                    if report.message_count:
                        flow_metrics['last_message_monotonic']=message_now
                        flow_metrics['last_message_utc']=message_utc
                    flow_metrics['frame_buffered_bytes']=len(self._frames[key].buffer)
                    total_frame_drops=int(self._frames[key].dropped_bytes)
                    acquisition_baseline=int(self._flow_frame_drop_baseline.get(key, total_frame_drops if key not in self._active_keys else 0))
                    flow_metrics['frame_dropped_bytes']=total_frame_drops
                    flow_metrics['frame_acquisition_dropped_bytes']=min(total_frame_drops, acquisition_baseline)
                    flow_metrics['frame_safety_dropped_bytes']=max(0, total_frame_drops-acquisition_baseline)
                    self._flow_metrics[key]=flow_metrics
                    self.canonical_event_count += report.canonical_event_count
                    self.classified_message_count += int(getattr(report, 'classified_message_count', 0) or 0)
                    self.zero_event_message_count += int(getattr(report, 'zero_event_message_count', 0) or 0)
                    self.opaque_compatibility_count += int(getattr(report, 'opaque_compatibility_count', 0) or 0)
                    for zero_name in tuple(getattr(report, 'zero_event_message_names', ()) or ()):
                        self._zero_event_message_names[str(zero_name)] += 1
                    for event_kind in tuple(getattr(report, 'canonical_event_kinds', ()) or ()):
                        self._canonical_event_kinds[str(event_kind)] += 1
                    for capability in tuple(getattr(report, 'transform_failure_capabilities', ()) or ()):
                        self._transform_failure_capabilities[str(capability)] += 1
                    if canonical_now is not None:
                        self.last_canonical_event_monotonic=canonical_now
                        self.last_canonical_event_utc=canonical_utc
                    self.transform_failure_count += len(report.transform_failures)
                    canonical_failures=tuple(getattr(report,'canonical_state_failures',()) or ())
                    self.canonical_state_failure_count += len(canonical_failures)
                    context_failures=tuple(getattr(report,'protocol_context_failures',()) or ())
                    self.protocol_context_failure_count += len(context_failures)
                    if bool(getattr(report,'ingestion_halted',False)):
                        self.canonical_ingestion_halt_count += 1
                    self.unprocessed_message_count += int(getattr(report,'unprocessed_message_count',0) or 0)
                    self.unclassified_count += len(report.unclassified_messages)
                    self._apply_transform_health(report)
                    # Adapter identity evolves from classified protocol evidence.
                    # Cache it under the cheap status lock after each ingestion.
                    self._local_actor_id=getattr(self.adapter,'local_actor_id',None)
                    self._local_actor_identity_source=str(getattr(self.adapter,'local_actor_identity_source','NONE') or 'NONE')
                    self._local_actor_identity_rank=int(getattr(self.adapter,'local_actor_identity_rank',0) or 0)
            with self._status_lock:
                flow_metrics=dict(self._flow_metrics.get(key) or {})
                flow_metrics['frame_buffered_bytes']=len(self._frames[key].buffer)
                total_frame_drops=int(self._frames[key].dropped_bytes)
                acquisition_baseline=int(self._flow_frame_drop_baseline.get(key, total_frame_drops if key not in self._active_keys else 0))
                flow_metrics['frame_dropped_bytes']=total_frame_drops
                flow_metrics['frame_acquisition_dropped_bytes']=min(total_frame_drops, acquisition_baseline)
                flow_metrics['frame_safety_dropped_bytes']=max(0, total_frame_drops-acquisition_baseline)
                self._flow_metrics[key]=flow_metrics
            # Fail closed on framing loss only after a flow has established valid
            # semantic framing. Initial attach-to-midstream resynchronization is
            # retained in per-flow diagnostics but cannot permanently poison a
            # runtime that later establishes healthy current Canonical truth.
            dropped=sum(
                max(0, int(self._frames[item].dropped_bytes)-int(self._flow_frame_drop_baseline.get(item, 0)))
                for item in self._active_keys
            )
            with self._status_lock:
                self._dropped_frame_bytes=int(dropped)

    def status(self)->dict:
        # Never acquire the framing/ingestion lock here. Passive health is a hot
        # control-loop read and must remain available while packet transformation
        # or canonical-store work is in progress. All values below are scalar
        # snapshots protected by the dedicated metrics lock.
        with self._status_lock:
            now=time.monotonic()
            def age(value):
                return None if value is None else max(0.0, now-float(value))
            flows=[]
            for (_flow_id, _direction), raw in sorted(self._flow_metrics.items(), key=lambda item: (str(item[0][0]), str(item[0][1]))):
                item=dict(raw)
                item['last_segment_age_seconds']=age(item.get('last_segment_monotonic'))
                item['last_contiguous_age_seconds']=age(item.get('last_contiguous_monotonic'))
                item['last_message_age_seconds']=age(item.get('last_message_monotonic'))
                item['reassembly_stalled']=bool(
                    int(item.get('pending_interval_count') or 0)>0
                    and int(item.get('first_gap_bytes') or 0)>0
                )
                flows.append(item)
            return {
                'capture_id':self.capture_id,
                'account_id':self.account_id,
                'client_instance_id':self.client_instance_id,
                'protocol_dialect':str(getattr(self.adapter,'protocol_dialect',self._protocol_dialect) or 'UNKNOWN'),
                'protocol_adapter_id':str(getattr(self.adapter,'adapter_id','UNKNOWN') or 'UNKNOWN'),
                'protocol_decoder_ready':bool(getattr(self.adapter,'protocol_decoder_ready',self._protocol_decoder_ready)),
                'protocol_decoder_mode':str(getattr(self.adapter,'protocol_decoder_mode',self._protocol_decoder_mode) or 'UNKNOWN'),
                'local_actor_id':getattr(self.adapter,'local_actor_id',self._local_actor_id),
                'local_actor_identity_source':str(getattr(self.adapter,'local_actor_identity_source',self._local_actor_identity_source) or 'NONE'),
                'local_actor_identity_rank':int(getattr(self.adapter,'local_actor_identity_rank',self._local_actor_identity_rank) or 0),
                'segment_count':self.segment_count,
                'frame_count':self._frame_number,
                'message_count':self.message_count,
                'canonical_event_count':self.canonical_event_count,
                'classified_message_count':self.classified_message_count,
                'zero_event_message_count':self.zero_event_message_count,
                'zero_event_message_names':dict(sorted(getattr(self, '_zero_event_message_names', {}).items(), key=lambda item: (-item[1], item[0]))[:32]),
                'canonical_event_kinds':dict(sorted(getattr(self, '_canonical_event_kinds', {}).items(), key=lambda item: (-item[1], item[0]))),
                'transform_failure_capabilities':dict(sorted(getattr(self, '_transform_failure_capabilities', {}).items(), key=lambda item: (-item[1], item[0]))),
                'opaque_compatibility_count':self.opaque_compatibility_count,
                'transform_failure_count':self.transform_failure_count,
                'canonical_state_failure_count':int(getattr(self,'canonical_state_failure_count',0) or 0),
                'canonical_ingestion_halt_count':int(getattr(self,'canonical_ingestion_halt_count',0) or 0),
                'canonical_state_failure_active':bool(getattr(self,'canonical_state_failure_active',False)),
                'last_canonical_state_failure_code':getattr(self,'last_canonical_state_failure_code',None),
                'last_canonical_state_failure_stage':getattr(self,'last_canonical_state_failure_stage',None),
                'last_canonical_state_failure_detail':getattr(self,'last_canonical_state_failure_detail',None),
                'last_canonical_state_failure_monotonic':getattr(self,'last_canonical_state_failure_monotonic',None),
                'last_canonical_state_failure_utc':getattr(self,'last_canonical_state_failure_utc',None),
                'last_canonical_state_failure_age_seconds':age(getattr(self,'last_canonical_state_failure_monotonic',None)),
                'protocol_context_failure_count':int(getattr(self,'protocol_context_failure_count',0) or 0),
                'protocol_context_failure_active':bool(getattr(self,'protocol_context_failure_active',False)),
                'last_protocol_context_failure_code':getattr(self,'last_protocol_context_failure_code',None),
                'last_protocol_context_failure_stage':getattr(self,'last_protocol_context_failure_stage',None),
                'last_protocol_context_failure_detail':getattr(self,'last_protocol_context_failure_detail',None),
                'last_protocol_context_failure_monotonic':getattr(self,'last_protocol_context_failure_monotonic',None),
                'last_protocol_context_failure_utc':getattr(self,'last_protocol_context_failure_utc',None),
                'last_protocol_context_failure_age_seconds':age(getattr(self,'last_protocol_context_failure_monotonic',None)),
                'unprocessed_message_count':int(getattr(self,'unprocessed_message_count',0) or 0),
                'unclassified_count':self.unclassified_count,
                'unclassified_message_names':dict(sorted(
                    getattr(self, '_unclassified_message_names', {}).items(),
                    key=lambda item: (-item[1], item[0]),
                )[:32]),
                'protocol_unclassified_active':bool(self.protocol_unclassified_active),
                'last_unclassified_detail':self.last_unclassified_detail,
                'last_unclassified_monotonic':self.last_unclassified_monotonic,
                'last_unclassified_utc':self.last_unclassified_utc,
                'last_unclassified_age_seconds':age(self.last_unclassified_monotonic),
                'dropped_frame_bytes':self._dropped_frame_bytes,
                'last_error':self.last_error,
                'last_transform_failure_detail':self.last_transform_failure_detail,
                'last_transform_failure_category':self.last_transform_failure_category,
                'last_transform_failure_capability':self.last_transform_failure_capability,
                'last_transform_failure_wire_semantic':self.last_transform_failure_wire_semantic,
                'last_transform_failure_adapter_id':self.last_transform_failure_adapter_id,
                'last_transform_failure_monotonic':self.last_transform_failure_monotonic,
                'last_transform_failure_utc':self.last_transform_failure_utc,
                'last_transform_failure_age_seconds':age(self.last_transform_failure_monotonic),
                'protocol_schema_drift_active':bool(self.protocol_schema_drift_active),
                'protocol_schema_drift_count':int(self.protocol_schema_drift_count),
                'last_protocol_schema_drift_detail':self.last_protocol_schema_drift_detail,
                'last_protocol_schema_drift_monotonic':self.last_protocol_schema_drift_monotonic,
                'last_protocol_schema_drift_utc':self.last_protocol_schema_drift_utc,
                'last_protocol_schema_drift_age_seconds':age(self.last_protocol_schema_drift_monotonic),
                'transform_recovery_count':self.transform_recovery_count,
                'last_segment_monotonic':self.last_segment_monotonic,
                'last_segment_utc':self.last_segment_utc,
                'last_segment_age_seconds':age(self.last_segment_monotonic),
                'last_message_monotonic':self.last_message_monotonic,
                'last_message_utc':self.last_message_utc,
                'last_message_age_seconds':age(self.last_message_monotonic),
                'last_canonical_event_monotonic':self.last_canonical_event_monotonic,
                'last_canonical_event_utc':self.last_canonical_event_utc,
                'last_canonical_event_age_seconds':age(self.last_canonical_event_monotonic),
                'flows':flows,
            }


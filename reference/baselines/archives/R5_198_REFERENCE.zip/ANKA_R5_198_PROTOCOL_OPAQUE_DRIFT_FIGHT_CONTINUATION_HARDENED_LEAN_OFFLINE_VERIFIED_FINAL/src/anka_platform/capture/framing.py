from __future__ import annotations

from anka_platform.protocol.protobuf import read_varint


class LengthPrefixedFrameDecoder:
    def __init__(self, *, max_frame_size: int = 2_000_000) -> None:
        self.buffer=bytearray()
        self.max_frame_size=int(max_frame_size)
        self.dropped_bytes=0

    def feed(self,payload:bytes)->list[bytes]:
        if payload: self.buffer.extend(payload)
        frames=[]
        while self.buffer:
            length,after=read_varint(self.buffer,0)
            if length is None: break
            if length<=0 or length>self.max_frame_size:
                del self.buffer[:1]; self.dropped_bytes += 1; continue
            end=after+length
            if len(self.buffer)<end: break
            frames.append(bytes(self.buffer[after:end]))
            del self.buffer[:end]
        return frames

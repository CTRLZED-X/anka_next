from __future__ import annotations

from importlib.util import find_spec
from pathlib import Path
from threading import RLock
from typing import Callable

from anka_platform.capture.models import CapturedTcpSegment


class CaptureUnavailable(RuntimeError):
    pass


class ScapyCaptureBackend:
    """Lazy Windows/Npcap edge. Importing ANKA never requires Scapy."""
    def __init__(self,*,ports:tuple[int,...],on_segment:Callable[[CapturedTcpSegment],None],interface:str|None=None,capture_path:str|Path|None=None)->None:
        self.ports=tuple(dict.fromkeys(int(p) for p in ports))
        self.on_segment=on_segment
        self.interface=interface
        self.capture_path=Path(capture_path) if capture_path else None
        self.running=False
        self.error: str|None=None
        self.packet_count=0
        self._sniffer=None
        self._writer=None
        self._lock=RLock()

    @staticmethod
    def available()->bool:
        return find_spec('scapy') is not None

    def start(self)->None:
        with self._lock:
            if self.running: return
            if not self.available():
                raise CaptureUnavailable('Scapy is not installed; run setup.bat')
            from scapy.all import AsyncSniffer, IP, TCP, Raw  # type: ignore
            if self.capture_path is not None:
                from scapy.utils import PcapNgWriter  # type: ignore
                self.capture_path.parent.mkdir(parents=True,exist_ok=True)
                self._writer=PcapNgWriter(str(self.capture_path))

            server_ports=set(self.ports)
            def callback(packet):
                try:
                    with self._lock:
                        self.packet_count += 1
                    if self._writer is not None:
                        self._writer.write(packet)
                    # The configured BPF only admits selected-port TCP traffic.
                    # ANKA's current transport identity/reassembly contract is IPv4.
                    # Never silently drop selected-port IPv6 (or another non-IPv4
                    # TCP form), otherwise runtime health could appear ready while
                    # game traffic is present on a transport we cannot consume.
                    if packet.haslayer(TCP) and not packet.haslayer(IP):
                        raise CaptureUnavailable(
                            'selected-port non-IPv4 TCP traffic is unsupported by the current live capture runtime'
                        )
                    if not packet.haslayer(IP) or not packet.haslayer(TCP):
                        return
                    ip=packet[IP]; tcp=packet[TCP]
                    sport=int(tcp.sport); dport=int(tcp.dport)
                    if sport not in server_ports and dport not in server_ports:
                        return
                    payload=bytes(packet[Raw].load) if packet.haslayer(Raw) else b''
                    flags=int(tcp.flags)
                    # Preserve connection-generation control packets. Without SYN
                    # visibility, a reconnect reusing the same TCP 4-tuple can leave
                    # the old sequence-space reassembler stalled forever.
                    if not payload and not (flags & (0x01 | 0x02 | 0x04)):
                        return
                    if sport in server_ports:
                        direction='server_to_client'; server=f'{ip.src}:{sport}'; client=f'{ip.dst}:{dport}'
                    else:
                        direction='client_to_server'; server=f'{ip.dst}:{dport}'; client=f'{ip.src}:{sport}'
                    self.on_segment(CapturedTcpSegment(
                        flow_id=f'{client}<->{server}',direction=direction,seq=int(tcp.seq),payload=payload,packet_number=self.packet_count,tcp_flags=flags,
                    ))
                except Exception as exc:
                    self.error=f'{type(exc).__name__}: {exc}'

            bpf=' or '.join(f'tcp port {port}' for port in self.ports)
            self._sniffer=AsyncSniffer(iface=self.interface,filter=bpf,prn=callback,store=False)
            self._sniffer.start()
            self.running=True

    def stop(self)->None:
        with self._lock:
            sniffer=self._sniffer; writer=self._writer
            self._sniffer=None; self._writer=None; self.running=False
        if sniffer is not None:
            try: sniffer.stop()
            except Exception: pass
        if writer is not None:
            try: writer.close()
            except Exception: pass

    def status(self)->dict:
        """Return configured and observed backend health without importing Scapy.

        ``running`` used to mirror only ANKA's configured flag.  If Scapy's
        AsyncSniffer thread died unexpectedly, that could make diagnostics claim
        capture was healthy until higher-level freshness watchdogs noticed the
        absence of packets.  The observed thread state is now surfaced when the
        backend exposes it, while test/fake sniffers that do not implement a
        ``running`` attribute retain the configured value.  This remains a
        passive health signal: capture is never blindly restarted here.
        """
        with self._lock:
            configured_running=bool(self.running)
            sniffer=self._sniffer
            packet_count=int(self.packet_count)
            error=self.error
        observed=getattr(sniffer,'running',None) if sniffer is not None else None
        sniffer_running=(configured_running if observed is None else bool(observed))
        effective_running=bool(configured_running and sniffer_running)
        return {
            'available':self.available(),
            'running':effective_running,
            'configured_running':configured_running,
            'sniffer_running':sniffer_running,
            'unexpected_stop':bool(configured_running and not sniffer_running),
            'packet_count':packet_count,
            'error':error,
            'ports':list(self.ports),
            'capture_path':str(self.capture_path) if self.capture_path else None,
        }

from __future__ import annotations

from dataclasses import dataclass

from anka_platform.live_state.reducer import CanonicalSequenceError
from anka_platform.live_state.store import (
    CanonicalStatePersistenceError,
    CanonicalStateStore,
    CanonicalStateStoreUnhealthyError,
)
from anka_platform.protocol.adapter import ProtocolAdapter
from anka_platform.protocol.models import RawProtocolMessage, TransformFailure, UnclassifiedMessage, transform_failure_from_exception
from anka_platform.observability.models import FailureCode
from anka_platform.protocol.compatibility import known_opaque_compatibility


@dataclass(frozen=True,slots=True)
class LiveIngestionReport:
    message_count: int
    canonical_event_count: int
    transform_failures: tuple[TransformFailure,...]
    unclassified_messages: tuple[UnclassifiedMessage,...]
    classified_message_count: int = 0
    zero_event_message_count: int = 0
    zero_event_message_names: tuple[str, ...] = ()
    opaque_compatibility_count: int = 0
    canonical_event_kinds: tuple[str, ...] = ()
    transform_failure_capabilities: tuple[str, ...] = ()
    canonical_state_failures: tuple["CanonicalStateFailure", ...] = ()
    protocol_context_failures: tuple["ProtocolContextFailure", ...] = ()
    ingestion_halted: bool = False
    unprocessed_message_count: int = 0


@dataclass(frozen=True, slots=True)
class CanonicalStateFailure:
    frame_number: int
    name: str
    failure_code: str
    stage: str
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {
            "frame_number": self.frame_number,
            "name": self.name,
            "failure_code": self.failure_code,
            "stage": self.stage,
            "detail": self.detail,
        }


@dataclass(frozen=True, slots=True)
class ProtocolContextFailure:
    frame_number: int
    name: str
    failure_code: str
    stage: str
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {
            "frame_number": self.frame_number,
            "name": self.name,
            "failure_code": self.failure_code,
            "stage": self.stage,
            "detail": self.detail,
        }


class LiveIngestionService:
    """Only bridge from protocol-adapter output into confirmed canonical state."""
    def __init__(self,adapter:ProtocolAdapter,store:CanonicalStateStore,*,client_instance_id:str|None=None,observability=None,critical_debug_export=None)->None:
        self.adapter=adapter
        self.store=store
        self.observability=observability
        self.critical_debug_export=critical_debug_export
        snapshot=store.snapshot()
        self.adapter.synchronize_sequence(snapshot.revision)
        if client_instance_id is not None:
            previous=store.get_runtime_metadata("client_instance_id")
            if previous == str(client_instance_id) and snapshot.revision > 0:
                self.adapter.hydrate_runtime_context(snapshot)
            store.set_runtime_metadata("client_instance_id", str(client_instance_id))

    def _critical_export(self) -> None:
        if self.critical_debug_export is None:
            return
        try:
            self.critical_debug_export()
        except Exception:
            pass

    def _observe(self, method_name: str, /, **kwargs) -> None:
        """Best-effort diagnostics that can never change live-truth control flow.

        Canonical commit/rollback and decoder-context ownership are primary
        authority.  A journal/export implementation failure must not be caught
        by those authority exception boundaries or roll back already-committed
        truth. Diagnostic subsystem health is reported independently elsewhere.
        """
        if self.observability is None:
            return
        try:
            method = getattr(self.observability, method_name)
            method(**kwargs)
        except Exception:
            pass

    def _rollback_adapter_context(self, checkpoint, snapshot) -> str | None:
        """Restore decoder state after a transform/commit did not become truth."""
        try:
            if checkpoint is not None:
                self.adapter.restore_runtime_context(checkpoint)
            else:
                # Compatibility path for retained adapters that predate the
                # transactional context API.  Canonical state is the safest
                # available rollback point for their semantic state.
                self.adapter.synchronize_sequence(snapshot.revision)
                self.adapter.hydrate_runtime_context(snapshot)
            return None
        except Exception as exc:
            return f"{type(exc).__name__}: {exc}"

    @staticmethod
    def _message_correlation(message, snapshot=None) -> dict:
        fight_instance_id = None
        if snapshot is not None and getattr(snapshot, "fight", None) is not None:
            fight = snapshot.fight
            if getattr(fight, "present", False) and getattr(fight, "fight_instance_id", None) is not None:
                fight_instance_id = int(fight.fight_instance_id)
        return {
            "account_id": getattr(message, "account_id", None),
            "client_instance_id": getattr(message, "client_instance_id", None),
            "flow_id": getattr(message, "flow_id", None),
            "fight_instance_id": fight_instance_id,
        }

    def ingest_many(self,messages)->LiveIngestionReport:
        message_batch=tuple(messages)
        count=0; events=0; failures=[]; unknown=[]
        canonical_failures=[]
        protocol_context_failures=[]
        halted=False
        classified=0; zero_event_names=[]; opaque_compatibility=0
        canonical_event_kinds=[]; transform_failure_capabilities=[]
        for message in message_batch:
            count += 1

            # A fenced Canonical Store is a hard live-truth boundary. Stop before
            # *any* adapter callback (including classify/compatibility handling) so
            # later packets cannot advance hidden adapter state or create a raw
            # evidence gap while canonical durability is unavailable.
            if not self.store.is_write_healthy():
                detail = "canonical state store is already fenced; live ingestion requires recovery/reopen"
                canonical_failures.append(CanonicalStateFailure(
                    frame_number=int(message.frame_number), name=str(message.name),
                    failure_code=FailureCode.CANONICAL_STORE_FENCED.value,
                    stage='pre_classification', detail=detail,
                ))
                if self.observability is not None:
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='canonical_state',event_type='store_fenced',severity='CRITICAL',
                        failure_code=FailureCode.CANONICAL_STORE_FENCED,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'detail':detail},
                        **self._message_correlation(message,current_snapshot),
                    )
                self._critical_export()
                halted=True
                break

            compatibility = known_opaque_compatibility(self.adapter, message)
            if compatibility is not None:
                opaque_compatibility += 1
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message, classification='CLASSIFIED_OPAQUE_COMPAT',
                        transform_result='SKIPPED', detail=compatibility.reason,
                    )
                continue
            if not self.adapter.classify(message):
                unknown.append(UnclassifiedMessage(message.frame_number,message.direction,message.name))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='UNCLASSIFIED',transform_result='SKIPPED',
                        detail='adapter classify returned false',
                    )
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='protocol',event_type='unknown_message',severity='WARNING',
                        failure_code=FailureCode.PROTOCOL_UNKNOWN_MESSAGE,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'packet_number':message.packet_number},
                        **self._message_correlation(message,current_snapshot),
                    )
                continue
            classified += 1

            before_snapshot = self.store.snapshot()
            try:
                checkpoint = self.adapter.checkpoint_runtime_context()
            except Exception as exc:
                detail=f'{type(exc).__name__}: {exc}'
                protocol_context_failures.append(ProtocolContextFailure(
                    frame_number=int(message.frame_number), name=str(message.name),
                    failure_code=FailureCode.PROTOCOL_CONTEXT_CHECKPOINT_FAILURE.value,
                    stage='checkpoint', detail=detail,
                ))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='CLASSIFIED',transform_result='CONTEXT_CHECKPOINT_FAILURE',detail=detail,max_payload_bytes=65536,
                    )
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='protocol',event_type='context_checkpoint_failure',severity='CRITICAL',
                        failure_code=FailureCode.PROTOCOL_CONTEXT_CHECKPOINT_FAILURE,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'packet_number':message.packet_number,'detail':detail},
                        **self._message_correlation(message,current_snapshot),
                    )
                self._critical_export()
                halted=True
                break
            try:
                envelopes=self.adapter.transform(message)
            except Exception as exc:
                rollback_detail = self._rollback_adapter_context(checkpoint, before_snapshot)
                detail=f'{type(exc).__name__}: {exc}'
                if rollback_detail:
                    detail += f'; adapter_rollback_failed={rollback_detail}'
                failure = transform_failure_from_exception(self.adapter, message, exc)
                if rollback_detail:
                    failure = TransformFailure(
                        frame_number=failure.frame_number,
                        name=failure.name,
                        detail=detail,
                        category=failure.category,
                        capability=failure.capability,
                        wire_semantic=failure.wire_semantic,
                        adapter_id=failure.adapter_id,
                    )
                failures.append(failure)
                if failure.capability:
                    transform_failure_capabilities.append(str(failure.capability))
                if rollback_detail:
                    protocol_context_failures.append(ProtocolContextFailure(
                        frame_number=int(message.frame_number), name=str(message.name),
                        failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE.value,
                        stage='restore_after_transform_failure', detail=rollback_detail,
                    ))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='CLASSIFIED',transform_result='FAILURE',detail=detail,max_payload_bytes=65536,
                    )
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='protocol',event_type='transform_failure',severity='ERROR',
                        failure_code=FailureCode.PROTOCOL_TRANSFORM_FAILURE,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'packet_number':message.packet_number,'detail':detail},
                        **self._message_correlation(message,current_snapshot),
                    )
                    if rollback_detail:
                        self._observe("record_event", 
                            component='protocol',event_type='context_recovery_failure',severity='CRITICAL',
                            failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE,canonical_revision=current_snapshot.revision,
                            context={'name':message.name,'frame_number':message.frame_number,'detail':rollback_detail},
                            **self._message_correlation(message,current_snapshot),
                        )
                self._critical_export()
                if rollback_detail:
                    halted=True
                    break
                continue

            try:
                if envelopes:
                    self.store.append_batch(envelopes)
                emitted=len(envelopes)
                events += emitted
                for envelope in envelopes:
                    canonical_event_kinds.append(str(envelope.event.kind))
                if emitted == 0:
                    zero_event_names.append(str(message.name))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='CLASSIFIED',transform_result='SUCCESS',canonical_event_count=emitted,
                    )
            except CanonicalStatePersistenceError as exc:
                rollback_detail = self._rollback_adapter_context(checkpoint, before_snapshot)
                detail=f'{type(exc).__name__}: {exc}'
                if rollback_detail:
                    detail += f'; adapter_rollback_failed={rollback_detail}'
                canonical_failures.append(CanonicalStateFailure(
                    frame_number=int(message.frame_number), name=str(message.name),
                    failure_code=FailureCode.CANONICAL_PERSISTENCE_FAILURE.value,
                    stage=str(exc.stage), detail=detail,
                ))
                if rollback_detail:
                    protocol_context_failures.append(ProtocolContextFailure(
                        frame_number=int(message.frame_number), name=str(message.name),
                        failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE.value,
                        stage='restore_after_canonical_persistence_failure', detail=rollback_detail,
                    ))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='CLASSIFIED',transform_result='CANONICAL_COMMIT_FAILURE',detail=detail,max_payload_bytes=65536,
                    )
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='canonical_state',event_type='persistence_failure',severity='CRITICAL',
                        failure_code=FailureCode.CANONICAL_PERSISTENCE_FAILURE,canonical_revision=current_snapshot.revision,
                        context={
                            'name':message.name,'frame_number':message.frame_number,'packet_number':message.packet_number,
                            'detail':detail,'stage':exc.stage,'rollback_succeeded':exc.rollback_succeeded,
                        },
                        **self._message_correlation(message,current_snapshot),
                    )
                    if rollback_detail:
                        self._observe("record_event", 
                            component='protocol',event_type='context_recovery_failure',severity='CRITICAL',
                            failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE,canonical_revision=current_snapshot.revision,
                            context={'name':message.name,'frame_number':message.frame_number,'detail':rollback_detail},
                            **self._message_correlation(message,current_snapshot),
                        )
                self._critical_export()
                # The store deliberately fences itself after a durable-write
                # failure.  Do not consume later messages and create an
                # unobservable truth gap; orchestration must re-open/recover.
                halted=True
                break
            except CanonicalStateStoreUnhealthyError as exc:
                rollback_detail = self._rollback_adapter_context(checkpoint, before_snapshot)
                detail=f'{type(exc).__name__}: {exc}'
                if rollback_detail:
                    detail += f'; adapter_rollback_failed={rollback_detail}'
                canonical_failures.append(CanonicalStateFailure(
                    frame_number=int(message.frame_number), name=str(message.name),
                    failure_code=FailureCode.CANONICAL_STORE_FENCED.value,
                    stage='fenced', detail=detail,
                ))
                if rollback_detail:
                    protocol_context_failures.append(ProtocolContextFailure(
                        frame_number=int(message.frame_number), name=str(message.name),
                        failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE.value,
                        stage='restore_after_store_fence', detail=rollback_detail,
                    ))
                if self.observability is not None:
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='canonical_state',event_type='store_fenced',severity='CRITICAL',
                        failure_code=FailureCode.CANONICAL_STORE_FENCED,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'detail':detail},
                        **self._message_correlation(message,current_snapshot),
                    )
                    if rollback_detail:
                        self._observe("record_event", 
                            component='protocol',event_type='context_recovery_failure',severity='CRITICAL',
                            failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE,canonical_revision=current_snapshot.revision,
                            context={'name':message.name,'frame_number':message.frame_number,'detail':rollback_detail},
                            **self._message_correlation(message,current_snapshot),
                        )
                self._critical_export()
                halted=True
                break
            except Exception as exc:
                rollback_detail = self._rollback_adapter_context(checkpoint, before_snapshot)
                detail=f'{type(exc).__name__}: {exc}'
                if rollback_detail:
                    detail += f'; adapter_rollback_failed={rollback_detail}'
                failure_code = (
                    FailureCode.CANONICAL_SEQUENCE_ERROR
                    if isinstance(exc, CanonicalSequenceError)
                    else FailureCode.CANONICAL_REDUCER_FAILURE
                )
                canonical_failures.append(CanonicalStateFailure(
                    frame_number=int(message.frame_number), name=str(message.name),
                    failure_code=failure_code.value,
                    stage='reduce', detail=detail,
                ))
                if rollback_detail:
                    protocol_context_failures.append(ProtocolContextFailure(
                        frame_number=int(message.frame_number), name=str(message.name),
                        failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE.value,
                        stage='restore_after_canonical_reducer_failure', detail=rollback_detail,
                    ))
                if self.observability is not None:
                    self._observe("record_protocol_message", 
                        message=message,classification='CLASSIFIED',transform_result='CANONICAL_REDUCER_FAILURE',detail=detail,max_payload_bytes=65536,
                    )
                    current_snapshot=self.store.snapshot()
                    self._observe("record_event", 
                        component='canonical_state',event_type='reducer_failure',severity='CRITICAL',
                        failure_code=failure_code,canonical_revision=current_snapshot.revision,
                        context={'name':message.name,'frame_number':message.frame_number,'packet_number':message.packet_number,'detail':detail},
                        **self._message_correlation(message,current_snapshot),
                    )
                    if rollback_detail:
                        self._observe("record_event", 
                            component='protocol',event_type='context_recovery_failure',severity='CRITICAL',
                            failure_code=FailureCode.PROTOCOL_CONTEXT_RECOVERY_FAILURE,canonical_revision=current_snapshot.revision,
                            context={'name':message.name,'frame_number':message.frame_number,'detail':rollback_detail},
                            **self._message_correlation(message,current_snapshot),
                        )
                self._critical_export()
                halted=True
                break
        return LiveIngestionReport(
            message_count=count, canonical_event_count=events,
            transform_failures=tuple(failures), unclassified_messages=tuple(unknown),
            classified_message_count=classified,
            zero_event_message_count=len(zero_event_names),
            zero_event_message_names=tuple(zero_event_names),
            opaque_compatibility_count=opaque_compatibility,
            canonical_event_kinds=tuple(canonical_event_kinds),
            transform_failure_capabilities=tuple(transform_failure_capabilities),
            canonical_state_failures=tuple(canonical_failures),
            protocol_context_failures=tuple(protocol_context_failures),
            ingestion_halted=halted,
            unprocessed_message_count=max(0, len(message_batch)-count),
        )

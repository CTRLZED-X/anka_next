from __future__ import annotations


class TcpStreamReassembler:
    """Directional TCP reassembly with overlap/retransmission trimming."""

    def __init__(self) -> None:
        self.expected_seq: int | None = None
        self.pending: list[tuple[int, bytes]] = []
        self.duplicate_segments = 0
        self.overlap_segments = 0

    def feed(self, seq: int, payload: bytes) -> bytes:
        if not payload:
            return b""
        seq = int(seq)
        if self.expected_seq is None:
            self.expected_seq = seq
        assert self.expected_seq is not None
        if seq + len(payload) <= self.expected_seq:
            self.duplicate_segments += 1
            return b""
        if seq < self.expected_seq:
            payload = payload[self.expected_seq-seq:]
            seq = self.expected_seq
        self._insert(seq, payload)
        chunks: list[bytes] = []
        while self.pending and self.pending[0][0] <= self.expected_seq:
            start, chunk = self.pending.pop(0)
            if start < self.expected_seq:
                trim = self.expected_seq-start
                if trim >= len(chunk):
                    self.duplicate_segments += 1
                    continue
                chunk = chunk[trim:]
            chunks.append(chunk)
            self.expected_seq += len(chunk)
        return b"".join(chunks)

    def _insert(self, seq: int, payload: bytes) -> None:
        intervals=[*self.pending,(seq,payload)]
        intervals.sort(key=lambda item:item[0])
        merged: list[tuple[int,bytes]]=[]
        for start,data in intervals:
            if not merged:
                merged.append((start,data)); continue
            pstart,pdata=merged[-1]
            pend=pstart+len(pdata)
            if start > pend:
                merged.append((start,data)); continue
            overlap=pend-start
            if overlap>0: self.overlap_segments += 1
            if overlap>=len(data):
                self.duplicate_segments += 1
                continue
            merged[-1]=(pstart,pdata+data[max(0,overlap):])
        self.pending=merged

"""Passive Dofus TCP capture and framing boundary."""

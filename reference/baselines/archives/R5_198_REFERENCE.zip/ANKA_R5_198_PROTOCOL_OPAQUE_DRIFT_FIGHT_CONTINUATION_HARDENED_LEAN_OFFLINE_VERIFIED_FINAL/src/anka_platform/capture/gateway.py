from __future__ import annotations
from collections import defaultdict

from anka_platform.capture.envelope import extract_any_messages
from anka_platform.capture.framing import LengthPrefixedFrameDecoder
from anka_platform.capture.models import CapturedTcpSegment
from anka_platform.capture.tcp_stream import TcpStreamReassembler


class OfflineCaptureGateway:
    """Transport-only gateway used by replay and live capture edges."""
    def __init__(self)->None:
        self._streams=defaultdict(TcpStreamReassembler)
        self._frames=defaultdict(LengthPrefixedFrameDecoder)
        self._messages={'server_to_client':[],'client_to_server':[]}
        self._dofus_message_keys=set()

    @property
    def dropped_frame_bytes(self)->int:
        return sum(self._frames[key].dropped_bytes for key in self._dofus_message_keys)

    def feed(self,segment:CapturedTcpSegment)->None:
        key=(segment.flow_id,segment.direction)
        if segment.syn:
            self._streams[key]=TcpStreamReassembler()
            self._frames[key]=LengthPrefixedFrameDecoder()
            self._dofus_message_keys.discard(key)
        if not segment.payload:
            return
        seq=int(segment.seq)+(1 if segment.syn else 0)
        contiguous=self._streams[key].feed(seq,segment.payload)
        if not contiguous: return
        for frame in self._frames[key].feed(contiguous):
            messages=extract_any_messages(frame)
            if messages:
                self._dofus_message_keys.add(key)
                self._messages.setdefault(segment.direction,[]).extend(messages)

    def messages_by_direction(self)->dict[str,list[tuple[str,bytes]]]:
        return {key:list(value) for key,value in self._messages.items()}

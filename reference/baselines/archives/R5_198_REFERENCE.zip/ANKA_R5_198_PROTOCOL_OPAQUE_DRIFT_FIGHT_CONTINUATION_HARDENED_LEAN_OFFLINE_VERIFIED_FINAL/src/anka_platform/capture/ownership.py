from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from typing import Callable, Mapping, Protocol

from anka_platform.capture.models import CapturedTcpSegment
from anka_platform.execution.windows import DofusWindowIdentity


class SegmentRuntime(Protocol):
    def feed_segment(self, segment: CapturedTcpSegment) -> None: ...


class FlowPidResolver(Protocol):
    def resolve_pid(self, flow_id: str) -> int | None: ...


@dataclass(frozen=True, slots=True)
class FlowOwner:
    flow_id: str
    account_id: str
    pid: int
    client_instance_id: str
    process_creation_time: int | None = None


class FlowOwnershipRegistry:
    """Immutable flow-to-account bindings for one party runtime generation."""

    def __init__(self) -> None:
        self._owners: dict[str, FlowOwner] = {}

    def bind(
        self,
        flow_id: str,
        account_id: str,
        pid: int,
        client_instance_id: str,
        process_creation_time: int | None = None,
    ) -> FlowOwner:
        key = str(flow_id)
        candidate = FlowOwner(
            key, str(account_id), int(pid), str(client_instance_id),
            int(process_creation_time) if process_creation_time is not None else None,
        )
        existing = self._owners.get(key)
        if existing is None:
            self._owners[key] = candidate
            return candidate
        if existing != candidate:
            raise ValueError(
                f"flow {key!r} is already owned by account {existing.account_id!r} "
                f"({existing.client_instance_id})"
            )
        return existing

    def owner(self, flow_id: str) -> FlowOwner | None:
        return self._owners.get(str(flow_id))

    def clear_flow(self, flow_id: str) -> None:
        self._owners.pop(str(flow_id), None)

    def clear_for_client(self, client_instance_id: str) -> None:
        token = str(client_instance_id)
        self._owners = {
            flow: owner for flow, owner in self._owners.items()
            if owner.client_instance_id != token
        }


class NetstatFlowPidResolver:
    """Resolve a captured client TCP endpoint to its owning Windows PID."""

    def __init__(self, command_runner: Callable[[], str] | None = None) -> None:
        self._command_runner = command_runner or self._run_netstat

    @staticmethod
    def _run_netstat() -> str:
        return subprocess.check_output(
            ["netstat", "-ano", "-p", "tcp"],
            text=True,
            encoding="utf-8",
            errors="replace",
        )

    @staticmethod
    def _client_endpoint(flow_id: str) -> str | None:
        parts = str(flow_id).split("<->", 1)
        if len(parts) != 2:
            return None
        value = parts[0].strip()
        return value or None

    def resolve_pid(self, flow_id: str) -> int | None:
        endpoint = self._client_endpoint(flow_id)
        if endpoint is None:
            return None
        try:
            output = self._command_runner()
        except Exception:
            return None
        candidates: set[int] = set()
        for raw in output.splitlines():
            parts = raw.split()
            if len(parts) < 5 or parts[0].upper() != "TCP":
                continue
            local = parts[1]
            if local != endpoint:
                continue
            try:
                candidates.add(int(parts[-1]))
            except ValueError:
                continue
        if len(candidates) != 1:
            return None
        return next(iter(candidates))


class AccountCaptureRouter:
    """Route TCP segments only after exact account/process ownership is proven.

    Unresolved flows are throttled so a packet burst cannot spawn one `netstat`
    process per segment.  When a process-generation resolver is available, both
    new and already-bound flows must still belong to the exact startup process.
    """

    def __init__(
        self,
        *,
        identities: Mapping[str, DofusWindowIdentity],
        runtimes: Mapping[str, SegmentRuntime],
        pid_resolver: FlowPidResolver,
        ownership: FlowOwnershipRegistry | None = None,
        process_creation_time_resolver: Callable[[int], int | None] | None = None,
        unresolved_retry_seconds: float = 1.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.identities = dict(identities)
        self.runtimes = dict(runtimes)
        self.pid_resolver = pid_resolver
        self.ownership = ownership or FlowOwnershipRegistry()
        self.process_creation_time_resolver = process_creation_time_resolver
        self.unresolved_retry_seconds = max(0.0, float(unresolved_retry_seconds))
        self.clock = clock
        missing = set(self.identities) - set(self.runtimes)
        if missing:
            raise ValueError(f"capture runtimes missing for accounts: {sorted(missing)}")
        self._quarantined_segment_count = 0
        self._quarantined_flows: set[str] = set()
        self._retry_after: dict[str, float] = {}
        self._resolution_attempt_count = 0
        self._resolution_throttled_count = 0
        self._generation_mismatch_count = 0

    def _live_generation_matches(self, owner: FlowOwner) -> bool:
        if self.process_creation_time_resolver is None:
            return True
        try:
            live = self.process_creation_time_resolver(int(owner.pid))
        except Exception:
            live = None
        if live is None or owner.process_creation_time is None or int(live) != int(owner.process_creation_time):
            self._generation_mismatch_count += 1
            return False
        return True

    def _defer(self, flow_id: str) -> None:
        self._retry_after[str(flow_id)] = float(self.clock()) + self.unresolved_retry_seconds

    def _resolve_owner(self, flow_id: str) -> FlowOwner | None:
        key = str(flow_id)
        existing = self.ownership.owner(key)
        if existing is not None:
            if self._live_generation_matches(existing):
                return existing
            self.ownership.clear_flow(key)
            self._defer(key)
            return None

        now = float(self.clock())
        if now < self._retry_after.get(key, 0.0):
            self._resolution_throttled_count += 1
            return None
        self._resolution_attempt_count += 1
        pid = self.pid_resolver.resolve_pid(key)
        if pid is None:
            self._defer(key)
            return None
        matches = [
            (account_id, identity)
            for account_id, identity in self.identities.items()
            if identity.pid == int(pid)
        ]
        if len(matches) != 1:
            self._defer(key)
            return None
        account_id, identity = matches[0]
        candidate = FlowOwner(
            key, account_id, identity.pid, identity.client_instance_id,
            identity.process_creation_time,
        )
        if not self._live_generation_matches(candidate):
            self._defer(key)
            return None
        self._retry_after.pop(key, None)
        return self.ownership.bind(
            key, account_id, identity.pid, identity.client_instance_id,
            identity.process_creation_time,
        )

    def feed_segment(self, segment: CapturedTcpSegment) -> bool:
        owner = self._resolve_owner(segment.flow_id)
        if owner is None:
            self._quarantined_segment_count += 1
            self._quarantined_flows.add(segment.flow_id)
            return False
        runtime = self.runtimes.get(owner.account_id)
        current = self.identities.get(owner.account_id)
        if (
            runtime is None
            or current is None
            or current.client_instance_id != owner.client_instance_id
            or current.pid != owner.pid
            or (
                owner.process_creation_time is not None
                and int(current.process_creation_time) != int(owner.process_creation_time)
            )
        ):
            self.ownership.clear_flow(segment.flow_id)
            self._quarantined_segment_count += 1
            self._quarantined_flows.add(segment.flow_id)
            return False
        runtime.feed_segment(segment)
        return True

    def status(self) -> dict:
        return {
            "bound_flow_count": len(self.ownership._owners),
            "quarantined_segment_count": self._quarantined_segment_count,
            "quarantined_flows": sorted(self._quarantined_flows),
            "resolution_attempt_count": self._resolution_attempt_count,
            "resolution_throttled_count": self._resolution_throttled_count,
            "generation_mismatch_count": self._generation_mismatch_count,
        }

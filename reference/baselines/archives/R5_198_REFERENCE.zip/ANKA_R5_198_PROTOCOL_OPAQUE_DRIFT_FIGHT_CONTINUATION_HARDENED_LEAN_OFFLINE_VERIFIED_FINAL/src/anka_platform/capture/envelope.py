from __future__ import annotations

from anka_platform.protocol.protobuf import parse_direct_fields, bytes_values

_PREFIX=b"type.ankama.com/"


def extract_any_messages(raw: bytes, *, max_depth: int = 8) -> list[tuple[str,bytes]]:
    found: list[tuple[str,bytes]]=[]
    seen: set[tuple[str,bytes]]=set()

    def walk(buf:bytes,depth:int)->None:
        if depth>max_depth: return
        try: fields=parse_direct_fields(buf)
        except ValueError: return
        type_url=None
        for value in bytes_values(fields,1):
            if value.startswith(_PREFIX):
                try: type_url=value.decode('ascii')
                except UnicodeDecodeError: pass
                break
        if type_url:
            name=type_url.rsplit('/',1)[-1]
            payloads=bytes_values(fields,2) or [b'']
            for payload in payloads:
                item=(name,payload)
                if item not in seen:
                    seen.add(item); found.append(item)
        for values in fields.values():
            for value in values:
                if isinstance(value,bytes): walk(value,depth+1)
    walk(raw,0)
    return found

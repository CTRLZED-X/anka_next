from __future__ import annotations

from collections import deque
from threading import RLock


class DeferredAccountCaptureRouter:
    """Capture sink that exists before a party generation is bindable.

    A small bounded buffer preserves the newest startup packets while window/
    bridge identity is still being reconciled.  Once a generation is installed,
    buffered packets are replayed through that generation's exact ownership router.
    """

    def __init__(self, manager, *, max_buffered_segments: int = 256) -> None:
        self.manager = manager
        self.max_buffered_segments = max(0, int(max_buffered_segments))
        self._buffer = deque()
        self._lock = RLock()
        self._buffered_total = 0
        self._dropped = 0
        self._forwarded = 0
        register = getattr(manager, "add_generation_listener", None)
        if callable(register):
            register(self._on_generation_installed)

    def _on_generation_installed(self, generation: int, runtime) -> None:
        # Flush immediately when the exact ownership router becomes available.
        # This avoids waiting for an unrelated future packet before Canonical State
        # can consume the buffered startup evidence.
        self.flush()

    def feed_segment(self, segment) -> bool:
        router = self.manager.capture_router
        if router is not None:
            self.flush()
            try:
                result = bool(router.feed_segment(segment))
            except Exception:
                result = False
            if result:
                self._forwarded += 1
            return result
        with self._lock:
            self._buffered_total += 1
            if self.max_buffered_segments <= 0:
                self._dropped += 1
                return False
            if len(self._buffer) >= self.max_buffered_segments:
                self._buffer.popleft()
                self._dropped += 1
            self._buffer.append(segment)
        return False

    def flush(self) -> int:
        router = self.manager.capture_router
        if router is None:
            return 0
        sent = 0
        while True:
            with self._lock:
                if not self._buffer:
                    break
                segment = self._buffer.popleft()
            try:
                ok = bool(router.feed_segment(segment))
            except Exception:
                ok = False
            if ok:
                self._forwarded += 1
            sent += 1
        return sent

    def status(self) -> dict:
        with self._lock:
            buffered = len(self._buffer)
        current = self.manager.capture_router
        downstream = None
        if current is not None:
            try:
                downstream = dict(current.status())
            except Exception as exc:
                downstream = {"error": f"{type(exc).__name__}: {exc}"}
        return {
            "buffered_segment_count": buffered,
            "buffered_total_count": self._buffered_total,
            "dropped_prebind_segment_count": self._dropped,
            "forwarded_segment_count": self._forwarded,
            "generation_ready": current is not None,
            "downstream": downstream,
        }

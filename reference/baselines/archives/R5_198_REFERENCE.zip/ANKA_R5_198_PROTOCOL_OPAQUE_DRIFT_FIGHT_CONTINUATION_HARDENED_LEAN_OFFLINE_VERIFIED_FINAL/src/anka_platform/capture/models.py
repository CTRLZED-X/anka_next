from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True,slots=True)
class CapturedTcpSegment:
    flow_id: str
    direction: str
    seq: int
    payload: bytes
    packet_number: int
    # TCP control metadata is retained so reconnects can reset directional
    # reassembly state even when SYN/RST/FIN packets carry no payload.
    tcp_flags: int = 0

    @property
    def syn(self) -> bool:
        return bool(int(self.tcp_flags) & 0x02)

    @property
    def fin(self) -> bool:
        return bool(int(self.tcp_flags) & 0x01)

    @property
    def rst(self) -> bool:
        return bool(int(self.tcp_flags) & 0x04)

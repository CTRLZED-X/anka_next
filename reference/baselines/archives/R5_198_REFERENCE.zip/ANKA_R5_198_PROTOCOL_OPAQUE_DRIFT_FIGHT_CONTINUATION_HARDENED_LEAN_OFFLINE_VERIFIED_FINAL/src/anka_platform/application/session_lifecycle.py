from __future__ import annotations

from threading import RLock
import inspect
from typing import Callable, Mapping, Any

from anka_platform.application.control_models import CleanupState, RunLifecycle, SessionControlRecord
from anka_platform.application.errors import SessionLaunchFailed
from anka_platform.application.session_registry import SessionControlRegistry
from anka_platform.core.session import SessionPlan
from anka_platform.scripting.events import ScriptTerminalEvent
from anka_platform.scripting.supervisor import ScriptRunState


_TERMINAL_MAP = {
    ScriptRunState.COMPLETED: RunLifecycle.COMPLETED,
    ScriptRunState.FAILED: RunLifecycle.FAILED,
    ScriptRunState.STOPPED: RunLifecycle.STOPPED,
}


class SessionLifecycleCoordinator:
    """Single writer for backend session lifecycle state."""

    def __init__(
        self,
        *,
        registry: SessionControlRegistry,
        supervisor,
        forensics,
        mission_launcher_resolver: Callable[[SessionPlan], str],
        session_locker: Callable[[str], None] | None = None,
        session_releaser: Callable[[str], None] | None = None,
        plan_activator: Callable[[SessionPlan], None] | None = None,
        launch_failure_notifier: Callable[..., Mapping[str, Any] | None] | None = None,
        run_reserved_binder: Callable[[str, str], Any] | None = None,
    ) -> None:
        self.registry = registry
        self.supervisor = supervisor
        self.forensics = forensics
        self.mission_launcher_resolver = mission_launcher_resolver
        self.session_locker = session_locker
        self.session_releaser = session_releaser
        self.plan_activator = plan_activator
        self.launch_failure_notifier = launch_failure_notifier
        self.run_reserved_binder = run_reserved_binder
        self._lock = RLock()
        self._pending_terminal: dict[str, ScriptTerminalEvent] = {}
        self._cleanup_claimed: set[str] = set()
        add_listener = getattr(self.supervisor, "add_terminal_listener", None)
        if callable(add_listener):
            add_listener(self.on_terminal)

    def register_applied(self, plan: SessionPlan) -> SessionControlRecord:
        return self.registry.register_applied(plan)

    def launch(self, session_id: str) -> SessionControlRecord:
        token = str(session_id).strip()
        current = self.registry.get_session(token)
        if current.lifecycle is not None:
            return current
        try:
            reserved = self.registry.reserve_launch(token)
        except RuntimeError:
            return self.registry.get_session(token)
        plan = reserved.plan
        store = None
        locked = False
        stage = "SESSION_FORENSICS_START"
        try:
            store = self.forensics.start(plan)
            if self.session_locker is not None:
                stage = "SESSION_LOCK"
                self.session_locker(plan.session_id)
                locked = True
            if self.plan_activator is not None:
                stage = "SESSION_PLAN_ACTIVATION"
                self.plan_activator(plan)
            stage = "MISSION_LAUNCHER_RESOLUTION"
            script_name = self.mission_launcher_resolver(plan)
            stage = "WORKER_START"
            start_parameters = inspect.signature(self.supervisor.start).parameters
            if self.run_reserved_binder is not None:
                if "run_reserved" not in start_parameters:
                    raise RuntimeError("CONTROL_RUN_PRESTART_BINDING_UNSUPPORTED")
                status = self.supervisor.start(
                    script_name,
                    run_reserved=lambda run_id: self.run_reserved_binder(plan.session_id, str(run_id)),
                )
            else:
                status = self.supervisor.start(script_name)
        except Exception as exc:
            fail_start = self.forensics.fail_start
            parameters = inspect.signature(fail_start).parameters
            if "stage" in parameters:
                errors = list(fail_start(plan=plan, store=store, error=exc, stage=stage))
            else:
                errors = list(fail_start(plan=plan, store=store, error=exc))
            if locked and self.session_releaser is not None:
                try:
                    self.session_releaser(plan.session_id)
                except Exception as release_exc:
                    errors.append(f"SESSION_RELEASE_FAILED:{type(release_exc).__name__}:{release_exc}")
            incident: dict[str, Any] = {}
            if self.launch_failure_notifier is not None:
                try:
                    result = self.launch_failure_notifier(
                        session_id=plan.session_id, mission_id=plan.mission_id,
                        stage=stage, error=exc, plan=plan,
                    )
                    if isinstance(result, Mapping):
                        incident = dict(result)
                except Exception as notify_exc:
                    errors.append(f"LAUNCH_FAILURE_NOTIFY_FAILED:{type(notify_exc).__name__}:{notify_exc}")
            cleanup_state = CleanupState.DEGRADED if errors else CleanupState.COMPLETE
            self.registry.mark_failed_to_start(
                plan.session_id, error=f"{type(exc).__name__}: {exc}",
                cleanup_state=cleanup_state, cleanup_errors=tuple(errors),
                terminal_incident_id=(str(incident.get("incident_id")) if incident.get("incident_id") else None),
            )
            raise SessionLaunchFailed(
                session_id=plan.session_id, stage=stage, error=exc, incident=incident,
            ) from exc

        # Once the worker exists it is runtime authority.  Forensic binding is
        # observational and may degrade, but must never release a live party.
        record = self.registry.bind_run(plan.session_id, status.run_id)
        try:
            self.forensics.bind_run(status.run_id, store, script_name=script_name)
        except Exception as exc:
            record = self.registry.mark_cleanup(
                status.run_id,
                CleanupState.DEGRADED,
                (f"FORENSICS_BIND_FAILED:{type(exc).__name__}:{exc}",),
            )

        pending = None
        with self._lock:
            pending = self._pending_terminal.pop(status.run_id, None)
        if pending is not None:
            self.on_terminal(pending)
        return self.registry.get_run(status.run_id)

    def pause(self, run_id: str) -> SessionControlRecord:
        record = self.registry.get_run(run_id)
        if record.lifecycle is RunLifecycle.PAUSED or record.lifecycle is not RunLifecycle.RUNNING:
            return record
        self.supervisor.pause(run_id)
        return self.registry.set_run_state(run_id, RunLifecycle.PAUSED)

    def resume(self, run_id: str) -> SessionControlRecord:
        record = self.registry.get_run(run_id)
        if record.lifecycle is RunLifecycle.RUNNING or record.lifecycle is not RunLifecycle.PAUSED:
            return record
        self.supervisor.resume(run_id)
        return self.registry.set_run_state(run_id, RunLifecycle.RUNNING)

    def stop(self, run_id: str) -> SessionControlRecord:
        record = self.registry.get_run(run_id)
        if record.lifecycle in {RunLifecycle.STOPPING, RunLifecycle.STOPPED, RunLifecycle.COMPLETED, RunLifecycle.FAILED, RunLifecycle.FAILED_TO_START}:
            return record
        if record.lifecycle not in {RunLifecycle.RUNNING, RunLifecycle.PAUSED}:
            return record
        stopping = self.registry.set_run_state(run_id, RunLifecycle.STOPPING)
        self.supervisor.stop(run_id)
        return self.registry.get_run(run_id) if self._has_run(run_id) else stopping

    def on_terminal(self, event: ScriptTerminalEvent) -> None:
        if event.state not in _TERMINAL_MAP:
            return
        try:
            record = self.registry.get_run(event.run_id)
        except KeyError:
            with self._lock:
                self._pending_terminal[event.run_id] = event
            return

        with self._lock:
            if event.run_id in self._cleanup_claimed:
                return
            self._cleanup_claimed.add(event.run_id)

        errors: list[str] = list(record.cleanup_errors)
        target = _TERMINAL_MAP[event.state]
        try:
            record = self.registry.set_run_state(event.run_id, target, error=event.error)
        except RuntimeError:
            current = self.registry.get_run(event.run_id)
            if current.lifecycle is not target:
                with self._lock:
                    self._cleanup_claimed.discard(event.run_id)
                raise
            record = current

        try:
            errors.extend(self.forensics.finish(record=record, event=event))
        except Exception as exc:
            errors.append(f"FORENSICS_FINISH_FAILED:{type(exc).__name__}:{exc}")

        if self.session_releaser is not None:
            try:
                self.session_releaser(record.session_id)
            except Exception as exc:
                errors.append(f"SESSION_RELEASE_FAILED:{type(exc).__name__}:{exc}")

        cleanup_state = CleanupState.DEGRADED if errors else CleanupState.COMPLETE
        self.registry.mark_cleanup(event.run_id, cleanup_state, tuple(errors))

    def _has_run(self, run_id: str) -> bool:
        try:
            self.registry.get_run(run_id)
        except KeyError:
            return False
        return True

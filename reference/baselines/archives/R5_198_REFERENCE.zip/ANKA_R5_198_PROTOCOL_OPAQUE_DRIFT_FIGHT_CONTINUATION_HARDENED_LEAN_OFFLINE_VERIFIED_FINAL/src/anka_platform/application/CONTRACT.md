# Application Contract

The application layer compiles operator intent into SessionPlan, performs readiness/preflight, owns composition/wiring, and exposes session-level commands/status to adapters such as Script Studio.

It may construct concrete infrastructure at `application/composition.py`. Web/UI code should consume this API rather than construct execution/runtime internals directly.

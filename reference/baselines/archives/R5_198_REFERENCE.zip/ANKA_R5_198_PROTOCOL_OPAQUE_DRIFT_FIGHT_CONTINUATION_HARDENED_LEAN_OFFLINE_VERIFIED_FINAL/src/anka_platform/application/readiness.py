from __future__ import annotations

from typing import Callable, Mapping
import re

from anka_platform.core.health import HealthReport, HealthStatus
from anka_platform.core.session import SessionPlan
from anka_platform.protocol.capabilities import CapabilityStatus, ProtocolCapabilityMatrix


class ReadinessService:
    """Separates immutable configuration validity from live runtime preflight."""

    def __init__(
        self,
        *,
        protocol_matrix_provider: Callable[[], ProtocolCapabilityMatrix],
        party_preflight_provider: Callable[[], dict] | None,
        windows_readiness_provider: Callable[[], dict] | None,
        mission_launchers: Mapping[str, str],
    ) -> None:
        self.protocol_matrix_provider = protocol_matrix_provider
        self.party_preflight_provider = party_preflight_provider
        self.windows_readiness_provider = windows_readiness_provider
        self.mission_launchers = mission_launchers

    def party_preflight(self) -> dict:
        if self.party_preflight_provider is None:
            return {"ready": False, "accounts": {}, "missing_required": [], "blockers": ["PARTY_RUNTIME_UNAVAILABLE"]}
        try:
            return dict(self.party_preflight_provider())
        except Exception as exc:
            return {"ready": False, "accounts": {}, "blockers": [f"PARTY_PREFLIGHT_ERROR:{type(exc).__name__}"]}

    def windows_preflight(self) -> dict:
        if self.windows_readiness_provider is None:
            return {"ready": False, "blockers": ["WINDOWS_CERTIFICATION_UNAVAILABLE"]}
        try:
            return dict(self.windows_readiness_provider())
        except Exception as exc:
            return {"ready": False, "blockers": [f"WINDOWS_CERTIFICATION_ERROR:{type(exc).__name__}"]}

    def protocol_payload(self, plan: SessionPlan) -> tuple[dict, tuple[str, ...]]:
        matrix = self.protocol_matrix_provider()
        required_protocol = {}
        blockers: list[str] = []
        for capability in plan.required_capabilities:
            entry = matrix._entry(capability)
            required_protocol[capability] = entry.to_dict()
            if entry.status is not CapabilityStatus.VERIFIED:
                blockers.append(f"PROTOCOL_CAPABILITY_NOT_VERIFIED:{capability}:{entry.status.value}")
        return {"adapter_id": matrix.adapter_id, "required": required_protocol}, tuple(blockers)

    def configuration_payload(self, plan: SessionPlan) -> dict:
        protocol, protocol_blockers = self.protocol_payload(plan)
        blockers = list(protocol_blockers)
        if plan.mission_id not in self.mission_launchers:
            blockers.append("MISSION_LAUNCHER_UNAVAILABLE")
        blockers = list(dict.fromkeys(blockers))
        return {
            "configuration_valid": not blockers,
            "ready": not blockers,
            "blockers": blockers,
            "party": {"ready": None, "status": "NOT_APPLIED", "accounts": {}},
            "windows": {"ready": None, "status": "NOT_APPLIED", "blockers": []},
            "protocol": protocol,
        }

    def runtime_preflight(self, plan: SessionPlan) -> dict:
        protocol, protocol_blockers = self.protocol_payload(plan)
        blockers = list(protocol_blockers)
        party = self.party_preflight()
        if party.get("ready") is not True:
            blockers.append("PARTY_PREFLIGHT_NOT_READY")
            blockers.extend(f"PARTY:{item}" for item in party.get("blockers") or ())
        # Execution safety is a launch-time concern, not necessarily a runtime
        # health failure. Surface it separately so an unresolved physical action
        # blocks a new SessionPlan with its exact account-scoped reason.
        blockers.extend(f"PARTY_LAUNCH:{item}" for item in party.get("launch_blockers") or ())
        windows = self.windows_preflight()
        if windows.get("ready") is not True:
            details = list(windows.get("blockers") or ["NOT_READY"])
            blockers.extend(f"PROCESS_ATTESTATION_NOT_READY:{item}" for item in details)
        if plan.mission_id not in self.mission_launchers:
            blockers.append("MISSION_LAUNCHER_UNAVAILABLE")
        blockers = list(dict.fromkeys(blockers))
        return {
            "configuration_valid": not protocol_blockers and plan.mission_id in self.mission_launchers,
            "ready": not blockers,
            "blockers": blockers,
            "party": party,
            "windows": windows,
            "protocol": protocol,
        }

    def health_reports(self, plan: SessionPlan | None) -> tuple[HealthReport, ...]:
        session_id = plan.session_id if plan is not None else None
        matrix = self.protocol_matrix_provider()
        required = tuple(plan.required_capabilities) if plan is not None else ()
        missing = [cap for cap in required if matrix._entry(cap).status is not CapabilityStatus.VERIFIED]
        party_payload = self.party_preflight()
        # Capability certification is the launch authority. A live client build
        # differing from the selected adapter is therefore surfaced as DEGRADED
        # (not silently READY, and not blindly BLOCKED) while the required
        # capabilities remain verified. Unknown protocol messages stay forensic
        # evidence and are never assigned invented semantics.
        adapter_match = re.search(r"dofus_(\d+)_(\d+)_(\d+)_(\d+)", str(matrix.adapter_id or ""))
        adapter_version = ".".join(adapter_match.groups()) if adapter_match else None
        observed_versions: set[str] = set()
        accounts = party_payload.get("accounts") if isinstance(party_payload, dict) else {}
        if isinstance(accounts, dict):
            for account in accounts.values():
                if not isinstance(account, dict):
                    continue
                window = account.get("window") if isinstance(account.get("window"), dict) else {}
                title = str(window.get("title") or "")
                match = re.search(r"(?<!\d)(\d+\.\d+\.\d+\.\d+)(?!\d)", title)
                if match:
                    observed_versions.add(match.group(1))
        protocol_warnings: list[str] = []
        if adapter_version and observed_versions and any(value != adapter_version for value in observed_versions):
            protocol_warnings.append(
                "PROTOCOL_VERSION_DRIFT_GUARDED:"
                f"adapter={adapter_version}:observed={','.join(sorted(observed_versions))}"
            )
        protocol_ready = not missing
        protocol_status = (
            HealthStatus.BLOCKED if missing
            else HealthStatus.DEGRADED if protocol_warnings
            else HealthStatus.READY
        )
        protocol = HealthReport(
            component="protocol",
            status=protocol_status,
            ready=protocol_ready,
            blockers=tuple(f"CAPABILITY_NOT_VERIFIED:{cap}" for cap in missing),
            warnings=tuple(protocol_warnings),
            session_id=session_id,
        )
        party_ready = party_payload.get("ready") is True
        party_blockers = list(party_payload.get("blockers") or ())
        party_blockers.extend(f"MISSING_REQUIRED:{item}" for item in party_payload.get("missing_required") or ())
        party = HealthReport(
            component="party",
            status=HealthStatus.READY if party_ready else HealthStatus.BLOCKED,
            ready=party_ready,
            blockers=tuple(party_blockers or (() if party_ready else ("PARTY_NOT_READY",))),
            session_id=session_id,
        )
        windows_payload = self.windows_preflight()
        windows_ready = windows_payload.get("ready") is True
        windows = HealthReport(
            component="windows",
            status=HealthStatus.READY if windows_ready else HealthStatus.BLOCKED,
            ready=windows_ready,
            blockers=tuple(windows_payload.get("blockers") or (() if windows_ready else ("WINDOWS_NOT_READY",))),
            session_id=session_id,
        )
        return protocol, party, windows

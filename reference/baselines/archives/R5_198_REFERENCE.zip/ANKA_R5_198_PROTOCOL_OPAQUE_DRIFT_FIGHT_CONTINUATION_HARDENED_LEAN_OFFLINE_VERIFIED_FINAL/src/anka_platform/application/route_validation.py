from __future__ import annotations

from anka_game_kernel.domain.ids import MapId
from anka_platform.core.routes import (
    CertifiedDirectionalRoute,
    CertifiedRouteEdge,
    RouteDirection,
    normalize_route_directions,
    route_positions,
)
from anka_platform.maps.routing import ensure_world_route


def _map_available(kernel, map_id: int) -> bool:
    maps = getattr(kernel, "maps", None)
    if maps is None:
        return False
    try:
        return MapId(map_id) in maps
    except TypeError:
        try:
            maps.require(MapId(map_id))
            return True
        except (KeyError, ValueError, LookupError):
            return False


def _ensure_map_available(kernel, map_id: int, *, coordinate: tuple[int, int]) -> None:
    if _map_available(kernel, map_id):
        return
    ensure_map = getattr(kernel, "ensure_map", None)
    result = ensure_map(map_id) if callable(ensure_map) else None
    if _map_available(kernel, map_id):
        return
    status = str(getattr(result, "status", "UNAVAILABLE")) if result is not None else "UNAVAILABLE"
    detail = str(getattr(result, "detail", "") or "").strip() if result is not None else ""
    suffix = f" ({status}{': ' + detail if detail else ''})"
    raise ValueError(
        f"route coordinate {coordinate} map {map_id} has no certified Mapuse data{suffix}; "
        "configure a valid maps_directory or add/import that map before Launch"
    )


def _coordinate_matches(kernel, coordinate: tuple[int, int]) -> list[int]:
    resolver = getattr(kernel, "map_ids_at_coordinate", None)
    if callable(resolver):
        return [int(value) for value in resolver(*coordinate)]
    return [
        int(location.map_id)
        for location in getattr(kernel, "map_locations", ())
        if (int(location.coordinate.x), int(location.coordinate.y)) == coordinate
    ]


def _resolve_unique_coordinate(kernel, coordinate: tuple[int, int]) -> int:
    matches = _coordinate_matches(kernel, coordinate)
    if len(matches) != 1:
        raise ValueError(
            f"route coordinate {coordinate} resolves to {len(matches)} maps: "
            f"{_candidate_summary(matches)}"
        )
    map_id = int(matches[0])
    _ensure_map_available(kernel, map_id, coordinate=coordinate)
    return map_id


def _legacy_direct_edge(kernel, source: int, target: int) -> bool:
    """Compatibility path for light-weight test/fake kernels without WorldService."""
    definition = kernel.maps.require(MapId(source))
    neighbors = getattr(definition, "neighbors", None)
    values = (
        getattr(neighbors, "top", None), getattr(neighbors, "right", None),
        getattr(neighbors, "bottom", None), getattr(neighbors, "left", None),
    )
    return int(target) in {int(item) for item in values if item is not None}


def _candidate_summary(matches: list[int] | tuple[int, ...], *, limit: int = 8) -> str:
    values = [int(value) for value in matches]
    sample = values[:limit]
    suffix = f" (+{len(values) - limit} more)" if len(values) > limit else ""
    return f"{sample}{suffix}"


def compile_directional_route(kernel, plan) -> CertifiedDirectionalRoute:
    """Compile start + directions into exact, certified one-edge transitions.

    Coordinate arithmetic expresses operator intent. Mapuse topology remains the
    execution authority: every direction must resolve to exactly the expected
    neighboring MapId, otherwise Launch is rejected before any input is sent.
    """
    start = getattr(plan, "route_start_coordinate", None)
    directions = normalize_route_directions(getattr(plan, "route_directions", ()))
    if start is None or not directions:
        raise ValueError("directional route requires route_start_coordinate and route_directions")
    start = (int(start[0]), int(start[1]))
    positions = route_positions(start, directions)
    if bool(getattr(plan, "route_loop", True)) and positions[-1] != positions[0]:
        raise ValueError(
            f"route cycle must return to its starting map: start={positions[0]} end={positions[-1]}"
        )

    edges: list[CertifiedRouteEdge] = []
    for index, direction in enumerate(directions):
        source_coordinate = positions[index]
        target_coordinate = positions[index + 1]
        source_id = _resolve_unique_coordinate(kernel, source_coordinate)
        target_id = _resolve_unique_coordinate(kernel, target_coordinate)

        # Prefer the Kernel's one-edge topology. A route token never means
        # "find some path to x+1"; it means this exact cardinal neighbor.
        world = getattr(kernel, "world", None)
        transitions = tuple(world.transitions(MapId(source_id))) if world is not None and callable(getattr(world, "transitions", None)) else ()
        if transitions:
            matching_direction = [
                item for item in transitions
                if str(getattr(item.direction, "value", item.direction)).upper() == direction.kernel_name
            ]
            if len(matching_direction) != 1:
                raise ValueError(
                    f"route edge {index} {source_coordinate} {direction.short} has no unique certified {direction.kernel_name} transition"
                )
            transition = matching_direction[0]
            if int(transition.target_map_id) != target_id:
                raise ValueError(
                    f"route edge {index} topology mismatch: {source_coordinate} {direction.short} intends {target_coordinate} "
                    f"(map {target_id}) but Mapuse points to map {int(transition.target_map_id)}"
                )
            if not bool(getattr(transition, "available_in_mapuse", False)):
                _ensure_map_available(kernel, target_id, coordinate=target_coordinate)
        elif not _legacy_direct_edge(kernel, source_id, target_id):
            raise ValueError(
                f"route edge {source_coordinate}->{target_coordinate} is not a certified cardinal neighbor"
            )

        edges.append(CertifiedRouteEdge(
            index=index,
            direction=RouteDirection.parse(direction),
            source_coordinate=source_coordinate,
            target_coordinate=target_coordinate,
            source_map_id=source_id,
            target_map_id=target_id,
        ))

    return CertifiedDirectionalRoute(
        start_coordinate=start,
        directions=directions,
        edges=tuple(edges),
        loop=bool(getattr(plan, "route_loop", True)),
    )


def validate_session_route(kernel, plan) -> tuple[int, ...]:
    """Validate a route before Launch.

    New sessions use exact directional edges. Legacy waypoint sessions remain
    supported during migration and keep their historical multi-edge semantics.
    """
    if tuple(getattr(plan, "route_directions", ()) or ()):
        return compile_directional_route(kernel, plan).map_ids

    coordinates = tuple((int(x), int(y)) for x, y in tuple(plan.route_coordinates or ()))
    if not coordinates:
        raise ValueError("session route must contain at least one coordinate")

    map_ids = [_resolve_unique_coordinate(kernel, coordinate) for coordinate in coordinates]
    if len(map_ids) == 1:
        return tuple(map_ids)

    edge_count = len(map_ids) if bool(getattr(plan, "route_loop", True)) else len(map_ids) - 1
    world = getattr(kernel, "world", None)
    for index in range(edge_count):
        next_index = (index + 1) % len(map_ids)
        source = MapId(map_ids[index])
        target = MapId(map_ids[next_index])
        if world is None or not callable(getattr(world, "route", None)):
            if not _legacy_direct_edge(kernel, int(source), int(target)):
                raise ValueError(
                    f"route edge {coordinates[index]}->{coordinates[next_index]} is not a certified cardinal neighbor"
                )
            continue
        route = ensure_world_route(kernel, source, target)
        if not route.reachable:
            raise ValueError(
                f"route waypoint {coordinates[index]}->{coordinates[next_index]} is not reachable "
                f"through certified Mapuse/fallback data: {route.reason or 'NO_ROUTE'}"
            )
        if int(route.map_ids[-1]) != int(target):
            raise ValueError(
                f"route waypoint {coordinates[index]}->{coordinates[next_index]} did not resolve to the requested target"
            )
    return tuple(map_ids)

from __future__ import annotations

from dataclasses import asdict
from enum import Enum

from anka_platform.application.control_models import SessionControlRecord
from anka_platform.core.session import SessionPlan


def json_value(value):
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, tuple):
        return [json_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): json_value(item) for key, item in value.items()}
    if hasattr(value, "__dataclass_fields__"):
        return json_value(asdict(value))
    return value


def run_payload(status) -> dict:
    return {
        "run_id": status.run_id,
        "script_name": status.script_name,
        "state": getattr(status.state, "value", status.state),
        "source_sha256": status.source_sha256,
        "source_copy": str(status.source_copy),
        "logs": list(status.logs),
        "error": status.error,
    }


def session_plan_payload(plan: SessionPlan) -> dict:
    return {
        "session_id": plan.session_id,
        "mission_id": plan.mission_id,
        "leader_account_id": plan.leader.account_id,
        "protocol_adapter_id": plan.protocol_adapter_id,
        "canonical_contract_version": plan.canonical_contract_version,
        "team_strategy_id": plan.team_strategy_id,
        "route_id": plan.route_id,
        "target_policy_id": plan.target_policy_id,
        "fight_policy_set_id": plan.fight_policy_set_id,
        "required_capabilities": list(plan.required_capabilities),
        "route_model": ("DIRECTIONAL" if plan.route_directions else "LEGACY_WAYPOINTS"),
        "route_start": (list(plan.route_start_coordinate) if plan.route_start_coordinate is not None else None),
        "route_directions": [item.short for item in plan.route_directions],
        "route_direction_names": [item.value for item in plan.route_directions],
        "route_coordinates": [list(item) for item in plan.route_coordinates],
        "target_min_monsters": plan.target_min_monsters,
        "target_max_monsters": plan.target_max_monsters,
        "route_loop": plan.route_loop,
        "stop": json_value(plan.stop),
        "members": [
            {
                "account_id": member.account_id,
                "control_mode": member.control_mode.value,
                "requirement": member.requirement.value,
                "leadership": member.leadership.value,
                "fight_policy_id": member.fight_policy_id,
                "passive_policy_id": member.passive_policy_id,
                "placement_policy_id": member.placement_policy_id,
                "combat_profile_id": member.combat_profile_id,
                "character_name": plan.profile_for(member.account_id).character_name,
                "class_name": plan.profile_for(member.account_id).class_name,
            }
            for member in plan.members
        ],
    }


def control_record_payload(record: SessionControlRecord) -> dict:
    return {
        "session_id": record.session_id,
        "plan_state": record.plan_state.value,
        "lifecycle": record.lifecycle.value if record.lifecycle is not None else None,
        "run_id": record.run_id,
        "cleanup_state": record.cleanup_state.value,
        "revision": record.revision,
        "created_utc": record.created_utc,
        "updated_utc": record.updated_utc,
        "terminal_error": record.terminal_error,
        "cleanup_errors": list(record.cleanup_errors),
        "terminal_incident_id": record.terminal_incident_id,
    }

from __future__ import annotations

from anka_platform.config import PlatformConfig
from anka_platform.core.models import ControlMode, MembershipRequirement
from anka_platform.core.session import SessionPlan


_REQUIRED_WORLD_DIRECTIONS = ("TOP", "RIGHT", "BOTTOM", "LEFT")
_REQUIRED_PHASE_CONTROLS = ("READY", "END_TURN")


def validate_session_runtime_configuration(config: PlatformConfig, plan: SessionPlan) -> None:
    """Fail before Apply when a frozen SessionPlan cannot be physically executed.

    This validates stable configuration facts only. Live facts such as whether a
    Dofus window is open, bridge health, capture freshness, or current MapId stay
    in runtime preflight. The goal is to prevent a configuration from being
    advertised as valid when its required lanes are missing deterministic input
    calibration or its selected active combat profile cannot perform any action.
    """
    if len(plan.members) > int(config.party.bridge_port_count):
        raise ValueError(
            f"PARTY_SIZE_EXCEEDS_BRIDGE_CAPACITY:{len(plan.members)}>{int(config.party.bridge_port_count)}"
        )

    for member in plan.members:
        if member.requirement is not MembershipRequirement.REQUIRED:
            continue
        profile = plan.profile_for(member.account_id)
        calibration_id = str(profile.calibration_profile).strip()
        if not config.calibration.has_profile(calibration_id):
            raise ValueError(f"CALIBRATION_PROFILE_NOT_FOUND:{member.account_id}:{calibration_id}")
        calibration = config.calibration.profile(calibration_id)
        if calibration.client_size is None:
            raise ValueError(f"CALIBRATION_CLIENT_SIZE_MISSING:{member.account_id}:{calibration_id}")

        missing_directions = [
            direction
            for direction in _REQUIRED_WORLD_DIRECTIONS
            if (calibration.directions.get(direction) is None or not calibration.directions[direction].verified)
        ]
        if missing_directions:
            raise ValueError(
                f"CALIBRATION_DIRECTIONS_MISSING:{member.account_id}:{calibration_id}:"
                + ",".join(missing_directions)
            )

        missing_controls = [control for control in _REQUIRED_PHASE_CONTROLS if not calibration.has_verified_control(control)]
        if missing_controls:
            raise ValueError(
                f"CALIBRATION_CONTROLS_MISSING:{member.account_id}:{calibration_id}:"
                + ",".join(missing_controls)
            )

        if member.control_mode is not ControlMode.ACTIVE:
            continue
        combat_profile_id = str(member.combat_profile_id or member.account_id)
        try:
            combat = config.fight_ai.profile(combat_profile_id)
        except KeyError as exc:
            raise ValueError(f"COMBAT_PROFILE_NOT_FOUND:{combat_profile_id}") from exc
        enabled = tuple(combat.enabled_spells)
        if not enabled:
            raise ValueError(f"COMBAT_PROFILE_HAS_NO_ENABLED_SPELLS:{member.account_id}:{combat_profile_id}")
        missing_slots = sorted({
            int(spell.slot_index)
            for spell in enabled
            if calibration.spell_slots.get(int(spell.slot_index)) is None
            or not calibration.spell_slots[int(spell.slot_index)].verified
        })
        if missing_slots:
            raise ValueError(
                f"CALIBRATION_SPELL_SLOTS_MISSING:{member.account_id}:{calibration_id}:"
                + ",".join(str(slot) for slot in missing_slots)
            )

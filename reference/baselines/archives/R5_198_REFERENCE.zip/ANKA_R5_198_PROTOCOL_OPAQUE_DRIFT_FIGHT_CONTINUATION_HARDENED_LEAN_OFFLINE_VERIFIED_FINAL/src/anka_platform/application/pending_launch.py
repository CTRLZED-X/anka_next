from __future__ import annotations

import time
from threading import Event, Lock, Thread
from typing import Callable, Mapping


_WAITING_STATUSES = frozenset({"WAITING", "RECOVERING", "LAUNCHING"})


class PendingLaunchWorker:
    """Backend-owned poller that advances frozen one-click Launch intents.

    The worker deliberately has no browser dependency.  Readiness checks remain
    passive; an optional ApplicationService recovery hook may start a separately
    guarded runtime operation.  Worker exceptions and persistent stalls are made
    observable instead of being silently swallowed.
    """

    def __init__(
        self,
        advance: Callable[[], object],
        *,
        interval_seconds: float = 0.5,
        event_observer: Callable[[list[dict]], None] | None = None,
        exception_observer: Callable[[BaseException], None] | None = None,
        stall_observer: Callable[[dict], None] | None = None,
        stall_after_seconds: float = 20.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        interval = float(interval_seconds)
        if interval <= 0:
            raise ValueError("interval_seconds must be > 0")
        stall = float(stall_after_seconds)
        if stall <= 0:
            raise ValueError("stall_after_seconds must be > 0")
        self._advance = advance
        self._interval_seconds = interval
        self._event_observer = event_observer
        self._exception_observer = exception_observer
        self._stall_observer = stall_observer
        self._stall_after_seconds = stall
        self._clock = clock
        self._stop = Event()
        self._lock = Lock()
        self._thread: Thread | None = None
        self._waiting: dict[str, dict] = {}
        self._last_events: list[dict] = []
        self._last_error: str | None = None
        self._stall_observer_failure_count = 0
        self._last_stall_observer_error: str | None = None
        self._loop_count = 0
        self._last_advance_monotonic: float | None = None

    def start(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = Thread(target=self._run, name="anka-pending-launch", daemon=True)
            self._thread.start()

    def stop(self, timeout: float = 3.0) -> None:
        with self._lock:
            thread = self._thread
            self._thread = None
            self._stop.set()
        if thread is not None and thread.is_alive():
            thread.join(max(0.0, float(timeout)))

    def status(self) -> dict:
        with self._lock:
            thread = self._thread
            waiting = {
                session_id: {
                    "first_wait_monotonic": float(item["first_wait_monotonic"]),
                    "stall_reported": bool(item.get("stall_reported")),
                    "latest_status": str((item.get("latest_event") or {}).get("status") or "WAITING"),
                    "latest_blockers": list((item.get("latest_event") or {}).get("blockers") or ()),
                    "recovery": dict((item.get("latest_event") or {}).get("recovery") or {}),
                    "latest_phase": str(((item.get("latest_event") or {}).get("recovery") or {}).get("phase") or "") or None,
                    "latest_recovery_code": str(((item.get("latest_event") or {}).get("recovery") or {}).get("code") or "") or None,
                }
                for session_id, item in self._waiting.items()
            }
            return {
                "running": bool(thread is not None and thread.is_alive()),
                "interval_seconds": self._interval_seconds,
                "stall_after_seconds": self._stall_after_seconds,
                "loop_count": self._loop_count,
                "last_advance_monotonic": self._last_advance_monotonic,
                "last_error": self._last_error,
                "stall_observer_failure_count": int(self._stall_observer_failure_count),
                "last_stall_observer_error": self._last_stall_observer_error,
                "last_events": [dict(item) for item in self._last_events],
                "waiting_sessions": waiting,
            }

    def _observe_events(self, raw: object) -> None:
        if not isinstance(raw, list):
            events: list[dict] = []
        else:
            events = [dict(item) for item in raw if isinstance(item, Mapping)]
        now = float(self._clock())
        with self._lock:
            self._last_events = [dict(item) for item in events]
            self._last_error = None
            self._loop_count += 1
            self._last_advance_monotonic = now

        if self._event_observer is not None and events:
            try:
                self._event_observer(events)
            except Exception:
                # Diagnostics must never kill the owner of pending Launch.
                pass

        # advance() returns the complete current set of pending-session events.
        # If a session disappeared because it launched, failed, was cancelled, or
        # was superseded, remove its watchdog state immediately.  R5.172 retained
        # stale waiting rows forever when the next poll returned no event.
        current_session_ids = {
            str(event.get("session_id") or "").strip() for event in events
            if str(event.get("session_id") or "").strip()
        }
        with self._lock:
            for stale_session_id in tuple(self._waiting):
                if stale_session_id not in current_session_ids:
                    self._waiting.pop(stale_session_id, None)

        for event in events:
            session_id = str(event.get("session_id") or "").strip()
            if not session_id:
                continue
            status = str(event.get("status") or "").upper()
            if status not in _WAITING_STATUSES:
                with self._lock:
                    self._waiting.pop(session_id, None)
                continue
            with self._lock:
                state = self._waiting.setdefault(session_id, {
                    "first_wait_monotonic": now,
                    "stall_reported": False,
                    "latest_event": dict(event),
                })
                # Never reset first_wait_monotonic because the visible blocker
                # changed; a chain that keeps changing symptoms is still one
                # continuously stalled Launch intent.
                state["latest_event"] = dict(event)
                elapsed = now - float(state["first_wait_monotonic"])
                recovery = event.get("recovery") if isinstance(event.get("recovery"), Mapping) else {}
                non_recoverable_wait = recovery.get("recoverable_by_waiting") is False
                should_report = (
                    (non_recoverable_wait or elapsed >= self._stall_after_seconds)
                    and not bool(state.get("stall_reported"))
                )
            if should_report:
                payload = {
                    **dict(event),
                    "stall_seconds": elapsed,
                    "watchdog_reason": (
                        "NON_RECOVERABLE_WAIT" if non_recoverable_wait else "STALL_TIMEOUT"
                    ),
                }
                if self._stall_observer is None:
                    with self._lock:
                        current = self._waiting.get(session_id)
                        if current is not None:
                            current["stall_reported"] = True
                else:
                    try:
                        self._stall_observer(payload)
                    except Exception as exc:
                        # A diagnostics/export/UI callback must never strand a
                        # non-recoverable Launch forever.  Keep the watchdog
                        # unreported so the next poll retries terminalization,
                        # while retaining dedicated evidence about the callback
                        # failure itself.
                        with self._lock:
                            self._stall_observer_failure_count += 1
                            self._last_stall_observer_error = f"{type(exc).__name__}: {exc}"
                    else:
                        with self._lock:
                            current = self._waiting.get(session_id)
                            if current is not None:
                                current["stall_reported"] = True

    def _record_exception(self, exc: BaseException) -> None:
        with self._lock:
            self._last_error = f"{type(exc).__name__}: {exc}"
            self._loop_count += 1
            self._last_advance_monotonic = float(self._clock())
        if self._exception_observer is not None:
            try:
                self._exception_observer(exc)
            except Exception:
                pass

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                result = self._advance()
            except Exception as exc:
                self._record_exception(exc)
            else:
                self._observe_events(result)
            self._stop.wait(self._interval_seconds)

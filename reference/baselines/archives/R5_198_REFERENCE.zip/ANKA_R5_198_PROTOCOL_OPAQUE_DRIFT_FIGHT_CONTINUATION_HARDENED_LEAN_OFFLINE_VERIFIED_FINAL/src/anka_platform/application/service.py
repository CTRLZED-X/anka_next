from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
import json
from pathlib import Path
from threading import RLock
from typing import Callable, Mapping
from uuid import uuid4

from anka_platform.application.models import SessionSelection
from anka_platform.application.errors import SessionLaunchFailed, SessionPreflightBlocked
from anka_platform.application.readiness import ReadinessService
from anka_platform.application.payloads import control_record_payload, run_payload, session_plan_payload
from anka_platform.application.session_forensics import SessionForensicsFinalizer
from anka_platform.application.session_lifecycle import SessionLifecycleCoordinator
from anka_platform.application.session_registry import SessionControlRegistry
from anka_platform.application.session_snapshot import SessionSnapshotService
from anka_platform.core.failures import SessionCompileError
from anka_platform.core.models import ControlMode, MembershipRequirement, PartyLeadership
from anka_platform.core.registry import PolicyRegistry
from anka_platform.core.session import PlayerProfile, SessionPlan
from anka_platform.core.session_compiler import SessionCompiler
from anka_platform.protocol.capabilities import CapabilityStatus, ProtocolCapabilityMatrix
from anka_platform.protocol.certification import core_capability_report
from anka_platform.observability.run_store import SessionRunRegistry
from anka_platform.execution.control_authority import ControlAuthorityBusyError


class ApplicationService:
    """Stable operator API between Script Studio and automation internals.

    It compiles a complete SessionPlan before any worker is started.  During the
    architecture migration a mission may launch through an existing proven
    script worker; that compatibility mapping is kept outside MissionDefinition.
    """

    def __init__(
        self,
        *,
        missions,
        profiles,
        compiler: SessionCompiler,
        policies: PolicyRegistry,
        protocol_matrix_provider: Callable[[], ProtocolCapabilityMatrix],
        canonical_contract_version: int,
        party_preflight_provider: Callable[[], dict] | None,
        windows_readiness_provider: Callable[[], dict] | None,
        supervisor,
        mission_launchers: Mapping[str, str],
        plan_activator: Callable[[SessionPlan], None] | None = None,
        runs_root: str | Path | None = None,
        run_registry: SessionRunRegistry | None = None,
        mission_runtime_resolver: Callable[[object], Mapping] | None = None,
        session_locker: Callable[[str], None] | None = None,
        session_releaser: Callable[[str], None] | None = None,
        client_inventory_provider: Callable[[], list[dict] | tuple[dict, ...]] | None = None,
        combat_profile_ids_provider: Callable[[], list[str] | tuple[str, ...]] | None = None,
        combat_profile_compatibility_provider: Callable[[str], tuple[str, ...] | list[str]] | None = None,
        calibration_profile_exists_provider: Callable[[str], bool] | None = None,
        max_party_accounts: int | None = None,
        session_configuration_validator: Callable[[SessionPlan], None] | None = None,
        party_plan_preparer: Callable[[SessionPlan], None] | None = None,
        route_validator: Callable[[SessionPlan], object] | None = None,
        launch_failure_notifier: Callable[..., Mapping | None] | None = None,
        pending_launch_recovery: Callable[[SessionPlan, Mapping], Mapping | None] | None = None,
        control_authority=None,
    ) -> None:
        self.missions = missions
        self.profiles = profiles
        self.compiler = compiler
        self.policies = policies
        self.protocol_matrix_provider = protocol_matrix_provider
        self.canonical_contract_version = int(canonical_contract_version)
        self.party_preflight_provider = party_preflight_provider
        self.windows_readiness_provider = windows_readiness_provider
        self.supervisor = supervisor
        self.mission_launchers = dict(mission_launchers)
        self.plan_activator = plan_activator
        self.runs_root = Path(runs_root) if runs_root is not None else None
        self.run_registry = run_registry
        self.mission_runtime_resolver = mission_runtime_resolver
        self.session_locker = session_locker
        self.session_releaser = session_releaser
        self.client_inventory_provider = client_inventory_provider
        self.combat_profile_ids_provider = combat_profile_ids_provider
        self.combat_profile_compatibility_provider = combat_profile_compatibility_provider
        self.calibration_profile_exists_provider = calibration_profile_exists_provider
        self.max_party_accounts = int(max_party_accounts) if max_party_accounts is not None else None
        if self.max_party_accounts is not None and self.max_party_accounts < 1:
            raise ValueError("max_party_accounts must be >= 1")
        self.session_configuration_validator = session_configuration_validator
        self.party_plan_preparer = party_plan_preparer
        self.route_validator = route_validator
        self.launch_failure_notifier = launch_failure_notifier
        self.pending_launch_recovery = pending_launch_recovery
        self.control_authority = control_authority
        self._pending_launch_lock = RLock()
        # Serializes the irreversible boundary between an unstarted pending
        # Launch and worker creation.  A stall fail-stop and a readiness edge
        # must never race such that one disarms while the other starts input.
        self._launch_transition_lock = RLock()
        self._pending_launch_session_ids: set[str] = set()
        self._launch_authorizations: dict[str, dict] = {}
        self._launch_authorization_history: dict[str, dict] = {}
        self.readiness = ReadinessService(
            protocol_matrix_provider=self.protocol_matrix_provider,
            party_preflight_provider=self.party_preflight_provider,
            windows_readiness_provider=self.windows_readiness_provider,
            mission_launchers=self.mission_launchers,
        )
        self.session_registry = SessionControlRegistry()
        self.session_forensics = SessionForensicsFinalizer(self.runs_root, run_registry=self.run_registry)
        self.session_lifecycle = SessionLifecycleCoordinator(
            registry=self.session_registry,
            supervisor=self.supervisor,
            forensics=self.session_forensics,
            mission_launcher_resolver=lambda plan: self.mission_launchers[plan.mission_id],
            session_locker=self.session_locker,
            session_releaser=self.session_releaser,
            plan_activator=self.plan_activator,
            launch_failure_notifier=self.launch_failure_notifier,
            run_reserved_binder=(self._bind_control_run_prestart if self.control_authority is not None else None),
        )
        self.session_snapshots = SessionSnapshotService(
            registry=self.session_registry,
            supervisor=self.supervisor,
            party_status_provider=self._party_preflight,
            health_provider=self._health_reports,
        )

    def _bind_control_run_prestart(self, session_id: str, run_id: str) -> dict:
        if self.control_authority is None:
            return {}
        bound = self.control_authority.bind_run(str(run_id), session_id=str(session_id))
        if not isinstance(bound, Mapping) or str(bound.get("run_id") or "") != str(run_id):
            raise RuntimeError("CONTROL_RUN_PRESTART_BIND_FAILED")
        return dict(bound)

    def catalog_payload(self) -> dict:
        missions = []
        for mission_id, mission in sorted(self.missions.all().items()):
            missions.append({
                "id": mission_id,
                "route_id": mission.route_id,
                "target_policy_id": mission.target_policy_id,
                "team_strategy_id": mission.team_strategy_id,
                "fight_policy_set_id": mission.fight_policy_set_id,
                "required_capabilities": list(mission.required_capabilities),
                "stop": mission.stop.model_dump(mode="json"),
                "route_start": (list(mission.route_start) if mission.route_start is not None else None),
                "route_directions": list(mission.route_directions),
                "route_coordinates": [list(item) for item in mission.route_coordinates],
                "route_loop": mission.route_loop,
                "target_min_monsters": mission.target_min_monsters,
                "target_max_monsters": mission.target_max_monsters,
                "launchable": mission_id in self.mission_launchers,
            })
        runtime = self._party_preflight()
        runtime_accounts = dict(runtime.get("accounts") or {})
        accounts = []
        for account_id, profile in sorted(self.profiles.all().items()):
            runtime_status = dict(runtime_accounts.get(account_id) or {})
            accounts.append({
                "account_id": account_id,
                "character_name": profile.character_name,
                "class_name": profile.class_name,
                "window_title_contains": profile.window_title_contains,
                "available": runtime_status.get("ready") if runtime_status else None,
                "runtime": runtime_status,
                "default_control_mode": profile.default_control_mode.value,
                "default_requirement": profile.default_requirement.value,
                "default_leadership": profile.default_leadership.value,
                "default_fight_policy_id": profile.default_fight_policy_id,
                "default_passive_policy_id": profile.default_passive_policy_id,
                "default_placement_policy_id": profile.default_placement_policy_id,
                "default_combat_profile_id": profile.default_combat_profile_id or account_id,
            })
        detected_clients = []
        client_inventory_error = None
        if self.client_inventory_provider is not None:
            try:
                detected_clients = [dict(item) if isinstance(item, Mapping) else item.to_dict() for item in self.client_inventory_provider()]
            except Exception as exc:
                client_inventory_error = f"{type(exc).__name__}: {exc}"
        combat_profiles = []
        if self.combat_profile_ids_provider is not None:
            try:
                combat_profiles = list(self.combat_profile_ids_provider())
            except Exception:
                combat_profiles = []
        return {
            "missions": missions,
            "accounts": accounts,
            "detected_clients": detected_clients,
            "client_inventory_error": client_inventory_error,
            "combat_profiles": combat_profiles,
            "combat_profile_compatibility": {
                profile_id: list(self.combat_profile_compatibility_provider(profile_id) or ())
                for profile_id in combat_profiles
            } if self.combat_profile_compatibility_provider is not None else {},
            "policies": {
                "fight": list(self.policies.fight_ids()),
                "passive": list(self.policies.passive_ids()),
                "team": list(self.policies.team_ids()),
                "placement": list(self.policies.placement_ids()),
                "world": list(self.policies.world_ids()),
            },
        }

    def clients_payload(self) -> dict:
        if self.client_inventory_provider is None:
            return {"clients": []}
        try:
            values = [dict(item) if isinstance(item, Mapping) else item.to_dict() for item in self.client_inventory_provider()]
        except Exception as exc:
            return {"clients": [], "error": f"{type(exc).__name__}: {exc}"}
        return {"clients": values}

    def _party_preflight(self) -> dict:
        return self.readiness.party_preflight()

    def _windows_preflight(self) -> dict:
        return self.readiness.windows_preflight()

    def _compile(self, selection: SessionSelection, matrix: ProtocolCapabilityMatrix) -> SessionPlan:
        mission = self.missions.require(selection.mission_id)
        profiles = dict(self.profiles.all())
        for item in selection.accounts:
            if item.account_id in profiles:
                continue
            if not item.character_name or not item.window_title_contains:
                raise ValueError(f"selected detected account requires character_name and window_title_contains: {item.account_id}")
            profiles[item.account_id] = PlayerProfile(
                account_id=item.account_id, character_name=item.character_name,
                class_name=item.class_name or "Unknown", window_title_contains=item.window_title_contains,
                calibration_profile=item.calibration_profile or "shared",
                default_control_mode=item.control_mode or ControlMode.PASSIVE,
                default_requirement=(MembershipRequirement.REQUIRED if item.required is True else MembershipRequirement.OPTIONAL),
                default_leadership=PartyLeadership.MEMBER,
                default_fight_policy_id=item.fight_policy_id,
                default_passive_policy_id=item.passive_policy_id or "passive_end_turn",
                default_placement_policy_id=item.placement_policy_id,
                default_combat_profile_id=item.combat_profile_id,
            )
        selected_ids = tuple(item.account_id for item in selection.accounts)
        explicit_leaders = tuple(item.account_id for item in selection.accounts if item.leader)
        if len(explicit_leaders) > 1:
            raise ValueError("SESSION_REQUIRES_EXACTLY_ONE_LEADER:" + ",".join(explicit_leaders))
        required_ids = tuple(
            item.account_id for item in selection.accounts
            if item.required is True or (item.required is None and profiles[item.account_id].default_requirement.value == "REQUIRED")
        )
        control_modes = {item.account_id: item.control_mode for item in selection.accounts if item.control_mode is not None}
        fight_ids = {item.account_id: item.fight_policy_id for item in selection.accounts if item.fight_policy_id is not None}
        passive_ids = {item.account_id: item.passive_policy_id for item in selection.accounts if item.passive_policy_id is not None}
        placement_ids = {item.account_id: item.placement_policy_id for item in selection.accounts if item.placement_policy_id is not None}
        combat_profile_ids = {item.account_id: item.combat_profile_id for item in selection.accounts if item.combat_profile_id is not None}
        report = core_capability_report(
            matrix,
            canonical_contract_version=self.canonical_contract_version,
            accepted_statuses=(CapabilityStatus.VERIFIED,),
        )
        plan = self.compiler.compile(
            mission,
            selected_account_ids=selected_ids,
            player_profiles=profiles,
            protocol_report=report,
            leader_account_id=(explicit_leaders[0] if explicit_leaders else None),
            required_account_ids=required_ids,
            control_modes=control_modes,
            fight_policy_ids=fight_ids,
            passive_policy_ids=passive_ids,
            placement_policy_ids=placement_ids,
            combat_profile_ids=combat_profile_ids,
            route_start=selection.route_start, route_directions=selection.route_directions,
            route_coordinates=selection.route_coordinates, route_loop=selection.route_loop,
            target_min_monsters=selection.target_min_monsters, target_max_monsters=selection.target_max_monsters,
            target_wins=selection.target_wins, max_attempts=selection.max_attempts,
            stop_on_loss=selection.stop_on_loss, stop_on_unknown=selection.stop_on_unknown,
        )
        runtime = dict(self.mission_runtime_resolver(mission) or {}) if self.mission_runtime_resolver is not None else {}
        if runtime:
            plan = replace(
                plan,
                route_coordinates=(plan.route_coordinates if plan.route_directions else (plan.route_coordinates or tuple(runtime.get("route_coordinates") or ()))),
                target_min_monsters=(plan.target_min_monsters if plan.target_min_monsters is not None else runtime.get("target_min_monsters")),
                target_max_monsters=(plan.target_max_monsters if plan.target_max_monsters is not None else runtime.get("target_max_monsters")),
            )
        # The web/runtime composition supplies a route validator and therefore
        # represents an executable farming session.  Keep the generic
        # ApplicationService usable by unit/integration consumers that compile
        # abstract SessionPlans without a world route, while enforcing the
        # complete executable contract before Script Studio can Apply/Launch.
        if self.route_validator is not None:
            active_required = [
                member for member in plan.members
                if member.control_mode is ControlMode.ACTIVE and member.requirement is MembershipRequirement.REQUIRED
            ]
            if not active_required:
                raise ValueError("MISSION_REQUIRES_ACTIVE_REQUIRED_CONTROLLER")

            if plan.target_min_monsters is None or plan.target_max_monsters is None:
                raise ValueError("SESSION_TARGET_RANGE_UNRESOLVED")
            if int(plan.target_min_monsters) < 1 or int(plan.target_max_monsters) < 1:
                raise ValueError("target monster counts must be >= 1")
            if int(plan.target_min_monsters) > int(plan.target_max_monsters):
                raise ValueError("target_min_monsters must be <= target_max_monsters")
            if not tuple(plan.route_coordinates or ()) and not tuple(plan.route_directions or ()):
                raise ValueError("SESSION_ROUTE_UNRESOLVED")

        if self.max_party_accounts is not None and len(plan.members) > self.max_party_accounts:
            raise ValueError(
                f"PARTY_SIZE_EXCEEDS_BRIDGE_CAPACITY:{len(plan.members)}>{self.max_party_accounts}"
            )

        if self.calibration_profile_exists_provider is not None:
            required_ids = {
                member.account_id for member in plan.members
                if member.requirement is MembershipRequirement.REQUIRED
            }
            for profile in plan.player_profiles:
                # Optional members may legitimately be absent for the whole run.
                # Stable executability therefore depends only on Required lanes;
                # enforcing calibration for Optional profiles would contradict the
                # SessionPlan membership contract and the deeper runtime validator.
                if profile.account_id not in required_ids:
                    continue
                calibration_profile = str(profile.calibration_profile).strip()
                try:
                    exists = bool(self.calibration_profile_exists_provider(calibration_profile))
                except Exception as exc:
                    raise ValueError(
                        f"CALIBRATION_PROFILE_CHECK_FAILED:{profile.account_id}:{calibration_profile}:{type(exc).__name__}"
                    ) from exc
                if not exists:
                    raise ValueError(
                        f"CALIBRATION_PROFILE_NOT_FOUND:{profile.account_id}:{calibration_profile}"
                    )

        if self.combat_profile_ids_provider is not None:
            available_combat_profiles = {str(item) for item in self.combat_profile_ids_provider()}
            for member in plan.members:
                if member.control_mode is not ControlMode.ACTIVE:
                    continue
                combat_profile_id = str(member.combat_profile_id or member.account_id)
                if combat_profile_id not in available_combat_profiles:
                    raise ValueError(f"COMBAT_PROFILE_NOT_FOUND:{combat_profile_id}")
                if self.combat_profile_compatibility_provider is not None:
                    compatible = tuple(str(item).strip() for item in self.combat_profile_compatibility_provider(combat_profile_id) if str(item).strip())
                    if compatible:
                        class_name = str(plan.profile_for(member.account_id).class_name).strip()
                        if not class_name or class_name.casefold() == "unknown":
                            raise ValueError(f"COMBAT_PROFILE_CLASS_UNKNOWN:{member.account_id}:{combat_profile_id}")
                        if class_name.casefold() not in {item.casefold() for item in compatible}:
                            raise ValueError(
                                f"COMBAT_PROFILE_CLASS_MISMATCH:{member.account_id}:{class_name}:{combat_profile_id}:"
                                + ",".join(compatible)
                            )
        if self.session_configuration_validator is not None:
            self.session_configuration_validator(plan)
        if self.route_validator is not None:
            self.route_validator(plan)
        return plan

    def apply_payload(self, selection: SessionSelection) -> dict:
        matrix = self.protocol_matrix_provider()
        plan = self._compile(selection, matrix)
        if self.party_plan_preparer is not None:
            self.party_plan_preparer(plan)
        self.session_lifecycle.register_applied(plan)
        preflight = self.preview_payload_for_plan(plan)
        return {"applied_session_id": plan.session_id, **preflight}

    def preview_payload_for_plan(self, plan: SessionPlan) -> dict:
        readiness = self.readiness.runtime_preflight(plan)
        return {
            **readiness,
            "compile_error": None,
            "plan": session_plan_payload(plan),
        }

    def preview_payload(self, selection: SessionSelection) -> dict:
        matrix = self.protocol_matrix_provider()
        mission = self.missions.require(selection.mission_id)
        plan = None
        compile_error = None
        blockers: list[str] = []
        try:
            plan = self._compile(selection, matrix)
        except (SessionCompileError, KeyError, ValueError) as exc:
            compile_error = str(exc)
            blockers.append(f"SESSION_PLAN_INVALID:{compile_error}")

        required_protocol = {}
        for capability in mission.required_capabilities:
            entry = matrix._entry(capability)
            required_protocol[capability] = entry.to_dict()
            if entry.status is not CapabilityStatus.VERIFIED:
                blockers.append(f"PROTOCOL_CAPABILITY_NOT_VERIFIED:{capability}:{entry.status.value}")
        if selection.mission_id not in self.mission_launchers:
            blockers.append("MISSION_LAUNCHER_UNAVAILABLE")
        blockers = list(dict.fromkeys(blockers))
        configuration_valid = plan is not None and not blockers
        return {
            "configuration_valid": configuration_valid,
            "ready": configuration_valid,
            "blockers": blockers,
            "compile_error": compile_error,
            "plan": session_plan_payload(plan) if plan is not None else None,
            "party": {"ready": None, "status": "NOT_APPLIED", "accounts": {}},
            "windows": {"ready": None, "status": "NOT_APPLIED", "blockers": []},
            "protocol": {"adapter_id": matrix.adapter_id, "required": required_protocol},
        }

    def _health_reports(self, plan: SessionPlan | None):
        return self.readiness.health_reports(plan)

    def applied_preflight_payload(self, session_id: str) -> dict:
        token = str(session_id).strip()
        try:
            record = self.session_registry.get_session(token)
        except KeyError as exc:
            raise ValueError("applied SessionPlan not found or stale") from exc
        return {
            "applied_session_id": token,
            **self.preview_payload_for_plan(record.plan),
            "control": control_record_payload(record),
            "pending_launch": self._is_pending_launch(token),
            "launch_authorization": self._launch_authorization(token),
        }

    def _authorize_launch(self, session_id: str, *, source: str) -> dict:
        token = str(session_id).strip()
        record = {
            "authorization_id": uuid4().hex,
            "session_id": token,
            "source": str(source),
            "requested_utc": datetime.now(timezone.utc).isoformat(),
            "state": "AUTHORIZED",
        }
        if self.control_authority is not None:
            try:
                self.control_authority.arm_session(
                    session_id=token, authorization_id=record["authorization_id"], source=str(source)
                )
            except ControlAuthorityBusyError as exc:
                raise ValueError(str(exc)) from exc
        # Publish the Launch authorization only after physical-control authority
        # was acquired. A rejected second Launch must not leave a phantom pending
        # authorization that can later be consumed by the convergence worker.
        with self._pending_launch_lock:
            self._launch_authorizations[token] = record
        return dict(record)

    def _launch_authorization(self, session_id: str) -> dict | None:
        token = str(session_id).strip()
        with self._pending_launch_lock:
            value = self._launch_authorizations.get(token) or self._launch_authorization_history.get(token)
            return dict(value) if value is not None else None

    def _consume_launch_authorization(self, session_id: str, *, state: str) -> dict | None:
        token = str(session_id).strip()
        with self._pending_launch_lock:
            value = self._launch_authorizations.pop(token, None)
            if value is None:
                value = self._launch_authorization_history.get(token)
            if value is None:
                return None
            consumed = {**dict(value), "state": str(state), "consumed_utc": datetime.now(timezone.utc).isoformat()}
            self._launch_authorization_history[token] = consumed
            return dict(consumed)

    def _has_active_launch_authorization(self, session_id: str) -> bool:
        token = str(session_id).strip()
        with self._pending_launch_lock:
            return token in self._launch_authorizations

    def _supersede_unstarted_sessions(self, *, except_session_id: str | None = None) -> tuple[str, ...]:
        keep = str(except_session_id).strip() if except_session_id is not None else None
        retired: list[str] = []
        for record in self.session_registry.applied_records():
            session_id = str(record.session_id)
            if keep is not None and session_id == keep:
                continue
            self._set_pending_launch(session_id, False)
            self._consume_launch_authorization(session_id, state="SUPERSEDED")
            if self.control_authority is not None:
                self.control_authority.disarm(reason="SESSION_SUPERSEDED", session_id=session_id)
            self.session_registry.supersede_applied(session_id)
            retired.append(session_id)
        return tuple(retired)

    def cancel_pending_launch(self, session_id: str) -> dict:
        """Cancel an explicit Launch intent before a worker owns the session."""
        token = str(session_id).strip()
        try:
            record = self.session_registry.get_session(token)
        except KeyError as exc:
            raise ValueError("applied SessionPlan not found or stale") from exc
        if record.lifecycle is not None:
            raise ValueError("pending Launch can only be cancelled before worker start")
        self._set_pending_launch(token, False)
        authorization = self._consume_launch_authorization(token, state="CANCELLED")
        if self.control_authority is not None:
            self.control_authority.disarm(reason="PENDING_LAUNCH_CANCELLED", session_id=token)
        record = self.session_registry.supersede_applied(token)
        return {
            "session_id": token,
            "status": "CANCELLED",
            "pending_launch": False,
            "launch_authorization": authorization,
            "control": control_record_payload(record),
        }

    def fail_pending_launch(
        self, session_id: str, *, error: str, reason: str = "PENDING_LAUNCH_STALLED",
        terminal_incident_id: str | None = None,
    ) -> dict:
        """Atomically retire an unstarted Launch intent and revoke input authority.

        This is the terminal counterpart to :meth:`cancel_pending_launch`.  It is
        used by the backend stall watchdog, not by browser state.  The transition
        lock closes the race where readiness becomes true at the same instant the
        watchdog fires: either a worker wins and owns the session, or the pending
        session becomes FAILED_TO_START before any worker can be created.
        """
        token = str(session_id).strip()
        if not token:
            raise ValueError("session_id must not be empty")
        with self._launch_transition_lock:
            try:
                record = self.session_registry.get_session(token)
            except KeyError as exc:
                raise ValueError("applied SessionPlan not found or stale") from exc

            # Never turn a stale watchdog observation into a live-run shutdown.
            if record.run_id is not None or (record.lifecycle is not None and getattr(record.lifecycle, "value", "") not in {"LAUNCHING"}):
                self._set_pending_launch(token, False)
                return {
                    "session_id": token,
                    "status": "ALREADY_STARTED_OR_TERMINAL",
                    "run_id": record.run_id,
                    "control": control_record_payload(record),
                }

            if record.lifecycle is None:
                record = self.session_registry.reserve_launch(token)
            record = self.session_registry.mark_failed_to_start(
                token,
                error=str(error),
                terminal_incident_id=(str(terminal_incident_id) if terminal_incident_id else None),
            )
            self._set_pending_launch(token, False)
            authorization = self._consume_launch_authorization(token, state="FAILED_TO_START")
            control = None
            if self.control_authority is not None:
                control = self.control_authority.disarm(reason=str(reason), session_id=token)
            return {
                "session_id": token,
                "status": "FAILED_TO_START",
                "pending_launch": False,
                "launch_authorization": authorization,
                "control_authority": control,
                "control": control_record_payload(record),
            }

    def _set_pending_launch(self, session_id: str, pending: bool) -> None:
        token = str(session_id).strip()
        with self._pending_launch_lock:
            if pending:
                self._pending_launch_session_ids.add(token)
            else:
                self._pending_launch_session_ids.discard(token)

    def _is_pending_launch(self, session_id: str) -> bool:
        token = str(session_id).strip()
        with self._pending_launch_lock:
            return token in self._pending_launch_session_ids

    def pending_launch_session_ids(self) -> tuple[str, ...]:
        with self._pending_launch_lock:
            return tuple(sorted(self._pending_launch_session_ids))

    def launch_applied(
        self, session_id: str, *, authorize_if_missing: bool = True,
        authorization_source: str = "EXPLICIT_LAUNCH_APPLIED",
        retain_authorization_on_preflight_block: bool = False,
        startup_recovery_permit: Mapping | None = None,
    ) -> dict:
        token = str(session_id).strip()
        if not self._has_active_launch_authorization(token):
            if authorize_if_missing:
                self._authorize_launch(token, source=authorization_source)
            else:
                raise ValueError("SESSION_LAUNCH_NOT_AUTHORIZED")
        authorization = self._launch_authorization(token)
        try:
            record = self.session_registry.get_session(token)
        except KeyError as exc:
            self._set_pending_launch(token, False)
            self._consume_launch_authorization(token, state="STALE")
            if self.control_authority is not None:
                self.control_authority.disarm(reason="SESSION_STALE", session_id=token)
            raise ValueError("applied SessionPlan not found or stale") from exc
        preflight = self.preview_payload_for_plan(record.plan)
        if record.lifecycle is None and not preflight["ready"]:
            permit = dict(startup_recovery_permit or {})
            permit_valid = bool(permit) and str(permit.get("session_id") or "") == token
            permit_valid = permit_valid and str(permit.get("recovery_status") or "").upper() == "RUNTIME_REQUIRED"
            approved = {str(item) for item in (permit.get("approved_preflight_blockers") or ()) if str(item)}
            current = {str(item) for item in (preflight.get("blockers") or ()) if str(item)}
            unexpected = sorted(current - approved) if permit_valid else sorted(current)
            if not permit_valid or unexpected:
                # Recovery is bound to the exact preflight blocker surface that
                # was passively assessed. A new blocker appearing before worker
                # creation cancels the handoff instead of being hidden by a broad
                # boolean bypass. Disappearing blockers are safe improvements.
                if not retain_authorization_on_preflight_block:
                    self._consume_launch_authorization(token, state="PREFLIGHT_BLOCKED")
                    if self.control_authority is not None:
                        self.control_authority.disarm(reason="SESSION_PREFLIGHT_BLOCKED", session_id=token)
                detail = unexpected or sorted(current)
                raise SessionPreflightBlocked(
                    session_id=token, blockers=detail, preflight=preflight,
                )
        try:
            with self._launch_transition_lock:
                record = self.session_lifecycle.launch(token)
        except SessionLaunchFailed:
            self._set_pending_launch(token, False)
            self._consume_launch_authorization(token, state="FAILED_TO_START")
            if self.control_authority is not None:
                self.control_authority.disarm(reason="SESSION_FAILED_TO_START", session_id=token)
            raise
        run_body = None
        health = self._health_reports(record.plan)
        if record.run_id is not None:
            self._set_pending_launch(token, False)
            authorization = self._consume_launch_authorization(token, state="CONSUMED_BY_RUN") or authorization
            if self.control_authority is not None:
                self.control_authority.bind_run(record.run_id, session_id=token)
            status = self.supervisor.status(record.run_id)
            run_body = run_payload(status)
            self.session_forensics.record_health_if_changed(record.run_id, (item.to_dict() for item in health))
        return {
            "pending_launch": self._is_pending_launch(token),
            "launch_authorization": authorization,
            "session": session_plan_payload(record.plan),
            "run": run_body,
            "preflight": preflight,
            "party": self._party_preflight(),
            "health": [item.to_dict() for item in health],
            "control": control_record_payload(self.session_registry.get_session(token)),
        }

    def launch(self, selection: SessionSelection) -> dict:
        applied = self.apply_payload(selection)
        session_id = str(applied["applied_session_id"])
        self._supersede_unstarted_sessions(except_session_id=session_id)
        authorization = self._authorize_launch(session_id, source="STUDIO_LAUNCH")
        if applied.get("ready") is not True:
            self._set_pending_launch(session_id, True)
            record = self.session_registry.get_session(session_id)
            health = self._health_reports(record.plan)
            return {
                "pending_launch": True,
                "applied_session_id": session_id,
                "launch_authorization": authorization,
                "session": session_plan_payload(record.plan),
                "run": None,
                "preflight": applied,
                "party": self._party_preflight(),
                "health": [item.to_dict() for item in health],
                "control": control_record_payload(record),
            }
        # Readiness is sampled once during apply_payload() and again inside
        # launch_applied() immediately before worker reservation.  A live client
        # can legitimately change between those two samples (window identity,
        # capture generation, protocol/runtime health, etc.).  Treat that as the
        # same guarded pending-Launch transition used by an initially-not-ready
        # request instead of surfacing a spurious HTTP launch failure.
        try:
            result = self.launch_applied(
                session_id, authorize_if_missing=False,
                retain_authorization_on_preflight_block=True,
            )
        except SessionPreflightBlocked as exc:
            self._set_pending_launch(session_id, True)
            current = exc.preflight
            record = self.session_registry.get_session(session_id)
            health = self._health_reports(record.plan)
            return {
                "pending_launch": True,
                "applied_session_id": session_id,
                "launch_authorization": self._launch_authorization(session_id),
                "session": session_plan_payload(record.plan),
                "run": None,
                "preflight": current,
                "party": current.get("party") or self._party_preflight(),
                "health": [item.to_dict() for item in health],
                "control": control_record_payload(record),
                "launch_transition": {
                    "status": "WAITING",
                    "code": "PREFLIGHT_CHANGED_BEFORE_WORKER_START",
                    "blockers": list(current.get("blockers") or exc.blockers),
                },
            }
        result["pending_launch"] = False
        return result

    def advance_pending_launches(self) -> list[dict]:
        events: list[dict] = []
        for session_id in self.pending_launch_session_ids():
            if not self._has_active_launch_authorization(session_id):
                self._set_pending_launch(session_id, False)
                events.append({
                    "session_id": session_id,
                    "status": "UNAUTHORIZED_PENDING_DROPPED",
                    "failure_code": "SESSION_LAUNCH_NOT_AUTHORIZED",
                })
                continue
            try:
                record = self.session_registry.get_session(session_id)
            except KeyError:
                self._set_pending_launch(session_id, False)
                self._consume_launch_authorization(session_id, state="STALE")
                events.append({"session_id": session_id, "status": "STALE"})
                continue
            if record.lifecycle is not None:
                self._set_pending_launch(session_id, False)
                self._consume_launch_authorization(session_id, state="ALREADY_STARTED")
                events.append({"session_id": session_id, "status": "ALREADY_STARTED", "run_id": record.run_id})
                continue
            preflight = self.preview_payload_for_plan(record.plan)
            if preflight.get("ready") is not True:
                recovery: dict = {}
                if self.pending_launch_recovery is not None:
                    try:
                        raw_recovery = self.pending_launch_recovery(record.plan, preflight)
                        if isinstance(raw_recovery, Mapping):
                            recovery = dict(raw_recovery)
                    except Exception as exc:
                        recovery = {
                            "status": "ERROR",
                            "code": "PENDING_LAUNCH_RECOVERY_ERROR",
                            "detail": f"{type(exc).__name__}: {exc}",
                        }
                recovery_status = str(recovery.get("status") or "").upper()
                if recovery_status == "RUNTIME_REQUIRED":
                    try:
                        recovery_permit = {
                            "session_id": session_id,
                            "recovery_status": recovery_status,
                            "recovery_code": str(recovery.get("code") or ""),
                            "approved_preflight_blockers": sorted(
                                str(item) for item in (preflight.get("blockers") or ()) if str(item)
                            ),
                        }
                        result = self.launch_applied(
                            session_id, authorize_if_missing=False,
                            retain_authorization_on_preflight_block=True,
                            startup_recovery_permit=recovery_permit,
                        )
                    except SessionLaunchFailed as exc:
                        # Worker creation/runtime launch genuinely failed.
                        # launch_applied() has already terminalized the pending
                        # intent and consumed its launch authorization.
                        events.append({
                            "session_id": session_id, "status": "FAILED_TO_START",
                            "error": exc.error, "incident_id": exc.incident_id,
                            "recovery": recovery,
                        })
                        continue
                    except SessionPreflightBlocked as exc:
                        # The passive preflight can change between recovery
                        # assessment and the guarded worker reservation.  This
                        # is a TOCTOU/readiness race, not a worker-start failure.
                        # Keep the frozen Launch intent and authorization alive
                        # so the next tick re-runs the *current* preflight and
                        # startup-convergence policy.  Reporting FAILED_TO_START
                        # here previously removed watchdog ownership while the
                        # session itself remained pending, creating an endless
                        # misleading failure loop.
                        current_preflight = exc.preflight
                        events.append({
                            "session_id": session_id,
                            "status": "WAITING",
                            "detail": str(exc),
                            "launch_authorization": self._launch_authorization(session_id),
                            "blockers": tuple(current_preflight.get("blockers") or exc.blockers),
                            "party_blockers": tuple((current_preflight.get("party") or {}).get("blockers") or ()),
                            "windows_blockers": tuple((current_preflight.get("windows") or {}).get("blockers") or ()),
                            "recovery": {
                                "status": "WAITING",
                                "code": "STARTUP_RECOVERY_PERMIT_INVALIDATED",
                                "detail": str(exc),
                                "recoverable_by_waiting": True,
                                "previous_recovery": recovery,
                            },
                        })
                        continue
                    except ValueError as exc:
                        # A ValueError here that is *not* a structured preflight
                        # race indicates a malformed/stale launch request.  Use
                        # the same atomic terminal transition as the watchdog so
                        # registry lifecycle, pending ownership, launch authority
                        # and ControlAuthority cannot disagree about the outcome.
                        error = f"{type(exc).__name__}: {exc}"
                        try:
                            terminal = self.fail_pending_launch(
                                session_id, error=error, reason="SESSION_FAILED_TO_START",
                            )
                        except ValueError:
                            # Stale/not-found requests have already been stripped
                            # of pending/authorization state by launch_applied().
                            terminal = {"session_id": session_id, "status": "STALE"}
                        events.append({
                            "session_id": session_id,
                            "status": str(terminal.get("status") or "FAILED_TO_START"),
                            "error": error,
                            "terminalization": terminal,
                            "recovery": recovery,
                        })
                        continue
                    run_id = (result.get("run") or {}).get("run_id") or (result.get("control") or {}).get("run_id")
                    recovery_record = {**recovery, "permit": recovery_permit}
                    events.append({
                        "session_id": session_id, "status": "LAUNCHED" if run_id else "LAUNCHING",
                        "run_id": run_id, "launch_authorization": result.get("launch_authorization"),
                        # Keep one canonical key because the checkpoint/incident
                        # consumer reads `recovery`. The historical alias remains
                        # for compatibility with older external readers.
                        "recovery": recovery_record,
                        "startup_recovery": recovery_record,
                    })
                    continue
                events.append({
                    "session_id": session_id,
                    "status": "RECOVERING" if recovery_status == "RECOVERING" else "WAITING",
                    "launch_authorization": self._launch_authorization(session_id),
                    "blockers": tuple(preflight.get("blockers") or ()),
                    "party_blockers": tuple((preflight.get("party") or {}).get("blockers") or ()),
                    "windows_blockers": tuple((preflight.get("windows") or {}).get("blockers") or ()),
                    "recovery": recovery,
                })
                continue
            try:
                result = self.launch_applied(
                    session_id, authorize_if_missing=False,
                    retain_authorization_on_preflight_block=True,
                )
            except SessionLaunchFailed as exc:
                self._set_pending_launch(session_id, False)
                events.append({
                    "session_id": session_id, "status": "FAILED_TO_START",
                    "error": exc.error, "incident_id": exc.incident_id,
                })
                continue
            except SessionPreflightBlocked as exc:
                # The ready sample changed before worker reservation. Preserve
                # the exact second-sample blockers and keep Launch pending; the
                # next convergence tick will classify their recoverability.
                current_preflight = exc.preflight
                events.append({
                    "session_id": session_id,
                    "status": "WAITING",
                    "detail": str(exc),
                    "launch_authorization": self._launch_authorization(session_id),
                    "blockers": tuple(current_preflight.get("blockers") or exc.blockers),
                    "party_blockers": tuple((current_preflight.get("party") or {}).get("blockers") or ()),
                    "windows_blockers": tuple((current_preflight.get("windows") or {}).get("blockers") or ()),
                    "recovery": {
                        "status": "WAITING",
                        "code": "PREFLIGHT_CHANGED_BEFORE_WORKER_START",
                        "detail": str(exc),
                        "recoverable_by_waiting": True,
                    },
                })
                continue
            except ValueError as exc:
                # Non-preflight ValueError is not a readiness race.  Leaving it
                # in WAITING would strand a malformed/stale launch behind the
                # watchdog.  Retire it through the same authoritative atomic
                # transition used by every other failed-to-start path.
                error = f"{type(exc).__name__}: {exc}"
                try:
                    terminal = self.fail_pending_launch(
                        session_id, error=error, reason="SESSION_FAILED_TO_START",
                    )
                except ValueError:
                    terminal = {"session_id": session_id, "status": "STALE"}
                events.append({
                    "session_id": session_id,
                    "status": str(terminal.get("status") or "FAILED_TO_START"),
                    "error": error,
                    "terminalization": terminal,
                })
                continue
            run_id = (result.get("run") or {}).get("run_id") or (result.get("control") or {}).get("run_id")
            if run_id:
                self._set_pending_launch(session_id, False)
                events.append({
                    "session_id": session_id, "status": "LAUNCHED", "run_id": run_id,
                    "launch_authorization": result.get("launch_authorization"),
                })
            else:
                events.append({
                    "session_id": session_id, "status": "LAUNCHING",
                    "launch_authorization": result.get("launch_authorization"),
                })
        return events

    def session_snapshot_payload(self, run_id: str) -> dict:
        return self.session_snapshots.snapshot(run_id).to_dict()

    def status_payload(self, run_id: str) -> dict:
        return self.session_snapshot_payload(run_id)

    def application_state_payload(self) -> dict:
        records = self.session_registry.records()
        active_records = self.session_registry.active_records()
        applied_records = self.session_registry.applied_records()
        active = []
        for record in active_records:
            item = {
                **control_record_payload(record),
                "mission_id": record.plan.mission_id,
                "session": session_plan_payload(record.plan),
                "pending_launch": self._is_pending_launch(record.session_id),
                "launch_authorization": self._launch_authorization(record.session_id),
            }
            if record.run_id is not None:
                item["snapshot"] = self.session_snapshot_payload(record.run_id)
            active.append(item)
        applied = [
            {
                **control_record_payload(record),
                "mission_id": record.plan.mission_id,
                "session": session_plan_payload(record.plan),
                "pending_launch": self._is_pending_launch(record.session_id),
                "launch_authorization": self._launch_authorization(record.session_id),
            }
            for record in applied_records
        ]
        terminal = []
        for record in self.session_registry.terminal_records()[:10]:
            item = {
                **control_record_payload(record),
                "mission_id": record.plan.mission_id,
                "session": session_plan_payload(record.plan),
                "pending_launch": False,
                "launch_authorization": self._launch_authorization(record.session_id),
            }
            if record.run_id is not None:
                try:
                    item["snapshot"] = self.session_snapshot_payload(record.run_id)
                except Exception:
                    # Recovery must remain available even if a historical worker
                    # can no longer be materialized into a live snapshot.
                    pass
            terminal.append(item)
        focused = active[0]["session_id"] if active else (applied[0]["session_id"] if applied else None)
        return {
            "revision": sum(record.revision for record in records),
            "active_sessions": active,
            "applied_sessions": applied,
            "recent_terminal_sessions": terminal,
            "focused_session_id": focused,
        }

    def diagnostics_payload(self, run_id: str) -> dict:
        body = self.status_payload(run_id)
        store = self.session_forensics.store_for(run_id)
        if store is None:
            body["forensics"] = None
            return body
        root = getattr(store, "root", None)
        files = sorted(item.name for item in root.iterdir() if item.is_file()) if root is not None and root.is_dir() else []
        body["forensics"] = {
            "session_id": getattr(store, "session_id", body["session"]["session_id"]),
            "root": str(root) if root is not None else None,
            "files": files,
        }
        return body

    def run_history_payload(self) -> dict:
        sessions: list[dict] = []
        if self.runs_root is not None and self.runs_root.is_dir():
            for root in self.runs_root.iterdir():
                if not root.is_dir():
                    continue
                try:
                    plan = json.loads((root / "session_plan.json").read_text(encoding="utf-8"))
                    summary_path = root / "summary.json"
                    summary = json.loads(summary_path.read_text(encoding="utf-8")) if summary_path.is_file() else {}
                except Exception:
                    continue
                sessions.append({
                    "session_id": plan.get("session_id", root.name),
                    "mission_id": plan.get("mission_id"),
                    "status": summary.get("status", "UNKNOWN"),
                    "run_id": summary.get("run_id"),
                    "finished_utc": summary.get("finished_utc"),
                })
        sessions.sort(key=lambda item: str(item.get("finished_utc") or ""), reverse=True)
        return {"sessions": sessions}

    def pause(self, run_id: str) -> dict:
        self.session_lifecycle.pause(run_id)
        return self.status_payload(run_id)

    def resume(self, run_id: str) -> dict:
        self.session_lifecycle.resume(run_id)
        return self.status_payload(run_id)

    def stop(self, run_id: str) -> dict:
        self.session_lifecycle.stop(run_id)
        return self.status_payload(run_id)


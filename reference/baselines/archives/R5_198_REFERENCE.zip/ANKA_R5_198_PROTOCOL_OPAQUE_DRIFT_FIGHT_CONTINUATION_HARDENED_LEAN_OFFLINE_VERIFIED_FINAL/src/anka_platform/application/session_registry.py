from __future__ import annotations

from collections import deque
from dataclasses import replace
from datetime import datetime, timezone
from threading import RLock

from anka_platform.application.control_models import (
    AppliedPlanState,
    CleanupState,
    RunLifecycle,
    SessionControlRecord,
)
from anka_platform.core.session import SessionPlan


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class SessionControlRegistry:
    """Thread-safe in-memory control-plane index.

    The registry only owns immutable control records and transition validation.
    It never performs external I/O or calls runtime services while holding its lock.
    """

    _ALLOWED: dict[RunLifecycle | None, frozenset[RunLifecycle]] = {
        None: frozenset({RunLifecycle.LAUNCHING}),
        RunLifecycle.LAUNCHING: frozenset({RunLifecycle.RUNNING, RunLifecycle.FAILED_TO_START}),
        RunLifecycle.RUNNING: frozenset({
            RunLifecycle.PAUSED,
            RunLifecycle.STOPPING,
            RunLifecycle.COMPLETED,
            RunLifecycle.FAILED,
            RunLifecycle.STOPPED,
        }),
        RunLifecycle.PAUSED: frozenset({
            RunLifecycle.RUNNING,
            RunLifecycle.STOPPING,
            RunLifecycle.COMPLETED,
            RunLifecycle.FAILED,
            RunLifecycle.STOPPED,
        }),
        RunLifecycle.STOPPING: frozenset({
            RunLifecycle.STOPPED,
            RunLifecycle.COMPLETED,
            RunLifecycle.FAILED,
        }),
        RunLifecycle.COMPLETED: frozenset(),
        RunLifecycle.FAILED: frozenset(),
        RunLifecycle.STOPPED: frozenset(),
        RunLifecycle.FAILED_TO_START: frozenset(),
    }

    def __init__(self, *, max_terminal_records: int = 128) -> None:
        if int(max_terminal_records) < 1:
            raise ValueError("max_terminal_records must be >= 1")
        self._lock = RLock()
        self._max_terminal_records = int(max_terminal_records)
        self._by_session: dict[str, SessionControlRecord] = {}
        self._session_by_run: dict[str, str] = {}
        self._terminal_order: deque[str] = deque()
        self._terminal_index: set[str] = set()

    def register_applied(self, plan: SessionPlan) -> SessionControlRecord:
        now = _utc_now()
        with self._lock:
            if plan.session_id in self._by_session:
                raise RuntimeError(f"session already registered: {plan.session_id}")
            record = SessionControlRecord(
                session_id=plan.session_id,
                plan=plan,
                plan_state=AppliedPlanState.APPLIED,
                lifecycle=None,
                run_id=None,
                cleanup_state=CleanupState.PENDING,
                revision=1,
                created_utc=now,
                updated_utc=now,
            )
            self._by_session[plan.session_id] = record
            return record

    def supersede_applied(self, session_id: str) -> SessionControlRecord:
        """Retire an unstarted applied plan so it can never acquire execution authority."""
        token = str(session_id).strip()
        with self._lock:
            record = self._by_session[token]
            if record.lifecycle is not None or record.plan_state is not AppliedPlanState.APPLIED:
                return record
            return self._replace(record, plan_state=AppliedPlanState.SUPERSEDED)

    def reserve_launch(self, session_id: str) -> SessionControlRecord:
        token = str(session_id).strip()
        with self._lock:
            record = self._by_session[token]
            if record.plan_state is not AppliedPlanState.APPLIED or record.lifecycle is not None:
                raise RuntimeError(f"session cannot reserve launch from {record.plan_state.value}/{getattr(record.lifecycle, 'value', None)}")
            return self._replace(record, lifecycle=RunLifecycle.LAUNCHING)

    def bind_run(self, session_id: str, run_id: str) -> SessionControlRecord:
        session_token = str(session_id).strip()
        run_token = str(run_id).strip()
        if not run_token:
            raise ValueError("run_id must not be empty")
        with self._lock:
            record = self._by_session[session_token]
            if record.lifecycle is not RunLifecycle.LAUNCHING:
                raise RuntimeError(f"session cannot bind run while {getattr(record.lifecycle, 'value', None)}")
            owner = self._session_by_run.get(run_token)
            if owner is not None and owner != session_token:
                raise RuntimeError(f"run already bound to another session: {run_token}")
            updated = self._replace(
                record,
                run_id=run_token,
                plan_state=AppliedPlanState.CONSUMED,
                lifecycle=RunLifecycle.RUNNING,
            )
            self._session_by_run[run_token] = session_token
            return updated

    def set_run_state(
        self,
        run_id: str,
        state: RunLifecycle,
        *,
        error: str | None = None,
    ) -> SessionControlRecord:
        run_token = str(run_id).strip()
        target = RunLifecycle(state)
        with self._lock:
            session_id = self._session_by_run.get(run_token)
            if session_id is None:
                raise RuntimeError(f"cannot transition unknown run: {run_token}")
            record = self._by_session[session_id]
            if record.lifecycle is target:
                if error == record.terminal_error or error is None:
                    return record
            if target not in self._ALLOWED.get(record.lifecycle, frozenset()):
                raise RuntimeError(
                    f"cannot transition run {run_token} from {getattr(record.lifecycle, 'value', None)} to {target.value}"
                )
            return self._replace(record, lifecycle=target, terminal_error=error)

    def mark_failed_to_start(
        self,
        session_id: str,
        error: str | None = None,
        *,
        cleanup_state: CleanupState = CleanupState.COMPLETE,
        cleanup_errors: tuple[str, ...] = (),
        terminal_incident_id: str | None = None,
    ) -> SessionControlRecord:
        token = str(session_id).strip()
        normalized_errors = tuple(str(item) for item in cleanup_errors)
        with self._lock:
            record = self._by_session[token]
            if record.lifecycle is RunLifecycle.FAILED_TO_START:
                return record
            if record.lifecycle is not RunLifecycle.LAUNCHING:
                raise RuntimeError(f"session cannot fail launch while {getattr(record.lifecycle, 'value', None)}")
            updated = self._replace(
                record,
                lifecycle=RunLifecycle.FAILED_TO_START,
                terminal_error=error,
                plan_state=AppliedPlanState.CONSUMED,
                cleanup_state=CleanupState(cleanup_state),
                cleanup_errors=normalized_errors,
                terminal_incident_id=(str(terminal_incident_id) if terminal_incident_id else None),
            )
            self._remember_terminal_locked(updated.session_id)
            self._prune_terminal_locked()
            return updated

    def terminal_records(self) -> tuple[SessionControlRecord, ...]:
        """Return bounded terminal records, newest first."""
        with self._lock:
            return tuple(
                self._by_session[session_id]
                for session_id in reversed(self._terminal_order)
                if session_id in self._by_session
            )

    def mark_cleanup(
        self,
        run_id: str,
        state: CleanupState,
        errors: tuple[str, ...] = (),
    ) -> SessionControlRecord:
        run_token = str(run_id).strip()
        target = CleanupState(state)
        normalized = tuple(str(item) for item in errors)
        with self._lock:
            session_id = self._session_by_run[run_token]
            record = self._by_session[session_id]
            if record.cleanup_state is target and record.cleanup_errors == normalized:
                return record
            updated = self._replace(record, cleanup_state=target, cleanup_errors=normalized)
            if updated.lifecycle is not None and updated.lifecycle.terminal and target in {CleanupState.COMPLETE, CleanupState.DEGRADED}:
                self._remember_terminal_locked(updated.session_id)
                self._prune_terminal_locked()
            return updated

    def get_session(self, session_id: str) -> SessionControlRecord:
        with self._lock:
            return self._by_session[str(session_id).strip()]

    def get_run(self, run_id: str) -> SessionControlRecord:
        with self._lock:
            session_id = self._session_by_run[str(run_id).strip()]
            return self._by_session[session_id]

    def records(self) -> tuple[SessionControlRecord, ...]:
        with self._lock:
            return tuple(self._by_session[key] for key in sorted(self._by_session))

    def active_records(self) -> tuple[SessionControlRecord, ...]:
        active = {
            RunLifecycle.LAUNCHING,
            RunLifecycle.RUNNING,
            RunLifecycle.PAUSED,
            RunLifecycle.STOPPING,
        }
        with self._lock:
            return tuple(
                record
                for _, record in sorted(self._by_session.items())
                if record.lifecycle in active
            )

    def applied_records(self) -> tuple[SessionControlRecord, ...]:
        with self._lock:
            return tuple(
                record
                for _, record in sorted(self._by_session.items())
                if record.plan_state is AppliedPlanState.APPLIED and record.lifecycle is None
            )

    def _remember_terminal_locked(self, session_id: str) -> None:
        if session_id in self._terminal_index:
            return
        self._terminal_index.add(session_id)
        self._terminal_order.append(session_id)

    def _prune_terminal_locked(self) -> None:
        while len(self._terminal_order) > self._max_terminal_records:
            session_id = self._terminal_order.popleft()
            self._terminal_index.discard(session_id)
            record = self._by_session.get(session_id)
            if record is None:
                continue
            if record.lifecycle is None or not record.lifecycle.terminal:
                continue
            if record.cleanup_state not in {CleanupState.COMPLETE, CleanupState.DEGRADED}:
                continue
            self._by_session.pop(session_id, None)
            if record.run_id is not None:
                self._session_by_run.pop(record.run_id, None)

    def _replace(self, record: SessionControlRecord, **changes) -> SessionControlRecord:
        updated = replace(
            record,
            revision=record.revision + 1,
            updated_utc=_utc_now(),
            **changes,
        )
        self._by_session[record.session_id] = updated
        return updated

from __future__ import annotations

from typing import Mapping, Any


class SessionLaunchFailed(RuntimeError):
    """Structured failure raised when a frozen SessionPlan cannot start a worker."""

    code = "SESSION_LAUNCH_FAILED"

    def __init__(
        self,
        *,
        session_id: str,
        stage: str,
        error: BaseException,
        incident: Mapping[str, Any] | None = None,
    ) -> None:
        self.session_id = str(session_id)
        self.stage = str(stage)
        self.original_error = error
        self.error = f"{type(error).__name__}: {error}"
        self.incident = dict(incident or {})
        self.incident_id = self.incident.get("incident_id")
        super().__init__(f"{self.code}:{self.stage}:{self.error}")

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "session_id": self.session_id,
            "stage": self.stage,
            "error": self.error,
            "incident_id": self.incident_id,
            "incident": dict(self.incident),
        }


class SessionPreflightBlocked(ValueError):
    """Structured passive-preflight rejection before worker reservation.

    This remains a ValueError for compatibility with the public application API,
    but preserves the exact second-sample blocker surface so pending-Launch
    recovery can distinguish a readiness race from an actual worker-start failure.
    """

    code = "SESSION_PREFLIGHT_BLOCKED"

    def __init__(self, *, session_id: str, blockers, preflight: Mapping[str, Any] | None = None) -> None:
        self.session_id = str(session_id)
        self.blockers = tuple(str(item) for item in blockers if str(item))
        self.preflight = dict(preflight or {})
        detail = ", ".join(self.blockers)
        super().__init__("session preflight blocked: " + detail)

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "session_id": self.session_id,
            "blockers": list(self.blockers),
            "preflight": dict(self.preflight),
        }

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from anka_platform.core.session import SessionPlan


class AppliedPlanState(str, Enum):
    APPLIED = "APPLIED"
    CONSUMED = "CONSUMED"
    SUPERSEDED = "SUPERSEDED"


class RunLifecycle(str, Enum):
    LAUNCHING = "LAUNCHING"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    STOPPED = "STOPPED"
    FAILED_TO_START = "FAILED_TO_START"

    @property
    def terminal(self) -> bool:
        return self in {
            RunLifecycle.COMPLETED,
            RunLifecycle.FAILED,
            RunLifecycle.STOPPED,
            RunLifecycle.FAILED_TO_START,
        }


class CleanupState(str, Enum):
    PENDING = "PENDING"
    COMPLETE = "COMPLETE"
    DEGRADED = "DEGRADED"


@dataclass(frozen=True, slots=True)
class SessionControlRecord:
    session_id: str
    plan: SessionPlan
    plan_state: AppliedPlanState
    lifecycle: RunLifecycle | None
    run_id: str | None
    cleanup_state: CleanupState
    revision: int
    created_utc: str
    updated_utc: str
    terminal_error: str | None = None
    cleanup_errors: tuple[str, ...] = ()
    terminal_incident_id: str | None = None

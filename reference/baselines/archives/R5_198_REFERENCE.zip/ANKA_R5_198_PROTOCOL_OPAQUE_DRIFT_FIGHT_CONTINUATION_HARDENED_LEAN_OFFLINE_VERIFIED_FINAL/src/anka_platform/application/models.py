from __future__ import annotations

from dataclasses import dataclass

from anka_platform.core.models import ControlMode
from anka_platform.core.routes import normalize_coordinate, normalize_route_directions, require_closed_cycle


def _optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    token = str(value).strip()
    return token or None


def _strict_bool(value: object, field_name: str) -> bool:
    if type(value) is not bool:
        raise ValueError(f"{field_name} must be a boolean")
    return value


def _optional_bool(value: object | None, field_name: str) -> bool | None:
    if value is None:
        return None
    return _strict_bool(value, field_name)


def _strict_int(value: object, field_name: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be an integer")
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        token = value.strip()
        if not token or any(ch not in "+-0123456789" for ch in token) or token in {"+", "-"}:
            raise ValueError(f"{field_name} must be an integer")
        return int(token)
    raise ValueError(f"{field_name} must be an integer")


@dataclass(frozen=True, slots=True)
class AccountSelection:
    account_id: str
    leader: bool = False
    required: bool | None = None
    control_mode: ControlMode | None = None
    fight_policy_id: str | None = None
    passive_policy_id: str | None = None
    placement_policy_id: str | None = None
    combat_profile_id: str | None = None
    character_name: str | None = None
    class_name: str | None = None
    window_title_contains: str | None = None
    calibration_profile: str | None = None

    def __post_init__(self) -> None:
        account_id = str(self.account_id).strip()
        if not account_id:
            raise ValueError("account_id must not be empty")
        object.__setattr__(self, "account_id", account_id)
        object.__setattr__(self, "leader", _strict_bool(self.leader, "leader"))
        object.__setattr__(self, "required", _optional_bool(self.required, "required"))
        if self.control_mode is not None and not isinstance(self.control_mode, ControlMode):
            object.__setattr__(self, "control_mode", ControlMode(str(self.control_mode).upper()))
        for field_name in ("fight_policy_id", "passive_policy_id", "placement_policy_id", "combat_profile_id", "character_name", "class_name", "window_title_contains", "calibration_profile"):
            object.__setattr__(self, field_name, _optional_text(getattr(self, field_name)))


@dataclass(frozen=True, slots=True)
class SessionSelection:
    mission_id: str
    accounts: tuple[AccountSelection, ...]
    route_start: tuple[int, int] | None = None
    route_directions: tuple[str, ...] | None = None
    route_coordinates: tuple[tuple[int, int], ...] | None = None
    route_loop: bool | None = None
    target_min_monsters: int | None = None
    target_max_monsters: int | None = None
    target_wins: int | None = None
    max_attempts: int | None = None
    stop_on_loss: bool | None = None
    stop_on_unknown: bool | None = None

    def __post_init__(self) -> None:
        mission_id = str(self.mission_id).strip()
        if not mission_id:
            raise ValueError("mission_id must not be empty")
        object.__setattr__(self, "mission_id", mission_id)
        object.__setattr__(self, "accounts", tuple(self.accounts))
        object.__setattr__(self, "route_loop", _optional_bool(self.route_loop, "route_loop"))
        object.__setattr__(self, "stop_on_loss", _optional_bool(self.stop_on_loss, "stop_on_loss"))
        if self.route_start is not None:
            object.__setattr__(self, "route_start", normalize_coordinate(self.route_start, field_name="route_start"))
        if self.route_directions is not None:
            normalized_directions = normalize_route_directions(self.route_directions)
            if not normalized_directions:
                raise ValueError("route_directions must contain at least one direction")
            object.__setattr__(self, "route_directions", tuple(item.value for item in normalized_directions))
        if self.route_start is not None or self.route_directions is not None:
            if self.route_start is None or self.route_directions is None:
                raise ValueError("route_start and route_directions must be configured together")
            if self.route_coordinates is not None:
                raise ValueError("route_coordinates cannot be combined with route_start/route_directions")
            if self.route_loop is not False:
                require_closed_cycle(self.route_start, self.route_directions)
        object.__setattr__(self, "stop_on_unknown", _optional_bool(self.stop_on_unknown, "stop_on_unknown"))
        if self.route_coordinates is not None:
            normalized_route: list[tuple[int, int]] = []
            for index, pair in enumerate(self.route_coordinates):
                try:
                    x, y = pair
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"route_coordinates[{index}] must contain exactly x,y") from exc
                normalized_route.append((
                    _strict_int(x, f"route_coordinates[{index}].x"),
                    _strict_int(y, f"route_coordinates[{index}].y"),
                ))
            object.__setattr__(self, "route_coordinates", tuple(normalized_route))
        for field_name in ("target_min_monsters", "target_max_monsters", "target_wins", "max_attempts"):
            value = getattr(self, field_name)
            if value is not None:
                normalized = _strict_int(value, field_name)
                if normalized < 1:
                    raise ValueError(f"{field_name} must be >= 1")
                object.__setattr__(self, field_name, normalized)
        if self.target_min_monsters is not None and self.target_max_monsters is not None and self.target_min_monsters > self.target_max_monsters:
            raise ValueError("target_min_monsters must be <= target_max_monsters")
        if self.target_wins is not None and self.max_attempts is not None and self.target_wins > self.max_attempts:
            raise ValueError("target_wins cannot exceed max_attempts")
        if self.route_coordinates is not None and not self.route_coordinates:
            raise ValueError("route_coordinates must contain at least one map")
        ids = [item.account_id for item in self.accounts]
        if not ids:
            raise ValueError("at least one account must be selected")
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate account selection")
        if sum(1 for item in self.accounts if item.leader) > 1:
            raise ValueError("at most one selected account may be leader")

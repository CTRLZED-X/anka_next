from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import time
from threading import RLock
from typing import Callable, Mapping

from anka_platform.application.payloads import control_record_payload, run_payload, session_plan_payload
from anka_platform.application.session_registry import SessionControlRegistry


@dataclass(frozen=True, slots=True)
class SessionSnapshot:
    snapshot_revision: int
    control: dict
    session: dict
    run: dict | None
    party: dict
    health: tuple[dict, ...]
    operational: dict
    problems: tuple[dict, ...] = ()

    def to_dict(self) -> dict:
        return {
            "snapshot_revision": self.snapshot_revision,
            "control": dict(self.control),
            "session": dict(self.session),
            "run": dict(self.run) if self.run is not None else None,
            "party": dict(self.party),
            "health": [dict(item) for item in self.health],
            "operational": dict(self.operational),
            "problems": [dict(item) for item in self.problems],
        }


class SessionSnapshotService:
    """Builds cheap read-only operator snapshots with monotonic revisions."""

    def __init__(
        self,
        *,
        registry: SessionControlRegistry,
        supervisor,
        party_status_provider: Callable[[], dict] | None,
        health_provider: Callable[[object], object] | None,
        problem_provider: Callable[[object], object] | None = None,
    ) -> None:
        self.registry = registry
        self.supervisor = supervisor
        self.party_status_provider = party_status_provider
        self.health_provider = health_provider
        self.problem_provider = problem_provider
        self._lock = RLock()
        self._revisions: dict[str, int] = {}
        self._fingerprints: dict[str, str] = {}

    @staticmethod
    def _normalize_report(item) -> dict:
        if isinstance(item, Mapping):
            return dict(item)
        to_dict = getattr(item, "to_dict", None)
        if callable(to_dict):
            return dict(to_dict())
        if hasattr(item, "__dataclass_fields__"):
            return asdict(item)
        return {"value": str(item)}

    def _party(self) -> dict:
        if self.party_status_provider is None:
            return {"ready": None, "status": "UNAVAILABLE"}
        try:
            return dict(self.party_status_provider())
        except Exception as exc:
            return {"ready": None, "status": "UNAVAILABLE", "error": f"{type(exc).__name__}: {exc}"}

    def _health(self, plan) -> tuple[dict, ...]:
        if self.health_provider is None:
            return ()
        try:
            return tuple(self._normalize_report(item) for item in (self.health_provider(plan) or ()))
        except Exception as exc:
            return ({"component": "snapshot_health", "ready": None, "status": "UNAVAILABLE", "error": f"{type(exc).__name__}: {exc}"},)

    def _problems(self, plan) -> tuple[dict, ...]:
        if self.problem_provider is None:
            return ()
        try:
            return tuple(self._normalize_report(item) for item in (self.problem_provider(plan) or ()))
        except Exception as exc:
            return ({"severity": "warning", "category": "snapshot", "title": "Problem projection unavailable", "detail": f"{type(exc).__name__}: {exc}"},)

    @staticmethod
    def _runtime_health(status, party: Mapping) -> dict:
        """Project the running mission into the same health stream as preflight.

        R5.106 only exposed startup readiness here, so a script could abort and
        the operator panel would remain green.  Mission lifecycle is now a
        first-class health component.
        """
        state = str(getattr(getattr(status, "state", None), "value", getattr(status, "state", "UNKNOWN")))
        mission = dict(party.get("mission") or {})
        shared = dict(party.get("shared_fight") or {})
        failure = mission.get("latest_failure") if isinstance(mission.get("latest_failure"), Mapping) else None
        phase = mission.get("phase") or ("FIGHT" if shared.get("fight_instance_id") is not None else "WORLD")
        started = mission.get("phase_started_monotonic")
        phase_age = None
        if started is not None:
            try:
                phase_age = round(max(0.0, time.monotonic() - float(started)), 3)
            except (TypeError, ValueError):
                phase_age = None
        base = {
            "component": "mission",
            "phase": phase,
            "phase_key": mission.get("phase_key"),
            "phase_age_seconds": phase_age,
            "fight_instance_id": shared.get("fight_instance_id"),
            "fight_status": shared.get("status"),
            "stop_reason": mission.get("stop_reason"),
        }
        if state == "FAILED":
            error = str(getattr(status, "error", None) or "MISSION_FAILED")
            return {**base, "ready": False, "status": "BLOCKED", "blockers": [error.split(":", 1)[0]], "detail": error}
        # The supervisor's terminal run state is authoritative for operator
        # health. A completed/stopped worker must never remain red because an
        # older mission snapshot still contains a transient blocker or stale
        # shared-fight frame from the final tick.
        if state == "COMPLETED":
            return {**base, "phase": "COMPLETED", "phase_key": mission.get("stop_reason"), "ready": True, "status": "COMPLETED", "blockers": []}
        if state == "STOPPED":
            return {**base, "phase": "STOPPED", "phase_key": mission.get("stop_reason"), "ready": True, "status": "STOPPED", "blockers": []}
        if failure:
            code = str(failure.get("failure_code") or failure.get("status") or "MISSION_RUNTIME_FAILURE")
            return {**base, "ready": False, "status": "BLOCKED", "blockers": [code], "detail": str(failure)}
        if str(shared.get("status") or "") == "CONFLICT":
            return {**base, "ready": False, "status": "BLOCKED", "blockers": ["SHARED_FIGHT_CONFLICT"], "detail": str(shared.get("detail") or "shared fight conflict")}
        return {**base, "ready": True, "status": "ACTIVE", "blockers": []}

    @staticmethod
    def _runtime_problems(status, party: Mapping) -> tuple[dict, ...]:
        state = str(getattr(getattr(status, "state", None), "value", getattr(status, "state", "UNKNOWN")))
        mission = dict(party.get("mission") or {})
        shared = dict(party.get("shared_fight") or {})
        problems: list[dict] = []
        # Terminal success owns the operator surface. Historical/transient
        # mission state remains available in diagnostics but is not an active
        # problem after the worker has completed or stopped normally.
        if state in {"COMPLETED", "STOPPED"}:
            return ()
        if state == "FAILED":
            error = str(getattr(status, "error", None) or "MISSION_FAILED")
            problems.append({
                "severity": "error",
                "category": "mission",
                "title": error.split(":", 1)[0],
                "detail": error,
                "hint": "The mission stopped fail-closed. Export diagnostics before restarting if this was a live run.",
            })
        failure = mission.get("latest_failure")
        if isinstance(failure, Mapping):
            code = str(failure.get("failure_code") or failure.get("status") or "MISSION_RUNTIME_FAILURE")
            if not any(item.get("title") == code for item in problems):
                problems.append({
                    "severity": "error",
                    "category": "mission",
                    "title": code,
                    "detail": json.dumps(dict(failure), sort_keys=True, default=str),
                    "hint": "The mission watchdog detected a terminal runtime blocker.",
                })
        if str(shared.get("status") or "") == "CONFLICT":
            problems.append({
                "severity": "error",
                "category": "fight",
                "title": "SHARED_FIGHT_CONFLICT",
                "detail": str(shared.get("detail") or "required party snapshots conflict"),
                "hint": "ANKA stopped before issuing unsafe fight actions; inspect the automatic incident bundle.",
            })
        return tuple(problems)

    @staticmethod
    def _operational(party: Mapping, status=None) -> dict:
        mission = dict(party.get("mission") or {})
        shared = dict(party.get("shared_fight") or {})
        current_operation = party.get("current_operation")
        run_state = str(getattr(getattr(status, "state", None), "value", getattr(status, "state", ""))) if status is not None else ""
        terminal = run_state in {"COMPLETED", "STOPPED", "FAILED"}
        phase = run_state if terminal else mission.get("phase")
        if phase is None:
            phase = "FIGHT" if shared.get("fight_instance_id") is not None else "WORLD"
        return {
            "phase": phase,
            "route_index": mission.get("route_index"),
            "wins": mission.get("wins"),
            "attempts": mission.get("attempts"),
            "fight_instance_id": None if terminal else shared.get("fight_instance_id"),
            "active_account_id": None if terminal else shared.get("active_account_id"),
            "fight_status": None if terminal else shared.get("status"),
            "current_operation": None if terminal else (dict(current_operation) if isinstance(current_operation, Mapping) else current_operation),
        }

    def snapshot(self, run_id: str) -> SessionSnapshot:
        token = str(run_id).strip()
        record = self.registry.get_run(token)
        status = self.supervisor.status(token)
        party = self._party()
        health = self._health(record.plan)
        health = (*health, self._runtime_health(status, party))
        problems = (*self._problems(record.plan), *self._runtime_problems(status, party))
        control = control_record_payload(record)
        session = session_plan_payload(record.plan)
        run = run_payload(status)
        operational = self._operational(party, status)
        body = {
            "control": control,
            "session": session,
            "run": run,
            "party": party,
            "health": health,
            "operational": operational,
            "problems": problems,
        }
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str)
        fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        with self._lock:
            previous = self._fingerprints.get(token)
            revision = self._revisions.get(token, 0)
            if previous != fingerprint:
                revision += 1
                self._fingerprints[token] = fingerprint
                self._revisions[token] = revision
            elif revision == 0:
                revision = 1
                self._revisions[token] = revision
        return SessionSnapshot(
            snapshot_revision=revision,
            control=control,
            session=session,
            run=run,
            party=party,
            health=health,
            operational=operational,
            problems=problems,
        )

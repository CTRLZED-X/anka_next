from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import os
from pathlib import Path

from anka_platform.capture.runtime import LiveTransportRuntime
from anka_platform.campaign.timing import derive_campaign_timing_budget
from anka_platform.capture.scapy_backend import ScapyCaptureBackend
from anka_platform.policy_composition import build_default_policy_registry
from anka_platform.fight_ai.telemetry import build_fight_decision_trace
from anka_platform.execution.coordinator import ExecutionCoordinator
from anka_platform.execution.service import ExecutionService
from anka_platform.execution.control_authority import ControlAuthorityStore
from anka_platform.execution.windows import DofusWindowInputDriver
from anka_platform.execution.window_control import WindowControlFacade
from anka_platform.observability.run_store import SessionRunRegistry
from anka_platform.party.coordinator import RunBudget
from anka_platform.party.mission import PartyMissionController
from anka_platform.scripting.host import ScriptRuntimeHost
from anka_platform.scripting.supervisor import ScriptSupervisor
from anka_platform.protocol.loader import load_protocol_adapter
from anka_platform.protocol.slots import protocol_spell_slot_index


@dataclass(slots=True)
class SingleAccountLiveStack:
    action_service: object | None
    action_handler: object | None
    capture_runtime: object | None
    capture_backend: object | None


@dataclass(slots=True)
class ScriptControlStack:
    policies: object
    mission: PartyMissionController | None
    runtime_host: ScriptRuntimeHost
    supervisor: ScriptSupervisor
    execution_coordinator: ExecutionCoordinator
    run_registry: SessionRunRegistry


def resolve_default_window_input(current_input, *, party_mode: bool):
    """Construct the default native window adapter outside the web layer."""
    if current_input is not None or party_mode or os.name != "nt":
        return current_input
    try:
        return DofusWindowInputDriver.native()
    except RuntimeError:
        return None


def build_single_account_live_stack(
    *,
    config,
    live_state,
    projection_service,
    input_driver,
    kernel,
    runtime_db: Path,
    observability,
    critical_debug_export,
    action_handler=None,
    action_service=None,
    capture_runtime=None,
    capture_backend=None,
    client_instance_id: str | None = None,
    control_authority: ControlAuthorityStore | None = None,
) -> SingleAccountLiveStack:
    """Build legacy/single-account infrastructure without leaking constructors into UI adapters."""
    resolved_service = action_service
    resolved_handler = action_handler
    resolved_capture = capture_runtime
    resolved_backend = capture_backend
    if resolved_handler is None and input_driver is not None:
        resolved_service = ExecutionService(
            live_state,
            projection_service,
            input_driver,
            kernel=kernel,
            calibration=config.calibration,
            timing=config.execution,
            execution_db_path=runtime_db,
            observability=observability,
            critical_debug_export=critical_debug_export,
            control_authority=control_authority,
            protocol_adapter_id=config.protocol.active_adapter,
        )
        resolved_handler = resolved_service.handle
    if resolved_capture is None:
        resolved_capture = LiveTransportRuntime(
            load_protocol_adapter(config.protocol.active_adapter),
            live_state,
            capture_id="live",
            client_instance_id=client_instance_id,
            observability=observability,
            critical_debug_export=critical_debug_export,
        )
    if resolved_backend is None and config.capture.enabled and hasattr(resolved_capture, "feed_segment"):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        resolved_backend = ScapyCaptureBackend(
            ports=config.capture.ports,
            interface=config.capture.interface,
            capture_path=config.capture.captures_directory / f"live_{stamp}.pcapng",
            on_segment=resolved_capture.feed_segment,
        )
    return SingleAccountLiveStack(
        action_service=resolved_service,
        action_handler=resolved_handler,
        capture_runtime=resolved_capture,
        capture_backend=resolved_backend,
    )


def build_script_control_stack(
    *,
    config,
    kernel,
    live_state,
    script_repository,
    party_registry,
    action_handler,
    action_service,
    client_instance_id: str | None,
    observability,
    critical_debug_export,
    success_debug_export=None,
) -> ScriptControlStack:
    """Composition root for mission/fight/script runtime objects used by UI/API adapters."""
    policies = build_default_policy_registry(kernel=kernel)
    mission = None
    if party_registry is not None:
        # Composition happens before a dynamic PartyRuntimeManager necessarily has
        # a live generation.  Timing defaults must therefore come from static
        # configuration, never from party_registry.lanes (which is live state).
        # The exact frozen SessionPlan count is applied again at Apply/Launch.
        configured_required_count = sum(
            1 for account in getattr(config.party, "accounts", ()) if bool(account.required)
        )
        required_count = max(1, configured_required_count)
        timing_budget = derive_campaign_timing_budget(
            config, required_account_count=required_count
        )
        mission = PartyMissionController(
            party_registry,
            kernel=kernel,
            phase_timeout_seconds=timing_budget.selected_phase_timeout_seconds,
            ready_ack_timeout_seconds=float(config.execution.profile("ready_fight").confirmation_timeout_seconds),
            # Live R5.127 evidence: first Ready at ~1.1-1.34 s after the final
            # placement action was ignored in 5/5 fights, while Ready at
            # ~2.0-2.31 s emitted the semantic request. Keep this generation-
            # scoped stabilization outside Execution so no account is singled out.
            ready_control_settle_seconds=config.reliability.ready_control_settle_seconds,
            ready_ui_quiescence_seconds=config.reliability.ready_ui_quiescence_seconds,
            ready_focus_stability_seconds=config.reliability.ready_focus_stability_seconds,
            ready_first_interaction_prime_seconds=config.reliability.ready_first_interaction_prime_seconds,
            ready_recovery_extra_attempts=config.reliability.ready_recovery_extra_attempts,
            ready_recovery_cooldown_seconds=config.reliability.ready_recovery_cooldown_seconds,
            ready_recovery_pointer_excursion_pixels=config.reliability.ready_recovery_pointer_excursion_pixels,
            run_budget=RunBudget(
                max_attempts=config.run_budget.max_attempts,
                target_wins=config.run_budget.target_wins,
                stop_on_loss=config.run_budget.stop_on_loss,
                stop_on_unknown=config.run_budget.stop_on_unknown,
            ),
        )
        mission.phase_timeout_basis = timing_budget.to_dict()
        mission.configure_phase_timeouts(timing_budget.phase_timeouts_seconds)
    run_registry = SessionRunRegistry()
    window_control = WindowControlFacade(party_registry) if party_registry is not None else None
    execution_coordinator = ExecutionCoordinator(
        party=party_registry, fallback_handler=action_handler, window_control=window_control,
    )
    runtime_host = ScriptRuntimeHost(
        kernel,
        live_state,
        action_handler=action_handler,
        decision_readiness=(action_service.decision_readiness if action_service is not None else None),
        party=party_registry,
        fight_ai=(config.fight_ai if config.party.enabled else None),
        decision_trace_builder=build_fight_decision_trace,
        mission=mission,
        policies=policies,
        execution_coordinator=execution_coordinator,
        run_registry=run_registry,
        spell_slot_resolver=protocol_spell_slot_index,
        world_reentry_stability_seconds=config.reliability.world_reentry_stability_seconds,
        world_reentry_timeout_seconds=config.reliability.world_reentry_timeout_seconds,
        live_truth_recovery_stability_seconds=config.reliability.live_truth_recovery_stability_seconds,
        live_truth_continuity_suspect_seconds=config.reliability.live_truth_continuity_suspect_seconds,
        ready_inbound_stall_suspect_seconds=config.reliability.ready_inbound_stall_suspect_seconds,
        pending_action_inbound_stall_suspect_seconds=config.reliability.pending_action_inbound_stall_suspect_seconds,
        live_truth_continuity_hold_timeout_seconds=config.reliability.live_truth_continuity_hold_timeout_seconds,
    )
    if party_registry is not None:
        try:
            lease_id = "party:" + ",".join(sorted(lane.identity.client_instance_id for lane in party_registry.lanes))
        except Exception:
            # Dynamic party registries intentionally exist before a live generation.
            lease_id = None
    else:
        lease_id = ((client_instance_id or "local-dofus-client") if action_handler is not None else None)
    supervisor = ScriptSupervisor(
        script_repository,
        config.scripting.runs_directory,
        request_handler=runtime_host.handle,
        execution_client_id=lease_id,
        observability=observability,
        critical_debug_export=critical_debug_export,
        success_debug_export=success_debug_export,
        request_timeout_seconds=config.reliability.script_rpc_timeout_seconds,
    )
    return ScriptControlStack(
        policies=policies,
        mission=mission,
        runtime_host=runtime_host,
        supervisor=supervisor,
        execution_coordinator=execution_coordinator,
        run_registry=run_registry,
    )

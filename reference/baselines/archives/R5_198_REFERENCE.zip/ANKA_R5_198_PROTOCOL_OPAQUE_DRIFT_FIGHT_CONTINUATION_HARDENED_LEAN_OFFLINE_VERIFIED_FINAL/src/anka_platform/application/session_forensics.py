from __future__ import annotations

import hashlib
import json
from pathlib import Path
from threading import RLock
from typing import Iterable, Mapping

from anka_platform.application.control_models import SessionControlRecord
from anka_platform.application.payloads import session_plan_payload
from anka_platform.core.session import SessionPlan
from anka_platform.observability.run_store import SessionRunRegistry, SessionRunStore
from anka_platform.scripting.events import ScriptTerminalEvent


class SessionForensicsFinalizer:
    """Owns per-session forensic store lifecycle independent of browser queries."""

    def __init__(
        self,
        runs_root: str | Path | None,
        *,
        run_registry: SessionRunRegistry | None = None,
    ) -> None:
        self.runs_root = Path(runs_root) if runs_root is not None else None
        self.run_registry = run_registry
        self._lock = RLock()
        self._stores_by_run: dict[str, object] = {}
        self._finished_runs: set[str] = set()
        self._finishing_runs: set[str] = set()
        self._health_fingerprints: dict[str, str] = {}

    def start(self, plan: SessionPlan) -> SessionRunStore | None:
        if self.runs_root is None:
            return None
        store = SessionRunStore(self.runs_root, plan.session_id)
        store.start(session_plan_payload(plan))
        store.append_event("session_plan_compiled", {"mission_id": plan.mission_id})
        if self.run_registry is not None:
            self.run_registry.register_session(plan.session_id, store)
        return store

    def bind_run(self, run_id: str, store: object | None, *, script_name: str) -> None:
        if store is None:
            return
        token = str(run_id).strip()
        if not token:
            raise ValueError("run_id must not be empty")
        with self._lock:
            self._stores_by_run[token] = store
        if self.run_registry is not None and isinstance(store, SessionRunStore):
            self.run_registry.register(token, store)
        append_event = getattr(store, "append_event", None)
        if callable(append_event):
            append_event("worker_started", {"run_id": token, "script_name": str(script_name)})

    def store_for(self, run_id: str) -> object | None:
        with self._lock:
            return self._stores_by_run.get(str(run_id).strip())

    def finish(self, *, record: SessionControlRecord, event: ScriptTerminalEvent) -> tuple[str, ...]:
        run_id = str(event.run_id)
        with self._lock:
            if run_id in self._finished_runs or run_id in self._finishing_runs:
                return ()
            store = self._stores_by_run.get(run_id)
            if store is None:
                return ()
            self._finishing_runs.add(run_id)
        errors: list[str] = []
        try:
            # R5.108: terminal worker failures belong in the durable failure
            # ledger, not only summary.json.  The incident exporter uses this
            # stream for root attribution; without it a normal runtime failure
            # was incorrectly defaulted to SESSION_LAUNCH_FAILED.
            if str(event.state.value).upper() == "FAILED":
                raw_error = str(event.error or "MISSION_FAILED")
                failure_code = raw_error.split(":", 1)[0].strip() or "MISSION_FAILED"
                append_failure = getattr(store, "append_failure", None)
                if callable(append_failure):
                    append_failure({
                        "failure_code": failure_code,
                        "detail": raw_error,
                        "stage": "MISSION_RUNTIME",
                        "run_id": run_id,
                        "script_name": event.script_name,
                    })
            store.finish({
                "status": event.state.value,
                "run_id": run_id,
                "script_name": event.script_name,
                "error": event.error,
                "mission_id": record.plan.mission_id,
            })
        except Exception as exc:
            errors.append(f"FORENSICS_FINISH_FAILED:{type(exc).__name__}:{exc}")
        finally:
            with self._lock:
                self._finishing_runs.discard(run_id)
                if not errors:
                    self._finished_runs.add(run_id)
        return tuple(errors)


    def fail_start(self, *, plan: SessionPlan, store: object | None, error: BaseException, stage: str | None = None) -> tuple[str, ...]:
        if store is None:
            return ()
        try:
            append_failure = getattr(store, "append_failure", None)
            if callable(append_failure):
                append_failure({
                    "failure_code": "SESSION_LAUNCH_FAILED",
                    "detail": f"{type(error).__name__}: {error}",
                    "stage": str(stage) if stage else None,
                })
            store.finish({
                "status": "FAILED_TO_START",
                "mission_id": plan.mission_id,
                "error": f"{type(error).__name__}: {error}",
            })
        except Exception as exc:
            return (f"FORENSICS_FAIL_START_FAILED:{type(exc).__name__}:{exc}",)
        return ()

    def record_health_if_changed(self, run_id: str, health: Iterable[Mapping]) -> bool:
        token = str(run_id).strip()
        payloads = tuple(dict(item) for item in health)
        canonical = json.dumps(payloads, sort_keys=True, separators=(",", ":"), default=str)
        fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        with self._lock:
            store = self._stores_by_run.get(token)
            if store is None:
                return False
            if self._health_fingerprints.get(token) == fingerprint:
                return False
            self._health_fingerprints[token] = fingerprint
        try:
            for payload in payloads:
                store.append_health(payload)
        except Exception:
            with self._lock:
                if self._health_fingerprints.get(token) == fingerprint:
                    self._health_fingerprints.pop(token, None)
            raise
        return True

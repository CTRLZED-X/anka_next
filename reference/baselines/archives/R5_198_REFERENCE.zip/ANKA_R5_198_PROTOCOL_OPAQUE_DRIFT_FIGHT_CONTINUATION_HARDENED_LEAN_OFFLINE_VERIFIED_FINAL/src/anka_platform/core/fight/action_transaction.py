from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Mapping


class ReconciliationPollState(StrEnum):
    """Controller-facing state of ExecutionService's passive reconciliation hook."""

    CLEAR = "CLEAR"
    WAITING = "WAITING"
    RECONCILED = "RECONCILED"
    AUTHORITY_MISMATCH = "AUTHORITY_MISMATCH"


@dataclass(frozen=True, slots=True)
class PendingCombatTransaction:
    """Turn-local projection of one execution-owned combat transaction.

    ExecutionService remains authoritative for durable physical uncertainty and
    settlement.  The combat controller stores only the minimum immutable context
    needed to apply turn-local consequences after ExecutionService closes that
    transaction.  Keeping this as one object avoids four independent fields that
    can drift apart during recovery/refactors.
    """

    action_key: tuple
    kind: str
    account_id: str | None = None
    origin_action_id: str | None = None
    fight_instance_id: int | None = None
    origin_cell_id: int | None = None
    target_cell_id: int | None = None

    @classmethod
    def from_execution(
        cls,
        *,
        action_key: tuple,
        kind: str,
        action_result: Mapping[str, object],
        account_id: str | None = None,
        fight_instance_id: int | None = None,
        origin_cell_id: int | None = None,
        target_cell_id: int | None = None,
    ) -> "PendingCombatTransaction":
        action_id = action_result.get("origin_action_id") or action_result.get("action_id")
        return cls(
            action_key=tuple(action_key),
            kind=str(kind or "").upper(),
            account_id=str(account_id) if account_id not in (None, "") else None,
            origin_action_id=str(action_id) if action_id not in (None, "") else None,
            fight_instance_id=(int(fight_instance_id) if fight_instance_id is not None else None),
            origin_cell_id=int(origin_cell_id) if origin_cell_id is not None else None,
            target_cell_id=int(target_cell_id) if target_cell_id is not None else None,
        )

    def matches_reconciliation(self, evidence: Mapping[str, object] | None) -> bool:
        """Require exact correlation for every transaction that has an action id.

        Pre-correlation historical fixtures can still create a transaction with no
        ``origin_action_id`` and remain compatible.  Once a current execution
        result exposes an action id, however, missing correlation is no longer
        evidence: the reconciliation must explicitly name that same action.
        """
        if self.origin_action_id is None:
            return True
        if not evidence:
            return False
        observed = evidence.get("origin_action_id") or evidence.get("observation_of_action_id")
        if observed in (None, "") or str(observed) != self.origin_action_id:
            return False
        if self.account_id is not None:
            observed_account = evidence.get("account_id")
            if observed_account in (None, "") or str(observed_account) != self.account_id:
                return False
        if self.fight_instance_id is not None:
            observed_fight = evidence.get("fight_instance_id")
            if observed_fight is None:
                return False
            try:
                if int(observed_fight) != int(self.fight_instance_id):
                    return False
            except (TypeError, ValueError):
                return False
        return True

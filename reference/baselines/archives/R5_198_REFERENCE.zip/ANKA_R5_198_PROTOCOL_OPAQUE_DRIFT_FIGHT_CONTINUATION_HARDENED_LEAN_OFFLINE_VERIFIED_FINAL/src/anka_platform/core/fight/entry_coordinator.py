from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Any

from anka_platform.party.shared_fight import SharedFightStatus


@dataclass(frozen=True, slots=True)
class FightEntrySnapshot:
    phase: str
    fight_instance_id: int | None
    required_accounts: tuple[str, ...]
    present_accounts: tuple[str, ...]
    missing_accounts: tuple[str, ...]
    accounts: dict[str, dict]
    launch_reference_ready: bool
    launch_transition_pending: bool
    preparation_stage: str | None
    shared_status: str
    active_actor_id: int | None

    def to_dict(self) -> dict:
        return {
            "phase": self.phase,
            "fight_instance_id": self.fight_instance_id,
            "required_accounts": list(self.required_accounts),
            "present_accounts": list(self.present_accounts),
            "missing_accounts": list(self.missing_accounts),
            "accounts": {key: dict(value) for key, value in self.accounts.items()},
            "launch_reference_ready": self.launch_reference_ready,
            "launch_transition_pending": self.launch_transition_pending,
            "preparation_stage": self.preparation_stage,
            "shared_status": self.shared_status,
            "active_actor_id": self.active_actor_id,
        }


class FightEntryCoordinator:
    """One diagnostic/control-plane view of leader entry -> party Active.

    The coordinator does not duplicate physical mechanics. PartyMissionController
    remains the owner of launch receipts, follower joining, placement and Ready;
    FightWorkflow remains the lifecycle owner. This class turns those independent
    pieces of evidence into one generation-scoped phase model so the parent and
    debug bundle can identify the first missing party boundary unambiguously.
    """

    def __init__(self, mission, *, clock=time.monotonic, history_limit: int = 128) -> None:
        self.mission = mission
        self._clock = clock
        self._history_limit = max(16, int(history_limit))
        self._sequence = 0
        self._last: FightEntrySnapshot | None = None
        self._history: list[dict] = []

    def reset(self) -> None:
        self._sequence = 0
        self._last = None
        self._history.clear()

    def last(self) -> dict | None:
        return None if self._last is None else self._last.to_dict()

    def history(self) -> list[dict]:
        return [dict(item) for item in self._history]

    @staticmethod
    def _signature(snapshot: FightEntrySnapshot) -> tuple:
        return (
            snapshot.phase,
            snapshot.fight_instance_id,
            snapshot.present_accounts,
            snapshot.missing_accounts,
            snapshot.launch_reference_ready,
            snapshot.launch_transition_pending,
            snapshot.preparation_stage,
            snapshot.shared_status,
            snapshot.active_actor_id,
            tuple(
                (
                    account,
                    str(details.get("phase") or ""),
                    details.get("placement_cell_id"),
                    tuple(details.get("missing_fields") or ()),
                    details.get("local_actor_id"),
                    details.get("local_actor_source"),
                )
                for account, details in sorted(snapshot.accounts.items())
            ),
        )

    def _record(self, snapshot: FightEntrySnapshot) -> None:
        previous = self._last
        if previous is not None and self._signature(previous) == self._signature(snapshot):
            return
        self._sequence += 1
        row = {
            "sequence": self._sequence,
            "observed_monotonic": float(self._clock()),
            **snapshot.to_dict(),
        }
        self._history.append(row)
        if len(self._history) > self._history_limit:
            del self._history[:-self._history_limit]

    def _mission_status(self) -> dict[str, Any]:
        status = getattr(self.mission, "status", None)
        if not callable(status):
            return {}
        try:
            raw = status()
        except Exception:
            return {}
        return dict(raw) if isinstance(raw, dict) else {}

    @staticmethod
    def _ready_phase(ready: dict) -> str | None:
        status = str(ready.get("last_status") or "").upper()
        if status in {"CONFIRMED", "SETTLED"} or ready.get("confirmed_revision") is not None:
            return "READY_CONFIRMED"
        if int(ready.get("count") or 0) > 0:
            if ready.get("semantic_request_observed") is True:
                return "READY_ACK_PENDING"
            if ready.get("retry_allowed") is True:
                return "READY_RETRY_PROBE_PENDING"
            return "READY_SETTLING"
        return None

    def capture(self, view) -> FightEntrySnapshot:
        mission = self._mission_status()
        preparation = mission.get("preparation") if isinstance(mission.get("preparation"), dict) else {}
        prep_stage = str(preparation.get("stage") or "").strip() or None
        ready_attempts = preparation.get("ready_attempts") if isinstance(preparation.get("ready_attempts"), dict) else {}
        placement_cells = preparation.get("placement_cells") if isinstance(preparation.get("placement_cells"), dict) else {}
        launch_reference = mission.get("active_launch_reference") if isinstance(mission.get("active_launch_reference"), dict) else None
        launch_pending = bool(mission.get("launch_transition_pending"))

        required = tuple(str(item) for item in getattr(view, "required_accounts", ()) or ())
        present = tuple(str(item) for item in getattr(view, "present_accounts", ()) or ())
        present_set = set(present)
        missing = tuple(account for account in required if account not in present_set)
        shared_status_obj = getattr(view, "status", SharedFightStatus.NO_FIGHT)
        shared_status = getattr(shared_status_obj, "value", str(shared_status_obj))
        fight_instance_id = getattr(view, "fight_instance_id", None)
        active_actor_id = getattr(view, "active_actor_id", None)

        if shared_status_obj is SharedFightStatus.NO_FIGHT:
            phase = "LEADER_ENTRY_PENDING" if launch_pending else "NO_FIGHT"
        elif shared_status_obj is SharedFightStatus.CONFLICT:
            phase = "PARTY_FIGHT_CONFLICT"
        elif missing:
            phase = "PARTY_JOINING" if launch_reference is not None else "CAUSAL_FIGHT_RECEIPT_PENDING"
        elif shared_status_obj is SharedFightStatus.PARTIAL:
            phase = "PARTY_FIGHT_CONVERGENCE"
        elif prep_stage is None:
            phase = "ENTRY_BARRIER"
        elif prep_stage.startswith("PLACEMENT"):
            phase = "PLACEMENT"
        elif prep_stage.startswith("READY"):
            phase = "READY_BARRIER"
        elif prep_stage == "COMPLETE":
            # Preparation completeness is the generation-scoped authority for
            # combat handoff. active_actor_id may legitimately be unknown during
            # a turn handoff, so do not relabel that transient as Ready again.
            phase = "FIGHT_ACTIVE"
        elif prep_stage.startswith("CHALLENGE"):
            phase = "CHALLENGE_OBSERVATION"
        else:
            phase = "ENTRY_BARRIER"

        accounts: dict[str, dict] = {}
        roles = dict(getattr(view, "account_roles", {}) or {})
        revisions = dict(getattr(view, "account_revisions", {}) or {})
        missing_fields = dict(getattr(view, "missing_fields", {}) or {})
        local_actor_ids = dict(getattr(view, "local_actor_ids", {}) or {})
        local_actor_sources = dict(getattr(view, "local_actor_sources", {}) or {})
        for account in required:
            if account not in present_set:
                account_phase = "JOIN_PENDING"
            else:
                account_phase = "FIGHT_PRESENT"
                if account in placement_cells:
                    account_phase = "PLACEMENT_CONFIRMED"
                ready = ready_attempts.get(account) if isinstance(ready_attempts.get(account), dict) else {}
                ready_phase = self._ready_phase(ready)
                if ready_phase is not None:
                    account_phase = ready_phase
                if prep_stage == "COMPLETE":
                    account_phase = "ACTIVE_ELIGIBLE"
            accounts[account] = {
                "phase": account_phase,
                "present": account in present_set,
                "role": roles.get(account),
                "revision": revisions.get(account),
                "missing_fields": list(missing_fields.get(account) or ()),
                "local_actor_id": local_actor_ids.get(account),
                "local_actor_source": local_actor_sources.get(account),
                "placement_cell_id": placement_cells.get(account),
                "ready_attempt": dict(ready_attempts.get(account) or {}) if isinstance(ready_attempts.get(account), dict) else None,
            }

        snapshot = FightEntrySnapshot(
            phase=phase,
            fight_instance_id=(int(fight_instance_id) if fight_instance_id is not None else None),
            required_accounts=required,
            present_accounts=present,
            missing_accounts=missing,
            accounts=accounts,
            launch_reference_ready=launch_reference is not None,
            launch_transition_pending=launch_pending,
            preparation_stage=prep_stage,
            shared_status=str(shared_status),
            active_actor_id=(int(active_actor_id) if active_actor_id is not None else None),
        )
        self._record(snapshot)
        self._last = snapshot
        return snapshot

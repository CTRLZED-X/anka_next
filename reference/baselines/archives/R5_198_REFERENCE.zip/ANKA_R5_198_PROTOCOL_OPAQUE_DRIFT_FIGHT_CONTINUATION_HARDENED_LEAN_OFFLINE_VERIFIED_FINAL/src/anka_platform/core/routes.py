from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable


class RouteDirection(str, Enum):
    """Operator-facing cardinal route intent.

    The platform deliberately uses UP/DOWN at the mission/UI boundary and maps
    them to the Kernel's TOP/BOTTOM vocabulary only at the world-topology seam.
    """

    UP = "UP"
    RIGHT = "RIGHT"
    DOWN = "DOWN"
    LEFT = "LEFT"

    @property
    def short(self) -> str:
        return {self.UP: "U", self.RIGHT: "R", self.DOWN: "D", self.LEFT: "L"}[self]

    @property
    def kernel_name(self) -> str:
        return {self.UP: "TOP", self.RIGHT: "RIGHT", self.DOWN: "BOTTOM", self.LEFT: "LEFT"}[self]

    @property
    def delta(self) -> tuple[int, int]:
        return {
            self.UP: (0, -1),
            self.RIGHT: (1, 0),
            self.DOWN: (0, 1),
            self.LEFT: (-1, 0),
        }[self]

    @classmethod
    def parse(cls, value: object) -> "RouteDirection":
        if isinstance(value, cls):
            return value
        token = str(value or "").strip().upper()
        aliases = {
            "U": cls.UP,
            "UP": cls.UP,
            "TOP": cls.UP,
            "R": cls.RIGHT,
            "RIGHT": cls.RIGHT,
            "D": cls.DOWN,
            "DOWN": cls.DOWN,
            "BOTTOM": cls.DOWN,
            "L": cls.LEFT,
            "LEFT": cls.LEFT,
        }
        try:
            return aliases[token]
        except KeyError as exc:
            raise ValueError(f"invalid route direction {value!r}; expected R/L/U/D") from exc


def normalize_route_directions(values: object) -> tuple[RouteDirection, ...]:
    """Normalize whitespace/comma separated text or an iterable of tokens."""
    if values is None:
        return ()
    if isinstance(values, str):
        tokens = values.replace(",", " ").split()
    else:
        try:
            tokens = list(values)  # type: ignore[arg-type]
        except TypeError as exc:
            raise ValueError("route_directions must be text or a sequence") from exc
    return tuple(RouteDirection.parse(token) for token in tokens)


def normalize_coordinate(value: object, *, field_name: str = "route_start") -> tuple[int, int]:
    try:
        x, y = value  # type: ignore[misc]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must contain exactly x,y") from exc
    if isinstance(x, bool) or isinstance(y, bool):
        raise ValueError(f"{field_name} coordinates must be integers")
    try:
        nx, ny = int(x), int(y)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} coordinates must be integers") from exc
    # Do not silently truncate floats such as 7.5.
    if str(x).strip() not in {str(nx), f"+{nx}"} and not isinstance(x, int):
        raise ValueError(f"{field_name}.x must be an integer")
    if str(y).strip() not in {str(ny), f"+{ny}"} and not isinstance(y, int):
        raise ValueError(f"{field_name}.y must be an integer")
    return nx, ny


def route_positions(
    start: tuple[int, int], directions: Iterable[RouteDirection | str]
) -> tuple[tuple[int, int], ...]:
    """Return start plus every destination coordinate (N directions => N+1 points)."""
    x, y = normalize_coordinate(start)
    result: list[tuple[int, int]] = [(x, y)]
    for raw in directions:
        direction = RouteDirection.parse(raw)
        dx, dy = direction.delta
        x += dx
        y += dy
        result.append((x, y))
    return tuple(result)


def route_source_coordinates(
    start: tuple[int, int], directions: Iterable[RouteDirection | str]
) -> tuple[tuple[int, int], ...]:
    """Compatibility view: one source coordinate per directional edge."""
    positions = route_positions(start, directions)
    return positions[:-1]


def require_closed_cycle(start: tuple[int, int], directions: Iterable[RouteDirection | str]) -> None:
    directions = tuple(RouteDirection.parse(item) for item in directions)
    if not directions:
        raise ValueError("route cycle requires at least one direction")
    positions = route_positions(start, directions)
    if positions[-1] != positions[0]:
        raise ValueError(
            f"route cycle must return to its starting map: start={positions[0]} end={positions[-1]}"
        )


@dataclass(frozen=True, slots=True)
class CertifiedRouteEdge:
    index: int
    direction: RouteDirection
    source_coordinate: tuple[int, int]
    target_coordinate: tuple[int, int]
    source_map_id: int
    target_map_id: int

    def to_dict(self) -> dict:
        return {
            "index": int(self.index),
            "direction": self.direction.value,
            "short_direction": self.direction.short,
            "source_coordinate": list(self.source_coordinate),
            "target_coordinate": list(self.target_coordinate),
            "source_map_id": int(self.source_map_id),
            "target_map_id": int(self.target_map_id),
        }


@dataclass(frozen=True, slots=True)
class CertifiedDirectionalRoute:
    start_coordinate: tuple[int, int]
    directions: tuple[RouteDirection, ...]
    edges: tuple[CertifiedRouteEdge, ...]
    loop: bool

    @property
    def anchor_map_id(self) -> int:
        if not self.edges:
            raise ValueError("directional route has no edges")
        return int(self.edges[0].source_map_id)

    @property
    def map_ids(self) -> tuple[int, ...]:
        return tuple(int(edge.source_map_id) for edge in self.edges)

    @property
    def source_coordinates(self) -> tuple[tuple[int, int], ...]:
        return tuple(edge.source_coordinate for edge in self.edges)

    @property
    def terminal_coordinate(self) -> tuple[int, int]:
        return self.edges[-1].target_coordinate if self.edges else self.start_coordinate

    def to_dict(self) -> dict:
        return {
            "model": "DIRECTIONAL",
            "start_coordinate": list(self.start_coordinate),
            "directions": [item.value for item in self.directions],
            "short_directions": [item.short for item in self.directions],
            "loop": bool(self.loop),
            "closed": self.terminal_coordinate == self.start_coordinate,
            "terminal_coordinate": list(self.terminal_coordinate),
            "edges": [edge.to_dict() for edge in self.edges],
        }

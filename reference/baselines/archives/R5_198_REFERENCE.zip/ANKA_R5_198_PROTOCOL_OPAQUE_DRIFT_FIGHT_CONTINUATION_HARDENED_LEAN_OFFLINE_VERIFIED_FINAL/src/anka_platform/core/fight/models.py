from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class FightWorkflowState(str, Enum):
    NO_FIGHT = "NO_FIGHT"
    ACQUIRE = "ACQUIRE"
    ENTRY_BARRIER = "ENTRY_BARRIER"
    JOINING = "JOINING"
    CHALLENGE = "CHALLENGE"
    PLACEMENT = "PLACEMENT"
    READY = "READY"
    ACTIVE = "ACTIVE"
    TERMINAL_DETECTED = "TERMINAL_DETECTED"
    POST_FIGHT_SETTLEMENT = "POST_FIGHT_SETTLEMENT"
    COMPLETE = "COMPLETE"
    FAILED = "FAILED"


@dataclass(frozen=True, slots=True)
class FightWorkflowResult:
    state: FightWorkflowState
    action: dict = field(default_factory=dict)
    reason: str = ""
    progress_token: str | None = None
    account_id: str | None = None
    next_allowed_commands: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return {
            "state": self.state.value,
            "action": dict(self.action),
            "reason": self.reason,
            "progress_token": self.progress_token,
            "account_id": self.account_id,
            "next_allowed_commands": list(self.next_allowed_commands),
        }

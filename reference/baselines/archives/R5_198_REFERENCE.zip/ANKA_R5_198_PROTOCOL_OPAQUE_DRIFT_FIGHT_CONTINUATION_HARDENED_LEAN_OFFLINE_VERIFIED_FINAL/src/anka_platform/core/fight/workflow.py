from __future__ import annotations

import time
from typing import Callable

from anka_platform.core.fight.models import FightWorkflowResult, FightWorkflowState
from anka_platform.core.fight.entry_coordinator import FightEntryCoordinator
from anka_platform.core.fight.lifecycle import (
    FightWorkflowLifecycleMemory, FightGenerationLifecycleStatus, FightPartialClassification,
)
from anka_platform.party.shared_fight import SharedFightStatus


_PREPARATION_STAGE_TO_STATE = {
    "ENTRY_BARRIER": FightWorkflowState.ENTRY_BARRIER,
    "CHALLENGE": FightWorkflowState.CHALLENGE,
    "CHALLENGE_BLOCKED": FightWorkflowState.CHALLENGE,
    "PLACEMENT": FightWorkflowState.PLACEMENT,
    "PLACEMENT_BLOCKED": FightWorkflowState.PLACEMENT,
    "READY_WINDOW_ARMING": FightWorkflowState.READY,
    "READY_SEND": FightWorkflowState.READY,
    "READY_BARRIER": FightWorkflowState.READY,
    "READY_CONVERGENCE": FightWorkflowState.READY,
    "READY_BLOCKED": FightWorkflowState.READY,
    # COMPLETE means preparation input/confirmation finished. Re-observe the
    # canonical fight before permitting a combat action; do not relabel a Ready
    # confirmation as a combat step.
    "COMPLETE": FightWorkflowState.READY,
}


class FightWorkflow:
    """Explicit party fight lifecycle above the existing proven mechanics.

    The workflow owns state classification and delegates physical mechanics to
    PartyMissionController / PartyCombatController.  This allows a safe staged
    migration: lifecycle is centralized without rewriting execution semantics.
    """

    def __init__(
        self,
        *,
        view_provider: Callable[[], object],
        mission,
        combat,
        preparation_required_provider: Callable[[], bool] | None = None,
        clock: Callable[[], float] = time.monotonic,
        local_roster_convergence_seconds: float = 1.5,
    ) -> None:
        self._view_provider = view_provider
        self.mission = mission
        self.combat = combat
        self._preparation_required_provider = preparation_required_provider or (lambda: True)
        self._clock = clock
        self._local_roster_convergence_seconds = max(0.0, float(local_roster_convergence_seconds))
        self._lifecycle_memory = FightWorkflowLifecycleMemory()
        self._seen_fight = False
        self._terminal_reported = False
        self._last_fight_instance_id: int | None = None
        self._converged_fight_instance_id: int | None = None
        # Preparation -> ACTIVE is a one-way transition for one exact fight
        # generation. Required clients do not receive turn packets atomically;
        # normal handoff skew must therefore never reopen placement/Ready.
        self._active_fight_instance_id: int | None = None
        self._local_roster_conflict_key: tuple | None = None
        self._local_roster_conflict_started: float | None = None
        self._last_view = None
        self._entry_coordinator = FightEntryCoordinator(mission)

    # Historical/private names remain as forwarding properties so old release
    # characterization tests and diagnostics keep working while one object owns
    # the mutable lifecycle history.
    @property
    def _seen_fight(self) -> bool:
        return self._lifecycle_memory.seen_fight

    @_seen_fight.setter
    def _seen_fight(self, value: bool) -> None:
        self._lifecycle_memory.seen_fight = bool(value)

    @property
    def _terminal_reported(self) -> bool:
        return self._lifecycle_memory.terminal_reported

    @_terminal_reported.setter
    def _terminal_reported(self, value: bool) -> None:
        self._lifecycle_memory.terminal_reported = bool(value)

    @property
    def _last_fight_instance_id(self) -> int | None:
        return self._lifecycle_memory.last_fight_instance_id

    @_last_fight_instance_id.setter
    def _last_fight_instance_id(self, value: int | None) -> None:
        self._lifecycle_memory.last_fight_instance_id = None if value is None else int(value)

    @property
    def _converged_fight_instance_id(self) -> int | None:
        return self._lifecycle_memory.converged_fight_instance_id

    @_converged_fight_instance_id.setter
    def _converged_fight_instance_id(self, value: int | None) -> None:
        self._lifecycle_memory.converged_fight_instance_id = None if value is None else int(value)

    @property
    def _active_fight_instance_id(self) -> int | None:
        return self._lifecycle_memory.active_fight_instance_id

    @_active_fight_instance_id.setter
    def _active_fight_instance_id(self, value: int | None) -> None:
        self._lifecycle_memory.active_fight_instance_id = None if value is None else int(value)

    def reset(self) -> None:
        self._lifecycle_memory.reset()
        self._local_roster_conflict_key = None
        self._local_roster_conflict_started = None
        self._last_view = None
        self._entry_coordinator.reset()

    @staticmethod
    def _only_local_roster_conflicts(view) -> bool:
        conflicts = tuple(getattr(view, "conflicting_fields", ()) or ())
        return bool(conflicts) and all(str(item).startswith("local_actor_roster:") for item in conflicts)

    def _entry_roster_convergence(self, view) -> FightWorkflowResult | None:
        """Temporarily quarantine a post-join local-roster mismatch.

        A follower can be physically accepted into the fight before all placement
        occupancy snapshots have converged.  R5.106 converted that short-lived
        state into a fatal identity error within milliseconds.  We still fail
        closed, but no preparation/combat input is allowed while the mismatch is
        in this bounded convergence grace.  If it remains authoritative past the
        grace, the ordinary SHARED_FIGHT_CONFLICT path fires.
        """
        if (
            view.status is not SharedFightStatus.CONFLICT
            or view.active_actor_id is not None
            or not self._only_local_roster_conflicts(view)
        ):
            self._local_roster_conflict_key = None
            self._local_roster_conflict_started = None
            return None

        key = (view.fight_instance_id, tuple(view.conflicting_fields))
        now = float(self._clock())
        if key != self._local_roster_conflict_key or self._local_roster_conflict_started is None:
            self._local_roster_conflict_key = key
            self._local_roster_conflict_started = now
        elapsed = max(0.0, now - float(self._local_roster_conflict_started))
        if elapsed >= self._local_roster_convergence_seconds:
            return None

        return FightWorkflowResult(
            FightWorkflowState.ENTRY_BARRIER,
            {
                "status": "IN_PROGRESS",
                "stage": "ENTRY_BARRIER",
                "reason": "LOCAL_ROSTER_CONVERGING",
                "detail": view.detail,
                "elapsed_seconds": elapsed,
                "grace_seconds": self._local_roster_convergence_seconds,
                "shared_fight": view.to_dict(),
            },
            reason="LOCAL_ROSTER_CONVERGING",
            next_allowed_commands=("OBSERVE_FIGHT",),
        )

    @staticmethod
    def _join_missing(view) -> tuple[str, ...]:
        present = set(view.present_accounts)
        return tuple(account for account in view.required_accounts if account not in present)

    def _preparation_complete_for(self, fight_instance_id: int | None) -> bool:
        """Read the exact-generation preparation proof without re-observing fight state.

        Production PartyMissionController exposes ``preparation_complete_for``.
        The legacy boolean provider remains as a compatibility seam for narrow
        tests/older integrations, but the workflow no longer asks that provider
        to build another SharedFightView during the same lifecycle decision.
        """
        exact = getattr(self.mission, "preparation_complete_for", None)
        if callable(exact):
            return bool(exact(fight_instance_id))
        return not bool(self._preparation_required_provider())

    def lifecycle_generation_status(self, fight_instance_id: int | None) -> FightGenerationLifecycleStatus:
        """Authoritative historical classification for one exact fight generation.

        Current-state projection still belongs to SharedFightManager. This typed
        result owns the monotonic history needed to distinguish PARTIAL entry
        convergence from ACTIVE/exit settlement. Parent campaign orchestration
        consumes this contract directly and must not re-infer the transition.
        """
        if fight_instance_id is None:
            return FightGenerationLifecycleStatus(
                fight_instance_id=None,
                preparation_complete=False,
                active_latched=False,
                post_entry_authorized=False,
                partial_classification=FightPartialClassification.ENTRY_JOINING,
            )
        fight_id = int(fight_instance_id)
        preparation_complete = self._preparation_complete_for(fight_id)
        active_latched = (
            self._active_fight_instance_id is not None
            and int(self._active_fight_instance_id) == fight_id
        )
        post_entry = bool(preparation_complete or active_latched)
        return FightGenerationLifecycleStatus(
            fight_instance_id=fight_id,
            preparation_complete=bool(preparation_complete),
            active_latched=bool(active_latched),
            post_entry_authorized=post_entry,
            partial_classification=(
                FightPartialClassification.EXIT_SETTLING
                if post_entry else FightPartialClassification.ENTRY_JOINING
            ),
        )

    def classify_partial_generation(self, fight_instance_id: int | None) -> str:
        return self.lifecycle_generation_status(fight_instance_id).partial_classification.value

    def _active_wait(self, view, *, reason: str, detail: str | None = None) -> FightWorkflowResult:
        action = {
            "status": "WAIT",
            "reason": str(reason),
            "fight_instance_id": view.fight_instance_id,
            "shared_fight": view.to_dict(),
        }
        if detail:
            action["detail"] = str(detail)
        return FightWorkflowResult(
            FightWorkflowState.ACTIVE,
            action,
            reason=str(reason),
            # Observation only. In particular, do not call combat from a PARTIAL
            # frame and let it reinterpret a newer frame in the same parent step.
            next_allowed_commands=("OBSERVE_FIGHT",),
        )

    def _decorate(self, result: FightWorkflowResult) -> FightWorkflowResult:
        if self._last_view is None:
            return result
        entry = self._entry_coordinator.capture(self._last_view).to_dict()
        return FightWorkflowResult(
            result.state,
            {**dict(result.action), "fight_entry": entry},
            reason=result.reason,
            progress_token=result.progress_token,
            account_id=result.account_id,
            next_allowed_commands=result.next_allowed_commands,
        )

    def last_entry_status(self) -> dict | None:
        return self._entry_coordinator.last()

    def entry_trace(self) -> list[dict]:
        return self._entry_coordinator.history()

    def inspect(self) -> FightWorkflowResult:
        view = self._view_provider()
        self._last_view = view
        if view.status is SharedFightStatus.NO_FIGHT:
            if self._seen_fight and not self._terminal_reported:
                self._terminal_reported = True
                return FightWorkflowResult(
                    FightWorkflowState.TERMINAL_DETECTED,
                    {"status": "TERMINAL_DETECTED", "fight_instance_id": self._last_fight_instance_id},
                    reason="REQUIRED_PARTY_LEFT_FIGHT",
                    next_allowed_commands=("SETTLE", "RECORD_OUTCOME"),
                )
            return FightWorkflowResult(
                FightWorkflowState.NO_FIGHT,
                {"status": "WAIT", "reason": "NO_FIGHT"},
                reason="NO_FIGHT",
                next_allowed_commands=("ACQUIRE_FIGHT",),
            )

        self._seen_fight = True
        if view.fight_instance_id is not None:
            observed_instance = int(view.fight_instance_id)
            if self._lifecycle_memory.observe_generation(observed_instance):
                # A terminal report is generation-scoped. The historical worker
                # kept an independent fight edge tracker, which masked this latch
                # remaining true after fight #1. Once lifecycle ownership moves
                # into the parent, every new exact fight generation must reopen
                # terminal detection deterministically.
                self._local_roster_conflict_key = None
                self._local_roster_conflict_started = None

        convergence = self._entry_roster_convergence(view)
        if convergence is not None:
            return convergence

        if view.status is SharedFightStatus.CONFLICT:
            return FightWorkflowResult(
                FightWorkflowState.FAILED,
                {"status": "BLOCKED", "reason": "SHARED_FIGHT_CONFLICT", "detail": view.detail},
                reason="SHARED_FIGHT_CONFLICT",
            )

        if view.status is SharedFightStatus.CONSISTENT:
            required = set(view.required_accounts)
            present = set(view.present_accounts)
            if required and required.issubset(present) and view.fight_instance_id is not None:
                self._converged_fight_instance_id = int(view.fight_instance_id)

        missing = self._join_missing(view)
        if missing:
            # SharedFightManager intentionally withholds a resolved shared
            # fight_instance_id whenever a required lane is absent. Therefore
            # the *current* partial view cannot distinguish entry from exit. The
            # monotonic ACTIVE generation latch is the authoritative history:
            # after ACTIVE, any required-party disappearance is observation-only
            # terminal settlement until the generation disappears everywhere or
            # the shared view reconverges.
            if self._active_fight_instance_id is not None:
                return FightWorkflowResult(
                    FightWorkflowState.POST_FIGHT_SETTLEMENT,
                    {
                        "status": "WAIT",
                        "reason": "REQUIRED_PARTY_EXIT_SETTLING",
                        "fight_instance_id": int(self._active_fight_instance_id),
                        "current_shared_fight_instance_id": view.fight_instance_id,
                        "present_accounts": list(view.present_accounts),
                        "missing_accounts": list(missing),
                        "physical_input_sent": False,
                    },
                    reason="REQUIRED_PARTY_EXIT_SETTLING",
                    next_allowed_commands=("OBSERVE_FIGHT",),
                )
            return FightWorkflowResult(
                FightWorkflowState.JOINING,
                {"status": "WAIT", "reason": "JOIN_REQUIRED", "accounts": list(missing)},
                reason="JOIN_REQUIRED",
                next_allowed_commands=("JOIN_FIGHT",),
            )

        preparation_complete = self._preparation_complete_for(view.fight_instance_id)
        active_latched = (
            self._active_fight_instance_id is not None
            and view.fight_instance_id is not None
            and int(self._active_fight_instance_id) == int(view.fight_instance_id)
        )

        # R5.126: volatile turn fields are expected to be temporarily PARTIAL as
        # one client observes TURN_ENDED before the other observes TURN_STARTED.
        # Once preparation was completed (or ACTIVE was already authorized), the
        # lifecycle is monotonic for that exact generation. Stay in ACTIVE and
        # observe only until the shared turn frame converges; never reopen prep.
        if view.status is SharedFightStatus.PARTIAL and (preparation_complete or active_latched):
            if view.fight_instance_id is not None:
                self._active_fight_instance_id = int(view.fight_instance_id)
            return self._active_wait(
                view,
                reason="ACTIVE_SHARED_FIGHT_CONVERGING",
                detail="active fight generation is waiting for required account turn-stream convergence",
            )

        # If the exact fight id itself is temporarily unavailable after ACTIVE,
        # keep the lifecycle latched but prohibit physical input until identity
        # converges again. This is safer than falling back into preparation.
        if (
            view.status is SharedFightStatus.PARTIAL
            and self._active_fight_instance_id is not None
            and set(view.required_accounts).issubset(set(view.present_accounts))
        ):
            return self._active_wait(
                view,
                reason="ACTIVE_FIGHT_IDENTITY_CONVERGING",
                detail="active lifecycle is latched; exact shared fight identity is temporarily incomplete",
            )

        # Before ACTIVE authorization, PARTIAL means the entry barrier has not
        # converged. Calling preparation here would cause a TOCTOU re-read and
        # could issue prep input against a different/newer frame.
        if view.status is SharedFightStatus.PARTIAL:
            return FightWorkflowResult(
                FightWorkflowState.ENTRY_BARRIER,
                {
                    "status": "WAIT",
                    "stage": "ENTRY_BARRIER",
                    "reason": "SHARED_FIGHT_NOT_CONVERGED",
                    "fight_instance_id": view.fight_instance_id,
                    "shared_fight": view.to_dict(),
                },
                reason="SHARED_FIGHT_NOT_CONVERGED",
                next_allowed_commands=("OBSERVE_FIGHT",),
            )

        if view.status is SharedFightStatus.CONSISTENT and (preparation_complete or active_latched):
            if view.fight_instance_id is not None:
                self._active_fight_instance_id = int(view.fight_instance_id)
            reason = "ACTIVE_TURN_AVAILABLE" if view.active_actor_id is not None else "TURN_HANDOFF_ACTIVE_PHASE"
            action = {
                "status": "READY",
                "reason": reason,
                "fight_instance_id": view.fight_instance_id,
                "lifecycle_evidence": {
                    "shared_fight_status": view.status.value,
                    "preparation_complete": bool(preparation_complete),
                    "active_latched": bool(active_latched),
                    "round": view.round,
                    "turn_index": view.turn_index,
                    "active_actor_id": view.active_actor_id,
                    "skewed_fields": list(view.skewed_fields),
                    "missing_fields": {
                        str(account): list(fields)
                        for account, fields in dict(view.missing_fields or {}).items()
                    },
                },
            }
            if active_latched and not preparation_complete:
                # Defense in depth: if a future mission-state bug loses its
                # COMPLETE marker, an already-authorized exact generation still
                # cannot regress to prep. Surface the invariant explicitly.
                action.update({
                    "lifecycle_invariant": "PREPARATION_COMPLETION_REGRESSION_BLOCKED",
                    "preparation_complete": False,
                })
            return FightWorkflowResult(
                FightWorkflowState.ACTIVE,
                action,
                reason=reason,
                next_allowed_commands=("COMBAT_STEP",),
            )

        return FightWorkflowResult(
            FightWorkflowState.ENTRY_BARRIER,
            {"status": "READY", "reason": "PREPARATION_REQUIRED"},
            reason="PREPARATION_REQUIRED",
            next_allowed_commands=("PREPARE_FIGHT",),
        )

    def advance(self, *, runtime_context: dict | None = None) -> FightWorkflowResult:
        inspected = self.inspect()
        # During the bounded post-join roster grace, observation is the *only*
        # legal operation.  Do not call PartyMissionController yet, because it
        # would re-read the same transient conflict and turn it terminal.
        if inspected.reason == "LOCAL_ROSTER_CONVERGING":
            return self._decorate(inspected)
        if inspected.reason == "SHARED_FIGHT_NOT_CONVERGED":
            return self._decorate(inspected)
        if inspected.state is FightWorkflowState.JOINING:
            join_step = getattr(self.mission, "join_required_party_step", None)
            if not callable(join_step):
                # Compatibility with narrow/legacy mission doubles. Production
                # PartyMissionController owns follower joining in the parent.
                return self._decorate(inspected)
            action = dict(join_step(runtime_context=runtime_context))
            status = str(action.get("status") or "UNKNOWN")
            terminal_join_statuses = {
                "FAILED", "UNCERTAIN", "NO_INTERACTION", "WINDOW_CLOSED",
                "TARGET_MISS", "IDENTITY_MISMATCH",
            }
            non_retryable_block = status == "BLOCKED" and action.get("retry_allowed") is False
            state = (
                FightWorkflowState.FAILED
                if status in terminal_join_statuses or non_retryable_block
                else FightWorkflowState.JOINING
            )
            return self._decorate(FightWorkflowResult(
                state,
                action,
                reason=str(
                    action.get("failure_code")
                    or action.get("join_failure_code")
                    or action.get("detail")
                    or "JOINING"
                ),
                account_id=action.get("account_id"),
                next_allowed_commands=("OBSERVE_FIGHT", "JOIN_FIGHT"),
            ))
        if inspected.state is FightWorkflowState.ACTIVE:
            if "COMBAT_STEP" not in inspected.next_allowed_commands:
                return self._decorate(inspected)
            action = dict(self.combat.step(runtime_context=runtime_context))
            return self._decorate(FightWorkflowResult(
                FightWorkflowState.ACTIVE,
                action,
                reason=str(action.get("reason") or "ACTIVE"),
                progress_token=action.get("progress_token"),
                account_id=action.get("account_id"),
                next_allowed_commands=("COMBAT_STEP",),
            ))
        if inspected.state in {
            FightWorkflowState.ENTRY_BARRIER,
            FightWorkflowState.CHALLENGE,
            FightWorkflowState.PLACEMENT,
            FightWorkflowState.READY,
        }:
            expected_fight_instance_id = None
            if self._last_view is not None and self._last_view.fight_instance_id is not None:
                expected_fight_instance_id = int(self._last_view.fight_instance_id)
            if runtime_context:
                action = dict(self.mission.prepare_fight_step(
                    runtime_context=runtime_context,
                    expected_fight_instance_id=expected_fight_instance_id,
                ))
            else:
                action = dict(self.mission.prepare_fight_step(
                    expected_fight_instance_id=expected_fight_instance_id,
                ))
            state = _PREPARATION_STAGE_TO_STATE.get(str(action.get("stage") or "ENTRY_BARRIER"), FightWorkflowState.ENTRY_BARRIER)
            if str(action.get("status") or "") in {"BLOCKED", "FAILED", "TIMEOUT"}:
                # Preparation remains recoverable unless the caller chooses to terminate.
                state = state if action.get("failure_code") != "SHARED_FIGHT_CONFLICT" else FightWorkflowState.FAILED
            return self._decorate(FightWorkflowResult(
                state,
                action,
                reason=str(action.get("failure_code") or action.get("detail") or action.get("stage") or "PREPARATION"),
                account_id=action.get("account_id"),
                next_allowed_commands=("OBSERVE_FIGHT",) if str(action.get("stage") or "") == "COMPLETE" else ("PREPARE_FIGHT",),
            ))
        return self._decorate(inspected)

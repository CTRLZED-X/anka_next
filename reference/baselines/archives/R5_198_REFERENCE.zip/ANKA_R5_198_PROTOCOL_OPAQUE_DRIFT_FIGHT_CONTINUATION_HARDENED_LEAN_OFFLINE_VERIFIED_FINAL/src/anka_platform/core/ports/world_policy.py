from __future__ import annotations

from typing import Mapping, Protocol, runtime_checkable


@runtime_checkable
class WorldPolicy(Protocol):
    def select_target(self, *, session_plan, snapshots: Mapping[str, object]) -> object | None: ...

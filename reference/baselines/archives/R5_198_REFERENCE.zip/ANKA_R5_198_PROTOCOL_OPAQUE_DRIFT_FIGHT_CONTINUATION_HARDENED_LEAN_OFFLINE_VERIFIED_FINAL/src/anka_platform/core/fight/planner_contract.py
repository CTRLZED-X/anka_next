from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Mapping

from anka_platform.core.fight.combat_truth import CombatTruthAvailability


class PlannerDisposition(StrEnum):
    """Core orchestration result of a planner slice.

    This is intentionally planner-agnostic.  TacticalPolicy, a rule engine, a
    beam search, or a test dummy all communicate turn-liveness through the same
    vocabulary while executable actions remain FightDecision values.
    """

    ACTION_READY = "ACTION_READY"
    CONTINUE_PLANNING = "CONTINUE_PLANNING"
    WAIT_EXTERNAL = "WAIT_EXTERNAL"
    NO_MATERIAL_ACTION = "NO_MATERIAL_ACTION"
    FAULT = "FAULT"


class PlannerFailureClass(StrEnum):
    """Why a planner result could not immediately provide an executable action.

    Recovery consumes this type; human-readable ``reason`` text is diagnostic
    only for current planner producers.
    """

    TRANSIENT_EXTERNAL = "TRANSIENT_EXTERNAL"
    COMPUTATION_INCOMPLETE = "COMPUTATION_INCOMPLETE"
    CONFIGURATION = "CONFIGURATION"
    POLICY_FAULT = "POLICY_FAULT"
    CONTRACT_VIOLATION = "CONTRACT_VIOLATION"




@dataclass(frozen=True, slots=True)
class ConfirmedTurnAction:
    """One game action whose semantic effect is confirmed for the current turn.

    This is orchestration truth, not Canonical State.  It exists so any current or
    future FightAI can reason about physical actions already consumed this turn
    without depending on PartyCombatController internals or execution logs.
    """

    kind: str
    action_id: str | None = None
    origin_cell_id: int | None = None
    target_cell_id: int | None = None
    spell_id: int | None = None
    grade: int | None = None
    slot_index: int | None = None
    target_actor_id: int | None = None
    path_distance: int | None = None
    canonical_revision: int | None = None
    decision_fingerprint: tuple | None = None
    reconciliation_outcome: str | None = None


@dataclass(frozen=True, slots=True)
class ConfirmedTurnExecutionHistory:
    """Planner-neutral history of confirmed actions in one authoritative turn."""

    fight_instance_id: int | None = None
    round: int | None = None
    turn_index: int | None = None
    actor_id: int | None = None
    actions: tuple[ConfirmedTurnAction, ...] = ()

    @property
    def move_count(self) -> int:
        return sum(1 for item in self.actions if str(item.kind).upper() == "MOVE")

    @property
    def cast_count(self) -> int:
        return sum(1 for item in self.actions if str(item.kind).upper() == "CAST")

    @property
    def action_count(self) -> int:
        return len(self.actions)


@dataclass(frozen=True, slots=True)
class PlannerInvocationContext:
    """Stable core-owned inputs that orchestration may provide to any FightPolicy.

    Concrete planners must not require FightDecisionService to introspect their
    private signatures.  New policies consume this object directly; a quarantined legacy invoker adapts historical policies that still expose the older keyword parameters.
    """

    decision_deadline_monotonic: float | None = None
    objective: object | None = None
    excluded_action_fingerprints: tuple[tuple, ...] = ()
    confirmed_turn_history: ConfirmedTurnExecutionHistory = ConfirmedTurnExecutionHistory()
    combat_truth: CombatTruthAvailability = CombatTruthAvailability()

@dataclass(frozen=True, slots=True)
class PassiveInvocationContext:
    """Stable inputs for passive/front-guard turn policies.

    It mirrors the active planner boundary so DecisionService never has to
    inspect a concrete passive policy signature.  ``kernel``/``snapshot`` stay
    typed as objects here to keep the foundation contract dependency-light.
    """

    current_cell_id: int | None = None
    kernel: object | None = None
    snapshot: object | None = None
    local_actor_id: int | None = None
    planner: PlannerInvocationContext = PlannerInvocationContext()


@dataclass(frozen=True, slots=True)
class PlannerProgress:
    """Opaque monotonic planner progress understood by orchestration only."""

    completed_units: int | None = None
    total_units: int | None = None
    token: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "completed_units": self.completed_units,
            "total_units": self.total_units,
            "token": self.token,
        }


@dataclass(frozen=True, slots=True)
class PlannerResultView:
    """Controller-facing planner contract independent from concrete FightAI traces."""

    disposition: PlannerDisposition
    reason: str
    dependency: str | None = None
    progress: PlannerProgress | None = None
    failure_class: PlannerFailureClass | None = None
    schema_version: int = 1
    compatibility_adapter: bool = False

    @property
    def continue_planning(self) -> bool:
        return self.disposition is PlannerDisposition.CONTINUE_PLANNING


_COMPUTE_INCOMPLETE_REASONS = frozenset({
    "SPELL_COVERAGE_INCOMPLETE",
    "DECISION_BUDGET_UNAVAILABLE",
})


def _optional_int(value) -> int | None:
    try:
        return None if value is None else int(value)
    except (TypeError, ValueError):
        return None


def _disposition(value: object, *, default: PlannerDisposition = PlannerDisposition.FAULT) -> PlannerDisposition:
    try:
        return PlannerDisposition(str(value or default.value).upper())
    except ValueError:
        return default



def _failure_class(value: object) -> PlannerFailureClass | None:
    if value in (None, ""):
        return None
    try:
        return PlannerFailureClass(str(value).upper())
    except ValueError:
        return None


def _typed_result(payload: Mapping[str, object]) -> PlannerResultView | None:
    raw = payload.get("planner_result")
    if not isinstance(raw, Mapping):
        return None
    progress_raw = raw.get("progress")
    progress = None
    if isinstance(progress_raw, Mapping):
        progress = PlannerProgress(
            completed_units=_optional_int(progress_raw.get("completed_units")),
            total_units=_optional_int(progress_raw.get("total_units")),
            token=(None if progress_raw.get("token") is None else str(progress_raw.get("token"))),
        )
    return PlannerResultView(
        disposition=_disposition(raw.get("disposition")),
        reason=str(raw.get("reason") or payload.get("reason") or ""),
        dependency=(None if raw.get("dependency") is None else str(raw.get("dependency"))),
        progress=progress,
        failure_class=_failure_class(raw.get("failure_class")),
        schema_version=_optional_int(raw.get("schema_version")) or 1,
        compatibility_adapter=bool(raw.get("compatibility_adapter", False)),
    )


def _legacy_progress(payload: Mapping[str, object]) -> PlannerProgress | None:
    """R5.147-only compatibility bridge for historical direct controller tests.

    Current production policies emit ``planner_result``.  This parser is kept in
    one quarantined adapter so PartyCombatController itself never knows a concrete
    planner's telemetry schema.  It can be deleted once historical direct-dict
    regressions are archived behind the typed contract.
    """

    trace = payload.get("tactical_trace")
    if not isinstance(trace, Mapping):
        return None
    audit = trace.get("candidate_generation_audit")
    if not isinstance(audit, Mapping):
        return None
    completed = _optional_int(audit.get("evaluated_spell_count"))
    total = _optional_int(audit.get("configured_spell_count"))
    if completed is None and total is None:
        return None
    return PlannerProgress(completed_units=completed, total_units=total, token="legacy_spell_coverage")


def normalize_planner_result(payload: Mapping[str, object]) -> PlannerResultView:
    typed = _typed_result(payload)
    if typed is not None:
        return typed

    kind = str(payload.get("kind") or "").upper()
    reason = str(payload.get("reason") or "")
    token = reason.split(":", 1)[0].strip()
    if kind in {"CAST", "MOVE", "END_TURN"}:
        disposition = PlannerDisposition.ACTION_READY
    elif kind == "WAIT":
        disposition = PlannerDisposition.WAIT_EXTERNAL
    elif kind == "BLOCKED" and token in _COMPUTE_INCOMPLETE_REASONS:
        disposition = PlannerDisposition.CONTINUE_PLANNING
    else:
        disposition = PlannerDisposition.FAULT
    legacy_failure = None
    if disposition is PlannerDisposition.CONTINUE_PLANNING:
        legacy_failure = PlannerFailureClass.COMPUTATION_INCOMPLETE
    elif token in {
        "CURRENT_AP_UNKNOWN", "CURRENT_MP_UNKNOWN", "FIGHT_CONTEXT_UNAVAILABLE",
        "FIGHT_MAP_UNKNOWN", "DECISION_STALE_COMBAT_FRAME",
        "DECISION_END_FRAME_UNAVAILABLE", "TEAM_OBSERVATION_NOT_CONVERGED",
        "ACTIVE_ACTOR_UNKNOWN", "NOT_LOCAL_TURN", "DECISION_STALE_TURN",
        "LOCAL_ACTOR_UNKNOWN", "LOCAL_ACTOR_OR_CELL_UNKNOWN", "LOCAL_TEAM_UNKNOWN",
    }:
        legacy_failure = PlannerFailureClass.TRANSIENT_EXTERNAL
    return PlannerResultView(
        disposition=disposition,
        reason=reason,
        progress=_legacy_progress(payload),
        failure_class=legacy_failure,
        schema_version=0,
        compatibility_adapter=True,
    )

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from anka_platform.contracts.common import ValueStatus


def _known(value):
    return value.value if getattr(value, "status", None) is ValueStatus.KNOWN else None


def _token(value) -> str:
    raw = _known(value)
    if isinstance(raw, Enum):
        raw = raw.value
    return str(raw or "").upper()


@dataclass(frozen=True, slots=True)
class CombatTruthAvailability:
    """Planner-neutral completeness map for live combat observations.

    This contract intentionally describes *what is known*, not what a tactical
    policy should do with it.  A replacement FightAI can therefore branch on
    certified availability without re-discovering Canonical-State conventions or
    silently treating UNKNOWN values as zeros.
    """

    local_actor_present: bool = False
    local_hp_known: bool = False
    local_max_hp_known: bool = False
    local_ap_known: bool = False
    local_mp_known: bool = False
    local_summon_count_known: bool = False
    local_states_complete: bool = False
    local_effects_complete: bool = False
    enemy_count: int = 0
    enemy_hp_known_count: int = 0
    enemy_max_hp_known_count: int = 0
    enemy_ap_known_count: int = 0
    enemy_mp_known_count: int = 0
    enemy_static_id_known_count: int = 0
    enemy_states_complete_count: int = 0
    enemy_effects_complete_count: int = 0
    max_effect_count: int = 0
    max_effect_semantic_multiplicity: int = 0
    effect_payload_expansion: bool = False
    exact_tackle_lock_supported: bool = False
    blockers: tuple[str, ...] = ()

    @property
    def enemy_hp_complete(self) -> bool:
        return self.enemy_count > 0 and self.enemy_hp_known_count == self.enemy_count

    @property
    def enemy_max_hp_complete(self) -> bool:
        return self.enemy_count > 0 and self.enemy_max_hp_known_count == self.enemy_count

    @property
    def enemy_ap_mp_complete(self) -> bool:
        return (
            self.enemy_count > 0
            and self.enemy_ap_known_count == self.enemy_count
            and self.enemy_mp_known_count == self.enemy_count
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "local_actor_present": self.local_actor_present,
            "local_hp_known": self.local_hp_known,
            "local_max_hp_known": self.local_max_hp_known,
            "local_ap_known": self.local_ap_known,
            "local_mp_known": self.local_mp_known,
            "local_summon_count_known": self.local_summon_count_known,
            "local_states_complete": self.local_states_complete,
            "local_effects_complete": self.local_effects_complete,
            "enemy_count": self.enemy_count,
            "enemy_hp_known_count": self.enemy_hp_known_count,
            "enemy_max_hp_known_count": self.enemy_max_hp_known_count,
            "enemy_ap_known_count": self.enemy_ap_known_count,
            "enemy_mp_known_count": self.enemy_mp_known_count,
            "enemy_static_id_known_count": self.enemy_static_id_known_count,
            "enemy_states_complete_count": self.enemy_states_complete_count,
            "enemy_effects_complete_count": self.enemy_effects_complete_count,
            "max_effect_count": self.max_effect_count,
            "max_effect_semantic_multiplicity": self.max_effect_semantic_multiplicity,
            "effect_payload_expansion": self.effect_payload_expansion,
            "exact_tackle_lock_supported": self.exact_tackle_lock_supported,
            "blockers": list(self.blockers),
        }


def assess_combat_truth(snapshot, *, local_actor_id: int) -> CombatTruthAvailability:
    actors = tuple(getattr(getattr(snapshot, "fight", None), "actors", ()) or ())
    local = next((actor for actor in actors if int(getattr(actor, "actor_id", 0)) == int(local_actor_id)), None)
    enemies = [actor for actor in actors if _token(getattr(actor, "side_relation", None)) in {"ENEMY", "ENEMY_SIDE"}]

    # Diagnostic grouping fallback only.  It never authorizes mechanics.
    if local is not None and not enemies:
        local_team = _known(getattr(local, "team_id", None))
        if local_team is not None:
            enemies = [
                actor for actor in actors
                if _known(getattr(actor, "team_id", None)) is not None
                and _known(getattr(actor, "team_id", None)) != local_team
            ]

    def known(actor, field: str) -> bool:
        return actor is not None and _known(getattr(actor, field, None)) is not None

    enemy_count = len(enemies)
    max_effect_count = 0
    max_semantic_multiplicity = 0
    for actor in actors:
        effects = tuple(getattr(actor, "effects", ()) or ())
        max_effect_count = max(max_effect_count, len(effects))
        signatures: dict[tuple[object, ...], int] = {}
        for item in effects:
            signature = (
                int(getattr(item, "effect_id", 0)),
                _known(getattr(item, "source_spell_id", None)),
                _known(getattr(item, "state_id", None)),
                _known(getattr(item, "source_actor_id", None)),
            )
            signatures[signature] = signatures.get(signature, 0) + 1
        max_semantic_multiplicity = max(max_semantic_multiplicity, max(signatures.values(), default=0))

    effect_payload_expansion = max_effect_count >= 64 or max_semantic_multiplicity >= 16
    blockers: list[str] = []
    if local is None or not (known(local, "hp") and known(local, "max_hp")):
        blockers.append("LOCAL_HP_MAX_HP_INCOMPLETE")
    if local is None or not known(local, "summon_count"):
        blockers.append("LOCAL_SUMMON_CAPACITY_INCOMPLETE")
    if local is None or not bool(getattr(local, "states_complete", False)):
        blockers.append("LOCAL_STATE_LIFECYCLE_PARTIAL")
    if local is None or not bool(getattr(local, "effects_complete", False)):
        blockers.append("LOCAL_EFFECT_LIFECYCLE_PARTIAL")
    if any(not (known(actor, "hp") and known(actor, "max_hp")) for actor in enemies):
        blockers.append("ENEMY_HP_MAX_HP_INCOMPLETE")
    if any(not (known(actor, "ap") and known(actor, "mp")) for actor in enemies):
        blockers.append("ENEMY_AP_MP_INCOMPLETE")
    if any(not bool(getattr(actor, "states_complete", False)) for actor in enemies):
        blockers.append("ENEMY_STATE_LIFECYCLE_PARTIAL")
    if any(not bool(getattr(actor, "effects_complete", False)) for actor in enemies):
        blockers.append("ENEMY_EFFECT_LIFECYCLE_PARTIAL")
    if any(not known(actor, "static_id") for actor in enemies):
        blockers.append("ENEMY_STATIC_ID_INCOMPLETE")
    if effect_payload_expansion:
        blockers.append("EFFECT_PAYLOAD_EXPANSION_OBSERVED")
    blockers.append("TACKLE_LOCK_EXACT_MECHANICS_UNSUPPORTED")

    return CombatTruthAvailability(
        local_actor_present=local is not None,
        local_hp_known=known(local, "hp"),
        local_max_hp_known=known(local, "max_hp"),
        local_ap_known=known(local, "ap"),
        local_mp_known=known(local, "mp"),
        local_summon_count_known=known(local, "summon_count"),
        local_states_complete=bool(getattr(local, "states_complete", False)) if local is not None else False,
        local_effects_complete=bool(getattr(local, "effects_complete", False)) if local is not None else False,
        enemy_count=enemy_count,
        enemy_hp_known_count=sum(1 for actor in enemies if known(actor, "hp")),
        enemy_max_hp_known_count=sum(1 for actor in enemies if known(actor, "max_hp")),
        enemy_ap_known_count=sum(1 for actor in enemies if known(actor, "ap")),
        enemy_mp_known_count=sum(1 for actor in enemies if known(actor, "mp")),
        enemy_static_id_known_count=sum(1 for actor in enemies if known(actor, "static_id")),
        enemy_states_complete_count=sum(1 for actor in enemies if bool(getattr(actor, "states_complete", False))),
        enemy_effects_complete_count=sum(1 for actor in enemies if bool(getattr(actor, "effects_complete", False))),
        max_effect_count=max_effect_count,
        max_effect_semantic_multiplicity=max_semantic_multiplicity,
        effect_payload_expansion=effect_payload_expansion,
        exact_tackle_lock_supported=False,
        blockers=tuple(sorted(set(blockers))),
    )

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class FightObjective:
    target_actor_id: int | None = None
    preferred_range_min: int | None = None
    preferred_range_max: int | None = None
    tags: tuple[str, ...] = ()


class NoOpTeamStrategy:
    """Behavior-neutral team strategy used by compatibility sessions."""

    def objectives(self, *, session_plan, snapshots: Mapping[str, object]) -> Mapping[str, FightObjective]:
        return {}

from __future__ import annotations

from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id

from dataclasses import dataclass, field
from typing import Mapping

from anka_platform.contracts.common import ValueStatus
from anka_platform.core.models import MembershipRequirement


def _known(value):
    return value.value if getattr(value, "status", None) is ValueStatus.KNOWN else None


class TeamObservationNotConverged(RuntimeError):
    """Required Canonical lanes do not yet describe one coherent fight epoch.

    Canonical ``revision`` values are intentionally *not* compared here.  Every
    account lane owns its own reducer sequence, so revision 200 on one account is
    not newer than revision 100 on another account.  Team synchronization is
    based only on shared semantic fight facts.
    """

    def __init__(self, reason: str, *, context: Mapping[str, object] | None = None) -> None:
        self.reason = str(reason)
        self.context = dict(context or {})
        detail = self.reason
        if self.context:
            detail += ": " + ", ".join(f"{key}={value!r}" for key, value in sorted(self.context.items()))
        super().__init__(detail)


@dataclass(frozen=True, slots=True)
class TeamFightEpoch:
    fight_instance_id: int
    map_id: int
    phase: str
    round: int
    turn_index: int
    active_actor_id: int

    def as_tuple(self) -> tuple[object, ...]:
        return (
            int(self.fight_instance_id),
            int(self.map_id),
            str(self.phase),
            int(self.round),
            int(self.turn_index),
            int(self.active_actor_id),
        )


@dataclass(frozen=True, slots=True)
class TeamFightObservation:
    epoch: TeamFightEpoch
    required_accounts: tuple[str, ...]
    actor_owners: Mapping[int, str]
    account_revisions: Mapping[str, int] = field(default_factory=dict)
    active_account_id: str | None = None

    def revision_for(self, account_id: str | None) -> int | None:
        if account_id is None:
            return None
        value = self.account_revisions.get(str(account_id))
        return None if value is None else int(value)


def converge_team_fight_observation(*, session_plan, snapshots: Mapping[str, object]) -> TeamFightObservation:
    """Prove that all required account lanes describe the same tactical epoch.

    This is deliberately stricter than simply finding a snapshot with the largest
    revision.  Required lanes must agree semantically on fight generation and turn
    identity.  Each local player actor is owned by its own lane.  Cross-lane
    revision values are retained only for diagnostics.
    """

    required_accounts = tuple(
        str(member.account_id)
        for member in session_plan.members
        if member.requirement is MembershipRequirement.REQUIRED
    )
    if not required_accounts:
        raise TeamObservationNotConverged("NO_REQUIRED_ACCOUNTS")

    missing = tuple(account for account in required_accounts if account not in snapshots)
    if missing:
        raise TeamObservationNotConverged("REQUIRED_SNAPSHOT_MISSING", context={"accounts": missing})

    required = {account: snapshots[account] for account in required_accounts}
    not_present = tuple(
        account for account, snapshot in required.items()
        if not bool(getattr(getattr(snapshot, "fight", None), "present", False))
    )
    if not_present:
        raise TeamObservationNotConverged("REQUIRED_FIGHT_NOT_PRESENT", context={"accounts": not_present})

    field_values: dict[str, dict[str, object | None]] = {
        "fight_instance_id": {},
        "map_id": {},
        "phase": {},
        "round": {},
        "turn_index": {},
        "active_actor_id": {},
    }
    for account, snapshot in required.items():
        fight = snapshot.fight
        field_values["fight_instance_id"][account] = (
            None if fight.fight_instance_id is None else int(fight.fight_instance_id)
        )
        map_id = _known(fight.map_id)
        field_values["map_id"][account] = None if map_id is None else int(map_id)
        phase = _known(fight.phase)
        field_values["phase"][account] = None if phase is None else str(phase)
        round_number = _known(fight.round)
        field_values["round"][account] = None if round_number is None else int(round_number)
        turn_index = _known(fight.turn_index)
        field_values["turn_index"][account] = None if turn_index is None else int(turn_index)
        active_actor = _known(fight.active_actor_id)
        field_values["active_actor_id"][account] = None if active_actor is None else int(active_actor)

    resolved: dict[str, object] = {}
    for field_name, values in field_values.items():
        unknown = tuple(account for account, value in values.items() if value is None)
        if unknown:
            raise TeamObservationNotConverged(
                "TEAM_EPOCH_FIELD_UNKNOWN",
                context={"field": field_name, "accounts": unknown},
            )
        distinct = {value for value in values.values()}
        if len(distinct) != 1:
            raise TeamObservationNotConverged(
                "TEAM_EPOCH_CONFLICT",
                context={"field": field_name, "values": tuple(sorted(values.items()))},
            )
        resolved[field_name] = next(iter(distinct))

    if str(resolved["phase"]).upper() != "ACTIVE":
        raise TeamObservationNotConverged(
            "TEAM_EPOCH_NOT_ACTIVE",
            context={"phase": resolved["phase"]},
        )

    actor_owners: dict[int, str] = {}
    for account, snapshot in required.items():
        local_actor = authoritative_canonical_local_actor_id(snapshot)
        if local_actor is None:
            raise TeamObservationNotConverged(
                "LOCAL_ACTOR_UNKNOWN",
                context={"account": account},
            )
        actor_id = int(local_actor)
        previous = actor_owners.get(actor_id)
        if previous is not None and previous != account:
            raise TeamObservationNotConverged(
                "ACTOR_OWNERSHIP_CONFLICT",
                context={"actor_id": actor_id, "accounts": (previous, account)},
            )
        actor_owners[actor_id] = account

    active_actor_id = int(resolved["active_actor_id"])
    return TeamFightObservation(
        epoch=TeamFightEpoch(
            fight_instance_id=int(resolved["fight_instance_id"]),
            map_id=int(resolved["map_id"]),
            phase=str(resolved["phase"]),
            round=int(resolved["round"]),
            turn_index=int(resolved["turn_index"]),
            active_actor_id=active_actor_id,
        ),
        required_accounts=required_accounts,
        actor_owners=dict(actor_owners),
        account_revisions={
            account: int(getattr(snapshot, "revision", 0))
            for account, snapshot in required.items()
        },
        active_account_id=actor_owners.get(active_actor_id),
    )

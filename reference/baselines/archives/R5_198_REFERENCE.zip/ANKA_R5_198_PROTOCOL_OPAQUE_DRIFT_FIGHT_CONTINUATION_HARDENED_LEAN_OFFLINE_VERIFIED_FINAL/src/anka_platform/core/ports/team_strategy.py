from __future__ import annotations

from typing import Mapping, Protocol, runtime_checkable


@runtime_checkable
class TeamStrategy(Protocol):
    def objectives(self, *, session_plan, snapshots: Mapping[str, object]) -> Mapping[str, object]: ...

from __future__ import annotations

from typing import Protocol, Sequence, runtime_checkable


@runtime_checkable
class PlacementPolicy(Protocol):
    def select_cell(self, *, account_id: str, snapshot, available_cells: Sequence[int], kernel) -> int | None: ...

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RouteRuntimeEdge:
    index: int
    source_map_id: int
    target_map_id: int
    direction: str

    @classmethod
    def from_mapping(cls, value) -> "RouteRuntimeEdge":
        if isinstance(value, cls):
            return value
        if hasattr(value, "source_map_id"):
            direction = getattr(value, "direction", "")
            direction = getattr(direction, "value", direction)
            return cls(
                index=int(getattr(value, "index", 0)),
                source_map_id=int(value.source_map_id),
                target_map_id=int(value.target_map_id),
                direction=str(direction),
            )
        return cls(
            index=int(value[0]), source_map_id=int(value[1]),
            target_map_id=int(value[2]), direction=str(value[3]),
        )


@dataclass(frozen=True, slots=True)
class RouteDecision:
    target_map_id: int | None
    reason: str
    edge_index: int | None
    cycle_iteration: int
    expected_source_map_id: int | None
    expected_target_map_id: int | None
    direction: str | None
    recovery: bool = False
    completed: bool = False

    def to_dict(self) -> dict:
        return {
            "route_reason": self.reason,
            "route_edge_index": self.edge_index,
            "route_cycle_iteration": int(self.cycle_iteration),
            "route_expected_source_map_id": self.expected_source_map_id,
            "route_expected_target_map_id": self.expected_target_map_id,
            "route_direction": self.direction,
            "route_recovery": bool(self.recovery),
            "route_completed": bool(self.completed),
        }


class DirectionalRouteRuntime:
    """Explicit party-level cursor for a certified directional route.

    Progress is never inferred with ``list.index(current_map)``.  The exact edge
    index is the authority. If external/manual displacement makes the observed map
    inconsistent with the expected edge, runtime deterministically reacquires the
    anchor instead of guessing which repeated occurrence of a map was intended.
    """

    def __init__(self, edges, *, loop: bool = True) -> None:
        self.edges = tuple(RouteRuntimeEdge.from_mapping(value) for value in edges)
        self.loop = bool(loop)
        self.edge_index = 0
        self.cycle_iteration = 0
        self.recovery_active = False
        self.completed = False
        if self.edges:
            for expected, edge in enumerate(self.edges):
                if edge.index != expected:
                    raise ValueError("directional route edges must be ordered and contiguous")
            for previous, nxt in zip(self.edges, self.edges[1:]):
                if previous.target_map_id != nxt.source_map_id:
                    raise ValueError("directional route edges must form one continuous chain")
            if self.loop and self.edges[-1].target_map_id != self.edges[0].source_map_id:
                raise ValueError("looping directional route must close back to its anchor map")

    @property
    def anchor_map_id(self) -> int | None:
        return int(self.edges[0].source_map_id) if self.edges else None

    @property
    def current_edge(self) -> RouteRuntimeEdge | None:
        if not self.edges or self.completed:
            return None
        return self.edges[self.edge_index]

    def reset(self) -> None:
        """Reset the party route cursor to the beginning of a fresh mission run."""
        self.edge_index = 0
        self.cycle_iteration = 0
        self.recovery_active = False
        self.completed = False

    def reset_to_anchor(self) -> None:
        """Reacquire the anchor without erasing the completed-cycle counter."""
        self.edge_index = 0
        self.recovery_active = False
        self.completed = False

    def _advance_edge(self) -> None:
        if not self.edges:
            self.completed = True
            return
        if self.edge_index + 1 < len(self.edges):
            self.edge_index += 1
            return
        if self.loop:
            self.edge_index = 0
            self.cycle_iteration += 1
            return
        self.completed = True

    def decide(self, current_map_id: int) -> RouteDecision:
        current = int(current_map_id)
        if not self.edges:
            return RouteDecision(None, "NO_DIRECTIONAL_ROUTE", None, self.cycle_iteration, None, None, None, completed=True)
        if self.completed:
            return RouteDecision(None, "ROUTE_COMPLETE", None, self.cycle_iteration, None, None, None, completed=True)

        edge = self.current_edge
        assert edge is not None

        # The previous physical edge has now been authoritatively observed by the
        # whole party at its target. Commit once, then reason about the next edge.
        if current == edge.target_map_id:
            self._advance_edge()
            if self.completed:
                return RouteDecision(None, "ROUTE_COMPLETE", None, self.cycle_iteration, None, None, None, completed=True)
            edge = self.current_edge
            assert edge is not None

        if current == edge.source_map_id:
            self.recovery_active = False
            return RouteDecision(
                int(edge.target_map_id), "ROUTE_EDGE", int(edge.index), self.cycle_iteration,
                int(edge.source_map_id), int(edge.target_map_id), str(edge.direction),
            )

        anchor = self.anchor_map_id
        if anchor is None:
            return RouteDecision(None, "NO_DIRECTIONAL_ROUTE", None, self.cycle_iteration, None, None, None, completed=True)

        # Never infer cursor position from a repeated/self-intersecting map. Any
        # inconsistent observation reacquires the one unambiguous anchor.
        self.recovery_active = True
        if current == anchor:
            self.reset_to_anchor()
            edge = self.current_edge
            assert edge is not None
            return RouteDecision(
                int(edge.target_map_id), "ROUTE_ANCHOR_REACQUIRED", int(edge.index), self.cycle_iteration,
                int(edge.source_map_id), int(edge.target_map_id), str(edge.direction), recovery=False,
            )
        return RouteDecision(
            int(anchor), "OFF_ROUTE_RECOVERY", int(edge.index), self.cycle_iteration,
            int(edge.source_map_id), int(edge.target_map_id), str(edge.direction), recovery=True,
        )

    def status(self) -> dict:
        edge = self.current_edge
        return {
            "model": "DIRECTIONAL",
            "edge_index": (int(edge.index) if edge is not None else None),
            "cycle_iteration": int(self.cycle_iteration),
            "anchor_map_id": self.anchor_map_id,
            "expected_source_map_id": (int(edge.source_map_id) if edge is not None else None),
            "expected_target_map_id": (int(edge.target_map_id) if edge is not None else None),
            "direction": (str(edge.direction) if edge is not None else None),
            "recovery_active": bool(self.recovery_active),
            "completed": bool(self.completed),
        }

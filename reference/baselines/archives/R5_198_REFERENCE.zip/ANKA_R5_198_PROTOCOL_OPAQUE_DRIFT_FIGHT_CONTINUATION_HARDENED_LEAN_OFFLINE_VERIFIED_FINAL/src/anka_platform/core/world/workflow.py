from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Callable

from anka_platform.contracts.common import ValueStatus
from anka_platform.core.world.models import WorldWorkflowResult, WorldWorkflowState
from anka_platform.core.world.route_runtime import DirectionalRouteRuntime


@dataclass(frozen=True, slots=True)
class MonsterCountTargetPolicy:
    min_monsters: int
    max_monsters: int

    def __post_init__(self) -> None:
        if int(self.min_monsters) < 1 or int(self.max_monsters) < int(self.min_monsters):
            raise ValueError("invalid monster count range")
        object.__setattr__(self, "min_monsters", int(self.min_monsters))
        object.__setattr__(self, "max_monsters", int(self.max_monsters))

    def candidates(self, groups):
        eligible = []
        for group in groups:
            size = len(tuple(getattr(group, "member_ids", ()) or ()))
            cell = getattr(group, "cell_id", None)
            cell_known = cell is not None and cell.status is ValueStatus.KNOWN and cell.value is not None
            if self.min_monsters <= size <= self.max_monsters and cell_known:
                eligible.append(group)
        return tuple(sorted(eligible, key=lambda item: (len(tuple(item.member_ids or ())), int(item.group_id)), reverse=True))

    def select(self, groups):
        candidates = self.candidates(groups)
        return candidates[0] if candidates else None


class WorldWorkflow:
    """Party-aware world lifecycle that never performs target clicks itself."""

    def __init__(
        self, *, party, mission, target_policy, route_map_ids: tuple[int, ...] = (),
        route_edges: tuple = (), route_loop: bool = True, world_reentry_stability_seconds: float = 1.5,
        world_reentry_timeout_seconds: float = 20.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.party = party
        self.mission = mission
        self.target_policy = target_policy
        self.route_map_ids = tuple(int(value) for value in route_map_ids)
        self.route_loop = bool(route_loop)
        self.route_runtime = DirectionalRouteRuntime(route_edges, loop=self.route_loop) if route_edges else None
        self.world_reentry_stability_seconds = max(0.0, float(world_reentry_stability_seconds))
        self.world_reentry_timeout_seconds = max(self.world_reentry_stability_seconds, float(world_reentry_timeout_seconds))
        self.clock = clock
        self._reentry_required = False
        self._reentry_started: float | None = None
        self._reentry_stable_since: float | None = None
        self._reentry_ready_started: float | None = None
        self._reentry_last_observed: float | None = None
        self._reentry_fingerprint: tuple | None = None
        self._reentry_release_pending = False
        self._reentry_reason: str | None = None
        # Waypoints may be multiple physical map edges apart. Keep the selected
        # waypoint sticky while the party advances one confirmed edge at a time;
        # otherwise an intermediate map that is itself another waypoint can make
        # the route bounce or reverse.
        self._route_cursor_index: int | None = None
        self._route_target_index: int | None = None
        self._route_target_map_id: int | None = None

    @property
    def reentry_required(self) -> bool:
        """Whether post-fight world interaction readiness still owns routing."""
        return bool(self._reentry_required)

    def reentry_status(self) -> dict:
        """Return cheap, cached re-entry timing evidence for diagnostics."""
        now = float(self.clock())
        started = self._reentry_started
        stable = self._reentry_stable_since
        ready = self._reentry_ready_started
        last = self._reentry_last_observed
        return {
            "required": bool(self._reentry_required),
            "reason": self._reentry_reason,
            "started_monotonic": started,
            "elapsed_seconds": (None if started is None else max(0.0, now - float(started))),
            "ready_started_monotonic": ready,
            "ready_elapsed_seconds": (None if ready is None else max(0.0, now - float(ready))),
            "stable_since_monotonic": stable,
            "stable_elapsed_seconds": (None if stable is None else max(0.0, now - float(stable))),
            "last_observed_monotonic": last,
            "observer_age_seconds": (None if last is None else max(0.0, now - float(last))),
            "release_pending": bool(self._reentry_release_pending),
            "fingerprint": list(self._reentry_fingerprint) if self._reentry_fingerprint is not None else None,
            "stability_seconds": float(self.world_reentry_stability_seconds),
            "timeout_seconds": float(self.world_reentry_timeout_seconds),
        }

    def reset(self) -> None:
        """Reset only run-scoped world orchestration state.

        Canonical State and the real client map remain authoritative and are not
        mutated here.  A fresh campaign must not inherit a previous run's
        post-fight gate, sticky waypoint, or route cursor; the next inspect()
        re-acquires routing from current live truth.
        """
        self._reentry_required = False
        self._reentry_started = None
        self._reentry_stable_since = None
        self._reentry_ready_started = None
        self._reentry_last_observed = None
        self._reentry_fingerprint = None
        self._reentry_release_pending = False
        self._reentry_reason = None
        self._route_cursor_index = None
        self._route_target_index = None
        self._route_target_map_id = None
        if self.route_runtime is not None:
            self.route_runtime.reset()

    def mark_reentry_required(self, *, reason: str = "FIGHT_TERMINATED") -> None:
        """Require a fresh, continuously stable world interaction surface.

        Canonical fight->world transition proves semantic world presence, but it
        does not prove that the rendered client is already safe to click.  This
        gate is armed only after a completed fight generation; ordinary startup
        and route traversal keep their existing behavior.
        """
        self._reentry_required = True
        self._reentry_started = float(self.clock())
        self._reentry_stable_since = None
        self._reentry_ready_started = None
        self._reentry_last_observed = None
        self._reentry_fingerprint = None
        self._reentry_release_pending = False
        self._reentry_reason = str(reason or "FIGHT_TERMINATED")

    def _projection_reentry_evidence(self, required, *, map_id: int) -> tuple[bool, tuple, dict]:
        details: dict[str, dict] = {}
        fingerprint: list[tuple] = []
        ready = True
        for lane in required:
            projection = getattr(lane, "projection", None)
            health_fn = getattr(projection, "health", None)
            if not callable(health_fn):
                details[lane.account_id] = {"ready": False, "blockers": ["PROJECTION_HEALTH_UNAVAILABLE"]}
                ready = False
                fingerprint.append((lane.account_id, "UNAVAILABLE"))
                continue
            try:
                health = dict(health_fn() or {})
            except Exception as exc:
                details[lane.account_id] = {
                    "ready": False, "blockers": ["PROJECTION_HEALTH_ERROR"],
                    "error": f"{type(exc).__name__}: {exc}",
                }
                ready = False
                fingerprint.append((lane.account_id, "ERROR"))
                continue

            blockers: list[str] = []
            if health.get("available") is not True:
                blockers.append("BRIDGE_UNAVAILABLE")
            if str(health.get("map_context") or "").upper() != "WORLD":
                blockers.append("MAP_CONTEXT_NOT_WORLD")
            try:
                loaded_map_id = int(health.get("loaded_map_id"))
            except (TypeError, ValueError):
                loaded_map_id = None
            if loaded_map_id != int(map_id):
                blockers.append("PROJECTION_MAP_MISMATCH")
            if health.get("direct_ready") is not True:
                blockers.append("DIRECT_PROJECTION_NOT_READY")
            if health.get("source_verified") is not True:
                blockers.append("PROJECTION_SOURCE_UNVERIFIED")

            lane_ready = not blockers
            ready = ready and lane_ready
            details[lane.account_id] = {
                "ready": lane_ready,
                "blockers": blockers,
                "loaded_map_id": loaded_map_id,
                "map_context": health.get("map_context"),
                "map_generation": health.get("map_generation"),
                "coordinate_generation": health.get("coordinate_generation"),
                "direct_ready": health.get("direct_ready"),
                "source_verified": health.get("source_verified"),
            }
            fingerprint.append((
                lane.account_id, loaded_map_id, str(health.get("map_context") or "").upper(),
                health.get("map_generation"), health.get("coordinate_generation"),
                bool(health.get("direct_ready")), bool(health.get("source_verified")),
            ))
        return ready, tuple(fingerprint), details

    def _post_fight_reentry_gate(self, required, snapshots) -> WorldWorkflowResult | None:
        """Hold every world action until post-fight world truth is fully stable.

        This gate intentionally runs before normal fight handoff, party map
        convergence, route movement and target selection.  Once an outcome has
        been committed, a stale fight flag or temporarily divergent/unknown MapId
        is evidence that world re-entry is still settling, not authority to send
        another physical action.
        """
        if not self._reentry_required:
            return None

        now = float(self.clock())
        started = now if self._reentry_started is None else float(self._reentry_started)
        total_elapsed = max(0.0, now - started)
        observation_gap = (
            None if self._reentry_last_observed is None
            else max(0.0, now - float(self._reentry_last_observed))
        )
        self._reentry_last_observed = now

        fight_details = {}
        fight_present = False
        for lane in required:
            snapshot = snapshots[lane.account_id]
            present = bool(snapshot.fight.present)
            fight_present = fight_present or present
            fight_details[lane.account_id] = {
                "fight_present": present,
                "fight_instance_id": getattr(snapshot.fight, "fight_instance_id", None),
            }

        maps = {lane.account_id: self._known_map(snapshots[lane.account_id]) for lane in required}
        known_maps = [value for value in maps.values() if value is not None]
        leader = self._leader_lane()
        leader_map = maps.get(leader.account_id)
        maps_known = len(known_maps) == len(required)
        maps_consistent = maps_known and len(set(known_maps)) == 1

        leader_world = snapshots[leader.account_id].world
        roster_complete = bool(getattr(leader_world, "monster_groups_complete", False)) if leader_map is not None else False

        projection_ready = False
        projection: dict = {}
        fingerprint: tuple = ()
        if maps_consistent and leader_map is not None:
            projection_ready, fingerprint, projection = self._projection_reentry_evidence(
                required, map_id=int(leader_map)
            )

        if fight_present:
            stage_reason = "POST_FIGHT_FIGHT_EXIT_SETTLING"
            missing_boundary = "CANONICAL_FIGHT_EXIT"
            owner = "CANONICAL_FIGHT_LIFECYCLE"
            stage_action = {
                "status": "WAIT", "reason": stage_reason, "fights": fight_details,
                "reentry_reason": self._reentry_reason,
            }
        elif not maps_known:
            stage_reason = "POST_FIGHT_WORLD_MAP_SETTLING"
            missing_boundary = "CANONICAL_WORLD_MAP_ID"
            owner = "CANONICAL_WORLD_REENTRY"
            stage_action = {
                "status": "WAIT", "reason": stage_reason, "maps": maps,
                "reentry_reason": self._reentry_reason,
            }
        elif not maps_consistent:
            stage_reason = "POST_FIGHT_WORLD_MAP_DIVERGENCE_SETTLING"
            missing_boundary = "CANONICAL_WORLD_MAP_CONSISTENCY"
            owner = "CANONICAL_WORLD_REENTRY"
            stage_action = {
                "status": "WAIT", "reason": stage_reason, "maps": maps,
                "reentry_reason": self._reentry_reason,
            }
        elif not roster_complete:
            stage_reason = "POST_FIGHT_WORLD_ROSTER_SETTLING"
            missing_boundary = "CANONICAL_WORLD_MONSTER_ROSTER"
            owner = "CANONICAL_WORLD_REENTRY"
            stage_action = {
                "status": "WAIT", "reason": stage_reason, "map_id": int(leader_map),
                "reentry_reason": self._reentry_reason,
            }
        elif not projection_ready:
            stage_reason = "POST_FIGHT_PROJECTION_SETTLING"
            missing_boundary = "POST_FIGHT_WORLD_INTERACTION_READINESS"
            owner = "WORLD_PROJECTION_REENTRY"
            stage_action = {
                "status": "WAIT", "reason": stage_reason, "map_id": int(leader_map),
                "projection": projection, "reentry_reason": self._reentry_reason,
            }
        else:
            stage_reason = "POST_FIGHT_WORLD_REENTRY_STABILIZING"
            missing_boundary = "POST_FIGHT_WORLD_INTERACTION_STABILITY"
            owner = "WORLD_PROJECTION_REENTRY"
            stage_action = {}

        # Missing readiness is bounded from fight completion.  Once every required
        # lane is already WORLD-ready, do not let a delayed parent poll convert
        # healthy evidence into a timeout.  R5.121 checked the absolute timeout
        # before consuming the second stable observation, so diagnostic I/O stalls
        # could kill an otherwise recovered campaign.
        if stage_reason != "POST_FIGHT_WORLD_REENTRY_STABILIZING":
            self._reentry_stable_since = None
            self._reentry_ready_started = None
            self._reentry_fingerprint = fingerprint if projection else None
            self._reentry_release_pending = False
            stage_action = {
                **stage_action,
                "elapsed_seconds": total_elapsed,
                "timeout_seconds": self.world_reentry_timeout_seconds,
                "observer_gap_seconds": observation_gap,
            }
            if total_elapsed >= self.world_reentry_timeout_seconds:
                return WorldWorkflowResult(
                    WorldWorkflowState.FAILED,
                    {
                        **stage_action,
                        "status": "FAILED",
                        "failure_code": "POST_FIGHT_WORLD_REENTRY_TIMEOUT",
                        "reason": "POST_FIGHT_WORLD_REENTRY_TIMEOUT",
                        "blocked_stage": stage_reason,
                        "first_missing_boundary": missing_boundary,
                        "likely_owner": owner,
                        "maps": maps,
                        "fights": fight_details,
                        "projection_ready": projection_ready,
                        "projection": projection,
                    },
                    "POST_FIGHT_WORLD_REENTRY_TIMEOUT",
                )
            return WorldWorkflowResult(WorldWorkflowState.WORLD_SETTLING, stage_action, stage_reason)

        if self._reentry_ready_started is None:
            self._reentry_ready_started = now
        if self._reentry_fingerprint != fingerprint or self._reentry_stable_since is None:
            self._reentry_fingerprint = fingerprint
            self._reentry_stable_since = now
            self._reentry_release_pending = False
        stable_elapsed = max(0.0, now - float(self._reentry_stable_since))
        ready_elapsed = max(0.0, now - float(self._reentry_ready_started))

        # A WORLD-ready surface that keeps changing generation/fingerprint forever
        # is still unsafe.  Bound *ready instability* independently from the time
        # spent waiting for fight exit/map/projection readiness.  This keeps the
        # gate fail-closed without making correctness depend on parent poll cadence.
        if (
            stable_elapsed < self.world_reentry_stability_seconds
            and ready_elapsed >= self.world_reentry_timeout_seconds
        ):
            return WorldWorkflowResult(
                WorldWorkflowState.FAILED,
                {
                    "status": "FAILED",
                    "failure_code": "POST_FIGHT_WORLD_REENTRY_STABILITY_TIMEOUT",
                    "reason": "POST_FIGHT_WORLD_REENTRY_STABILITY_TIMEOUT",
                    "blocked_stage": stage_reason,
                    "elapsed_seconds": total_elapsed,
                    "ready_elapsed_seconds": ready_elapsed,
                    "stable_seconds": stable_elapsed,
                    "timeout_seconds": self.world_reentry_timeout_seconds,
                    "first_missing_boundary": "POST_FIGHT_WORLD_INTERACTION_STABILITY",
                    "likely_owner": "WORLD_PROJECTION_REENTRY",
                    "maps": maps,
                    "fights": fight_details,
                    "projection_ready": projection_ready,
                    "projection": projection,
                    "observer_gap_seconds": observation_gap,
                },
                "POST_FIGHT_WORLD_REENTRY_STABILITY_TIMEOUT",
            )

        if stable_elapsed < self.world_reentry_stability_seconds:
            return WorldWorkflowResult(
                WorldWorkflowState.WORLD_SETTLING,
                {
                    "status": "WAIT",
                    "reason": "POST_FIGHT_WORLD_REENTRY_STABILIZING",
                    "map_id": int(leader_map),
                    "stable_seconds": stable_elapsed,
                    "required_stable_seconds": self.world_reentry_stability_seconds,
                    "elapsed_seconds": total_elapsed,
                    "ready_elapsed_seconds": ready_elapsed,
                    "observer_gap_seconds": observation_gap,
                    "deadline_crossed_with_ready_evidence": total_elapsed >= self.world_reentry_timeout_seconds,
                    "projection": projection,
                    "reentry_reason": self._reentry_reason,
                },
                "POST_FIGHT_WORLD_REENTRY_STABILIZING",
            )

        # Crossing the continuous-stability threshold does not itself authorize
        # physical input.  Return one action-free release observation, then
        # require the *next* parent tick to re-read the same WORLD projection
        # fingerprint before the gate is removed.  This protects the exact live
        # race where canonical/world projection became available just before the
        # rendered client was actually ready to accept another monster click.
        if not self._reentry_release_pending:
            self._reentry_release_pending = True
            return WorldWorkflowResult(
                WorldWorkflowState.WORLD_SETTLING,
                {
                    "status": "WAIT",
                    "reason": "POST_FIGHT_WORLD_REENTRY_VERIFIED",
                    "map_id": int(leader_map),
                    "stable_seconds": stable_elapsed,
                    "required_stable_seconds": self.world_reentry_stability_seconds,
                    "elapsed_seconds": total_elapsed,
                    "ready_elapsed_seconds": ready_elapsed,
                    "observer_gap_seconds": observation_gap,
                    "deadline_crossed_with_ready_evidence": total_elapsed >= self.world_reentry_timeout_seconds,
                    "release_observation_required": True,
                    "projection": projection,
                    "reentry_reason": self._reentry_reason,
                },
                "POST_FIGHT_WORLD_REENTRY_VERIFIED",
            )

        self._reentry_required = False
        self._reentry_started = None
        self._reentry_stable_since = None
        self._reentry_ready_started = None
        self._reentry_last_observed = None
        self._reentry_fingerprint = None
        self._reentry_release_pending = False
        self._reentry_reason = None
        return None

    @staticmethod
    def _known_map(snapshot) -> int | None:
        value = snapshot.world.map_id
        if value.status is ValueStatus.KNOWN and value.value is not None:
            return int(value.value)
        return None

    def _required(self):
        return tuple(lane for lane in self.party.lanes if lane.required)

    def _leader_lane(self):
        leader = getattr(self.party, "leader", None)
        if leader is not None:
            return leader
        return self._required()[0]

    def _directional_route_decision(self, current: int):
        if self.route_runtime is None:
            return None
        return self.route_runtime.decide(int(current))

    def _next_map(self, current: int) -> int | None:
        if self.route_runtime is not None:
            return self.route_runtime.decide(int(current)).target_map_id
        if not self.route_map_ids:
            return None
        current = int(current)

        # Finish an already-selected waypoint before choosing another one. This
        # makes non-adjacent configured waypoints deterministic while Execution
        # advances exactly one Kernel edge per call.
        if self._route_target_map_id is not None:
            if current != self._route_target_map_id:
                return int(self._route_target_map_id)
            self._route_cursor_index = self._route_target_index
            self._route_target_index = None
            self._route_target_map_id = None

        if len(self.route_map_ids) == 1:
            only = int(self.route_map_ids[0])
            if current == only:
                self._route_cursor_index = 0
                return None
            self._route_target_index = 0
            self._route_target_map_id = only
            return only

        if self._route_cursor_index is not None:
            expected = int(self.route_map_ids[self._route_cursor_index])
            if current != expected:
                # External/manual displacement invalidates the cursor. Re-acquire
                # from the current route map when possible, otherwise head to the
                # configured first waypoint.
                self._route_cursor_index = None

        if self._route_cursor_index is None:
            try:
                self._route_cursor_index = self.route_map_ids.index(current)
            except ValueError:
                self._route_target_index = 0
                self._route_target_map_id = int(self.route_map_ids[0])
                return int(self._route_target_map_id)

        # Skip redundant consecutive/same-map waypoints without asking the
        # execution layer to "transition" to the map it is already on.  This
        # makes operator routes tolerant of duplicate rows while preserving a
        # deterministic cursor.  A route containing only one distinct map is
        # therefore equivalent to a one-map patrol and waits for respawn.
        next_index = self._route_cursor_index + 1
        visited = 0
        while visited < len(self.route_map_ids):
            if next_index >= len(self.route_map_ids):
                if not self.route_loop:
                    return None
                next_index = 0
            candidate = int(self.route_map_ids[next_index])
            if candidate != current:
                self._route_target_index = next_index
                self._route_target_map_id = candidate
                return candidate
            self._route_cursor_index = next_index
            next_index += 1
            visited += 1
        return None

    def inspect(self) -> WorldWorkflowResult:
        required = self._required()
        if not required:
            return WorldWorkflowResult(WorldWorkflowState.FAILED, {"status":"BLOCKED","reason":"NO_REQUIRED_ACCOUNTS"}, "NO_REQUIRED_ACCOUNTS")
        snapshots = {lane.account_id: lane.snapshot() for lane in required}

        # Outcome commitment arms a hard world-reentry barrier.  Run it before
        # *any* normal world/fight routing so stale post-fight lifecycle/map
        # observations can never authorize convergence or target input.
        reentry = self._post_fight_reentry_gate(required, snapshots)
        if reentry is not None:
            return reentry

        if any(snapshot.fight.present for snapshot in snapshots.values()):
            return WorldWorkflowResult(WorldWorkflowState.FIGHT_HANDOFF, {"status":"READY","reason":"FIGHT_PRESENT"}, "FIGHT_PRESENT", next_allowed_commands=("FIGHT_WORKFLOW",))

        maps = {account: self._known_map(snapshot) for account, snapshot in snapshots.items()}
        leader = self._leader_lane()
        leader_map = maps.get(leader.account_id)
        if leader_map is None:
            return WorldWorkflowResult(WorldWorkflowState.WORLD_SETTLING, {"status":"WAIT","reason":"LEADER_MAP_UNKNOWN","maps":maps}, "LEADER_MAP_UNKNOWN")
        if any(value is None or value != leader_map for value in maps.values()):
            return WorldWorkflowResult(
                WorldWorkflowState.PARTY_CONVERGENCE,
                {"status":"READY","reason":"PARTY_MAP_DIVERGED","leader_map_id":leader_map,"maps":maps},
                "PARTY_MAP_DIVERGED",
                next_allowed_commands=("CONVERGE_PARTY",),
            )

        world = snapshots[leader.account_id].world
        if not bool(world.monster_groups_complete):
            return WorldWorkflowResult(WorldWorkflowState.OBSERVE_MAP, {"status":"WAIT","reason":"MONSTER_ROSTER_INCOMPLETE","map_id":leader_map}, "MONSTER_ROSTER_INCOMPLETE")

        # Route intent is party-level. Directional routes keep an explicit edge
        # cursor and recover to one unambiguous anchor instead of guessing route
        # position from a repeated MapId. Legacy waypoint routes retain their old
        # compatibility behavior until migrated.
        route_decision = self._directional_route_decision(leader_map)
        if route_decision is not None and route_decision.recovery and route_decision.target_map_id is not None:
            return WorldWorkflowResult(
                WorldWorkflowState.SEARCH_TARGET,
                {
                    "status": "READY",
                    "reason": "OFF_ROUTE_RECOVERY",
                    "map_id": leader_map,
                    "next_map_id": int(route_decision.target_map_id),
                    **route_decision.to_dict(),
                    "route_runtime": self.route_runtime.status(),
                },
                "OFF_ROUTE_RECOVERY",
                next_allowed_commands=("TRANSITION",),
            )
        if self.route_runtime is None and self.route_map_ids and leader_map not in self.route_map_ids and self._route_target_map_id is None:
            entry_map = self._next_map(leader_map)
            if entry_map is not None:
                return WorldWorkflowResult(
                    WorldWorkflowState.SEARCH_TARGET,
                    {
                        "status": "READY",
                        "reason": "OFF_ROUTE_CONVERGENCE",
                        "map_id": leader_map,
                        "next_map_id": entry_map,
                    },
                    "OFF_ROUTE_CONVERGENCE",
                    next_allowed_commands=("TRANSITION",),
                )

        candidates = self.target_policy.candidates(world.monster_groups)
        target = candidates[0] if candidates else None
        if target is not None:
            candidate_payload = [
                {
                    "group_id": int(item.group_id),
                    "cell_id": int(item.cell_id.value),
                    "monster_count": len(tuple(item.member_ids or ())),
                }
                for item in candidates
            ]
            return WorldWorkflowResult(
                WorldWorkflowState.SELECT_TARGET,
                {
                    "status":"READY",
                    "reason":"TARGET_SELECTED",
                    "map_id":leader_map,
                    "target_group_id":int(target.group_id),
                    "target_cell_id":int(target.cell_id.value),
                    "monster_count":len(tuple(target.member_ids or ())),
                    "candidate_groups": candidate_payload,
                },
                "TARGET_SELECTED",
                account_id=leader.account_id,
                next_allowed_commands=("LAUNCH_FIGHT",),
            )
        if route_decision is not None:
            next_map = route_decision.target_map_id
            route_meta = {**route_decision.to_dict(), "route_runtime": self.route_runtime.status()}
        else:
            next_map = self._next_map(leader_map)
            route_meta = {}
        if next_map is None:
            return WorldWorkflowResult(
                WorldWorkflowState.WAIT_RESPAWN,
                {"status":"WAIT","reason":"NO_TARGET_NO_ROUTE","map_id":leader_map, **route_meta},
                "NO_TARGET_NO_ROUTE",
            )
        return WorldWorkflowResult(
            WorldWorkflowState.SEARCH_TARGET,
            {"status":"READY","reason":"NO_TARGET","map_id":leader_map,"next_map_id":int(next_map), **route_meta},
            "NO_TARGET",
            next_allowed_commands=("TRANSITION",),
        )

    def advance(self, *, runtime_context: dict | None = None) -> WorldWorkflowResult:
        state = self.inspect()
        if state.state is WorldWorkflowState.PARTY_CONVERGENCE:
            target = int(state.action["leader_map_id"])
            result = dict(self.mission.change_world_map(target, **({"runtime_context":runtime_context} if runtime_context else {})))
            return WorldWorkflowResult(WorldWorkflowState.PARTY_CONVERGENCE, result, str(result.get("detail") or "PARTY_CONVERGENCE"), next_allowed_commands=("CONVERGE_PARTY",))
        if state.state is WorldWorkflowState.SEARCH_TARGET:
            target = int(state.action["next_map_id"])
            result = dict(self.mission.change_world_map(target, **({"runtime_context":runtime_context} if runtime_context else {})))
            return WorldWorkflowResult(WorldWorkflowState.TRANSITION, {**result,"target_map_id":target}, str(result.get("detail") or "TRANSITION"), next_allowed_commands=("OBSERVE_MAP",))
        if state.state is WorldWorkflowState.SELECT_TARGET:
            launcher = getattr(self.mission, "launch_world_target_candidates", None)
            if not callable(launcher):
                # Compatibility for narrow test/legacy composition. Production
                # party missions provide the parent-owned target launcher.
                return state
            candidate_ids = tuple(
                int(item["group_id"])
                for item in (state.action.get("candidate_groups") or ())
                if isinstance(item, dict) and item.get("group_id") is not None
            )
            if not candidate_ids and state.action.get("target_group_id") is not None:
                candidate_ids = (int(state.action["target_group_id"]),)
            result = dict(launcher(
                candidate_ids, **({"runtime_context": runtime_context} if runtime_context else {})
            ))
            return WorldWorkflowResult(
                WorldWorkflowState.ACQUIRE_TARGET,
                {**result, "candidate_group_ids": list(candidate_ids)},
                str(result.get("detail") or "WORLD_TARGET_ACQUISITION"),
                account_id=(str(result.get("account_id")) if result.get("account_id") is not None else state.account_id),
                next_allowed_commands=("OBSERVE_MAP", "FIGHT_WORKFLOW"),
            )
        return state

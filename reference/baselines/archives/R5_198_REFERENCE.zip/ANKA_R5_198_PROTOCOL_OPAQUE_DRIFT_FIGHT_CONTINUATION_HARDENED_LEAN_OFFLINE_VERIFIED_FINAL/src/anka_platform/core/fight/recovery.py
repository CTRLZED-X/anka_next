from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Mapping

from anka_platform.core.fight.action_outcome import CombatActionOutcome, CombatActionPhase
from anka_platform.core.fight.planner_contract import (
    PlannerDisposition, PlannerFailureClass, PlannerResultView,
)


class CombatFailureClass(StrEnum):
    RECOVERABLE_ACTION_FAILURE = "RECOVERABLE_ACTION_FAILURE"
    INVALID_FIGHT_AI_DECISION = "INVALID_FIGHT_AI_DECISION"
    TEMPORARY_STATE_UNCERTAINTY = "TEMPORARY_STATE_UNCERTAINTY"
    PLANNER_COMPUTATION_INCOMPLETE = "PLANNER_COMPUTATION_INCOMPLETE"
    DECODER_STATE_SYNC_DELAY = "DECODER_STATE_SYNC_DELAY"
    EXECUTOR_FAILURE = "EXECUTOR_FAILURE"
    ACCOUNT_CONTROL_FAILURE = "ACCOUNT_CONTROL_FAILURE"
    UNCERTAIN_PHYSICAL_INPUT = "UNCERTAIN_PHYSICAL_INPUT"
    PERMANENT_COMBAT_FAILURE = "PERMANENT_COMBAT_FAILURE"
    MISSION_FATAL_FAILURE = "MISSION_FATAL_FAILURE"


class RecoveryDirectiveKind(StrEnum):
    WAIT_FOR_EVIDENCE = "WAIT_FOR_EVIDENCE"
    REPLAN_CURRENT_FRAME = "REPLAN_CURRENT_FRAME"
    EXCLUDE_ACTION_CURRENT_TURN = "EXCLUDE_ACTION_CURRENT_TURN"
    FALLBACK_END_TURN = "FALLBACK_END_TURN"
    FENCE_UNCERTAIN_INPUT = "FENCE_UNCERTAIN_INPUT"
    ABORT_FIGHT = "ABORT_FIGHT"
    ABORT_MISSION = "ABORT_MISSION"


@dataclass(frozen=True, slots=True)
class RecoveryDirective:
    kind: RecoveryDirectiveKind
    failure_class: CombatFailureClass
    reason: str
    safe_to_continue: bool
    quarantine_candidate: bool = False
    planner_replan: bool = False

    def as_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind.value,
            "failure_class": self.failure_class.value,
            "reason": self.reason,
            "safe_to_continue": bool(self.safe_to_continue),
            "quarantine_candidate": bool(self.quarantine_candidate),
            "planner_replan": bool(self.planner_replan),
        }


class TurnRecoveryPolicy:
    """Classify combat failures by causality instead of one generic retry bit."""

    _SAFE_DECISION_FALLBACK_REASONS = frozenset({
        "CURRENT_AP_UNKNOWN",
        "CURRENT_MP_UNKNOWN",
        "FIGHT_CONTEXT_UNAVAILABLE",
        "FIGHT_MAP_UNKNOWN",
        "SPELL_COVERAGE_INCOMPLETE",
        "DECISION_BUDGET_UNAVAILABLE",
    })

    @staticmethod
    def classify_decision_failure(reason: str) -> CombatFailureClass:
        token = str(reason or "").split(":", 1)[0].strip()
        if token in {"SPELL_COVERAGE_INCOMPLETE", "DECISION_BUDGET_UNAVAILABLE"}:
            return CombatFailureClass.PLANNER_COMPUTATION_INCOMPLETE
        if token in {
            "CURRENT_AP_UNKNOWN", "CURRENT_MP_UNKNOWN", "FIGHT_CONTEXT_UNAVAILABLE",
            "FIGHT_MAP_UNKNOWN", "DECISION_STALE_COMBAT_FRAME",
            "DECISION_END_FRAME_UNAVAILABLE", "TEAM_OBSERVATION_NOT_CONVERGED",
        }:
            return CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY
        if token in {"ACTIVE_ACTOR_UNKNOWN", "NOT_LOCAL_TURN", "DECISION_STALE_TURN"}:
            return CombatFailureClass.DECODER_STATE_SYNC_DELAY
        if token in {
            "INVALID_MOVE_DECISION", "UNKNOWN_DECISION",
            "NO_CONFIRMED_ENEMY_TARGET",
        }:
            return CombatFailureClass.INVALID_FIGHT_AI_DECISION
        if token in {
            "LIVE_SPELL_BAR_MISMATCH", "PROFILE_SPELL_BAR_INVALID",
            "PROFILE_SPELL_BAR_EMPTY", "PROTOCOL_SLOT_RESOLVER_UNAVAILABLE",
        }:
            return CombatFailureClass.PERMANENT_COMBAT_FAILURE
        return CombatFailureClass.PERMANENT_COMBAT_FAILURE

    @staticmethod
    def _outcome(result: CombatActionOutcome | Mapping[str, object]) -> CombatActionOutcome:
        return result if isinstance(result, CombatActionOutcome) else CombatActionOutcome.from_mapping(result)

    @staticmethod
    def classify_action_failure(result: CombatActionOutcome | Mapping[str, object]) -> CombatFailureClass | None:
        outcome = TurnRecoveryPolicy._outcome(result)
        code = outcome.failure_code
        if outcome.phase is CombatActionPhase.ACCEPTED:
            return None
        if outcome.phase in {CombatActionPhase.RECONCILING, CombatActionPhase.AWAITING_SETTLEMENT}:
            return CombatFailureClass.DECODER_STATE_SYNC_DELAY
        if outcome.phase is CombatActionPhase.PHYSICAL_UNCERTAIN:
            return CombatFailureClass.UNCERTAIN_PHYSICAL_INPUT
        if code == "INVALID_COMBAT_ACTION_CONTRACT":
            return CombatFailureClass.INVALID_FIGHT_AI_DECISION
        if code in {"CAST_ADMISSION_UNKNOWN", "MOVE_ADMISSION_UNKNOWN"}:
            return CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY
        if code == "WINDOW_FOCUS_FAILED" and outcome.retry_allowed is True and outcome.no_physical_input:
            return CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY
        if code in {
            "CAST_ADMISSION_REJECTED", "MOVE_ADMISSION_REJECTED", "CLIENT_CAST_REJECTED",
            "SPELL_TARGET_EMPTY_NON_WALKABLE",
        }:
            return CombatFailureClass.RECOVERABLE_ACTION_FAILURE
        if outcome.phase is CombatActionPhase.CONTROL_FAILURE:
            return CombatFailureClass.ACCOUNT_CONTROL_FAILURE
        if code in {
            "PROJECTION_STALE", "PROJECTION_ENTITY_UNVERIFIED", "PROJECTION_CELL_UNAVAILABLE",
            "PROJECTION_OUTSIDE_VIEWPORT", "SPELL_TARGET_INTERACTION_UNVERIFIED",
            "INPUT_NOT_SENT",
        }:
            return CombatFailureClass.EXECUTOR_FAILURE
        if code in {"KERNEL_UNKNOWN", "KERNEL_CONTEXT_INCOMPLETE"}:
            return CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY
        if code in {"KERNEL_UNSUPPORTED"}:
            return CombatFailureClass.PERMANENT_COMBAT_FAILURE
        if outcome.phase in {CombatActionPhase.FAILED, CombatActionPhase.REJECTED_NOT_SENT}:
            return CombatFailureClass.PERMANENT_COMBAT_FAILURE
        return None

    @classmethod
    def classify_planner_result(
        cls, result: PlannerResultView, *, repeated_same_frame_count: int,
    ) -> RecoveryDirective | None:
        """Classify current planner orchestration without interpreting reason text."""
        disposition = result.disposition
        failure_class = result.failure_class
        diagnostic = str(result.reason or disposition.value)

        if disposition is PlannerDisposition.CONTINUE_PLANNING:
            return RecoveryDirective(
                RecoveryDirectiveKind.REPLAN_CURRENT_FRAME,
                CombatFailureClass.PLANNER_COMPUTATION_INCOMPLETE,
                f"{diagnostic}: computational planner slice incomplete; continue progressive search on the same semantic frame",
                True, planner_replan=True,
            )
        if disposition is PlannerDisposition.NO_MATERIAL_ACTION:
            return RecoveryDirective(
                RecoveryDirectiveKind.FALLBACK_END_TURN,
                CombatFailureClass.RECOVERABLE_ACTION_FAILURE,
                f"{diagnostic}: planner certified no material action",
                True,
            )
        if (
            disposition is PlannerDisposition.WAIT_EXTERNAL
            and failure_class is PlannerFailureClass.TRANSIENT_EXTERNAL
        ):
            if int(repeated_same_frame_count) <= 2:
                return RecoveryDirective(
                    RecoveryDirectiveKind.WAIT_FOR_EVIDENCE,
                    CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                    f"{diagnostic}: allow a bounded external evidence refresh before abandoning the turn",
                    True,
                )
            return RecoveryDirective(
                RecoveryDirectiveKind.FALLBACK_END_TURN,
                CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                f"{diagnostic}: repeated same-frame external uncertainty; preserve the fight with END_TURN",
                True,
            )
        if (
            disposition is PlannerDisposition.FAULT
            and failure_class in {PlannerFailureClass.POLICY_FAULT, PlannerFailureClass.CONTRACT_VIOLATION}
        ):
            return RecoveryDirective(
                RecoveryDirectiveKind.FALLBACK_END_TURN,
                CombatFailureClass.INVALID_FIGHT_AI_DECISION,
                f"{diagnostic}: contain planner fault to the current turn",
                True,
            )
        return None

    @classmethod
    def classify_decision_block(
        cls, reason: str, *, repeated_same_frame_count: int,
        planner_disposition: str | None = None,
        planner_failure_class: str | None = None,
        compatibility_adapter: bool | None = None,
    ) -> RecoveryDirective | None:
        """Compatibility adapter for pre-R5.148 callers.

        Current production passes ``PlannerResultView`` to
        :meth:`classify_planner_result`; only historical/direct-dict inputs need
        reason-token interpretation here.
        """
        legacy_compatibility = bool(compatibility_adapter) or (
            compatibility_adapter is None
            and planner_disposition in (None, "")
            and planner_failure_class in (None, "")
        )
        if not legacy_compatibility:
            try:
                disposition = PlannerDisposition(str(planner_disposition or "").strip().upper())
            except ValueError:
                disposition = PlannerDisposition.FAULT
            try:
                failure_class = (
                    None if not planner_failure_class
                    else PlannerFailureClass(str(planner_failure_class).strip().upper())
                )
            except ValueError:
                failure_class = None
            return cls.classify_planner_result(
                PlannerResultView(
                    disposition=disposition,
                    reason=str(reason or ""),
                    failure_class=failure_class,
                    compatibility_adapter=False,
                ),
                repeated_same_frame_count=repeated_same_frame_count,
            )

        token = str(reason or "").split(":", 1)[0].strip()
        if token in {"SPELL_COVERAGE_INCOMPLETE", "DECISION_BUDGET_UNAVAILABLE"}:
            return RecoveryDirective(
                RecoveryDirectiveKind.REPLAN_CURRENT_FRAME,
                CombatFailureClass.PLANNER_COMPUTATION_INCOMPLETE,
                f"{token}: computational planner slice incomplete; continue progressive search on the same semantic frame",
                True, planner_replan=True,
            )
        if token not in cls._SAFE_DECISION_FALLBACK_REASONS:
            return None
        if int(repeated_same_frame_count) <= 2:
            return RecoveryDirective(
                RecoveryDirectiveKind.WAIT_FOR_EVIDENCE,
                CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                f"{token}: allow a bounded Canonical evidence refresh before abandoning the turn",
                True,
            )
        return RecoveryDirective(
            RecoveryDirectiveKind.FALLBACK_END_TURN,
            CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
            f"{token}: repeated same-frame planner uncertainty; preserve the fight with END_TURN",
            True,
        )

    @staticmethod
    def classify_action_block(
        result: CombatActionOutcome | Mapping[str, object], *, repeated_same_frame_count: int,
    ) -> RecoveryDirective | None:
        outcome = TurnRecoveryPolicy._outcome(result)
        code = outcome.failure_code
        physical = outcome.physical_send_state
        semantic = outcome.semantic_send_state

        if outcome.phase is CombatActionPhase.AWAITING_SETTLEMENT:
            return RecoveryDirective(
                RecoveryDirectiveKind.WAIT_FOR_EVIDENCE,
                CombatFailureClass.DECODER_STATE_SYNC_DELAY,
                "server-confirmed action is waiting for decision-critical Canonical settlement",
                True,
            )

        if outcome.phase is CombatActionPhase.PHYSICAL_UNCERTAIN:
            return RecoveryDirective(
                RecoveryDirectiveKind.FENCE_UNCERTAIN_INPUT,
                CombatFailureClass.UNCERTAIN_PHYSICAL_INPUT,
                "physical input may have occurred without settled semantic causality",
                False,
            )

        if outcome.phase not in {
            CombatActionPhase.REJECTED_NOT_SENT,
            CombatActionPhase.SEMANTIC_REJECTED_SAFE,
        }:
            return None

        # A possible physical input can never be hidden behind an END_TURN or a
        # speculative retry. Preserve the causality fence.
        if physical in {"SENT", "UNCERTAIN"} and semantic in {"", "UNCERTAIN"}:
            return RecoveryDirective(
                RecoveryDirectiveKind.FENCE_UNCERTAIN_INPUT,
                CombatFailureClass.UNCERTAIN_PHYSICAL_INPUT,
                "physical input may have occurred without settled semantic causality",
                False,
            )

        if code == "INVALID_COMBAT_ACTION_CONTRACT" and physical in {"", "NOT_SENT"} and semantic in {"", "NOT_SENT"}:
            return RecoveryDirective(
                RecoveryDirectiveKind.EXCLUDE_ACTION_CURRENT_TURN,
                CombatFailureClass.INVALID_FIGHT_AI_DECISION,
                "local combat action contract is malformed; waiting for game evidence cannot repair it",
                True,
                quarantine_candidate=True,
            )

        if code == "WINDOW_FOCUS_FAILED" and outcome.retry_allowed is True and physical in {"", "NOT_SENT"}:
            return RecoveryDirective(
                RecoveryDirectiveKind.WAIT_FOR_EVIDENCE,
                CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                "target window identity is still valid but bounded foreground acquisition failed; retry on a later tick",
                True,
            )

        if code in {
            "CAST_ADMISSION_REJECTED", "MOVE_ADMISSION_REJECTED", "CLIENT_CAST_REJECTED",
            "SPELL_TARGET_INTERACTION_UNVERIFIED", "SPELL_TARGET_EMPTY_NON_WALKABLE",
        }:
            return RecoveryDirective(
                RecoveryDirectiveKind.EXCLUDE_ACTION_CURRENT_TURN,
                CombatFailureClass.RECOVERABLE_ACTION_FAILURE,
                code,
                True,
                quarantine_candidate=True,
            )

        if code in {"CAST_ADMISSION_UNKNOWN", "MOVE_ADMISSION_UNKNOWN"} and physical in {"", "NOT_SENT"} and semantic in {"", "NOT_SENT"}:
            if int(repeated_same_frame_count) <= 1:
                return RecoveryDirective(
                    RecoveryDirectiveKind.WAIT_FOR_EVIDENCE,
                    CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                    "admission is UNKNOWN before input; allow one bounded evidence refresh",
                    True,
                )
            return RecoveryDirective(
                RecoveryDirectiveKind.EXCLUDE_ACTION_CURRENT_TURN,
                CombatFailureClass.TEMPORARY_STATE_UNCERTAINTY,
                "same-frame admission stayed UNKNOWN with no physical input; exclude candidate and continue",
                True,
                quarantine_candidate=True,
            )

        if outcome.safe_replan:
            return RecoveryDirective(
                RecoveryDirectiveKind.REPLAN_CURRENT_FRAME,
                CombatFailureClass.RECOVERABLE_ACTION_FAILURE,
                code or "SAFE_REPLAN",
                True,
                quarantine_candidate=outcome.quarantine_candidate,
            )

        return None

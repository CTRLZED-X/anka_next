from __future__ import annotations

import inspect
from dataclasses import dataclass

from anka_platform.core.fight.planner_contract import PlannerInvocationContext, PassiveInvocationContext


@dataclass(frozen=True, slots=True)
class FightPolicyInvocationResult:
    decision: object
    compatibility_adapter: bool = False


class FightPolicyInvoker:
    """Invoke the current FightPolicy port while quarantining legacy signatures.

    Current policies accept one ``planner_context`` keyword. Historical tests/custom policies may still expose the old optional keywords.  Signature
    inspection lives only here so FightDecisionService and PartyCombatController
    remain independent from concrete planner call shapes.
    """

    def invoke(
        self,
        policy,
        *,
        kernel,
        snapshot,
        local_actor_id: int,
        profile,
        context: PlannerInvocationContext,
    ) -> FightPolicyInvocationResult:
        parameters = inspect.signature(policy.decide).parameters
        has_var_kwargs = any(
            param.kind is inspect.Parameter.VAR_KEYWORD
            for param in parameters.values()
        )
        if "planner_context" in parameters:
            return FightPolicyInvocationResult(
                policy.decide(
                    kernel, snapshot, local_actor_id, profile, planner_context=context
                ),
                compatibility_adapter=False,
            )

        kwargs = {}
        if "decision_deadline_monotonic" in parameters or has_var_kwargs:
            kwargs["decision_deadline_monotonic"] = context.decision_deadline_monotonic
        if "objective" in parameters or has_var_kwargs:
            kwargs["objective"] = context.objective
        if "excluded_action_fingerprints" in parameters or has_var_kwargs:
            kwargs["excluded_action_fingerprints"] = context.excluded_action_fingerprints
        return FightPolicyInvocationResult(
            policy.decide(kernel, snapshot, local_actor_id, profile, **kwargs),
            compatibility_adapter=True,
        )
    def invoke_passive(self, policy, *, context: PassiveInvocationContext) -> FightPolicyInvocationResult:
        parameters = inspect.signature(policy.decide).parameters
        has_var_kwargs = any(
            param.kind is inspect.Parameter.VAR_KEYWORD
            for param in parameters.values()
        )
        if "planner_context" in parameters:
            return FightPolicyInvocationResult(
                policy.decide(planner_context=context), compatibility_adapter=False
            )

        kwargs = {}
        legacy = {
            "current_cell_id": context.current_cell_id,
            "kernel": context.kernel,
            "snapshot": context.snapshot,
            "local_actor_id": context.local_actor_id,
            "objective": context.planner.objective,
            "decision_deadline_monotonic": context.planner.decision_deadline_monotonic,
        }
        for key, value in legacy.items():
            if key in parameters or has_var_kwargs:
                kwargs[key] = value
        return FightPolicyInvocationResult(
            policy.decide(**kwargs), compatibility_adapter=True
        )


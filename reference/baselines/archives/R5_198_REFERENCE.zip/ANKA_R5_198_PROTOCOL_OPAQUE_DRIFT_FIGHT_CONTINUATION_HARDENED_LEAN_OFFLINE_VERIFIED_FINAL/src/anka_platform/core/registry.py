from __future__ import annotations

from typing import Any

from anka_platform.core.ports.fight_policy import FightPolicy
from anka_platform.core.ports.passive_policy import PassiveTurnPolicy
from anka_platform.core.ports.team_strategy import TeamStrategy
from anka_platform.core.ports.placement_policy import PlacementPolicy
from anka_platform.core.ports.world_policy import WorldPolicy


class PolicyRegistry:
    """Auditable in-process policy registry with separate semantic namespaces."""

    def __init__(self) -> None:
        self._fight: dict[str, FightPolicy] = {}
        self._passive: dict[str, PassiveTurnPolicy] = {}
        self._team: dict[str, TeamStrategy] = {}
        self._placement: dict[str, PlacementPolicy] = {}
        self._world: dict[str, WorldPolicy] = {}
        self._fight_policy_sets: dict[str, Any] = {}

    @staticmethod
    def _key(policy_id: str) -> str:
        key = str(policy_id).strip()
        if not key:
            raise ValueError("policy_id must not be empty")
        return key

    @staticmethod
    def _register(store: dict[str, Any], policy_id: str, policy: Any) -> None:
        key = PolicyRegistry._key(policy_id)
        if key in store:
            raise ValueError(f"policy already registered: {key}")
        store[key] = policy

    @staticmethod
    def _require(store: dict[str, Any], policy_id: str, namespace: str) -> Any:
        key = PolicyRegistry._key(policy_id)
        try:
            return store[key]
        except KeyError as exc:
            raise KeyError(f"unknown {namespace} policy: {key}") from exc

    def register_fight(self, policy_id: str, policy: FightPolicy) -> None:
        if not isinstance(policy, FightPolicy):
            raise TypeError("fight policy must implement the FightPolicy port")
        self._register(self._fight, policy_id, policy)
    def register_passive(self, policy_id: str, policy: PassiveTurnPolicy) -> None:
        if not isinstance(policy, PassiveTurnPolicy):
            raise TypeError("passive policy must implement the PassiveTurnPolicy port")
        self._register(self._passive, policy_id, policy)

    def register_team(self, policy_id: str, policy: Any) -> None:
        # Keep the generic registry backward-compatible. Current-session port
        # validation belongs to SessionCompiler/preflight, where the selected
        # policy can fail before any live control is armed.
        self._register(self._team, policy_id, policy)

    def register_placement(self, policy_id: str, policy: Any) -> None:
        self._register(self._placement, policy_id, policy)

    def register_world(self, policy_id: str, policy: Any) -> None:
        self._register(self._world, policy_id, policy)
    def register_fight_policy_set(self, policy_set_id: str, policy_set: Any) -> None: self._register(self._fight_policy_sets, policy_set_id, policy_set)

    def require_fight(self, policy_id: str) -> FightPolicy: return self._require(self._fight, policy_id, "fight")
    def require_passive(self, policy_id: str) -> PassiveTurnPolicy: return self._require(self._passive, policy_id, "passive")
    def require_team(self, policy_id: str) -> TeamStrategy: return self._require(self._team, policy_id, "team")
    def require_placement(self, policy_id: str) -> PlacementPolicy: return self._require(self._placement, policy_id, "placement")
    def require_world(self, policy_id: str) -> WorldPolicy: return self._require(self._world, policy_id, "world")
    def require_fight_policy_set(self, policy_set_id: str) -> Any: return self._require(self._fight_policy_sets, policy_set_id, "fight policy set")

    def has_fight(self, policy_id: str | None) -> bool: return bool(policy_id) and str(policy_id).strip() in self._fight
    def has_passive(self, policy_id: str | None) -> bool: return bool(policy_id) and str(policy_id).strip() in self._passive
    def has_team(self, policy_id: str | None) -> bool: return bool(policy_id) and str(policy_id).strip() in self._team
    def has_placement(self, policy_id: str | None) -> bool: return bool(policy_id) and str(policy_id).strip() in self._placement
    def has_world(self, policy_id: str | None) -> bool: return bool(policy_id) and str(policy_id).strip() in self._world
    def has_fight_policy_set(self, policy_set_id: str | None) -> bool: return bool(policy_set_id) and str(policy_set_id).strip() in self._fight_policy_sets

    def fight_ids(self) -> tuple[str, ...]: return tuple(sorted(self._fight))
    def passive_ids(self) -> tuple[str, ...]: return tuple(sorted(self._passive))
    def team_ids(self) -> tuple[str, ...]: return tuple(sorted(self._team))
    def placement_ids(self) -> tuple[str, ...]: return tuple(sorted(self._placement))
    def world_ids(self) -> tuple[str, ...]: return tuple(sorted(self._world))
    def fight_policy_set_ids(self) -> tuple[str, ...]: return tuple(sorted(self._fight_policy_sets))



def build_r594_policy_registry(*, kernel=None) -> PolicyRegistry:
    """Historical import compatibility; current composition lives outside core.

    Kept dynamically resolved so the neutral core registry has no static import
    edge back into product policy composition.  New production code must import
    ``build_default_policy_registry`` from ``anka_platform.policy_composition``.
    """
    from importlib import import_module

    compose = import_module("anka_platform.policy_composition").build_r594_policy_registry
    return compose(kernel=kernel)

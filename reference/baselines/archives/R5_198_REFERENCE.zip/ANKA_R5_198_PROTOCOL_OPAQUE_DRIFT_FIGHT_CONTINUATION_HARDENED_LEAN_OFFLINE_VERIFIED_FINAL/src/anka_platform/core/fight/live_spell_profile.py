from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping

from anka_game_kernel.domain.ids import SpellId
from anka_platform.config import CombatProfileSettings, CombatSpellSettings


@dataclass(frozen=True, slots=True)
class LiveSpellVariantSubstitution:
    ui_slot: int
    protocol_slot: int
    configured_spell_id: int
    live_spell_id: int
    variant_group_id: int
    grade: int

    def as_dict(self) -> dict[str, int]:
        return {
            "ui_slot": int(self.ui_slot),
            "protocol_slot": int(self.protocol_slot),
            "configured_spell_id": int(self.configured_spell_id),
            "live_spell_id": int(self.live_spell_id),
            "variant_group_id": int(self.variant_group_id),
            "grade": int(self.grade),
        }


@dataclass(frozen=True, slots=True)
class LiveSpellProfileResolution:
    profile: CombatProfileSettings
    substitutions: tuple[LiveSpellVariantSubstitution, ...] = ()
    mismatches: tuple[dict[str, object], ...] = ()

    @property
    def accepted(self) -> bool:
        return not self.mismatches

    @property
    def verification(self) -> str:
        if self.mismatches:
            return "LIVE_SPELL_BAR_MISMATCH"
        if self.substitutions:
            return "LIVE_VERIFIED_VARIANT_ADAPTED"
        return "LIVE_VERIFIED"


def _variant_index(kernel) -> dict[int, tuple[int, frozenset[int]]]:
    """Return spell id -> (variant group id, group spell ids).

    The Kernel's static catalog is the only authority for variant equivalence.  A
    missing/unknown group never degrades to name/slot heuristics.
    """

    index: dict[int, tuple[int, frozenset[int]]] = {}
    registry = getattr(kernel, "spell_variants", None)
    if registry is None:
        return index
    for group in registry:
        ids = frozenset(int(item) for item in group.spell_ids)
        group_id = int(group.variant_id)
        for spell_id in ids:
            index[spell_id] = (group_id, ids)
    return index


def _grade_available(kernel, *, spell_id: int, grade: int) -> bool:
    registry = getattr(kernel, "spells", None)
    if registry is None:
        return False
    definition = registry.get(SpellId(int(spell_id)))
    if definition is None:
        return False
    return any(int(item.grade) == int(grade) for item in definition.grades)


def resolve_live_spell_profile(
    *,
    kernel,
    profile: CombatProfileSettings,
    observed_by_protocol_slot: Mapping[int, int],
    protocol_slot_for_ui_slot: Callable[[int], int],
) -> LiveSpellProfileResolution:
    """Reconcile configured slots with the authoritative live bar.

    Exact spell IDs are preferred.  A different live spell is accepted only when
    Kernel static evidence proves that it is a sibling from the same spell-variant
    group *and* the configured grade is valid for the equipped sibling.  The
    returned profile replaces the configured ID with the live ID, ensuring all
    later legality/effect/scoring work uses the mechanics that are actually on the
    bar rather than pretending sibling variants are mechanically equivalent.
    """

    variants = _variant_index(kernel)
    replacements: dict[int, CombatSpellSettings] = {}
    substitutions: list[LiveSpellVariantSubstitution] = []
    mismatches: list[dict[str, object]] = []

    for spell in profile.enabled_spells:
        ui_slot = int(spell.slot_index)
        protocol_slot = int(protocol_slot_for_ui_slot(ui_slot))
        expected = int(spell.spell_id)
        actual_raw = observed_by_protocol_slot.get(protocol_slot)
        actual = None if actual_raw is None else int(actual_raw)
        if actual == expected:
            continue

        mismatch: dict[str, object] = {
            "ui_slot": ui_slot,
            "protocol_slot": protocol_slot,
            "expected_spell_id": expected,
            "observed_spell_id": actual,
        }
        if actual is None:
            mismatch["mismatch_reason"] = "LIVE_SLOT_EMPTY_OR_UNOBSERVED"
            mismatches.append(mismatch)
            continue

        expected_variant = variants.get(expected)
        actual_variant = variants.get(actual)
        if (
            expected_variant is None
            or actual_variant is None
            or expected_variant[0] != actual_variant[0]
            or actual not in expected_variant[1]
        ):
            mismatch["mismatch_reason"] = "NOT_VERIFIED_VARIANT_SIBLING"
            mismatches.append(mismatch)
            continue

        if not _grade_available(kernel, spell_id=actual, grade=int(spell.grade)):
            mismatch["mismatch_reason"] = "LIVE_VARIANT_GRADE_UNAVAILABLE"
            mismatch["variant_group_id"] = int(expected_variant[0])
            mismatches.append(mismatch)
            continue

        replacements[ui_slot] = spell.model_copy(update={"spell_id": actual})
        substitutions.append(
            LiveSpellVariantSubstitution(
                ui_slot=ui_slot,
                protocol_slot=protocol_slot,
                configured_spell_id=expected,
                live_spell_id=actual,
                variant_group_id=int(expected_variant[0]),
                grade=int(spell.grade),
            )
        )

    if mismatches:
        return LiveSpellProfileResolution(
            profile=profile,
            substitutions=tuple(substitutions),
            mismatches=tuple(mismatches),
        )

    if not replacements:
        return LiveSpellProfileResolution(profile=profile)

    effective_spells = tuple(
        replacements.get(int(spell.slot_index), spell)
        if spell.enabled
        else spell
        for spell in profile.spells
    )
    effective = profile.model_copy(update={"spells": effective_spells})
    return LiveSpellProfileResolution(
        profile=effective,
        substitutions=tuple(substitutions),
    )

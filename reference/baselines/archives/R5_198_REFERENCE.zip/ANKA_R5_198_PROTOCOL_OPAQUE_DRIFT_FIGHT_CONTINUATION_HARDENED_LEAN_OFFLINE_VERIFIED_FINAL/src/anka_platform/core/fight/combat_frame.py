from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from types import MappingProxyType
from typing import Mapping

from anka_platform.core.fight.team_observation import (
    TeamFightObservation,
    TeamObservationNotConverged,
    converge_team_fight_observation,
)
from anka_platform.party.evidence import PartyEvidenceConflict, overlay_certified_side_relations


class CombatFrameUnavailable(RuntimeError):
    """A coherent immutable combat decision frame could not be assembled."""

    def __init__(self, reason: str, *, context: Mapping[str, object] | None = None) -> None:
        self.reason = str(reason)
        self.context = dict(context or {})
        detail = self.reason
        if self.context:
            detail += ": " + ", ".join(
                f"{key}={value!r}" for key, value in sorted(self.context.items())
            )
        super().__init__(detail)


@dataclass(frozen=True, slots=True)
class CombatDecisionFrame:
    """One captured, cross-account-certified semantic view of a combat instant.

    Canonical stores remain the live authorities.  The frame is only an immutable
    decision/admission input assembled from one capture of each required account
    lane.  Cross-lane revision numbers are retained for diagnostics and are never
    globally ordered.
    """

    owner_account_id: str
    owner_snapshot: object
    raw_owner_snapshot: object
    snapshots: Mapping[str, object]
    raw_snapshots: Mapping[str, object]
    account_revisions: tuple[tuple[str, int], ...]
    team_observation: TeamFightObservation | None
    frame_id: str
    # Hash only decision-critical semantic values.  Evidence watermarks/revisions
    # live in ``provenance_fingerprint`` so new observations that do not change
    # planner-visible truth do not invalidate an otherwise safe decision.
    semantic_fingerprint: str
    provenance_fingerprint: str

    @property
    def owner_revision(self) -> int:
        return int(getattr(self.raw_owner_snapshot, "revision", 0))

    @property
    def team_epoch(self) -> tuple[object, ...] | None:
        if self.team_observation is None:
            return None
        return self.team_observation.epoch.as_tuple()

    def snapshot_for(self, account_id: str):
        return self.snapshots[str(account_id)]

    def raw_snapshot_for(self, account_id: str):
        return self.raw_snapshots[str(account_id)]

    def diagnostics(self) -> dict[str, object]:
        return {
            "combat_frame_id": self.frame_id,
            "combat_frame_owner_account_id": self.owner_account_id,
            "combat_frame_owner_revision": self.owner_revision,
            "combat_frame_account_revisions": {
                account_id: int(revision) for account_id, revision in self.account_revisions
            },
            "combat_frame_team_epoch": (
                list(self.team_epoch) if self.team_epoch is not None else None
            ),
            "combat_frame_semantic_fingerprint": self.semantic_fingerprint,
            "combat_frame_provenance_fingerprint": self.provenance_fingerprint,
        }


class CombatFrameAssembler:
    """Capture all required lanes once and build the shared combat semantic frame.

    The same assembler is bound to FightAI and execution admission.  This prevents
    planning from enriching side/team evidence while execution later evaluates the
    same action against a weaker raw local lane.
    """

    def __init__(self, party, *, session_plan=None) -> None:
        self.party = party
        self.session_plan = session_plan

    def _captured_snapshots(self, owner_account_id: str) -> dict[str, object]:
        owner_account_id = str(owner_account_id)
        lanes = tuple(self.party.lanes)
        selected = [lane for lane in lanes if bool(getattr(lane, "required", False))]
        if not any(str(lane.account_id) == owner_account_id for lane in selected):
            try:
                selected.append(self.party.require(owner_account_id))
            except KeyError as exc:
                raise CombatFrameUnavailable(
                    "OWNER_ACCOUNT_UNKNOWN", context={"account_id": owner_account_id}
                ) from exc
        # Read every lane exactly once for this frame.
        return {str(lane.account_id): lane.snapshot() for lane in selected}

    @staticmethod
    def _frame_id(
        *, owner_account_id: str, observations: TeamFightObservation | None,
        snapshots: Mapping[str, object],
    ) -> str:
        revisions = ",".join(
            f"{account_id}={int(getattr(snapshot, 'revision', 0))}"
            for account_id, snapshot in sorted(snapshots.items())
        )
        if observations is not None:
            epoch = ":".join(str(item) for item in observations.epoch.as_tuple())
        else:
            owner = snapshots[owner_account_id]
            fight = getattr(owner, "fight", None)
            epoch = str(getattr(fight, "fight_instance_id", None))
        return f"{owner_account_id}|{epoch}|{revisions}"

    @staticmethod
    def _semantic_value(value) -> tuple[object, object]:
        status = getattr(getattr(value, "status", None), "value", getattr(value, "status", None))
        return (status, getattr(value, "value", None))

    @classmethod
    def _effect_semantic_signature(cls, actor) -> list[tuple[object, ...]]:
        """Decision-facing effect semantics separated from instance provenance.

        For an incomplete effect set, instance ids are observation provenance and
        are therefore excluded from the semantic hash.  **Multiplicity is kept**:
        until effect stacking/expiry semantics are authoritative, an additional
        semantically-identical row could be either transport duplication *or* a
        real stack.  Treating that as harmless would make stale-action admission
        too permissive.  Once the adapter provides a complete lifecycle, exact
        instance identity is also decision-semantic.
        """
        rows = []
        complete = bool(getattr(actor, "effects_complete", False))
        for item in getattr(actor, "effects", ()) or ():
            rows.append((
                int(item.effect_id),
                cls._semantic_value(item.effect_instance_id) if complete else None,
                cls._semantic_value(item.source_spell_id),
                cls._semantic_value(item.state_id),
                cls._semantic_value(item.source_actor_id),
                cls._semantic_value(item.remaining_turns),
                cls._semantic_value(item.stack_count),
            ))
        return sorted(rows, key=repr)

    @classmethod
    def _snapshot_semantic_signature(cls, snapshot) -> dict[str, object]:
        fight = getattr(snapshot, "fight", None)
        if fight is None:
            return {"revisionless": True}

        actors = []
        for actor in sorted(getattr(fight, "actors", ()) or (), key=lambda item: int(item.actor_id)):
            actors.append({
                "actor_id": int(actor.actor_id),
                "team_id": cls._semantic_value(actor.team_id),
                "side_relation": cls._semantic_value(actor.side_relation),
                "cell_id": cls._semantic_value(actor.cell_id),
                "hp": cls._semantic_value(actor.hp),
                "max_hp": cls._semantic_value(actor.max_hp),
                "eroded_hp": cls._semantic_value(actor.eroded_hp),
                "shield_points": cls._semantic_value(actor.shield_points),
                "ap": cls._semantic_value(actor.ap),
                "mp": cls._semantic_value(actor.mp),
                "range_bonus": cls._semantic_value(actor.range_bonus),
                "alive": cls._semantic_value(actor.alive),
                "actor_type": cls._semantic_value(actor.actor_type),
                "static_id": cls._semantic_value(actor.static_id),
                "level": cls._semantic_value(actor.level),
                "grade": cls._semantic_value(actor.grade),
                "summoner_actor_id": cls._semantic_value(actor.summoner_actor_id),
                "creature_id": cls._semantic_value(actor.creature_id),
                "creature_grade": cls._semantic_value(actor.creature_grade),
                "summon_count": cls._semantic_value(actor.summon_count),
                "placement_ready": cls._semantic_value(actor.placement_ready),
                "state_ids": sorted(int(item) for item in (getattr(actor, "state_ids", ()) or ())),
                "states_complete": bool(getattr(actor, "states_complete", False)),
                "effects": cls._effect_semantic_signature(actor),
                "effects_complete": bool(getattr(actor, "effects_complete", False)),
                "cooldowns": sorted(
                    (int(item.spell_id), int(item.remaining_turns))
                    for item in (getattr(actor, "cooldowns", ()) or ())
                ),
                "cooldowns_complete": bool(getattr(actor, "cooldowns_complete", False)),
                "characteristics_total": sorted(
                    (int(item.characteristic_id), int(item.total_value))
                    for item in (getattr(actor, "characteristics_total", ()) or ())
                ),
                "live_spell_loadout": list(getattr(actor, "live_spell_loadout", ()) or ()),
                "live_spell_slots": list(getattr(actor, "live_spell_slots", ()) or ()),
                "spell_property_modifiers": sorted(
                    (int(item.spell_id), int(item.property_code), int(item.raw_value))
                    for item in (getattr(actor, "spell_property_modifiers", ()) or ())
                ),
            })

        def casts(items):
            rows = []
            for item in items or ():
                rows.append((
                    int(item.caster_actor_id), int(item.spell_id),
                    cls._semantic_value(item.target_cell_id),
                    cls._semantic_value(item.target_actor_id),
                    cls._semantic_value(item.grade_id),
                    cls._semantic_value(item.round),
                    cls._semantic_value(item.turn_index),
                ))
            return rows

        return {
            "local_player_actor_id": cls._semantic_value(snapshot.local_player_actor_id),
            "fight_present": bool(getattr(fight, "present", False)),
            "fight_instance_id": getattr(fight, "fight_instance_id", None),
            "fight_id": cls._semantic_value(fight.fight_id),
            "map_id": cls._semantic_value(fight.map_id),
            "phase": cls._semantic_value(fight.phase),
            "round": cls._semantic_value(fight.round),
            "turn_index": cls._semantic_value(fight.turn_index),
            "active_actor_id": cls._semantic_value(fight.active_actor_id),
            "actor_roster_ids": list(getattr(fight, "actor_roster_ids", ()) or ()),
            "actor_roster_complete": bool(getattr(fight, "actor_roster_complete", False)),
            "actors": actors,
            "casts_turn": casts(getattr(fight, "confirmed_casts_this_turn", ())),
            "casts_global": casts(getattr(fight, "confirmed_casts_this_global_turn", ()) or ()),
            "casts_fight": casts(getattr(fight, "confirmed_casts_this_fight", ())),
        }

    @classmethod
    def _snapshot_provenance_signature(cls, snapshot) -> dict[str, object]:
        fight = getattr(snapshot, "fight", None)
        actors = []
        if fight is not None:
            for actor in sorted(getattr(fight, "actors", ()) or (), key=lambda item: int(item.actor_id)):
                observed = getattr(actor, "observed", None)
                watermarks = {}
                if observed is not None:
                    for name in getattr(type(observed), "model_fields", {}):
                        watermarks[name] = int(getattr(observed, name, 0) or 0)
                actors.append({
                    "actor_id": int(actor.actor_id),
                    "observed": watermarks,
                    "effect_instance_ids": [
                        cls._semantic_value(item.effect_instance_id)
                        for item in (getattr(actor, "effects", ()) or ())
                    ],
                })
        return {
            "snapshot_revision": int(getattr(snapshot, "revision", 0) or 0),
            "actor_observations": actors,
            "turn_observed_revision": int(getattr(fight, "turn_observed_revision", 0) or 0) if fight is not None else 0,
            "actor_roster_observed_revision": int(getattr(fight, "actor_roster_observed_revision", 0) or 0) if fight is not None else 0,
            "cast_observed_revisions": [
                int(getattr(item, "observed_revision", 0) or 0)
                for name in ("confirmed_casts_this_turn", "confirmed_casts_this_global_turn", "confirmed_casts_this_fight")
                for item in ((getattr(fight, name, ()) or ()) if fight is not None else ())
            ],
        }

    @staticmethod
    def _hash_payload(payload: Mapping[str, object]) -> str:
        blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()

    @classmethod
    def _semantic_fingerprint(cls, snapshots: Mapping[str, object]) -> str:
        return cls._hash_payload({
            str(account_id): cls._snapshot_semantic_signature(snapshot)
            for account_id, snapshot in sorted(snapshots.items())
        })

    @classmethod
    def semantic_fingerprint_for_snapshots(cls, snapshots: Mapping[str, object]) -> str:
        """Public decision-semantic fingerprint for orchestration recovery.

        Unlike raw Canonical revisions, this changes only when planner-visible
        combat semantics change.  It is intentionally whole-frame conservative:
        a later milestone may narrow dependencies per action, but provenance-only
        churn must never release an admission-UNKNOWN wait.
        """
        return cls._semantic_fingerprint(snapshots)

    @classmethod
    def semantic_drift_for_snapshots(
        cls, before: Mapping[str, object], after: Mapping[str, object], *, max_changes: int = 32,
    ) -> dict[str, object]:
        """Return a bounded explanation of decision-semantic drift.

        A stale-frame rejection is a safety success, but a fingerprint alone does
        not tell a future policy author *what* changed while the policy was
        thinking.  This helper compares the exact same semantic payload used by
        the admission fingerprint and emits only bounded, compact path summaries.
        It never participates in action authorization.
        """
        before_payload = {
            str(account_id): cls._snapshot_semantic_signature(snapshot)
            for account_id, snapshot in sorted(before.items())
        }
        after_payload = {
            str(account_id): cls._snapshot_semantic_signature(snapshot)
            for account_id, snapshot in sorted(after.items())
        }
        limit = max(1, int(max_changes))
        changes: list[dict[str, object]] = []
        total = 0

        def compact(value):
            if value is None or isinstance(value, (bool, int, float, str)):
                return value
            if isinstance(value, (list, tuple)):
                raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
                return {
                    "kind": "sequence", "length": len(value),
                    "fingerprint": hashlib.sha256(raw).hexdigest()[:16],
                }
            if isinstance(value, Mapping):
                raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
                return {
                    "kind": "mapping", "key_count": len(value),
                    "fingerprint": hashlib.sha256(raw).hexdigest()[:16],
                }
            return str(value)[:160]

        def emit(path: str, left, right) -> None:
            nonlocal total
            total += 1
            if len(changes) < limit:
                changes.append({"path": path, "before": compact(left), "after": compact(right)})

        def keyed_actors(value):
            if not isinstance(value, list) or not value:
                return None
            if not all(isinstance(item, Mapping) and "actor_id" in item for item in value):
                return None
            return {str(item["actor_id"]): item for item in value}

        def walk(left, right, path: str) -> None:
            if left == right:
                return
            if isinstance(left, Mapping) and isinstance(right, Mapping):
                for key in sorted(set(left) | set(right), key=str):
                    child = f"{path}.{key}" if path else str(key)
                    if key not in left:
                        emit(child, "<MISSING>", right[key])
                    elif key not in right:
                        emit(child, left[key], "<MISSING>")
                    else:
                        walk(left[key], right[key], child)
                return
            left_actors = keyed_actors(left)
            right_actors = keyed_actors(right)
            if left_actors is not None and right_actors is not None:
                for actor_id in sorted(set(left_actors) | set(right_actors), key=str):
                    child = f"{path}[actor_id={actor_id}]"
                    if actor_id not in left_actors:
                        emit(child, "<MISSING>", right_actors[actor_id])
                    elif actor_id not in right_actors:
                        emit(child, left_actors[actor_id], "<MISSING>")
                    else:
                        walk(left_actors[actor_id], right_actors[actor_id], child)
                return
            # Non-actor sequences (effects, casts, states, loadout...) are kept
            # as one compact delta. Expanding every row would recreate the debug
            # payload explosion this diagnostic is designed to avoid.
            emit(path or "<root>", left, right)

        walk(before_payload, after_payload, "")
        return {
            "changed_field_count": total,
            "reported_change_count": len(changes),
            "truncated": total > len(changes),
            "changes": changes,
        }

    @classmethod
    def _provenance_fingerprint(cls, snapshots: Mapping[str, object]) -> str:
        return cls._hash_payload({
            str(account_id): cls._snapshot_provenance_signature(snapshot)
            for account_id, snapshot in sorted(snapshots.items())
        })

    def capture(self, owner_account_id: str) -> CombatDecisionFrame:
        owner_account_id = str(owner_account_id)
        captured = self._captured_snapshots(owner_account_id)
        owner = captured.get(owner_account_id)
        if owner is None:
            raise CombatFrameUnavailable(
                "OWNER_SNAPSHOT_MISSING", context={"account_id": owner_account_id}
            )

        observation = None
        if self.session_plan is not None:
            try:
                observation = converge_team_fight_observation(
                    session_plan=self.session_plan, snapshots=captured,
                )
            except TeamObservationNotConverged as exc:
                raise CombatFrameUnavailable(
                    "TEAM_OBSERVATION_NOT_CONVERGED",
                    context={"reason": exc.reason, **dict(exc.context)},
                ) from exc

        semantic: dict[str, object] = {}
        try:
            for account_id, snapshot in captured.items():
                peers = tuple(
                    peer for peer_id, peer in captured.items() if peer_id != account_id
                )
                semantic[account_id] = overlay_certified_side_relations(snapshot, peers)
        except PartyEvidenceConflict as exc:
            raise CombatFrameUnavailable(
                "PARTY_SIDE_EVIDENCE_CONFLICT", context={"detail": str(exc)}
            ) from exc

        account_revisions = tuple(
            sorted(
                (account_id, int(getattr(snapshot, "revision", 0)))
                for account_id, snapshot in captured.items()
            )
        )
        frame_id = self._frame_id(
            owner_account_id=owner_account_id,
            observations=observation,
            snapshots=captured,
        )
        semantic_fingerprint = self._semantic_fingerprint(semantic)
        provenance_fingerprint = self._provenance_fingerprint(captured)
        return CombatDecisionFrame(
            owner_account_id=owner_account_id,
            owner_snapshot=semantic[owner_account_id],
            raw_owner_snapshot=owner,
            snapshots=MappingProxyType(dict(semantic)),
            raw_snapshots=MappingProxyType(dict(captured)),
            account_revisions=account_revisions,
            team_observation=observation,
            frame_id=frame_id,
            semantic_fingerprint=semantic_fingerprint,
            provenance_fingerprint=provenance_fingerprint,
        )

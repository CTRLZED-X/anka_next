from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PartyFightLifecycleState(str, Enum):
    WORLD = "WORLD"
    ENTRY_JOINING = "ENTRY_JOINING"
    FULL_PARTY = "FULL_PARTY"
    EXIT_SETTLING = "EXIT_SETTLING"
    AMBIGUOUS_PARTIAL = "AMBIGUOUS_PARTIAL"
    CONFLICT = "CONFLICT"




class FightPartialClassification(str, Enum):
    ENTRY_JOINING = "ENTRY_JOINING"
    EXIT_SETTLING = "EXIT_SETTLING"


@dataclass(frozen=True, slots=True)
class FightGenerationLifecycleStatus:
    """Typed monotonic history for one exact fight generation.

    This is the only cross-layer contract used to classify a partial required-party
    observation as entry convergence versus exit settlement. Current-state truth
    remains owned by SharedFightManager; this object carries only historical gates.
    """

    fight_instance_id: int | None
    preparation_complete: bool
    active_latched: bool
    post_entry_authorized: bool
    partial_classification: FightPartialClassification

    def to_dict(self) -> dict[str, object]:
        return {
            "fight_instance_id": self.fight_instance_id,
            "preparation_complete": self.preparation_complete,
            "active_latched": self.active_latched,
            "post_entry_authorized": self.post_entry_authorized,
            "partial_classification": self.partial_classification.value,
        }

    @classmethod
    def from_mapping(cls, value: dict[str, object]) -> "FightGenerationLifecycleStatus":
        raw = str(value.get("partial_classification") or "ENTRY_JOINING").upper()
        classification = (
            FightPartialClassification.EXIT_SETTLING
            if raw == FightPartialClassification.EXIT_SETTLING.value
            else FightPartialClassification.ENTRY_JOINING
        )
        fight_id = value.get("fight_instance_id")
        return cls(
            fight_instance_id=(int(fight_id) if fight_id is not None else None),
            preparation_complete=bool(value.get("preparation_complete")),
            active_latched=bool(value.get("active_latched")),
            post_entry_authorized=bool(value.get("post_entry_authorized")),
            partial_classification=classification,
        )


@dataclass(frozen=True, slots=True)
class PartyFightLifecycleObservation:
    state: PartyFightLifecycleState
    fight_instance_id: int | None
    present_accounts: tuple[str, ...]
    missing_accounts: tuple[str, ...]
    expected_fight_instance_id: int | None
    converged_before: bool
    reason: str

    def to_dict(self) -> dict:
        return {
            "state": self.state.value,
            "fight_instance_id": self.fight_instance_id,
            "present_accounts": list(self.present_accounts),
            "missing_accounts": list(self.missing_accounts),
            "expected_fight_instance_id": self.expected_fight_instance_id,
            "converged_before": self.converged_before,
            "reason": self.reason,
        }


class PartyFightLifecycleTracker:
    """Classify partial-party fight states using run-local generation history.

    A partial required-party view is ambiguous without history: it can mean
    either "leader entered, follower still needs to join" or "fight ended for
    one account, the rest are still settling back to world".  The tracker makes
    that distinction explicit by remembering the exact fight generation that
    was launched and whether every required account was ever observed in it.

    The tracker never sends input.  It only supplies a fail-closed lifecycle
    classification to orchestration/certification scripts.
    """

    def __init__(self, required_accounts, leader_account_id: str) -> None:
        required = tuple(dict.fromkeys(str(item) for item in required_accounts))
        if not required:
            raise ValueError("required_accounts must not be empty")
        leader = str(leader_account_id)
        if leader not in required:
            raise ValueError("leader_account_id must be a required account")
        self.required_accounts = required
        self.leader_account_id = leader
        self.expected_fight_instance_id: int | None = None
        self._converged_fight_instance_ids: set[int] = set()
        self._terminal_fight_instance_ids: set[int] = set()
        self._admitted_accounts_by_fight: dict[int, set[str]] = {}

    @staticmethod
    def _fight_instance_id(snapshot: dict | None) -> int | None:
        raw = ((snapshot or {}).get("fight") or {}).get("fight_instance_id")
        if raw is None:
            return None
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _fight_phase(snapshot: dict | None) -> str | None:
        raw = ((snapshot or {}).get("fight") or {}).get("phase")
        if isinstance(raw, dict) and raw.get("status") == "KNOWN":
            value = raw.get("value")
            return str(value) if value is not None else None
        if isinstance(raw, str):
            return raw
        return None

    def note_launch(self, fight_instance_id: int) -> None:
        fight_id = int(fight_instance_id)
        self.expected_fight_instance_id = fight_id
        self._admitted_accounts_by_fight[fight_id] = {self.leader_account_id}

    def note_join_confirmed(self, account_id: str, fight_instance_id: int) -> None:
        fight_id = int(fight_instance_id)
        account = str(account_id)
        admitted = self._admitted_accounts_by_fight.setdefault(fight_id, {self.leader_account_id})
        admitted.add(account)
        # A confirmed join proves that the follower crossed the join boundary,
        # but it does not by itself prove that the canonical party view has
        # converged for every required account.  Only a subsequent FULL_PARTY
        # observation establishes that boundary.  This prevents a short
        # canonical propagation delay immediately after join confirmation from
        # being misclassified as post-fight settlement.
        self.expected_fight_instance_id = fight_id

    def note_terminal(self, fight_instance_id: int | None = None) -> None:
        resolved = fight_instance_id
        if resolved is None:
            resolved = self.expected_fight_instance_id
        if resolved is not None:
            self._terminal_fight_instance_ids.add(int(resolved))
        self.expected_fight_instance_id = None

    def observe(self, snapshots: dict[str, dict]) -> PartyFightLifecycleObservation:
        required = self.required_accounts
        present = tuple(
            account for account in required
            if bool((((snapshots.get(account) or {}).get("fight") or {}).get("present")))
        )
        missing = tuple(account for account in required if account not in present)
        observed_ids = {
            instance
            for account in present
            for instance in (self._fight_instance_id(snapshots.get(account)),)
            if instance is not None
        }
        observed_phases = {
            phase
            for account in present
            for phase in (self._fight_phase(snapshots.get(account)),)
            if phase is not None
        }

        if len(observed_ids) > 1:
            return PartyFightLifecycleObservation(
                PartyFightLifecycleState.CONFLICT,
                None,
                present,
                missing,
                self.expected_fight_instance_id,
                False,
                "required accounts expose different fight generations",
            )

        observed_id = next(iter(observed_ids), None)
        resolved_id = observed_id if observed_id is not None else self.expected_fight_instance_id
        converged_before = bool(
            resolved_id is not None and int(resolved_id) in self._converged_fight_instance_ids
        )

        if not present:
            return PartyFightLifecycleObservation(
                PartyFightLifecycleState.WORLD,
                resolved_id,
                present,
                missing,
                self.expected_fight_instance_id,
                converged_before,
                "no required account currently observes a fight",
            )

        if self.expected_fight_instance_id is not None and observed_id is not None:
            if int(observed_id) != int(self.expected_fight_instance_id) and not converged_before:
                return PartyFightLifecycleObservation(
                    PartyFightLifecycleState.CONFLICT,
                    observed_id,
                    present,
                    missing,
                    self.expected_fight_instance_id,
                    converged_before,
                    "observed fight generation does not match the confirmed leader launch",
                )

        if not missing:
            if resolved_id is not None:
                self._converged_fight_instance_ids.add(int(resolved_id))
                self.expected_fight_instance_id = int(resolved_id)
            return PartyFightLifecycleObservation(
                PartyFightLifecycleState.FULL_PARTY,
                resolved_id,
                present,
                missing,
                self.expected_fight_instance_id,
                converged_before,
                "all required accounts are present in the fight",
            )

        if converged_before:
            return PartyFightLifecycleObservation(
                PartyFightLifecycleState.EXIT_SETTLING,
                resolved_id,
                present,
                missing,
                self.expected_fight_instance_id,
                True,
                "a previously converged fight is settling back to world",
            )

        if self.leader_account_id in present:
            if "ACTIVE" in observed_phases:
                if self.expected_fight_instance_id is not None:
                    return PartyFightLifecycleObservation(
                        PartyFightLifecycleState.CONFLICT,
                        resolved_id,
                        present,
                        missing,
                        self.expected_fight_instance_id,
                        False,
                        "fight became ACTIVE before every required account joined",
                    )
                return PartyFightLifecycleObservation(
                    PartyFightLifecycleState.EXIT_SETTLING,
                    resolved_id,
                    present,
                    missing,
                    self.expected_fight_instance_id,
                    False,
                    "leader-only ACTIVE partial fight without a current launch receipt is quarantined as settlement",
                )
            return PartyFightLifecycleObservation(
                PartyFightLifecycleState.ENTRY_JOINING,
                resolved_id,
                present,
                missing,
                self.expected_fight_instance_id,
                False,
                "leader is in the fight and required followers still need to join",
            )

        # In a leader-launched mission, a follower-only partial fight cannot be
        # a valid entry state. Quarantine it as settlement rather than ever
        # issuing world actions or trying to make the leader re-join its own
        # fight. This also safely handles attach/restart while an old fight is
        # draining.
        return PartyFightLifecycleObservation(
            PartyFightLifecycleState.EXIT_SETTLING,
            resolved_id,
            present,
            missing,
            self.expected_fight_instance_id,
            False,
            "leader is absent from a partial fight; quarantine until world settlement",
        )


@dataclass(slots=True)
class FightWorkflowLifecycleMemory:
    """Single mutable owner of FightWorkflow generation history.

    SharedFightManager remains the current-state projection.  This object owns
    only monotonic/historical workflow facts so generation reset cannot leave
    independent booleans and ids out of sync.
    """

    seen_fight: bool = False
    terminal_reported: bool = False
    last_fight_instance_id: int | None = None
    converged_fight_instance_id: int | None = None
    active_fight_instance_id: int | None = None

    def reset(self) -> None:
        self.seen_fight = False
        self.terminal_reported = False
        self.last_fight_instance_id = None
        self.converged_fight_instance_id = None
        self.active_fight_instance_id = None

    def observe_generation(self, fight_instance_id: int) -> bool:
        """Record an exact generation and atomically reopen per-fight latches."""
        fight_id = int(fight_instance_id)
        changed = self.last_fight_instance_id != fight_id
        if changed:
            self.terminal_reported = False
            self.converged_fight_instance_id = None
            self.active_fight_instance_id = None
        self.last_fight_instance_id = fight_id
        self.seen_fight = True
        return changed

    def mark_converged(self, fight_instance_id: int) -> None:
        self.converged_fight_instance_id = int(fight_instance_id)

    def mark_active(self, fight_instance_id: int) -> None:
        self.active_fight_instance_id = int(fight_instance_id)

    def consume_terminal_edge(self) -> bool:
        """Return True exactly once after a seen fight disappears."""
        if not self.seen_fight or self.terminal_reported:
            return False
        self.terminal_reported = True
        return True

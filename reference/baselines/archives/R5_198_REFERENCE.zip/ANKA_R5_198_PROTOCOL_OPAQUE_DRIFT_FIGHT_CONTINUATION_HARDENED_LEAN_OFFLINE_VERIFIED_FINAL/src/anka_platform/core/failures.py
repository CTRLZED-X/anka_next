from __future__ import annotations

from enum import Enum


class CoreFailureCode(str, Enum):
    INVALID_SESSION = "INVALID_SESSION"
    PROFILE_NOT_FOUND = "PROFILE_NOT_FOUND"
    REQUIRED_MEMBER_MISSING = "REQUIRED_MEMBER_MISSING"
    INVALID_LEADER = "INVALID_LEADER"
    MISSING_POLICY = "MISSING_POLICY"
    MISSING_CAPABILITY = "MISSING_CAPABILITY"
    DUPLICATE_IDENTITY = "DUPLICATE_IDENTITY"
    PROTOCOL_NOT_READY = "PROTOCOL_NOT_READY"


class SessionCompileError(ValueError):
    def __init__(self, code: CoreFailureCode, message: str, **context: object) -> None:
        super().__init__(str(message))
        self.code = code
        self.context = dict(context)

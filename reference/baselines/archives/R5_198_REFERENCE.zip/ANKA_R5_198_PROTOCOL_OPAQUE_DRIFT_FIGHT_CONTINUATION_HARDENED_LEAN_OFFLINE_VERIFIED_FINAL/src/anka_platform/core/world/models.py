from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class WorldWorkflowState(str, Enum):
    WORLD_SETTLING = "WORLD_SETTLING"
    PARTY_CONVERGENCE = "PARTY_CONVERGENCE"
    OBSERVE_MAP = "OBSERVE_MAP"
    SEARCH_TARGET = "SEARCH_TARGET"
    SELECT_TARGET = "SELECT_TARGET"
    ACQUIRE_TARGET = "ACQUIRE_TARGET"
    TRANSITION = "TRANSITION"
    FIGHT_HANDOFF = "FIGHT_HANDOFF"
    WAIT_RESPAWN = "WAIT_RESPAWN"
    FAILED = "FAILED"


@dataclass(frozen=True, slots=True)
class WorldWorkflowResult:
    state: WorldWorkflowState
    action: dict = field(default_factory=dict)
    reason: str = ""
    account_id: str | None = None
    next_allowed_commands: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return {
            "state": self.state.value,
            "action": dict(self.action),
            "reason": self.reason,
            "account_id": self.account_id,
            "next_allowed_commands": list(self.next_allowed_commands),
        }

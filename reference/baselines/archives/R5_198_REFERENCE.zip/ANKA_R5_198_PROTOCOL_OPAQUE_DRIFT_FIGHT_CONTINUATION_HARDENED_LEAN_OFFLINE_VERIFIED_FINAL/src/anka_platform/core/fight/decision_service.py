from __future__ import annotations

import time
from uuid import uuid4
from collections.abc import Callable

from anka_platform.config import FightAISettings, PartyMemberRole
from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id
from anka_platform.core.models import ControlMode
from anka_platform.core.fight.team_observation import TeamObservationNotConverged
from anka_platform.core.fight.combat_frame import CombatFrameAssembler, CombatFrameUnavailable
from anka_platform.core.fight.live_spell_profile import resolve_live_spell_profile
from anka_platform.core.fight.combat_truth import assess_combat_truth
from anka_platform.core.fight.planner_contract import (
    ConfirmedTurnExecutionHistory, PlannerDisposition, PlannerFailureClass,
    PlannerInvocationContext, PassiveInvocationContext,
)
from anka_platform.core.fight.policy_invocation import FightPolicyInvoker
from anka_platform.core.registry import PolicyRegistry
from anka_platform.core.session import SessionPlan
from anka_platform.core.fight.decision_contract import FightDecision, action_key_from_payload


class FightDecisionService:
    """Resolve and invoke the configured turn policy for one account.

    This service owns policy selection and decision freshness. It does not execute
    physical actions; PartyCombatController remains the single action authority.
    """

    def __init__(
        self,
        *,
        kernel,
        party,
        fight_ai: FightAISettings | None,
        policies: PolicyRegistry,
        session_plan: SessionPlan | None = None,
        active_policy_override=None,
        spell_slot_resolver=None,
        frame_assembler: CombatFrameAssembler | None = None,
        decision_trace_builder: Callable[..., dict] | None = None,
        policy_invoker: FightPolicyInvoker | None = None,
    ) -> None:
        self.kernel = kernel
        self.party = party
        self.fight_ai = fight_ai
        self.policies = policies
        self.session_plan = session_plan
        self.active_policy_override = active_policy_override
        self.spell_slot_resolver = spell_slot_resolver
        # Observability is injected from composition.  The core decision service
        # must not import a concrete FightAI implementation merely to build a
        # forensic trace.  A replacement planner can therefore use this service
        # without importing TacticalPolicy or fight_ai.telemetry.
        self.decision_trace_builder = decision_trace_builder
        self.policy_invoker = policy_invoker or FightPolicyInvoker()
        self.frame_assembler = frame_assembler or CombatFrameAssembler(
            party, session_plan=session_plan
        )
        # R5.135 safe-replan quarantine. Keys are semantic turn identities, never
        # cross-lane revision numbers. Entries expire naturally at turn change.
        self._quarantined_actions: dict[tuple, set[tuple]] = {}

    @staticmethod
    def _turn_fingerprint(snapshot) -> tuple:
        fight = snapshot.fight

        def known(value):
            return value.value if value.status is ValueStatus.KNOWN else None

        return (
            bool(fight.present),
            fight.fight_instance_id,
            known(fight.round),
            known(fight.turn_index),
            known(fight.active_actor_id),
        )

    @staticmethod
    def _decision_fingerprint_payload(decision: dict) -> tuple:
        return action_key_from_payload(decision)

    def _quarantine_key(self, account_id: str, snapshot) -> tuple:
        return (str(account_id), *self._turn_fingerprint(snapshot))

    def quarantine_decision(self, account_id: str, decision: dict) -> dict:
        """Suppress one exact action for the remainder of the current semantic turn.

        This is used only after execution proves the attempted action did not
        become a server-side combat action. It never changes Canonical State and
        never authorizes input; it only prevents deterministic reselection loops.
        """
        lane = self.party.require(str(account_id))
        snapshot = lane.snapshot()
        key = self._quarantine_key(str(account_id), snapshot)
        fingerprint = self._decision_fingerprint_payload(decision)
        # Keep at most the current turn for this account.
        for old_key in tuple(self._quarantined_actions):
            if old_key[0] == str(account_id) and old_key != key:
                self._quarantined_actions.pop(old_key, None)
        self._quarantined_actions.setdefault(key, set()).add(fingerprint)
        return {
            "account_id": str(account_id),
            "turn_key": list(key[1:]),
            "fingerprint": list(fingerprint),
            "count": len(self._quarantined_actions[key]),
        }

    @staticmethod
    def _decision_payload(decision: FightDecision) -> dict:
        """Serialize executable intent plus the policy-independent planner contract.

        ``FightDecision.to_payload`` remains the stable physical-action schema.
        ``planner_result`` is orchestration metadata consumed by the turn controller
        and is deliberately separate from TacticalPolicy telemetry.
        """
        payload = dict(decision.to_payload())
        payload["planner_result"] = decision.planner_result_payload()
        return payload

    @staticmethod
    def _planner_envelope(
        *, kind: str, reason: str, disposition: PlannerDisposition,
        dependency: str | None = None,
        failure_class: PlannerFailureClass | None = None,
        **extra,
    ) -> dict:
        """Build a policy-independent orchestration result for service-owned gates."""
        return {
            "kind": str(kind),
            "reason": str(reason),
            "planner_result": {
                "schema_version": 1,
                "disposition": disposition.value,
                "reason": str(reason),
                "dependency": dependency,
                "progress": None,
                "failure_class": None if failure_class is None else failure_class.value,
            },
            **extra,
        }

    @staticmethod
    def _local_cell(snapshot, local_actor_id: int) -> int | None:
        actor = next((item for item in snapshot.fight.actors if int(item.actor_id) == int(local_actor_id)), None)
        if actor is None or actor.cell_id.status is not ValueStatus.KNOWN or actor.cell_id.value is None:
            return None
        return int(actor.cell_id.value)

    def _resolved_member(self, account_id: str):
        if self.session_plan is None:
            return None
        try:
            return self.session_plan.member_for(account_id)
        except KeyError:
            return None

    def _control_mode(self, account_id: str, account_role: str | None) -> ControlMode:
        member = self._resolved_member(account_id)
        if member is not None:
            return member.control_mode
        if account_role is None:
            lane = self.party.require(account_id)
            account_role = getattr(lane.role, "value", lane.role)
        return (
            ControlMode.ACTIVE
            if str(account_role) == PartyMemberRole.ACTIVE_CONTROLLER.value
            else ControlMode.PASSIVE
        )

    def _policy_id(self, account_id: str, control_mode: ControlMode) -> str:
        member = self._resolved_member(account_id)
        if control_mode is ControlMode.ACTIVE:
            if member is not None and member.fight_policy_id:
                return member.fight_policy_id
            return "normal"
        if member is not None and member.passive_policy_id:
            return member.passive_policy_id
        return "passive_end_turn"

    def _objective_for(self, account_id: str, *, snapshots=None):
        if self.session_plan is None or not self.session_plan.team_strategy_id:
            return None
        strategy = self.policies.require_team(self.session_plan.team_strategy_id)
        if snapshots is None:
            frame = self.frame_assembler.capture(str(account_id))
            snapshots = frame.snapshots
        objectives = strategy.objectives(session_plan=self.session_plan, snapshots=snapshots)
        return objectives.get(account_id) if objectives is not None else None

    @classmethod
    def _team_convergence_wait(cls, exc: TeamObservationNotConverged) -> dict:
        return cls._planner_envelope(
            kind="WAIT",
            reason="TEAM_OBSERVATION_NOT_CONVERGED",
            disposition=PlannerDisposition.WAIT_EXTERNAL,
            dependency="TEAM_OBSERVATION",
            failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
            team_observation_reason=exc.reason,
            team_observation_context=dict(exc.context),
        )

    def decide(
        self, account_id: str, *, account_role: str | None = None,
        confirmed_turn_history: ConfirmedTurnExecutionHistory | None = None,
    ) -> dict:
        decision_started = time.monotonic()
        lane = self.party.require(str(account_id))
        frame_started = time.monotonic()
        try:
            frame = self.frame_assembler.capture(lane.account_id)
        except CombatFrameUnavailable as exc:
            if exc.reason == "TEAM_OBSERVATION_NOT_CONVERGED":
                return self._planner_envelope(
                    kind="WAIT",
                    reason="TEAM_OBSERVATION_NOT_CONVERGED",
                    disposition=PlannerDisposition.WAIT_EXTERNAL,
                    dependency="TEAM_OBSERVATION",
                    failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
                    team_observation_reason=exc.context.get("reason"),
                    team_observation_context=dict(exc.context),
                )
            return self._planner_envelope(
                kind="BLOCKED",
                reason=f"{exc.reason}: {exc}",
                disposition=PlannerDisposition.WAIT_EXTERNAL,
                dependency="COMBAT_FRAME",
                failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
                combat_frame_error={"reason": exc.reason, "context": dict(exc.context)},
            )
        frame_capture_ms = max(0.0, (time.monotonic() - frame_started) * 1000.0)
        snapshot = frame.owner_snapshot

        local_actor_id = authoritative_canonical_local_actor_id(snapshot)
        if local_actor_id is None:
            return self._planner_envelope(kind="BLOCKED", reason="LOCAL_ACTOR_UNKNOWN_OR_PROVISIONAL", disposition=PlannerDisposition.WAIT_EXTERNAL, dependency="LOCAL_ACTOR", failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        combat_truth = assess_combat_truth(snapshot, local_actor_id=local_actor_id)
        control_mode = self._control_mode(lane.account_id, account_role)
        quarantine_key = self._quarantine_key(lane.account_id, snapshot)
        excluded_action_fingerprints = tuple(sorted(
            self._quarantined_actions.get(quarantine_key, set()), key=repr
        ))

        decision_id = uuid4().hex
        start_revision = int(snapshot.revision)
        start_turn = self._turn_fingerprint(snapshot)
        resolved_policy_id = self._policy_id(lane.account_id, control_mode)
        spell_bar_verification = "NOT_APPLICABLE"
        spell_variant_substitutions: tuple[dict[str, int], ...] = ()
        profile = None
        objective = None
        policy_elapsed_ms = 0.0

        if control_mode is ControlMode.PASSIVE:
            policy = self.policies.require_passive(resolved_policy_id)
            try:
                objective = self._objective_for(lane.account_id, snapshots=frame.snapshots)
            except TeamObservationNotConverged as exc:
                return self._team_convergence_wait(exc)
            policy_started = time.monotonic()
            deadline = (
                policy_started + float(self.fight_ai.decision_budget_seconds)
                if self.fight_ai is not None else None
            )
            try:
                invocation = self.policy_invoker.invoke_passive(
                    policy,
                    context=PassiveInvocationContext(
                        current_cell_id=self._local_cell(snapshot, local_actor_id),
                        kernel=self.kernel,
                        snapshot=snapshot,
                        local_actor_id=local_actor_id,
                        planner=PlannerInvocationContext(
                            decision_deadline_monotonic=deadline, objective=objective,
                            confirmed_turn_history=(
                                confirmed_turn_history or ConfirmedTurnExecutionHistory()
                            ),
                            combat_truth=combat_truth,
                        ),
                    ),
                )
            except Exception as exc:
                return self._planner_envelope(
                    kind="BLOCKED", reason="FIGHT_POLICY_EXCEPTION",
                    disposition=PlannerDisposition.FAULT,
                    dependency="FIGHT_POLICY",
                    failure_class=PlannerFailureClass.POLICY_FAULT,
                    policy_exception=f"{type(exc).__name__}: {exc}",
                    policy_id=resolved_policy_id,
                )
            decision = invocation.decision
            policy_invocation_compatibility_adapter = bool(invocation.compatibility_adapter)
            if not isinstance(decision, FightDecision):
                return self._planner_envelope(
                    kind="BLOCKED", reason="INVALID_FIGHT_POLICY_RESULT",
                    disposition=PlannerDisposition.FAULT,
                    dependency="FIGHT_POLICY_CONTRACT",
                    failure_class=PlannerFailureClass.CONTRACT_VIOLATION,
                    policy_result_type=type(decision).__name__,
                    policy_id=resolved_policy_id,
                )
            policy_elapsed_ms = max(0.0, (time.monotonic() - policy_started) * 1000.0)
        else:
            if self.fight_ai is None:
                return self._planner_envelope(kind="BLOCKED", reason="FIGHT_AI_UNAVAILABLE", disposition=PlannerDisposition.FAULT, dependency="FIGHT_POLICY_CONFIGURATION", failure_class=PlannerFailureClass.CONFIGURATION)
            member = self._resolved_member(lane.account_id)
            combat_profile_id = (member.combat_profile_id if member is not None and member.combat_profile_id else lane.account_id)
            profile = self.fight_ai.profile(combat_profile_id)
            if self.fight_ai.verify_live_spell_slots:
                actor = next((item for item in snapshot.fight.actors if int(item.actor_id) == local_actor_id), None)
                live_known = bool(
                    actor is not None
                    and actor.live_spell_loadout
                    and len(actor.live_spell_loadout) == len(actor.live_spell_slots)
                )
                adapter_id = (
                    self.session_plan.protocol_adapter_id
                    if self.session_plan is not None
                    else None
                )
                if not live_known:
                    # R5.108 startup-continuity fence. A newly unpacked runtime
                    # can attach to an already-open Dofus client after its one-time
                    # JVA spell-bar snapshot has passed. The configured profile is
                    # allowed only as an explicit temporary bridge; execution still
                    # requires a verified physical slot calibration, and any later
                    # live JVA evidence is authoritative and checked below.
                    if not self.fight_ai.allow_profile_spell_bar_fallback:
                        return self._planner_envelope(kind="BLOCKED", reason="LIVE_SPELL_BAR_UNKNOWN", disposition=PlannerDisposition.WAIT_EXTERNAL, dependency="LIVE_SPELL_BAR", failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
                    if not profile.enabled_spells:
                        return self._planner_envelope(kind="BLOCKED", reason="PROFILE_SPELL_BAR_EMPTY", disposition=PlannerDisposition.FAULT, dependency="COMBAT_PROFILE", failure_class=PlannerFailureClass.CONFIGURATION)
                    for spell in profile.enabled_spells:
                        if int(spell.slot_index) <= 0 or int(spell.spell_id) <= 0:
                            return self._planner_envelope(
                                kind="BLOCKED", reason="PROFILE_SPELL_BAR_INVALID",
                                disposition=PlannerDisposition.FAULT,
                                dependency="COMBAT_PROFILE",
                                failure_class=PlannerFailureClass.CONFIGURATION,
                                spell_id=int(spell.spell_id), slot_index=int(spell.slot_index),
                            )
                        try:
                            if self.spell_slot_resolver is not None and adapter_id is not None:
                                self.spell_slot_resolver(adapter_id, int(spell.slot_index))
                            else:
                                # Legacy/direct hosts without a SessionPlan stay core-independent:
                                # the config object resolves its compatibility slot through the
                                # composition/protocol boundary rather than importing protocol here.
                                int(spell.protocol_slot_index)
                        except (LookupError, RuntimeError, ValueError):
                            return self._planner_envelope(kind="BLOCKED", reason="PROTOCOL_SLOT_RESOLVER_UNAVAILABLE", disposition=PlannerDisposition.FAULT, dependency="PROTOCOL_SLOT_RESOLVER", failure_class=PlannerFailureClass.CONFIGURATION, adapter_id=adapter_id)
                    spell_bar_verification = "PROFILE_BOOTSTRAP_PENDING_LIVE"
                else:
                    observed = {
                        int(slot): int(spell_id)
                        for slot, spell_id in zip(actor.live_spell_slots, actor.live_spell_loadout)
                    }
                    def protocol_slot_for_ui_slot(ui_slot: int) -> int:
                        try:
                            if self.spell_slot_resolver is not None and adapter_id is not None:
                                return int(self.spell_slot_resolver(adapter_id, int(ui_slot)))
                            configured = next(
                                (item for item in profile.enabled_spells if int(item.slot_index) == int(ui_slot)),
                                None,
                            )
                            if configured is None:
                                raise KeyError(ui_slot)
                            return int(configured.protocol_slot_index)
                        except (LookupError, ValueError, RuntimeError) as exc:
                            raise RuntimeError(f"PROTOCOL_SLOT_RESOLVER_UNAVAILABLE:{adapter_id or 'UNSPECIFIED'}") from exc

                    try:
                        live_resolution = resolve_live_spell_profile(
                            kernel=self.kernel,
                            profile=profile,
                            observed_by_protocol_slot=observed,
                            protocol_slot_for_ui_slot=protocol_slot_for_ui_slot,
                        )
                    except RuntimeError as exc:
                        if str(exc).startswith("PROTOCOL_SLOT_RESOLVER_UNAVAILABLE:"):
                            return self._planner_envelope(
                                kind="BLOCKED", reason="PROTOCOL_SLOT_RESOLVER_UNAVAILABLE",
                                disposition=PlannerDisposition.FAULT,
                                dependency="PROTOCOL_SLOT_RESOLVER",
                                failure_class=PlannerFailureClass.CONFIGURATION,
                                adapter_id=adapter_id,
                            )
                        raise
                    if not live_resolution.accepted:
                        return self._planner_envelope(
                            kind="BLOCKED", reason="LIVE_SPELL_BAR_MISMATCH",
                            disposition=PlannerDisposition.FAULT,
                            dependency="LIVE_SPELL_BAR",
                            failure_class=PlannerFailureClass.CONFIGURATION,
                            mismatches=list(live_resolution.mismatches),
                        )
                    profile = live_resolution.profile
                    spell_variant_substitutions = tuple(
                        item.as_dict() for item in live_resolution.substitutions
                    )
                    spell_bar_verification = live_resolution.verification

            policy = self.active_policy_override or self.policies.require_fight(
                resolved_policy_id
            )
            try:
                objective = self._objective_for(lane.account_id, snapshots=frame.snapshots)
            except TeamObservationNotConverged as exc:
                return self._team_convergence_wait(exc)
            policy_started = time.monotonic()
            deadline = policy_started + float(self.fight_ai.decision_budget_seconds)
            try:
                invocation = self.policy_invoker.invoke(
                    policy,
                    kernel=self.kernel,
                    snapshot=snapshot,
                    local_actor_id=local_actor_id,
                    profile=profile,
                    context=PlannerInvocationContext(
                        decision_deadline_monotonic=deadline,
                        objective=objective,
                        excluded_action_fingerprints=tuple(excluded_action_fingerprints),
                        confirmed_turn_history=(
                            confirmed_turn_history or ConfirmedTurnExecutionHistory()
                        ),
                        combat_truth=combat_truth,
                    ),
                )
            except Exception as exc:
                return self._planner_envelope(
                    kind="BLOCKED", reason="FIGHT_POLICY_EXCEPTION",
                    disposition=PlannerDisposition.FAULT,
                    dependency="FIGHT_POLICY",
                    failure_class=PlannerFailureClass.POLICY_FAULT,
                    policy_exception=f"{type(exc).__name__}: {exc}",
                    policy_id=resolved_policy_id,
                )
            decision = invocation.decision
            policy_invocation_compatibility_adapter = bool(invocation.compatibility_adapter)
            if not isinstance(decision, FightDecision):
                return self._planner_envelope(
                    kind="BLOCKED", reason="INVALID_FIGHT_POLICY_RESULT",
                    disposition=PlannerDisposition.FAULT,
                    dependency="FIGHT_POLICY_CONTRACT",
                    failure_class=PlannerFailureClass.CONTRACT_VIOLATION,
                    policy_result_type=type(decision).__name__,
                    policy_id=resolved_policy_id,
                )
            policy_elapsed_ms = max(0.0, (time.monotonic() - policy_started) * 1000.0)
            # Generic fallback for policies that do not implement candidate-level
            # exclusion: never replay a quarantined physical action. TacticalPolicy
            # normally chooses an alternate candidate before this boundary.
            if decision.fingerprint() in set(excluded_action_fingerprints):
                from anka_platform.core.fight.decision_contract import FightDecisionKind
                decision = FightDecision(FightDecisionKind.END_TURN, "QUARANTINED_ACTION_NO_ALTERNATIVE")

        elapsed_ms = max(0.0, (time.monotonic() - decision_started) * 1000.0)
        end_frame_error = None
        try:
            end_frame = self.frame_assembler.capture(lane.account_id)
            end_snapshot = end_frame.raw_owner_snapshot
        except CombatFrameUnavailable as exc:
            end_frame = None
            end_snapshot = lane.snapshot()
            end_frame_error = {"reason": exc.reason, "context": dict(exc.context)}
        end_revision = int(end_snapshot.revision)
        end_turn = self._turn_fingerprint(end_snapshot)
        configured_budget_seconds = (
            float(self.fight_ai.decision_budget_seconds) if self.fight_ai is not None else None
        )
        configured_budget_ms = (
            configured_budget_seconds * 1000.0 if configured_budget_seconds is not None else None
        )
        diagnostics = {
            "decision_elapsed_ms": round(elapsed_ms, 3),
            "combat_frame_capture_ms": round(frame_capture_ms, 3),
            "policy_decision_ms": round(policy_elapsed_ms, 3),
            "decision_budget_utilization": (
                round(policy_elapsed_ms / configured_budget_ms, 4)
                if configured_budget_ms not in (None, 0.0) else None
            ),
            "decision_budget_overrun_ms": (
                round(max(0.0, policy_elapsed_ms - configured_budget_ms), 3)
                if configured_budget_ms is not None else None
            ),
            "decision_start_revision": start_revision,
            "decision_end_revision": end_revision,
            "policy_id": resolved_policy_id,
            "control_mode": control_mode.value,
            "decision_id": decision_id,
            "session_id": (self.session_plan.session_id if self.session_plan is not None else None),
            "mission_id": (self.session_plan.mission_id if self.session_plan is not None else None),
            "account_id": lane.account_id,
            "canonical_revision": start_revision,
            "turn_key": list(start_turn[1:]),
            "spell_bar_verification": spell_bar_verification,
            "spell_variant_substitutions": list(spell_variant_substitutions),
            "quarantined_action_count": len(excluded_action_fingerprints),
            "policy_invocation_compatibility_adapter": policy_invocation_compatibility_adapter,
            "combat_truth_availability": combat_truth.as_dict(),
            **frame.diagnostics(),
            "decision_end_combat_frame_id": (end_frame.frame_id if end_frame is not None else None),
            "decision_end_combat_frame_semantic_fingerprint": (
                end_frame.semantic_fingerprint if end_frame is not None else None
            ),
            "decision_end_combat_frame_provenance_fingerprint": (
                end_frame.provenance_fingerprint if end_frame is not None else None
            ),
            "decision_end_combat_frame_error": end_frame_error,
        }
        if self.fight_ai is not None:
            diagnostics["decision_budget_seconds"] = float(self.fight_ai.decision_budget_seconds)
        if start_turn != end_turn:
            return self._planner_envelope(
                kind="WAIT", reason="DECISION_STALE_TURN",
                disposition=PlannerDisposition.WAIT_EXTERNAL,
                dependency="TURN_STATE",
                failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
                **diagnostics,
                decision_start_turn=start_turn,
                decision_end_turn=end_turn,
            )
        if end_frame is None:
            return self._planner_envelope(
                kind="WAIT", reason="DECISION_END_FRAME_UNAVAILABLE",
                disposition=PlannerDisposition.WAIT_EXTERNAL,
                dependency="COMBAT_FRAME",
                failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
                **diagnostics,
            )
        if frame.semantic_fingerprint != end_frame.semantic_fingerprint:
            return self._planner_envelope(
                kind="WAIT", reason="DECISION_STALE_COMBAT_FRAME",
                disposition=PlannerDisposition.WAIT_EXTERNAL,
                dependency="DECISION_STATE",
                failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL,
                **diagnostics,
                decision_start_frame_id=frame.frame_id,
                decision_end_frame_id=end_frame.frame_id,
                decision_semantic_drift=self.frame_assembler.semantic_drift_for_snapshots(
                    frame.snapshots, end_frame.snapshots, max_changes=32,
                ),
            )
        result = self._decision_payload(decision)
        result.update(diagnostics)
        # Optional read-only forensic trace.  Composition injects the concrete
        # builder; core/fight stays independent of FightAI implementation details.
        # The trace is never consulted by execution and cannot authorize input.
        if self.decision_trace_builder is not None:
            try:
                trace_started = time.monotonic()
                result["fight_ai_trace"] = self.decision_trace_builder(
                    kernel=self.kernel,
                    snapshot=snapshot,
                    account_id=lane.account_id,
                    local_actor_id=local_actor_id,
                    control_mode=control_mode.value,
                    policy_id=resolved_policy_id,
                    decision_id=decision_id,
                    objective=objective,
                    decision_payload=result,
                    profile=profile,
                )
                trace_elapsed_ms = max(0.0, (time.monotonic() - trace_started) * 1000.0)
                result["fight_ai_trace_build_ms"] = round(trace_elapsed_ms, 3)
                if isinstance(result.get("fight_ai_trace"), dict):
                    result["fight_ai_trace"]["trace_build_ms"] = round(trace_elapsed_ms, 3)
            except Exception as exc:
                # Fight intelligence is auxiliary. Never replace a valid decision with
                # an observability failure, but make the missing evidence explicit.
                result["fight_ai_trace"] = {
                    "schema_version": 1,
                    "kind": "FIGHT_AI_DECISION_TRACE",
                    "decision_id": decision_id,
                    "account_id": lane.account_id,
                    "canonical_revision": start_revision,
                    "trace_error": f"{type(exc).__name__}: {exc}",
                }
        return result

from __future__ import annotations

from dataclasses import replace
import inspect
from typing import Mapping
from uuid import uuid4

from anka_platform.core.failures import CoreFailureCode, SessionCompileError
from anka_platform.core.health import HealthStatus, ProtocolCapabilityReport
from anka_platform.core.models import ControlMode, MembershipRequirement, PartyLeadership, SessionMember
from anka_platform.core.registry import PolicyRegistry
from anka_platform.core.ports.fight_policy import FightPolicy
from anka_platform.core.ports.passive_policy import PassiveTurnPolicy
from anka_platform.core.ports.team_strategy import TeamStrategy
from anka_platform.core.ports.placement_policy import PlacementPolicy
from anka_platform.core.session import PlayerProfile, SessionPlan, SessionStopConditions
from anka_platform.core.routes import normalize_coordinate, normalize_route_directions, require_closed_cycle, route_source_coordinates
from anka_platform.missions.models import MissionDefinition


class SessionCompiler:
    """Compile selected profiles + mission intent into a fail-closed SessionPlan.

    The registry intentionally remains a generic namespace for historical and
    tooling compatibility.  The compiler is the current-run boundary: every
    policy selected into an executable SessionPlan must satisfy its core port
    before the session can be armed.
    """

    def __init__(self, policies: PolicyRegistry) -> None:
        self.policies = policies

    @staticmethod
    def _policy_signature_error(*, policy: object, namespace: str) -> str | None:
        """Validate that a selected policy can actually be called by its port.

        ``runtime_checkable Protocol`` verifies attribute presence, not callable
        shape.  A ``decide(self)`` method therefore satisfies ``isinstance`` even
        though the live decision service cannot invoke it.  Current-session
        preflight binds the concrete callable against the supported invocation
        shape so malformed replacements fail before control is armed.
        """
        method_name = {
            "fight": "decide",
            "passive": "decide",
            "team": "objectives",
            "placement": "select_cell",
            "world": "select_target",
        }.get(str(namespace))
        if not method_name:
            return None
        method = getattr(policy, method_name, None)
        if not callable(method):
            return f"missing callable {method_name}"
        try:
            signature = inspect.signature(method)
            parameters = signature.parameters
            has_var_kwargs = any(
                param.kind is inspect.Parameter.VAR_KEYWORD for param in parameters.values()
            )
            marker = object()
            if namespace == "fight":
                if "planner_context" not in parameters and not has_var_kwargs:
                    return "decide must accept the current planner_context keyword"
                signature.bind(marker, marker, 1, marker, planner_context=marker)
            elif namespace == "passive":
                if "planner_context" not in parameters and not has_var_kwargs:
                    return "decide must accept the current planner_context keyword"
                signature.bind(planner_context=marker)
            elif namespace == "team":
                signature.bind(session_plan=marker, snapshots={})
            elif namespace == "placement":
                signature.bind(
                    account_id="cra", snapshot=marker, available_cells=(1,), kernel=marker
                )
            elif namespace == "world":
                signature.bind(session_plan=marker, snapshots={})
        except (TypeError, ValueError) as exc:
            return f"{method_name}{signature if 'signature' in locals() else ''}: {exc}"
        return None

    @staticmethod
    def _require_policy_port(*, policy: object, port: type, namespace: str, policy_id: str, account_id: str | None = None) -> None:
        context: dict[str, object] = {
            "namespace": namespace,
            "policy_id": str(policy_id),
            "required_port": getattr(port, "__name__", str(port)),
        }
        if account_id is not None:
            context["account_id"] = str(account_id)
        if not isinstance(policy, port):
            raise SessionCompileError(
                CoreFailureCode.INVALID_SESSION,
                f"registered {namespace} policy violates its core port contract",
                **context,
            )
        signature_error = SessionCompiler._policy_signature_error(
            policy=policy, namespace=namespace
        )
        if signature_error is not None:
            raise SessionCompileError(
                CoreFailureCode.INVALID_SESSION,
                f"registered {namespace} policy has an incompatible callable signature",
                **context,
                signature_error=signature_error,
            )

    def compile(
        self,
        mission: MissionDefinition,
        *,
        selected_account_ids: tuple[str, ...] | list[str],
        player_profiles: Mapping[str, PlayerProfile],
        protocol_report: ProtocolCapabilityReport,
        session_id: str | None = None,
        leader_account_id: str | None = None,
        required_account_ids: tuple[str, ...] | list[str] | None = None,
        control_modes: Mapping[str, ControlMode] | None = None,
        fight_policy_ids: Mapping[str, str | None] | None = None,
        passive_policy_ids: Mapping[str, str | None] | None = None,
        placement_policy_ids: Mapping[str, str | None] | None = None,
        combat_profile_ids: Mapping[str, str | None] | None = None,
        route_start: tuple[int, int] | list[int] | None = None,
        route_directions: tuple[str, ...] | list[str] | str | None = None,
        route_coordinates: tuple[tuple[int, int], ...] | list[tuple[int, int]] | None = None,
        route_loop: bool | None = None,
        target_min_monsters: int | None = None,
        target_max_monsters: int | None = None,
        target_wins: int | None = None,
        max_attempts: int | None = None,
        stop_on_loss: bool | None = None,
        stop_on_unknown: bool | None = None,
    ) -> SessionPlan:
        if protocol_report.status is not HealthStatus.READY:
            raise SessionCompileError(CoreFailureCode.PROTOCOL_NOT_READY, "protocol capability report is not READY", status=protocol_report.status.value)
        missing_capabilities = protocol_report.missing(mission.required_capabilities)
        if missing_capabilities:
            raise SessionCompileError(CoreFailureCode.MISSING_CAPABILITY, "protocol is missing mission-required capabilities", capabilities=missing_capabilities)

        selected: list[str] = []
        for raw in selected_account_ids:
            account_id = str(raw).strip()
            if not account_id:
                continue
            if account_id in selected:
                raise SessionCompileError(CoreFailureCode.INVALID_SESSION, "duplicate selected account", account_id=account_id)
            selected.append(account_id)
        if not selected:
            raise SessionCompileError(CoreFailureCode.INVALID_SESSION, "at least one account must be selected")

        profiles: list[PlayerProfile] = []
        for account_id in selected:
            profile = player_profiles.get(account_id)
            if profile is None:
                raise SessionCompileError(CoreFailureCode.PROFILE_NOT_FOUND, "selected account has no player profile", account_id=account_id)
            profiles.append(profile)

        windows: dict[str, str] = {}
        for profile in profiles:
            token = profile.window_title_contains.casefold()
            other = windows.get(token)
            if other is not None:
                raise SessionCompileError(CoreFailureCode.DUPLICATE_IDENTITY, "selected profiles share one window identity", account_id=profile.account_id, other_account_id=other)
            windows[token] = profile.account_id

        explicit_required_membership = required_account_ids is not None
        required_set = set(str(item).strip() for item in (required_account_ids or ()) if str(item).strip())
        if not explicit_required_membership:
            required_set = {profile.account_id for profile in profiles if profile.default_requirement is MembershipRequirement.REQUIRED}
        missing_required = tuple(sorted(required_set.difference(selected)))
        if missing_required:
            raise SessionCompileError(CoreFailureCode.REQUIRED_MEMBER_MISSING, "required accounts are not selected", accounts=missing_required)

        inferred_leaders = [profile.account_id for profile in profiles if profile.default_leadership is PartyLeadership.LEADER]
        leader = str(leader_account_id).strip() if leader_account_id is not None else (inferred_leaders[0] if len(inferred_leaders) == 1 else "")
        if leader not in selected:
            raise SessionCompileError(CoreFailureCode.INVALID_LEADER, "session requires exactly one selected leader", leader_account_id=leader or None)

        control_modes = control_modes or {}
        fight_policy_ids = fight_policy_ids or {}
        passive_policy_ids = passive_policy_ids or {}
        placement_policy_ids = placement_policy_ids or {}
        combat_profile_ids = combat_profile_ids or {}

        policy_set = None
        if mission.fight_policy_set_id:
            if not self.policies.has_fight_policy_set(mission.fight_policy_set_id):
                raise SessionCompileError(
                    CoreFailureCode.MISSING_POLICY,
                    "unknown FightPolicySet",
                    policy_set_id=mission.fight_policy_set_id,
                )
            policy_set = self.policies.require_fight_policy_set(mission.fight_policy_set_id)
            required_team_strategy = getattr(policy_set, "required_team_strategy_id", None)
            if required_team_strategy and str(mission.team_strategy_id or "").strip() != str(required_team_strategy):
                raise SessionCompileError(
                    CoreFailureCode.INVALID_SESSION,
                    "FightPolicySet requires a compatible TeamStrategy",
                    policy_set_id=mission.fight_policy_set_id,
                    required_team_strategy_id=required_team_strategy,
                    team_strategy_id=mission.team_strategy_id,
                )

        members: list[SessionMember] = []
        for profile in profiles:
            account_id = profile.account_id
            control = control_modes.get(account_id, profile.default_control_mode)
            requirement = (
                MembershipRequirement.REQUIRED
                if account_id in required_set
                else (MembershipRequirement.OPTIONAL if explicit_required_membership else profile.default_requirement)
            )
            leadership = PartyLeadership.LEADER if account_id == leader else PartyLeadership.MEMBER
            default_fight_policy_id = (
                policy_set.policy_for_active(profile.default_fight_policy_id)
                if policy_set is not None
                else profile.default_fight_policy_id
            )
            default_passive_policy_id = (
                policy_set.policy_for_passive(profile.default_passive_policy_id)
                if policy_set is not None
                else profile.default_passive_policy_id
            )
            default_placement_policy_id = (
                policy_set.placement_for(
                    passive=(control is ControlMode.PASSIVE),
                    profile_default=profile.default_placement_policy_id,
                )
                if policy_set is not None
                else profile.default_placement_policy_id
            )
            fight_policy_id = fight_policy_ids.get(account_id, default_fight_policy_id)
            passive_policy_id = passive_policy_ids.get(account_id, default_passive_policy_id)
            placement_policy_id = placement_policy_ids.get(account_id, default_placement_policy_id)
            combat_profile_id = combat_profile_ids.get(account_id, profile.default_combat_profile_id or account_id)

            if leadership is PartyLeadership.LEADER and requirement is not MembershipRequirement.REQUIRED:
                raise SessionCompileError(
                    CoreFailureCode.INVALID_SESSION,
                    "party leader must be a required member",
                    account_id=account_id,
                )
            if control is ControlMode.ACTIVE and requirement is not MembershipRequirement.REQUIRED:
                raise SessionCompileError(
                    CoreFailureCode.INVALID_SESSION,
                    "active combat members must be required so join/turn ownership is deterministic",
                    account_id=account_id,
                )

            if control is ControlMode.ACTIVE:
                if not fight_policy_id or not self.policies.has_fight(fight_policy_id):
                    raise SessionCompileError(CoreFailureCode.MISSING_POLICY, "active member requires a registered FightPolicy", account_id=account_id, policy_id=fight_policy_id)
                self._require_policy_port(
                    policy=self.policies.require_fight(fight_policy_id),
                    port=FightPolicy, namespace="fight", policy_id=fight_policy_id, account_id=account_id,
                )
                if policy_set is not None and not policy_set.require_compatible_active(fight_policy_id):
                    raise SessionCompileError(
                        CoreFailureCode.INVALID_SESSION,
                        "active FightPolicy is incompatible with selected FightPolicySet",
                        account_id=account_id, policy_set_id=mission.fight_policy_set_id, policy_id=fight_policy_id,
                        compatible_policy_ids=policy_set.compatible_active_policy_ids,
                    )
                passive_policy_id = None
            else:
                if not passive_policy_id or not self.policies.has_passive(passive_policy_id):
                    raise SessionCompileError(CoreFailureCode.MISSING_POLICY, "passive member requires a registered PassiveTurnPolicy", account_id=account_id, policy_id=passive_policy_id)
                self._require_policy_port(
                    policy=self.policies.require_passive(passive_policy_id),
                    port=PassiveTurnPolicy, namespace="passive", policy_id=passive_policy_id, account_id=account_id,
                )
                if policy_set is not None and not policy_set.require_compatible_passive(passive_policy_id):
                    raise SessionCompileError(
                        CoreFailureCode.INVALID_SESSION,
                        "passive FightPolicy is incompatible with selected FightPolicySet",
                        account_id=account_id, policy_set_id=mission.fight_policy_set_id, policy_id=passive_policy_id,
                        compatible_policy_ids=policy_set.compatible_passive_policy_ids,
                    )
                fight_policy_id = None

            if placement_policy_id and not self.policies.has_placement(placement_policy_id):
                raise SessionCompileError(CoreFailureCode.MISSING_POLICY, "unknown PlacementPolicy", account_id=account_id, policy_id=placement_policy_id)
            if placement_policy_id:
                self._require_policy_port(
                    policy=self.policies.require_placement(placement_policy_id),
                    port=PlacementPolicy, namespace="placement", policy_id=placement_policy_id, account_id=account_id,
                )

            members.append(SessionMember(
                account_id=account_id, control_mode=control, requirement=requirement,
                leadership=leadership, fight_policy_id=fight_policy_id,
                passive_policy_id=passive_policy_id, placement_policy_id=placement_policy_id,
                combat_profile_id=(combat_profile_id if control is ControlMode.ACTIVE else None),
            ))

        if mission.team_strategy_id and not self.policies.has_team(mission.team_strategy_id):
            raise SessionCompileError(CoreFailureCode.MISSING_POLICY, "unknown TeamStrategy", policy_id=mission.team_strategy_id)
        if mission.team_strategy_id:
            self._require_policy_port(
                policy=self.policies.require_team(mission.team_strategy_id),
                port=TeamStrategy, namespace="team", policy_id=mission.team_strategy_id,
            )

        stop = SessionStopConditions(
            target_wins=(mission.stop.target_wins if target_wins is None else target_wins),
            max_attempts=(mission.stop.max_attempts if max_attempts is None else max_attempts),
            stop_on_loss=(mission.stop.stop_on_loss if stop_on_loss is None else stop_on_loss),
            stop_on_unknown=(mission.stop.stop_on_unknown if stop_on_unknown is None else stop_on_unknown),
        )

        # New sessions carry directional intent as their authoritative route.
        # Legacy waypoint missions remain compilable while they are migrated.
        effective_loop = mission.route_loop if route_loop is None else bool(route_loop)
        requested_directional = route_start is not None or route_directions is not None
        requested_legacy = route_coordinates is not None
        mission_directional = mission.route_start is not None or bool(mission.route_directions)

        # Explicit request intent always wins over mission defaults. New callers
        # should use start+directions, but bounded legacy/API compatibility still
        # requires an explicit route_coordinates override to remain authoritative.
        if requested_directional:
            if route_start is None or route_directions is None:
                raise SessionCompileError(CoreFailureCode.INVALID_SESSION, "route_start and route_directions must be supplied together")
            effective_start = normalize_coordinate(route_start, field_name="route_start")
            effective_directions = normalize_route_directions(route_directions)
            effective_coordinates = ()
        elif requested_legacy:
            effective_start = None
            effective_directions = ()
            effective_coordinates = tuple(route_coordinates)
        elif mission_directional:
            if mission.route_start is None or not mission.route_directions:
                raise SessionCompileError(CoreFailureCode.INVALID_SESSION, "mission directional route is incomplete")
            effective_start = normalize_coordinate(mission.route_start, field_name="route_start")
            effective_directions = normalize_route_directions(mission.route_directions)
            effective_coordinates = ()
        else:
            effective_start = None
            effective_directions = ()
            effective_coordinates = tuple(mission.route_coordinates)

        if effective_directions:
            if not effective_start:
                raise SessionCompileError(CoreFailureCode.INVALID_SESSION, "directional route requires a starting coordinate")
            if effective_loop:
                require_closed_cycle(effective_start, effective_directions)
            effective_coordinates = route_source_coordinates(effective_start, effective_directions)

        return SessionPlan(
            session_id=session_id or uuid4().hex,
            mission_id=mission.id,
            members=tuple(members),
            player_profiles=tuple(profiles),
            protocol_adapter_id=protocol_report.adapter_id,
            canonical_contract_version=protocol_report.canonical_contract_version,
            team_strategy_id=mission.team_strategy_id,
            route_id=mission.route_id,
            target_policy_id=mission.target_policy_id,
            fight_policy_set_id=mission.fight_policy_set_id,
            stop=stop,
            required_capabilities=mission.required_capabilities,
            route_start_coordinate=effective_start,
            route_directions=effective_directions,
            route_coordinates=tuple(effective_coordinates),
            route_loop=effective_loop,
            target_min_monsters=(mission.target_min_monsters if target_min_monsters is None else target_min_monsters),
            target_max_monsters=(mission.target_max_monsters if target_max_monsters is None else target_max_monsters),
        )

from __future__ import annotations

from anka_game_kernel.domain.ids import CellId
from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id


def _enemy_cells(snapshot) -> tuple[int, ...]:
    local_id = authoritative_canonical_local_actor_id(snapshot)
    actors = tuple(getattr(getattr(snapshot, "fight", None), "actors", ()) or ())
    local_actor = next((a for a in actors if local_id is not None and int(a.actor_id) == local_id), None)
    if local_actor is None or local_actor.side_relation.status is not ValueStatus.KNOWN:
        return ()
    local_side = local_actor.side_relation.value
    cells = []
    for actor in actors:
        if int(actor.actor_id) == local_id:
            continue
        if actor.cell_id.status is not ValueStatus.KNOWN or actor.cell_id.value is None:
            continue
        if actor.alive.status is ValueStatus.KNOWN and actor.alive.value is False:
            continue
        if actor.side_relation.status is ValueStatus.KNOWN and actor.side_relation.value != local_side:
            cells.append(int(actor.cell_id.value))
    return tuple(cells)


class CurrentDefaultPlacementPolicy:
    """R5.94-compatible preference: maximize distance from certified enemies."""

    def select_cell(self, *, account_id: str, snapshot, available_cells, kernel) -> int | None:
        cells = tuple(sorted(int(cell) for cell in available_cells))
        if not cells:
            return None
        enemies = _enemy_cells(snapshot)
        if kernel is None or not enemies:
            return min(cells)
        geometry = kernel.geometry

        def score(cell: int):
            coord = geometry.cell_to_coordinate(CellId(cell))
            nearest = min(
                geometry.distance(coord, geometry.cell_to_coordinate(CellId(enemy)))
                for enemy in enemies
            )
            return (int(nearest), -int(cell))

        return max(cells, key=score)


class PassiveFrontProtectorPlacementPolicy:
    """Deterministic passive policy: choose the legal cell nearest certified enemies."""

    def select_cell(self, *, account_id: str, snapshot, available_cells, kernel) -> int | None:
        cells = tuple(sorted(int(cell) for cell in available_cells))
        if not cells:
            return None
        enemies = _enemy_cells(snapshot)
        if kernel is None or not enemies:
            return min(cells)
        geometry = kernel.geometry

        def score(cell: int):
            coord = geometry.cell_to_coordinate(CellId(cell))
            nearest = min(
                geometry.distance(coord, geometry.cell_to_coordinate(CellId(enemy)))
                for enemy in enemies
            )
            return (int(nearest), int(cell))

        return min(cells, key=score)

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class HealthStatus(str, Enum):
    READY = "READY"
    DEGRADED = "DEGRADED"
    BLOCKED = "BLOCKED"
    UNKNOWN = "UNKNOWN"


def _text(value: str | None) -> str | None:
    if value is None:
        return None
    token = str(value).strip()
    return token or None


def _tokens(values) -> tuple[str, ...]:
    result: list[str] = []
    for value in values or ():
        token = str(value).strip()
        if token and token not in result:
            result.append(token)
    return tuple(result)


@dataclass(frozen=True, slots=True)
class HealthReport:
    component: str
    status: HealthStatus
    ready: bool
    blockers: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    last_success: str | None = None
    last_failure: str | None = None
    session_id: str | None = None
    account_id: str | None = None

    def __post_init__(self) -> None:
        component = str(self.component).strip()
        if not component:
            raise ValueError("component must not be empty")
        object.__setattr__(self, "component", component)
        if not isinstance(self.status, HealthStatus):
            object.__setattr__(self, "status", HealthStatus(str(self.status).upper()))
        object.__setattr__(self, "ready", bool(self.ready))
        object.__setattr__(self, "blockers", _tokens(self.blockers))
        object.__setattr__(self, "warnings", _tokens(self.warnings))
        object.__setattr__(self, "last_success", _text(self.last_success))
        object.__setattr__(self, "last_failure", _text(self.last_failure))
        object.__setattr__(self, "session_id", _text(self.session_id))
        object.__setattr__(self, "account_id", _text(self.account_id))

    @classmethod
    def ready_report(cls, component: str, *, session_id: str | None = None, account_id: str | None = None, warnings=()) -> "HealthReport":
        return cls(component=component, status=HealthStatus.READY, ready=True, warnings=tuple(warnings), session_id=session_id, account_id=account_id)

    def to_dict(self) -> dict:
        return {
            "component": self.component,
            "status": self.status.value,
            "ready": self.ready,
            "blockers": list(self.blockers),
            "warnings": list(self.warnings),
            "last_success": self.last_success,
            "last_failure": self.last_failure,
            "session_id": self.session_id,
            "account_id": self.account_id,
        }


@dataclass(frozen=True, slots=True)
class ProtocolCapabilityReport:
    adapter_id: str
    canonical_contract_version: int
    capabilities: frozenset[str]
    status: HealthStatus = HealthStatus.READY

    def __post_init__(self) -> None:
        adapter_id = str(self.adapter_id).strip()
        if not adapter_id:
            raise ValueError("adapter_id must not be empty")
        if int(self.canonical_contract_version) < 1:
            raise ValueError("canonical_contract_version must be >= 1")
        normalized = frozenset(str(item).strip().upper() for item in self.capabilities if str(item).strip())
        object.__setattr__(self, "adapter_id", adapter_id)
        object.__setattr__(self, "canonical_contract_version", int(self.canonical_contract_version))
        object.__setattr__(self, "capabilities", normalized)

    def supports(self, capability: str) -> bool:
        return str(capability).strip().upper() in self.capabilities

    def missing(self, required: tuple[str, ...] | list[str]) -> tuple[str, ...]:
        missing: list[str] = []
        for item in required:
            token = str(item).strip().upper()
            if token and token not in self.capabilities and token not in missing:
                missing.append(token)
        return tuple(missing)

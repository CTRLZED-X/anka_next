from __future__ import annotations

from typing import Mapping, Protocol, runtime_checkable


@runtime_checkable
class TeamPlacementStrategy(Protocol):
    """Optional policy capability for joint pre-fight team placement.

    Placement remains advisory: PartyMissionController/Kernel still own legal-cell
    admission and ExecutionService remains the only physical-input authority.
    Strategies that do not need joint placement simply do not implement this port.
    """

    def placement_plan(self, *, session_plan, snapshots: Mapping[str, object]) -> object | None: ...

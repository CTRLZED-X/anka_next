from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ControlMode(str, Enum):
    ACTIVE = "ACTIVE"
    PASSIVE = "PASSIVE"


class MembershipRequirement(str, Enum):
    REQUIRED = "REQUIRED"
    OPTIONAL = "OPTIONAL"


class PartyLeadership(str, Enum):
    LEADER = "LEADER"
    MEMBER = "MEMBER"


def _required_text(value: str, field_name: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        raise ValueError(f"{field_name} must not be empty")
    return normalized


def _optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


@dataclass(frozen=True, slots=True)
class SessionMember:
    """Resolved semantic behavior for one account in one automation session.

    Leadership, requirement, and control mode are deliberately independent
    dimensions.  This prevents role-enum explosion and keeps new accounts
    configuration driven.
    """

    account_id: str
    control_mode: ControlMode
    requirement: MembershipRequirement
    leadership: PartyLeadership
    fight_policy_id: str | None = None
    passive_policy_id: str | None = None
    placement_policy_id: str | None = None
    combat_profile_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "account_id", _required_text(self.account_id, "account_id"))
        object.__setattr__(self, "fight_policy_id", _optional_text(self.fight_policy_id))
        object.__setattr__(self, "passive_policy_id", _optional_text(self.passive_policy_id))
        object.__setattr__(self, "placement_policy_id", _optional_text(self.placement_policy_id))
        object.__setattr__(self, "combat_profile_id", _optional_text(self.combat_profile_id))

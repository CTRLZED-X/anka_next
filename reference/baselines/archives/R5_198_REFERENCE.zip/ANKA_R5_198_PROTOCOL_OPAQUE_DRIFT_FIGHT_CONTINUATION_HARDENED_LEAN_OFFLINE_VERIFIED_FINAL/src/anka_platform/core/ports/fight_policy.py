from __future__ import annotations

from typing import Protocol, runtime_checkable

from anka_platform.contracts.canonical_state import CanonicalSnapshot
from anka_platform.core.fight.decision_contract import FightDecision
from anka_platform.core.fight.planner_contract import PlannerInvocationContext


@runtime_checkable
class FightPolicy(Protocol):
    def decide(
        self,
        kernel,
        snapshot: CanonicalSnapshot,
        local_actor_id: int,
        profile,
        *,
        planner_context: PlannerInvocationContext,
    ) -> FightDecision: ...

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class SessionCommandKind(str, Enum):
    LAUNCH = "LAUNCH"
    PAUSE = "PAUSE"
    RESUME = "RESUME"
    STOP = "STOP"
    RESTART = "RESTART"


@dataclass(frozen=True, slots=True)
class SessionCommand:
    kind: SessionCommandKind
    session_id: str

    def __post_init__(self) -> None:
        session_id = str(self.session_id).strip()
        if not session_id:
            raise ValueError("session_id must not be empty")
        object.__setattr__(self, "session_id", session_id)

# Platform Core Contract

Platform Core coordinates immutable session intent, party/world/fight lifecycle and policy selection.

Allowed dependencies: canonical/domain contracts, Game Kernel APIs through explicit services, party abstractions, injected ports.

Forbidden responsibilities: raw protocol decoding, web/UI, mouse/keyboard/window implementation, packet capture, persistent runtime wiring.

Every account action is selected through the shared party authority. World/Fight workflows classify lifecycle state; they do not bypass execution safety.

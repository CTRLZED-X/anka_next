from __future__ import annotations

from dataclasses import dataclass, field
import time
from typing import Callable

from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id
from anka_platform.party.shared_fight import SharedFightManager, SharedFightStatus
from anka_platform.core.fight.policy_resolution import LegacyTurnPolicyResolver
from anka_platform.core.fight.recovery import RecoveryDirectiveKind, TurnRecoveryPolicy
from anka_platform.core.fight.planner_contract import (
    ConfirmedTurnAction,
    ConfirmedTurnExecutionHistory,
    PlannerDisposition,
    normalize_planner_result,
)
from anka_platform.core.fight.action_outcome import CombatActionOutcome, CombatActionPhase
from anka_platform.core.fight.action_transaction import PendingCombatTransaction, ReconciliationPollState
from anka_platform.core.fight.combat_frame import CombatFrameAssembler
from anka_platform.core.fight.decision_contract import FightDecision, action_key_from_payload
from anka_platform.control_correlation import (
    failure_attribution,
    failure_code as execution_failure_code,
    invoke_correlated_activation,
    retry_allowed as execution_retry_allowed,
)
from anka_platform.canonical_readiness import local_turn_readiness_payload


@dataclass(slots=True)
class _TurnState:
    turn_key: tuple | None = None
    activated: bool = False
    action_count: int = 0
    accepted_actions: int = 0
    confirmed_actions: list[ConfirmedTurnAction] = field(default_factory=list)
    last_action_revision: int | None = None
    last_action_fingerprint: tuple | None = None
    last_action_kind: str | None = None
    last_move_from_cell: int | None = None
    last_move_to_cell: int | None = None
    # Consecutive MOVE-only chain for this semantic turn.  R5.145 uses it to
    # reject A->B->C->A style cycles, not only the historical immediate A->B->A
    # reversal.  Any accepted non-MOVE action clears the chain.
    move_chain_cells: set[int] = field(default_factory=set)
    end_turn_accepted: bool = False
    blocked_key: tuple | None = None
    blocked_count: int = 0
    owner_wait_key: tuple | None = None
    owner_wait_count: int = 0
    owner_mismatch_key: tuple | None = None
    owner_mismatch_count: int = 0
    activation_block_key: tuple | None = None
    activation_block_count: int = 0
    action_block_key: tuple | None = None
    action_block_count: int = 0
    # R5.140: one no-input UNKNOWN may wait for genuinely new Canonical evidence.
    # Store the exact team revision vector and attempted decision so the next poll
    # can avoid spending another full FightAI decision on an unchanged frame.
    pending_no_input_action: dict | None = None
    pending_no_input_revision_vector: tuple[tuple[str, int], ...] | None = None
    pending_no_input_semantic_fingerprint: str | None = None
    pending_no_input_failure_code: str | None = None
    # Canonical ActionKeys that recovery has excluded for this exact turn. The
    # controller independently verifies the next decision does not violate the
    # exclusion contract, so a broken planner/quarantine seam cannot loop until
    # the parent campaign watchdog.
    quarantined_action_keys: set[tuple] = field(default_factory=set)
    safe_recovery_count: int = 0
    force_end_turn_reason: str | None = None
    pending_combat_transaction: PendingCombatTransaction | None = None
    # If the client repeatedly ignores a proven END_TURN click, stop generating
    # more physical input and let the game timer/authoritative handoff advance the
    # turn.  The next turn resets this state automatically.
    end_turn_no_semantic_failures: int = 0
    end_turn_auto_wait: bool = False
    # R5.147 turn-liveness defense.  Heartbeat is a non-click cursor move and is
    # attempted at most once per authoritative semantic turn.
    turn_heartbeat_attempted: bool = False
    turn_heartbeat_sent: bool = False
    planner_slice_count: int = 0
    planner_last_coverage_count: int | None = None
    planner_no_progress_count: int = 0
    turn_started_monotonic: float | None = None
    first_game_action_monotonic: float | None = None
    # The authoritative resource baseline may arrive immediately before
    # TURN_STARTED. Require one unchanged readiness-evidence poll before the
    # first FightAI invocation so a burst cannot be consumed half-applied. The
    # signature intentionally excludes the global Canonical revision so
    # unrelated traffic cannot starve the turn.
    turn_readiness_signature: tuple | None = None
    turn_readiness_stable_polls: int = 0
    turn_readiness_stabilized: bool = False
    # A genuinely missing/stale AP/MP stream must not wait forever. Count only
    # the causal readiness gap for this semantic turn (not global revisions), so
    # unrelated traffic cannot reset the liveness budget.
    turn_readiness_wait_key: tuple | None = None
    turn_readiness_wait_count: int = 0


class PartyCombatController:
    """Single parent-owned ACTIVE-fight turn orchestration authority.

    Each ``step`` performs at most one physical game action.  Canonical State
    stays authoritative; the controller only remembers turn-local guards needed
    to avoid duplicate decisions/actions while scripts remain thin orchestrators.
    """

    def __init__(
        self,
        party,
        *,
        decision_provider: Callable[[str], dict],
        turn_policy_resolver=None,
        max_actions_per_turn: int = 12,
        max_blocked_stall_polls: int = 15,
        max_safe_recoveries_per_turn: int = 4,
        max_planner_replan_slices: int = 5,
        max_planner_no_progress_slices: int = 2,
        max_planner_replan_seconds: float = 9.0,
        recovery_policy: TurnRecoveryPolicy | None = None,
    ) -> None:
        self.party = party
        self.decision_provider = decision_provider
        self.turn_policy_resolver = turn_policy_resolver or LegacyTurnPolicyResolver(decision_provider)
        self.max_actions_per_turn = max(1, int(max_actions_per_turn))
        self.max_blocked_stall_polls = max(1, int(max_blocked_stall_polls))
        self.max_safe_recoveries_per_turn = max(1, int(max_safe_recoveries_per_turn))
        self.max_planner_replan_slices = max(2, int(max_planner_replan_slices))
        self.max_planner_no_progress_slices = max(1, int(max_planner_no_progress_slices))
        self.max_planner_replan_seconds = max(1.0, float(max_planner_replan_seconds))
        self.recovery_policy = recovery_policy or TurnRecoveryPolicy()
        self._state = _TurnState()

    @staticmethod
    def _known_int(value) -> int | None:
        if value.status is ValueStatus.KNOWN and value.value is not None:
            return int(value.value)
        return None

    @staticmethod
    def _phase(snapshot) -> str | None:
        phase = snapshot.fight.phase
        if phase.status is ValueStatus.KNOWN and phase.value is not None:
            return str(phase.value)
        return None

    @staticmethod
    def _fingerprint(decision: dict) -> tuple:
        try:
            return action_key_from_payload(decision)
        except (TypeError, ValueError):
            # Malformed policy output is not executable. Preserve a stable raw key
            # only for bounded diagnostics until the normal decision validation
            # reports INVALID_FIGHT_AI_DECISION.
            return (
                str(decision.get("kind") or ""), decision.get("spell_id"), decision.get("grade"),
                decision.get("slot_index"), decision.get("target_cell_id"), decision.get("target_actor_id"),
                "MALFORMED_ACTION_CONTRACT",
            )

    @staticmethod
    def _planner_result(decision: dict):
        return normalize_planner_result(decision)

    @staticmethod
    def _planner_progress(decision: dict) -> tuple[int | None, int | None]:
        progress = normalize_planner_result(decision).progress
        if progress is None:
            return None, None
        return progress.completed_units, progress.total_units

    @staticmethod
    def _decision_failure_attribution(reason: str) -> tuple[str, str, str]:
        text = str(reason or "FIGHT_AI_BLOCKED_STALLED")
        token = text.split(":", 1)[0].strip() or "FIGHT_AI_BLOCKED_STALLED"
        if token in {"CURRENT_AP_UNKNOWN", "CURRENT_MP_UNKNOWN", "ACTIVE_ACTOR_UNKNOWN"}:
            return token, "LIVE_TURN_RESOURCES", "PROTOCOL_CANONICAL"
        if token in {"FIGHT_CONTEXT_UNAVAILABLE", "FIGHT_MAP_UNKNOWN"}:
            return token, "FIGHT_MAP_CONTEXT", "KERNEL_CONTEXT"
        if token in {
            "LIVE_SPELL_BAR_UNKNOWN", "LIVE_SPELL_BAR_MISMATCH", "PROFILE_SPELL_BAR_EMPTY",
            "PROFILE_SPELL_BAR_INVALID", "PROTOCOL_SLOT_RESOLVER_UNAVAILABLE",
        }:
            return token, "LIVE_SPELL_PROFILE", "FIGHT_DECISION_SERVICE"
        if token in {"LOCAL_ACTOR_UNKNOWN", "LOCAL_ACTOR_OR_CELL_UNKNOWN", "LOCAL_TEAM_UNKNOWN"}:
            return token, "LOCAL_FIGHT_ACTOR_STATE", "PROTOCOL_CANONICAL"
        if token.startswith("PARTY_SIDE_EVIDENCE_CONFLICT"):
            return "PARTY_SIDE_EVIDENCE_CONFLICT", "PARTY_SIDE_EVIDENCE", "PARTY_EVIDENCE"
        if token == "FIGHT_AI_UNAVAILABLE":
            return token, "FIGHT_POLICY_CONFIGURATION", "FIGHT_DECISION_SERVICE"
        return token if token.isupper() and " " not in token else "FIGHT_AI_BLOCKED_STALLED", "FIGHT_DECISION", "FIGHT_AI"


    @staticmethod
    def _action_payload(payload: dict, runtime_context: dict | None) -> dict:
        result = dict(payload)
        if runtime_context:
            result["_runtime"] = dict(runtime_context)
        return result

    def _progress_token(self, *, view, owner: str | None = None, revision: int | None = None) -> str:
        parts = [
            str(view.fight_instance_id if view.fight_instance_id is not None else "none"),
            str(view.round if view.round is not None else "none"),
            str(view.turn_index if view.turn_index is not None else "none"),
            str(view.active_actor_id if view.active_actor_id is not None else "none"),
            str(owner or "none"),
            str(revision if revision is not None else "none"),
            str(self._state.accepted_actions),
        ]
        return ":".join(parts)

    def _reset_for_turn(self, turn_key: tuple) -> None:
        self._state = _TurnState(turn_key=turn_key, turn_started_monotonic=time.monotonic())

    def _confirmed_turn_history(self, view) -> ConfirmedTurnExecutionHistory:
        """Expose only actions whose semantic game effect is already proven.

        This history belongs to orchestration.  It deliberately does not mutate
        Canonical State, whose job is observed game truth rather than remembering
        which physical commands this controller issued.
        """
        return ConfirmedTurnExecutionHistory(
            fight_instance_id=(int(view.fight_instance_id) if view.fight_instance_id is not None else None),
            round=(int(view.round) if view.round is not None else None),
            turn_index=(int(view.turn_index) if view.turn_index is not None else None),
            actor_id=(int(view.active_actor_id) if view.active_actor_id is not None else None),
            actions=tuple(self._state.confirmed_actions),
        )

    def _record_confirmed_action(
        self,
        *,
        kind: str,
        action_id: str | None = None,
        origin_cell_id: int | None = None,
        target_cell_id: int | None = None,
        spell_id: int | None = None,
        grade: int | None = None,
        slot_index: int | None = None,
        target_actor_id: int | None = None,
        path_distance: int | None = None,
        canonical_revision: int | None = None,
        decision_fingerprint: tuple | None = None,
        reconciliation_outcome: str | None = None,
    ) -> None:
        normalized_action_id = str(action_id) if action_id not in (None, "") else None
        if normalized_action_id is not None and any(
            item.action_id == normalized_action_id for item in self._state.confirmed_actions
        ):
            return
        self._state.confirmed_actions.append(ConfirmedTurnAction(
            kind=str(kind or "").upper(),
            action_id=normalized_action_id,
            origin_cell_id=(int(origin_cell_id) if origin_cell_id is not None else None),
            target_cell_id=(int(target_cell_id) if target_cell_id is not None else None),
            spell_id=(int(spell_id) if spell_id is not None else None),
            grade=(int(grade) if grade is not None else None),
            slot_index=(int(slot_index) if slot_index is not None else None),
            target_actor_id=(int(target_actor_id) if target_actor_id is not None else None),
            path_distance=(int(path_distance) if path_distance is not None else None),
            canonical_revision=(int(canonical_revision) if canonical_revision is not None else None),
            decision_fingerprint=(tuple(decision_fingerprint) if decision_fingerprint is not None else None),
            reconciliation_outcome=(str(reconciliation_outcome) if reconciliation_outcome else None),
        ))

    def _reconcile_pending_combat_input(self, required) -> tuple[ReconciliationPollState, dict | None]:
        """Passively close any reconcilable combat action before FightAI runs.

        ExecutionService is the durable authority for physical uncertainty.  If
        the controller remembers a pending transaction and that authority reports
        no matching pending state, input must remain fenced: disagreement between
        the two state owners is an invariant violation, not permission to continue.
        This method never sends physical input.
        """
        reconciled: dict | None = None
        pending = self._state.pending_combat_transaction
        lanes = tuple(required)
        if pending is not None and pending.account_id is not None:
            lanes = tuple(lane for lane in required if str(lane.account_id) == str(pending.account_id))
            if not lanes:
                return ReconciliationPollState.AUTHORITY_MISMATCH, {
                    "status": "AUTHORITY_MISMATCH",
                    "reason": "PENDING_COMBAT_TRANSACTION_OWNER_UNAVAILABLE",
                    "account_id": pending.account_id,
                    "origin_action_id": pending.origin_action_id,
                }

        saw_authority_hook = False
        for lane in lanes:
            hook = getattr(getattr(lane, "execution", None), "reconcile_combat_action_uncertainty", None)
            if not callable(hook):
                if pending is not None:
                    return ReconciliationPollState.AUTHORITY_MISMATCH, {
                        "status": "AUTHORITY_MISMATCH",
                        "reason": "COMBAT_RECONCILIATION_HOOK_MISSING",
                        "account_id": lane.account_id,
                        "origin_action_id": pending.origin_action_id,
                    }
                continue
            saw_authority_hook = True
            try:
                result = dict(hook("PARTY_COMBAT_CONTROLLER_POLL") or {})
            except Exception as exc:
                # A reconciliation hook exception is an authority failure, not an
                # evidence wait: no Canonical update can repair broken code at the
                # physical-transaction owner. Keep input fenced and surface the
                # exact boundary immediately instead of polling forever.
                return ReconciliationPollState.AUTHORITY_MISMATCH, {
                    "status": "AUTHORITY_MISMATCH",
                    "reason": "COMBAT_RECONCILIATION_AUTHORITY_EXCEPTION",
                    "detail": f"{type(exc).__name__}: {exc}",
                    "account_id": getattr(lane, "account_id", None),
                    "expected_origin_action_id": pending.origin_action_id if pending is not None else None,
                }
            status = str(result.get("status") or "").upper()
            correlated = {**result, "account_id": lane.account_id}
            if status in {"WAITING", "RETAINED", "RECONCILED"}:
                if pending is None:
                    return ReconciliationPollState.AUTHORITY_MISMATCH, {
                        **correlated,
                        "status": "AUTHORITY_MISMATCH",
                        "reason": "UNTRACKED_EXECUTION_COMBAT_TRANSACTION",
                        "authority_reported_status": status,
                    }
                if not pending.matches_reconciliation(correlated):
                    return ReconciliationPollState.AUTHORITY_MISMATCH, {
                        **correlated,
                        "status": "AUTHORITY_MISMATCH",
                        "reason": "COMBAT_RECONCILIATION_CORRELATION_MISMATCH",
                        "authority_reported_status": status,
                        "expected_origin_action_id": pending.origin_action_id,
                        "expected_account_id": pending.account_id,
                        "expected_fight_instance_id": pending.fight_instance_id,
                    }
                if status in {"WAITING", "RETAINED"}:
                    return ReconciliationPollState.WAITING, correlated
                reconciled = correlated
                continue
            if pending is not None:
                return ReconciliationPollState.AUTHORITY_MISMATCH, {
                    **correlated,
                    "status": "AUTHORITY_MISMATCH",
                    "reason": "COMBAT_TRANSACTION_AUTHORITY_MISMATCH",
                    "authority_reported_status": status or "MISSING",
                    "expected_origin_action_id": pending.origin_action_id,
                }

        if pending is not None and not saw_authority_hook:
            return ReconciliationPollState.AUTHORITY_MISMATCH, {
                "status": "AUTHORITY_MISMATCH",
                "reason": "COMBAT_RECONCILIATION_AUTHORITY_UNAVAILABLE",
                "account_id": pending.account_id,
                "expected_origin_action_id": pending.origin_action_id,
            }
        return (ReconciliationPollState.RECONCILED, reconciled) if reconciled is not None else (ReconciliationPollState.CLEAR, None)

    def step(self, *, runtime_context: dict | None = None) -> dict:
        required = tuple(lane for lane in self.party.lanes if lane.required)
        reconcile_state, reconciliation = self._reconcile_pending_combat_input(required)
        snapshots = {lane.account_id: lane.snapshot() for lane in required}
        view = SharedFightManager(self.party).view()
        base = {"shared_fight": view.to_dict()}
        if reconcile_state is ReconciliationPollState.AUTHORITY_MISMATCH:
            pending = self._state.pending_combat_transaction
            mismatch_reason = str((reconciliation or {}).get("reason") or "COMBAT_TRANSACTION_AUTHORITY_MISMATCH")
            failure_code = (
                "COMBAT_RECONCILIATION_CORRELATION_MISMATCH"
                if mismatch_reason == "COMBAT_RECONCILIATION_CORRELATION_MISMATCH"
                else "COMBAT_TRANSACTION_AUTHORITY_MISMATCH"
            )
            return {
                **base,
                "status": "BLOCKED",
                "reason": failure_code,
                "failure_code": failure_code,
                "retry_allowed": False,
                "first_missing_boundary": "COMBAT_TRANSACTION_AUTHORITY",
                "likely_owner": "EXECUTION_SERVICE",
                "account_id": (reconciliation or {}).get("account_id") or (pending.account_id if pending else None),
                "expected_origin_action_id": pending.origin_action_id if pending else None,
                "reconciliation": reconciliation,
                "progress_token": self._progress_token(view=view),
            }
        if reconcile_state is ReconciliationPollState.RECONCILED and reconciliation is not None:
            # Preserve the passive transaction closure on the same controller
            # step that resumes planning. This makes the final status visible in
            # the run store even when a new primitive is selected immediately.
            base["reconciliation"] = dict(reconciliation)
        if reconcile_state is ReconciliationPollState.WAITING:
            return {
                **base,
                "status": "WAIT",
                "reason": "COMBAT_ACTION_RECONCILING",
                "retry_allowed": True,
                "reconciliation": reconciliation,
                "account_id": (reconciliation or {}).get("account_id"),
                "progress_token": ":".join((
                    self._progress_token(view=view),
                    "reconcile",
                    str((reconciliation or {}).get("canonical_revision") or "none"),
                    str(
                        (reconciliation or {}).get("semantic_move_send_state")
                        or (reconciliation or {}).get("semantic_end_turn_send_state")
                        or "unknown"
                    ),
                    str(
                        (reconciliation or {}).get("negative_move_absence_samples")
                        or (reconciliation or {}).get("negative_end_turn_absence_samples")
                        or 0
                    ),
                )),
            }
        if reconcile_state is ReconciliationPollState.RECONCILED:
            outcome = str((reconciliation or {}).get("outcome") or "")
            pending = self._state.pending_combat_transaction
            if pending is not None and not pending.matches_reconciliation(reconciliation):
                return {
                    **base,
                    "status": "BLOCKED",
                    "reason": "COMBAT_RECONCILIATION_CORRELATION_MISMATCH",
                    "failure_code": "COMBAT_RECONCILIATION_CORRELATION_MISMATCH",
                    "retry_allowed": False,
                    "account_id": (reconciliation or {}).get("account_id"),
                    "reconciliation": reconciliation,
                    "expected_origin_action_id": pending.origin_action_id,
                    "progress_token": self._progress_token(view=view),
                }
            pending_kind = pending.kind if pending is not None else None
            pending_origin = pending.origin_cell_id if pending is not None else None
            pending_target = pending.target_cell_id if pending is not None else None
            if outcome in {"NO_MOVE_OBSERVED", "NO_SEMANTIC_MOVE_REQUEST"}:
                if pending is not None:
                    self._state.quarantined_action_keys.add(pending.action_key)
            elif outcome == "NO_SEMANTIC_END_TURN_REQUEST":
                self._state.end_turn_no_semantic_failures += 1
                if self._state.end_turn_no_semantic_failures >= 2:
                    self._state.end_turn_auto_wait = True
            elif outcome == "CAST_CONFIRMED":
                # A physically ambiguous CAST has now been proven and its AP
                # settlement observed. Count the real action, release the temporary
                # ActionKey quarantine, and replan from authoritative current state.
                self._state.action_count += 1
                self._state.accepted_actions += 1
                if pending is not None:
                    self._state.quarantined_action_keys.discard(pending.action_key)
                self._state.move_chain_cells.clear()
                self._state.last_action_kind = "CAST"
                self._record_confirmed_action(
                    kind="CAST",
                    action_id=(pending.origin_action_id if pending is not None else None),
                    decision_fingerprint=(pending.action_key if pending is not None else None),
                    canonical_revision=(
                        int((reconciliation or {}).get("canonical_revision"))
                        if (reconciliation or {}).get("canonical_revision") is not None
                        else max((int(snapshot.revision) for snapshot in snapshots.values()), default=None)
                    ),
                    reconciliation_outcome=outcome,
                )
            elif outcome in {"TARGET_REACHED", "MOVED_TO_OTHER_CELL"}:
                # Both outcomes prove that a physical combat MOVE consumed game
                # state. A target mismatch may represent a shortened path/tackle
                # interaction, so count it as a real action and continue from the
                # authoritative actual cell rather than granting a free retry.
                self._state.action_count += 1
                self._state.accepted_actions += 1
                actual_cell = (reconciliation or {}).get("actual_cell_id")
                reached_cell = (
                    int(actual_cell) if actual_cell is not None
                    else int(pending_target) if pending_target is not None
                    else None
                )
                if outcome == "MOVED_TO_OTHER_CELL" and pending is not None:
                    self._state.quarantined_action_keys.add(pending.action_key)
                if pending_kind == "MOVE" and reached_cell is not None:
                    if self._state.last_action_kind != "MOVE":
                        self._state.move_chain_cells.clear()
                    if pending_origin is not None:
                        self._state.move_chain_cells.add(int(pending_origin))
                    self._state.move_chain_cells.add(int(reached_cell))
                    self._state.last_move_from_cell = pending_origin
                    self._state.last_move_to_cell = reached_cell
                    self._state.last_action_kind = "MOVE"
                    self._record_confirmed_action(
                        kind="MOVE",
                        action_id=(pending.origin_action_id if pending is not None else None),
                        origin_cell_id=pending_origin,
                        target_cell_id=reached_cell,
                        canonical_revision=(
                            int((reconciliation or {}).get("canonical_revision"))
                            if (reconciliation or {}).get("canonical_revision") is not None
                            else max((int(snapshot.revision) for snapshot in snapshots.values()), default=None)
                        ),
                        decision_fingerprint=(pending.action_key if pending is not None else None),
                        reconciliation_outcome=outcome,
                    )
            self._state.pending_combat_transaction = None

        if view.status is SharedFightStatus.NO_FIGHT:
            return {**base, "status": "WAIT", "reason": "NO_FIGHT", "progress_token": self._progress_token(view=view)}

        if view.active_actor_id is None:
            if any(self._phase(snapshot) == "ACTIVE" for snapshot in snapshots.values()):
                return {
                    **base,
                    "status": "WAIT",
                    "reason": "TURN_HANDOFF_WAIT",
                    "progress_token": self._progress_token(view=view),
                }
            return {
                **base,
                "status": "PREPARATION_REQUIRED",
                "reason": "NO_ACTIVE_TURN_BEFORE_ACTIVE_PHASE",
                "progress_token": self._progress_token(view=view),
            }

        if view.status is SharedFightStatus.CONFLICT:
            return {
                **base,
                "status": "BLOCKED",
                "reason": "SHARED_FIGHT_CONFLICT",
                "detail": view.detail,
                "progress_token": self._progress_token(view=view),
            }
        if view.status is not SharedFightStatus.CONSISTENT:
            return {
                **base,
                "status": "WAIT",
                "reason": "SHARED_FIGHT_NOT_CONVERGED",
                "detail": view.detail,
                "progress_token": self._progress_token(view=view),
            }

        active_actor = int(view.active_actor_id)
        turn_key = (view.fight_instance_id, view.round, view.turn_index, active_actor)
        if self._state.turn_key != turn_key:
            self._reset_for_turn(turn_key)

        if self._state.end_turn_auto_wait:
            return {
                **base,
                "status": "WAIT",
                "reason": "END_TURN_CLIENT_IGNORED_WAIT_FOR_AUTO_HANDOFF",
                "retry_allowed": True,
                "end_turn_no_semantic_failures": self._state.end_turn_no_semantic_failures,
                "progress_token": self._progress_token(view=view),
            }

        owner = view.actor_owners.get(active_actor)
        if owner is None:
            # A roster-known actor with no account owner is a legitimate enemy,
            # summon, or other non-party turn. Waiting here is normal and must
            # never consume the bounded "owner unknown" failure budget.
            observed_actor_ids = {
                int(actor.actor_id)
                for snapshot in snapshots.values()
                for actor in snapshot.fight.actors
            }
            if active_actor in observed_actor_ids:
                self._state.owner_wait_key = None
                self._state.owner_wait_count = 0
                return {
                    **base,
                    "status": "WAIT",
                    "reason": "NON_PARTY_ACTOR_TURN",
                    "active_actor_id": active_actor,
                    "progress_token": self._progress_token(view=view),
                }
            owner_wait_key = (turn_key, tuple(sorted(view.actor_owners.items())))
            if owner_wait_key == self._state.owner_wait_key:
                self._state.owner_wait_count += 1
            else:
                self._state.owner_wait_key = owner_wait_key
                self._state.owner_wait_count = 1
            status = "BLOCKED_STALLED" if self._state.owner_wait_count >= self.max_blocked_stall_polls else "WAIT"
            return {
                **base,
                "status": status,
                "reason": "ACTIVE_ACTOR_OWNER_UNKNOWN",
                "active_actor_id": active_actor,
                "blocked_polls": self._state.owner_wait_count,
                "progress_token": self._progress_token(view=view),
            }

        self._state.owner_wait_key = None
        self._state.owner_wait_count = 0
        lane = self.party.require(owner)
        owner_snapshot = snapshots.get(owner) or lane.snapshot()
        local_actor = authoritative_canonical_local_actor_id(owner_snapshot)
        if local_actor is None or int(local_actor) != active_actor:
            mismatch_key = (turn_key, owner, local_actor, active_actor, int(owner_snapshot.revision))
            if mismatch_key == self._state.owner_mismatch_key:
                self._state.owner_mismatch_count += 1
            else:
                self._state.owner_mismatch_key = mismatch_key
                self._state.owner_mismatch_count = 1
            stalled = self._state.owner_mismatch_count >= self.max_blocked_stall_polls
            return {
                **base,
                "status": "BLOCKED_STALLED" if stalled else "WAIT",
                "reason": "ACTIVE_ACTOR_NOT_LOCAL_OWNER",
                "failure_code": "ACTIVE_ACTOR_NOT_LOCAL_OWNER" if stalled else None,
                "retry_allowed": False if stalled else True,
                "first_missing_boundary": "TURN_OWNER_IDENTITY" if stalled else None,
                "likely_owner": "PARTY_FIGHT_STATE" if stalled else None,
                "account_id": owner,
                "active_actor_id": active_actor,
                "local_actor_id": local_actor,
                "blocked_polls": self._state.owner_mismatch_count,
                "progress_token": self._progress_token(view=view, owner=owner, revision=int(owner_snapshot.revision)),
            }

        self._state.owner_mismatch_key = None
        self._state.owner_mismatch_count = 0
        revision = int(owner_snapshot.revision)

        # Gate semantic turn readiness before window activation and before
        # FightAI.  R5.195 previously planned the same CAST repeatedly and only
        # discovered at ExecutionService that AP/MP were considered stale.  A
        # legitimate synchronization wait is passive: no planner work and no
        # physical/window input should occur until the baseline is usable.
        if not self._state.turn_readiness_stabilized:
            readiness = dict(local_turn_readiness_payload(owner_snapshot))
            if str(readiness.get("status") or "") != "READY":
                self._state.turn_readiness_signature = None
                self._state.turn_readiness_stable_polls = 0
                missing = tuple(sorted(str(item) for item in readiness.get("missing_requirements") or ()))
                readiness_wait_key = (
                    turn_key,
                    owner,
                    str(readiness.get("readiness_basis") or ""),
                    int(readiness.get("freshness_floor_revision") or 0),
                    missing,
                )
                if readiness_wait_key == self._state.turn_readiness_wait_key:
                    self._state.turn_readiness_wait_count += 1
                else:
                    self._state.turn_readiness_wait_key = readiness_wait_key
                    self._state.turn_readiness_wait_count = 1
                stalled = self._state.turn_readiness_wait_count >= self.max_blocked_stall_polls
                return {
                    **base,
                    "status": "BLOCKED_STALLED" if stalled else "WAIT",
                    "reason": "ACTION_BLOCKED_READINESS" if stalled else "TURN_START_RESOURCE_SYNC_WAIT",
                    "failure_code": "ACTION_BLOCKED_READINESS" if stalled else None,
                    "retry_allowed": False if stalled else True,
                    "first_missing_boundary": "TURN_START_RESOURCES" if stalled else None,
                    "likely_owner": "PROTOCOL_CANONICAL" if stalled else None,
                    "account_id": owner,
                    "revision": revision,
                    "blocked_polls": self._state.turn_readiness_wait_count,
                    "turn_readiness": readiness,
                    "progress_token": self._progress_token(view=view, owner=owner, revision=revision),
                }

            self._state.turn_readiness_wait_key = None
            self._state.turn_readiness_wait_count = 0
            basis_revision = int(readiness.get("basis_revision") or 0)
            ap_revision = int(readiness.get("ap_revision") or 0)
            mp_revision = int(readiness.get("mp_revision") or 0)
            readiness_basis = str(readiness.get("readiness_basis") or "")
            needs_stability_probe = bool(
                basis_revision > 0
                and readiness_basis in {"FIGHT_ACTIVE_WINDOW", "TURN_HANDOFF_WINDOW"}
                and (ap_revision <= basis_revision or mp_revision <= basis_revision)
            )
            if not needs_stability_probe:
                self._state.turn_readiness_stabilized = True
            else:
                readiness_signature = (
                    int(active_actor),
                    basis_revision,
                    int(readiness.get("freshness_floor_revision") or 0),
                    ap_revision,
                    mp_revision,
                    readiness_basis,
                )
                if readiness_signature == self._state.turn_readiness_signature:
                    self._state.turn_readiness_stable_polls += 1
                else:
                    self._state.turn_readiness_signature = readiness_signature
                    self._state.turn_readiness_stable_polls = 1
                if self._state.turn_readiness_stable_polls < 2:
                    return {
                        **base,
                        "status": "WAIT",
                        "reason": "TURN_START_BASELINE_STABILITY_WAIT",
                        "account_id": owner,
                        "revision": revision,
                        "turn_readiness": readiness,
                        "stable_polls": self._state.turn_readiness_stable_polls,
                        "progress_token": self._progress_token(view=view, owner=owner, revision=revision),
                    }
                self._state.turn_readiness_stabilized = True

        revision_vector = tuple(sorted(
            (str(account_id), int(snapshot.revision))
            for account_id, snapshot in snapshots.items()
        ))
        decision_semantic_fingerprint = CombatFrameAssembler.semantic_fingerprint_for_snapshots(snapshots)
        progress_token = self._progress_token(view=view, owner=owner, revision=revision)

        if not self._state.activated:
            activate = getattr(lane.execution, "activate_window", None)
            if not callable(activate):
                return {
                    **base,
                    "status": "BLOCKED",
                    "reason": "WINDOW_ACTIVATION_UNAVAILABLE",
                    "account_id": owner,
                    "progress_token": progress_token,
                }
            activation = invoke_correlated_activation(
                activate, runtime_context=runtime_context
            )
            if str(activation.get("status") or "UNKNOWN") != "WINDOW_READY":
                code = execution_failure_code(activation)
                retry = execution_retry_allowed(activation)
                boundary, likely_owner = failure_attribution(activation)
                # Control/session/run and exact-window identity violations cannot
                # heal by polling. Promote them immediately so the parent campaign
                # preserves the real causal boundary instead of timing out later.
                terminal = retry is False
                block_key = (turn_key, owner, code, str(activation.get("status") or "UNKNOWN"))
                if block_key == self._state.activation_block_key:
                    self._state.activation_block_count += 1
                else:
                    self._state.activation_block_key = block_key
                    self._state.activation_block_count = 1
                stalled = (
                    not terminal
                    and self._state.activation_block_count >= self.max_blocked_stall_polls
                )
                failure = code or ("TURN_OWNER_ACTIVATION_STALLED" if stalled else None)
                return {
                    **base,
                    "status": "BLOCKED" if terminal else ("BLOCKED_STALLED" if stalled else "WAIT"),
                    "reason": failure or "TURN_OWNER_ACTIVATION_BLOCKED",
                    "failure_code": failure if terminal or stalled else None,
                    "retry_allowed": False if stalled else retry,
                    "first_missing_boundary": boundary or ("TURN_OWNER_WINDOW_ACTIVATION" if stalled else None),
                    "likely_owner": likely_owner or ("WINDOW_INPUT" if stalled else None),
                    "account_id": owner,
                    "blocked_polls": self._state.activation_block_count,
                    "activation": activation,
                    "progress_token": progress_token,
                }
            self._state.activation_block_key = None
            self._state.activation_block_count = 0
            self._state.activated = True

        if not self._state.turn_heartbeat_attempted:
            self._state.turn_heartbeat_attempted = True
            heartbeat = getattr(lane.execution, "turn_activity_heartbeat", None)
            heartbeat_result = {"status": "SKIPPED", "reason": "HEARTBEAT_UNAVAILABLE"}
            if callable(heartbeat):
                try:
                    heartbeat_result = dict(heartbeat(runtime_context=runtime_context) or {})
                except Exception as exc:
                    heartbeat_result = {
                        "status": "SKIPPED", "reason": "HEARTBEAT_EXCEPTION",
                        "detail": f"{type(exc).__name__}: {exc}",
                    }
            self._state.turn_heartbeat_sent = str(heartbeat_result.get("status") or "") == "HEARTBEAT_SENT"
            base["turn_activity_heartbeat"] = heartbeat_result

        if self._state.last_action_revision is not None and revision == self._state.last_action_revision:
            return {
                **base,
                "status": "WAIT",
                "reason": "CANONICAL_REVISION_UNCHANGED_AFTER_ACTION",
                "account_id": owner,
                "revision": revision,
                "progress_token": progress_token,
            }

        # END_TURN is terminal for this exact turn key. Canonical revisions can
        # continue advancing while TURN_ENDED/TURN_STARTED propagates between
        # clients; those revisions must never authorize a second click for the
        # same turn. The latch is cleared only by _reset_for_turn when the exact
        # (fight, round, turn_index, active_actor) key changes.
        if self._state.end_turn_accepted:
            return {
                **base,
                "status": "WAIT",
                "reason": "TURN_END_SETTLEMENT_WAIT",
                "account_id": owner,
                "revision": revision,
                "end_turn_accepted": True,
                "progress_token": progress_token,
            }

        # R5.140 bounded evidence refresh. If the previous attempt was blocked as
        # admission UNKNOWN *before any physical input*, do not recompute FightAI
        # against the exact same captured team revisions. On the first unchanged
        # follow-up poll, quarantine that exact candidate for this semantic turn so
        # the next decision must choose an alternative (or normal END_TURN). If any
        # required lane advanced, clear the wait and let the candidate be evaluated
        # against genuinely new evidence.
        if self._state.pending_no_input_action is not None:
            pending_semantic = self._state.pending_no_input_semantic_fingerprint
            if pending_semantic == decision_semantic_fingerprint:
                quarantine = {"supported": False}
                handler = getattr(self.turn_policy_resolver, "quarantine", None)
                if callable(handler):
                    try:
                        quarantine = dict(handler(owner, dict(self._state.pending_no_input_action)))
                    except Exception as exc:
                        quarantine = {"supported": False, "error": f"{type(exc).__name__}: {exc}"}
                if quarantine.get("supported") is True:
                    prior = dict(self._state.pending_no_input_action)
                    self._state.quarantined_action_keys.add(self._fingerprint(prior))
                    prior_code = self._state.pending_no_input_failure_code
                    self._state.pending_no_input_action = None
                    self._state.pending_no_input_revision_vector = None
                    self._state.pending_no_input_semantic_fingerprint = None
                    self._state.pending_no_input_failure_code = None
                    self._state.action_block_key = None
                    self._state.action_block_count = 0
                    self._state.safe_recovery_count += 1
                    if self._state.safe_recovery_count >= self.max_safe_recoveries_per_turn:
                        self._state.force_end_turn_reason = (
                            f"SAFE_RECOVERY_BUDGET_EXHAUSTED:{prior_code or 'ADMISSION_UNKNOWN'}"
                        )
                    return {
                        **base,
                        "status": "WAIT",
                        "reason": f"ACTION_REPLAN:{prior_code or 'ADMISSION_UNKNOWN'}",
                        "failure_code": None,
                        "retry_allowed": True,
                        "replan_required": True,
                        "quarantine": quarantine,
                        "recovery": {
                            "kind": RecoveryDirectiveKind.EXCLUDE_ACTION_CURRENT_TURN.value,
                            "failure_class": "TEMPORARY_STATE_UNCERTAINTY",
                            "reason": "no new Canonical evidence arrived after bounded admission-UNKNOWN refresh; exclude exact candidate",
                            "safe_to_continue": True,
                            "quarantine_candidate": True,
                        },
                        "account_id": owner,
                        "revision": revision,
                        "decision": prior,
                        "safe_recovery_count": self._state.safe_recovery_count,
                        "force_end_turn_next_step": self._state.force_end_turn_reason is not None,
                        "evidence_refresh_revision_vector": {k: v for k, v in revision_vector},
                        "evidence_refresh_semantic_fingerprint": decision_semantic_fingerprint,
                        "progress_token": progress_token,
                    }
                # A same-frame no-input UNKNOWN is safe to contain at turn scope.
                # If the resolver cannot quarantine, do not re-enter the same
                # candidate loop: schedule END_TURN instead of relying on the
                # parent mission watchdog.
                prior_code = self._state.pending_no_input_failure_code
                self._state.pending_no_input_action = None
                self._state.pending_no_input_revision_vector = None
                self._state.pending_no_input_semantic_fingerprint = None
                self._state.pending_no_input_failure_code = None
                self._state.action_block_key = None
                self._state.action_block_count = 0
                self._state.force_end_turn_reason = (
                    f"QUARANTINE_UNAVAILABLE:{prior_code or 'ADMISSION_UNKNOWN'}"
                )
                return {
                    **base,
                    "status": "WAIT",
                    "reason": "ACTION_RECOVERY:FALLBACK_END_TURN:QUARANTINE_UNAVAILABLE",
                    "failure_code": None,
                    "retry_allowed": True,
                    "replan_required": False,
                    "quarantine": quarantine,
                    "recovery": {
                        "kind": RecoveryDirectiveKind.FALLBACK_END_TURN.value,
                        "failure_class": "TEMPORARY_STATE_UNCERTAINTY",
                        "reason": "same-frame no-input uncertainty could not be quarantined; end the turn safely",
                        "safe_to_continue": True,
                        "quarantine_candidate": True,
                    },
                    "account_id": owner,
                    "revision": revision,
                    "force_end_turn_next_step": True,
                    "progress_token": progress_token,
                }
            else:
                self._state.pending_no_input_action = None
                self._state.pending_no_input_revision_vector = None
                self._state.pending_no_input_semantic_fingerprint = None
                self._state.pending_no_input_failure_code = None
                self._state.action_block_key = None
                self._state.action_block_count = 0

        role = str(view.account_roles.get(owner) or "")
        owner_actor = next((actor for actor in owner_snapshot.fight.actors if int(actor.actor_id) == active_actor), None)
        current_cell_id = self._known_int(owner_actor.cell_id) if owner_actor is not None else None
        if self._state.force_end_turn_reason is not None:
            decision = {
                "kind": "END_TURN",
                "reason": "RECOVERY_END_TURN_FALLBACK",
                "recovery_original_reason": self._state.force_end_turn_reason,
            }
        else:
            try:
                decide_with_context = getattr(self.turn_policy_resolver, "decide_with_context", None)
                if callable(decide_with_context):
                    decision = dict(decide_with_context(
                        owner, role, current_cell_id=current_cell_id,
                        confirmed_turn_history=self._confirmed_turn_history(view),
                    ))
                else:
                    # Quarantined compatibility seam for historical/custom resolvers.
                    # Production ServiceTurnPolicyResolver uses the typed context path.
                    decision = dict(
                        self.turn_policy_resolver.decide(
                            owner, role, current_cell_id=current_cell_id
                        )
                    )
            except Exception as exc:
                # R5.143: FightAI/policy code executes before any physical input.
                # A local planner exception must therefore be contained at the
                # turn boundary instead of escaping into the campaign lifecycle.
                # Preserve the exact exception for diagnostics and end this turn
                # through the normal ExecutionService safety gates.
                planner_failure = f"{type(exc).__name__}: {exc}"
                decision = {
                    "kind": "END_TURN",
                    "reason": "RECOVERY_END_TURN_FALLBACK",
                    "recovery_original_reason": f"FIGHT_AI_EXCEPTION:{planner_failure}",
                    "planner_exception": planner_failure,
                }

        # R5.143: policy output is an internal contract boundary.  Malformed or
        # semantically incomplete decisions occur before any physical input, so
        # contain them to the current turn instead of promoting a planner defect
        # into a campaign-terminal failure.  END_TURN still passes through the
        # normal ExecutionService authority/readiness/settlement gates.
        decision_contract_error = None
        try:
            FightDecision.from_payload(decision)
            proposed_kind = str(decision.get("kind") or "BLOCKED")
            if proposed_kind == "CAST" and any(
                decision.get(name) is None for name in ("spell_id", "slot_index", "target_cell_id")
            ):
                raise ValueError("CAST requires spell_id, slot_index and target_cell_id")
            if proposed_kind == "MOVE" and decision.get("target_cell_id") is None:
                raise ValueError("MOVE requires target_cell_id")
        except (TypeError, ValueError) as exc:
            decision_contract_error = f"{type(exc).__name__}: {exc}"
            decision = {
                "kind": "END_TURN",
                "reason": "RECOVERY_END_TURN_FALLBACK",
                "recovery_original_reason": f"INVALID_FIGHT_AI_DECISION:{decision_contract_error}",
                "planner_contract_error": decision_contract_error,
            }

        kind = str(decision.get("kind") or "BLOCKED")
        reason = str(decision.get("reason") or "")
        fingerprint = self._fingerprint(decision)
        decision_info = {"kind": kind, **decision}
        decision_recovery = None
        recovery_original_reason = None
        recovery_blocked_polls = None
        if (
            kind == "END_TURN"
            and reason == "RECOVERY_END_TURN_FALLBACK"
            and decision.get("recovery_original_reason")
        ):
            recovery_original_reason = str(decision.get("recovery_original_reason"))
            planner_exception = str(decision.get("planner_exception") or "")
            planner_contract_error = str(decision.get("planner_contract_error") or "")
            decision_recovery = {
                "kind": RecoveryDirectiveKind.FALLBACK_END_TURN.value,
                "failure_class": (
                    "INVALID_FIGHT_AI_DECISION"
                    if (
                        planner_exception
                        or planner_contract_error
                        or recovery_original_reason.startswith("FIGHT_AI_EXCEPTION:")
                        or recovery_original_reason.startswith("INVALID_FIGHT_AI_DECISION:")
                    )
                    else "RECOVERABLE_ACTION_FAILURE"
                ),
                "reason": recovery_original_reason,
                "safe_to_continue": True,
                "quarantine_candidate": False,
            }
            if planner_exception:
                decision_recovery["planner_exception"] = planner_exception
            if planner_contract_error:
                decision_recovery["planner_contract_error"] = planner_contract_error

        if fingerprint in self._state.quarantined_action_keys and kind != "END_TURN":
            # Recovery itself is a safety contract. If a quarantined semantic
            # action reappears, do not execute it or wait for another watchdog;
            # preserve the fight with the already-authorized generic END_TURN
            # fallback path. No physical input has occurred for this decision.
            decision_recovery = {
                "kind": RecoveryDirectiveKind.FALLBACK_END_TURN.value,
                "failure_class": "INVALID_FIGHT_AI_DECISION",
                "reason": "RECOVERY_INVARIANT_VIOLATION: quarantined ActionKey was selected again",
                "safe_to_continue": True,
                "quarantine_candidate": True,
            }
            recovery_original_reason = "RECOVERY_INVARIANT_VIOLATION"
            recovery_blocked_polls = None
            decision = {"kind": "END_TURN", "reason": "RECOVERY_END_TURN_FALLBACK"}
            kind = "END_TURN"
            reason = "RECOVERY_END_TURN_FALLBACK"
            fingerprint = self._fingerprint(decision)
            decision_info = {
                "kind": kind, **decision,
                "recovery_original_reason": recovery_original_reason,
            }

        if kind == "BLOCKED":
            blocked_key = (turn_key, revision, reason, fingerprint)
            if blocked_key == self._state.blocked_key:
                self._state.blocked_count += 1
            else:
                self._state.blocked_key = blocked_key
                self._state.blocked_count = 1
            planner_result = self._planner_result(decision_info)
            planner_disposition = planner_result.disposition
            directive = (
                self.recovery_policy.classify_decision_block(
                    reason,
                    repeated_same_frame_count=self._state.blocked_count,
                    compatibility_adapter=True,
                )
                if planner_result.compatibility_adapter
                else self.recovery_policy.classify_planner_result(
                    planner_result, repeated_same_frame_count=self._state.blocked_count
                )
            )
            if directive is not None and directive.kind is RecoveryDirectiveKind.FALLBACK_END_TURN:
                decision_recovery = directive.as_dict()
                recovery_original_reason = reason or "FIGHT_AI_BLOCKED"
                recovery_blocked_polls = self._state.blocked_count
                # END_TURN still passes through ExecutionService control/readiness
                # gates. This fallback is therefore only an intent to preserve the
                # fight; it cannot bypass pending/uncertain physical input fences.
                decision = {"kind": "END_TURN", "reason": "RECOVERY_END_TURN_FALLBACK"}
                kind = "END_TURN"
                reason = "RECOVERY_END_TURN_FALLBACK"
                fingerprint = self._fingerprint(decision)
                decision_info = {
                    "kind": kind, **decision,
                    "recovery_original_reason": recovery_original_reason,
                }
                self._state.blocked_key = None
                self._state.blocked_count = 0
            else:
                planner_replan = bool(
                    directive is not None
                    and getattr(directive, "planner_replan", False)
                    and planner_disposition is PlannerDisposition.CONTINUE_PLANNING
                )
                if planner_replan:
                    self._state.planner_slice_count += 1
                    evaluated, configured = self._planner_progress(decision_info)
                    if evaluated is not None:
                        if (
                            self._state.planner_last_coverage_count is None
                            or evaluated > self._state.planner_last_coverage_count
                        ):
                            self._state.planner_no_progress_count = 0
                            self._state.planner_last_coverage_count = evaluated
                        else:
                            self._state.planner_no_progress_count += 1
                    if configured is not None and evaluated is not None and evaluated >= configured:
                        # A policy claiming incomplete coverage after full deep coverage
                        # violates the planner contract. End only this turn through the
                        # normal executor gates instead of spinning or killing the mission.
                        decision_recovery = {
                            **directive.as_dict(),
                            "reason": "PLANNER_COVERAGE_CONTRACT_VIOLATION",
                        }
                        recovery_original_reason = reason or "SPELL_COVERAGE_INCOMPLETE"
                        recovery_blocked_polls = self._state.planner_slice_count
                        decision = {"kind": "END_TURN", "reason": "PLANNER_LIVENESS_END_TURN_FALLBACK"}
                        kind = "END_TURN"
                        reason = "PLANNER_LIVENESS_END_TURN_FALLBACK"
                        fingerprint = self._fingerprint(decision)
                        decision_info = {
                            "kind": kind, **decision,
                            "recovery_original_reason": recovery_original_reason,
                        }
                        self._state.blocked_key = None
                        self._state.blocked_count = 0
                    elif (
                        self._state.planner_slice_count >= self.max_planner_replan_slices
                        or self._state.planner_no_progress_count >= self.max_planner_no_progress_slices
                        or (
                            self._state.turn_started_monotonic is not None
                            and (time.monotonic() - self._state.turn_started_monotonic)
                            >= self.max_planner_replan_seconds
                        )
                    ):
                        # R5.147 liveness fuse. Progressive search is expected to
                        # advance coverage each slice. If it cannot, sacrifice only
                        # this turn through a certified END_TURN rather than spend a
                        # full turn in a compute loop and trigger Dofus inactivity.
                        decision_recovery = {
                            **directive.as_dict(),
                            "reason": "PLANNER_PROGRESS_STALLED",
                            "planner_slice_count": self._state.planner_slice_count,
                            "planner_no_progress_count": self._state.planner_no_progress_count,
                            "evaluated_spell_count": evaluated,
                            "configured_spell_count": configured,
                            "planner_elapsed_seconds": (
                                None if self._state.turn_started_monotonic is None
                                else round(time.monotonic() - self._state.turn_started_monotonic, 6)
                            ),
                        }
                        recovery_original_reason = reason or "SPELL_COVERAGE_INCOMPLETE"
                        recovery_blocked_polls = self._state.planner_slice_count
                        decision = {"kind": "END_TURN", "reason": "PLANNER_LIVENESS_END_TURN_FALLBACK"}
                        kind = "END_TURN"
                        reason = "PLANNER_LIVENESS_END_TURN_FALLBACK"
                        fingerprint = self._fingerprint(decision)
                        decision_info = {
                            "kind": kind, **decision,
                            "recovery_original_reason": recovery_original_reason,
                        }
                        self._state.blocked_key = None
                        self._state.blocked_count = 0
                    else:
                        return {
                            **base,
                            "status": "WAIT",
                            "reason": "PLANNER_REPLAN_CURRENT_FRAME",
                            "retry_allowed": True,
                            "account_id": owner,
                            "revision": revision,
                            "blocked_polls": self._state.blocked_count,
                            "planner_slice_count": self._state.planner_slice_count,
                            "planner_no_progress_count": self._state.planner_no_progress_count,
                            "planner_evaluated_spell_count": evaluated,
                            "planner_configured_spell_count": configured,
                            "turn_heartbeat_sent": self._state.turn_heartbeat_sent,
                            "decision": decision_info,
                            "recovery": directive.as_dict(),
                            "replan_required": True,
                            "progress_token": progress_token,
                        }
                if self._state.blocked_count >= self.max_blocked_stall_polls and not planner_replan:
                    failure_code, boundary, likely_owner = self._decision_failure_attribution(
                        reason or "FIGHT_AI_BLOCKED_STALLED"
                    )
                    return {
                        **base,
                        "status": "BLOCKED_STALLED",
                        "reason": reason or "FIGHT_AI_BLOCKED",
                        "failure_code": failure_code,
                        "retry_allowed": False,
                        "first_missing_boundary": boundary,
                        "likely_owner": likely_owner,
                        "failure_class": (
                            planner_result.failure_class.value
                            if planner_result.failure_class is not None and not planner_result.compatibility_adapter
                            else self.recovery_policy.classify_decision_failure(reason).value
                        ),
                        "account_id": owner,
                        "revision": revision,
                        "blocked_polls": self._state.blocked_count,
                        "decision": decision_info,
                        "recovery": directive.as_dict() if directive is not None else None,
                        "progress_token": progress_token,
                    }
                if kind == "BLOCKED":
                    return {
                        **base,
                        "status": "WAIT",
                        "reason": reason or "FIGHT_AI_BLOCKED",
                        "account_id": owner,
                        "revision": revision,
                        "blocked_polls": self._state.blocked_count,
                        "decision": decision_info,
                        "recovery": directive.as_dict() if directive is not None else None,
                        "replan_required": bool(
                            directive is not None and getattr(directive, "planner_replan", False)
                        ),
                        "turn_heartbeat_sent": self._state.turn_heartbeat_sent,
                        "progress_token": progress_token,
                    }

        self._state.blocked_key = None
        self._state.blocked_count = 0
        self._state.planner_slice_count = 0
        self._state.planner_last_coverage_count = None
        self._state.planner_no_progress_count = 0

        if kind == "WAIT":
            return {
                **base,
                "status": "WAIT",
                "reason": reason or "FIGHT_AI_WAIT",
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "progress_token": progress_token,
            }

        if self._state.action_count >= self.max_actions_per_turn:
            decision = {"kind": "END_TURN", "reason": "ACTION_CEILING"}
            kind = "END_TURN"
            fingerprint = self._fingerprint(decision)
            decision_info = dict(decision)

        if (
            kind == "MOVE"
            and self._state.last_action_kind == "MOVE"
            and current_cell_id is not None
            and self._state.last_move_to_cell == int(current_cell_id)
            and decision.get("target_cell_id") is not None
            and self._state.last_move_from_cell == int(decision.get("target_cell_id"))
        ):
            # R5.138: exact immediate A->B->A movement in one semantic turn is a
            # deterministic waste pattern observed in fight 93. Quarantine only
            # that exact reverse action and replan; a cast or any other action in
            # between clears the pattern naturally via last_action_kind.
            quarantine = {"supported": False}
            handler = getattr(self.turn_policy_resolver, "quarantine", None)
            if callable(handler):
                try:
                    quarantine = dict(handler(owner, decision_info))
                except Exception as exc:
                    quarantine = {"supported": False, "error": f"{type(exc).__name__}: {exc}"}
            if quarantine.get("supported") is True:
                self._state.quarantined_action_keys.add(fingerprint)
            return {
                **base,
                "status": "WAIT",
                "reason": "IMMEDIATE_MOVE_REVERSAL_REPLAN",
                "retry_allowed": True,
                "replan_required": True,
                "quarantine": quarantine,
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "progress_token": progress_token,
            }

        if (
            kind == "MOVE"
            and self._state.last_action_kind == "MOVE"
            and decision.get("target_cell_id") is not None
            and int(decision.get("target_cell_id")) in self._state.move_chain_cells
        ):
            # R5.145: prevent longer MOVE-only loops such as A->B->C->A.  A cast,
            # end-turn, or turn handoff resets this guard, so legitimate later
            # repositioning after the tactical state changes is not prohibited.
            quarantine = {"supported": False}
            handler = getattr(self.turn_policy_resolver, "quarantine", None)
            if callable(handler):
                try:
                    quarantine = dict(handler(owner, decision_info))
                except Exception as exc:
                    quarantine = {"supported": False, "error": f"{type(exc).__name__}: {exc}"}
            if quarantine.get("supported") is True:
                self._state.quarantined_action_keys.add(fingerprint)
            return {
                **base,
                "status": "WAIT",
                "reason": "MOVE_CYCLE_REPLAN",
                "retry_allowed": True,
                "replan_required": True,
                "quarantine": quarantine,
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "progress_token": progress_token,
            }

        if kind == "CAST":
            spell_id = decision.get("spell_id")
            slot_index = decision.get("slot_index")
            target_cell_id = decision.get("target_cell_id")
            if None in (spell_id, slot_index, target_cell_id):
                return {**base, "status": "BLOCKED", "reason": "INVALID_CAST_DECISION", "decision": decision_info, "progress_token": progress_token}
            cast_payload = {
                "spell_id": int(spell_id),
                "target_cell_id": int(target_cell_id),
                "slot_index": int(slot_index),
            }
            if decision.get("grade") is not None:
                cast_payload["grade"] = int(decision["grade"])
            if decision.get("target_actor_id") is not None:
                cast_payload["target_actor_id"] = int(decision["target_actor_id"])
            if decision.get("action_intent") is not None:
                cast_payload["action_intent"] = decision["action_intent"]
            admission_mode = str(decision.get("admission_mode") or "STRICT")
            probe_assumptions = tuple(decision.get("probe_assumptions") or ())
            if admission_mode != "STRICT" or probe_assumptions:
                cast_payload["admission_mode"] = admission_mode
                cast_payload["probe_assumptions"] = list(probe_assumptions)
            action_result = dict(lane.handle_action(
                "cast_spell", self._action_payload(cast_payload, runtime_context)
            ))
        elif kind == "MOVE":
            target_cell_id = decision.get("target_cell_id")
            if target_cell_id is None:
                return {
                    **base, "status": "BLOCKED", "reason": "INVALID_MOVE_DECISION",
                    "failure_class": "INVALID_FIGHT_AI_DECISION",
                    "decision": decision_info, "progress_token": progress_token,
                }
            action_result = dict(lane.handle_action("move_fight", self._action_payload({
                "actor_id": int(local_actor), "target_cell_id": int(target_cell_id),
            }, runtime_context)))
        elif kind == "END_TURN":
            action_result = dict(lane.handle_action("end_turn", self._action_payload({}, runtime_context)))
        else:
            return {
                **base,
                "status": "BLOCKED",
                "reason": f"UNKNOWN_DECISION:{kind}",
                "failure_class": "INVALID_FIGHT_AI_DECISION",
                "account_id": owner,
                "decision": decision_info,
                "progress_token": progress_token,
            }

        action_outcome = CombatActionOutcome.from_mapping(action_result)
        action_status = action_outcome.status
        if action_outcome.phase is CombatActionPhase.CONTRACT_VIOLATION:
            return {
                **base,
                "status": "BLOCKED",
                "reason": "INVALID_EXECUTION_RESULT_CONTRACT",
                "failure_code": "INVALID_EXECUTION_RESULT_CONTRACT",
                "retry_allowed": False,
                "first_missing_boundary": "COMBAT_EXECUTION_RESULT_CONTRACT",
                "likely_owner": "EXECUTION_SERVICE",
                "failure_class": "EXECUTOR_FAILURE",
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "action_result": action_result,
                "execution_contract_error": action_outcome.contract_error,
                "raw_failure_code": action_outcome.raw_failure_code,
                "progress_token": progress_token,
            }
        if action_outcome.accepted:
            self._state.action_block_key = None
            self._state.action_block_count = 0
            self._state.action_count += 1
            self._state.accepted_actions += 1
            if self._state.first_game_action_monotonic is None:
                self._state.first_game_action_monotonic = time.monotonic()
            self._state.last_action_revision = revision
            self._state.last_action_fingerprint = fingerprint
            previous_kind = self._state.last_action_kind
            if kind == "MOVE":
                origin_cell = int(current_cell_id) if current_cell_id is not None else None
                target_cell = int(decision.get("target_cell_id")) if decision.get("target_cell_id") is not None else None
                if previous_kind != "MOVE":
                    self._state.move_chain_cells.clear()
                if origin_cell is not None:
                    self._state.move_chain_cells.add(origin_cell)
                if target_cell is not None:
                    self._state.move_chain_cells.add(target_cell)
                self._state.last_move_from_cell = origin_cell
                self._state.last_move_to_cell = target_cell
            else:
                self._state.move_chain_cells.clear()
            self._state.last_action_kind = kind
            if kind == "END_TURN":
                self._state.end_turn_accepted = True
            self._record_confirmed_action(
                kind=kind,
                action_id=(action_result.get("action_id") or action_result.get("origin_action_id")),
                origin_cell_id=(int(current_cell_id) if kind == "MOVE" and current_cell_id is not None else None),
                target_cell_id=(
                    int(decision.get("target_cell_id"))
                    if decision.get("target_cell_id") is not None else None
                ),
                spell_id=(int(decision.get("spell_id")) if decision.get("spell_id") is not None else None),
                grade=(int(decision.get("grade")) if decision.get("grade") is not None else None),
                slot_index=(int(decision.get("slot_index")) if decision.get("slot_index") is not None else None),
                target_actor_id=(
                    int(decision.get("target_actor_id"))
                    if decision.get("target_actor_id") is not None else None
                ),
                path_distance=(
                    int(decision.get("path_distance"))
                    if decision.get("path_distance") is not None else None
                ),
                canonical_revision=int(revision),
                decision_fingerprint=fingerprint,
                reconciliation_outcome="ACCEPTED",
            )
            return {
                **base,
                "status": "ACTION_ACCEPTED",
                "reason": reason,
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "action_result": action_result,
                "recovery": decision_recovery,
                "recovery_original_reason": recovery_original_reason,
                "blocked_polls": recovery_blocked_polls,
                "turn_liveness": {
                    "heartbeat_sent": self._state.turn_heartbeat_sent,
                    "seconds_to_first_game_action": (
                        None if self._state.turn_started_monotonic is None or self._state.first_game_action_monotonic is None
                        else round(self._state.first_game_action_monotonic - self._state.turn_started_monotonic, 6)
                    ),
                },
                "progress_token": self._progress_token(view=view, owner=owner, revision=revision),
            }
        if action_outcome.phase is CombatActionPhase.RECONCILING:
            # A combat CAST/MOVE/END_TURN transaction has crossed the physical
            # input boundary but causality is not yet closed. Quarantine the exact
            # semantic action, retain the execution fence, and poll passive
            # reconciliation on later steps. No duplicate physical input is allowed.
            self._state.pending_combat_transaction = PendingCombatTransaction.from_execution(
                action_key=fingerprint,
                kind=kind,
                action_result=action_result,
                account_id=owner,
                fight_instance_id=(
                    int(view.fight_instance_id) if view.fight_instance_id is not None else None
                ),
                origin_cell_id=(
                    int(current_cell_id) if kind == "MOVE" and current_cell_id is not None else None
                ),
                target_cell_id=(
                    int(decision.get("target_cell_id"))
                    if kind == "MOVE" and decision.get("target_cell_id") is not None else None
                ),
            )
            self._state.quarantined_action_keys.add(fingerprint)
            return {
                **base,
                "status": "WAIT",
                "reason": "COMBAT_ACTION_RECONCILING",
                "failure_code": None,
                "retry_allowed": True,
                "replan_required": False,
                "account_id": owner,
                "revision": revision,
                "decision": decision_info,
                "action_result": action_result,
                "recovery": {
                    "kind": "WAIT_FOR_EVIDENCE",
                    "failure_class": "DECODER_STATE_SYNC_DELAY",
                    "reason": "sent combat action awaits authoritative reconciliation",
                    "safe_to_continue": True,
                    "quarantine_candidate": True,
                },
                "progress_token": progress_token,
            }
        if action_outcome.blocked_like:
            code = execution_failure_code(action_result)
            retry = execution_retry_allowed(action_result)
            boundary, likely_owner = failure_attribution(action_result)
            block_key = (turn_key, revision, fingerprint, action_status, code)
            if block_key == self._state.action_block_key:
                self._state.action_block_count += 1
            else:
                self._state.action_block_key = block_key
                self._state.action_block_count = 1

            directive = self.recovery_policy.classify_action_block(
                action_outcome, repeated_same_frame_count=self._state.action_block_count,
            )
            if directive is not None:
                recovery = directive.as_dict()
                if directive.kind in {
                    RecoveryDirectiveKind.EXCLUDE_ACTION_CURRENT_TURN,
                    RecoveryDirectiveKind.REPLAN_CURRENT_FRAME,
                }:
                    quarantine = {"supported": False}
                    if directive.quarantine_candidate:
                        # The controller owns the final same-turn exclusion
                        # postcondition.  Resolver quarantine improves candidate
                        # selection efficiency, but a missing/broken resolver hook
                        # must never permit the exact failed ActionKey to execute
                        # again.
                        self._state.quarantined_action_keys.add(fingerprint)
                        handler = getattr(self.turn_policy_resolver, "quarantine", None)
                        if callable(handler):
                            try:
                                quarantine = dict(handler(owner, decision_info))
                            except Exception as exc:
                                quarantine = {"supported": False, "error": f"{type(exc).__name__}: {exc}"}
                    if directive.safe_to_continue:
                        self._state.safe_recovery_count += 1
                        if self._state.safe_recovery_count >= self.max_safe_recoveries_per_turn:
                            self._state.force_end_turn_reason = (
                                f"SAFE_RECOVERY_BUDGET_EXHAUSTED:{code or directive.kind.value}"
                            )
                    self._state.action_block_key = None
                    self._state.action_block_count = 0
                    return {
                        **base,
                        "status": "WAIT",
                        "reason": f"ACTION_REPLAN:{code or 'SAFE_CAST_ABORT'}",
                        "failure_code": None,
                        "retry_allowed": True,
                        "replan_required": True,
                        "quarantine": quarantine,
                        "recovery": recovery,
                        "account_id": owner,
                        "revision": revision,
                        "decision": decision_info,
                        "action_result": action_result,
                        "safe_recovery_count": self._state.safe_recovery_count,
                        "force_end_turn_next_step": self._state.force_end_turn_reason is not None,
                        "progress_token": progress_token,
                    }
                if directive.kind is RecoveryDirectiveKind.WAIT_FOR_EVIDENCE:
                    # Admission UNKNOWN before input gets exactly one evidence
                    # refresh window. Persist the attempted decision + full required
                    # lane revision vector so an unchanged next poll can quarantine
                    # without recomputing FightAI or re-entering execution.
                    if (
                        code in {"CAST_ADMISSION_UNKNOWN", "MOVE_ADMISSION_UNKNOWN"}
                        and str(action_result.get("physical_send_state") or "") in {"", "NOT_SENT"}
                        and str(action_result.get("semantic_cast_send_state") or "") in {"", "NOT_SENT"}
                    ):
                        self._state.pending_no_input_action = dict(decision_info)
                        self._state.pending_no_input_revision_vector = revision_vector
                        self._state.pending_no_input_semantic_fingerprint = decision_semantic_fingerprint
                        self._state.pending_no_input_failure_code = code
                    # Confirmed-but-unsettled actions can legitimately need more
                    # Canonical evidence, but still retain the historical bounded
                    # stall ceiling.
                    if self._state.action_block_count < self.max_blocked_stall_polls:
                        return {
                            **base,
                            "status": "WAIT",
                            "reason": f"ACTION_RECOVERY:{directive.kind.value}:{code or action_status}",
                            "failure_code": None,
                            "retry_allowed": True,
                            "blocked_polls": self._state.action_block_count,
                            "recovery": recovery,
                            "account_id": owner,
                            "revision": revision,
                            "decision": decision_info,
                            "action_result": action_result,
                            "progress_token": progress_token,
                        }
                if directive.kind is RecoveryDirectiveKind.FENCE_UNCERTAIN_INPUT:
                    return {
                        **base,
                        "status": "BLOCKED",
                        "reason": code or "UNCERTAIN_PHYSICAL_INPUT",
                        "failure_code": code or "UNCERTAIN_PHYSICAL_INPUT",
                        "retry_allowed": False,
                        "first_missing_boundary": boundary or "COMBAT_ACTION_CAUSALITY",
                        "likely_owner": likely_owner or "EXECUTION_SERVICE",
                        "recovery": recovery,
                        "account_id": owner,
                        "revision": revision,
                        "decision": decision_info,
                        "action_result": action_result,
                        "progress_token": progress_token,
                    }

            terminal = (
                action_outcome.phase in {CombatActionPhase.CONTROL_FAILURE, CombatActionPhase.FAILED}
                or (action_outcome.phase is CombatActionPhase.REJECTED_NOT_SENT and retry is False)
            )
            stalled = (
                not terminal
                and self._state.action_block_count >= self.max_blocked_stall_polls
            )
            failure = code if terminal else (code or "COMBAT_ACTION_STALLED") if stalled else None
            return {
                **base,
                "status": "BLOCKED" if terminal else ("BLOCKED_STALLED" if stalled else "WAIT"),
                "reason": failure or code or f"ACTION_{action_status}",
                "failure_code": failure,
                "retry_allowed": False if stalled else retry,
                "first_missing_boundary": boundary or ("COMBAT_ACTION_SETTLEMENT" if stalled else None),
                "likely_owner": likely_owner or ("EXECUTION_SERVICE" if stalled else None),
                "failure_class": (
                    self.recovery_policy.classify_action_failure(action_result).value
                    if self.recovery_policy.classify_action_failure(action_result) is not None
                    else None
                ),
                "account_id": owner,
                "revision": revision,
                "blocked_polls": self._state.action_block_count,
                "decision": decision_info,
                "action_result": action_result,
                "decision_recovery": decision_recovery,
                "recovery_original_reason": recovery_original_reason,
                "progress_token": progress_token,
            }
        code = execution_failure_code(action_result)
        boundary, likely_owner = failure_attribution(action_result)
        return {
            **base,
            "status": "FAILED",
            "reason": code or f"ACTION_{action_status}",
            "failure_code": code,
            "retry_allowed": False,
            "first_missing_boundary": boundary,
            "likely_owner": likely_owner,
            "failure_class": (
                self.recovery_policy.classify_action_failure(action_result).value
                if self.recovery_policy.classify_action_failure(action_result) is not None
                else None
            ),
            "account_id": owner,
            "revision": revision,
            "decision": decision_info,
            "action_result": action_result,
            "decision_recovery": decision_recovery,
            "recovery_original_reason": recovery_original_reason,
            "progress_token": progress_token,
        }

from __future__ import annotations

from dataclasses import dataclass


def _optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    token = str(value).strip()
    return token or None


@dataclass(frozen=True, slots=True)
class FightPolicySet:
    """Mission-level policy defaults without weakening per-account overrides.

    A policy set does not own execution or runtime state. It only supplies the
    default policy IDs used while compiling an immutable SessionPlan. Explicit
    account/session overrides retain precedence over these defaults.
    """

    active_fight_policy_id: str | None = None
    passive_policy_id: str | None = None
    active_placement_policy_id: str | None = None
    passive_placement_policy_id: str | None = None
    required_team_strategy_id: str | None = None
    compatible_active_policy_ids: tuple[str, ...] = ()
    compatible_passive_policy_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for field_name in (
            "active_fight_policy_id",
            "passive_policy_id",
            "active_placement_policy_id",
            "passive_placement_policy_id",
            "required_team_strategy_id",
        ):
            object.__setattr__(self, field_name, _optional_text(getattr(self, field_name)))
        object.__setattr__(self, "compatible_active_policy_ids", tuple(
            token for item in self.compatible_active_policy_ids if (token := _optional_text(item)) is not None
        ))
        object.__setattr__(self, "compatible_passive_policy_ids", tuple(
            token for item in self.compatible_passive_policy_ids if (token := _optional_text(item)) is not None
        ))

    def require_compatible_active(self, policy_id: str | None) -> bool:
        return not self.compatible_active_policy_ids or _optional_text(policy_id) in set(self.compatible_active_policy_ids)

    def require_compatible_passive(self, policy_id: str | None) -> bool:
        return not self.compatible_passive_policy_ids or _optional_text(policy_id) in set(self.compatible_passive_policy_ids)

    def policy_for_active(self, profile_default: str | None) -> str | None:
        return self.active_fight_policy_id or _optional_text(profile_default)

    def policy_for_passive(self, profile_default: str | None) -> str | None:
        return self.passive_policy_id or _optional_text(profile_default)

    def placement_for(self, *, passive: bool, profile_default: str | None) -> str | None:
        configured = self.passive_placement_policy_id if passive else self.active_placement_policy_id
        return configured or _optional_text(profile_default)

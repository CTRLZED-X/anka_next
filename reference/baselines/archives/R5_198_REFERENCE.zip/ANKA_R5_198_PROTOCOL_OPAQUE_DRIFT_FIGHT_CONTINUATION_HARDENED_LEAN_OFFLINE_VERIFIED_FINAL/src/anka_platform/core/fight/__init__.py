"""Core fight contracts, state machines, and orchestration components.

R5.148 intentionally keeps this package initializer dependency-free.  Import
concrete components from their modules (for example ``core.fight.controller`` or
``core.fight.planner_contract``).  Eager re-exports here previously created a
FightAI <-> core circular-import path and made low-level contracts impossible to
use independently.
"""

__all__: list[str] = []

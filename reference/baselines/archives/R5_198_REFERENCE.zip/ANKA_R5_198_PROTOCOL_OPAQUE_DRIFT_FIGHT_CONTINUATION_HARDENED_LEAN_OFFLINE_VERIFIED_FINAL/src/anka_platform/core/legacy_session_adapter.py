from __future__ import annotations

from dataclasses import replace

from anka_platform.config import PartyMemberRole, PlatformConfig
from anka_platform.core.health import HealthStatus, ProtocolCapabilityReport
from anka_platform.core.models import ControlMode, MembershipRequirement, PartyLeadership
from anka_platform.core.registry import build_r594_policy_registry
from anka_platform.core.session import PlayerProfile, SessionPlan
from anka_platform.core.session_compiler import SessionCompiler
from anka_platform.missions.models import MissionDefinition, MissionStop


def compile_legacy_session_plan(config: PlatformConfig, *, session_id: str | None = None) -> SessionPlan:
    """Compile current R5.94 config into the new immutable plan without changing runtime behavior."""

    profiles: dict[str, PlayerProfile] = {}
    control_modes: dict[str, ControlMode] = {}
    fight_policy_ids: dict[str, str | None] = {}
    passive_policy_ids: dict[str, str | None] = {}
    required_ids: list[str] = []

    for account in config.party.accounts:
        control = ControlMode.ACTIVE if account.role is PartyMemberRole.ACTIVE_CONTROLLER else ControlMode.PASSIVE
        requirement = MembershipRequirement.REQUIRED if account.required else MembershipRequirement.OPTIONAL
        leadership = PartyLeadership.LEADER if account.account_id == config.party.leader_account_id else PartyLeadership.MEMBER
        profiles[account.account_id] = PlayerProfile(
            account_id=account.account_id,
            character_name=account.character_name,
            class_name=account.class_name,
            window_title_contains=account.window_title_contains,
            calibration_profile=account.calibration_profile,
            activation_hotkey=account.activation_hotkey,
            default_control_mode=control,
            default_requirement=requirement,
            default_leadership=leadership,
            default_fight_policy_id="normal" if control is ControlMode.ACTIVE else None,
            default_passive_policy_id="passive_end_turn" if control is ControlMode.PASSIVE else None,
        )
        control_modes[account.account_id] = control
        fight_policy_ids[account.account_id] = "normal" if control is ControlMode.ACTIVE else None
        passive_policy_ids[account.account_id] = "passive_end_turn" if control is ControlMode.PASSIVE else None
        if account.required:
            required_ids.append(account.account_id)

    mission = MissionDefinition(
        id="legacy_r594_party_patrol",
        route_id="legacy_patrol",
        target_policy_id="monster_count_range",
        fight_policy_set_id="r594_normal",
        team_strategy_id=None,
        stop=MissionStop(
            target_wins=config.run_budget.target_wins,
            max_attempts=config.run_budget.max_attempts,
            stop_on_loss=config.run_budget.stop_on_loss,
            stop_on_unknown=config.run_budget.stop_on_unknown,
        ),
        required_capabilities=(),
    )
    report = ProtocolCapabilityReport(
        adapter_id=config.protocol.active_adapter,
        canonical_contract_version=config.protocol.canonical_contract_version,
        capabilities=frozenset(),
        status=HealthStatus.READY,
    )
    plan = SessionCompiler(build_r594_policy_registry()).compile(
        mission,
        selected_account_ids=tuple(account.account_id for account in config.party.accounts),
        player_profiles=profiles,
        protocol_report=report,
        session_id=session_id,
        leader_account_id=config.party.leader_account_id,
        required_account_ids=tuple(required_ids),
        control_modes=control_modes,
        fight_policy_ids=fight_policy_ids,
        passive_policy_ids=passive_policy_ids,
    )
    return replace(
        plan,
        route_coordinates=tuple((int(x), int(y)) for x, y in config.patrol.world_coordinates),
        target_min_monsters=int(config.patrol.min_monsters),
        target_max_monsters=int(config.patrol.max_monsters),
    )

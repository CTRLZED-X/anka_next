from __future__ import annotations

from typing import Callable, Protocol

from anka_platform.config import PartyMemberRole
from anka_platform.core.fight.decision_contract import FightDecision



class PassiveDecisionPort(Protocol):
    def decide(self, *, current_cell_id: int | None = None) -> FightDecision: ...


class _DefaultPassiveEndTurn:
    """Foundation fallback with no dependency on a concrete FightAI package."""

    def decide(self, *, current_cell_id: int | None = None) -> FightDecision:
        del current_cell_id
        from anka_platform.core.fight.decision_contract import FightDecisionKind
        return FightDecision(FightDecisionKind.END_TURN, "PASSIVE_END_TURN")

def decision_to_payload(decision: FightDecision) -> dict:
    return dict(decision.to_payload())


class LegacyTurnPolicyResolver:
    """Compatibility resolver that moves role branching out of the controller.

    ACTIVE_CONTROLLER delegates to the existing active FightAI decision provider.
    Passive accounts are resolved through the real PassivePolicy implementation.
    """

    def __init__(
        self,
        active_decision_provider: Callable[[str], dict],
        *,
        passive_policy: PassiveDecisionPort | None = None,
    ) -> None:
        self._active = active_decision_provider
        self._passive: PassiveDecisionPort = passive_policy or _DefaultPassiveEndTurn()

    def decide(self, account_id: str, role: str, *, current_cell_id: int | None = None) -> dict:
        if str(role) == PartyMemberRole.ACTIVE_CONTROLLER.value:
            return dict(self._active(str(account_id)))
        payload = decision_to_payload(self._passive.decide(current_cell_id=current_cell_id))
        # Preserve the proven R5.94 outward diagnostic while using PassivePolicy internally.
        if payload.get("kind") == "END_TURN" and payload.get("reason") == "PASSIVE_END_TURN":
            payload["reason"] = "PASSIVE_MEMBER"
        return payload


class ServiceTurnPolicyResolver:
    """Adapter from PartyCombatController's turn hook to FightDecisionService."""

    def __init__(self, service) -> None:
        self._service = service

    def decide(self, account_id: str, role: str, *, current_cell_id: int | None = None) -> dict:
        return dict(self._service.decide(account_id, account_role=role))

    def decide_with_context(
        self, account_id: str, role: str, *, current_cell_id: int | None = None,
        confirmed_turn_history=None,
    ) -> dict:
        del current_cell_id
        return dict(self._service.decide(
            account_id, account_role=role, confirmed_turn_history=confirmed_turn_history
        ))

    def quarantine(self, account_id: str, decision: dict) -> dict:
        handler = getattr(self._service, "quarantine_decision", None)
        if not callable(handler):
            return {"supported": False}
        return {"supported": True, **dict(handler(str(account_id), dict(decision)))}

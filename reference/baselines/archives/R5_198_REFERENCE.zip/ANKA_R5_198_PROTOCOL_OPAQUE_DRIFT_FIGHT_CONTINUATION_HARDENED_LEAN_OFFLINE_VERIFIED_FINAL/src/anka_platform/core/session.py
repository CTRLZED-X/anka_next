from __future__ import annotations

from dataclasses import dataclass

from anka_platform.core.models import ControlMode, MembershipRequirement, PartyLeadership, SessionMember
from anka_platform.core.routes import RouteDirection, normalize_coordinate, normalize_route_directions, require_closed_cycle, route_source_coordinates


def _required_text(value: str, field_name: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        raise ValueError(f"{field_name} must not be empty")
    return normalized


def _optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


@dataclass(frozen=True, slots=True)
class PlayerProfile:
    account_id: str
    character_name: str
    class_name: str
    window_title_contains: str
    calibration_profile: str
    activation_hotkey: str | None = None
    default_control_mode: ControlMode = ControlMode.PASSIVE
    default_requirement: MembershipRequirement = MembershipRequirement.OPTIONAL
    default_leadership: PartyLeadership = PartyLeadership.MEMBER
    default_fight_policy_id: str | None = None
    default_passive_policy_id: str | None = "passive_end_turn"
    default_placement_policy_id: str | None = None
    default_combat_profile_id: str | None = None

    def __post_init__(self) -> None:
        for field_name in ("account_id", "character_name", "class_name", "window_title_contains", "calibration_profile"):
            object.__setattr__(self, field_name, _required_text(getattr(self, field_name), field_name))
        hotkey = _optional_text(self.activation_hotkey)
        if hotkey is not None:
            hotkey = hotkey.upper()
        object.__setattr__(self, "activation_hotkey", hotkey)
        object.__setattr__(self, "default_fight_policy_id", _optional_text(self.default_fight_policy_id))
        object.__setattr__(self, "default_passive_policy_id", _optional_text(self.default_passive_policy_id))
        object.__setattr__(self, "default_placement_policy_id", _optional_text(self.default_placement_policy_id))
        object.__setattr__(self, "default_combat_profile_id", _optional_text(self.default_combat_profile_id))


@dataclass(frozen=True, slots=True)
class SessionStopConditions:
    target_wins: int = 1
    max_attempts: int = 1
    stop_on_loss: bool = True
    stop_on_unknown: bool = True

    def __post_init__(self) -> None:
        if int(self.target_wins) < 1:
            raise ValueError("target_wins must be >= 1")
        if int(self.max_attempts) < 1:
            raise ValueError("max_attempts must be >= 1")
        if int(self.target_wins) > int(self.max_attempts):
            raise ValueError("target_wins cannot exceed max_attempts")
        object.__setattr__(self, "target_wins", int(self.target_wins))
        object.__setattr__(self, "max_attempts", int(self.max_attempts))


@dataclass(frozen=True, slots=True)
class SessionPlan:
    """Immutable, fully resolved description of what a session intends to run.

    Runtime services/stores/windows are intentionally excluded.  The plan can be
    logged, compared, inspected in Script Studio, and reconstructed for forensics.
    """

    session_id: str
    mission_id: str
    members: tuple[SessionMember, ...]
    player_profiles: tuple[PlayerProfile, ...]
    protocol_adapter_id: str
    canonical_contract_version: int
    team_strategy_id: str | None
    route_id: str
    target_policy_id: str
    stop: SessionStopConditions
    fight_policy_set_id: str | None = None
    required_capabilities: tuple[str, ...] = ()
    # Directional route intent is authoritative for new sessions. route_coordinates
    # remains a derived/legacy compatibility view and must not be edited by runtime.
    route_start_coordinate: tuple[int, int] | None = None
    route_directions: tuple[RouteDirection, ...] = ()
    route_coordinates: tuple[tuple[int, int], ...] = ()
    target_min_monsters: int | None = None
    target_max_monsters: int | None = None
    route_loop: bool = True

    def __post_init__(self) -> None:
        for field_name in ("session_id", "mission_id", "protocol_adapter_id", "route_id", "target_policy_id"):
            object.__setattr__(self, field_name, _required_text(getattr(self, field_name), field_name))
        if int(self.canonical_contract_version) < 1:
            raise ValueError("canonical_contract_version must be >= 1")
        object.__setattr__(self, "canonical_contract_version", int(self.canonical_contract_version))
        object.__setattr__(self, "team_strategy_id", _optional_text(self.team_strategy_id))
        object.__setattr__(self, "fight_policy_set_id", _optional_text(self.fight_policy_set_id))

        member_ids = [member.account_id for member in self.members]
        if not member_ids:
            raise ValueError("session requires at least one member")
        if len(member_ids) != len(set(member_ids)):
            raise ValueError("duplicate session member account_id")
        leaders = [member for member in self.members if member.leadership is PartyLeadership.LEADER]
        if len(leaders) != 1:
            raise ValueError("session requires exactly one leader")

        profile_ids = [profile.account_id for profile in self.player_profiles]
        if len(profile_ids) != len(set(profile_ids)):
            raise ValueError("duplicate player profile account_id")
        if set(member_ids) != set(profile_ids):
            raise ValueError("session members and player profiles must identify the same accounts")

        windows = [profile.window_title_contains.casefold() for profile in self.player_profiles]
        if len(windows) != len(set(windows)):
            raise ValueError("duplicate player window identity")

        required_caps = tuple(dict.fromkeys(str(item).strip().upper() for item in self.required_capabilities if str(item).strip()))
        object.__setattr__(self, "required_capabilities", required_caps)
        directions = normalize_route_directions(self.route_directions)
        object.__setattr__(self, "route_directions", directions)
        if self.route_start_coordinate is not None:
            start = normalize_coordinate(self.route_start_coordinate, field_name="route_start_coordinate")
            object.__setattr__(self, "route_start_coordinate", start)
            if directions:
                if self.route_loop:
                    require_closed_cycle(start, directions)
                object.__setattr__(self, "route_coordinates", route_source_coordinates(start, directions))
        object.__setattr__(self, "route_coordinates", tuple((int(x), int(y)) for x, y in self.route_coordinates))
        if directions and self.route_start_coordinate is None:
            raise ValueError("route_start_coordinate is required when route_directions are configured")
        if self.target_min_monsters is not None:
            value = int(self.target_min_monsters)
            if value < 1:
                raise ValueError("target_min_monsters must be >= 1")
            object.__setattr__(self, "target_min_monsters", value)
        if self.target_max_monsters is not None:
            value = int(self.target_max_monsters)
            if value < 1:
                raise ValueError("target_max_monsters must be >= 1")
            object.__setattr__(self, "target_max_monsters", value)
        if self.target_min_monsters is not None and self.target_max_monsters is not None and self.target_min_monsters > self.target_max_monsters:
            raise ValueError("target_min_monsters must be <= target_max_monsters")

    @property
    def leader(self) -> SessionMember:
        return next(member for member in self.members if member.leadership is PartyLeadership.LEADER)

    def member_for(self, account_id: str) -> SessionMember:
        key = str(account_id).strip()
        try:
            return next(member for member in self.members if member.account_id == key)
        except StopIteration as exc:
            raise KeyError(f"unknown session member: {key}") from exc

    def profile_for(self, account_id: str) -> PlayerProfile:
        key = str(account_id).strip()
        try:
            return next(profile for profile in self.player_profiles if profile.account_id == key)
        except StopIteration as exc:
            raise KeyError(f"unknown player profile: {key}") from exc

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, StrEnum
from typing import Any, Mapping

from anka_platform.contracts.combat_action import ActionIntent
from anka_platform.core.fight.planner_contract import (
    PlannerDisposition,
    PlannerFailureClass,
    PlannerProgress,
)


class FightDecisionKind(str, Enum):
    CAST = "CAST"
    MOVE = "MOVE"
    END_TURN = "END_TURN"
    WAIT = "WAIT"
    BLOCKED = "BLOCKED"


class FightAdmissionMode(StrEnum):
    STRICT = "STRICT"
    CLIENT_VALIDATE_SAFE_PROBE = "CLIENT_VALIDATE_SAFE_PROBE"


@dataclass(frozen=True, slots=True)
class FightDecision:
    """Stable planner -> orchestration executable-decision contract.

    This type is owned by the core combat foundation, not by a concrete FightAI
    implementation.  Planner orchestration metadata is intentionally excluded
    from ``to_payload`` so ExecutionService consumes only physical action intent.
    """

    kind: FightDecisionKind
    reason: str = ""
    spell_id: int | None = None
    grade: int | None = None
    slot_index: int | None = None
    target_cell_id: int | None = None
    path_distance: int | None = None
    target_actor_id: int | None = None
    target_count: int = 0
    action_intent: ActionIntent | None = None
    admission_mode: FightAdmissionMode = FightAdmissionMode.STRICT
    probe_assumptions: tuple[str, ...] = ()
    planner_disposition: PlannerDisposition | None = None
    planner_progress: PlannerProgress | None = None
    planner_dependency: str | None = None
    planner_failure_class: PlannerFailureClass | None = None

    def fingerprint(self) -> tuple:
        return action_key_from_decision(self)

    def resolved_planner_disposition(self) -> PlannerDisposition:
        if self.planner_disposition is not None:
            return self.planner_disposition
        if self.kind in {FightDecisionKind.CAST, FightDecisionKind.MOVE, FightDecisionKind.END_TURN}:
            return PlannerDisposition.ACTION_READY
        if self.kind is FightDecisionKind.WAIT:
            return PlannerDisposition.WAIT_EXTERNAL
        return PlannerDisposition.FAULT

    def planner_result_payload(self) -> dict[str, object]:
        payload = {
            "schema_version": 1,
            "disposition": self.resolved_planner_disposition().value,
            "reason": str(self.reason),
            "dependency": self.planner_dependency,
            "progress": None if self.planner_progress is None else self.planner_progress.to_payload(),
        }
        if self.planner_failure_class is not None:
            payload["failure_class"] = self.planner_failure_class.value
        return payload

    def to_payload(self) -> dict[str, object]:
        return {
            "kind": self.kind.value,
            "reason": str(self.reason),
            "spell_id": self.spell_id,
            "grade": self.grade,
            "slot_index": self.slot_index,
            "target_cell_id": self.target_cell_id,
            "path_distance": self.path_distance,
            "target_actor_id": self.target_actor_id,
            "target_count": int(self.target_count),
            "action_intent": None if self.action_intent is None else self.action_intent.to_payload(),
            "admission_mode": self.admission_mode.value,
            "probe_assumptions": list(self.probe_assumptions),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "FightDecision":
        if not isinstance(payload, Mapping):
            raise ValueError("fight decision payload must be a mapping")
        try:
            kind = FightDecisionKind(str(payload.get("kind") or ""))
        except ValueError as exc:
            raise ValueError("fight decision kind is invalid") from exc
        intent_payload = payload.get("action_intent")
        intent = None if intent_payload is None else ActionIntent.from_payload(intent_payload)
        try:
            admission_mode = FightAdmissionMode(
                str(payload.get("admission_mode") or FightAdmissionMode.STRICT.value)
            )
        except ValueError as exc:
            raise ValueError("fight decision admission_mode is invalid") from exc
        probe_raw = payload.get("probe_assumptions", [])
        if not isinstance(probe_raw, list) or any(
            not isinstance(item, str) or not item for item in probe_raw
        ):
            raise ValueError("fight decision probe_assumptions must be a list of non-empty strings")
        probe_assumptions = tuple(probe_raw)
        if admission_mode is FightAdmissionMode.STRICT and probe_assumptions:
            raise ValueError("strict fight decision cannot carry probe assumptions")
        if admission_mode is FightAdmissionMode.CLIENT_VALIDATE_SAFE_PROBE and not probe_assumptions:
            raise ValueError("safe-probe fight decision requires probe assumptions")

        def optional_int(name: str) -> int | None:
            value = payload.get(name)
            if value is None:
                return None
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"fight decision {name} must be an integer or null")
            return int(value)

        return cls(
            kind=kind,
            reason=str(payload.get("reason") or ""),
            spell_id=optional_int("spell_id"),
            grade=optional_int("grade"),
            slot_index=optional_int("slot_index"),
            target_cell_id=optional_int("target_cell_id"),
            path_distance=optional_int("path_distance"),
            target_actor_id=optional_int("target_actor_id"),
            target_count=int(payload.get("target_count") or 0),
            action_intent=intent,
            admission_mode=admission_mode,
            probe_assumptions=probe_assumptions,
        )


def action_key_from_decision(decision: FightDecision) -> tuple:
    return (
        decision.kind.value,
        decision.spell_id,
        decision.grade,
        decision.slot_index,
        decision.target_cell_id,
        decision.target_actor_id,
        None if decision.action_intent is None else decision.action_intent.fingerprint(),
    )


def action_key_from_payload(payload: Mapping[str, Any]) -> tuple:
    """Return the canonical semantic identity for a serialized decision."""
    return FightDecision.from_payload(payload).fingerprint()

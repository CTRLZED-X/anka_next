from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Mapping


class CombatActionPhase(StrEnum):
    ACCEPTED = "ACCEPTED"
    RECONCILING = "RECONCILING"
    AWAITING_SETTLEMENT = "AWAITING_SETTLEMENT"
    REJECTED_NOT_SENT = "REJECTED_NOT_SENT"
    SEMANTIC_REJECTED_SAFE = "SEMANTIC_REJECTED_SAFE"
    PHYSICAL_UNCERTAIN = "PHYSICAL_UNCERTAIN"
    CONTROL_FAILURE = "CONTROL_FAILURE"
    CONTRACT_VIOLATION = "CONTRACT_VIOLATION"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"


_CONTROL_CODES = frozenset({
    "WINDOW_NOT_FOUND", "WINDOW_AMBIGUOUS", "WINDOW_IDENTITY_CHANGED",
    "INPUT_INTEGRITY_MISMATCH", "CLIENT_SIZE_MISMATCH",
    "DPI_CONTEXT_FAILURE", "ACTION_EXECUTION_LEASE_DENIED",
})


@dataclass(frozen=True, slots=True)
class CombatActionOutcome:
    """Typed view of ExecutionService's transport/result mapping.

    ExecutionService remains the physical-input authority.  This adapter gives
    orchestration/recovery one stable vocabulary so callers do not independently
    reinterpret raw status/failure strings in several modules.
    """

    phase: CombatActionPhase
    status: str
    failure_code: str
    physical_send_state: str
    semantic_send_state: str
    retry_allowed: bool | None
    safe_replan: bool
    quarantine_candidate: bool
    contract_error: str | None = None
    raw_failure_code: str = ""

    @property
    def accepted(self) -> bool:
        return self.phase is CombatActionPhase.ACCEPTED

    @property
    def input_may_have_occurred(self) -> bool:
        return self.physical_send_state in {"SENT", "UNCERTAIN"}

    @property
    def no_physical_input(self) -> bool:
        return self.physical_send_state in {"", "NOT_SENT"}

    @property
    def blocked_like(self) -> bool:
        return self.phase in {
            CombatActionPhase.AWAITING_SETTLEMENT,
            CombatActionPhase.REJECTED_NOT_SENT,
            CombatActionPhase.SEMANTIC_REJECTED_SAFE,
            CombatActionPhase.PHYSICAL_UNCERTAIN,
            CombatActionPhase.CONTROL_FAILURE,
            CombatActionPhase.CONTRACT_VIOLATION,
        }

    @classmethod
    def from_mapping(cls, result: Mapping[str, object]) -> "CombatActionOutcome":
        status = str(result.get("status") or "UNKNOWN").upper()
        raw_code = str(result.get("failure_code") or "")
        physical = str(result.get("physical_send_state") or "").upper()
        semantic = str(
            result.get("semantic_cast_send_state")
            or result.get("semantic_move_send_state")
            or result.get("semantic_end_turn_send_state")
            or ""
        ).upper()
        retry_raw = result.get("retry_allowed")
        retry = retry_raw if isinstance(retry_raw, bool) else None

        accepted_status = status in {"CONFIRMED", "SETTLED"}
        valid_physical = {"", "NOT_SENT", "SENT", "UNCERTAIN", "UNKNOWN"}
        valid_semantic = {
            "", "NOT_SENT", "SENT", "UNCERTAIN", "UNKNOWN", "OBSERVED",
            "CONFIRMED", "ABSENT_SAMPLE", "PROVEN_ABSENT",
        }
        contract_errors: list[str] = []
        if physical not in valid_physical:
            contract_errors.append(f"unknown physical_send_state={physical}")
        if semantic not in valid_semantic:
            contract_errors.append(f"unknown semantic_send_state={semantic}")
        if status == "SENT":
            contract_errors.append(
                "combat action result cannot terminate at generic SENT; settlement or reconciliation is required"
            )
        if accepted_status:
            if raw_code:
                contract_errors.append(f"accepted status carries failure_code={raw_code}")
            if physical not in {"", "SENT"}:
                contract_errors.append(f"accepted status contradicts physical_send_state={physical}")
            if semantic in {"NOT_SENT", "UNCERTAIN"}:
                contract_errors.append(f"accepted status contradicts semantic_send_state={semantic}")
        if status == "RECONCILING" and physical not in {"SENT", "UNCERTAIN"}:
            contract_errors.append(
                f"RECONCILING requires SENT/UNCERTAIN physical_send_state, got {physical or 'MISSING'}"
            )
        if physical == "NOT_SENT" and semantic in {"SENT", "OBSERVED", "CONFIRMED"}:
            contract_errors.append(
                f"physical_send_state=NOT_SENT contradicts semantic_send_state={semantic}"
            )

        contract_error = "; ".join(contract_errors) or None
        code = "INVALID_EXECUTION_RESULT_CONTRACT" if contract_error else raw_code

        if contract_error:
            phase = CombatActionPhase.CONTRACT_VIOLATION
        elif accepted_status:
            phase = CombatActionPhase.ACCEPTED
        elif (
            status == "BLOCKED"
            and physical == "SENT"
            and semantic == "NOT_SENT"
            and bool(result.get("safe_replan"))
            and bool(result.get("quarantine_candidate"))
            and (
                code == "CLIENT_CAST_REJECTED"
                or (
                    isinstance(result.get("ui_neutralization"), Mapping)
                    and bool(result.get("ui_neutralization", {}).get("neutralized"))
                )
            )
        ):
            # Some CAST failures happen after the harmless spell-slot click but
            # before any semantic cast request.  Once ExecutionService proves the
            # UI was neutralized, this is a safe semantic abort, not a terminal
            # physical-input failure.  R5.149 accidentally classified this shape
            # as FAILED, making the recovery policy's safe_replan contract
            # unreachable.
            phase = CombatActionPhase.SEMANTIC_REJECTED_SAFE
        elif status == "RECONCILING" or code in {
            "COMBAT_MOVE_CAUSALITY_PENDING",
            "COMBAT_CAST_CAUSALITY_PENDING",
            "COMBAT_END_TURN_CAUSALITY_PENDING",
        }:
            phase = CombatActionPhase.RECONCILING
        elif status == "CONFIRMED_UNSETTLED" or code in {"ACTION_SETTLEMENT_TIMEOUT", "ACTION_CONFIRM_TIMEOUT"}:
            phase = (
                CombatActionPhase.PHYSICAL_UNCERTAIN
                if physical in {"SENT", "UNCERTAIN"} and semantic in {"", "UNCERTAIN"}
                else CombatActionPhase.AWAITING_SETTLEMENT
            )
        elif code in {"INPUT_UNCERTAIN", "ACTION_UNCERTAIN_FENCE"} or (
            physical in {"SENT", "UNCERTAIN"} and semantic in {"", "UNCERTAIN"}
        ):
            phase = CombatActionPhase.PHYSICAL_UNCERTAIN
        elif code.startswith("CONTROL_") or code in _CONTROL_CODES:
            phase = CombatActionPhase.CONTROL_FAILURE
        elif status == "BLOCKED" and physical in {"", "NOT_SENT"}:
            phase = CombatActionPhase.REJECTED_NOT_SENT
        elif status in {"FAILED", "BLOCKED"}:
            phase = CombatActionPhase.FAILED
        else:
            phase = CombatActionPhase.UNKNOWN

        return cls(
            phase=phase,
            status=status,
            failure_code=code,
            physical_send_state=physical,
            semantic_send_state=semantic,
            retry_allowed=retry,
            safe_replan=bool(result.get("safe_replan")),
            quarantine_candidate=bool(result.get("quarantine_candidate")),
            contract_error=contract_error,
            raw_failure_code=raw_code,
        )


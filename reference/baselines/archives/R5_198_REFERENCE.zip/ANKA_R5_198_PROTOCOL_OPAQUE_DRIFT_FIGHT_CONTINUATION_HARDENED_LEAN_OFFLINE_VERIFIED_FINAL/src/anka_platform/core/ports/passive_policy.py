from __future__ import annotations

from typing import Protocol, runtime_checkable

from anka_platform.core.fight.decision_contract import FightDecision
from anka_platform.core.fight.planner_contract import PassiveInvocationContext


@runtime_checkable
class PassiveTurnPolicy(Protocol):
    def decide(self, *, planner_context: PassiveInvocationContext) -> FightDecision: ...

from __future__ import annotations

import inspect
from collections.abc import Callable, Mapping
from typing import Any

from anka_platform.contracts.correlation import CorrelationContext, correlation_mapping
from anka_platform.contracts.failure_registry import RetryDisposition, explicit_failure_attribution, failure_spec


# Retry/attribution semantics are centralized in contracts.failure_registry.


def callable_accepts_runtime_context(callback: Callable[..., Any]) -> bool:
    """Return whether a compatibility callable accepts ``runtime_context``.

    Production physical-control callables must accept the correlated runtime
    context. A small amount of legacy/test code still exposes the historical
    zero-argument activation contract, so callers inspect the signature instead
    of catching ``TypeError``. Catching ``TypeError`` around the invocation can
    accidentally swallow a real bug raised *inside* the physical-control path.
    """

    try:
        parameters = inspect.signature(callback).parameters.values()
    except (TypeError, ValueError):
        return False
    return any(
        parameter.name == "runtime_context"
        or parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in parameters
    )


def invoke_correlated_activation(
    callback: Callable[..., Any],
    *,
    runtime_context: Mapping[str, Any] | None,
) -> dict:
    """Invoke one account window activation without losing run correlation."""

    correlation = correlation_mapping(runtime_context)
    if callable_accepts_runtime_context(callback):
        return dict(callback(runtime_context=correlation))
    authority_correlation = CorrelationContext.from_mapping(correlation).has_authority_identity
    if authority_correlation:
        # Never silently discard a real live-control correlation. Metadata such
        # as account_id alone is not an authority token and remains compatible
        # with legacy zero-argument test/utility façades. A future production
        # executor that receives any session/run/request/script correlation but
        # cannot accept runtime_context fails at the exact seam instead of
        # bypassing control authority.
        return {
            "status": "BLOCKED",
            "failure_code": "CONTROL_CORRELATION_UNSUPPORTED",
            "detail": "window activation callable cannot accept runtime_context",
            "retry_allowed": False,
            "first_missing_boundary": "TURN_OWNER_CONTROL_AUTHORIZATION",
            "likely_owner": "EXECUTION_CONTROL",
            "runtime_context": correlation,
        }
    # Compatibility-only fallback for narrow legacy/test façades when there is
    # no session/run context to lose.
    return dict(callback())


def failure_code(result: Mapping[str, Any] | None) -> str | None:
    if not isinstance(result, Mapping):
        return None
    raw = result.get("failure_code")
    if raw is None:
        authority = result.get("control_authority")
        if isinstance(authority, Mapping):
            raw = authority.get("failure_code")
    token = str(raw or "").strip()
    return token or None


def retry_allowed(result: Mapping[str, Any] | None) -> bool | None:
    """Classify whether repeating a blocked operation is safe/useful.

    An explicit result flag always wins. Control/identity invariant failures are
    terminal for the current run. Unknown blocked outcomes remain unclassified
    so the owning workflow may apply its existing bounded policy.
    """

    if not isinstance(result, Mapping):
        return None
    explicit = result.get("retry_allowed")
    if isinstance(explicit, bool):
        return explicit
    code = failure_code(result)
    if code is None:
        return None
    spec = failure_spec(code)
    if spec is not None:
        if spec.retry is RetryDisposition.NEVER:
            return False
        if spec.retry in {RetryDisposition.RECONCILE_ONLY, RetryDisposition.BOUNDED, RetryDisposition.AFTER_STATE_CHANGE}:
            return True
    # Unknown control failures remain non-retryable at runtime even before the
    # architecture gate can reject the new producer.
    if code.startswith("CONTROL_"):
        return False
    return None


def failure_attribution(result: Mapping[str, Any] | None) -> tuple[str | None, str | None]:
    """Return the registry-owned boundary/owner attribution for a result."""

    code = failure_code(result)
    return explicit_failure_attribution(code)

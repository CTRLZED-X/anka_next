"""Composition root for concrete ANKA platform dependencies.

Only construction belongs here. Core contracts remain infrastructure agnostic.
Existing callers are intentionally not migrated in A1/A2.
"""
from __future__ import annotations

from pathlib import Path

from anka_platform.config import load_platform_config
from anka_platform.core.legacy_session_adapter import compile_legacy_session_plan
from anka_platform.core.registry import PolicyRegistry
from anka_platform.policy_composition import build_r594_policy_registry as _build_r594_policy_registry
from anka_platform.core.session import SessionPlan


def build_r594_policy_registry(*, kernel=None) -> PolicyRegistry:
    return _build_r594_policy_registry(kernel=kernel)


def compile_current_config_session_plan(config_path: str | Path, *, session_id: str | None = None) -> SessionPlan:
    return compile_legacy_session_plan(load_platform_config(config_path), session_id=session_id)

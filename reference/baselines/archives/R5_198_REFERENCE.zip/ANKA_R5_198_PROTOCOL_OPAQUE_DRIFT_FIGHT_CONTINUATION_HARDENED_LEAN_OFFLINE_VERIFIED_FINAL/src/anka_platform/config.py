from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

import yaml
from yaml.constructor import ConstructorError
from yaml.resolver import BaseResolver
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from anka_game_kernel.config import ExternalGameDataConfig
from anka_platform.calibration.models import CalibrationSettings


class PlatformConfigError(ValueError):
    """Raised when root ANKA platform configuration is invalid."""


class _UniqueKeySafeLoader(yaml.SafeLoader):
    """Safe YAML loader that rejects duplicate mapping keys.

    PyYAML normally keeps the last duplicate key silently.  That behavior is
    unsafe for timeout/safety configuration because an operator can believe one
    value is active while another duplicate later in the file wins.
    """


def _construct_unique_mapping(loader: _UniqueKeySafeLoader, node, deep: bool = False):
    loader.flatten_mapping(node)
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            duplicate = key in mapping
        except TypeError as exc:
            raise ConstructorError(
                "while constructing a mapping",
                node.start_mark,
                "found unhashable configuration key",
                key_node.start_mark,
            ) from exc
        if duplicate:
            raise ConstructorError(
                "while constructing a mapping",
                node.start_mark,
                f"found duplicate configuration key {key!r}",
                key_node.start_mark,
            )
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


_UniqueKeySafeLoader.add_constructor(
    BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


class KernelSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    static_directory: Path
    mapuse_directory: Path
    maps_directory: Path | None = None
    game_version: str = "3.6.10.10"
    static_source_version: str = "static-user-supplied"
    mapuse_source_version: str = "mapuse-user-supplied"
    pack_version: str = "anka-external-game-data-v1"

    @field_validator("game_version", "static_source_version", "mapuse_source_version", "pack_version")
    @classmethod
    def _non_empty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be empty")
        return value

    def external_game_data(self) -> ExternalGameDataConfig:
        return ExternalGameDataConfig(
            static_directory=self.static_directory,
            mapuse_directory=self.mapuse_directory,
            static_source_version=self.static_source_version,
            mapuse_source_version=self.mapuse_source_version,
            pack_version=self.pack_version,
            game_version=self.game_version,
        )


class ProtocolSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    active_adapter: str
    canonical_contract_version: int = Field(default=1, ge=1)

    @field_validator("active_adapter")
    @classmethod
    def _active_adapter_non_empty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("active_adapter must not be empty")
        return value




class PartyMemberRole(str, Enum):
    ACTIVE_CONTROLLER = "ACTIVE_CONTROLLER"
    PASSIVE_MEMBER = "PASSIVE_MEMBER"


class PartyAccountSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    account_id: str
    character_name: str
    class_name: str
    role: PartyMemberRole = PartyMemberRole.PASSIVE_MEMBER
    required: bool = False
    window_title_contains: str
    calibration_profile: str = "default"
    activation_hotkey: str | None = None
    combat_profile_id: str | None = None

    @field_validator("account_id", "character_name", "class_name", "window_title_contains", "calibration_profile")
    @classmethod
    def _non_empty_text(cls, value: str) -> str:
        normalized = str(value).strip()
        if not normalized:
            raise ValueError("must not be empty")
        return normalized

    @field_validator("activation_hotkey")
    @classmethod
    def _valid_activation_hotkey(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip().upper()
        if not normalized.startswith("F") or not normalized[1:].isdigit():
            raise ValueError("activation_hotkey must be one function key F1..F24")
        number = int(normalized[1:])
        if not 1 <= number <= 24:
            raise ValueError("activation_hotkey must be one function key F1..F24")
        return f"F{number}"

    @field_validator("combat_profile_id")
    @classmethod
    def _combat_profile_id(cls, value: str | None) -> str | None:
        if value is None:
            return None
        token = str(value).strip()
        return token or None


class PartySettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    enabled: bool = False
    leader_account_id: str | None = None
    accounts: tuple[PartyAccountSettings, ...] = ()
    bridge_port_start: int = Field(default=8765, ge=1, le=65535)
    bridge_port_count: int = Field(default=32, ge=1, le=128)

    @model_validator(mode="after")
    def _validate_party(self) -> "PartySettings":
        ids = [item.account_id for item in self.accounts]
        if len(ids) != len(set(ids)):
            raise ValueError("party account_id values must be unique")
        tokens = [item.window_title_contains.casefold() for item in self.accounts]
        if len(tokens) != len(set(tokens)):
            raise ValueError("party window_title_contains values must be unique")
        if self.enabled:
            if not self.accounts:
                raise ValueError("enabled party requires accounts")
            if self.leader_account_id is None or self.leader_account_id not in set(ids):
                raise ValueError("leader_account_id must identify a configured party account")
        if self.bridge_port_start + self.bridge_port_count - 1 > 65535:
            raise ValueError("bridge port range exceeds 65535")
        return self

    @property
    def leader(self) -> PartyAccountSettings | None:
        return next((item for item in self.accounts if item.account_id == self.leader_account_id), None)

    @property
    def active_controllers(self) -> tuple[PartyAccountSettings, ...]:
        return tuple(item for item in self.accounts if item.role is PartyMemberRole.ACTIVE_CONTROLLER)

    @property
    def optional_members(self) -> tuple[PartyAccountSettings, ...]:
        return tuple(item for item in self.accounts if not item.required)


class PatrolSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    world_coordinates: tuple[tuple[int, int], ...] = ((7, -12), (8, -12), (8, -11), (7, -11))
    min_monsters: int = Field(default=6, ge=1)
    max_monsters: int = Field(default=8, ge=1)

    @model_validator(mode="after")
    def _validate_patrol(self) -> "PatrolSettings":
        if not self.world_coordinates:
            raise ValueError("patrol world_coordinates must not be empty")
        if self.min_monsters > self.max_monsters:
            raise ValueError("patrol min_monsters must be <= max_monsters")
        return self


class CombatSpellSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    spell_id: int = Field(gt=0)
    grade: int = Field(ge=1, le=3)
    slot_index: int = Field(ge=1, le=22)
    priority: int = Field(default=0)
    enabled: bool = True

    @property
    def protocol_slot_index(self) -> int:
        """Compatibility facade for the current adapter-owned slot dialect.

        New runtime code should resolve slots through the active protocol manifest.
        """
        from anka_platform.protocol.slots import default_protocol_spell_slot_index
        return default_protocol_spell_slot_index(int(self.slot_index))


class CombatProfileSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    spells: tuple[CombatSpellSettings, ...] = ()
    compatible_classes: tuple[str, ...] = ()
    # Static strategic affinity only. These elements influence ranking, never
    # live legality/resources. They are intentionally profile-owned so a build
    # change does not require policy source edits.
    preferred_damage_elements: tuple[str, ...] = ()

    @field_validator("compatible_classes")
    @classmethod
    def _compatible_classes(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        normalized: list[str] = []
        seen: set[str] = set()
        for raw in values:
            value = str(raw).strip()
            if not value:
                continue
            token = value.casefold()
            if token in seen:
                continue
            seen.add(token)
            normalized.append(value)
        return tuple(normalized)

    @field_validator("preferred_damage_elements")
    @classmethod
    def _preferred_damage_elements(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        allowed = {"neutral", "earth", "fire", "water", "air"}
        normalized: list[str] = []
        seen: set[str] = set()
        for raw in values:
            value = str(raw).strip().casefold()
            if not value:
                continue
            if value not in allowed:
                raise ValueError(f"unsupported preferred damage element: {raw!r}")
            if value in seen:
                continue
            seen.add(value)
            normalized.append(value)
        return tuple(normalized)

    @property
    def enabled_spells(self) -> tuple[CombatSpellSettings, ...]:
        return tuple(item for item in self.spells if item.enabled)

    def supports_class(self, class_name: str) -> bool:
        if not self.compatible_classes:
            return True
        token = str(class_name).strip().casefold()
        return bool(token) and token in {item.casefold() for item in self.compatible_classes}


class FightAISettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    max_actions_per_turn: int = Field(default=12, ge=1, le=100)
    decision_budget_seconds: float = Field(default=3.0, ge=0.1, le=5.0)
    verify_live_spell_slots: bool = False
    # If the client was already open before capture, the authoritative JVA spell
    # loadout may not be replayed.  When enabled, an exact configured profile
    # may bridge that startup gap until live JVA evidence arrives.  A live
    # mismatch always wins and fails closed.
    allow_profile_spell_bar_fallback: bool = False
    profiles: dict[str, CombatProfileSettings] = Field(default_factory=dict)

    def profile(self, account_id: str) -> CombatProfileSettings:
        key = str(account_id).strip()
        try:
            return self.profiles[key]
        except KeyError as exc:
            raise KeyError(f"no FightAI profile configured for account {key!r}") from exc


class RunBudgetSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    max_attempts: int = Field(default=5, ge=1)
    target_wins: int = Field(default=5, ge=1)
    stop_on_loss: bool = True
    stop_on_unknown: bool = True

    @model_validator(mode="after")
    def _validate_budget(self) -> "RunBudgetSettings":
        if self.target_wins > self.max_attempts:
            raise ValueError("target_wins cannot exceed max_attempts")
        return self


class RuntimeSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    data_directory: Path


class ActionTimingSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    confirmation_timeout_seconds: float = Field(default=5.0, gt=0, le=120)
    settlement_timeout_seconds: float = Field(default=3.0, ge=0, le=120)


def _default_action_timings() -> dict[str, ActionTimingSettings]:
    return {
        "change_map": ActionTimingSettings(confirmation_timeout_seconds=8.0, settlement_timeout_seconds=0.0),
        "bootstrap_change_map": ActionTimingSettings(confirmation_timeout_seconds=8.0, settlement_timeout_seconds=0.0),
        "launch_fight": ActionTimingSettings(confirmation_timeout_seconds=8.0, settlement_timeout_seconds=8.0),
        "join_fight": ActionTimingSettings(confirmation_timeout_seconds=8.0, settlement_timeout_seconds=0.0),
        "ready_fight": ActionTimingSettings(confirmation_timeout_seconds=8.0, settlement_timeout_seconds=0.0),
        "place_fighter": ActionTimingSettings(confirmation_timeout_seconds=5.0, settlement_timeout_seconds=0.0),
        "choose_challenge": ActionTimingSettings(confirmation_timeout_seconds=3.0, settlement_timeout_seconds=0.0),
        "cast_spell": ActionTimingSettings(confirmation_timeout_seconds=4.0, settlement_timeout_seconds=4.0),
        "move_fight": ActionTimingSettings(confirmation_timeout_seconds=4.0, settlement_timeout_seconds=4.0),
        "end_turn": ActionTimingSettings(confirmation_timeout_seconds=6.0, settlement_timeout_seconds=0.0),
        "world_move_to_cell": ActionTimingSettings(confirmation_timeout_seconds=5.0, settlement_timeout_seconds=0.0),
    }


class ExecutionSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    poll_interval_seconds: float = Field(default=0.1, gt=0, le=2)
    # World clicks are two-stage transactions: physical delivery first, then
    # certified Dofus request evidence. A retry is allowed only when the bounded
    # protocol trace proves the previous click emitted no certified request.
    world_interaction_semantic_grace_seconds: float = Field(default=1.25, ge=0.2, le=10.0)
    world_interaction_max_attempts: int = Field(default=3, ge=1, le=8)
    world_interaction_retry_backoff_seconds: float = Field(default=0.75, ge=0.0, le=10.0)
    actions: dict[str, ActionTimingSettings] = Field(default_factory=_default_action_timings)

    @field_validator("actions")
    @classmethod
    def _known_action_timing_keys(
        cls, value: dict[str, ActionTimingSettings]
    ) -> dict[str, ActionTimingSettings]:
        allowed = frozenset(_default_action_timings())
        unknown = sorted(str(key) for key in value if str(key) not in allowed)
        if unknown:
            raise ValueError(
                "unknown execution action timing key(s): " + ", ".join(unknown)
            )
        return value

    def profile(self, operation: str) -> ActionTimingSettings:
        key = str(operation)
        if key in self.actions:
            return self.actions[key]
        return _default_action_timings().get(key, ActionTimingSettings())

    def confirmation_polls(self, operation: str) -> int:
        import math
        return max(1, int(math.ceil(self.profile(operation).confirmation_timeout_seconds / self.poll_interval_seconds)))

    def settlement_polls(self, operation: str) -> int:
        import math
        seconds = self.profile(operation).settlement_timeout_seconds
        return max(0, int(math.ceil(seconds / self.poll_interval_seconds)))


class ReliabilitySettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    max_capture_age_seconds: float = Field(default=45.0, ge=5.0, le=300.0)
    max_message_age_seconds: float = Field(default=45.0, ge=5.0, le=300.0)
    max_canonical_age_seconds: float = Field(default=60.0, ge=5.0, le=600.0)
    script_rpc_timeout_seconds: float = Field(default=45.0, ge=1.0, le=120.0)
    mission_phase_timeout_seconds: float = Field(default=30.0, ge=5.0, le=300.0)
    # Temporary transport/live-truth loss is not gameplay progress. Parent campaign
    # watchdogs are suspended while all blockers are freshness-only, then released
    # only after a continuous healthy stabilization window.
    live_truth_recovery_stability_seconds: float = Field(default=2.0, ge=0.0, le=15.0)
    # Fight-only parent continuity warning. This is intentionally lower than the
    # physical-input freshness fence so a 44-45 s gameplay watchdog cannot expire
    # before connectivity loss is recognized and quarantined.
    live_truth_continuity_suspect_seconds: float = Field(default=30.0, ge=5.0, le=120.0)
    # R5.165 incident evidence: CRA's server->client game stream stalled for ~4.3 s
    # during READY while the account-wide capture clock remained fresh because
    # outgoing traffic still flowed.  This short threshold is applied only after
    # a Ready click has *proven* no outbound READY_REQUEST; it never gates the
    # first Ready interaction merely because preparation is quiet.
    ready_inbound_stall_suspect_seconds: float = Field(default=3.25, ge=1.0, le=15.0)
    # General short continuity gate while an account has a semantically pending
    # action/settlement. Quiet WORLD/idle periods are not affected.
    pending_action_inbound_stall_suspect_seconds: float = Field(default=5.0, ge=1.0, le=30.0)
    live_truth_continuity_hold_timeout_seconds: float = Field(default=600.0, ge=30.0, le=3600.0)
    pending_launch_stall_seconds: float = Field(default=20.0, ge=5.0, le=300.0)
    unresolved_flow_retry_seconds: float = Field(default=1.0, ge=0.1, le=30.0)
    # After a fight ends, canonical world state can become available before the
    # Unity/client interaction surface is genuinely stable. Require a continuous
    # exact-map projection-ready window before world actions are re-authorized.
    world_reentry_stability_seconds: float = Field(default=1.5, ge=0.0, le=15.0)
    world_reentry_timeout_seconds: float = Field(default=20.0, ge=2.0, le=120.0)
    # Fight preparation can become canonically complete slightly before the
    # client Ready control is actually interactive.  Keep this as a named
    # reliability contract rather than a composition-layer magic number.
    ready_control_settle_seconds: float = Field(default=1.0, ge=0.0, le=10.0)
    # R5.161 live evidence: R5.160 still missed CRA's first Ready interaction in
    # all 5/5 fights. Those first clicks occurred ~3.48-3.61 s after the final
    # placement confirmation and emitted no READY_REQUEST; ENU's first successful
    # Ready interactions occurred ~4.72-4.87 s after placement confirmation.
    # Preserve the historical
    # 1.0 s control-settle contract and raise only the explicit UI-quiescence
    # allowance. With normal arming/focus stabilization this moves the first click
    # beyond the observed non-interactive window without relying on blind retry.
    ready_ui_quiescence_seconds: float = Field(default=2.75, ge=0.0, le=10.0)
    # Ready is the first multi-account control that immediately follows placement.
    # Arm the target account window on a separate parent tick, then require a
    # short continuous foreground-stability interval before the Ready click.
    # This separates window activation from semantic game input and makes a
    # swallowed activation click impossible by construction.
    ready_focus_stability_seconds: float = Field(default=0.25, ge=0.0, le=5.0)
    # R5.162: before the first Ready click of a fight, move the pointer to the
    # verified Ready control and let the already-focused client observe a short
    # hover-only priming interval. This is not a blind extra click and the state
    # is re-authorized afterwards. It targets the repeated first-interaction
    # swallow seen even after >5 s post-placement waits.
    ready_first_interaction_prime_seconds: float = Field(default=0.35, ge=0.0, le=2.0)
    # If several semantically-proven swallowed Ready clicks remain after transport
    # is healthy, permit a very small number of additional attempts separated by
    # a no-input recovery interval. Blind retry is still forbidden whenever a
    # READY_REQUEST was observed or semantic evidence is unavailable.
    ready_recovery_extra_attempts: int = Field(default=2, ge=0, le=4)
    ready_recovery_cooldown_seconds: float = Field(default=3.0, ge=0.5, le=15.0)
    ready_recovery_pointer_excursion_pixels: int = Field(default=42, ge=0, le=120)


class CaptureSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    enabled: bool = True
    ports: tuple[int, ...] = (5555, 6337)
    interface: str | None = None
    captures_directory: Path = Path("runtime/captures")

    @field_validator("ports")
    @classmethod
    def _valid_ports(cls, values: tuple[int, ...]) -> tuple[int, ...]:
        normalized=[]
        for raw in values:
            value=int(raw)
            if not 1 <= value <= 65535:
                raise ValueError(f"invalid TCP port: {value}")
            if value not in normalized:
                normalized.append(value)
        if not normalized:
            raise ValueError("at least one capture port is required")
        return tuple(normalized)


class ProjectionSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    bridge_url: str = "http://127.0.0.1:8765"
    timeout_seconds: float = Field(default=0.75, gt=0, le=10)
    observe_timeout_seconds: float = Field(default=22.0, gt=0, le=60)
    sync_enabled: bool = True
    sync_interval_seconds: float = Field(default=0.35, gt=0, le=5)
    heartbeat_seconds: float = Field(default=10.0, gt=0, le=120)





class ScriptingSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    scripts_directory: Path = Path("scripts")
    runs_directory: Path = Path("runtime/script_runs")


class WebSettings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    host: str = "127.0.0.1"
    port: int = Field(default=8000, ge=1, le=65535)


class PlatformConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    config_schema_version: int = Field(default=1, ge=1)
    kernel: KernelSettings
    protocol: ProtocolSettings
    runtime: RuntimeSettings
    execution: ExecutionSettings = Field(default_factory=ExecutionSettings)
    web: WebSettings = Field(default_factory=WebSettings)
    projection: ProjectionSettings = Field(default_factory=ProjectionSettings)
    scripting: ScriptingSettings = Field(default_factory=ScriptingSettings)
    calibration: CalibrationSettings = Field(default_factory=CalibrationSettings)
    capture: CaptureSettings = Field(default_factory=CaptureSettings)
    reliability: ReliabilitySettings = Field(default_factory=ReliabilitySettings)
    party: PartySettings = Field(default_factory=PartySettings)
    patrol: PatrolSettings = Field(default_factory=PatrolSettings)
    run_budget: RunBudgetSettings = Field(default_factory=RunBudgetSettings)
    fight_ai: FightAISettings = Field(default_factory=FightAISettings)

    @field_validator("config_schema_version")
    @classmethod
    def _supported_config_schema(cls, value: int) -> int:
        if int(value) != 1:
            raise ValueError(
                f"unsupported config_schema_version={value}; this release supports schema 1"
            )
        return int(value)


    @model_validator(mode="after")
    def _validate_runtime_timeout_hierarchy(self) -> "PlatformConfig":
        rpc_timeout = float(self.reliability.script_rpc_timeout_seconds)
        if float(self.fight_ai.decision_budget_seconds) >= rpc_timeout:
            raise ValueError(
                "FightAI decision budget must be strictly smaller than script RPC timeout "
                f"({self.fight_ai.decision_budget_seconds}s >= {rpc_timeout}s)"
            )

        # Every production parent RPC performs at most one physical action, but
        # that action may legitimately spend its whole confirmation+settlement
        # budget before returning.  Reject configurations where the worker's
        # outer request deadline can fire first; such a configuration is not
        # executable even though each field is individually valid.
        poll = float(self.execution.poll_interval_seconds)
        rpc_margin = max(1.0, poll * 4.0)
        action_budgets = {}
        for name, profile in self.execution.actions.items():
            operation = str(name)
            confirmation = float(profile.confirmation_timeout_seconds)
            settlement = float(profile.settlement_timeout_seconds)
            if operation == "launch_fight":
                # launch_fight keeps the RPC open while it proves whether the
                # client emitted a semantic world request. That observation
                # window is max(confirmation, semantic_grace), followed by a
                # short protocol insertion-settle margin and canonical
                # settlement. Validate the real synchronous upper bound instead
                # of the old confirmation+settlement approximation.
                acceptance = max(
                    confirmation,
                    float(self.execution.world_interaction_semantic_grace_seconds),
                )
                protocol_settle = max(0.25, poll * 3.0)
                required = acceptance + protocol_settle + settlement + rpc_margin
            else:
                required = confirmation + settlement + rpc_margin
            action_budgets[operation] = required
        if action_budgets:
            operation, required = max(action_budgets.items(), key=lambda item: item[1])
            if required >= rpc_timeout:
                raise ValueError(
                    "Script RPC timeout must exceed every synchronous execution action budget "
                    f"with polling margin; {operation} requires > {required:.3f}s but "
                    f"script_rpc_timeout_seconds={rpc_timeout:.3f}s"
                )
        return self

def _absolute_path(base: Path, value: Any) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = base / candidate
    return candidate.resolve()


def load_platform_config(path: str | Path) -> PlatformConfig:
    config_path = Path(path).expanduser().resolve()
    if not config_path.exists():
        raise PlatformConfigError(f"Platform config does not exist: {config_path}")
    if not config_path.is_file():
        raise PlatformConfigError(f"Platform config is not a file: {config_path}")

    try:
        raw = yaml.load(
            config_path.read_text(encoding="utf-8"),
            Loader=_UniqueKeySafeLoader,
        )
    except (OSError, yaml.YAMLError) as exc:
        raise PlatformConfigError(f"Unable to read platform config {config_path}: {exc}") from exc

    if not isinstance(raw, dict):
        raise PlatformConfigError("Platform config root must be a mapping")

    normalized = dict(raw)
    base = config_path.parent
    kernel = dict(normalized.get("kernel") or {})
    runtime = dict(normalized.get("runtime") or {})
    scripting = dict(normalized.get("scripting") or {})
    capture = dict(normalized.get("capture") or {})
    if "static_directory" in kernel:
        kernel["static_directory"] = _absolute_path(base, kernel["static_directory"])
    if "mapuse_directory" in kernel:
        kernel["mapuse_directory"] = _absolute_path(base, kernel["mapuse_directory"])
    if "maps_directory" in kernel and kernel["maps_directory"] is not None:
        kernel["maps_directory"] = _absolute_path(base, kernel["maps_directory"])
    if "data_directory" in runtime:
        runtime["data_directory"] = _absolute_path(base, runtime["data_directory"])
    normalized["kernel"] = kernel
    for key in ("scripts_directory", "runs_directory"):
        if key in scripting:
            scripting[key] = _absolute_path(base, scripting[key])
    if "captures_directory" in capture:
        capture["captures_directory"] = _absolute_path(base, capture["captures_directory"])
    elif "data_directory" in runtime:
        capture["captures_directory"] = Path(runtime["data_directory"]) / "captures"
    normalized["runtime"] = runtime
    normalized["scripting"] = scripting
    normalized["capture"] = capture

    try:
        return PlatformConfig.model_validate(normalized)
    except ValidationError as exc:
        raise PlatformConfigError(f"Invalid platform config: {exc}") from exc

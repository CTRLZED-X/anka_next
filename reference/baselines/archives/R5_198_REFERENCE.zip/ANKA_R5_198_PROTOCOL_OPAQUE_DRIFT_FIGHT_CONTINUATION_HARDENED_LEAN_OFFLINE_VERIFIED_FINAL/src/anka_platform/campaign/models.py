from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class CampaignActionTransaction:
    """One parent-observed runtime action in campaign context.

    This is intentionally diagnostic/control-plane state, not an execution
    authority. Execution owns physical input; the campaign records the resulting
    semantic disposition so one place can explain why the mission is waiting,
    retrying, continuing, or terminating.
    """

    sequence: int
    operation: str
    account_id: str | None
    status: str
    failure_code: str | None
    detail: str | None
    action_id: str | None
    transaction_id: str | None
    origin_action_id: str | None
    request_id: str | None
    run_id: str | None
    target: dict[str, Any]
    attempt_index: int | None
    retry_allowed: bool | None
    retry_after_seconds: float | None
    semantic_request_state: str | None
    semantic_request_kind: str | None
    first_missing_boundary: str | None
    likely_owner: str | None
    observed_monotonic: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CampaignWorkflowTransition:
    """One parent-observed world/fight lifecycle transition.

    Workflow state is diagnostic/control-plane truth only. It does not authorize
    physical input; Execution remains the sole physical authority. Keeping this
    record in the parent campaign makes one run explainable without reconstructing
    lifecycle ordering from worker log strings.
    """

    sequence: int
    domain: str
    state: str
    reason: str | None
    action_status: str | None
    failure_code: str | None
    first_missing_boundary: str | None
    likely_owner: str | None
    account_id: str | None
    progress_token: str | None
    next_allowed_commands: tuple[str, ...]
    run_id: str | None
    request_id: str | None
    observed_monotonic: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CampaignRecoveryObligation:
    """A campaign-visible safe-recovery obligation.

    Execution remains the authority that decides whether another physical input
    is safe.  The campaign only records *that* a retryable transaction exists,
    what target it belongs to, and whether a later observation actually closes
    that obligation.  This prevents ``RETRYABLE`` from disappearing into a log
    line while the worker/campaign continues with unrelated work.
    """

    recovery_key: str
    operation: str
    account_id: str | None
    target: dict[str, Any]
    opened_sequence: int
    opened_monotonic: float
    updated_sequence: int
    updated_monotonic: float
    originating_transaction_id: str | None
    originating_action_id: str | None
    latest_transaction_id: str | None
    latest_action_id: str | None
    attempt_index: int | None
    retry_after_seconds: float | None
    retry_not_before_monotonic_ms: int | None
    first_missing_boundary: str | None
    likely_owner: str | None
    state: str
    resolution_status: str | None = None
    resolution_failure_code: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

from __future__ import annotations

from collections import deque
import inspect
import time
from typing import Callable

from anka_platform.campaign.disposition import workflow_terminal_failure_code
from anka_platform.campaign.continuity import CampaignContinuityGuard, ContinuityState
from anka_platform.party.coordinator import FightOutcome
from anka_platform.party.startup_policy import classify_for_bootstrap
from anka_platform.core.fight.lifecycle import FightGenerationLifecycleStatus, FightPartialClassification


class FightGenerationAuthorityError(RuntimeError):
    """Raised when the production fight-lifecycle authority exists but fails."""


class CampaignRuntimeController:
    """Parent-owned world <-> fight <-> outcome lifecycle coordinator.

    This class intentionally composes existing proven owners instead of replacing
    them: WorldWorkflow owns world decisions, FightWorkflow owns fight lifecycle,
    PartyMissionController owns campaign budget/synchronization, and Execution
    remains the sole physical-input authority.  The controller's job is to make
    the *transition between those owners* single-source and generation-scoped so
    the worker cannot maintain a second campaign state machine.
    """

    def __init__(
        self,
        *,
        party,
        mission,
        world_workflow,
        fight_workflow,
        outcome_resolver: Callable[[dict, dict], dict],
        startup_bootstrap_provider: Callable[[], object | None] | None = None,
        clock: Callable[[], float] = time.monotonic,
        history_limit: int = 128,
        continuity_recovery_stability_seconds: float = 2.0,
        continuity_suspect_seconds: float = 30.0,
        ready_inbound_stall_suspect_seconds: float = 3.25,
        pending_action_inbound_stall_suspect_seconds: float = 5.0,
        continuity_hold_timeout_seconds: float = 600.0,
    ) -> None:
        self.party = party
        self.mission = mission
        self.world_workflow = world_workflow
        self.fight_workflow = fight_workflow
        self.outcome_resolver = outcome_resolver
        self.startup_bootstrap_provider = startup_bootstrap_provider
        self.clock = clock
        self._history_limit = max(16, int(history_limit))
        self._runtime_step_sequence = 0
        self._recent_steps = deque(maxlen=self._history_limit)
        self._last_step: dict | None = None
        self._observed_fight_instance_id: int | None = None
        self._last_committed_fight_instance_id: int | None = None
        self._fight_evidence: dict[str, object] = {}
        self._terminal_failure: dict | None = None
        self._observability_errors = deque(maxlen=32)
        self._observation_frame_sequence = 0
        self._recent_observation_frames = deque(maxlen=self._history_limit)
        self._last_observation_frame: dict | None = None
        self._first_invariant_violation: dict | None = None
        self._active_fight_generations = deque(maxlen=64)
        # Compact authoritative fight-accounting history survives high-frequency
        # runtime polling.  R5.163's final debug retained only the last 128
        # campaign steps, which were all repeated fifth-launch denials and hid
        # the four successfully committed fights.
        self._fight_outcome_history = deque(maxlen=64)
        # Exact generation that has crossed the ACTIVE authorization boundary.
        # Unlike the historical deque above, this latch is current-generation
        # state and is cleared only after terminal outcome commit/reset. It is
        # the authority for distinguishing initial partial entry from normal
        # asynchronous post-fight partial exit.
        self._active_observed_fight_instance_id: int | None = None
        self._continuity_suspect_seconds = max(0.0, float(continuity_suspect_seconds))
        self._ready_inbound_stall_suspect_seconds = max(0.0, float(ready_inbound_stall_suspect_seconds))
        self._pending_action_inbound_stall_suspect_seconds = max(0.0, float(pending_action_inbound_stall_suspect_seconds))
        self._last_runtime_health: dict[str, dict] = {}
        self._continuity_history = deque(maxlen=64)
        self._last_continuity_fingerprint: tuple | None = None
        self._continuity = CampaignContinuityGuard(
            recovery_stability_seconds=float(continuity_recovery_stability_seconds),
            hold_timeout_seconds=float(continuity_hold_timeout_seconds),
            clock=clock,
        )

    def reset(self) -> None:
        self._runtime_step_sequence = 0
        self._recent_steps.clear()
        self._last_step = None
        self._observed_fight_instance_id = None
        self._last_committed_fight_instance_id = None
        self._fight_evidence.clear()
        self._terminal_failure = None
        self._observability_errors.clear()
        self._observation_frame_sequence = 0
        self._recent_observation_frames.clear()
        self._last_observation_frame = None
        self._first_invariant_violation = None
        self._active_fight_generations.clear()
        self._fight_outcome_history.clear()
        self._active_observed_fight_instance_id = None
        self._last_runtime_health = {}
        self._continuity_history.clear()
        self._last_continuity_fingerprint = None
        self._continuity.reset()
        self._set_campaign_watchdog_hold(False, reason="CAMPAIGN_RESET", context={})
        for owner in (self.world_workflow, self.fight_workflow):
            reset = getattr(owner, "reset", None)
            if callable(reset):
                reset()

    @staticmethod
    def _generation_failure_code(exc: BaseException) -> str | None:
        text = str(exc or "").strip()
        known = (
            "GENERATION_CHANGED_DURING_SESSION",
            "PARTY_GENERATION_CHANGED",
            "PARTY_GENERATION_BLOCKED",
            "PARTY_RUNTIME_NOT_READY",
            "PARTY_GENERATION_INVALIDATED",
            "WINDOW_IDENTITY_VERIFY_TIMEOUT",
            "PARTY_WINDOW_IDENTITY_VERIFY_TIMEOUT",
        )
        for code in known:
            if code in text:
                return code
        return None

    def _party_runtime_status(self) -> dict | None:
        manager = getattr(self.party, "manager", None)
        status = getattr(manager, "status", None)
        if not callable(status):
            return None
        try:
            raw = status()
        except Exception as exc:
            return {"ready": False, "status_error": f"{type(exc).__name__}: {exc}"}
        return dict(raw or {}) if isinstance(raw, dict) else None

    def _required_lanes(self):
        return tuple(lane for lane in self.party.lanes if lane.required)

    def _snapshots(self) -> dict[str, object]:
        return {str(lane.account_id): lane.snapshot() for lane in self._required_lanes()}

    @staticmethod
    def _directional_inbound_stall(inbound: dict, threshold_seconds: float) -> tuple[bool, dict]:
        """Classify directional silence without overreacting to TCP reordering.

        A decoder reassembly gap can exist briefly while fresh segments/messages
        continue to arrive.  Treating that boolean alone as an outage caused many
        sub-second false HOLDs in the successful R5.165 five-fight run.  A gap is
        therefore continuity-relevant only when contiguous progress itself has
        remained stale for a material fraction of the semantic-stall threshold.
        """
        threshold = max(0.0, float(threshold_seconds))
        message_age = inbound.get("last_message_age_seconds")
        contiguous_age = inbound.get("last_contiguous_age_seconds")
        try:
            message_stale = message_age is not None and float(message_age) > threshold
        except (TypeError, ValueError):
            message_stale = False
        # Keep a bounded early warning for a *persistent* reassembly gap, but do
        # not freeze on ordinary packet reordering.  Half the semantic threshold
        # preserves earlier detection while remaining evidence-driven.
        gap_threshold = max(1.0, threshold * 0.5)
        try:
            gap_persistent = bool(inbound.get("reassembly_stalled")) and contiguous_age is not None and float(contiguous_age) > gap_threshold
        except (TypeError, ValueError):
            gap_persistent = False
        return bool(message_stale or gap_persistent), {
            "message_stale": bool(message_stale),
            "persistent_reassembly_gap": bool(gap_persistent),
            "reassembly_gap_threshold_seconds": float(gap_threshold),
        }

    def _required_runtime_health(self, lanes=None) -> dict[str, dict]:
        """Collect passive health without granting physical-input authority.

        Legacy/narrow test lanes without a health fence are omitted. Production
        required lanes expose RuntimeHealthFence.assess_passive().
        """
        result: dict[str, dict] = {}
        mission_status = self._mission_status()
        preparation = mission_status.get("preparation") if isinstance(mission_status.get("preparation"), dict) else {}
        preparation_stage = str(preparation.get("stage") or "")
        ready_attempts = preparation.get("ready_attempts") if isinstance(preparation.get("ready_attempts"), dict) else {}
        legacy_latest_action = mission_status.get("latest_action_transaction") if isinstance(mission_status.get("latest_action_transaction"), dict) else {}
        for lane in tuple(lanes or self._required_lanes()):
            health = getattr(lane, "health", None)
            assess = getattr(health, "assess_passive", None)
            if not callable(assess):
                continue
            account_id = str(getattr(lane, "account_id", "unknown"))
            try:
                payload = assess()
                if isinstance(payload, dict):
                    normalized = dict(payload)
                    # The incident-derived early continuity gate is fight-only.
                    # World idleness may legitimately have long quiet periods, but
                    # a required fight client going silent for ~30 s must suspend
                    # parent progress before a 44-45 s fight watchdog can expire.
                    fight_context = bool(
                        self._observed_fight_instance_id is not None
                        or (self._last_step is not None and str(self._last_step.get("domain") or "") == "FIGHT")
                    )
                    if fight_context and self._continuity_suspect_seconds > 0.0:
                        blockers = list(normalized.get("blockers") or ())
                        capture = normalized.get("capture") if isinstance(normalized.get("capture"), dict) else {}
                        canonical = normalized.get("canonical") if isinstance(normalized.get("canonical"), dict) else {}
                        message_age = capture.get("computed_message_age_seconds", capture.get("last_message_age_seconds"))
                        canonical_age = canonical.get("computed_age_seconds", canonical.get("last_event_age_seconds"))
                        try:
                            if message_age is not None and float(message_age) > self._continuity_suspect_seconds:
                                blockers.append("PROTOCOL_MESSAGES_CONTINUITY_SUSPECT")
                        except (TypeError, ValueError):
                            pass
                        try:
                            if canonical_age is not None and float(canonical_age) > self._continuity_suspect_seconds:
                                blockers.append("CANONICAL_STATE_CONTINUITY_SUSPECT")
                        except (TypeError, ValueError):
                            pass
                        normalized["blockers"] = list(dict.fromkeys(str(item) for item in blockers))

                    # R5.165: after a Ready click is *semantically proven absent*,
                    # distinguish a per-client inbound gameplay-stream stall from a
                    # normal swallowed UI click. Account-wide message freshness is
                    # insufficient because outgoing keepalives can remain active while
                    # server->client live truth is delayed. This short gate is never
                    # applied before the first Ready attempt, so ordinary quiet UI
                    # stabilization cannot deadlock preparation.
                    ready_attempt = ready_attempts.get(account_id) if isinstance(ready_attempts, dict) else None
                    ready_missing_request = bool(
                        preparation_stage.startswith("READY")
                        and isinstance(ready_attempt, dict)
                        and int(ready_attempt.get("count") or 0) > 0
                        and ready_attempt.get("semantic_request_observed") is False
                        and bool(ready_attempt.get("retry_allowed", False))
                    )
                    if ready_missing_request and self._ready_inbound_stall_suspect_seconds > 0.0:
                        capture = normalized.get("capture") if isinstance(normalized.get("capture"), dict) else {}
                        directional = capture.get("primary_directional_flows") if isinstance(capture.get("primary_directional_flows"), dict) else {}
                        inbound = directional.get("server_to_client") if isinstance(directional.get("server_to_client"), dict) else {}
                        ready_stalled, stall_basis = self._directional_inbound_stall(
                            inbound, self._ready_inbound_stall_suspect_seconds
                        )
                        if ready_stalled:
                            blockers = list(normalized.get("blockers") or ())
                            blockers.append("SERVER_TO_CLIENT_READY_STALL")
                            normalized["blockers"] = list(dict.fromkeys(str(item) for item in blockers))
                            normalized["ready_transport_gate"] = {
                                "triggered": True,
                                "mode": "REQUEST_ABSENT_RETRY_WAIT",
                                "threshold_seconds": float(self._ready_inbound_stall_suspect_seconds),
                                "server_to_client": dict(inbound),
                                "stall_basis": stall_basis,
                                "attempt_count": int(ready_attempt.get("count") or 0),
                                "semantic_request_observed": False,
                                "retry_allowed": True,
                            }

                    # If READY_REQUEST was sent but the local ready acknowledgement
                    # is still pending, that wait is also directionally dependent
                    # on fresh server truth.  A temporary inbound stall must pause
                    # preparation rather than consuming the Ready ACK timeout.
                    ready_ack_waiting = bool(
                        preparation_stage.startswith("READY")
                        and isinstance(ready_attempt, dict)
                        and int(ready_attempt.get("count") or 0) > 0
                        and bool(ready_attempt.get("ready_ack_pending", False))
                        and not bool(ready_attempt.get("retry_allowed", False))
                    )
                    if ready_ack_waiting and self._ready_inbound_stall_suspect_seconds > 0.0:
                        capture = normalized.get("capture") if isinstance(normalized.get("capture"), dict) else {}
                        directional = capture.get("primary_directional_flows") if isinstance(capture.get("primary_directional_flows"), dict) else {}
                        inbound = directional.get("server_to_client") if isinstance(directional.get("server_to_client"), dict) else {}
                        ack_stalled, stall_basis = self._directional_inbound_stall(
                            inbound, self._ready_inbound_stall_suspect_seconds
                        )
                        if ack_stalled:
                            blockers = list(normalized.get("blockers") or ())
                            blockers.append("SERVER_TO_CLIENT_READY_ACK_STALL")
                            normalized["blockers"] = list(dict.fromkeys(str(item) for item in blockers))
                            normalized["ready_transport_gate"] = {
                                "triggered": True,
                                "mode": "ACK_PENDING",
                                "threshold_seconds": float(self._ready_inbound_stall_suspect_seconds),
                                "server_to_client": dict(inbound),
                                "stall_basis": stall_basis,
                                "attempt_count": int(ready_attempt.get("count") or 0),
                                "semantic_request_observed": ready_attempt.get("semantic_request_observed"),
                                "retry_allowed": False,
                                "ready_ack_pending": True,
                            }

                    # General pending-action continuity: if this exact account is
                    # waiting on a *currently unresolved* execution result and its primary
                    # server->client gameplay flow goes quiet, pause the parent
                    # before action-specific retry/watchdog logic can fail.  Never
                    # use CampaignEngine.latest_action_transaction here: that is
                    # historical telemetry and can remain SENT long after the
                    # transaction has settled (R5.165 live run: old ENU Ready was
                    # still the latest campaign action deep into combat, creating
                    # false continuity HOLD episodes).
                    pending_execution: dict = {}
                    execution_service = getattr(lane, "execution", None)
                    pending_reader = getattr(execution_service, "continuity_pending_status", None)
                    if callable(pending_reader):
                        try:
                            candidate = pending_reader()
                            if isinstance(candidate, dict):
                                pending_execution = dict(candidate)
                        except Exception as exc:
                            # This accessor participates in continuity authority:
                            # if it cannot tell whether a physical transaction is
                            # unresolved, the parent must not guess that the lane
                            # is safe to advance through a transport stall.
                            normalized["continuity_pending_status_error"] = f"{type(exc).__name__}: {exc}"
                            blockers = list(normalized.get("blockers") or ())
                            blockers.append("CONTINUITY_PENDING_STATUS_UNAVAILABLE")
                            normalized["blockers"] = list(dict.fromkeys(str(item) for item in blockers))
                    elif execution_service is None:
                        # Compatibility for narrow/legacy façades that predate
                        # ExecutionService ownership. Production PartyLane objects
                        # always expose execution and therefore never take this
                        # historical fallback (which caused the R5.165 false HOLDs).
                        legacy_status = str(legacy_latest_action.get("status") or "").upper()
                        if (
                            str(legacy_latest_action.get("account_id") or "") == account_id
                            and legacy_status in {"PENDING", "SENT", "IN_PROGRESS", "RECONCILING", "CONFIRMED_UNSETTLED", "WAIT"}
                        ):
                            pending_execution = {
                                "active": True,
                                "status": legacy_status,
                                "kind": legacy_latest_action.get("operation"),
                                "origin_action_id": legacy_latest_action.get("action_id"),
                                "attempt_index": legacy_latest_action.get("attempt_index"),
                                "requires_server_to_client_truth": True,
                                "authority": "LEGACY_TEST_FACADE_HISTORY_FALLBACK",
                            }
                    if pending_execution:
                        normalized["active_execution_obligation"] = dict(pending_execution)
                    pending_for_account = bool(
                        pending_execution.get("active") is True
                        and pending_execution.get("requires_server_to_client_truth") is not False
                    )
                    if pending_for_account and self._pending_action_inbound_stall_suspect_seconds > 0.0:
                        capture = normalized.get("capture") if isinstance(normalized.get("capture"), dict) else {}
                        directional = capture.get("primary_directional_flows") if isinstance(capture.get("primary_directional_flows"), dict) else {}
                        inbound = directional.get("server_to_client") if isinstance(directional.get("server_to_client"), dict) else {}
                        pending_stalled, stall_basis = self._directional_inbound_stall(
                            inbound, self._pending_action_inbound_stall_suspect_seconds
                        )
                        if pending_stalled:
                            blockers = list(normalized.get("blockers") or ())
                            blockers.append("SERVER_TO_CLIENT_ACTION_STALL")
                            normalized["blockers"] = list(dict.fromkeys(str(item) for item in blockers))
                            normalized["pending_action_transport_gate"] = {
                                "triggered": True,
                                "threshold_seconds": float(self._pending_action_inbound_stall_suspect_seconds),
                                "server_to_client": dict(inbound),
                                "stall_basis": stall_basis,
                                "active_execution_obligation": dict(pending_execution),
                                # Compatibility projection for R5.165 readers.
                                # Production authority is the active obligation
                                # above; this field is diagnostic only.
                                "latest_action": {
                                    "operation": pending_execution.get("kind"),
                                    "status": pending_execution.get("status"),
                                    "action_id": pending_execution.get("origin_action_id"),
                                    "attempt_index": pending_execution.get("attempt_index"),
                                },
                            }
                    result[account_id] = normalized
                else:
                    result[account_id] = {
                        "status": "BLOCKED",
                        "blockers": ["RUNTIME_HEALTH_INVALID"],
                        "detail": f"passive health returned {type(payload).__name__}",
                    }
            except Exception as exc:
                result[account_id] = {
                    "status": "BLOCKED",
                    "blockers": ["RUNTIME_HEALTH_UNAVAILABLE"],
                    "detail": f"{type(exc).__name__}: {exc}",
                }
        return result

    def _set_campaign_watchdog_hold(
        self, active: bool, *, reason: str, context: dict | None = None
    ) -> dict | None:
        setter = getattr(self.mission, "set_watchdog_hold", None)
        if not callable(setter):
            campaign = getattr(self.mission, "campaign", None)
            setter = getattr(campaign, "set_watchdog_hold", None)
        if not callable(setter):
            return None
        try:
            return dict(setter(bool(active), reason=reason, context=dict(context or {})) or {})
        except Exception as exc:
            self._observability_errors.append({
                "stage": "CAMPAIGN_WATCHDOG_HOLD",
                "error": f"{type(exc).__name__}: {exc}",
                "observed_monotonic": float(self.clock()),
            })
            return None

    def _record_continuity_health(self, assessment, health: dict[str, dict]) -> None:
        self._last_runtime_health = {str(k): dict(v) for k, v in dict(health or {}).items()}
        fingerprint = (
            str(getattr(assessment.state, "value", assessment.state)),
            tuple(assessment.affected_accounts),
            tuple(assessment.transient_blockers),
            tuple(assessment.hard_blockers),
        )
        if fingerprint == self._last_continuity_fingerprint:
            return
        accounts: dict[str, dict] = {}
        for account_id, raw in self._last_runtime_health.items():
            capture = raw.get("capture") if isinstance(raw.get("capture"), dict) else {}
            directional = capture.get("primary_directional_flows") if isinstance(capture.get("primary_directional_flows"), dict) else {}
            accounts[str(account_id)] = {
                "blockers": list(raw.get("blockers") or ()),
                "ready_transport_gate": raw.get("ready_transport_gate"),
                "pending_action_transport_gate": raw.get("pending_action_transport_gate"),
                "active_execution_obligation": raw.get("active_execution_obligation"),
                "primary_directional_flows": {
                    key: dict(value) for key, value in directional.items() if isinstance(value, dict)
                },
            }
        self._continuity_history.append({
            "observed_monotonic": float(self.clock()),
            "assessment": assessment.to_dict(),
            "accounts": accounts,
        })
        self._last_continuity_fingerprint = fingerprint

    def _continuity_step(
        self, lanes, *, runtime_context: dict | None = None, health_override: dict[str, dict] | None = None
    ) -> dict | None:
        health = dict(health_override) if health_override is not None else self._required_runtime_health(lanes)
        # Compatibility/test façades without health fences retain historical
        # behavior. Production required lanes always provide health.
        if not health:
            return None
        assessment = self._continuity.assess(health)
        self._record_continuity_health(assessment, health)
        detail = assessment.to_dict()
        state = assessment.state
        if state in {ContinuityState.HOLDING, ContinuityState.RECOVERING}:
            hold = self._set_campaign_watchdog_hold(
                True, reason=assessment.reason, context={"continuity": detail}
            )
            return {
                "domain": "CONTINUITY",
                "state": "HOLD" if state is ContinuityState.HOLDING else "RECOVERING",
                "reason": assessment.reason,
                "action": {
                    "status": "WAIT",
                    "physical_input_sent": False,
                    "first_missing_boundary": "LIVE_TRUTH_CONTINUITY",
                    "likely_owner": "NETWORK_OR_LIVE_TRANSPORT",
                    "affected_accounts": list(assessment.affected_accounts),
                    "blockers_by_account": {k: list(v) for k, v in assessment.blockers_by_account.items()},
                    "continuity": detail,
                    "campaign_watchdog_hold": hold,
                },
                "next_allowed_commands": ["OBSERVE_RUNTIME_HEALTH"],
            }
        if state is ContinuityState.TIMEOUT:
            self._set_campaign_watchdog_hold(
                True, reason=assessment.reason, context={"continuity": detail}
            )
            return self._runtime_failure(
                failure_code="LIVE_TRUTH_CONTINUITY_TIMEOUT",
                detail=(
                    "required live truth remained stale beyond the configured continuity hold timeout; "
                    "no new physical input was authorized during the outage"
                ),
                first_missing_boundary="LIVE_TRUTH_CONTINUITY",
                likely_owner="NETWORK_OR_LIVE_TRANSPORT",
                runtime_context=runtime_context,
                continuity=detail,
            )
        if state is ContinuityState.HARD_BLOCK:
            # End any prior transient hold before surfacing a genuine runtime
            # health fault. Hard faults must not masquerade as connectivity.
            self._set_campaign_watchdog_hold(
                False, reason="LIVE_TRUTH_HARD_BLOCK", context={"continuity": detail}
            )
            return self._runtime_failure(
                failure_code="LIVE_TRUTH_RUNTIME_HEALTH_BLOCKED",
                detail="required runtime health has a non-transient blocker",
                first_missing_boundary="LIVE_TRUTH_RUNTIME_HEALTH",
                likely_owner="RUNTIME_HEALTH_OR_PROTOCOL",
                runtime_context=runtime_context,
                continuity=detail,
            )
        # HEALTHY is reached only after the configured recovery-stability window.
        self._set_campaign_watchdog_hold(
            False, reason="LIVE_TRUTH_RECOVERED", context={"continuity": detail}
        )
        return None


    def _bootstrap_health_gate(self, lanes) -> tuple[bool, dict[str, dict], dict]:
        """Allow the launched-run bootstrap only through the startup policy.

        Normal continuity quite correctly treats a missing current-session
        Canonical baseline as a hard blocker.  The world bootstrap is the one
        operation whose job is to create that baseline, so its first tick must
        be evaluated against the narrower startup blocker registry instead of
        ordinary steady-state continuity.  Unknown/new blockers still fail
        closed; protocol/capture/identity faults are never relaxed here.
        """
        health = self._required_runtime_health(lanes)
        if not health:
            return True, health, {"status": "LEGACY_NO_HEALTH", "blocking": [], "expected": []}
        expected: list[str] = []
        blocking: list[str] = []
        by_account: dict[str, dict] = {}
        for account_id, raw in health.items():
            current = dict(raw or {})
            blockers = [str(item) for item in (current.get("blockers") or ()) if str(item)]
            capture = current.get("capture") if isinstance(current.get("capture"), dict) else {}
            if bool(capture.get("protocol_context_failure_active")):
                blockers.append("PROTOCOL_CONTEXT_FAILURE_ACTIVE")
            if bool(capture.get("canonical_state_failure_active")):
                blockers.append("CANONICAL_STATE_FAILURE_ACTIVE")
            if capture.get("last_error"):
                blockers.append("PROTOCOL_TRANSFORM_ACTIVE")
            if bool(capture.get("protocol_unclassified_active")) or int(capture.get("unclassified_count") or 0) > 0:
                blockers.append("PROTOCOL_UNCLASSIFIED_ACTIVE")
            blockers = list(dict.fromkeys(blockers))
            policy = classify_for_bootstrap(blockers)
            account_expected = [str(item) for item in policy.get("expected") or ()]
            account_blocking = [str(item) for item in policy.get("blocking") or ()]
            expected.extend(f"{account_id}:{item}" for item in account_expected)
            blocking.extend(f"{account_id}:{item}" for item in account_blocking)
            status = str(current.get("status") or "UNKNOWN").upper()
            if status not in {"READY", "BLOCKED"}:
                blocking.append(f"{account_id}:RUNTIME_HEALTH_UNAVAILABLE")
            by_account[str(account_id)] = {
                "status": status,
                "blockers": blockers,
                "startup_expected": account_expected,
                "startup_blocking": account_blocking,
            }
        detail = {
            "status": "READY" if not blocking else "BLOCKED",
            "expected": list(dict.fromkeys(expected)),
            "blocking": list(dict.fromkeys(blocking)),
            "accounts": by_account,
        }
        return not blocking, health, detail

    @staticmethod
    def _semantic_value(value) -> dict:
        if value is None:
            return {"status": "MISSING", "value": None}
        status = getattr(value, "status", None)
        raw = getattr(value, "value", None)
        return {
            "status": str(getattr(status, "value", status) or "UNKNOWN"),
            "value": raw,
        }

    def _preparation_complete_for(self, fight_instance_id: int | None) -> bool:
        """Return exact-generation preparation proof when the mission exposes it.

        ACTIVE observation is the strongest normal settlement latch, but a very
        fast terminal transition can begin after the Ready barrier is complete
        and before the parent records its first ACTIVE child state. Exact
        preparation completion is therefore also sufficient to classify a
        same-generation partial disappearance as post-fight exit skew.
        """
        if fight_instance_id is None:
            return False
        exact = getattr(self.mission, "preparation_complete_for", None)
        if not callable(exact):
            return False
        try:
            return bool(exact(int(fight_instance_id)))
        except Exception:
            return False

    def _fight_generation_authority(self, fight_instance_id: int | None) -> FightGenerationLifecycleStatus:
        """Consume FightWorkflow's lifecycle authority without reclassifying it.

        The mapping adapter is compatibility-only for historical test façades. The
        production FightWorkflow returns the typed core contract.
        """
        status = getattr(self.fight_workflow, "lifecycle_generation_status", None)
        if callable(status):
            try:
                value = status(fight_instance_id)
                if isinstance(value, FightGenerationLifecycleStatus):
                    return value
                if isinstance(value, dict):
                    return FightGenerationLifecycleStatus.from_mapping(value)
            except Exception as exc:
                raise FightGenerationAuthorityError(
                    "FightWorkflow lifecycle authority raised while classifying "
                    f"fight_instance_id={fight_instance_id}: {type(exc).__name__}: {exc}"
                ) from exc
            raise FightGenerationAuthorityError(
                "FightWorkflow lifecycle authority returned an unsupported result "
                f"for fight_instance_id={fight_instance_id}: {type(value).__name__}"
            )
        # Compatibility only: preserve old behavior for narrow legacy façades.
        active_latched = bool(
            fight_instance_id is not None
            and self._active_observed_fight_instance_id is not None
            and int(fight_instance_id) == int(self._active_observed_fight_instance_id)
        )
        preparation_complete = self._preparation_complete_for(fight_instance_id)
        post_entry = bool(active_latched or preparation_complete)
        return FightGenerationLifecycleStatus(
            fight_instance_id=fight_instance_id,
            preparation_complete=preparation_complete,
            active_latched=active_latched,
            post_entry_authorized=post_entry,
            partial_classification=(
                FightPartialClassification.EXIT_SETTLING
                if post_entry else FightPartialClassification.ENTRY_JOINING
            ),
        )

    @staticmethod
    def _callable_accepts_keyword(callable_obj, keyword: str) -> bool:
        """Inspect compatibility without executing and swallowing user code."""
        try:
            signature = inspect.signature(callable_obj)
        except (TypeError, ValueError):
            return True
        if any(
            parameter.kind is inspect.Parameter.VAR_KEYWORD
            for parameter in signature.parameters.values()
        ):
            return True
        parameter = signature.parameters.get(str(keyword))
        return parameter is not None and parameter.kind in {
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        }

    def _capture_observation_frame(
        self, snapshots: dict[str, object], mission_status: dict
    ) -> dict:
        self._observation_frame_sequence += 1
        accounts = {}
        present_accounts = []
        fight_ids = set()
        for account_id, snapshot in snapshots.items():
            fight = getattr(snapshot, "fight", None)
            world = getattr(snapshot, "world", None)
            present = bool(getattr(fight, "present", False))
            fight_id = getattr(fight, "fight_instance_id", None) if present else None
            if present:
                present_accounts.append(str(account_id))
                if fight_id is not None:
                    fight_ids.add(int(fight_id))
            accounts[str(account_id)] = {
                "revision": int(getattr(snapshot, "revision", 0) or 0),
                "world_map": self._semantic_value(getattr(world, "map_id", None)),
                "fight_present": present,
                "fight_instance_id": (int(fight_id) if fight_id is not None else None),
                "fight_phase": self._semantic_value(getattr(fight, "phase", None)),
                "active_actor_id": self._semantic_value(getattr(fight, "active_actor_id", None)),
                "round": self._semantic_value(getattr(fight, "round", None)),
                "turn_index": self._semantic_value(getattr(fight, "turn_index", None)),
                "local_player_actor_id": self._semantic_value(
                    getattr(snapshot, "local_player_actor_id", None)
                ),
            }
        pending = mission_status.get("active_launch_transaction")
        receipt = mission_status.get("active_launch_reference")
        required_count = len(snapshots)
        if len(fight_ids) > 1:
            phase = "FIGHT_GENERATION_CONFLICT"
        elif present_accounts and len(present_accounts) < required_count:
            only_fight = next(iter(fight_ids)) if len(fight_ids) == 1 else None
            lifecycle = self._fight_generation_authority(only_fight)
            phase = (
                "POST_FIGHT_PARTIAL_EXIT"
                if only_fight is not None and lifecycle.partial_classification is FightPartialClassification.EXIT_SETTLING
                else "PARTIAL_FIGHT_ENTRY"
            )
        elif present_accounts:
            phase = "FIGHT_CONVERGED_OBSERVED"
        elif pending and not receipt:
            phase = "LEADER_ENTRY_PENDING"
        else:
            phase = "WORLD_STABLE_CANDIDATE"
        party_runtime = self._party_runtime_status() or {}
        runtime_accounts = party_runtime.get("accounts") if isinstance(party_runtime.get("accounts"), dict) else {}
        for account_id, account in accounts.items():
            binding = runtime_accounts.get(account_id) if isinstance(runtime_accounts, dict) else None
            if isinstance(binding, dict):
                account["client_instance_id"] = binding.get("client_instance_id")
                account["pid"] = binding.get("pid")
                account["process_creation_time"] = binding.get("process_creation_time")
        frame = {
            "frame_id": self._observation_frame_sequence,
            "captured_monotonic": float(self.clock()),
            "phase": phase,
            "party_generation": party_runtime.get("generation"),
            "party_session_id": party_runtime.get("session_id"),
            "identity_continuity": party_runtime.get("identity_continuity"),
            "accounts": accounts,
            "present_accounts": sorted(present_accounts),
            "fight_instance_ids": sorted(fight_ids),
            "pending_launch_transaction": dict(pending) if isinstance(pending, dict) else None,
            "active_launch_reference": dict(receipt) if isinstance(receipt, dict) else None,
        }
        self._last_observation_frame = frame
        self._recent_observation_frames.append(frame)
        return frame

    def _record_invariant_violation(
        self,
        *,
        code: str,
        frame: dict,
        detail: str,
        first_missing_boundary: str = "CAMPAIGN_LIFECYCLE_INVARIANT",
        likely_owner: str = "CAMPAIGN_RUNTIME",
        **extra,
    ) -> None:
        if self._first_invariant_violation is None:
            self._first_invariant_violation = {
                "failure_code": str(code),
                "detail": str(detail),
                "first_missing_boundary": str(first_missing_boundary),
                "likely_owner": str(likely_owner),
                "frame": dict(frame),
                "observed_monotonic": float(self.clock()),
                **extra,
            }

    def _fight_lifecycle_regression_failure(
        self,
        *,
        fight_instance_id: int,
        result: dict,
        observation_frame: dict,
        runtime_context: dict | None,
    ) -> dict | None:
        """Fail at the first impossible ACTIVE -> preparation regression.

        This is intentionally a parent-level tripwire, not the primary fix.
        FightWorkflow and PartyMissionController independently prevent this
        transition, but retaining the invariant here guarantees that a future
        regression is diagnosed from one runtime package instead of surfacing as
        a later PREPARATION_TIMEOUT.
        """
        state = str(result.get("state") or "")
        fight_id = int(fight_instance_id)
        if state == "ACTIVE":
            if fight_id not in self._active_fight_generations:
                self._active_fight_generations.append(fight_id)
            self._active_observed_fight_instance_id = fight_id
            action = dict(result.get("action") or {})
            lifecycle_invariant = str(action.get("lifecycle_invariant") or "").strip()
            if lifecycle_invariant:
                # The lower lifecycle fence kept execution safe, but preserving
                # the first attempted regression in the parent diagnostic frame
                # makes the incident self-explanatory even if the run later
                # fails for an unrelated reason.
                self._record_invariant_violation(
                    code=lifecycle_invariant,
                    frame=observation_frame,
                    detail=(
                        f"fight generation {fight_id} remained ACTIVE because a "
                        "completed preparation proof attempted to regress"
                    ),
                    first_missing_boundary="FIGHT_PREPARATION_COMPLETION",
                    likely_owner="PARTY_MISSION",
                    fight_instance_id=fight_id,
                    child_reason=result.get("reason"),
                    child_action=action,
                )
            return None
        prep_states = {"ENTRY_BARRIER", "CHALLENGE", "PLACEMENT", "READY"}
        if state not in prep_states or fight_id not in self._active_fight_generations:
            return None

        action = dict(result.get("action") or {})
        detail = (
            f"fight generation {fight_id} was already ACTIVE but regressed to {state}; "
            "preparation is monotonic and cannot reopen within one exact generation"
        )
        self._record_invariant_violation(
            code="FIGHT_LIFECYCLE_PHASE_REGRESSION",
            frame=observation_frame,
            detail=detail,
            first_missing_boundary="FIGHT_PHASE_MONOTONICITY",
            likely_owner="FIGHT_WORKFLOW",
            fight_instance_id=fight_id,
            previous_state="ACTIVE",
            regressed_state=state,
            child_reason=result.get("reason"),
            child_action=action,
        )
        return self._runtime_failure(
            failure_code="FIGHT_LIFECYCLE_PHASE_REGRESSION",
            detail=detail,
            first_missing_boundary="FIGHT_PHASE_MONOTONICITY",
            likely_owner="FIGHT_WORKFLOW",
            runtime_context=runtime_context,
            fight_instance_id=fight_id,
            previous_state="ACTIVE",
            regressed_state=state,
            child_reason=result.get("reason"),
            child_action=action,
            observation_frame_id=observation_frame.get("frame_id"),
        )

    def _mission_status(self) -> dict:
        """Read the parent-owned campaign status without requiring worker cooperation.

        A stopped RunBudget must fence every later campaign tick.  The worker
        normally notices the stop first, but the parent runtime is the actual
        lifecycle owner and therefore must remain safe if another caller polls it
        again after TARGET_WINS/MAX_ATTEMPTS/LOSS/UNKNOWN termination.
        """
        runtime_status = getattr(self.mission, "runtime_status", None)
        if callable(runtime_status):
            raw = runtime_status()
            return dict(raw or {}) if isinstance(raw, dict) else {}
        status = getattr(self.mission, "status", None)
        if callable(status):
            raw = status()
            return dict(raw or {}) if isinstance(raw, dict) else {}
        campaign = getattr(self.mission, "campaign", None)
        campaign_status = getattr(campaign, "status", None)
        if callable(campaign_status):
            raw = campaign_status()
            return dict(raw or {}) if isinstance(raw, dict) else {}
        return {}

    def _stopped_result(self, status: dict) -> dict:
        stop_reason = str(status.get("stop_reason") or "CAMPAIGN_STOPPED")
        return {
            "domain": "CAMPAIGN",
            "state": "STOPPED",
            "action": {
                "status": "STOP",
                "stop_reason": stop_reason,
                "budget": dict(status.get("budget") or {}),
            },
            "reason": stop_reason,
            "next_allowed_commands": [],
        }

    def _runtime_failure(
        self, *, failure_code: str, detail: str,
        first_missing_boundary: str, likely_owner: str,
        runtime_context: dict | None = None, **extra,
    ) -> dict:
        note = getattr(self.mission, "note_runtime_failure", None)
        if not callable(note):
            # Narrow/legacy mission façades may expose CampaignEngine directly
            # without forwarding this diagnostic hook. Preserve parent-runtime
            # root causality in that shape too; failure recording must not depend
            # on which façade happens to host the runtime controller.
            campaign = getattr(self.mission, "campaign", None)
            note = getattr(campaign, "note_runtime_failure", None)
        if callable(note):
            try:
                note(
                    failure_code=str(failure_code), detail=str(detail),
                    first_missing_boundary=str(first_missing_boundary),
                    likely_owner=str(likely_owner), runtime_context=runtime_context,
                )
            except Exception:
                # Diagnostic persistence must never replace the actual runtime
                # failure returned to the caller. The primary failure remains
                # fail-closed even if a secondary reporter is unavailable.
                pass
        return {
            "domain": "CAMPAIGN",
            "state": "FAILED",
            "action": {
                "status": "FAILED",
                "failure_code": str(failure_code),
                "first_missing_boundary": str(first_missing_boundary),
                "likely_owner": str(likely_owner),
                "detail": str(detail),
                **extra,
            },
            "reason": str(failure_code),
            "next_allowed_commands": [],
        }

    @staticmethod
    def _present_fight_id(snapshot) -> int | None:
        if not snapshot.fight.present or snapshot.fight.fight_instance_id is None:
            return None
        return int(snapshot.fight.fight_instance_id)

    def _capture_fight_evidence(self, snapshots: dict[str, object], fight_instance_id: int) -> None:
        if self._observed_fight_instance_id != int(fight_instance_id):
            self._observed_fight_instance_id = int(fight_instance_id)
            self._fight_evidence.clear()
        for account_id, snapshot in snapshots.items():
            if self._present_fight_id(snapshot) == int(fight_instance_id):
                self._fight_evidence[str(account_id)] = snapshot

    def _post_fight_partial_exit_result(
        self,
        *,
        snapshots: dict[str, object],
        present_ids: set[int],
        observation_frame: dict,
    ) -> dict | None:
        """Quarantine normal required-party exit skew after ACTIVE.

        Required Dofus clients do not observe FIGHT_ENDED/world re-entry at the
        same instant. Once an exact generation has completed preparation or
        crossed ACTIVE, a frame where only some required lanes still report that
        same generation is terminal settlement evidence, never a new JOINING
        decision. No child workflow or physical-input owner is called from this
        state.
        """
        observed_id = self._observed_fight_instance_id
        if observed_id is None or len(present_ids) != 1:
            return None
        current_id = int(next(iter(present_ids)))
        lifecycle = self._fight_generation_authority(current_id)
        active_latched = bool(lifecycle.active_latched)
        preparation_latched = bool(lifecycle.preparation_complete)
        if (
            current_id != int(observed_id)
            or lifecycle.partial_classification is not FightPartialClassification.EXIT_SETTLING
        ):
            return None

        required_ids = tuple(str(lane.account_id) for lane in self._required_lanes())
        present_accounts = [
            account_id for account_id in required_ids
            if self._present_fight_id(snapshots[account_id]) == current_id
        ]
        missing_accounts = [account_id for account_id in required_ids if account_id not in present_accounts]
        if not present_accounts or not missing_accounts:
            return None

        # Preserve the freshest still-in-fight evidence while retaining the
        # earlier complete generation evidence for lanes that already exited.
        self._capture_fight_evidence(snapshots, current_id)
        failure = self._watchdog_failure(phase="POST_FIGHT", key=current_id)
        if failure is not None:
            action = dict(failure.get("action") or {})
            action.update({
                "fight_instance_id": current_id,
                "present_accounts": list(present_accounts),
                "missing_accounts": list(missing_accounts),
                "observation_frame_id": observation_frame.get("frame_id"),
                "first_missing_boundary": "POST_FIGHT_REQUIRED_PARTY_EXIT",
                "likely_owner": "CANONICAL_FIGHT_LIFECYCLE",
            })
            return {**failure, "action": action}

        return {
            "domain": "FIGHT",
            "state": "POST_FIGHT_SETTLEMENT",
            "action": {
                "status": "WAIT",
                "reason": "POST_FIGHT_PARTIAL_EXIT_SETTLING",
                "fight_instance_id": current_id,
                "active_generation_latched": bool(active_latched),
                "preparation_complete_latched": bool(preparation_latched),
                "present_accounts": list(present_accounts),
                "missing_accounts": list(missing_accounts),
                "observation_frame_id": observation_frame.get("frame_id"),
                "physical_input_sent": False,
                "detail": (
                    "an ACTIVE fight generation is exiting asynchronously across required accounts; "
                    "wait for the remaining clients to leave before committing outcome"
                ),
            },
            "reason": "POST_FIGHT_PARTIAL_EXIT_SETTLING",
            "next_allowed_commands": ["OBSERVE_FIGHT_EXIT"],
        }

    @staticmethod
    def _terminal_step_failure(domain: str, result: dict) -> dict | None:
        """Promote only semantically terminal child dispositions.

        The terminality decision is shared with CampaignEngine so transient
        convergence blockers cannot be recorded as sticky failures while the
        parent runtime treats them as ordinary waits.
        """
        action = dict(result.get("action") or {})
        failure_code = workflow_terminal_failure_code(domain, result)
        if failure_code is None:
            return None
        state = str(result.get("state") or "")
        status = str(action.get("status") or "UNKNOWN")
        nested = dict(action.get("action_result") or {}) if isinstance(action.get("action_result"), dict) else {}
        return {
            "domain": "CAMPAIGN",
            "state": "FAILED",
            "action": {
                **action,
                "status": "FAILED",
                "failure_code": failure_code,
                "child_domain": str(domain),
                "child_state": state,
                "child_status": status,
                "first_missing_boundary": action.get("first_missing_boundary") or nested.get("first_missing_boundary"),
                "likely_owner": action.get("likely_owner") or nested.get("likely_owner") or f"{str(domain).upper()}_RUNTIME",
            },
            "reason": failure_code,
            "next_allowed_commands": [],
        }

    def _watchdog_failure(self, *, phase: str, key=None) -> dict | None:
        observe = getattr(self.mission, "observe_phase", None)
        if not callable(observe):
            return None
        result = dict(observe(str(phase), key=key) or {})
        if str(result.get("status") or "") != "TIMEOUT":
            return None
        return {
            "domain": "CAMPAIGN",
            "state": "FAILED",
            "action": {
                **result,
                "status": "FAILED",
                "failure_code": str(result.get("failure_code") or "MISSION_TIMEOUT"),
                "first_missing_boundary": "CAMPAIGN_PHASE_PROGRESS",
                "likely_owner": "CAMPAIGN_RUNTIME",
            },
            "reason": str(result.get("failure_code") or "MISSION_TIMEOUT"),
            "next_allowed_commands": [],
        }

    @staticmethod
    def _fight_watchdog_phase(result: dict, fight_instance_id: int) -> tuple[str, object] | None:
        state = str(result.get("state") or "")
        action = dict(result.get("action") or {})
        if state == "JOINING":
            return "FIGHT_JOINING", fight_instance_id
        if state in {"ENTRY_BARRIER", "CHALLENGE", "PLACEMENT", "READY"}:
            return "FIGHT_PREPARATION", fight_instance_id
        if state == "ACTIVE":
            return "FIGHT_ACTIVE", result.get("progress_token") or action.get("progress_token") or fight_instance_id
        if state == "POST_FIGHT_SETTLEMENT":
            return "POST_FIGHT", fight_instance_id
        return None

    @staticmethod
    def _world_watchdog_phase(result: dict) -> tuple[str, object] | None:
        state = str(result.get("state") or "")
        action = dict(result.get("action") or {})

        def map_progress_token():
            maps = action.get("account_maps") or action.get("maps")
            if isinstance(maps, dict):
                normalized_maps = tuple(
                    sorted((str(account), None if value is None else int(value)) for account, value in maps.items())
                )
            else:
                normalized_maps = ()
            return (
                action.get("target_map_id") or action.get("leader_map_id"),
                normalized_maps,
                action.get("action_account_id") or action.get("account_id"),
                action.get("confirmed_map_id"),
            )

        if state == "PARTY_CONVERGENCE":
            return "WORLD_CONVERGENCE", map_progress_token()
        if state == "TRANSITION":
            return "WORLD_TRANSITION", map_progress_token()
        if state == "ACQUIRE_TARGET":
            # Keep one key across safe retry attempts for the same target so the
            # outer watchdog supervises the entire bounded recovery transaction.
            return "LAUNCHING_FIGHT", (
                action.get("origin_world_entity_id")
                or action.get("group_id")
                or action.get("target_group_id")
                or action.get("selected_group_id")
                or tuple(action.get("candidate_group_ids") or ())
            )
        if state == "WORLD_SETTLING":
            return "POST_FIGHT_WORLD_REENTRY", action.get("map_id") or action.get("reason")
        return None

    def _commit_terminal_outcome(self, current: dict[str, object]) -> dict:
        fight_instance_id = self._observed_fight_instance_id
        required_ids = tuple(str(lane.account_id) for lane in self._required_lanes())
        evidence_complete = set(self._fight_evidence) == set(required_ids)
        if evidence_complete:
            terminal = dict(self.outcome_resolver(dict(self._fight_evidence), dict(current)) or {})
        else:
            terminal = {
                "outcome": FightOutcome.UNKNOWN.value,
                "reason": "REQUIRED_ACCOUNT_TERMINAL_EVIDENCE_INCOMPLETE",
                "terminal_evidence": {
                    "fight_instance_id": fight_instance_id,
                    "required_accounts": list(required_ids),
                    "captured_accounts": sorted(self._fight_evidence),
                    "missing_accounts": sorted(set(required_ids) - set(self._fight_evidence)),
                },
            }

        raw_outcome = str(terminal.get("outcome") or FightOutcome.UNKNOWN.value)
        try:
            outcome = FightOutcome(raw_outcome)
        except ValueError:
            outcome = FightOutcome.UNKNOWN
        recorded = dict(self.mission.record_outcome(outcome))
        if str(recorded.get("status") or "") == "CONTINUE":
            self.world_workflow.mark_reentry_required(reason=f"FIGHT_OUTCOME_{outcome.value}")
            recorded["world_reentry_required"] = True

        budget_after = dict(recorded.get("budget") or {})
        self._fight_outcome_history.append({
            "fight_ordinal": int(budget_after.get("attempts") or 0),
            "fight_instance_id": (int(fight_instance_id) if fight_instance_id is not None else None),
            "outcome": outcome.value,
            "outcome_reason": terminal.get("reason"),
            "confirmed_wins": int(budget_after.get("wins") or 0),
            "target_wins": int(budget_after.get("target_wins") or 0),
            "attempts": int(budget_after.get("attempts") or 0),
            "max_attempts": int(budget_after.get("max_attempts") or 0),
            "decision": str(recorded.get("status") or "UNKNOWN"),
            "stop_reason": recorded.get("stop_reason"),
            "world_reentry_required": bool(recorded.get("world_reentry_required")),
            "evidence_complete": bool(evidence_complete),
            "observed_monotonic": float(self.clock()),
        })

        result = {
            "domain": "CAMPAIGN",
            "state": "OUTCOME_COMMITTED",
            "action": {
                **recorded,
                "outcome": outcome.value,
                "fight_instance_id": fight_instance_id,
                "outcome_reason": terminal.get("reason"),
                "terminal_evidence": terminal.get("terminal_evidence"),
                "evidence_complete": evidence_complete,
            },
            "reason": str(terminal.get("reason") or "TERMINAL_OUTCOME_COMMITTED"),
            "next_allowed_commands": (
                [] if str(recorded.get("status") or "") == "STOP" else ["WORLD_WORKFLOW"]
            ),
        }
        self._last_committed_fight_instance_id = (
            int(fight_instance_id) if fight_instance_id is not None else None
        )
        self._observed_fight_instance_id = None
        self._active_observed_fight_instance_id = None
        self._fight_evidence.clear()

        # The parent is the authority that knows this exact generation has been
        # terminally accounted. Retire the child fight lifecycle immediately so
        # an ordinary partial entry into fight #N+1 cannot inherit the previous
        # generation's ACTIVE latch and be misclassified as post-fight exit skew.
        # Narrow test/legacy façades may omit reset(); production FightWorkflow
        # implements it and clears only run-scoped fight lifecycle state.
        retire = getattr(self.fight_workflow, "reset", None)
        if callable(retire):
            retire()
        return result

    def _note_workflow_result(
        self, *, domain: str, result: dict, runtime_context: dict | None = None
    ) -> None:
        """Mirror lifecycle evidence without making observability a runtime dependency.

        Production PartyMissionController exposes ``note_workflow_result`` and
        forwards it into CampaignEngine for causal diagnostics. Narrow legacy/test
        façades may intentionally omit the hook, and a diagnostics implementation
        may itself fail. Neither case may create a second mission failure after the
        authoritative world/fight owner has already produced a valid result.
        """
        note = getattr(self.mission, "note_workflow_result", None)
        if not callable(note):
            return
        try:
            note(domain=str(domain), result=dict(result or {}), runtime_context=runtime_context)
        except Exception as exc:
            context = dict(runtime_context or {})
            self._observability_errors.append({
                "domain": str(domain),
                "error": f"{type(exc).__name__}: {exc}",
                "run_id": (str(context.get("run_id")) if context.get("run_id") is not None else None),
                "request_id": (str(context.get("request_id")) if context.get("request_id") is not None else None),
                "observed_monotonic": float(self.clock()),
            })

    def _startup_bootstrap_step(
        self, snapshots: dict[str, object], *, runtime_context: dict | None = None
    ) -> dict | None:
        """Own current-session map acquisition inside the launched run.

        Pending Launch is observation-only in R5.120.  If every required lane is
        semantically WORLD with an unknown MapId, the parent campaign may execute
        the one certified fixed-edge bootstrap under the current run/session
        control authorization.  No pre-run worker or readiness loop may do so.
        """
        if self.startup_bootstrap_provider is None:
            return None
        required = tuple(snapshots.items())
        if not required:
            return None
        if any(bool(getattr(getattr(snapshot, "fight", None), "present", False)) for _, snapshot in required):
            return None
        unknown = []
        for account_id, snapshot in required:
            world = getattr(snapshot, "world", None)
            semantic = getattr(world, "map_id", None)
            status = getattr(getattr(semantic, "status", None), "value", getattr(semantic, "status", None))
            value = getattr(semantic, "value", None)
            if str(status or "") != "KNOWN" or value is None:
                unknown.append(str(account_id))
        if len(unknown) != len(required):
            return None
        bootstrap = self.startup_bootstrap_provider()
        if bootstrap is None:
            return None
        try:
            assessment = dict(bootstrap.assess() or {})
        except Exception as exc:
            return self._runtime_failure(
                failure_code="STARTUP_BOOTSTRAP_ASSESSMENT_ERROR",
                detail=f"{type(exc).__name__}: {exc}",
                first_missing_boundary="STARTUP_WORLD_MAP_ACQUISITION",
                likely_owner="PARTY_STARTUP_CONVERGENCE",
                runtime_context=runtime_context,
            )
        status = str(assessment.get("status") or "UNKNOWN").upper()
        if status == "CONFIRMED":
            return None
        if status == "BLOCKED":
            return self._runtime_failure(
                failure_code="WORLD_MAP_BOOTSTRAP_BLOCKED",
                detail=str(assessment.get("detail") or assessment.get("code") or "world-map bootstrap became unsafe after Launch"),
                first_missing_boundary="STARTUP_WORLD_MAP_ACQUISITION",
                likely_owner="PARTY_STARTUP_CONVERGENCE",
                runtime_context=runtime_context,
                startup_bootstrap=assessment,
            )
        if status != "READY":
            return {
                "domain": "STARTUP",
                "state": "WORLD_MAP_BOOTSTRAP_WAIT",
                "action": {
                    **assessment,
                    "status": "WAIT",
                    "physical_input_sent": False,
                    "first_missing_boundary": "STARTUP_WORLD_MAP_ACQUISITION",
                    "likely_owner": "PARTY_STARTUP_CONVERGENCE",
                },
                "reason": str(assessment.get("code") or "WORLD_MAP_BOOTSTRAP_NOT_READY"),
            }
        execute = getattr(bootstrap, "execute", None)
        if not callable(execute):
            return self._runtime_failure(
                failure_code="STARTUP_BOOTSTRAP_EXECUTION_ERROR",
                detail="startup bootstrap is READY but exposes no callable execute authority",
                first_missing_boundary="STARTUP_WORLD_MAP_ACQUISITION",
                likely_owner="PARTY_STARTUP_CONVERGENCE",
                runtime_context=runtime_context,
            )
        try:
            if self._callable_accepts_keyword(execute, "runtime_context"):
                result = dict(execute(runtime_context=runtime_context) or {})
            else:
                # Compatibility only for an explicitly old signature.  Never
                # infer compatibility by swallowing a TypeError thrown *inside*
                # the modern implementation.
                result = dict(execute() or {})
        except Exception as exc:
            return self._runtime_failure(
                failure_code="STARTUP_BOOTSTRAP_EXECUTION_ERROR",
                detail=f"{type(exc).__name__}: {exc}",
                first_missing_boundary="STARTUP_WORLD_MAP_ACQUISITION",
                likely_owner="PARTY_STARTUP_CONVERGENCE",
                runtime_context=runtime_context,
            )
        action_status = str(result.get("status") or "UNKNOWN").upper()
        failure_code = str(result.get("failure_code") or result.get("code") or "")
        if action_status in {"FAILED", "UNCERTAIN"} or failure_code.startswith("CONTROL_"):
            return self._runtime_failure(
                failure_code=failure_code or "STARTUP_BOOTSTRAP_EXECUTION_ERROR",
                detail=str(result.get("detail") or "launched runtime bootstrap failed"),
                first_missing_boundary="STARTUP_WORLD_MAP_ACQUISITION",
                likely_owner="PARTY_STARTUP_CONVERGENCE",
                runtime_context=runtime_context,
                startup_bootstrap=result,
            )
        return {
            "domain": "STARTUP",
            "state": "WORLD_MAP_BOOTSTRAP",
            "action": {**result, "startup_owned_by_run": True},
            "reason": str(result.get("detail") or result.get("code") or "WORLD_MAP_BOOTSTRAP"),
        }

    def _advance_world(self, *, runtime_context: dict | None = None) -> dict:
        result = self.world_workflow.advance(runtime_context=runtime_context).to_dict()
        self._note_workflow_result(
            domain="world", result=result, runtime_context=runtime_context
        )
        terminal_failure = self._terminal_step_failure("WORLD", result)
        if terminal_failure is not None:
            return terminal_failure
        phase = self._world_watchdog_phase(result)
        if phase is not None:
            failure = self._watchdog_failure(phase=phase[0], key=phase[1])
            if failure is not None:
                return failure
        return {"domain": "WORLD", **result}

    def _step_once(self, *, runtime_context: dict | None = None) -> dict:
        if self._terminal_failure is not None:
            # A terminal campaign failure owns the runtime until an explicit
            # fresh-run reset.  Repeated worker/UI polling is observation-only
            # and can never reopen world/fight actions after a failed boundary.
            return {
                **dict(self._terminal_failure),
                "action": {
                    **dict(self._terminal_failure.get("action") or {}),
                    "terminal_failure_latched": True,
                },
            }
        required = self._required_lanes()
        if not required:
            return self._runtime_failure(
                failure_code="CAMPAIGN_REQUIRED_PARTY_EMPTY",
                detail="campaign runtime has no required account lanes",
                first_missing_boundary="CAMPAIGN_REQUIRED_PARTY",
                likely_owner="CAMPAIGN_RUNTIME",
                runtime_context=runtime_context,
            )

        mission_status = self._mission_status()
        if mission_status.get("stop_reason"):
            return self._stopped_result(mission_status)

        # Startup has one deliberately narrower health contract than normal
        # continuity: the launched runtime may create the first Canonical MapId
        # when (and only when) every current blocker is classified by the startup
        # policy as bootstrap-expected.  This prevents the historical first-tick
        # deadlock where continuity killed the run before bootstrap could execute.
        snapshots = self._snapshots()
        bootstrap_allowed, bootstrap_health, bootstrap_health_detail = self._bootstrap_health_gate(required)
        if bootstrap_allowed:
            startup = self._startup_bootstrap_step(snapshots, runtime_context=runtime_context)
            if startup is not None:
                action = dict(startup.get("action") or {})
                action.setdefault("startup_health_gate", bootstrap_health_detail)
                startup["action"] = action
                return startup

        continuity_result = self._continuity_step(
            required, runtime_context=runtime_context, health_override=bootstrap_health
        )
        if continuity_result is not None:
            return continuity_result

        # Once an outcome is committed, WorldWorkflow owns the entire re-entry
        # boundary. A stale canonical fight flag for the just-finished generation
        # must never reopen FightWorkflow before the rendered world surface is
        # proven stable. The generation tombstone survives until that gate clears.
        reentry_pending = bool(getattr(self.world_workflow, "reentry_required", False))
        if self._last_committed_fight_instance_id is not None and reentry_pending:
            # R5.164: fight outcome commitment is mission authority, while stale
            # action causality belongs to each lane's ExecutionService.  Sweep
            # those generation-scoped combat fences before WorldWorkflow is
            # allowed to reach SELECT_TARGET/LAUNCH_FIGHT.  The sweep is passive
            # and cannot emit physical input.
            reconcile = getattr(self.mission, "reconcile_post_fight_execution_safety", None)
            if callable(reconcile):
                safety = dict(reconcile(reason="POST_FIGHT_WORLD_REENTRY") or {})
                safety_status = str(safety.get("status") or "UNKNOWN").upper()
                if safety_status == "BLOCKED":
                    return self._runtime_failure(
                        failure_code=str(safety.get("failure_code") or "POST_FIGHT_EXECUTION_SAFETY_BLOCKED"),
                        detail=str(safety.get("detail") or "post-fight execution safety could not be reconciled"),
                        first_missing_boundary=str(safety.get("first_missing_boundary") or "POST_FIGHT_EXECUTION_SAFETY"),
                        likely_owner=str(safety.get("likely_owner") or "EXECUTION_SERVICE"),
                        runtime_context=runtime_context,
                        execution_safety=safety,
                    )
                if safety_status == "WAIT":
                    timeout = self._watchdog_failure(
                        phase="POST_FIGHT",
                        key=self._last_committed_fight_instance_id,
                    )
                    if timeout is not None:
                        return timeout
                    return {
                        "domain": "FIGHT",
                        "state": "POST_FIGHT_EXECUTION_SAFETY",
                        "action": {**safety, "status": "WAIT"},
                        "reason": str(safety.get("reason") or "POST_FIGHT_EXECUTION_SAFETY_RECONCILING"),
                        "next_allowed_commands": ["OBSERVE_EXECUTION_SAFETY"],
                    }
            return self._advance_world(runtime_context=runtime_context)

        # One parent observation frame owns this campaign decision. Child owners
        # may observe newer state, but they may not silently reinterpret a pending
        # launch as ordinary world convergence.
        mission_status = self._mission_status()
        observation_frame = self._capture_observation_frame(snapshots, mission_status)
        present_ids = {
            fight_id
            for fight_id in (self._present_fight_id(snapshot) for snapshot in snapshots.values())
            if fight_id is not None
        }
        if len(present_ids) > 1:
            return self._runtime_failure(
                failure_code="CAMPAIGN_FIGHT_GENERATION_CONFLICT",
                detail="required accounts observe different fight generations",
                first_missing_boundary="SHARED_FIGHT_GENERATION",
                likely_owner="FIGHT_LIFECYCLE",
                runtime_context=runtime_context,
                fight_instance_ids=sorted(present_ids),
            )

        launch_pending = bool(mission_status.get("launch_transition_pending"))
        launch_settlement_action: dict | None = None
        if launch_pending:
            settle = getattr(self.mission, "settle_active_launch_transaction_step", None)
            if not callable(settle):
                self._record_invariant_violation(
                    code="LAUNCH_TRANSACTION_OWNER_MISSING",
                    frame=observation_frame,
                    detail="a pending launch transaction exists but the mission cannot settle it across the domain handoff",
                )
                return self._runtime_failure(
                    failure_code="LAUNCH_TRANSACTION_OWNER_MISSING",
                    detail="pending launch transaction cannot be advanced by the parent lifecycle owner",
                    first_missing_boundary="WORLD_TO_FIGHT_TRANSACTION_CONTINUITY",
                    likely_owner="CAMPAIGN_RUNTIME",
                    runtime_context=runtime_context,
                )
            launch_settlement_action = dict(settle(runtime_context=runtime_context) or {})
            status = str(launch_settlement_action.get("status") or "UNKNOWN")
            if status in {"FAILED", "UNCERTAIN"}:
                self._record_invariant_violation(
                    code=str(launch_settlement_action.get("failure_code") or "LAUNCH_TRANSITION_FAILED"),
                    frame=observation_frame,
                    detail=str(launch_settlement_action.get("detail") or "pending launch transition failed"),
                )
                return self._runtime_failure(
                    failure_code=str(launch_settlement_action.get("failure_code") or "LAUNCH_TRANSITION_FAILED"),
                    detail=str(launch_settlement_action.get("detail") or "pending launch transition failed"),
                    first_missing_boundary=str(launch_settlement_action.get("first_missing_boundary") or "FIGHT_GENERATION_SETTLEMENT"),
                    likely_owner=str(launch_settlement_action.get("likely_owner") or "WORLD_TO_FIGHT_TRANSITION"),
                    runtime_context=runtime_context,
                    launch_action=launch_settlement_action,
                )
            # Settling can materialize the exact receipt even though the parent
            # frame was captured one instant earlier. Refresh only mission-owned
            # transaction metadata; lifecycle domain remains owned by this frame.
            mission_status = self._mission_status()

            if not present_ids:
                transaction_id = (
                    launch_settlement_action.get("transaction_id")
                    or launch_settlement_action.get("transition_transaction_id")
                    or (mission_status.get("active_launch_transaction") or {}).get("transaction_id")
                )
                failure = self._watchdog_failure(phase="LAUNCHING_FIGHT", key=transaction_id)
                if failure is not None:
                    self._record_invariant_violation(
                        code=str(failure.get("reason") or "LAUNCH_TRANSITION_TIMEOUT"),
                        frame=observation_frame,
                        detail="accepted/pending launch did not reach an exact fight generation within the campaign watchdog",
                    )
                    return failure
                return {
                    "domain": "TRANSITION",
                    "state": "LEADER_ENTRY_PENDING",
                    "action": {
                        **launch_settlement_action,
                        "world_commands_fenced": True,
                        "authorization_frame_id": observation_frame["frame_id"],
                    },
                    "reason": str(launch_settlement_action.get("failure_code") or "LAUNCH_TRANSACTION_SETTLING"),
                    "next_allowed_commands": ["OBSERVE_LAUNCH_TRANSACTION"],
                }

        if present_ids:
            partial_exit = self._post_fight_partial_exit_result(
                snapshots=snapshots, present_ids=present_ids, observation_frame=observation_frame
            )
            if partial_exit is not None:
                self._note_workflow_result(
                    domain="fight", result=partial_exit, runtime_context=runtime_context
                )
                return partial_exit

            # A launch receipt may legally materialize after the parent has already
            # observed FIGHT. Promote it only from the same accepted transaction
            # and exact canonical origin; this gives follower join a causal receipt
            # without fabricating one.
            promote = getattr(self.mission, "promote_launch_reference_from_fight", None)
            if callable(promote):
                promote(snapshots)
                mission_status = self._mission_status()
            fight_instance_id = next(iter(present_ids))
            if (
                self._observed_fight_instance_id is None
                and self._last_committed_fight_instance_id is not None
                and int(self._last_committed_fight_instance_id) == int(fight_instance_id)
            ):
                reference = mission_status.get("active_launch_reference")
                authorized_reuse = False
                if isinstance(reference, dict) and reference.get("fight_instance_id") is not None:
                    try:
                        authorized_reuse = int(reference.get("fight_instance_id")) == int(fight_instance_id)
                    except (TypeError, ValueError):
                        authorized_reuse = False
                if not authorized_reuse:
                    return self._runtime_failure(
                        failure_code="CAMPAIGN_COMMITTED_FIGHT_REAPPEARED",
                        detail="a previously committed fight generation reappeared without a new exact launch receipt",
                        first_missing_boundary="POST_FIGHT_GENERATION_SEPARATION",
                        likely_owner="CANONICAL_FIGHT_LIFECYCLE",
                        runtime_context=runtime_context,
                        fight_instance_id=int(fight_instance_id),
                        last_committed_fight_instance_id=int(self._last_committed_fight_instance_id),
                    )
                self._last_committed_fight_instance_id = None
            elif (
                self._observed_fight_instance_id is None
                and self._last_committed_fight_instance_id is not None
                and int(self._last_committed_fight_instance_id) != int(fight_instance_id)
            ):
                # A distinct generation is sufficient to retire the old tombstone.
                self._last_committed_fight_instance_id = None

            if (
                self._observed_fight_instance_id is not None
                and int(self._observed_fight_instance_id) != int(fight_instance_id)
            ):
                return self._runtime_failure(
                    failure_code="CAMPAIGN_FIGHT_GENERATION_ADVANCED_BEFORE_OUTCOME",
                    detail="a new fight generation appeared before the previous fight outcome was committed",
                    first_missing_boundary="FIGHT_TERMINAL_OUTCOME_COMMIT",
                    likely_owner="CAMPAIGN_RUNTIME",
                    runtime_context=runtime_context,
                    previous_fight_instance_id=int(self._observed_fight_instance_id),
                    observed_fight_instance_id=int(fight_instance_id),
                    captured_evidence_accounts=sorted(self._fight_evidence),
                )
            self._capture_fight_evidence(snapshots, fight_instance_id)
            result = self.fight_workflow.advance(runtime_context=runtime_context).to_dict()
            self._note_workflow_result(
                domain="fight", result=result, runtime_context=runtime_context
            )
            lifecycle_regression = self._fight_lifecycle_regression_failure(
                fight_instance_id=fight_instance_id,
                result=result,
                observation_frame=observation_frame,
                runtime_context=runtime_context,
            )
            if lifecycle_regression is not None:
                return lifecycle_regression
            terminal_failure = self._terminal_step_failure("FIGHT", result)
            if terminal_failure is not None:
                return terminal_failure
            phase = self._fight_watchdog_phase(result, fight_instance_id)
            if phase is not None:
                failure = self._watchdog_failure(phase=phase[0], key=phase[1])
                if failure is not None:
                    return failure
            return {"domain": "FIGHT", **result}

        # A previously observed exact fight generation has now disappeared from
        # every required lane. Commit its outcome before *any* world action. This
        # makes fight->outcome->world ordering parent-owned and prevents a worker
        # from skipping accounting or launching fight #N+1 from stale state.
        if self._observed_fight_instance_id is not None:
            return self._commit_terminal_outcome(snapshots)

        return self._advance_world(runtime_context=runtime_context)

    def _record_runtime_step(self, result: dict, runtime_context: dict | None) -> dict:
        payload = dict(result or {})
        action = dict(payload.get("action") or {}) if isinstance(payload.get("action"), dict) else {}
        context = dict(runtime_context or {})
        self._runtime_step_sequence += 1
        mission_status = self._mission_status()
        budget = dict(mission_status.get("budget") or {})
        record = {
            "sequence": self._runtime_step_sequence,
            "observed_monotonic": float(self.clock()),
            "domain": str(payload.get("domain") or "UNKNOWN"),
            "state": str(payload.get("state") or "UNKNOWN"),
            "reason": (str(payload.get("reason")) if payload.get("reason") is not None else None),
            "action_status": (str(action.get("status")) if action.get("status") is not None else None),
            "failure_code": (
                str(action.get("failure_code")) if action.get("failure_code") is not None else None
            ),
            "first_missing_boundary": (
                str(action.get("first_missing_boundary"))
                if action.get("first_missing_boundary") is not None else None
            ),
            "likely_owner": (
                str(action.get("likely_owner")) if action.get("likely_owner") is not None else None
            ),
            "run_id": (str(context.get("run_id")) if context.get("run_id") is not None else None),
            "request_id": (
                str(context.get("request_id")) if context.get("request_id") is not None else None
            ),
            "account_id": (
                str(payload.get("account_id") or action.get("account_id"))
                if (payload.get("account_id") is not None or action.get("account_id") is not None)
                else None
            ),
            "fight_instance_id": (
                action.get("fight_instance_id")
                if action.get("fight_instance_id") is not None
                else self._observed_fight_instance_id
            ),
            "observed_fight_instance_id": self._observed_fight_instance_id,
            "active_observed_fight_instance_id": self._active_observed_fight_instance_id,
            "present_accounts": list(action.get("present_accounts") or ()),
            "missing_accounts": list(action.get("missing_accounts") or ()),
            "last_committed_fight_instance_id": self._last_committed_fight_instance_id,
            "post_fight_world_reentry_required": bool(
                getattr(self.world_workflow, "reentry_required", False)
            ),
            "budget": {
                key: budget.get(key)
                for key in (
                    "wins", "target_wins", "attempts", "max_attempts",
                    "losses", "unknowns", "aborted",
                )
                if key in budget
            },
            "stop_reason": mission_status.get("stop_reason"),
            "continuity": {
                **self._continuity.status(),
                "suspect_seconds": self._continuity_suspect_seconds,
                "ready_inbound_stall_suspect_seconds": self._ready_inbound_stall_suspect_seconds,
                "pending_action_inbound_stall_suspect_seconds": self._pending_action_inbound_stall_suspect_seconds,
            },
            "live_transport_health": {
                "ready_inbound_stall_suspect_seconds": self._ready_inbound_stall_suspect_seconds,
                "pending_action_inbound_stall_suspect_seconds": self._pending_action_inbound_stall_suspect_seconds,
                "last_runtime_health": {str(k): dict(v) for k, v in self._last_runtime_health.items()},
                "continuity_history": [dict(item) for item in self._continuity_history],
            },
            "campaign_watchdog_hold": mission_status.get("watchdog_hold"),
        }
        self._recent_steps.append(record)
        self._last_step = record
        return payload

    def step(self, *, runtime_context: dict | None = None) -> dict:
        try:
            result = self._step_once(runtime_context=runtime_context)
        except FightGenerationAuthorityError as exc:
            result = self._runtime_failure(
                failure_code="FIGHT_LIFECYCLE_AUTHORITY_FAILURE",
                detail=str(exc),
                first_missing_boundary="FIGHT_GENERATION_LIFECYCLE_AUTHORITY",
                likely_owner="FIGHT_WORKFLOW",
                runtime_context=runtime_context,
            )
        except RuntimeError as exc:
            code = self._generation_failure_code(exc)
            if code is None:
                raise
            result = self._runtime_failure(
                failure_code=code,
                detail=str(exc),
                first_missing_boundary="PARTY_RUNTIME_GENERATION",
                likely_owner="PARTY_RUNTIME_RECONCILIATION",
                runtime_context=runtime_context,
                party_runtime_status=self._party_runtime_status(),
            )
        if (
            str(result.get("domain") or "") == "CAMPAIGN"
            and str(result.get("state") or "") == "FAILED"
        ):
            self._terminal_failure = {
                **dict(result),
                "action": dict(result.get("action") or {}),
            }
        return self._record_runtime_step(result, runtime_context)

    def _lifecycle_phase(self, mission_status: dict) -> str:
        if mission_status.get("stop_reason"):
            return "STOPPED"
        if self._terminal_failure is not None:
            return "FAILED"
        if self._last_step is not None and str(self._last_step.get("state") or "") == "FAILED":
            return "FAILED"
        if (
            self._last_step is not None
            and str(self._last_step.get("state") or "")
            in {"POST_FIGHT_SETTLEMENT", "POST_FIGHT_EXECUTION_SAFETY"}
        ):
            return str(self._last_step.get("state"))
        if self._observed_fight_instance_id is not None:
            return "FIGHT"
        if mission_status.get("launch_transition_pending"):
            return "LEADER_ENTRY_PENDING"
        if (
            self._last_committed_fight_instance_id is not None
            and bool(getattr(self.world_workflow, "reentry_required", False))
        ):
            return "POST_FIGHT_WORLD_REENTRY"
        if self._last_step is not None and str(self._last_step.get("state") or "") == "OUTCOME_COMMITTED":
            return "OUTCOME_COMMITTED"
        return "WORLD"

    def status(self) -> dict:
        party_access_error = None
        try:
            required_ids = {str(lane.account_id) for lane in self._required_lanes()}
        except RuntimeError as exc:
            code = self._generation_failure_code(exc)
            if code is None:
                raise
            required_ids = set()
            party_access_error = {
                "failure_code": code,
                "detail": str(exc),
                "first_missing_boundary": "PARTY_RUNTIME_GENERATION",
                "likely_owner": "PARTY_RUNTIME_RECONCILIATION",
            }
        mission_status = self._mission_status()
        evidence = {}
        for account_id, snapshot in self._fight_evidence.items():
            evidence[str(account_id)] = {
                "revision": int(getattr(snapshot, "revision", 0)),
                "fight_instance_id": self._present_fight_id(snapshot),
            }
        budget = dict(mission_status.get("budget") or {})
        attempts = int(budget.get("attempts") or 0)
        return {
            "owner": "PARENT_CAMPAIGN_RUNTIME",
            "continuity": {
                **self._continuity.status(),
                "suspect_seconds": self._continuity_suspect_seconds,
                "ready_inbound_stall_suspect_seconds": self._ready_inbound_stall_suspect_seconds,
                "pending_action_inbound_stall_suspect_seconds": self._pending_action_inbound_stall_suspect_seconds,
            },
            "live_transport_health": {
                "ready_inbound_stall_suspect_seconds": self._ready_inbound_stall_suspect_seconds,
                "pending_action_inbound_stall_suspect_seconds": self._pending_action_inbound_stall_suspect_seconds,
                "last_runtime_health": {str(k): dict(v) for k, v in self._last_runtime_health.items()},
                "continuity_history": [dict(item) for item in self._continuity_history],
            },
            "campaign_watchdog_hold": mission_status.get("watchdog_hold"),
            "terminal_failure": (
                {**dict(self._terminal_failure), "action": dict(self._terminal_failure.get("action") or {})}
                if self._terminal_failure is not None else None
            ),
            "party_access_error": party_access_error,
            "party_runtime_status": self._party_runtime_status(),
            "lifecycle_phase": self._lifecycle_phase(mission_status),
            "runtime_step_sequence": self._runtime_step_sequence,
            "last_step": (dict(self._last_step) if self._last_step is not None else None),
            "recent_steps": [dict(item) for item in self._recent_steps],
            "observation_frame": (
                dict(self._last_observation_frame) if self._last_observation_frame is not None else None
            ),
            "recent_observation_frames": [dict(item) for item in self._recent_observation_frames],
            "first_invariant_violation": (
                dict(self._first_invariant_violation) if self._first_invariant_violation is not None else None
            ),
            "active_fight_generations": [int(item) for item in self._active_fight_generations],
            "fight_outcome_history": [dict(item) for item in self._fight_outcome_history],
            "active_observed_fight_instance_id": self._active_observed_fight_instance_id,
            "active_launch_transaction": (
                dict(mission_status.get("active_launch_transaction"))
                if isinstance(mission_status.get("active_launch_transaction"), dict)
                else None
            ),
            "launch_transition_pending": bool(mission_status.get("launch_transition_pending")),
            "fight_entry_status": (
                self.fight_workflow.last_entry_status()
                if callable(getattr(self.fight_workflow, "last_entry_status", None))
                else None
            ),
            "fight_entry_trace": (
                self.fight_workflow.entry_trace()
                if callable(getattr(self.fight_workflow, "entry_trace", None))
                else []
            ),
            "next_attempt_ordinal": (None if mission_status.get("stop_reason") else attempts + 1),
            "observed_fight_instance_id": self._observed_fight_instance_id,
            "active_observed_fight_instance_id": self._active_observed_fight_instance_id,
            "present_accounts": list((self._last_step or {}).get("present_accounts") or ()),
            "missing_accounts": list((self._last_step or {}).get("missing_accounts") or ()),
            "last_committed_fight_instance_id": self._last_committed_fight_instance_id,
            "post_fight_world_reentry_required": bool(getattr(self.world_workflow, "reentry_required", False)),
            "post_fight_world_reentry": (
                self.world_workflow.reentry_status()
                if callable(getattr(self.world_workflow, "reentry_status", None))
                else {"required": bool(getattr(self.world_workflow, "reentry_required", False))}
            ),
            "required_account_ids": sorted(required_ids),
            "fight_evidence_accounts": sorted(self._fight_evidence),
            "fight_evidence": evidence,
            "fight_evidence_complete": (
                set(self._fight_evidence) == required_ids
                if self._observed_fight_instance_id is not None
                else False
            ),
            "stop_reason": mission_status.get("stop_reason"),
            "budget": dict(mission_status.get("budget") or {}),
            "observability_errors": [dict(item) for item in self._observability_errors],
        }

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
import time
from typing import Callable, Mapping, Any


class ContinuityState(str, Enum):
    HEALTHY = "HEALTHY"
    HOLDING = "HOLDING"
    RECOVERING = "RECOVERING"
    TIMEOUT = "TIMEOUT"
    HARD_BLOCK = "HARD_BLOCK"


# These blockers mean the current generation/identity can still be trusted, but
# live protocol/canonical progress is too old to authorize automation. They are
# therefore safe to *wait through* without consuming mission watchdog budget.
_TRANSIENT_FRESHNESS_BLOCKERS = frozenset({
    "CAPTURE_STALE",
    "PROTOCOL_MESSAGES_STALE",
    "CANONICAL_STATE_STALE",
    # Parent-only early warning used during an already-observed fight. These do
    # not change ExecutionService health thresholds; they merely suspend child
    # progression before a shorter fight watchdog can beat the formal stale gate.
    "PROTOCOL_MESSAGES_CONTINUITY_SUSPECT",
    "CANONICAL_STATE_CONTINUITY_SUSPECT",
    # Short preparation-only directional warning after a semantically absent
    # Ready click. The account/process generation is still trusted; wait for the
    # server->client gameplay flow to recover before any further physical input.
    "SERVER_TO_CLIENT_READY_STALL",
    "SERVER_TO_CLIENT_READY_ACK_STALL",
    "SERVER_TO_CLIENT_ACTION_STALL",
})

# These are not connectivity stalls. Waiting indefinitely would hide a local
# process/generation/capture fault or a protocol transform defect.
_HARD_BLOCKERS = frozenset({
    "WINDOW_IDENTITY_CHANGED",
    "CAPTURE_STATUS_UNAVAILABLE",
    "CANONICAL_STATUS_UNAVAILABLE",
    "CAPTURE_NOT_CURRENT_SESSION",
    "PROTOCOL_MESSAGES_NOT_CURRENT_SESSION",
    "CANONICAL_STATE_NOT_CURRENT_SESSION",
})


@dataclass(frozen=True, slots=True)
class ContinuityAssessment:
    state: ContinuityState
    reason: str
    affected_accounts: tuple[str, ...]
    blockers_by_account: dict[str, tuple[str, ...]]
    hold_elapsed_seconds: float | None
    recovery_elapsed_seconds: float | None
    recovery_stability_seconds: float
    hold_timeout_seconds: float
    first_hold_monotonic: float | None
    hard_blockers: tuple[str, ...]
    transient_blockers: tuple[str, ...]

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["state"] = self.state.value
        return payload


class CampaignContinuityGuard:
    """Classify temporary live-truth loss without weakening execution safety.

    This guard never authorizes physical input. It only decides whether a parent
    campaign watchdog should be suspended while required account live truth is
    stale. ExecutionService and SharedFightManager remain the final safety gates.

    Recovery requires a continuous healthy interval so a single fresh packet
    cannot instantly reopen automation after a long transport outage.
    """

    def __init__(
        self,
        *,
        recovery_stability_seconds: float = 2.0,
        hold_timeout_seconds: float = 600.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.clock = clock
        self.recovery_stability_seconds = max(0.0, float(recovery_stability_seconds))
        self.hold_timeout_seconds = max(0.0, float(hold_timeout_seconds))
        self._hold_started: float | None = None
        self._recovery_started: float | None = None
        self._last_assessment: ContinuityAssessment | None = None
        self._episode_count = 0
        self._last_recovered_monotonic: float | None = None

    def reset(self) -> None:
        self._hold_started = None
        self._recovery_started = None
        self._last_assessment = None
        self._episode_count = 0
        self._last_recovered_monotonic = None

    @staticmethod
    def _normalize_health(health_by_account: Mapping[str, Mapping[str, Any]]) -> tuple[
        dict[str, tuple[str, ...]], tuple[str, ...], tuple[str, ...]
    ]:
        by_account: dict[str, tuple[str, ...]] = {}
        transient: list[str] = []
        hard: list[str] = []
        for account_id, raw_health in health_by_account.items():
            health = dict(raw_health or {})
            blockers = tuple(str(item) for item in (health.get("blockers") or ()))
            capture = dict(health.get("capture") or {}) if isinstance(health.get("capture"), Mapping) else {}
            # Canonical durability and protocol-transform faults are both hard
            # blockers, but they have different owners and must remain distinct
            # in diagnostics. Neither may be hidden behind connectivity waiting.
            if bool(capture.get("protocol_context_failure_active")):
                blockers = tuple(dict.fromkeys((*blockers, "PROTOCOL_CONTEXT_FAILURE_ACTIVE")))
            elif bool(capture.get("canonical_state_failure_active")):
                blockers = tuple(dict.fromkeys((*blockers, "CANONICAL_STATE_FAILURE_ACTIVE")))
            elif capture.get("last_error"):
                blockers = tuple(dict.fromkeys((*blockers, "PROTOCOL_TRANSFORM_ACTIVE")))
            if bool(capture.get("protocol_unclassified_active")) or int(capture.get("unclassified_count") or 0) > 0:
                blockers = tuple(dict.fromkeys((*blockers, "PROTOCOL_UNCLASSIFIED_ACTIVE")))
            by_account[str(account_id)] = blockers
            for blocker in blockers:
                if blocker in _TRANSIENT_FRESHNESS_BLOCKERS:
                    transient.append(f"{account_id}:{blocker}")
                elif blocker in _HARD_BLOCKERS or blocker == "PROTOCOL_TRANSFORM_ACTIVE":
                    hard.append(f"{account_id}:{blocker}")
                else:
                    # Unknown health blockers are conservatively hard. New
                    # blocker types must be explicitly classified before they can
                    # gain the right to suspend watchdogs indefinitely.
                    hard.append(f"{account_id}:{blocker}")
        return by_account, tuple(dict.fromkeys(transient)), tuple(dict.fromkeys(hard))

    def assess(self, health_by_account: Mapping[str, Mapping[str, Any]]) -> ContinuityAssessment:
        now = float(self.clock())
        by_account, transient, hard = self._normalize_health(health_by_account)
        affected = tuple(sorted(account for account, blockers in by_account.items() if blockers))

        if hard:
            self._recovery_started = None
            assessment = ContinuityAssessment(
                state=ContinuityState.HARD_BLOCK,
                reason="NON_RECOVERABLE_RUNTIME_HEALTH_BLOCKER",
                affected_accounts=affected,
                blockers_by_account=by_account,
                hold_elapsed_seconds=(None if self._hold_started is None else max(0.0, now - self._hold_started)),
                recovery_elapsed_seconds=None,
                recovery_stability_seconds=self.recovery_stability_seconds,
                hold_timeout_seconds=self.hold_timeout_seconds,
                first_hold_monotonic=self._hold_started,
                hard_blockers=hard,
                transient_blockers=transient,
            )
            self._last_assessment = assessment
            return assessment

        if transient:
            if self._hold_started is None:
                self._hold_started = now
                self._episode_count += 1
            self._recovery_started = None
            elapsed = max(0.0, now - self._hold_started)
            if self.hold_timeout_seconds > 0.0 and elapsed > self.hold_timeout_seconds:
                state = ContinuityState.TIMEOUT
                reason = "LIVE_TRUTH_CONTINUITY_TIMEOUT"
            else:
                state = ContinuityState.HOLDING
                reason = "LIVE_TRUTH_CONTINUITY_STALL"
            assessment = ContinuityAssessment(
                state=state,
                reason=reason,
                affected_accounts=affected,
                blockers_by_account=by_account,
                hold_elapsed_seconds=elapsed,
                recovery_elapsed_seconds=None,
                recovery_stability_seconds=self.recovery_stability_seconds,
                hold_timeout_seconds=self.hold_timeout_seconds,
                first_hold_monotonic=self._hold_started,
                hard_blockers=(),
                transient_blockers=transient,
            )
            self._last_assessment = assessment
            return assessment

        # No blockers. If an outage was active, require a short continuous
        # healthy interval before the parent resumes child workflows/input.
        if self._hold_started is not None:
            if self._recovery_started is None:
                self._recovery_started = now
            recovery_elapsed = max(0.0, now - self._recovery_started)
            if recovery_elapsed < self.recovery_stability_seconds:
                assessment = ContinuityAssessment(
                    state=ContinuityState.RECOVERING,
                    reason="LIVE_TRUTH_RECOVERY_STABILIZING",
                    affected_accounts=(),
                    blockers_by_account=by_account,
                    hold_elapsed_seconds=max(0.0, now - self._hold_started),
                    recovery_elapsed_seconds=recovery_elapsed,
                    recovery_stability_seconds=self.recovery_stability_seconds,
                    hold_timeout_seconds=self.hold_timeout_seconds,
                    first_hold_monotonic=self._hold_started,
                    hard_blockers=(),
                    transient_blockers=(),
                )
                self._last_assessment = assessment
                return assessment
            self._last_recovered_monotonic = now
            self._hold_started = None
            self._recovery_started = None

        assessment = ContinuityAssessment(
            state=ContinuityState.HEALTHY,
            reason="LIVE_TRUTH_HEALTHY",
            affected_accounts=(),
            blockers_by_account=by_account,
            hold_elapsed_seconds=None,
            recovery_elapsed_seconds=None,
            recovery_stability_seconds=self.recovery_stability_seconds,
            hold_timeout_seconds=self.hold_timeout_seconds,
            first_hold_monotonic=None,
            hard_blockers=(),
            transient_blockers=(),
        )
        self._last_assessment = assessment
        return assessment

    def status(self) -> dict:
        return {
            "episode_count": int(self._episode_count),
            "last_recovered_monotonic": self._last_recovered_monotonic,
            "recovery_stability_seconds": self.recovery_stability_seconds,
            "hold_timeout_seconds": self.hold_timeout_seconds,
            "last_assessment": (
                self._last_assessment.to_dict() if self._last_assessment is not None else None
            ),
        }

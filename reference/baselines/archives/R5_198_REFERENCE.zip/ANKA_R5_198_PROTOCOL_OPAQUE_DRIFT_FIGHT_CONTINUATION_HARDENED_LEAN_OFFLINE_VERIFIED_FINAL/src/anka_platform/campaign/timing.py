from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True, slots=True)
class CampaignTimingBudget:
    """Derived upper bounds for parent-owned campaign watchdog phases.

    A campaign watchdog must never expire before an operation it supervises has
    exhausted its own configured confirmation/settlement/recovery budget. The
    values here are conservative coordination bounds, not sleeps or fixed local
    poll ceilings. Phase-specific values prevent a long world-launch recovery
    budget from making unrelated combat/world stalls equally slow to detect.
    """

    configured_floor_seconds: float
    party_sync_seconds: float
    fight_joining_seconds: float
    fight_preparation_seconds: float
    fight_active_progress_seconds: float
    world_transition_progress_seconds: float
    world_launch_recovery_seconds: float
    post_fight_reentry_seconds: float
    selected_phase_timeout_seconds: float
    required_account_count: int
    world_launch_max_attempts: int
    phase_timeouts_seconds: dict[str, float]

    def to_dict(self) -> dict:
        return asdict(self)


def _action_budget(profile, *, margin_seconds: float = 0.0) -> float:
    return (
        float(profile.confirmation_timeout_seconds)
        + float(profile.settlement_timeout_seconds)
        + max(0.0, float(margin_seconds))
    )


def derive_campaign_timing_budget(config, *, required_account_count: int) -> CampaignTimingBudget:
    execution = config.execution
    reliability = config.reliability
    required = max(1, int(required_account_count))
    configured_floor = float(reliability.mission_phase_timeout_seconds)
    poll_margin = max(1.0, float(execution.poll_interval_seconds) * 10.0)

    join = execution.profile("join_fight")
    place = execution.profile("place_fighter")
    ready = execution.profile("ready_fight")
    challenge = execution.profile("choose_challenge")

    # World launch creates the leader's fight, so at most required-1 followers
    # need a join action. Keep a small observation/scheduling margin around each
    # serialized account operation.
    followers = max(0, required - 1)
    fight_joining = max(
        configured_floor,
        10.0 + followers * _action_budget(join, margin_seconds=poll_margin),
    )

    # Placement and Ready are serialized across required accounts. Challenge
    # selection is leader-owned but belongs to the same preparation lifecycle.
    fight_preparation = max(
        configured_floor,
        10.0
        + _action_budget(challenge, margin_seconds=poll_margin)
        + required
        * (
            _action_budget(place, margin_seconds=poll_margin)
            + _action_budget(ready, margin_seconds=poll_margin)
        ),
    )
    party_sync = max(fight_joining, fight_preparation)

    launch = execution.profile("launch_fight")
    attempts = max(1, int(execution.world_interaction_max_attempts))
    # semantic_grace is a lower bound on the acceptance observation window in
    # Execution; it overlaps confirmation rather than adding to it. Using max
    # mirrors the real transaction while remaining conservative around polling.
    acceptance_window = max(
        float(launch.confirmation_timeout_seconds),
        float(execution.world_interaction_semantic_grace_seconds),
    )
    per_launch_attempt = (
        acceptance_window
        + float(launch.settlement_timeout_seconds)
        + poll_margin
    )
    retry_backoff = max(0.0, float(execution.world_interaction_retry_backoff_seconds))
    world_launch_recovery = (
        5.0
        + attempts * per_launch_attempt
        + max(0, attempts - 1) * retry_backoff
    )

    change_map = execution.profile("change_map")
    # WorldWorkflow performs at most one physical edge for one account per RPC.
    # The runtime watchdog key is progress-aware, so every confirmed edge/account
    # advancement resets this budget instead of requiring a route-length guess.
    world_transition_progress = max(
        configured_floor,
        _action_budget(change_map, margin_seconds=5.0 + poll_margin),
    )

    combat_profiles = [
        execution.profile(name)
        for name in ("cast_spell", "move_fight", "end_turn")
        if name in execution.actions
    ]
    # A quarantined uncertain combat action can intentionally emit *no* further
    # input while waiting for natural turn expiration/authoritative handoff.  Give
    # that passive recovery a full turn-scale horizon instead of letting the outer
    # watchdog kill a healthy recovery transaction first.
    passive_combat_recovery_horizon = 45.0
    fight_active_progress = max(
        configured_floor,
        passive_combat_recovery_horizon,
        max((_action_budget(profile, margin_seconds=5.0 + poll_margin) for profile in combat_profiles), default=0.0),
    )

    # WorldWorkflow owns this bounded gate. Keep a parent scheduling margin so
    # the outer watchdog cannot win a race against the inner timeout.
    post_fight_reentry = max(
        configured_floor,
        float(reliability.world_reentry_timeout_seconds) + 5.0,
    )

    phase_timeouts = {
        "WORLD_CONVERGENCE": world_transition_progress,
        "WORLD_TRANSITION": world_transition_progress,
        "LAUNCHING_FIGHT": max(configured_floor, world_launch_recovery),
        "POST_FIGHT_WORLD_REENTRY": post_fight_reentry,
        "FIGHT_JOINING": fight_joining,
        "FIGHT_PREPARATION": fight_preparation,
        "FIGHT_ACTIVE": fight_active_progress,
        "POST_FIGHT": post_fight_reentry,
    }
    selected = max(configured_floor, *phase_timeouts.values())

    return CampaignTimingBudget(
        configured_floor_seconds=configured_floor,
        party_sync_seconds=party_sync,
        fight_joining_seconds=fight_joining,
        fight_preparation_seconds=fight_preparation,
        fight_active_progress_seconds=fight_active_progress,
        world_transition_progress_seconds=world_transition_progress,
        world_launch_recovery_seconds=world_launch_recovery,
        post_fight_reentry_seconds=post_fight_reentry,
        selected_phase_timeout_seconds=selected,
        required_account_count=required,
        world_launch_max_attempts=attempts,
        phase_timeouts_seconds=phase_timeouts,
    )

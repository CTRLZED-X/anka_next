from __future__ import annotations

import json
import time
from collections import deque
from dataclasses import asdict
from typing import Callable

from anka_platform.campaign.disposition import workflow_terminal_failure_code
from anka_platform.campaign.models import (
    CampaignActionTransaction,
    CampaignRecoveryObligation,
    CampaignWorkflowTransition,
)
from anka_platform.party.coordinator import FightOutcome, RunBudget


class CampaignEngine:
    """Single owner of campaign progress, watchdog phase and action disposition.

    The engine never performs game input and never interprets mechanics. It owns
    only mission-level state that must stay coherent across worker RPCs: run
    budget, stop reason, current watchdog phase, outcome history, and recent
    parent-observed action transactions/recovery attempts.
    """

    def __init__(
        self,
        *,
        budget: RunBudget,
        phase_timeout_seconds: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
        action_history_limit: int = 64,
    ) -> None:
        self.clock = clock
        self.phase_timeout_seconds = max(0.1, float(phase_timeout_seconds))
        self.phase_timeouts_seconds: dict[str, float] = {}
        self.budget = budget
        self._phase: str | None = None
        self._phase_key: str | None = None
        self._phase_started: float | None = None
        self._watchdog_hold_started: float | None = None
        self._watchdog_hold_reason: str | None = None
        self._watchdog_hold_context: dict | None = None
        self._watchdog_hold_total_seconds: float = 0.0
        self._watchdog_hold_episode_count: int = 0
        self._watchdog_last_hold_duration_seconds: float | None = None
        self._latest_failure: dict | None = None
        self._last_outcome: str | None = None
        self._sequence = 0
        self._actions: deque[CampaignActionTransaction] = deque(maxlen=max(8, int(action_history_limit)))
        self._workflow_sequence = 0
        self._workflow_transitions: deque[CampaignWorkflowTransition] = deque(maxlen=max(16, int(action_history_limit) * 2))
        self._workflow_current: dict[str, CampaignWorkflowTransition] = {}
        self._workflow_fingerprints: dict[str, tuple] = {}
        self._recoveries: dict[str, int] = {}
        self._pending_recoveries: dict[str, CampaignRecoveryObligation] = {}
        self._recovery_history: deque[CampaignRecoveryObligation] = deque(
            maxlen=max(8, int(action_history_limit))
        )

    def configure_phase_timeout(self, seconds: float) -> None:
        self.phase_timeout_seconds = max(0.1, float(seconds))

    def configure_phase_timeouts(self, values: dict[str, float] | None) -> None:
        normalized: dict[str, float] = {}
        for phase, seconds in dict(values or {}).items():
            normalized[str(phase)] = max(0.1, float(seconds))
        self.phase_timeouts_seconds = normalized

    def configure_budget(
        self,
        *,
        max_attempts: int,
        target_wins: int,
        stop_on_loss: bool,
        stop_on_unknown: bool,
    ) -> dict:
        self.budget = RunBudget(
            max_attempts=int(max_attempts),
            target_wins=int(target_wins),
            stop_on_loss=bool(stop_on_loss),
            stop_on_unknown=bool(stop_on_unknown),
        )
        return {"status": "CONFIGURED", "budget": asdict(self.budget)}

    def reset(self) -> dict:
        self.budget = RunBudget(
            max_attempts=self.budget.max_attempts,
            target_wins=self.budget.target_wins,
            stop_on_loss=self.budget.stop_on_loss,
            stop_on_unknown=self.budget.stop_on_unknown,
        )
        self._phase = None
        self._phase_key = None
        self._phase_started = None
        self._watchdog_hold_started = None
        self._watchdog_hold_reason = None
        self._watchdog_hold_context = None
        self._watchdog_hold_total_seconds = 0.0
        self._watchdog_hold_episode_count = 0
        self._watchdog_last_hold_duration_seconds = None
        self._latest_failure = None
        self._last_outcome = None
        self._sequence = 0
        self._actions.clear()
        self._workflow_sequence = 0
        self._workflow_transitions.clear()
        self._workflow_current.clear()
        self._workflow_fingerprints.clear()
        self._recoveries.clear()
        self._pending_recoveries.clear()
        self._recovery_history.clear()
        return {"status": "RESET", "budget": asdict(self.budget), "stop_reason": None}

    @staticmethod
    def _recovery_key(operation: str, account_id: str | None, target: dict | None) -> str:
        """Return a deterministic campaign-only recovery identity.

        Physical transaction IDs are intentionally per attempt.  A safe retry is
        therefore a *new* Execution transaction but part of the same campaign
        recovery chain.  The immutable operation/account/target tuple is the
        stable lineage needed to correlate those attempts without pretending the
        campaign owns physical-input identity.
        """
        normalized_target = json.dumps(dict(target or {}), sort_keys=True, separators=(",", ":"), default=str)
        return f"{str(operation)}|{str(account_id) if account_id is not None else '-'}|{normalized_target}"

    def _close_superseded_recoveries(self, tx: CampaignActionTransaction) -> None:
        """Close diagnostic recovery chains when the campaign selects a new target.

        Recovery obligations describe campaign intent; they do not authorize input.
        If a later transaction for the same operation/account uses a different
        immutable target, the old obligation cannot remain "pending" forever.
        Execution's durable ledger still independently enforces physical safety.
        """
        current_key = self._recovery_key(tx.operation, tx.account_id, tx.target)
        now = float(tx.observed_monotonic)
        for key, existing in tuple(self._pending_recoveries.items()):
            if key == current_key:
                continue
            if existing.operation != tx.operation or existing.account_id != tx.account_id:
                continue
            resolved = CampaignRecoveryObligation(
                recovery_key=existing.recovery_key,
                operation=existing.operation,
                account_id=existing.account_id,
                target=dict(existing.target),
                opened_sequence=existing.opened_sequence,
                opened_monotonic=existing.opened_monotonic,
                updated_sequence=tx.sequence,
                updated_monotonic=now,
                originating_transaction_id=existing.originating_transaction_id,
                originating_action_id=existing.originating_action_id,
                latest_transaction_id=tx.transaction_id or existing.latest_transaction_id,
                latest_action_id=tx.action_id or existing.latest_action_id,
                attempt_index=existing.attempt_index,
                retry_after_seconds=None,
                retry_not_before_monotonic_ms=None,
                first_missing_boundary=existing.first_missing_boundary,
                likely_owner=existing.likely_owner,
                state="CLOSED",
                resolution_status="ABANDONED_TARGET_CHANGED",
                resolution_failure_code="RECOVERY_TARGET_SUPERSEDED",
            )
            self._pending_recoveries.pop(key, None)
            self._recovery_history.append(resolved)

    def _update_recovery_obligation(self, tx: CampaignActionTransaction, result: dict) -> None:
        key = self._recovery_key(tx.operation, tx.account_id, tx.target)
        existing = self._pending_recoveries.get(key)
        now = float(tx.observed_monotonic)

        if tx.status == "RETRYABLE" and tx.retry_allowed is True:
            retry_not_before = result.get("retry_not_before_monotonic_ms")
            obligation = CampaignRecoveryObligation(
                recovery_key=key,
                operation=tx.operation,
                account_id=tx.account_id,
                target=dict(tx.target),
                opened_sequence=(existing.opened_sequence if existing is not None else tx.sequence),
                opened_monotonic=(existing.opened_monotonic if existing is not None else now),
                updated_sequence=tx.sequence,
                updated_monotonic=now,
                originating_transaction_id=(
                    existing.originating_transaction_id if existing is not None else tx.transaction_id
                ),
                originating_action_id=(
                    existing.originating_action_id if existing is not None else (tx.origin_action_id or tx.action_id)
                ),
                latest_transaction_id=tx.transaction_id,
                latest_action_id=tx.action_id,
                attempt_index=tx.attempt_index,
                retry_after_seconds=tx.retry_after_seconds,
                retry_not_before_monotonic_ms=(
                    int(retry_not_before) if retry_not_before is not None else None
                ),
                first_missing_boundary=tx.first_missing_boundary,
                likely_owner=tx.likely_owner,
                state="RETRY_DUE",
            )
            self._pending_recoveries[key] = obligation
            return

        if existing is None:
            return

        # Same recovery target observed again.  Keep the obligation explicit
        # through backoff/settlement, and only close it on a disposition that
        # actually resolves or abandons that target.
        if tx.status == "IN_PROGRESS":
            state = "WAITING_BACKOFF" if tx.failure_code == "WORLD_INTERACTION_RETRY_BACKOFF" else "SETTLING"
            self._pending_recoveries[key] = CampaignRecoveryObligation(
                recovery_key=existing.recovery_key,
                operation=existing.operation,
                account_id=existing.account_id,
                target=dict(existing.target),
                opened_sequence=existing.opened_sequence,
                opened_monotonic=existing.opened_monotonic,
                updated_sequence=tx.sequence,
                updated_monotonic=now,
                originating_transaction_id=existing.originating_transaction_id,
                originating_action_id=existing.originating_action_id,
                latest_transaction_id=tx.transaction_id or existing.latest_transaction_id,
                latest_action_id=tx.action_id or existing.latest_action_id,
                attempt_index=tx.attempt_index if tx.attempt_index is not None else existing.attempt_index,
                retry_after_seconds=tx.retry_after_seconds,
                retry_not_before_monotonic_ms=(
                    int(result["retry_not_before_monotonic_ms"])
                    if result.get("retry_not_before_monotonic_ms") is not None
                    else existing.retry_not_before_monotonic_ms
                ),
                first_missing_boundary=tx.first_missing_boundary or existing.first_missing_boundary,
                likely_owner=tx.likely_owner or existing.likely_owner,
                state=state,
            )
            return

        if tx.status in {"CONFIRMED", "FAILED", "UNCERTAIN", "BLOCKED"}:
            resolution_state = "RECOVERED" if tx.status == "CONFIRMED" else "CLOSED"
            resolved = CampaignRecoveryObligation(
                recovery_key=existing.recovery_key,
                operation=existing.operation,
                account_id=existing.account_id,
                target=dict(existing.target),
                opened_sequence=existing.opened_sequence,
                opened_monotonic=existing.opened_monotonic,
                updated_sequence=tx.sequence,
                updated_monotonic=now,
                originating_transaction_id=existing.originating_transaction_id,
                originating_action_id=existing.originating_action_id,
                latest_transaction_id=tx.transaction_id or existing.latest_transaction_id,
                latest_action_id=tx.action_id or existing.latest_action_id,
                attempt_index=tx.attempt_index if tx.attempt_index is not None else existing.attempt_index,
                retry_after_seconds=None,
                retry_not_before_monotonic_ms=None,
                first_missing_boundary=tx.first_missing_boundary or existing.first_missing_boundary,
                likely_owner=tx.likely_owner or existing.likely_owner,
                state=resolution_state,
                resolution_status=tx.status,
                resolution_failure_code=tx.failure_code,
            )
            self._pending_recoveries.pop(key, None)
            self._recovery_history.append(resolved)

    def set_watchdog_hold(
        self,
        active: bool,
        *,
        reason: str | None = None,
        context: dict | None = None,
    ) -> dict:
        """Suspend/resume mission watchdog time without altering lifecycle state.

        A connectivity/live-truth outage must never consume the same timeout
        budget used to diagnose a genuinely stuck gameplay phase.  The campaign
        remains fail-closed while held; this method changes only elapsed-time
        accounting.  On release, the current phase start is shifted by the exact
        held duration so previously consumed phase budget is preserved.
        """
        now = float(self.clock())
        if bool(active):
            if self._watchdog_hold_started is None:
                self._watchdog_hold_started = now
                self._watchdog_hold_episode_count += 1
            self._watchdog_hold_reason = str(reason or "WATCHDOG_HOLD")
            self._watchdog_hold_context = dict(context or {})
        elif self._watchdog_hold_started is not None:
            duration = max(0.0, now - float(self._watchdog_hold_started))
            self._watchdog_hold_total_seconds += duration
            self._watchdog_last_hold_duration_seconds = duration
            if self._phase_started is not None:
                self._phase_started = float(self._phase_started) + duration
            self._watchdog_hold_started = None
            self._watchdog_hold_reason = None
            self._watchdog_hold_context = None
        return self.watchdog_hold_status()

    def watchdog_hold_status(self) -> dict:
        now = float(self.clock())
        active = self._watchdog_hold_started is not None
        current = (
            max(0.0, now - float(self._watchdog_hold_started))
            if self._watchdog_hold_started is not None
            else None
        )
        return {
            "active": active,
            "reason": self._watchdog_hold_reason,
            "context": dict(self._watchdog_hold_context or {}) or None,
            "started_monotonic": self._watchdog_hold_started,
            "current_hold_seconds": current,
            "total_completed_hold_seconds": self._watchdog_hold_total_seconds,
            "episode_count": self._watchdog_hold_episode_count,
            "last_hold_duration_seconds": self._watchdog_last_hold_duration_seconds,
        }

    def observe_phase(self, phase: str, *, key: str | int | None = None) -> dict:
        now = float(self.clock())
        token = str(phase)
        phase_key = None if key is None else str(key)
        if token != self._phase or phase_key != self._phase_key or self._phase_started is None:
            self._phase = token
            self._phase_key = phase_key
            self._phase_started = now
            timeout_seconds = float(self.phase_timeouts_seconds.get(token, self.phase_timeout_seconds))
            return {
                "status": "HELD" if self._watchdog_hold_started is not None else "ACTIVE",
                "phase": token,
                "key": phase_key,
                "elapsed_seconds": 0.0,
                "timeout_seconds": timeout_seconds,
                "watchdog_hold": self.watchdog_hold_status(),
            }
        timeout_seconds = float(self.phase_timeouts_seconds.get(token, self.phase_timeout_seconds))
        effective_now = (
            float(self._watchdog_hold_started)
            if self._watchdog_hold_started is not None
            else now
        )
        elapsed = max(0.0, effective_now - float(self._phase_started))
        if self._watchdog_hold_started is not None:
            return {
                "status": "HELD",
                "phase": token,
                "key": phase_key,
                "elapsed_seconds": elapsed,
                "timeout_seconds": timeout_seconds,
                "watchdog_hold": self.watchdog_hold_status(),
            }
        if elapsed > timeout_seconds:
            self._latest_failure = {
                "status": "TIMEOUT",
                "failure_code": "MISSION_TIMEOUT",
                "phase": token,
                "key": phase_key,
                "elapsed_seconds": elapsed,
                "timeout_seconds": timeout_seconds,
                "configured_default_timeout_seconds": self.phase_timeout_seconds,
                "watchdog_hold": self.watchdog_hold_status(),
            }
            return dict(self._latest_failure)
        return {
            "status": "ACTIVE",
            "phase": token,
            "key": phase_key,
            "elapsed_seconds": elapsed,
            "timeout_seconds": timeout_seconds,
            "watchdog_hold": self.watchdog_hold_status(),
        }

    def note_runtime_failure(
        self, *, failure_code: str, detail: str | None = None,
        first_missing_boundary: str | None = None, likely_owner: str | None = None,
        runtime_context: dict | None = None,
    ) -> dict:
        """Persist a parent-runtime failure before the worker can rewrite it."""
        context = dict(runtime_context or {})
        self._latest_failure = {
            "status": "FAILED",
            "failure_code": str(failure_code),
            "detail": (str(detail) if detail is not None else None),
            "first_missing_boundary": (
                str(first_missing_boundary) if first_missing_boundary is not None else None
            ),
            "likely_owner": (str(likely_owner) if likely_owner is not None else "CAMPAIGN_RUNTIME"),
            "run_id": (str(context.get("run_id")) if context.get("run_id") is not None else None),
            "request_id": (str(context.get("request_id")) if context.get("request_id") is not None else None),
        }
        return dict(self._latest_failure)

    def record_outcome(self, outcome: FightOutcome | str) -> dict:
        resolved = outcome if isinstance(outcome, FightOutcome) else FightOutcome(str(outcome))
        self.budget = self.budget.record(resolved)
        self._last_outcome = resolved.value
        if self.budget.should_stop:
            # Terminal campaign truth must replace the last in-fight watchdog
            # phase. Otherwise a successful TARGET_WINS_REACHED run can remain
            # projected as FIGHT_ACTIVE even though the worker has completed.
            self._phase = "CAMPAIGN_COMPLETE"
            self._phase_key = str(self.budget.stop_reason or "CAMPAIGN_STOPPED")
            self._phase_started = float(self.clock())
        return {
            "status": "STOP" if self.budget.should_stop else "CONTINUE",
            "outcome": resolved.value,
            "budget": asdict(self.budget),
            "stop_reason": self.budget.stop_reason,
        }

    def note_action(
        self,
        *,
        operation: str,
        account_id: str | None,
        result: dict,
        target: dict | None = None,
        runtime_context: dict | None = None,
    ) -> dict:
        result = dict(result or {})
        runtime_context = dict(runtime_context or {})
        self._sequence += 1
        status = str(result.get("status") or "UNKNOWN")
        failure_code = str(result.get("failure_code")) if result.get("failure_code") is not None else None
        retry_allowed = result.get("retry_allowed")
        tx = CampaignActionTransaction(
            sequence=self._sequence,
            operation=str(operation),
            account_id=(str(account_id) if account_id is not None else None),
            status=status,
            failure_code=failure_code,
            detail=(str(result.get("detail")) if result.get("detail") is not None else None),
            action_id=(str(result.get("action_id")) if result.get("action_id") is not None else None),
            transaction_id=(str(result.get("transaction_id")) if result.get("transaction_id") is not None else None),
            origin_action_id=(str(result.get("origin_action_id")) if result.get("origin_action_id") is not None else None),
            request_id=(str(runtime_context.get("request_id")) if runtime_context.get("request_id") is not None else None),
            run_id=(str(runtime_context.get("run_id")) if runtime_context.get("run_id") is not None else None),
            target=dict(target or {}),
            attempt_index=(int(result["attempt_index"]) if result.get("attempt_index") is not None else None),
            retry_allowed=(bool(retry_allowed) if retry_allowed is not None else None),
            retry_after_seconds=(float(result["retry_after_seconds"]) if result.get("retry_after_seconds") is not None else None),
            semantic_request_state=(str(result.get("semantic_request_state")) if result.get("semantic_request_state") is not None else None),
            semantic_request_kind=(str(result.get("semantic_request_kind")) if result.get("semantic_request_kind") is not None else None),
            first_missing_boundary=(str(result.get("first_missing_boundary")) if result.get("first_missing_boundary") is not None else None),
            likely_owner=(str(result.get("likely_owner")) if result.get("likely_owner") is not None else None),
            observed_monotonic=float(self.clock()),
        )
        self._actions.append(tx)
        self._close_superseded_recoveries(tx)
        if status == "RETRYABLE" and retry_allowed is True:
            self._recoveries[str(operation)] = int(self._recoveries.get(str(operation), 0)) + 1
        self._update_recovery_obligation(tx, result)
        if status in {"FAILED", "UNCERTAIN"}:
            self._latest_failure = {
                "status": status,
                "failure_code": failure_code or f"ACTION_{status}",
                "operation": str(operation),
                "account_id": tx.account_id,
                "action_id": tx.action_id,
                "request_id": tx.request_id,
                "run_id": tx.run_id,
                "detail": tx.detail,
                "first_missing_boundary": tx.first_missing_boundary,
                "likely_owner": tx.likely_owner,
            }
        return tx.to_dict()


    def note_workflow(
        self,
        *,
        domain: str,
        result: dict,
        runtime_context: dict | None = None,
    ) -> dict:
        """Record a world/fight lifecycle observation in the parent campaign.

        Repeated identical polling observations update the current domain state
        but do not flood the transition history. A change in state, reason,
        action disposition, failure code, account, or progress token creates one
        ordered transition.
        """
        domain_key = str(domain).strip().lower()
        if domain_key not in {"world", "fight"}:
            raise ValueError(f"unsupported campaign workflow domain: {domain!r}")
        payload = dict(result or {})
        action = payload.get("action") if isinstance(payload.get("action"), dict) else {}
        runtime_context = dict(runtime_context or {})
        state = str(payload.get("state") or "UNKNOWN")
        reason = str(payload.get("reason")) if payload.get("reason") is not None else None
        action_status = str(action.get("status")) if action.get("status") is not None else None
        failure_code = str(action.get("failure_code")) if action.get("failure_code") is not None else None
        first_missing_boundary = (
            str(action.get("first_missing_boundary")) if action.get("first_missing_boundary") is not None else None
        )
        likely_owner = str(action.get("likely_owner")) if action.get("likely_owner") is not None else None
        account_id = str(payload.get("account_id")) if payload.get("account_id") is not None else None
        progress_token = str(payload.get("progress_token")) if payload.get("progress_token") is not None else None
        next_allowed = tuple(str(item) for item in (payload.get("next_allowed_commands") or ()))
        fingerprint = (
            state, reason, action_status, failure_code, first_missing_boundary, likely_owner,
            account_id, progress_token, next_allowed,
        )
        previous = self._workflow_current.get(domain_key)
        if self._workflow_fingerprints.get(domain_key) == fingerprint and previous is not None:
            # Preserve transition ordering while still exposing the latest
            # observation time/run correlation for the current state.
            current = CampaignWorkflowTransition(
                sequence=previous.sequence,
                domain=domain_key,
                state=state,
                reason=reason,
                action_status=action_status,
                failure_code=failure_code,
                first_missing_boundary=first_missing_boundary,
                likely_owner=likely_owner,
                account_id=account_id,
                progress_token=progress_token,
                next_allowed_commands=next_allowed,
                run_id=(str(runtime_context.get("run_id")) if runtime_context.get("run_id") is not None else previous.run_id),
                request_id=(str(runtime_context.get("request_id")) if runtime_context.get("request_id") is not None else previous.request_id),
                observed_monotonic=float(self.clock()),
            )
            self._workflow_current[domain_key] = current
            return current.to_dict()

        self._workflow_sequence += 1
        transition = CampaignWorkflowTransition(
            sequence=self._workflow_sequence,
            domain=domain_key,
            state=state,
            reason=reason,
            action_status=action_status,
            failure_code=failure_code,
            first_missing_boundary=first_missing_boundary,
            likely_owner=likely_owner,
            account_id=account_id,
            progress_token=progress_token,
            next_allowed_commands=next_allowed,
            run_id=(str(runtime_context.get("run_id")) if runtime_context.get("run_id") is not None else None),
            request_id=(str(runtime_context.get("request_id")) if runtime_context.get("request_id") is not None else None),
            observed_monotonic=float(self.clock()),
        )
        self._workflow_fingerprints[domain_key] = fingerprint
        self._workflow_current[domain_key] = transition
        self._workflow_transitions.append(transition)
        terminal_failure_code = workflow_terminal_failure_code(domain_key, payload)
        if terminal_failure_code:
            self._latest_failure = {
                "status": action_status or state,
                "failure_code": terminal_failure_code,
                "workflow_domain": domain_key,
                "workflow_state": state,
                "detail": reason,
                "first_missing_boundary": first_missing_boundary,
                "likely_owner": likely_owner,
                "run_id": transition.run_id,
                "request_id": transition.request_id,
            }
        return transition.to_dict()

    def runtime_status(self) -> dict:
        """Return the small operational state needed by the campaign hot path.

        Full ``status()`` intentionally includes recent action/workflow/recovery
        histories for diagnostics.  Rebuilding those histories several times per
        gameplay tick made runtime cost grow with campaign history.
        """
        return {
            "phase": self._phase,
            "phase_key": self._phase_key,
            "phase_started_monotonic": self._phase_started,
            "phase_timeout_seconds": self.phase_timeout_seconds,
            "active_phase_timeout_seconds": (
                float(self.phase_timeouts_seconds.get(self._phase, self.phase_timeout_seconds))
                if self._phase is not None else None
            ),
            "budget": asdict(self.budget),
            "stop_reason": self.budget.stop_reason,
            "last_outcome": self._last_outcome,
            "latest_failure": dict(self._latest_failure) if self._latest_failure else None,
            # R5.165: continuity decisions need the current transaction without
            # rebuilding the full diagnostic action history on every hot-path tick.
            "latest_action_transaction": (self._actions[-1].to_dict() if self._actions else None),
            "watchdog_hold": self.watchdog_hold_status(),
        }

    def status(self) -> dict:
        latest_action = self._actions[-1].to_dict() if self._actions else None
        return {
            "phase": self._phase,
            "phase_key": self._phase_key,
            "phase_started_monotonic": self._phase_started,
            "phase_timeout_seconds": self.phase_timeout_seconds,
            "phase_timeouts_seconds": dict(self.phase_timeouts_seconds),
            "active_phase_timeout_seconds": (
                float(self.phase_timeouts_seconds.get(self._phase, self.phase_timeout_seconds))
                if self._phase is not None else None
            ),
            "budget": asdict(self.budget),
            "stop_reason": self.budget.stop_reason,
            "last_outcome": self._last_outcome,
            "latest_failure": dict(self._latest_failure) if self._latest_failure else None,
            "latest_action_transaction": latest_action,
            "recent_action_transactions": [item.to_dict() for item in self._actions],
            "workflow": {key: item.to_dict() for key, item in self._workflow_current.items()},
            "recent_workflow_transitions": [item.to_dict() for item in self._workflow_transitions],
            "recovery_counts": dict(self._recoveries),
            "pending_recoveries": [
                item.to_dict() for _, item in sorted(self._pending_recoveries.items(), key=lambda pair: pair[0])
            ],
            "recent_recoveries": [item.to_dict() for item in self._recovery_history],
            "watchdog_hold": self.watchdog_hold_status(),
        }

from __future__ import annotations

import json
from typing import Mapping


# These preparation states are fail-closed terminal boundaries. Other BLOCKED
# preparation results (for example FIGHT_ENTRY_BARRIER_NOT_READY) are ordinary
# convergence observations and must never become a sticky campaign failure.
_TERMINAL_PREPARATION_FAILURES = frozenset({
    "PREPARATION_TIMEOUT",
    "PREPARATION_AUTO_STARTED_INCOMPLETE",
    "READY_ACK_TIMEOUT",
    "READY_REQUEST_RETRY_EXHAUSTED",
    "READY_RECOVERY_EXHAUSTED",
    "SHARED_FIGHT_CONFLICT",
    "LOCAL_FIGHTER_IDENTITY_CONFLICT",
    "FIGHT_GEOMETRY_UNAVAILABLE",
})

_TERMINAL_ACTIVE_STATUSES = frozenset({"FAILED", "BLOCKED", "BLOCKED_STALLED"})
_TERMINAL_WORLD_STATUSES = frozenset({"FAILED", "UNCERTAIN", "TIMEOUT", "INVALID"})

# These failures describe the process-wide physical-control lease itself, not
# an ordinary gameplay/convergence blocker.  Once one reaches a production
# campaign action there is no useful polling loop left for the campaign to run:
# physical input cannot resume until an operator/runtime owner explicitly
# repairs or re-arms control.  Treating these as temporary WORLD blockers was
# the reason the R5.163 live incident emitted 100+ identical acquisition rows
# and finally surfaced as the much less useful MISSION_TIMEOUT.
_TERMINAL_CONTROL_FAILURES = frozenset({
    "CONTROL_AUTHORITY_DISARMED",
    "CONTROL_AUTHORITY_BUSY",
    "CONTROL_RUN_REQUIRED",
    "CONTROL_RUN_NOT_BOUND",
    "CONTROL_RUN_MISMATCH",
    "CONTROL_SESSION_MISMATCH",
    "CONTROL_SCRIPT_MISMATCH",
})

# Execution-journal rows use ``failure_code`` for both errors and bounded
# progress states. Only these dispositions are failure candidates. In
# particular IN_PROGRESS / RETRYABLE are explicitly non-terminal even when they
# carry codes such as WORLD_INTERACTION_SETTLING.
_TERMINAL_ACTION_STATUSES = frozenset({
    "FAILED",
    "UNCERTAIN",
    "TIMEOUT",
    "INVALID",
    "BLOCKED",
    "BLOCKED_STALLED",
    "CONFIRMED_UNSETTLED",
})


def preparation_terminal_failure_code(status: str | None, failure_code: str | None) -> str | None:
    """Classify one preparation disposition using the shared terminality contract."""
    normalized_status = str(status or "").strip().upper()
    code = str(failure_code or "").strip()
    if normalized_status == "BLOCKED" and code in _TERMINAL_PREPARATION_FAILURES:
        return code
    return None


def workflow_terminal_failure_code(domain: str, result: Mapping | None) -> str | None:
    """Return the terminal failure code for one workflow result, if any.

    This function is the single semantic authority shared by CampaignEngine and
    CampaignRuntimeController. It deliberately separates a *temporary blocker*
    from a *terminal failure*. Keeping that distinction in one place prevents a
    normal convergence wait from becoming a sticky operator problem while also
    preventing the runtime and diagnostics layers from drifting apart.
    """

    payload = dict(result or {})
    action = payload.get("action") if isinstance(payload.get("action"), Mapping) else {}
    action = dict(action or {})
    nested = action.get("action_result") if isinstance(action.get("action_result"), Mapping) else {}
    nested = dict(nested or {})
    domain_token = str(domain or "").strip().upper()
    state = str(payload.get("state") or "").strip().upper()
    status = str(action.get("status") or "UNKNOWN").strip().upper()
    reason = str(
        action.get("failure_code")
        or action.get("join_failure_code")
        or nested.get("failure_code")
        or action.get("reason")
        or payload.get("reason")
        or "UNKNOWN"
    )

    # Control-authority failures are terminal independently of workflow state.
    # A WORLD acquisition may legitimately use BLOCKED for temporary projection
    # or admission races, so BLOCKED cannot be terminal in general.  These exact
    # codes are different: they prove that the process currently has no valid
    # physical-control lease and therefore cannot make progress by observing the
    # same workflow again.
    if reason in _TERMINAL_CONTROL_FAILURES:
        return reason

    if state == "FAILED":
        return str(action.get("failure_code") or action.get("join_failure_code") or reason or f"{domain_token}_WORKFLOW_FAILED")

    if domain_token == "FIGHT" and state in {"ENTRY_BARRIER", "CHALLENGE", "PLACEMENT", "READY"}:
        code = preparation_terminal_failure_code(status, action.get("failure_code"))
        if code is not None:
            return code
        if status not in {"IN_PROGRESS", "CONFIRMED", "BLOCKED", "WAIT", "READY"}:
            return "PREPARATION_INVALID_STATUS"
        return None

    if domain_token == "FIGHT" and state == "ACTIVE" and status in _TERMINAL_ACTIVE_STATUSES:
        return str(action.get("failure_code") or f"COMBAT_{status}")

    if domain_token == "WORLD" and status in _TERMINAL_WORLD_STATUSES:
        return str(action.get("failure_code") or f"WORLD_ACTION_{status}")

    return None


def action_row_is_terminal_failure(row: Mapping | None) -> bool:
    """True only when an execution/action journal row is a failure candidate.

    ``failure_code`` is historically overloaded in the journal. A non-empty code
    alone is therefore not evidence of failure: IN_PROGRESS
    WORLD_INTERACTION_SETTLING and RETRYABLE states are expected recovery/progress
    observations. Exporters should use this disposition classifier rather than
    testing the code field directly.
    """

    item = dict(row or {})
    status = str(item.get("status") or "").strip().upper()
    code = str(item.get("failure_code") or "").strip().upper()
    if status not in _TERMINAL_ACTION_STATUSES:
        return False
    # Decode the typed action result once so terminality is based on semantic
    # delivery/recovery state rather than the historically overloaded outer
    # ``status``/``failure_code`` columns.
    result = item.get("result") if isinstance(item.get("result"), Mapping) else item
    if result is item and item.get("result_json"):
        try:
            decoded = json.loads(str(item.get("result_json")))
            if isinstance(decoded, Mapping):
                result = decoded
        except Exception:
            pass

    # A BLOCKED row is not terminal when Execution deliberately failed closed
    # *before the semantic action was sent* and explicitly permits replan/retry.
    # R5.159 live evidence exposed this with MOVE_ADMISSION_UNKNOWN: the action
    # sent no mouse/game request, FightAI replanned, and the campaign reached its
    # target wins. Exporters must preserve the row as an anomaly without turning
    # a successful campaign into FAILURE_OBSERVED.
    if status == "BLOCKED":
        # Historical projection-race rows predate typed retry/send fields. Their
        # shared contract has always been non-terminal, so keep that invariant.
        if code in {"PROJECTION_STALE", "PROJECTION_ENTITY_UNVERIFIED"}:
            return False
        physical = str(
            result.get("physical_send_state")
            or item.get("physical_send_state")
            or ""
        ).strip().upper()
        semantic_cast = str(result.get("semantic_cast_send_state") or "").strip().upper()
        retry_allowed = result.get("retry_allowed") is True
        safe_replan = result.get("safe_replan") is True
        reconciliation_required = result.get("reconciliation_required") is True
        input_quarantined = result.get("input_quarantined") is True

        # Pure acquisition/admission/projection races with no physical semantic
        # input are normal fail-closed recovery observations.
        if code in {
            "PROJECTION_STALE", "PROJECTION_ENTITY_UNVERIFIED", "WINDOW_FOCUS_FAILED",
            "CAST_ADMISSION_REJECTED", "CAST_ADMISSION_UNKNOWN",
            "MOVE_ADMISSION_REJECTED", "MOVE_ADMISSION_UNKNOWN",
            "FIGHT_GEOMETRY_PENDING", "FIGHT_STATE_CHANGED_BEFORE_INPUT",
        } and retry_allowed and physical in {"", "NOT_SENT"}:
            return False

        # CAST can have a harmless slot-selection click before its target is
        # blocked. If the semantic target was NOT_SENT, the UI was neutralized,
        # and Execution explicitly marks safe_replan, the row is recovered rather
        # than terminal even though ``physical_send_state`` reflects the slot.
        if safe_replan and semantic_cast == "NOT_SENT" and not reconciliation_required and not input_quarantined:
            neutral = result.get("ui_neutralization") if isinstance(result.get("ui_neutralization"), Mapping) else {}
            if neutral.get("neutralized") is True:
                return False

        if code == "READY_PREARMED_FOREGROUND_LOST":
            ready_evidence = result.get("ready_input_evidence") if isinstance(result.get("ready_input_evidence"), Mapping) else {}
            physical = str(physical or ready_evidence.get("physical_send_state") or "").strip().upper()
            if retry_allowed and physical in {"", "NOT_SENT"}:
                # R5.130 deliberately loses no game action here: the pre-armed Ready
                # click is cancelled when foreground ownership changed, then the lane
                # is re-armed on a later tick. Preserve the row as recovery evidence,
                # but it is not a terminal campaign failure candidate.
                return False
    # Terminal status is independently meaningful even if an older/corrupt
    # journal row lost its typed failure code. Diagnostics must still surface
    # FAILED/UNCERTAIN/TIMEOUT/etc. rather than silently treating it as success.
    return True


__all__ = ["preparation_terminal_failure_code", "workflow_terminal_failure_code", "action_row_is_terminal_failure"]

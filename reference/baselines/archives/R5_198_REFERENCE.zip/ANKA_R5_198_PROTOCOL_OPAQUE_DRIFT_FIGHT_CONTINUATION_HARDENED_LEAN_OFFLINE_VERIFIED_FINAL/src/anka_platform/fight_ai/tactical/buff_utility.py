from __future__ import annotations

from dataclasses import dataclass

from anka_game_kernel.domain.characteristics import CharacteristicKey
from anka_game_kernel.domain.ids import ActorId
from anka_game_kernel.domain.mechanics import MechanicKey


# Only effects whose tactical direction is mechanically unambiguous belong here.
# This is deliberately a semantic whitelist, not a spell-id table.
_OFFENSIVE_SCALE: dict[CharacteristicKey, float] = {
    CharacteristicKey.STRENGTH: 250.0,
    CharacteristicKey.INTELLIGENCE: 250.0,
    CharacteristicKey.CHANCE: 250.0,
    CharacteristicKey.AGILITY: 250.0,
    CharacteristicKey.POWER: 250.0,
    CharacteristicKey.CRITICAL_CHANCE: 15.0,
    CharacteristicKey.CRITICAL_DAMAGE: 50.0,
    CharacteristicKey.PUSHBACK_DAMAGE: 150.0,
    CharacteristicKey.FIXED_DAMAGE: 50.0,
    CharacteristicKey.PERCENT_DAMAGE: 20.0,
    CharacteristicKey.DISTANCE_DAMAGE_PERCENT: 20.0,
}


def amount_min(occurrence) -> float | None:
    amount = getattr(getattr(occurrence, "parameters", None), "amount", None)
    value = getattr(amount, "minimum", None)
    return None if value is None else float(value)


def characteristic_key(occurrence) -> CharacteristicKey | None:
    if getattr(occurrence, "mechanic_key", None) is not MechanicKey.CHARACTERISTIC_CHANGE:
        return None
    raw = getattr(getattr(occurrence, "parameters", None), "characteristic", None)
    if isinstance(raw, CharacteristicKey):
        return raw
    try:
        return CharacteristicKey(str(getattr(raw, "value", raw)))
    except (TypeError, ValueError):
        return None


def offensive_characteristic_signal(occurrence) -> float:
    key = characteristic_key(occurrence)
    amount = amount_min(occurrence)
    if key is None or amount is None or amount == 0.0:
        return 0.0
    scale = _OFFENSIVE_SCALE.get(key)
    if scale is None:
        return 0.0
    # Preserve sign and cap one individual effect so unusually large static values
    # do not dominate all positional/safety reasoning.
    return max(-2.0, min(2.0, amount / scale))


def is_positive_offensive_buff(occurrence) -> bool:
    return offensive_characteristic_signal(occurrence) > 0.0


def is_negative_offensive_debuff(occurrence) -> bool:
    return offensive_characteristic_signal(occurrence) < 0.0


@dataclass(frozen=True, slots=True)
class CertifiedBuffUtility:
    self_offensive_buff: float = 0.0
    ally_offensive_buff: float = 0.0
    enemy_offensive_debuff: float = 0.0
    self_range_sacrifice: float = 0.0
    positive_offensive_actor_ids: tuple[int, ...] = ()
    negative_offensive_actor_ids: tuple[int, ...] = ()

    @property
    def permits_self_tradeoff(self) -> bool:
        return self.self_offensive_buff > 0.0 and self.self_range_sacrifice > 0.0

    @property
    def material(self) -> bool:
        return any((
            self.self_offensive_buff > 0.0,
            self.ally_offensive_buff > 0.0,
            self.enemy_offensive_debuff > 0.0,
        ))


def analyze_certified_buff_utility(
    preview,
    *,
    caster_id: int,
    ally_ids: set[ActorId] | set[int],
    enemy_ids: set[ActorId] | set[int],
) -> CertifiedBuffUtility:
    resolution = getattr(preview, "effect_resolution", None)
    if resolution is None:
        return CertifiedBuffUtility()

    caster = int(caster_id)
    allies = {int(item) for item in ally_ids}
    enemies = {int(item) for item in enemy_ids}
    self_buff = 0.0
    ally_buff = 0.0
    enemy_debuff = 0.0
    range_sacrifice = 0.0
    positive_actors: set[int] = set()
    negative_actors: set[int] = set()

    for step in getattr(resolution, "steps", ()) or ():
        occurrence = getattr(step, "occurrence", None)
        if occurrence is None:
            continue
        targets = {int(item) for item in getattr(step, "eligible_actor_ids", ()) or ()}
        if occurrence.mechanic_key in {MechanicKey.RANGE_CHANGE, MechanicKey.SPELL_RANGE_CHANGE}:
            amount = amount_min(occurrence)
            if amount is not None and amount < 0.0 and caster in targets:
                range_sacrifice += min(2.0, abs(amount) / 3.0)
            continue

        signal = offensive_characteristic_signal(occurrence)
        if signal > 0.0:
            for actor_id in targets:
                positive_actors.add(actor_id)
                if actor_id == caster:
                    self_buff += signal
                elif actor_id in allies:
                    ally_buff += signal
        elif signal < 0.0:
            magnitude = abs(signal)
            for actor_id in targets:
                negative_actors.add(actor_id)
                if actor_id in enemies:
                    enemy_debuff += magnitude

    return CertifiedBuffUtility(
        self_offensive_buff=min(4.0, self_buff),
        ally_offensive_buff=min(4.0, ally_buff),
        enemy_offensive_debuff=min(4.0, enemy_debuff),
        self_range_sacrifice=min(2.0, range_sacrifice),
        positive_offensive_actor_ids=tuple(sorted(positive_actors)),
        negative_offensive_actor_ids=tuple(sorted(negative_actors)),
    )


def self_harm_is_only_range_sacrifice(preview, *, caster_id: int) -> bool:
    """True only when every mechanically harmful self occurrence is a negative range effect."""
    resolution = getattr(preview, "effect_resolution", None)
    if resolution is None:
        return False
    caster = int(caster_id)
    saw_harm = False
    for step in getattr(resolution, "steps", ()) or ():
        occurrence = getattr(step, "occurrence", None)
        if occurrence is None or caster not in {int(item) for item in getattr(step, "eligible_actor_ids", ()) or ()}:
            continue
        kind = occurrence.mechanic_key
        amount = amount_min(occurrence)
        harmful = False
        if kind in {MechanicKey.DAMAGE, MechanicKey.LIFESTEAL, MechanicKey.PUSH, MechanicKey.PULL, MechanicKey.SWAP, MechanicKey.RECOIL}:
            harmful = True
        elif kind in {MechanicKey.AP_CHANGE, MechanicKey.MP_CHANGE, MechanicKey.RANGE_CHANGE, MechanicKey.SPELL_RANGE_CHANGE}:
            harmful = amount is not None and amount < 0.0
        elif kind is MechanicKey.CHARACTERISTIC_CHANGE:
            harmful = is_negative_offensive_debuff(occurrence)
        if not harmful:
            continue
        saw_harm = True
        if kind not in {MechanicKey.RANGE_CHANGE, MechanicKey.SPELL_RANGE_CHANGE} or amount is None or amount >= 0.0:
            return False
    return saw_harm

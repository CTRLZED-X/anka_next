from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from anka_platform.core.fight.decision_contract import FightDecision, FightDecisionKind
from anka_platform.core.fight.planner_contract import PassiveInvocationContext


class PassiveDirectiveKind(str, Enum):
    END_TURN = "END_TURN"
    MOVE_TO_CELL = "MOVE_TO_CELL"


@dataclass(frozen=True, slots=True)
class PassiveDirective:
    kind: PassiveDirectiveKind = PassiveDirectiveKind.END_TURN
    target_cell_id: int | None = None

    @classmethod
    def move_to_cell(cls, cell_id: int) -> "PassiveDirective":
        if not 0 <= int(cell_id) < 560:
            raise ValueError("passive target CellId must be in 0..559")
        return cls(PassiveDirectiveKind.MOVE_TO_CELL, int(cell_id))


class PassivePolicy:
    def __init__(self, directive: PassiveDirective | None = None) -> None:
        self.directive = directive or PassiveDirective()

    def decide(
        self, *, planner_context: PassiveInvocationContext | None = None,
        current_cell_id: int | None = None,
    ) -> FightDecision:
        if planner_context is not None:
            current_cell_id = planner_context.current_cell_id
        if self.directive.kind is PassiveDirectiveKind.MOVE_TO_CELL:
            target = self.directive.target_cell_id
            if target is not None and current_cell_id != target:
                return FightDecision(
                    FightDecisionKind.MOVE,
                    "PASSIVE_MOVE_DIRECTIVE",
                    target_cell_id=target,
                )
        return FightDecision(FightDecisionKind.END_TURN, "PASSIVE_END_TURN")

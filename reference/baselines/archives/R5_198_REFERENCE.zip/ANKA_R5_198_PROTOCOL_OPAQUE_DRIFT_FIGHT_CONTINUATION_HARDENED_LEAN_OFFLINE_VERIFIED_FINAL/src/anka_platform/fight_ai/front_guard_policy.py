from __future__ import annotations

from dataclasses import dataclass, field
import time
from typing import Mapping

from anka_game_kernel.domain.certainty import Certainty
from anka_game_kernel.domain.ids import ActorId, CellId
from anka_platform.contracts.common import ValueStatus
from anka_platform.core.fight.decision_contract import FightDecision, FightDecisionKind
from anka_platform.core.fight.planner_contract import PassiveInvocationContext
from anka_platform.fight_ai.tactical.models import ActorTacticalObjective, TacticalRole
from anka_platform.integration.kernel_context import KernelContextAdapter, KernelContextUnavailable
from anka_platform.integration.fight_geometry import FightGeometryUnavailable, fight_context_map_definition


def _known(value):
    return value.value if value.status is ValueStatus.KNOWN else None


@dataclass(frozen=True, slots=True)
class FrontGuardFightDecision(FightDecision):
    tactical_trace: Mapping[str, object] = field(default_factory=dict)


class FrontGuardPolicyV1:
    """Non-offensive passive guard policy.

    The guard never casts.  It may spend MP only when a certified reachable cell
    measurably improves its geometric interception of the team's priority threat
    relative to the protected Cra/Enu core.  Otherwise it ends turn immediately.

    This is intentionally conservative: it is a tactical passive policy, not a
    new control-authority mode, and it cannot bypass PartyCombatController or
    ExecutionService.
    """

    MIN_IMPROVEMENT = 0.22
    MAX_CANDIDATES = 64

    def decide(
        self,
        *,
        planner_context: PassiveInvocationContext | None = None,
        current_cell_id: int | None = None,
        kernel=None,
        snapshot=None,
        local_actor_id: int | None = None,
        objective=None,
        decision_deadline_monotonic: float | None = None,
    ) -> FightDecision:
        if planner_context is not None:
            current_cell_id = planner_context.current_cell_id
            kernel = planner_context.kernel
            snapshot = planner_context.snapshot
            local_actor_id = planner_context.local_actor_id
            objective = planner_context.planner.objective
            decision_deadline_monotonic = planner_context.planner.decision_deadline_monotonic
        if kernel is None or snapshot is None or local_actor_id is None:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_CONTEXT_UNAVAILABLE")
        if self._deadline_exhausted(decision_deadline_monotonic):
            return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")
        if not isinstance(objective, ActorTacticalObjective) or objective.role is not TacticalRole.FRONT_GUARD:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_OBJECTIVE_UNAVAILABLE")
        protected_raw = objective.protect_actor_id or objective.team_plan.protected_actor_id
        threat_raw = objective.control_target_actor_id or objective.team_plan.priority_threat_actor_id
        if protected_raw is None or threat_raw is None:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_NO_PROTECTIVE_PAIR")

        fight = snapshot.fight
        active = _known(fight.active_actor_id)
        if active is None or int(active) != int(local_actor_id):
            return FightDecision(FightDecisionKind.WAIT, "NOT_LOCAL_TURN")
        try:
            context = KernelContextAdapter(kernel).fight_context(snapshot)
        except KernelContextUnavailable:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_FIGHT_CONTEXT_UNAVAILABLE")
        if context.map_id is None:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_MAP_UNKNOWN")
        guard = context.actor(ActorId(int(local_actor_id)))
        protected = context.actor(ActorId(int(protected_raw)))
        threat = context.actor(ActorId(int(threat_raw)))
        if any(item is None or item.cell_id is None for item in (guard, protected, threat)):
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_ACTOR_POSITION_UNKNOWN")
        if guard.current_mp is None or guard.current_mp <= 0:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_NO_CONFIRMED_MP")

        try:
            map_definition = fight_context_map_definition(kernel, context)
        except FightGeometryUnavailable:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_FIGHT_GEOMETRY_UNAVAILABLE")
        reachable = kernel.fight_queries.reachable_cells(map_definition, context, guard.actor_id)
        if reachable.certainty is not Certainty.DETERMINISTIC:
            return FightDecision(FightDecisionKind.END_TURN, "FRONT_GUARD_REACHABILITY_UNCERTAIN")

        current_value = self._protective_value(kernel, guard.cell_id, threat.cell_id, protected.cell_id)
        rows = []
        for item in sorted(reachable.reachable, key=lambda row: (int(row.distance), int(row.cell_id)))[: self.MAX_CANDIDATES]:
            if item.distance <= 0 or self._deadline_exhausted(decision_deadline_monotonic):
                continue
            value = self._protective_value(kernel, item.cell_id, threat.cell_id, protected.cell_id)
            improvement = value["total"] - current_value["total"]
            if improvement < self.MIN_IMPROVEMENT:
                continue
            rows.append((
                improvement,
                value["total"],
                -int(item.distance),
                -int(item.cell_id),
                item,
                value,
            ))
        if not rows:
            return FrontGuardFightDecision(
                FightDecisionKind.END_TURN,
                "FRONT_GUARD_NO_MATERIAL_PROTECTIVE_MOVE",
                tactical_trace={
                    "schema_version": 1,
                    "planner": "front_guard_v1",
                    "role": TacticalRole.FRONT_GUARD.value,
                    "protected_actor_id": int(protected_raw),
                    "priority_threat_actor_id": int(threat_raw),
                    "current_cell_id": int(guard.cell_id),
                    "current_protection": current_value,
                    "selected": "END_TURN",
                },
            )
        _, _, _, _, best, best_value = max(rows, key=lambda row: row[:4])
        return FrontGuardFightDecision(
            FightDecisionKind.MOVE,
            "FRONT_GUARD_PROTECTIVE_MOVE",
            target_cell_id=int(best.cell_id),
            path_distance=int(best.distance),
            tactical_trace={
                "schema_version": 1,
                "planner": "front_guard_v1",
                "role": TacticalRole.FRONT_GUARD.value,
                "protected_actor_id": int(protected_raw),
                "priority_threat_actor_id": int(threat_raw),
                "current_cell_id": int(guard.cell_id),
                "selected_cell_id": int(best.cell_id),
                "current_protection": current_value,
                "selected_protection": best_value,
                "improvement": round(float(best_value["total"] - current_value["total"]), 6),
                "candidate_count": len(rows),
            },
        )

    @staticmethod
    def _protective_value(kernel, guard_cell: CellId, threat_cell: CellId, protected_cell: CellId) -> dict[str, float]:
        threat_to_core = max(1, FrontGuardPolicyV1._distance(kernel, threat_cell, protected_cell))
        threat_to_guard = FrontGuardPolicyV1._distance(kernel, threat_cell, guard_cell)
        guard_to_core = FrontGuardPolicyV1._distance(kernel, guard_cell, protected_cell)
        detour = abs((threat_to_guard + guard_to_core) - threat_to_core)
        corridor = 1.0 / (1.0 + float(detour))
        between = 1.0 if threat_to_guard < threat_to_core and guard_to_core < threat_to_core else 0.0
        threat_contact = max(0.0, 1.0 - abs(float(threat_to_guard) - 2.0) / max(2.0, float(threat_to_core)))
        core_spacing = 1.0 if 2 <= guard_to_core <= 5 else max(0.0, 1.0 - abs(float(guard_to_core) - 3.0) / 8.0)
        # Standing exactly in a straight core↔threat firing lane can protect pathing
        # but may block Cra/Enu LoS, so it is a soft penalty rather than a hard ban.
        aligned = 1.0 if kernel.fight_queries.cells_aligned(protected_cell, threat_cell) else 0.0
        direct_lane = aligned if detour == 0 else 0.0
        total = 0.42 * corridor + 0.28 * between + 0.18 * threat_contact + 0.12 * core_spacing - 0.20 * direct_lane
        return {
            "total": round(total, 6),
            "corridor": round(corridor, 6),
            "between": between,
            "threat_contact": round(threat_contact, 6),
            "core_spacing": round(core_spacing, 6),
            "direct_los_block_risk": direct_lane,
            "threat_to_guard": float(threat_to_guard),
            "guard_to_core": float(guard_to_core),
        }

    @staticmethod
    def _distance(kernel, first: CellId, second: CellId) -> int:
        return kernel.geometry.distance(
            kernel.geometry.cell_to_coordinate(first),
            kernel.geometry.cell_to_coordinate(second),
        )

    @staticmethod
    def _deadline_exhausted(deadline: float | None) -> bool:
        return deadline is not None and time.monotonic() >= float(deadline)

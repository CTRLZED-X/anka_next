from __future__ import annotations

from dataclasses import dataclass, field

from anka_game_kernel.domain.ids import CellId, CharacteristicId
from anka_platform.fight_ai.knowledge import generic_reach_envelope
from anka_platform.fight_ai.tactical.models import ActorTacticalObjective
from anka_platform.fight_ai.tactical.threat import calibrated_enemy_pressure


@dataclass(frozen=True, slots=True)
class TeamReplyPressure:
    total: float
    per_actor: dict[int, float]
    peak_actor_id: int | None
    per_enemy: dict[int, float] = field(default_factory=dict)
    exact_range_pairs: tuple[tuple[int, int], ...] = ()

    def as_dict(self) -> dict[str, object]:
        return {
            "total": float(self.total),
            "per_actor": {str(k): float(v) for k, v in sorted(self.per_actor.items())},
            "per_enemy": {str(k): float(v) for k, v in sorted(self.per_enemy.items())},
            "peak_actor_id": self.peak_actor_id,
            "exact_range_pairs": [list(row) for row in self.exact_range_pairs],
        }


def _aggregate(rows: dict[int, float]) -> float:
    if not rows:
        return 0.0
    values = [max(0.0, float(value)) for value in rows.values()]
    peak = max(values)
    return peak + 0.30 * max(0.0, sum(values) - peak)


def team_reply_pressure(
    objective: ActorTacticalObjective | None,
    *,
    local_actor_id: int,
    local_pressure: float,
) -> TeamReplyPressure:
    """Backward-compatible aggregate over the precomputed team pressure map."""
    rows: dict[int, float] = {}
    if objective is not None:
        rows.update({int(k): max(0.0, float(v)) for k, v in objective.team_plan.pressure_by_ally.items()})
    rows[int(local_actor_id)] = max(0.0, float(local_pressure))
    peak_actor_id = None
    if rows:
        peak_actor_id = min(rows, key=lambda actor_id: (-rows[actor_id], actor_id))
    return TeamReplyPressure(_aggregate(rows), rows, peak_actor_id)


def _distance(kernel, first, second) -> int | None:
    if first is None or second is None:
        return None
    try:
        return int(kernel.geometry.distance(
            kernel.geometry.cell_to_coordinate(CellId(int(first))),
            kernel.geometry.cell_to_coordinate(CellId(int(second))),
        ))
    except Exception:
        return None


def _hp_vulnerability(actor) -> float:
    hp = getattr(actor, "current_hp", None)
    max_hp = getattr(actor, "max_hp", None)
    if hp is None or max_hp in (None, 0):
        return 1.0
    ratio = max(0.0, min(1.0, float(hp) / float(max_hp)))
    # Pressure on an already-damaged core actor matters more to the team than the
    # same pressure on a healthy partner.  Bounded so it cannot dominate geometry.
    return 1.0 + 0.75 * (1.0 - ratio)


def _capability(objective: ActorTacticalObjective | None, enemy) -> dict[str, object]:
    if objective is not None:
        raw = objective.team_plan.enemy_capabilities.get(int(enemy.actor_id))
        if raw:
            return dict(raw)
    mp = getattr(enemy, "current_mp", None)
    characteristic = getattr(enemy, "characteristic", None)
    mp_capacity = characteristic(CharacteristicId(23)) if callable(characteristic) else None
    return {
        "effective_reach": generic_reach_envelope(mp, mp_capacity),
        "mp_capacity": mp_capacity,
        "threat_multiplier": 1.0,
        "exact_range_hazard": None,
        "exact_range_threat_multiplier": 1.0,
        "uncertainty": 0.65,
    }


def projected_team_reply_pressure(
    kernel,
    objective: ActorTacticalObjective | None,
    *,
    enemies,
    allies,
    local_actor_id: int,
    local_cell: int,
) -> TeamReplyPressure:
    """Recompute enemy reply pressure against the *whole* local team.

    Unlike the legacy local-pressure substitution, this evaluates every observed
    enemy against every Cra/Enu/guard position after the proposed local MOVE.  It
    therefore rejects moves that make the current actor safer by transferring a
    worse threat onto the partner.  The calculation is advisory scoring only;
    Kernel legality remains the action gate.
    """
    all_allies = list(allies)
    core_ids = set()
    if objective is not None:
        core_ids = {int(item) for item in objective.team_plan.core_actor_ids}
    if core_ids:
        all_allies = [item for item in all_allies if int(item.actor_id) in core_ids]
    local = next((item for item in all_allies if int(item.actor_id) == int(local_actor_id)), None)
    if local is None:
        # TacticalPolicy passes partners separately, so synthesize a minimal local
        # view from the first matching objective pressure entry if necessary.
        class _Local:
            actor_id = int(local_actor_id)
            cell_id = int(local_cell)
            current_hp = None
            max_hp = None
        local = _Local()
        all_allies.append(local)

    per_actor: dict[int, float] = {int(item.actor_id): 0.0 for item in all_allies}
    per_enemy: dict[int, float] = {}
    exact_pairs: list[tuple[int, int]] = []

    for enemy in enemies:
        cap = _capability(objective, enemy)
        reach = max(0.0, float(cap.get("effective_reach") or 0.0))
        multiplier = max(0.25, float(cap.get("threat_multiplier") or 1.0))
        uncertainty = max(0.0, min(1.0, float(cap.get("uncertainty") or 0.0)))
        exact = cap.get("exact_range_hazard")
        exact_multiplier = max(1.0, float(cap.get("exact_range_threat_multiplier") or 1.0))
        ap = getattr(enemy, "current_ap", None)
        mp = getattr(enemy, "current_mp", None)
        characteristic = getattr(enemy, "characteristic", None)
        mp_capacity = cap.get("mp_capacity")
        if mp_capacity is None and callable(characteristic):
            mp_capacity = characteristic(CharacteristicId(23))
        enemy_rows: list[tuple[int, float]] = []
        for ally in all_allies:
            ally_id = int(ally.actor_id)
            cell = int(local_cell) if ally_id == int(local_actor_id) else getattr(ally, "cell_id", None)
            distance = _distance(kernel, getattr(enemy, "cell_id", None), cell)
            if distance is None:
                continue
            if exact is not None and int(distance) == int(exact):
                exact_pairs.append((int(enemy.actor_id), ally_id))
            pressure = calibrated_enemy_pressure(
                distance=distance,
                ap=ap,
                mp=mp,
                mp_capacity=mp_capacity if isinstance(mp_capacity, int) and not isinstance(mp_capacity, bool) else None,
                effective_reach=reach,
                threat_multiplier=multiplier,
                exact_range_hazard=None if exact is None else int(exact),
                exact_range_threat_multiplier=exact_multiplier,
                uncertainty=uncertainty,
            ) * _hp_vulnerability(ally)
            per_actor[ally_id] = per_actor.get(ally_id, 0.0) + pressure
            enemy_rows.append((ally_id, pressure))
        if enemy_rows:
            values = [value for _aid, value in enemy_rows]
            peak = max(values)
            per_enemy[int(enemy.actor_id)] = peak + 0.25 * max(0.0, sum(values) - peak)

    total = _aggregate(per_enemy)
    peak_actor_id = None
    if per_actor:
        peak_actor_id = min(per_actor, key=lambda actor_id: (-per_actor[actor_id], actor_id))
    return TeamReplyPressure(
        total=round(float(total), 6),
        per_actor={key: round(float(value), 6) for key, value in per_actor.items()},
        peak_actor_id=peak_actor_id,
        per_enemy={key: round(float(value), 6) for key, value in per_enemy.items()},
        exact_range_pairs=tuple(sorted(set(exact_pairs))),
    )

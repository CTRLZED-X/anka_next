from __future__ import annotations

from dataclasses import asdict, dataclass
from importlib.resources import files
from pathlib import Path
from typing import Any, Mapping

from .enemy_memory import EnemyBehaviorMemory

import yaml


# Advisory-only conservative envelopes for enemies whose current resources have
# not yet been observed. They never enter Kernel movement/cast legality.
UNKNOWN_ENEMY_MP_CAPACITY = 6
GENERIC_ATTACK_REACH_ALLOWANCE = 2


def generic_reach_envelope(mp: int | None, mp_capacity: int | None = None) -> float:
    """Return a conservative tactical reach prior without inventing current MP.

    Unknown current MP must remain UNKNOWN in Canonical/Kernel state. Tactical
    threat scoring, however, must not turn that uncertainty into an immobile
    enemy. Use a bounded six-MP defensive envelope until live/static/learned
    evidence provides something better.
    """
    if mp is not None:
        movement = max(0, int(mp))
    elif mp_capacity is not None:
        # Characteristic 23 is certified as an MP total/capacity observation,
        # never as current remaining MP.  It is therefore safe for advisory
        # threat envelopes but must not populate Canonical/Kernel current_mp.
        movement = max(0, int(mp_capacity))
    else:
        movement = UNKNOWN_ENEMY_MP_CAPACITY
    return float(movement + GENERIC_ATTACK_REACH_ALLOWANCE)


@dataclass(frozen=True, slots=True)
class EnemyCapabilityView:
    """Conservative tactical prior for one observed enemy.

    Capability data is advisory strategy evidence only. It may increase the
    planner's defensive envelope, but it never replaces Canonical State or Kernel
    legality and it cannot authorize physical input.
    """

    static_id: int | None
    source: str
    nominal_reach: float
    capability_reach: float
    effective_reach: float
    threat_multiplier: float
    phase: int
    exact_range_hazard: int | None = None
    exact_range_threat_multiplier: float = 1.0
    tags: tuple[str, ...] = ()
    observed_reach: float | None = None
    evidence_confidence: float = 0.0
    evidence_count: int = 0
    uncertainty: float = 0.0

    def as_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["tags"] = list(self.tags)
        return data


def _number(value: Any, default: float) -> float:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    return float(default)


class EnemyCapabilityCatalog:
    """Data-driven enemy tactical priors keyed by canonical monster ``static_id``.

    The bundled R5.132 file contains only the four level-200 Sufokia profiles
    supplied and accepted in ``SUFOKIA_DUO_AI_v0.3.10``. Unknown monsters use the
    generic MP+2 fallback. This keeps zone expansion data-driven rather than adding
    species-specific branches to planner code.
    """

    def __init__(self, profiles: Mapping[int, Mapping[str, Any]] | None = None, *, source: str = "EMPTY") -> None:
        self._profiles = {int(key): dict(value) for key, value in dict(profiles or {}).items()}
        self.source = str(source)

    @classmethod
    def empty(cls) -> "EnemyCapabilityCatalog":
        return cls({}, source="EMPTY")

    @classmethod
    def load(cls, path: str | Path, *, source: str | None = None) -> "EnemyCapabilityCatalog":
        source_path = Path(path)
        raw = yaml.safe_load(source_path.read_text(encoding="utf-8")) if source_path.is_file() else {}
        raw_profiles = raw.get("profiles") if isinstance(raw, Mapping) else {}
        profiles: dict[int, dict[str, Any]] = {}
        if isinstance(raw_profiles, Mapping):
            for raw_id, profile in raw_profiles.items():
                try:
                    static_id = int(raw_id)
                except (TypeError, ValueError):
                    continue
                if isinstance(profile, Mapping):
                    profiles[static_id] = dict(profile)
        declared = raw.get("source") if isinstance(raw, Mapping) else None
        return cls(profiles, source=str(source or declared or source_path.name))

    @classmethod
    def bundled(cls) -> "EnemyCapabilityCatalog":
        resource = files("anka_platform.fight_ai").joinpath("data/enemy_capabilities_sufokia.yaml")
        with resource.open("r", encoding="utf-8") as handle:
            raw = yaml.safe_load(handle) or {}
        raw_profiles = raw.get("profiles") if isinstance(raw, Mapping) else {}
        profiles = {
            int(raw_id): dict(profile)
            for raw_id, profile in dict(raw_profiles or {}).items()
            if isinstance(profile, Mapping)
        }
        return cls(profiles, source=str(raw.get("source") or "BUNDLED"))

    def raw_profile(self, static_id: int | None) -> dict[str, Any] | None:
        if static_id is None:
            return None
        profile = self._profiles.get(int(static_id))
        return None if profile is None else dict(profile)

    @staticmethod
    def _phase(profile: Mapping[str, Any], hp_ratio: float | None, state_ids: tuple[int, ...] = ()) -> int:
        """Return the most conservative phase supported by canonical evidence.

        HP thresholds and explicit state ids are both evidence.  If they disagree,
        the higher (more dangerous) phase wins; the catalog never downgrades a
        threat because one evidence source is missing.
        """
        phase = 0
        raw = profile.get("phase_thresholds")
        if hp_ratio is not None and isinstance(raw, list):
            for index, value in enumerate(raw, start=1):
                if isinstance(value, (int, float)) and not isinstance(value, bool) and float(hp_ratio) <= float(value):
                    phase = max(phase, index)
        state_phase_map = profile.get("state_phase_map")
        if isinstance(state_phase_map, Mapping):
            for state_id in state_ids:
                mapped = state_phase_map.get(str(int(state_id)), state_phase_map.get(int(state_id)))
                if isinstance(mapped, int) and not isinstance(mapped, bool):
                    phase = max(phase, int(mapped))
        return phase

    @staticmethod
    def _phase_value(value: Any, phase: int, default: float) -> float:
        if isinstance(value, list) and value:
            index = max(0, min(int(phase), len(value) - 1))
            return _number(value[index], default)
        return _number(value, default)

    def capability_for(self, actor) -> EnemyCapabilityView:
        observed_mp = getattr(actor, "mp", None)
        if observed_mp is None:
            observed_mp = getattr(actor, "current_mp", None)
        mp_capacity = getattr(actor, "mp_capacity", None)
        if mp_capacity is None:
            characteristic = getattr(actor, "characteristic", None)
            if callable(characteristic):
                try:
                    from anka_game_kernel.domain.ids import CharacteristicId
                    mp_capacity = characteristic(CharacteristicId(23))
                except Exception:
                    mp_capacity = None
        nominal = generic_reach_envelope(observed_mp, mp_capacity)
        static_id = getattr(actor, "static_id", None)
        profile = self.raw_profile(static_id)
        if profile is None:
            return EnemyCapabilityView(
                static_id=None if static_id is None else int(static_id),
                source=(
                    "GENERIC_MP_PLUS_2"
                    if observed_mp is not None
                    else "GENERIC_MP_CAPACITY_PLUS_2"
                    if mp_capacity is not None
                    else "GENERIC_UNKNOWN_MP_ENVELOPE"
                ),
                nominal_reach=nominal,
                capability_reach=0.0,
                effective_reach=nominal,
                threat_multiplier=1.0,
                phase=0,
                uncertainty=0.65,
            )
        phase = self._phase(
            profile,
            getattr(actor, "hp_ratio", None),
            tuple(int(item) for item in (getattr(actor, "state_ids", ()) or ())),
        )
        capability_reach = max(0.0, _number(profile.get("effective_reach"), 0.0))
        base_multiplier = max(0.25, _number(profile.get("threat_multiplier"), 1.0))
        phase_multiplier = max(0.25, self._phase_value(profile.get("phase_threat_multiplier"), phase, 1.0))
        exact = profile.get("exact_range_hazard")
        if not isinstance(exact, int) or isinstance(exact, bool):
            exact = None
        tags = tuple(sorted(str(item) for item in (profile.get("tags") or ()) if str(item).strip()))
        return EnemyCapabilityView(
            static_id=int(static_id),
            source=self.source,
            nominal_reach=nominal,
            capability_reach=capability_reach,
            effective_reach=max(nominal, capability_reach),
            threat_multiplier=min(4.0, base_multiplier * phase_multiplier),
            phase=phase,
            exact_range_hazard=exact,
            exact_range_threat_multiplier=max(1.0, _number(profile.get("exact_range_threat_multiplier"), 1.0)),
            tags=tags,
        )


class AdaptiveEnemyCapabilityCatalog:
    """Merge optional static priors with confidence-weighted live observations.

    This is the generic level-200 path: static zone profiles are optional hints,
    while unknown monsters remain supported and can widen their defensive envelope
    as Canonical evidence accumulates. Learned data never shrinks the base envelope.
    """

    def __init__(self, base: EnemyCapabilityCatalog | None = None, memory: EnemyBehaviorMemory | None = None) -> None:
        self.base = base or EnemyCapabilityCatalog.empty()
        self.memory = memory or EnemyBehaviorMemory()
        self.source = f"ADAPTIVE[{self.base.source}]"

    def raw_profile(self, static_id: int | None) -> dict[str, Any] | None:
        return self.base.raw_profile(static_id)

    def capability_for(self, actor) -> EnemyCapabilityView:
        base = self.base.capability_for(actor)
        static_id = base.static_id
        learned = self.memory.capability_for(static_id)
        if learned is None:
            return base
        effective = max(float(base.effective_reach), float(learned.effective_reach))
        source = f"{base.source}+LIVE_OBSERVED"
        # High-confidence demonstrated reach also raises defensive attention a
        # little, but never by more than the existing hard cap.
        multiplier = min(
            4.0,
            max(
                float(base.threat_multiplier) * (1.0 + 0.20 * learned.confidence),
                float(learned.observed_threat_multiplier),
            ),
        )
        return EnemyCapabilityView(
            static_id=base.static_id,
            source=source,
            nominal_reach=base.nominal_reach,
            capability_reach=max(base.capability_reach, learned.effective_reach),
            effective_reach=effective,
            threat_multiplier=multiplier,
            phase=base.phase,
            exact_range_hazard=base.exact_range_hazard,
            exact_range_threat_multiplier=base.exact_range_threat_multiplier,
            tags=tuple(sorted(set(base.tags) | {"LIVE_ADAPTIVE_REACH"})),
            observed_reach=float(learned.effective_reach),
            evidence_confidence=float(learned.confidence),
            evidence_count=int(learned.evidence_count),
            uncertainty=max(0.0, float(base.uncertainty) * (1.0 - learned.confidence)),
        )

    def observe(self, *, kernel, state, snapshots: Mapping[str, object], session_id: str) -> None:
        self.memory.observe(kernel=kernel, state=state, snapshots=snapshots, session_id=session_id)

    def export_memory(self) -> dict[str, object]:
        return self.memory.export_state()

from __future__ import annotations

from typing import Mapping

from anka_platform.fight_ai.tactical.models import CandidateScoreBreakdown, TacticalMode, TacticalRole


_BASE_WEIGHTS: dict[str, float] = {
    "damage": 18.0,
    "aoe_targets": 18.0,
    "mp_control": 24.0,
    "mp_control_waste": -12.0,
    "ap_control": 15.0,
    "ap_control_waste": -8.0,
    "push": 15.0,
    "pull": 8.0,
    "recoil": 12.0,
    "heal": 20.0,
    "shield": 16.0,
    "range_control": 10.0,
    # Arbitrary state valence and controlled summons are not yet certified by
    # ANKA's generic tactical contract. Keep the keys explicit but non-scoring so
    # future callers cannot accidentally re-enable them by emitting raw features.
    "state_control": 0.0,
    "summon": 0.0,
    "focus_fire": 18.0,
    "finish": 55.0,
    "threat_reduction": 30.0,
    "position_safety": 28.0,
    "formation": 10.0,
    "front_geometry": 22.0,
    "pincer_reduction": 30.0,
    "pincer_increase": -38.0,
    "ally_ap_support": 9.0,
    "ally_mp_support": 10.0,
    "ally_range_support": 8.0,
    # Raising intrinsic minimum range creates a dead zone. It is a trade-off,
    # not additional reach, and is therefore scored separately from max-range.
    "minimum_range_increase": -5.0,
    "self_offensive_buff": 11.0,
    "ally_offensive_buff": 9.0,
    "enemy_offensive_debuff": 10.0,
    "self_range_sacrifice": -8.0,
    "ap_efficiency": 3.0,
    "mp_efficiency": 2.0,
    "future_value": 8.0,
    "uncertainty": -20.0,
    "ally_risk": -70.0,
    "death_risk": -150.0,
    "unnecessary_movement": -12.0,
    "safety_improvement": 20.0,
    "team_reply_pressure_reduction": 34.0,
    "pm_reserve_loss": -7.0,
    "mp_overspend": -12.0,
    "movement_lock_risk": -14.0,
    "enemy_resource_benefit": -36.0,
    "build_affinity": 7.0,
    "resistance_penalty": -30.0,
    "resistance_vulnerability": 18.0,
    # Tie-breaker only: when mechanics value is otherwise comparable, prefer an
    # empty fight-walkable target surface because live evidence shows those cells
    # are more reliable physical spell-click anchors. Never a legality gate.
    "client_interaction_preference": 2.0,
    # UI-driven automation pays a real reliability cost for every additional
    # primitive.  Keep this modest so material tactical value always wins, but
    # break near-ties in favour of simpler plans.
    "execution_complexity": -3.5,
}

_ROLE_MULTIPLIERS: dict[TacticalRole, dict[str, float]] = {
    TacticalRole.CRA_RANGED_CONTROL_DAMAGE: {
        "damage": 1.35, "finish": 1.35, "aoe_targets": 1.2, "push": 1.15,
        "position_safety": 1.2, "mp_control": 0.8, "ally_range_support": 1.2,
        "self_offensive_buff": 1.25, "self_range_sacrifice": 1.1,
    },
    TacticalRole.ENU_WATER_MP_CONTROL: {
        "mp_control": 1.7, "threat_reduction": 1.4, "position_safety": 1.15,
        "damage": 0.9, "finish": 1.0, "push": 1.15, "ally_mp_support": 1.15,
    },
    TacticalRole.FRONT_GUARD: {
        "damage": 0.0, "finish": 0.0, "mp_control": 0.0, "ap_control": 0.0,
        "position_safety": 1.5, "formation": 1.7, "threat_reduction": 1.7,
        "unnecessary_movement": 1.7,
    },
    TacticalRole.GENERIC_ACTIVE: {},
}

_MODE_MULTIPLIERS: dict[TacticalMode, dict[str, float]] = {
    TacticalMode.SURVIVE: {
        "death_risk": 2.0, "position_safety": 2.0, "threat_reduction": 1.8,
        "mp_control": 1.5, "push": 1.4, "heal": 1.7, "damage": 0.55,
    },
    TacticalMode.SAVE_ALLY: {
        "threat_reduction": 1.9, "position_safety": 1.5, "mp_control": 1.5,
        "push": 1.5, "heal": 1.6, "damage": 0.7,
    },
    TacticalMode.BURST_KILL: {
        "damage": 1.35, "finish": 1.6, "focus_fire": 1.4, "self_offensive_buff": 1.2,
    },
    TacticalMode.BREAK_PINCER: {
        "position_safety": 1.7, "threat_reduction": 1.6, "push": 1.45,
        "mp_control": 1.35, "formation": 1.4, "pincer_reduction": 2.0,
        "pincer_increase": 1.5,
    },
    TacticalMode.FULL_RETREAT: {
        "position_safety": 2.1, "threat_reduction": 1.7, "damage": 0.45,
        "unnecessary_movement": 0.7,
    },
    TacticalMode.ESCAPE_AND_CONTROL: {
        "position_safety": 1.8, "threat_reduction": 1.7, "mp_control": 1.6,
        "push": 1.5, "damage": 0.65,
    },
    TacticalMode.KITE_AND_BURN: {
        "damage": 1.2, "position_safety": 1.35, "push": 1.2, "self_range_sacrifice": 1.35,
    },
    TacticalMode.ISOLATE_AND_FOCUS: {"focus_fire": 1.35, "mp_control": 1.3, "push": 1.3},
    TacticalMode.REJOIN_FORMATION: {"formation": 2.0, "position_safety": 1.4, "damage": 0.7},
    TacticalMode.SETUP_NEXT_TURN: {
        "future_value": 1.7, "formation": 1.3, "ally_ap_support": 1.5,
        "ally_mp_support": 1.4, "ally_range_support": 1.5,
        "self_offensive_buff": 1.6, "ally_offensive_buff": 1.5, "self_range_sacrifice": 0.8,
    },
    TacticalMode.CONTROL_AND_FOCUS: {
        "focus_fire": 1.2, "threat_reduction": 1.15, "enemy_offensive_debuff": 1.25,
    },
}


def score_features(
    features: Mapping[str, float], *, role: TacticalRole, mode: TacticalMode,
    hard_rejections: tuple[str, ...] = (),
) -> CandidateScoreBreakdown:
    components: dict[str, float] = {}
    role_m = _ROLE_MULTIPLIERS.get(role, {})
    mode_m = _MODE_MULTIPLIERS.get(mode, {})
    for key, raw_value in features.items():
        token = str(key)
        # Candidate features also carry diagnostic measurements (for example
        # projected pressure before/after a MOVE).  Only explicitly registered
        # tactical terms are allowed to influence ranking; observability fields
        # must never become accidental one-point scoring rules.
        if token not in _BASE_WEIGHTS:
            continue
        value = float(raw_value)
        base = _BASE_WEIGHTS[token]
        multiplier = float(role_m.get(token, 1.0)) * float(mode_m.get(token, 1.0))
        components[token] = value * base * multiplier
    total = sum(components.values())
    return CandidateScoreBreakdown(total=round(total, 6), components=components, hard_rejections=tuple(hard_rejections))

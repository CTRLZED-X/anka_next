from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations

from anka_game_kernel.domain.ids import CellId

from anka_platform.fight_ai.knowledge import EnemyCapabilityCatalog, generic_reach_envelope
from anka_platform.fight_ai.tactical.state import TacticalActorState, TacticalFightState
from anka_platform.fight_ai.tactical.threat import _enemy_pressure, calibrated_enemy_pressure


@dataclass(frozen=True, slots=True)
class TeamSafeStateAnalysis:
    pincer_score: float
    threat_sectors: int
    exposure_by_ally: dict[int, float]
    max_exposure: float
    ally_gap: int | None = None


def _distance(kernel, a: int | None, b: int | None) -> int | None:
    if a is None or b is None:
        return None
    try:
        return int(kernel.geometry.distance(
            kernel.geometry.cell_to_coordinate(CellId(int(a))),
            kernel.geometry.cell_to_coordinate(CellId(int(b))),
        ))
    except Exception:
        return None



def enemy_between_players(kernel, first_cell: int | None, second_cell: int | None, enemy_cell: int | None) -> bool:
    """Return strong geometry evidence that an enemy splits the two core actors.

    This is deliberately monster-agnostic.  It uses only Kernel distance geometry;
    one-cell slack tolerates grid/path metric quirks without inventing LoS facts.
    """
    if first_cell is None or second_cell is None or enemy_cell is None:
        return False
    if int(enemy_cell) in {int(first_cell), int(second_cell)}:
        return False
    direct = _distance(kernel, int(first_cell), int(second_cell))
    left = _distance(kernel, int(first_cell), int(enemy_cell))
    right = _distance(kernel, int(enemy_cell), int(second_cell))
    if direct is None or left is None or right is None or direct <= 1:
        return False
    return left < direct and right < direct and (left + right) <= direct + 1

def _reach(enemy: TacticalActorState, capability_catalog: EnemyCapabilityCatalog | None = None) -> float:
    if capability_catalog is None:
        return generic_reach_envelope(enemy.mp, enemy.mp_capacity)
    return float(capability_catalog.capability_for(enemy).effective_reach)


def _threat_factor(
    distance: int | None,
    enemy: TacticalActorState,
    capability_catalog: EnemyCapabilityCatalog | None = None,
) -> float:
    """Normalized pincer factor derived from the shared calibrated pressure prior.

    Earlier drafts kept an independent ``(reach+1)/distance`` curve here, which
    meant pincer/safe-state could disagree with team threat and projected reply
    pressure in large groups.  Use the same calibrated model everywhere and only
    normalize for the 0..1 pincer geometry multiplier.
    """
    if distance is None:
        return 0.0
    capability = capability_catalog.capability_for(enemy) if capability_catalog is not None else None
    if capability is None:
        reach = generic_reach_envelope(enemy.mp, enemy.mp_capacity)
        multiplier = 1.0
        exact = None
        exact_multiplier = 1.0
        uncertainty = 0.65
    else:
        reach = float(capability.effective_reach)
        multiplier = float(capability.threat_multiplier)
        exact = capability.exact_range_hazard
        exact_multiplier = float(capability.exact_range_threat_multiplier)
        uncertainty = float(getattr(capability, "uncertainty", 0.0))
    pressure = calibrated_enemy_pressure(
        distance=int(distance),
        ap=enemy.ap,
        mp=enemy.mp,
        mp_capacity=enemy.mp_capacity,
        effective_reach=reach,
        threat_multiplier=multiplier,
        exact_range_hazard=exact,
        exact_range_threat_multiplier=exact_multiplier,
        uncertainty=uncertainty,
    )
    # Pincer is partly a geometry question, not only an aggregate danger score.
    # The calibrated pressure curve intentionally decays strongly so 6-8 distant
    # enemies do not force permanent retreat; using that curve alone made two
    # enemies already inside their generic influence envelope stop registering as
    # a close two-sided pincer.  Keep the shared pressure severity, but combine it
    # with a bounded reach-proximity term for this *geometry-only* multiplier.
    pressure_factor = max(0.0, min(1.0, float(pressure) / (0.55 + float(pressure))))
    proximity_factor = max(0.0, min(1.0, 1.0 - float(distance) / max(1.0, reach + 3.0)))
    return max(pressure_factor, proximity_factor)


def pincer_score_for_cell(
    kernel,
    cell: int | None,
    enemies: tuple[TacticalActorState, ...],
    capability_catalog: EnemyCapabilityCatalog | None = None,
) -> float:
    live = [enemy for enemy in enemies if enemy.cell_id is not None and enemy.alive is not False]
    if cell is None or len(live) < 2:
        return 0.0
    best = 0.0
    for left, right in combinations(live, 2):
        dl = _distance(kernel, cell, left.cell_id)
        dr = _distance(kernel, cell, right.cell_id)
        pair = _distance(kernel, left.cell_id, right.cell_id)
        if dl is None or dr is None or pair is None or pair <= 0:
            continue
        excess = abs((dl + dr) - pair)
        corridor = max(0.0, 1.0 - excess / max(2.0, pair * 0.50))
        threatened = min(
            _threat_factor(dl, left, capability_catalog),
            _threat_factor(dr, right, capability_catalog),
        )
        best = max(best, corridor * threatened)
    return round(max(0.0, min(1.0, best)), 6)


def analyze_team_safe_state(
    kernel,
    state: TacticalFightState,
    capability_catalog: EnemyCapabilityCatalog | None = None,
    *,
    core_actor_ids: tuple[int, ...] | None = None,
) -> TeamSafeStateAnalysis:
    exposure: dict[int, float] = {}
    pincer = 0.0
    threatened_directions = 0
    allowed_core = None if not core_actor_ids else {int(item) for item in core_actor_ids}
    core_actors = tuple(
        ally for ally in state.local_actors
        if allowed_core is None or int(ally.actor_id) in allowed_core
    )
    if not core_actors:
        core_actors = state.local_actors
    for ally in core_actors:
        actor_pincer = pincer_score_for_cell(kernel, ally.cell_id, state.enemies, capability_catalog)
        pincer = max(pincer, actor_pincer)
        normalized_factors = []
        calibrated_pressures = []
        for enemy in state.enemies:
            d = _distance(kernel, ally.cell_id, enemy.cell_id)
            normalized_factors.append(_threat_factor(d, enemy, capability_catalog))
            pressure, _capability = _enemy_pressure(kernel, enemy, ally, capability_catalog)
            calibrated_pressures.append(float(pressure))
        exposure[ally.actor_id] = round(sum(calibrated_pressures), 6)
        threatened_directions = max(
            threatened_directions,
            sum(1 for value in normalized_factors if value >= 0.65),
        )
    sectors = 2 if pincer >= 0.45 or threatened_directions >= 2 else (1 if threatened_directions else 0)
    ally_distances = [
        distance
        for left, right in combinations(core_actors, 2)
        if (distance := _distance(kernel, left.cell_id, right.cell_id)) is not None
    ]
    return TeamSafeStateAnalysis(
        pincer_score=pincer,
        threat_sectors=sectors,
        exposure_by_ally=exposure,
        max_exposure=max(exposure.values(), default=0.0),
        ally_gap=max(ally_distances, default=None),
    )

from __future__ import annotations

from dataclasses import dataclass
import time

from anka_game_kernel.domain.certainty import Certainty
from anka_game_kernel.domain.ids import ActorId, CellId, SpellId
from anka_platform.config import CombatProfileSettings, CombatSpellSettings
from anka_platform.contracts.canonical_state import CanonicalActorSnapshot, CanonicalSnapshot
from anka_platform.contracts.common import ValueStatus
from anka_platform.core.fight.decision_contract import FightDecision, FightDecisionKind
from anka_platform.core.fight.planner_contract import (
    PlannerDisposition, PlannerFailureClass, PlannerInvocationContext,
)
from anka_platform.integration.kernel_context import KernelContextAdapter, KernelContextUnavailable
from anka_platform.integration.fight_geometry import FightGeometryUnavailable, fight_context_map_definition


def _known(value):
    return value.value if value.status is ValueStatus.KNOWN else None


@dataclass(frozen=True, slots=True)
class _Enemy:
    actor_id: int
    cell_id: int
    hp: int | None


class NormalPolicy:
    """Simple deterministic-first generic FightAI.

    The policy decides only from confirmed Canonical Contract values and Kernel
    legality/projection. It never estimates live damage, resistances or hidden state.
    """

    def decide(
        self,
        kernel,
        snapshot: CanonicalSnapshot,
        local_actor_id: int,
        profile: CombatProfileSettings,
        *,
        planner_context: PlannerInvocationContext | None = None,
        decision_deadline_monotonic: float | None = None,
        objective=None,
    ) -> FightDecision:
        if planner_context is not None:
            decision_deadline_monotonic = planner_context.decision_deadline_monotonic
            objective = planner_context.objective
        fight = snapshot.fight
        if not fight.present:
            return FightDecision(FightDecisionKind.BLOCKED, "NO_ACTIVE_FIGHT", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="FIGHT_PRESENCE", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        active = _known(fight.active_actor_id)
        if active is None:
            return FightDecision(FightDecisionKind.WAIT, "ACTIVE_ACTOR_UNKNOWN", planner_dependency="TURN_OWNER", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        if int(active) != int(local_actor_id):
            return FightDecision(FightDecisionKind.WAIT, "NOT_LOCAL_TURN", planner_dependency="TURN_OWNER", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        if self._deadline_exhausted(decision_deadline_monotonic):
            return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")

        try:
            context = KernelContextAdapter(kernel).fight_context(snapshot)
        except KernelContextUnavailable as exc:
            return FightDecision(FightDecisionKind.BLOCKED, f"FIGHT_CONTEXT_UNAVAILABLE: {exc}", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="KERNEL_CONTEXT", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        if context.map_id is None:
            return FightDecision(FightDecisionKind.BLOCKED, "FIGHT_MAP_UNKNOWN", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="FIGHT_MAP", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        local = context.actor(ActorId(int(local_actor_id)))
        if local is None or local.cell_id is None:
            return FightDecision(FightDecisionKind.BLOCKED, "LOCAL_ACTOR_OR_CELL_UNKNOWN", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="LOCAL_ACTOR", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        if local.team_id is None:
            return FightDecision(FightDecisionKind.BLOCKED, "LOCAL_TEAM_UNKNOWN", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="TEAM_IDENTITY", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)

        enemies = self._enemies(snapshot, int(local_actor_id))
        if not enemies:
            return FightDecision(FightDecisionKind.END_TURN, "NO_CONFIRMED_ENEMY_TARGET")

        # R4 characteristic totals (for example AP/MP totals) are not current
        # turn resources.  Casting is unsafe until a live current-AP baseline
        # is actually observed for this actor.
        if local.current_ap is None:
            return FightDecision(FightDecisionKind.BLOCKED, "CURRENT_AP_UNKNOWN", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="CURRENT_AP", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)

        try:
            map_definition = fight_context_map_definition(kernel, context)
        except FightGeometryUnavailable as exc:
            return FightDecision(FightDecisionKind.BLOCKED, f"FIGHT_GEOMETRY_UNAVAILABLE: {exc}", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="FIGHT_GEOMETRY", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)
        cast = self._best_cast(
            kernel, context, map_definition, local, enemies, profile,
            decision_deadline_monotonic=decision_deadline_monotonic,
        )
        if cast is not None:
            return cast

        # Movement fallback is AP-independent but still requires an observed
        # current MP baseline.  Never substitute characteristic total 23.
        if local.current_mp is None:
            return FightDecision(FightDecisionKind.BLOCKED, "CURRENT_MP_UNKNOWN", planner_disposition=PlannerDisposition.WAIT_EXTERNAL, planner_dependency="CURRENT_MP", planner_failure_class=PlannerFailureClass.TRANSIENT_EXTERNAL)

        if self._deadline_exhausted(decision_deadline_monotonic):
            return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")
        move = self._best_move(
            kernel, context, map_definition, local, enemies, profile,
            decision_deadline_monotonic=decision_deadline_monotonic,
        )
        if move is not None:
            return move
        return FightDecision(FightDecisionKind.END_TURN, "NO_SAFE_CAST_OR_MOVE")

    @staticmethod
    def _enemies(snapshot: CanonicalSnapshot, local_actor_id: int) -> tuple[_Enemy, ...]:
        local_snap = next((a for a in snapshot.fight.actors if int(a.actor_id) == int(local_actor_id)), None)
        if local_snap is None:
            return ()
        local_team = _known(local_snap.team_id)
        local_side = _known(local_snap.side_relation)
        if local_team is None and local_side is None:
            return ()
        result: list[_Enemy] = []
        for actor in snapshot.fight.actors:
            if int(actor.actor_id) == int(local_actor_id):
                continue
            team = _known(actor.team_id)
            side = _known(actor.side_relation)
            cell = _known(actor.cell_id)
            alive = _known(actor.alive)
            if cell is None or alive is False:
                continue
            if local_team is not None:
                if team is None or team == local_team:
                    continue
            else:
                if side is None or side == local_side:
                    continue
            result.append(_Enemy(int(actor.actor_id), int(cell), _known(actor.hp)))
        return tuple(result)

    def _best_cast(
        self, kernel, context, map_definition, local, enemies, profile, *,
        decision_deadline_monotonic: float | None = None,
    ):
        candidates: list[tuple[tuple, FightDecision]] = []
        enemy_by_cell = {enemy.cell_id: enemy for enemy in enemies}

        # R5.195 performance hardening: resolve the composite Kernel service once
        # for the whole decision. ``GameKernel.spell_decisions`` intentionally
        # constructs an immutable service graph (overlay + action projection) on
        # access. Re-resolving it for every configured spell rebuilt and
        # revalidated that graph up to 22 times for the production CRA profile.
        # Holding the service locally is generation-safe because one planner
        # invocation already operates against one immutable Kernel generation.
        spell_decisions = kernel.spell_decisions
        for spell in profile.enabled_spells:
            if self._deadline_exhausted(decision_deadline_monotonic):
                if candidates:
                    return max(candidates, key=lambda item: item[0])[1]
                return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")
            # Candidate-first legality is both equivalent to the old policy and
            # dramatically cheaper.  NormalPolicy only ever considers confirmed
            # enemy-occupied cells as direct cast targets, so enumerating all 560
            # map cells for every one of the 22 configured CRA spells performed
            # thousands of redundant Kernel evaluations before looking at the
            # handful of cells the policy can actually select.  Keep Kernel as
            # the sole legality authority, but ask it only about each selectable
            # enemy cell.
            for cell, enemy in enemy_by_cell.items():
                if self._deadline_exhausted(decision_deadline_monotonic):
                    if candidates:
                        return max(candidates, key=lambda item: item[0])[1]
                    return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")
                target = CellId(cell)
                evaluated = spell_decisions.evaluate_cast_cell(
                    spell_id=SpellId(spell.spell_id),
                    grade=spell.grade,
                    caster_id=local.actor_id,
                    target_cell=target,
                    map_definition=map_definition,
                    context=context,
                )
                if evaluated.certainty is not Certainty.DETERMINISTIC or evaluated.legal is not True:
                    continue
                preview = spell_decisions.preview_cast(
                    spell_id=SpellId(spell.spell_id),
                    grade=spell.grade,
                    caster_id=local.actor_id,
                    target_cell=target,
                    map_definition=map_definition,
                    context=context,
                )
                target_count = self._confirmed_enemy_count(preview, enemies)
                distance = self._distance(kernel, local.cell_id, target)
                decision = FightDecision(
                    kind=FightDecisionKind.CAST,
                    reason="KERNEL_LEGAL_CAST",
                    spell_id=spell.spell_id,
                    grade=spell.grade,
                    slot_index=spell.slot_index,
                    target_cell_id=cell,
                    target_actor_id=enemy.actor_id,
                    target_count=max(1, target_count),
                )
                # Stable score: more confirmed targets, then configured priority,
                # then nearer selected cell, then stable lower CellId/spell id.
                score = (max(1, target_count), spell.priority, -distance, -cell, -spell.spell_id)
                candidates.append((score, decision))
        if not candidates:
            return None
        return max(candidates, key=lambda item: item[0])[1]

    def _best_move(
        self, kernel, context, map_definition, local, enemies, profile, *,
        decision_deadline_monotonic: float | None = None,
    ):
        """Choose a deterministic safe move without spell-profile expansion.

        R5.88 evaluated every reachable destination against every enabled spell,
        which made the production 22-spell profiles combinatorial.  Reachability
        is already a deterministic Kernel result, so movement selection can stay
        bounded by scoring those reachable endpoints geometrically.  Execution
        re-validates the selected move against the current live state before input.
        """
        if local.current_mp is None or local.current_mp <= 0:
            return None
        reachable = kernel.fight_queries.reachable_cells(map_definition, context, local.actor_id)
        if reachable.certainty is not Certainty.DETERMINISTIC:
            return None
        candidates = [item for item in reachable.reachable if item.distance > 0]
        if not candidates:
            return None

        origin_distance = min(self._distance(kernel, local.cell_id, CellId(enemy.cell_id)) for enemy in enemies)
        closer: list[tuple[tuple, FightDecision]] = []
        for item in candidates:
            if self._deadline_exhausted(decision_deadline_monotonic):
                return FightDecision(FightDecisionKind.END_TURN, "DECISION_BUDGET_EXHAUSTED")
            enemy_distance = min(self._distance(kernel, item.cell_id, CellId(enemy.cell_id)) for enemy in enemies)
            if enemy_distance >= origin_distance:
                continue
            decision = FightDecision(
                FightDecisionKind.MOVE,
                "MOVE_CLOSER_TO_ENEMY",
                target_cell_id=int(item.cell_id),
                path_distance=item.distance,
            )
            # Prefer the endpoint closest to a confirmed enemy, then the shorter
            # path, then a stable lower CellId.  This is independent of profile size.
            score = (-enemy_distance, -item.distance, -int(item.cell_id))
            closer.append((score, decision))
        return max(closer, key=lambda item: item[0])[1] if closer else None

    @staticmethod
    def _deadline_exhausted(deadline: float | None) -> bool:
        return deadline is not None and time.monotonic() >= float(deadline)

    @staticmethod
    def _confirmed_enemy_count(preview, enemies: tuple[_Enemy, ...]) -> int:
        effect = getattr(preview, "effect_resolution", None)
        if effect is None:
            return 0
        enemy_ids = {ActorId(enemy.actor_id) for enemy in enemies}
        affected: set[ActorId] = set()
        for step in effect.steps:
            affected.update(actor_id for actor_id in step.eligible_actor_ids if actor_id in enemy_ids)
        return len(affected)

    @staticmethod
    def _distance(kernel, first: CellId, second: CellId) -> int:
        return kernel.geometry.distance(
            kernel.geometry.cell_to_coordinate(first),
            kernel.geometry.cell_to_coordinate(second),
        )

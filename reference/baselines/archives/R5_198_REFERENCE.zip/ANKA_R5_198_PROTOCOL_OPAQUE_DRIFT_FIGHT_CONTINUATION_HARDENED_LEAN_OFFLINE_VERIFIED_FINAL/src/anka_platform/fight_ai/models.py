from __future__ import annotations

from dataclasses import dataclass

# Compatibility surface.  R5.148 moved the planner/executable action contract to
# core so foundation ports no longer depend on a concrete FightAI package.
from anka_platform.contracts.combat_action import ActionIntent, ImpactRequirement
from anka_platform.core.fight.decision_contract import (
    FightAdmissionMode,
    FightDecision,
    FightDecisionKind,
    action_key_from_decision,
    action_key_from_payload,
)
from anka_platform.core.fight.planner_contract import (
    PlannerDisposition,
    PlannerFailureClass,
    PlannerProgress,
)


@dataclass(frozen=True, slots=True)
class TurnGuardResult:
    allowed: bool
    reason: str
    action_count: int


class TurnSafetyGuard:
    """Fail-closed turn guard against stale-state action loops.

    This legacy helper remains under FightAI for historical callers.  Current
    PartyCombatController owns the production turn guard state.
    """

    def __init__(self, max_actions: int = 12) -> None:
        if isinstance(max_actions, bool) or not isinstance(max_actions, int) or max_actions < 1:
            raise ValueError("max_actions must be a positive integer")
        self.max_actions = max_actions
        self._turn_key: tuple | None = None
        self._action_count = 0
        self._last_revision: int | None = None
        self._last_fingerprint: tuple | None = None

    def allow(self, turn_key: tuple, *, snapshot_revision: int, decision_fingerprint: tuple) -> TurnGuardResult:
        if self._turn_key != turn_key:
            self._turn_key = tuple(turn_key)
            self._action_count = 0
            self._last_revision = None
            self._last_fingerprint = None
        if self._action_count >= self.max_actions:
            return TurnGuardResult(False, "ACTION_CEILING", self._action_count)
        if self._last_revision == int(snapshot_revision) and self._last_fingerprint == tuple(decision_fingerprint):
            return TurnGuardResult(False, "REPEATED_STATE_ACTION", self._action_count)
        self._action_count += 1
        self._last_revision = int(snapshot_revision)
        self._last_fingerprint = tuple(decision_fingerprint)
        return TurnGuardResult(True, "ALLOWED", self._action_count)


__all__ = [
    "ActionIntent",
    "ImpactRequirement",
    "FightAdmissionMode",
    "FightDecision",
    "FightDecisionKind",
    "PlannerDisposition",
    "PlannerFailureClass",
    "PlannerProgress",
    "TurnGuardResult",
    "TurnSafetyGuard",
    "action_key_from_decision",
    "action_key_from_payload",
]

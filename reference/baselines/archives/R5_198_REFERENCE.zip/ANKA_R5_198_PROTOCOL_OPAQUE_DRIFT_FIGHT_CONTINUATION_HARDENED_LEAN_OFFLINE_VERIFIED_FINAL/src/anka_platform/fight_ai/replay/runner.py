from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
from typing import Any, Mapping

from anka_platform.config import CombatProfileSettings
from anka_platform.contracts.canonical_state import CanonicalSnapshot
from anka_platform.contracts.common import ValueStatus
from anka_platform.fight_ai.front_guard_policy import FrontGuardPolicyV1
from anka_platform.fight_ai.tactical.models import ActorTacticalObjective
from anka_platform.fight_ai.tactical_policy import TacticalPolicyV1


_DECISION_FIELDS = (
    "kind", "reason", "spell_id", "grade", "slot_index", "target_cell_id",
    "path_distance", "target_actor_id", "target_count",
)


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [_jsonable(item) for item in value]
    if is_dataclass(value):
        return _jsonable(asdict(value))
    return str(value)


def decision_payload(decision) -> dict[str, object]:
    return {
        key: _jsonable(getattr(decision, key, None))
        for key in _DECISION_FIELDS
    }


def build_replay_record(trace: Mapping[str, Any] | None) -> dict[str, object] | None:
    """Build one self-contained offline replay step from a decision trace."""
    if not isinstance(trace, Mapping):
        return None
    replay_input = trace.get("replay_input")
    decision = trace.get("decision")
    if not isinstance(replay_input, Mapping) or not isinstance(decision, Mapping):
        return None
    if not isinstance(replay_input.get("canonical_snapshot"), Mapping):
        return None
    return {
        "schema_version": 1,
        "kind": "FIGHT_AI_REPLAY_STEP",
        "decision_id": trace.get("decision_id"),
        "account_id": trace.get("account_id"),
        "fight_instance_id": trace.get("fight_instance_id"),
        "canonical_revision": trace.get("canonical_revision"),
        "round": trace.get("round"),
        "turn_index": trace.get("turn_index"),
        "replay_input": dict(replay_input),
        "expected_decision": {
            key: _jsonable(decision.get(key))
            for key in _DECISION_FIELDS
        },
    }


@dataclass(frozen=True, slots=True)
class ReplayStepResult:
    exact_match: bool
    policy_id: str
    expected_decision: Mapping[str, object]
    actual_decision: Mapping[str, object]
    mismatches: Mapping[str, Mapping[str, object]]

    def as_dict(self) -> dict[str, object]:
        return {
            "exact_match": bool(self.exact_match),
            "policy_id": self.policy_id,
            "expected_decision": dict(self.expected_decision),
            "actual_decision": dict(self.actual_decision),
            "mismatches": {str(key): dict(value) for key, value in self.mismatches.items()},
        }


class TacticalReplayRunner:
    """Pure offline replay for one recorded ANKA tactical decision.

    Replay owns no execution service, window handle, transport, or control permit.
    It reconstructs only the recorded Canonical snapshot/configuration and asks the
    corresponding tactical policy what it would decide now.
    """

    def __init__(self, kernel) -> None:
        self.kernel = kernel

    def run(self, record: Mapping[str, Any]) -> ReplayStepResult:
        if str(record.get("kind") or "") != "FIGHT_AI_REPLAY_STEP":
            raise ValueError("unsupported replay record kind")
        replay_input = record.get("replay_input")
        expected = record.get("expected_decision")
        if not isinstance(replay_input, Mapping) or not isinstance(expected, Mapping):
            raise ValueError("replay record requires replay_input and expected_decision")
        raw_snapshot = replay_input.get("canonical_snapshot")
        if not isinstance(raw_snapshot, Mapping):
            raise ValueError("replay input requires canonical_snapshot")
        snapshot = CanonicalSnapshot.model_validate(raw_snapshot)
        local_actor_id = int(replay_input.get("local_actor_id"))
        policy_id = str(replay_input.get("policy_id") or "")
        objective_raw = replay_input.get("objective")
        objective = (
            ActorTacticalObjective.from_dict(objective_raw)
            if isinstance(objective_raw, Mapping) and objective_raw.get("team_plan") is not None
            else None
        )

        if policy_id == "tactical_v1":
            profile_raw = replay_input.get("combat_profile")
            if not isinstance(profile_raw, Mapping):
                raise ValueError("tactical_v1 replay requires combat_profile")
            profile = CombatProfileSettings.model_validate(profile_raw)
            actual = TacticalPolicyV1().decide(
                self.kernel, snapshot, local_actor_id, profile, objective=objective,
            )
        elif policy_id == "front_guard_v1":
            local = next(
                (actor for actor in snapshot.fight.actors if int(actor.actor_id) == local_actor_id),
                None,
            )
            current_cell = None
            if local is not None and local.cell_id.status is ValueStatus.KNOWN:
                current_cell = int(local.cell_id.value)
            actual = FrontGuardPolicyV1().decide(
                current_cell_id=current_cell,
                kernel=self.kernel,
                snapshot=snapshot,
                local_actor_id=local_actor_id,
                objective=objective,
            )
        else:
            raise ValueError(f"unsupported tactical replay policy {policy_id!r}")

        actual_payload = decision_payload(actual)
        expected_payload = {key: _jsonable(expected.get(key)) for key in _DECISION_FIELDS}
        mismatches = {
            key: {"expected": expected_payload.get(key), "actual": actual_payload.get(key)}
            for key in _DECISION_FIELDS
            if expected_payload.get(key) != actual_payload.get(key)
        }
        return ReplayStepResult(
            exact_match=not mismatches,
            policy_id=policy_id,
            expected_decision=expected_payload,
            actual_decision=actual_payload,
            mismatches=mismatches,
        )

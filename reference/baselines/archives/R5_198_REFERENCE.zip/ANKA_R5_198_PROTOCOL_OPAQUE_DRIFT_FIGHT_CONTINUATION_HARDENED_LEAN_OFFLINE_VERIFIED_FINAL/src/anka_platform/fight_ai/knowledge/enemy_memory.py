from __future__ import annotations

from dataclasses import dataclass
from threading import RLock
from typing import Any, Mapping

from anka_game_kernel.domain.ids import CellId
from anka_platform.contracts.common import ValueStatus


def _known(value):
    return value.value if getattr(value, "status", None) is ValueStatus.KNOWN else None


@dataclass(frozen=True, slots=True)
class LearnedEnemyCapability:
    static_id: int
    effective_reach: float
    confidence: float
    evidence_count: int
    evidence_kinds: tuple[str, ...]
    observed_threat_multiplier: float = 1.0
    threat_evidence_count: int = 0

    def as_dict(self) -> dict[str, object]:
        return {
            "static_id": int(self.static_id),
            "effective_reach": float(self.effective_reach),
            "confidence": float(self.confidence),
            "evidence_count": int(self.evidence_count),
            "evidence_kinds": list(self.evidence_kinds),
            "observed_threat_multiplier": float(self.observed_threat_multiplier),
            "threat_evidence_count": int(self.threat_evidence_count),
        }


@dataclass(frozen=True, slots=True)
class _LocalObservation:
    hp: int | None
    max_hp: int | None
    enemy_distances: tuple[tuple[int, float], ...]


class EnemyBehaviorMemory:
    """Bounded confidence-weighted memory for unknown monster influence reach.

    The memory is deliberately advisory.  It never authorizes casts/moves and it
    never shrinks a verified/static defensive envelope.  Ambiguous multi-enemy
    damage expands reach only by its attribution confidence; direct observations
    are stronger.  Evidence is bounded so a long campaign cannot grow memory
    without limit.
    """

    MAX_EVIDENCE_PER_MONSTER = 24
    MAX_MONSTER_PROFILES = 128
    MAX_LOCAL_OBSERVATIONS = 256
    MAX_SEEN_CASTS = 4096

    def __init__(self) -> None:
        self._lock = RLock()
        self._reach: dict[int, float] = {}
        self._confidence: dict[int, float] = {}
        self._evidence: dict[int, list[tuple[float, float, str]]] = {}
        self._threat_multiplier: dict[int, float] = {}
        self._threat_evidence: dict[int, list[tuple[float, float, str]]] = {}
        self._last_local: dict[tuple[str, int, int], _LocalObservation] = {}
        self._seen_casts: set[tuple[str, int, int, int, int, int]] = set()
        self._seen_cast_order: list[tuple[str, int, int, int, int, int]] = []

    @staticmethod
    def attribution_confidence(enemy_count: int, *, geometry_compatible: bool = True) -> float:
        if not geometry_compatible:
            return 0.05
        if enemy_count <= 1:
            return 1.0
        return max(0.20, min(0.60, 1.0 / float(enemy_count)))

    def _record(self, static_id: int, distance: float, confidence: float, kind: str) -> None:
        sid = int(static_id)
        dist = max(0.0, float(distance))
        conf = max(0.0, min(1.0, float(confidence)))
        if conf <= 0.0:
            return
        if sid not in self._evidence and len(self._evidence) >= self.MAX_MONSTER_PROFILES:
            # Dict insertion order gives a deterministic FIFO eviction policy. Live
            # evidence is advisory, so evicting the oldest profile is safer than
            # allowing unbounded process growth.  Rejecting zero-confidence input
            # above this branch is important: diagnostic noise must never evict
            # useful learned evidence.
            stale = next(iter(self._evidence))
            self._evidence.pop(stale, None)
            self._reach.pop(stale, None)
            self._confidence.pop(stale, None)
            self._threat_multiplier.pop(stale, None)
            self._threat_evidence.pop(stale, None)
        rows = self._evidence.setdefault(sid, [])
        rows.append((dist, conf, str(kind)))
        if len(rows) > self.MAX_EVIDENCE_PER_MONSTER:
            del rows[:-self.MAX_EVIDENCE_PER_MONSTER]
        current = float(self._reach.get(sid, 0.0))
        if conf >= 0.85:
            learned = max(current, dist)
        else:
            learned = max(current, current + max(0.0, dist - current) * conf)
        self._reach[sid] = learned
        self._confidence[sid] = max(float(self._confidence.get(sid, 0.0)), conf)

    def _record_threat(self, static_id: int, multiplier: float, confidence: float, kind: str) -> None:
        sid = int(static_id)
        conf = max(0.0, min(1.0, float(confidence)))
        if conf <= 0.0:
            return
        value = max(1.0, min(3.5, float(multiplier)))
        if sid not in self._evidence and sid not in self._threat_evidence and len(self._threat_evidence) >= self.MAX_MONSTER_PROFILES:
            stale = next(iter(self._threat_evidence))
            self._threat_evidence.pop(stale, None)
            self._threat_multiplier.pop(stale, None)
        rows = self._threat_evidence.setdefault(sid, [])
        rows.append((value, conf, str(kind)))
        if len(rows) > self.MAX_EVIDENCE_PER_MONSTER:
            del rows[:-self.MAX_EVIDENCE_PER_MONSTER]
        current = float(self._threat_multiplier.get(sid, 1.0))
        # Ambiguous evidence raises attention proportionally to attribution
        # confidence; strong single-enemy evidence may adopt the full observed
        # severity. Learned severity never lowers a monster's defensive prior.
        promoted = 1.0 + max(0.0, value - 1.0) * conf
        self._threat_multiplier[sid] = max(current, promoted)

    def capability_for(self, static_id: int | None) -> LearnedEnemyCapability | None:
        if static_id is None:
            return None
        sid = int(static_id)
        with self._lock:
            reach = self._reach.get(sid)
            if reach is None:
                return None
            rows = tuple(self._evidence.get(sid, ()))
            return LearnedEnemyCapability(
                static_id=sid,
                effective_reach=float(reach),
                confidence=float(self._confidence.get(sid, 0.0)),
                evidence_count=len(rows),
                evidence_kinds=tuple(sorted({kind for _dist, _conf, kind in rows})),
                observed_threat_multiplier=float(self._threat_multiplier.get(sid, 1.0)),
                threat_evidence_count=len(self._threat_evidence.get(sid, ())),
            )

    @staticmethod
    def _distance(kernel, left: int | None, right: int | None) -> float | None:
        if left is None or right is None:
            return None
        try:
            return float(kernel.geometry.distance(
                kernel.geometry.cell_to_coordinate(CellId(int(left))),
                kernel.geometry.cell_to_coordinate(CellId(int(right))),
            ))
        except Exception:
            return None

    @staticmethod
    def _static_key(enemy: Any) -> int | None:
        raw = getattr(enemy, "static_id", None)
        if raw is None:
            raw = getattr(enemy, "creature_id", None)
        return None if raw is None else int(raw)

    def observe(self, *, kernel, state, snapshots: Mapping[str, object], session_id: str) -> None:
        """Learn only from already-observed Canonical consequences.

        Two generic evidence sources are used:
        * HP loss between local decision observations, attributed conservatively to
          enemies that were in the previous geometry; and
        * confirmed enemy casts, using caster->target distance as low-confidence
          reach evidence because the caster may also have moved during the turn.
        """
        fight_id = int(state.fight_instance_id or -1)
        live_enemies = [item for item in state.enemies if item.alive is not False]
        enemy_count = len(live_enemies)
        with self._lock:
            for ally in state.local_actors:
                key = (str(session_id), fight_id, int(ally.actor_id))
                previous = self._last_local.get(key)
                if previous is not None and previous.hp is not None and ally.hp is not None and previous.max_hp:
                    lost = max(0, int(previous.hp) - int(ally.hp))
                    threshold = max(150, int(previous.max_hp * 0.08))
                    if lost >= threshold:
                        severe = lost >= max(1000, int(previous.max_hp * 0.50))
                        base_conf = 1.0 if severe else self.attribution_confidence(len(previous.enemy_distances))
                        loss_ratio = max(0.0, min(1.0, float(lost) / float(previous.max_hp)))
                        observed_multiplier = 1.0 + min(2.0, 2.5 * loss_ratio)
                        for static_id, distance in previous.enemy_distances:
                            learned_distance = float(distance) + (1.5 if severe else 0.0)
                            self._record(static_id, learned_distance, base_conf, "HP_LOSS_INFLUENCE")
                            self._record_threat(static_id, observed_multiplier, base_conf, "HP_LOSS_SEVERITY")

                distances: list[tuple[int, float]] = []
                for enemy in live_enemies:
                    sid = self._static_key(enemy)
                    distance = self._distance(kernel, ally.cell_id, enemy.cell_id)
                    if sid is not None and distance is not None:
                        distances.append((sid, distance))
                self._last_local[key] = _LocalObservation(
                    hp=ally.hp,
                    max_hp=ally.max_hp,
                    enemy_distances=tuple(distances),
                )
                while len(self._last_local) > self.MAX_LOCAL_OBSERVATIONS:
                    self._last_local.pop(next(iter(self._last_local)), None)

            # R5.134: revisions are lane-local and cannot select a cross-account
            # "newest" snapshot.  The synchronized tactical state records which
            # account owns the active actor; that lane is the authoritative
            # observation source for current-turn cast memory.  If no active-owner
            # lane exists, skip cast learning rather than guessing from peer order.
            anchor_account = getattr(state, "canonical_account_id", None)
            anchor = snapshots.get(anchor_account) if anchor_account is not None else None
            if anchor is None or not getattr(getattr(anchor, "fight", None), "present", False):
                return
            enemy_by_actor = {int(item.actor_id): item for item in live_enemies}
            casts = getattr(anchor.fight, "confirmed_casts_this_global_turn", None)
            if casts is None:
                casts = getattr(anchor.fight, "confirmed_casts_this_turn", ())
            for cast in casts or ():
                caster_id = int(cast.caster_actor_id)
                enemy = enemy_by_actor.get(caster_id)
                if enemy is None:
                    continue
                target_cell = _known(cast.target_cell_id)
                sid = self._static_key(enemy)
                if target_cell is None or sid is None:
                    continue
                token = (
                    str(session_id), fight_id, caster_id, int(cast.spell_id),
                    int(target_cell), int(getattr(cast, "observed_revision", 0)),
                )
                if token in self._seen_casts:
                    continue
                self._seen_casts.add(token)
                self._seen_cast_order.append(token)
                while len(self._seen_cast_order) > self.MAX_SEEN_CASTS:
                    stale = self._seen_cast_order.pop(0)
                    self._seen_casts.discard(stale)
                distance = self._distance(kernel, enemy.cell_id, int(target_cell))
                if distance is not None and distance > 0:
                    # Current caster cell can differ from the cast-origin cell; keep
                    # confidence intentionally low and only widen gradually.
                    self._record(sid, distance, 0.35, "CONFIRMED_CAST_GEOMETRY")

    def export_state(self) -> dict[str, object]:
        with self._lock:
            return {
                "reach": {str(key): float(value) for key, value in sorted(self._reach.items())},
                "confidence": {str(key): float(value) for key, value in sorted(self._confidence.items())},
                "threat_multiplier": {
                    str(key): float(value) for key, value in sorted(self._threat_multiplier.items())
                },
                "evidence": {
                    str(key): [
                        {"distance": float(distance), "confidence": float(confidence), "kind": kind}
                        for distance, confidence, kind in rows[-self.MAX_EVIDENCE_PER_MONSTER:]
                    ]
                    for key, rows in sorted(self._evidence.items())
                },
                "threat_evidence": {
                    str(key): [
                        {"multiplier": float(value), "confidence": float(confidence), "kind": kind}
                        for value, confidence, kind in rows[-self.MAX_EVIDENCE_PER_MONSTER:]
                    ]
                    for key, rows in sorted(self._threat_evidence.items())
                },
            }

from __future__ import annotations

from dataclasses import dataclass

from anka_platform.fight_ai.tactical.candidates import TacticalCandidate, TacticalCandidateKind


@dataclass(frozen=True, slots=True)
class EndTurnCertification:
    allowed: bool
    reason: str
    remaining_ap: int
    remaining_mp: int
    material_action_count: int = 0
    safe_move_followup_count: int = 0
    alternatives: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, object]:
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "remaining_ap": self.remaining_ap,
            "remaining_mp": self.remaining_mp,
            "material_action_count": self.material_action_count,
            "safe_move_followup_count": self.safe_move_followup_count,
            "alternatives": list(self.alternatives),
        }


def _material(candidate: TacticalCandidate) -> bool:
    return candidate.score.accepted and candidate.score.total >= 1.0 and candidate.kind is TacticalCandidateKind.CAST


def certify_end_turn(
    selected: TacticalCandidate,
    candidates: tuple[TacticalCandidate, ...] | list[TacticalCandidate],
    move_followups: dict[int, tuple[TacticalCandidate, ...] | list[TacticalCandidate]],
    *, remaining_ap: int, remaining_mp: int,
) -> tuple[TacticalCandidate, EndTurnCertification]:
    """Reference-derived fail-closed END_TURN gate.

    It understands only already-certified material casts and certified MOVE->CAST
    follow-ups. Unknown speculative sequences never force input.
    """
    ap = max(0, int(remaining_ap)); mp = max(0, int(remaining_mp))
    if selected.kind is not TacticalCandidateKind.END_TURN:
        return selected, EndTurnCertification(True, "not_end_turn_selected", ap, mp)

    current = sorted(
        (item for item in candidates if _material(item) and float(item.features.get("ap_cost", 0.0)) <= ap),
        key=lambda item: (-item.score.total, float(item.features.get("ap_cost", 0.0)), item.label),
    )
    if current:
        return current[0], EndTurnCertification(
            False, "current_material_action_available", ap, mp,
            material_action_count=len(current), alternatives=tuple(item.label for item in current[:16]),
        )

    routes: list[tuple[TacticalCandidate, TacticalCandidate, str]] = []
    for move in candidates:
        if move.kind is not TacticalCandidateKind.MOVE or not move.score.accepted:
            continue
        if float(move.features.get("mp_cost", 0.0)) > mp:
            continue
        if float(move.features.get("movement_lock_risk", 0.0)) > 0.05:
            continue
        if float(move.features.get("death_risk", 0.0)) >= 1.0:
            continue
        destination = move.decision.target_cell_id
        if destination is None:
            continue
        followups = sorted(
            (item for item in move_followups.get(int(destination), ()) if _material(item) and float(item.features.get("ap_cost", 0.0)) <= ap),
            key=lambda item: (-item.score.total, item.label),
        )
        if followups:
            routes.append((move, followups[0], f"{destination}->{followups[0].label}"))
    routes.sort(key=lambda row: (-row[1].score.total, float(row[0].features.get("mp_cost", 0.0)), row[2]))
    if routes:
        return routes[0][0], EndTurnCertification(
            False, "certified_move_followup_available", ap, mp,
            safe_move_followup_count=len(routes), alternatives=tuple(row[2] for row in routes[:16]),
        )
    return selected, EndTurnCertification(True, "positive_sequence_exhausted", ap, mp)

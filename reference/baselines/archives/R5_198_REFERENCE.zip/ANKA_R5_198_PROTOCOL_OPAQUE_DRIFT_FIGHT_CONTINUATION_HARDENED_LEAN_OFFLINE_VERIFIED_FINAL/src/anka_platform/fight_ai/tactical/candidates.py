from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Mapping

from anka_platform.core.fight.decision_contract import FightDecision
from anka_platform.fight_ai.tactical.models import CandidateScoreBreakdown


class TacticalCandidateKind(StrEnum):
    CAST = "CAST"
    MOVE = "MOVE"
    END_TURN = "END_TURN"


@dataclass(frozen=True, slots=True)
class TacticalCandidate:
    kind: TacticalCandidateKind
    decision: FightDecision
    features: Mapping[str, float] = field(default_factory=dict)
    score: CandidateScoreBreakdown = field(default_factory=lambda: CandidateScoreBreakdown(0.0))
    target_actor_id: int | None = None
    label: str = ""

    def as_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind.value,
            "decision": {
                "kind": self.decision.kind.value,
                "reason": self.decision.reason,
                "spell_id": self.decision.spell_id,
                "grade": self.decision.grade,
                "slot_index": self.decision.slot_index,
                "target_cell_id": self.decision.target_cell_id,
                "path_distance": self.decision.path_distance,
                "target_actor_id": self.decision.target_actor_id,
                "target_count": self.decision.target_count,
                "admission_mode": self.decision.admission_mode.value,
                "probe_assumptions": list(self.decision.probe_assumptions),
                "action_intent": (
                    None
                    if self.decision.action_intent is None
                    else {
                        "required_impacts": [
                            {
                                "actor_id": int(item.actor_id),
                                "effect_orders": [int(value) for value in item.effect_orders],
                                "role": str(item.role),
                            }
                            for item in self.decision.action_intent.required_impacts
                        ]
                    }
                ),
            },
            "features": {str(key): float(value) for key, value in sorted(self.features.items())},
            "score": self.score.as_dict(),
            "target_actor_id": self.target_actor_id,
            "label": self.label,
        }

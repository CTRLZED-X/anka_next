from __future__ import annotations

from dataclasses import dataclass

from anka_game_kernel.domain.ids import CellId
from anka_platform.integration.client_interaction import (
    SpellTargetInteractionStatus,
    evaluate_spell_target_interaction_admissibility,
)


@dataclass(frozen=True, slots=True)
class SpellTargetInteractionPreference:
    score: float
    surface: str
    occupied: bool
    fight_walkable: bool | None
    status: SpellTargetInteractionStatus
    reason: str

    @property
    def admissible(self) -> bool:
        return self.status is SpellTargetInteractionStatus.ADMISSIBLE


def evaluate_spell_target_interaction(
    *, kernel, map_definition, context, target_cell: CellId,
) -> SpellTargetInteractionPreference:
    result = evaluate_spell_target_interaction_admissibility(
        kernel=kernel, map_definition=map_definition, context=context, target_cell=target_cell,
    )
    return SpellTargetInteractionPreference(
        score=1.0 if result.surface == "EMPTY_FIGHT_WALKABLE" else 0.0,
        surface=result.surface,
        occupied=result.occupied,
        fight_walkable=result.fight_walkable,
        status=result.status,
        reason=result.reason,
    )

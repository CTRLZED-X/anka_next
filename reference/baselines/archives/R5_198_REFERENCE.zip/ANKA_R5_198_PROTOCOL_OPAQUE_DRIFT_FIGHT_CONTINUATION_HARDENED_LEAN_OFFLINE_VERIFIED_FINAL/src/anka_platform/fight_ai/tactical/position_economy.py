from __future__ import annotations

SAFE_ENOUGH_EXPOSURE = 0.25
DANGER_EXPOSURE = 0.60


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def safety_risk_value(exposure: float) -> float:
    """Non-linear danger value adapted from the accepted duo planner.

    Once the actor is already safe, extra spacing has small marginal value. This
    prevents the tactical planner from burning MP merely to maximize distance.
    """
    x = max(0.0, float(exposure))
    if x <= SAFE_ENOUGH_EXPOSURE:
        return 0.15 * (x / SAFE_ENOUGH_EXPOSURE) ** 2
    excess = x - SAFE_ENOUGH_EXPOSURE
    return 0.15 + 1.55 * excess + 1.15 * excess * excess


def safety_improvement_value(current_exposure: float, new_exposure: float) -> float:
    return max(0.0, safety_risk_value(current_exposure) - safety_risk_value(new_exposure))


def pm_reserve_value(*, remaining_mp: float, exposure: float, enu_controller: bool) -> float:
    remaining = max(0.0, float(remaining_mp))
    x = max(0.0, float(exposure))
    if x >= 0.85:
        urgency_factor = 0.10
    elif x >= DANGER_EXPOSURE:
        urgency_factor = 0.30
    elif x >= SAFE_ENOUGH_EXPOSURE:
        urgency_factor = 0.65
    else:
        urgency_factor = 1.0
    role_factor = 1.25 if enu_controller else 1.0
    reserve_curve = (
        min(remaining, 2.0)
        + 0.65 * min(max(0.0, remaining - 2.0), 2.0)
        + 0.35 * max(0.0, remaining - 4.0)
    )
    return role_factor * urgency_factor * reserve_curve


def minimum_sufficient_penalty(*, mp_cost: float, tactical_gain: float, exposure: float) -> float:
    spent = max(0.0, float(mp_cost))
    if spent <= 0:
        return 0.0
    gain = max(0.0, float(tactical_gain))
    urgency = _clamp01(
        (float(exposure) - SAFE_ENOUGH_EXPOSURE)
        / max(0.01, DANGER_EXPOSURE - SAFE_ENOUGH_EXPOSURE)
    )
    free_mp = 1.0 if gain >= 0.65 else 0.0
    chargeable = max(0.0, spent - free_mp)
    insufficient = max(0.0, chargeable - 1.25 * gain)
    return insufficient * (1.0 - 0.80 * urgency)

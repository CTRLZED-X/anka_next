from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Mapping


class TacticalRole(StrEnum):
    """Stable tactical responsibilities independent from physical-control ownership."""

    CRA_RANGED_CONTROL_DAMAGE = "CRA_RANGED_CONTROL_DAMAGE"
    ENU_WATER_MP_CONTROL = "ENU_WATER_MP_CONTROL"
    FRONT_GUARD = "FRONT_GUARD"
    GENERIC_ACTIVE = "GENERIC_ACTIVE"


class TacticalMode(StrEnum):
    """Team-level mode used to change priorities without changing execution semantics."""

    CONTROL_AND_FOCUS = "CONTROL_AND_FOCUS"
    KITE_AND_BURN = "KITE_AND_BURN"
    ISOLATE_AND_FOCUS = "ISOLATE_AND_FOCUS"
    SURVIVE = "SURVIVE"
    SAVE_ALLY = "SAVE_ALLY"
    BURST_KILL = "BURST_KILL"
    BREAK_PINCER = "BREAK_PINCER"
    FULL_RETREAT = "FULL_RETREAT"
    REJOIN_FORMATION = "REJOIN_FORMATION"
    ESCAPE_AND_CONTROL = "ESCAPE_AND_CONTROL"
    SETUP_NEXT_TURN = "SETUP_NEXT_TURN"


@dataclass(frozen=True, slots=True)
class TeamFightPlan:
    """One immutable shared tactical intent for a certified canonical revision.

    This is deliberately richer than the legacy ``FightObjective`` but remains a
    pure data contract.  It owns no physical input and makes no hidden-state claims.
    """

    tactical_mode: TacticalMode = TacticalMode.CONTROL_AND_FOCUS
    primary_target_actor_id: int | None = None
    priority_threat_actor_id: int | None = None
    controller_target_actor_id: int | None = None
    finisher_target_actor_id: int | None = None
    protected_actor_id: int | None = None
    disengagement_target_actor_id: int | None = None
    preferred_range_min: int | None = None
    preferred_range_max: int | None = None
    formation_intent: str | None = None
    # Shared multi-turn intent tags. These are planning/telemetry contracts only;
    # they never authorize execution or bypass Kernel legality. They make the
    # Cra/Enu coordination objective explicit so future L200 strategy can evolve
    # without changing the fight/runtime safety boundary.
    coordination_intents: tuple[str, ...] = ()
    # Canonically observed local player actors that form the Cra/Enu tactical core.
    # Guards/allied summons are intentionally excluded so front geometry is about
    # keeping the two decision-making backline actors on one useful side.
    core_actor_ids: tuple[int, ...] = ()
    threat_scores: Mapping[int, float] = field(default_factory=dict)
    pressure_by_ally: Mapping[int, float] = field(default_factory=dict)
    enemy_capabilities: Mapping[int, Mapping[str, object]] = field(default_factory=dict)
    pincer_score: float = 0.0
    threat_sectors: int = 0
    confidence: float = 1.0
    evidence: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "TeamFightPlan":
        data = dict(payload)
        return cls(
            tactical_mode=TacticalMode(str(data.get("tactical_mode") or TacticalMode.CONTROL_AND_FOCUS.value)),
            primary_target_actor_id=data.get("primary_target_actor_id"),
            priority_threat_actor_id=data.get("priority_threat_actor_id"),
            controller_target_actor_id=data.get("controller_target_actor_id"),
            finisher_target_actor_id=data.get("finisher_target_actor_id"),
            protected_actor_id=data.get("protected_actor_id"),
            disengagement_target_actor_id=data.get("disengagement_target_actor_id"),
            preferred_range_min=data.get("preferred_range_min"),
            preferred_range_max=data.get("preferred_range_max"),
            formation_intent=data.get("formation_intent"),
            coordination_intents=tuple(str(item) for item in (data.get("coordination_intents") or ())),
            core_actor_ids=tuple(int(item) for item in (data.get("core_actor_ids") or ())),
            threat_scores={int(key): float(value) for key, value in dict(data.get("threat_scores") or {}).items()},
            pressure_by_ally={int(key): float(value) for key, value in dict(data.get("pressure_by_ally") or {}).items()},
            enemy_capabilities={int(key): dict(value) for key, value in dict(data.get("enemy_capabilities") or {}).items()},
            pincer_score=float(data.get("pincer_score") or 0.0),
            threat_sectors=int(data.get("threat_sectors") or 0),
            confidence=float(data.get("confidence") if data.get("confidence") is not None else 1.0),
            evidence=tuple(str(item) for item in (data.get("evidence") or ())),
        )

    def as_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["tactical_mode"] = self.tactical_mode.value
        data["coordination_intents"] = list(self.coordination_intents)
        data["core_actor_ids"] = [int(item) for item in self.core_actor_ids]
        data["threat_scores"] = {
            str(int(actor_id)): float(score)
            for actor_id, score in sorted(self.threat_scores.items(), key=lambda item: int(item[0]))
        }
        data["pressure_by_ally"] = {
            str(int(actor_id)): float(score)
            for actor_id, score in sorted(self.pressure_by_ally.items(), key=lambda item: int(item[0]))
        }
        data["enemy_capabilities"] = {
            str(int(actor_id)): dict(payload)
            for actor_id, payload in sorted(self.enemy_capabilities.items(), key=lambda item: int(item[0]))
        }
        data["evidence"] = list(self.evidence)
        return data


@dataclass(frozen=True, slots=True)
class ActorTacticalObjective:
    """Account-specific objective derived from one ``TeamFightPlan``."""

    role: TacticalRole
    team_plan: TeamFightPlan
    target_actor_id: int | None = None
    control_target_actor_id: int | None = None
    protect_actor_id: int | None = None
    preferred_range_min: int | None = None
    preferred_range_max: int | None = None
    tags: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ActorTacticalObjective":
        data = dict(payload)
        team_raw = data.get("team_plan")
        if not isinstance(team_raw, Mapping):
            raise ValueError("actor tactical objective requires team_plan")
        return cls(
            role=TacticalRole(str(data.get("role") or TacticalRole.GENERIC_ACTIVE.value)),
            team_plan=TeamFightPlan.from_dict(team_raw),
            target_actor_id=data.get("target_actor_id"),
            control_target_actor_id=data.get("control_target_actor_id"),
            protect_actor_id=data.get("protect_actor_id"),
            preferred_range_min=data.get("preferred_range_min"),
            preferred_range_max=data.get("preferred_range_max"),
            tags=tuple(str(item) for item in (data.get("tags") or ())),
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "role": self.role.value,
            "team_plan": self.team_plan.as_dict(),
            "target_actor_id": self.target_actor_id,
            "control_target_actor_id": self.control_target_actor_id,
            "protect_actor_id": self.protect_actor_id,
            "preferred_range_min": self.preferred_range_min,
            "preferred_range_max": self.preferred_range_max,
            "tags": list(self.tags),
        }


@dataclass(frozen=True, slots=True)
class CandidateScoreBreakdown:
    """Explainable score surface shared by future CAST/MOVE/END candidates."""

    total: float
    components: Mapping[str, float] = field(default_factory=dict)
    hard_rejections: tuple[str, ...] = ()

    @property
    def accepted(self) -> bool:
        return not self.hard_rejections

    def as_dict(self) -> dict[str, object]:
        return {
            "total": float(self.total),
            "components": {
                str(key): float(value)
                for key, value in sorted(self.components.items())
            },
            "hard_rejections": list(self.hard_rejections),
            "accepted": self.accepted,
        }

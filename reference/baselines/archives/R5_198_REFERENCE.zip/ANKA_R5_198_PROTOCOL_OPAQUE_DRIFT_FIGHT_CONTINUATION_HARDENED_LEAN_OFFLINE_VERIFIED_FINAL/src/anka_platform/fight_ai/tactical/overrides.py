from __future__ import annotations

from anka_platform.fight_ai.tactical.candidates import TacticalCandidate, TacticalCandidateKind
from anka_platform.fight_ai.tactical.models import TacticalMode, TacticalRole

_DANGER_MODES = {
    TacticalMode.SURVIVE,
    TacticalMode.SAVE_ALLY,
    TacticalMode.BREAK_PINCER,
    TacticalMode.FULL_RETREAT,
    TacticalMode.ESCAPE_AND_CONTROL,
}


def material_action_value(candidate: TacticalCandidate) -> float:
    if candidate.kind is not TacticalCandidateKind.CAST or not candidate.score.accepted:
        return 0.0
    f = candidate.features
    return (
        100.0 * max(0.0, float(f.get("finish", 0.0)))
        + 2.2 * max(0.0, float(f.get("threat_reduction", 0.0)))
        + 1.5 * max(0.0, float(f.get("mp_control", 0.0)))
        + 1.15 * max(0.0, float(f.get("ap_control", 0.0)))
        + 1.0 * max(0.0, float(f.get("push", 0.0)))
        + 0.8 * max(0.0, float(f.get("recoil", 0.0)))
        + 1.2 * max(0.0, float(f.get("damage", 0.0)))
        + 1.5 * max(0.0, float(f.get("heal", 0.0)))
        + 1.0 * max(0.0, float(f.get("shield", 0.0)))
        + 0.75 * max(0.0, float(f.get("ally_ap_support", 0.0)))
        + 0.90 * max(0.0, float(f.get("ally_mp_support", 0.0)))
        + 0.65 * max(0.0, float(f.get("ally_range_support", 0.0)))
        + 0.8 * max(0.0, float(f.get("future_value", 0.0)))
    )


def material_casts(candidates: list[TacticalCandidate], *, remaining_ap: int) -> list[TacticalCandidate]:
    viable = [
        item for item in candidates
        if item.kind is TacticalCandidateKind.CAST
        and float(item.features.get("ap_cost", 0.0)) <= float(max(0, int(remaining_ap)))
        and material_action_value(item) >= 0.85
    ]
    viable.sort(key=lambda item: (
        -material_action_value(item),
        -float(item.score.total),
        float(item.features.get("ap_cost", 0.0)),
        item.label,
    ))
    return viable


def _setup_support_value(candidate: TacticalCandidate) -> float:
    if candidate.kind is not TacticalCandidateKind.CAST or not candidate.score.accepted:
        return 0.0
    f = candidate.features
    if float(f.get("enemy_resource_benefit", 0.0)) > 0.0:
        return 0.0
    return (
        1.00 * max(0.0, float(f.get("ally_ap_support", 0.0)))
        + 0.90 * max(0.0, float(f.get("ally_mp_support", 0.0)))
        + 0.85 * max(0.0, float(f.get("ally_range_support", 0.0)))
    )


def _same_turn_followup_value(candidate: TacticalCandidate) -> float:
    if candidate.kind is not TacticalCandidateKind.CAST or not candidate.score.accepted:
        return 0.0
    f = candidate.features
    return (
        100.0 * max(0.0, float(f.get("finish", 0.0)))
        + 1.5 * max(0.0, float(f.get("damage", 0.0)))
        + 1.8 * max(0.0, float(f.get("mp_control", 0.0)))
        + 1.2 * max(0.0, float(f.get("ap_control", 0.0)))
        + 1.0 * max(0.0, float(f.get("push", 0.0)))
        + 0.8 * max(0.0, float(f.get("recoil", 0.0)))
        + 1.2 * max(0.0, float(f.get("threat_reduction", 0.0)))
    )


def choose_setup_before_material_cast_override(
    selected: TacticalCandidate,
    candidates: list[TacticalCandidate],
    *,
    remaining_ap: int,
    mode: TacticalMode,
    round_number: int | None,
    already_setup_cast: bool,
) -> tuple[TacticalCandidate, str | None]:
    """Order a verified opening support cast before a proven same-turn payoff.

    Only positive AP/MP/range support already proven by Kernel effect resolution
    qualifies. The helper is opening-only, never overrides a finisher, requires
    support and the material follow-up to fit in the current AP budget, and will
    not chain another setup after any setup spell has been canonically confirmed
    this turn.
    """
    if mode is not TacticalMode.SETUP_NEXT_TURN:
        return selected, None
    if round_number is None or int(round_number) > 1 or already_setup_cast:
        return selected, None
    if float(selected.features.get("finish", 0.0)) > 0.0:
        return selected, None

    ap_budget = float(max(0, int(remaining_ap)))
    supports = [
        item for item in candidates
        if _setup_support_value(item) >= 0.75
        and float(item.features.get("ap_cost", 0.0)) <= ap_budget
    ]
    material = [
        item for item in candidates
        if _same_turn_followup_value(item) >= 0.85
        and _setup_support_value(item) <= 0.0
        and float(item.features.get("ap_cost", 0.0)) <= ap_budget
    ]
    if not supports:
        return selected, None

    # If scoring already selected a setup, keep it only when a material action
    # is provably affordable afterwards. This prevents empty/repeated setup turns.
    if _setup_support_value(selected) > 0.0:
        affordable = [
            item for item in material
            if float(selected.features.get("ap_cost", 0.0))
            + float(item.features.get("ap_cost", 0.0)) <= ap_budget
        ]
        if affordable:
            return selected, None
        if material:
            material.sort(key=lambda item: (-_same_turn_followup_value(item), -item.score.total, item.label))
            return material[0], "SETUP_WITHOUT_CERTIFIED_SAME_TURN_PAYOFF_REJECTED"
        return selected, None

    if selected.kind is not TacticalCandidateKind.CAST or _same_turn_followup_value(selected) < 0.85:
        return selected, None

    viable = [
        item for item in supports
        if float(item.features.get("ap_cost", 0.0))
        + float(selected.features.get("ap_cost", 0.0)) <= ap_budget
    ]
    if not viable:
        return selected, None
    viable.sort(key=lambda item: (-_setup_support_value(item), float(item.features.get("ap_cost", 0.0)), -item.score.total, item.label))
    return viable[0], "VERIFIED_SETUP_BEFORE_MATERIAL_CAST"


def survival_gate(
    candidates: list[TacticalCandidate], *, mode: TacticalMode,
) -> tuple[list[TacticalCandidate], tuple[str, ...]]:
    """Suppress ordinary greed while the shared plan is in critical survival mode."""
    if mode is not TacticalMode.SURVIVE:
        return candidates, ()
    eligible: list[TacticalCandidate] = []
    suppressed: list[str] = []
    for item in candidates:
        f = item.features
        escape = any(max(0.0, float(f.get(key, 0.0))) > 0 for key in (
            "position_safety", "threat_reduction", "team_reply_pressure_reduction",
            "pincer_reduction", "front_geometry",
        ))
        control = any(max(0.0, float(f.get(key, 0.0))) > 0 for key in (
            "mp_control", "ap_control", "push", "recoil", "state_control",
        ))
        support = (
            max(0.0, float(f.get("heal", 0.0))) > 0
            or max(0.0, float(f.get("shield", 0.0))) > 0
            or max(0.0, float(f.get("ally_mp_support", 0.0))) > 0
        )
        lethal = max(0.0, float(f.get("finish", 0.0))) > 0
        if escape or control or support or lethal:
            eligible.append(item)
        else:
            suppressed.append(item.label)
    return (eligible, tuple(sorted(suppressed))) if eligible else (candidates, ())



def danger_mode_gate(
    candidates: list[TacticalCandidate], *, mode: TacticalMode,
) -> tuple[list[TacticalCandidate], tuple[str, ...]]:
    """Fail closed on ordinary greed in non-SURVIVE danger modes.

    The accepted duo planner treats SAVE_ALLY/BREAK_PINCER/FULL_RETREAT/
    ESCAPE_AND_CONTROL as more than score labels.  ANKA mirrors that invariant
    only with already-certified candidate features: if a real protective/control
    action exists, ordinary damage/setup/END_TURN candidates are suppressed.  If
    no such candidate exists the original set is returned so the planner still
    chooses the least-bad legal primitive instead of deadlocking.
    """
    if mode not in {
        TacticalMode.SAVE_ALLY, TacticalMode.BREAK_PINCER,
        TacticalMode.FULL_RETREAT, TacticalMode.ESCAPE_AND_CONTROL,
    }:
        return candidates, ()

    def positive(f, *keys: str) -> bool:
        return any(max(0.0, float(f.get(key, 0.0))) > 1e-9 for key in keys)

    eligible: list[TacticalCandidate] = []
    suppressed: list[str] = []
    for item in candidates:
        if not item.score.accepted:
            suppressed.append(item.label)
            continue
        f = item.features
        control = positive(
            f, "mp_control", "ap_control", "push", "recoil",
            "threat_reduction", "team_reply_pressure_reduction",
        )
        escape = positive(
            f, "position_safety", "safety_improvement",
            "team_reply_pressure_reduction", "pincer_reduction",
        )
        support = positive(
            f, "heal", "shield", "ally_ap_support", "ally_mp_support",
            "ally_range_support",
        )
        formation = positive(f, "formation", "front_geometry")

        if mode is TacticalMode.SAVE_ALLY:
            keep = control or support or escape
        elif mode is TacticalMode.BREAK_PINCER:
            keep = control or escape or formation
        elif mode is TacticalMode.FULL_RETREAT:
            keep = control or escape or positive(f, "heal", "shield")
        else:  # ESCAPE_AND_CONTROL
            keep = control or escape

        if keep:
            eligible.append(item)
        else:
            suppressed.append(item.label)

    return (eligible, tuple(sorted(suppressed))) if eligible else (candidates, ())

def choose_control_override(
    selected: TacticalCandidate,
    candidates: list[TacticalCandidate],
    *,
    role: TacticalRole,
    mode: TacticalMode,
    priority_target_id: int | None,
    remaining_ap: int,
    priority_pressure: float = 0.0,
) -> tuple[TacticalCandidate, str | None]:
    controller_needed = mode in _DANGER_MODES or float(priority_pressure) >= 0.75
    if role is not TacticalRole.ENU_WATER_MP_CONTROL or not controller_needed:
        return selected, None
    if float(selected.features.get("finish", 0.0)) > 0:
        return selected, None

    def value(item: TacticalCandidate) -> float:
        if item.kind is not TacticalCandidateKind.CAST:
            return 0.0
        if float(item.features.get("ap_cost", 0.0)) > float(max(0, remaining_ap)):
            return 0.0
        f = item.features
        score = (
            2.2 * max(0.0, float(f.get("threat_reduction", 0.0)))
            + 1.8 * max(0.0, float(f.get("mp_control", 0.0)))
            + 1.10 * max(0.0, float(f.get("ap_control", 0.0)))
            + 0.7 * max(0.0, float(f.get("push", 0.0)))
            + 0.6 * max(0.0, float(f.get("build_affinity", 0.0)))
            + 0.5 * max(0.0, float(f.get("recoil", 0.0)))
        )
        if priority_target_id is not None and item.target_actor_id == int(priority_target_id):
            score += 0.9
        return score

    alternatives = [item for item in candidates if value(item) >= 1.0]
    if not alternatives:
        return selected, None
    alternatives.sort(key=lambda item: (-value(item), -item.score.total, item.label))
    best = alternatives[0]
    if value(best) <= value(selected) + 0.20:
        return selected, None
    return best, "ENU_CONTROLLER_CONTROL_OPPORTUNITY"


def choose_cast_before_move_override(
    selected: TacticalCandidate,
    candidates: list[TacticalCandidate],
    move_followups: dict[int, tuple[TacticalCandidate, ...]],
    *,
    remaining_ap: int,
    remaining_mp: int,
    mode: TacticalMode,
    local_hp_ratio: float | None,
    pincer_score: float,
) -> tuple[TacticalCandidate, str | None]:
    """Prefer useful AP expenditure before ordinary movement.

    Movement keeps priority only for a real survival exit or a short certified
    route that unlocks a materially stronger cast. Physical MOVE still settles
    independently and the next decision is recalculated from Canonical State.
    """
    if selected.kind is not TacticalCandidateKind.MOVE:
        return selected, None
    current = material_casts(candidates, remaining_ap=remaining_ap)
    if not current:
        return selected, None

    f = selected.features
    genuine_escape = (
        (local_hp_ratio is not None and local_hp_ratio <= 0.32 and float(f.get("threat_reduction", 0.0)) > 0)
        or (mode is TacticalMode.BREAK_PINCER and pincer_score >= 0.70 and float(f.get("position_safety", 0.0)) > 0)
        or (mode in {TacticalMode.SURVIVE, TacticalMode.FULL_RETREAT} and float(f.get("team_reply_pressure_reduction", 0.0)) >= 0.20)
    )
    if genuine_escape:
        return selected, None

    destination = selected.decision.target_cell_id
    followups = material_casts(
        list(move_followups.get(int(destination), ())) if destination is not None else [],
        remaining_ap=remaining_ap,
    )
    best_current = material_action_value(current[0])
    best_follow = material_action_value(followups[0]) if followups else 0.0
    move_cost = float(f.get("mp_cost", 0.0))
    exact_safe_move = (
        float(f.get("movement_path_certified", 0.0)) > 0
        and move_cost <= float(max(0, int(remaining_mp)))
        and float(f.get("death_risk", 0.0)) < 1.0
    )
    materially_better_after_move = bool(
        exact_safe_move
        and followups
        and move_cost <= 2.0
        and best_follow >= max(best_current + 1.0, best_current * 1.35)
    )
    if materially_better_after_move:
        return selected, None
    return current[0], "CAST_BEFORE_UNNECESSARY_MOVE"


def choose_disengage_override(
    selected: TacticalCandidate,
    candidates: list[TacticalCandidate],
    *,
    remaining_ap: int,
) -> tuple[TacticalCandidate, str | None]:
    """Prefer deterministic push/control before walking away from adjacency.

    This is intentionally not a guessed tackle model.  It triggers only when the
    selected MOVE records an observed adjacent enemy and a currently legal CAST
    can materially displace/control that threat. The physical cast still settles
    independently and the next primitive action is replanned from Canonical State.
    """
    if selected.kind is not TacticalCandidateKind.MOVE:
        return selected, None
    if float(selected.features.get("adjacent_enemy", 0.0)) <= 0.0:
        return selected, None

    def value(item: TacticalCandidate) -> float:
        if item.kind is not TacticalCandidateKind.CAST:
            return 0.0
        if float(item.features.get("ap_cost", 0.0)) > float(max(0, int(remaining_ap))):
            return 0.0
        f = item.features
        return (
            2.2 * max(0.0, float(f.get("push", 0.0)))
            + 1.8 * max(0.0, float(f.get("recoil", 0.0)))
            + 1.6 * max(0.0, float(f.get("mp_control", 0.0)))
            + 1.2 * max(0.0, float(f.get("state_control", 0.0)))
            + 1.5 * max(0.0, float(f.get("team_reply_pressure_reduction", 0.0)))
            + 0.8 * max(0.0, float(f.get("threat_reduction", 0.0)))
        )

    alternatives = [item for item in candidates if value(item) >= 1.0]
    if not alternatives:
        return selected, None
    alternatives.sort(key=lambda item: (-value(item), -item.score.total, item.label))
    return alternatives[0], "DISENGAGE_CAST_BEFORE_ADJACENT_MOVE"

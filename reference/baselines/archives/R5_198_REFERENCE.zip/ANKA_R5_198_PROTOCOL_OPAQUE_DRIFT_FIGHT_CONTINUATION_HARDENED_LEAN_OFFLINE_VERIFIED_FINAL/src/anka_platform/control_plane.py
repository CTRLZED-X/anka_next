from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import webbrowser

import yaml

from anka_platform.config import load_platform_config


@dataclass(frozen=True)
class ControlPlaneEndpoint:
    scheme: str
    bind_host: str
    connect_host: str
    port: int

    @property
    def base_url(self) -> str:
        return f"{self.scheme}://{_url_host(self.connect_host)}:{self.port}"

    @property
    def readiness_url(self) -> str:
        return f"{self.base_url}/api/party/status"

    @property
    def identity_url(self) -> str:
        return f"{self.base_url}/api/meta/server"

    @property
    def dashboard_url(self) -> str:
        return f"{self.base_url}/dashboard3"

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload.update(
            base_url=self.base_url,
            readiness_url=self.readiness_url,
            identity_url=self.identity_url,
            dashboard_url=self.dashboard_url,
        )
        return payload


def _url_host(host: str) -> str:
    value = str(host or "").strip()
    if ":" in value and not value.startswith("["):
        return f"[{value}]"
    return value


def _connect_host(bind_host: str) -> str:
    value = str(bind_host or "").strip()
    if value in {"::", "[::]"}:
        return "::1"
    if value in {"", "0.0.0.0", "*", "+"}:
        return "127.0.0.1"
    return value


def resolve_control_plane_endpoint(config_path: str | Path) -> ControlPlaneEndpoint:
    path = Path(config_path).resolve()
    # The supervisor must be able to resolve the bind endpoint even when another
    # unrelated part of config.yaml is invalid, so startup can fail at the real
    # server/config boundary rather than silently falling back to a hard-coded
    # port. Prefer the validated PlatformConfig, then use a narrow web-only parse.
    try:
        config = load_platform_config(path)
        bind_host = str(config.web.host or "127.0.0.1").strip() or "127.0.0.1"
        port = int(config.web.port)
    except Exception:
        bind_host = "127.0.0.1"
        port = 8000
        try:
            raw = yaml.safe_load(path.read_text(encoding="utf-8")) if path.is_file() else {}
            web = dict(raw.get("web") or {}) if isinstance(raw, dict) else {}
            bind_host = str(web.get("host") or bind_host).strip() or bind_host
            port = int(web.get("port") or port)
            if not 1 <= port <= 65535:
                port = 8000
        except Exception:
            pass
    return ControlPlaneEndpoint(
        scheme="http",
        bind_host=bind_host,
        connect_host=_connect_host(bind_host),
        port=port,
    )


def control_plane_state_directory() -> Path:
    """Return the stable per-user cross-release control-plane state directory."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA")
        if base:
            return Path(base) / "ANKA"
        return Path.home() / "AppData" / "Local" / "ANKA"
    xdg = os.environ.get("XDG_STATE_HOME")
    if xdg:
        return Path(xdg) / "anka"
    return Path.home() / ".anka"


def control_plane_lease_path() -> Path:
    return control_plane_state_directory() / "control_plane_lease.json"


def read_control_plane_lease(path: str | Path | None = None) -> dict | None:
    target = Path(path) if path is not None else control_plane_lease_path()
    try:
        payload = json.loads(target.read_text(encoding="utf-8"))
    except Exception:
        return None
    return dict(payload) if isinstance(payload, dict) else None


def write_control_plane_lease(payload: dict, path: str | Path | None = None) -> Path:
    target = Path(path) if path is not None else control_plane_lease_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    body = dict(payload)
    body.setdefault("schema_version", 1)
    body.setdefault("server_kind", "ANKA_PLATFORM")
    body["updated_utc"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(body, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    tmp.replace(target)
    return target


def clear_control_plane_lease_if_generation_matches(
    *, pid: int, process_creation_time_utc: str | None, path: str | Path | None = None
) -> None:
    target = Path(path) if path is not None else control_plane_lease_path()
    lease = read_control_plane_lease(target)
    if not lease:
        return
    try:
        lease_pid = int(lease.get("pid"))
    except (TypeError, ValueError):
        return
    if lease_pid != int(pid):
        return
    expected = str(process_creation_time_utc or "").strip()
    actual = str(lease.get("process_creation_time_utc") or "").strip()
    if expected and actual and expected != actual:
        return
    try:
        target.unlink(missing_ok=True)
    except Exception:
        pass


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Resolve the configured ANKA control-plane endpoint")
    parser.add_argument("--config", type=Path, default=Path("config.yaml"))
    parser.add_argument(
        "--field",
        choices=("base_url", "readiness_url", "identity_url", "dashboard_url", "bind_host", "connect_host", "port", "json"),
        default="base_url",
    )
    parser.add_argument("--open-dashboard", action="store_true")
    return parser


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    endpoint = resolve_control_plane_endpoint(args.config)
    if args.open_dashboard:
        # The localhost origin is intentionally reused across ANKA checkpoints.
        # Open a build-qualified URL so Chrome cannot restore a document from an
        # older Script Studio generation during a cross-release handover.
        from urllib.parse import urlencode
        from anka_platform.web.frontend_integrity import SCRIPT_STUDIO_UI_BUILD_ID
        launch_url = endpoint.dashboard_url + "?" + urlencode({"anka_ui": SCRIPT_STUDIO_UI_BUILD_ID})
        print(f"ANKA_DASHBOARD_URL={launch_url}")
        try:
            webbrowser.open(launch_url, new=2)
        except Exception as exc:
            print(f"ANKA_DASHBOARD_OPEN=WARNING detail={type(exc).__name__}:{exc}")
            return 1
        print("ANKA_DASHBOARD_OPEN=REQUESTED")
        return 0
    if args.field == "json":
        print(json.dumps(endpoint.to_dict(), sort_keys=True))
    else:
        print(getattr(endpoint, args.field))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import json
import os
import platform
import subprocess
from typing import Iterable


def parse_netstat_tcp(text: str) -> list[dict]:
    rows: list[dict] = []
    for raw in str(text or '').splitlines():
        parts = raw.split()
        if len(parts) < 5 or parts[0].upper() != 'TCP':
            continue
        try:
            pid = int(parts[-1])
        except (TypeError, ValueError):
            continue
        rows.append({
            'protocol': 'TCP',
            'local': parts[1],
            'remote': parts[2],
            'state': parts[3],
            'pid': pid,
        })
    return rows


def _endpoint_port(endpoint: str) -> int | None:
    value = str(endpoint or '').strip()
    if not value:
        return None
    if value.startswith('['):
        end = value.rfind(']:')
        if end < 0:
            return None
        raw = value[end + 2:]
    else:
        if ':' not in value:
            return None
        raw = value.rsplit(':', 1)[-1]
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _run(args: list[str], timeout: float = 5.0) -> dict:
    try:
        completed = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=max(0.1, float(timeout)),
            shell=False,
            errors='replace',
        )
        return {
            'command': list(args),
            'returncode': int(completed.returncode),
            'stdout': completed.stdout[-64 * 1024:],
            'stderr': completed.stderr[-64 * 1024:],
        }
    except Exception as exc:
        return {
            'command': list(args),
            'error': f'{type(exc).__name__}: {exc}',
        }


def windows_process_metadata_diagnostic(pid: int) -> tuple[dict | None, dict]:
    """Return best-effort process-generation evidence plus probe diagnostics.

    Win32_Process/CIM can be unavailable on otherwise healthy Windows hosts.  A
    failed CIM query must not erase the process generation that Get-Process can
    still provide (PID + StartTime).  Command-line attribution remains stronger
    and is preserved when CIM succeeds; the fallback is intentionally narrower.
    """
    try:
        process_id = int(pid)
    except (TypeError, ValueError):
        return None, {'status': 'INVALID_PID', 'pid': pid}
    if process_id <= 0 or os.name != 'nt':
        return None, {'status': 'WINDOWS_ONLY' if os.name != 'nt' else 'INVALID_PID', 'pid': process_id}

    cim_script = (
        "$ErrorActionPreference='Stop';"
        f"$p=Get-CimInstance Win32_Process -Filter \"ProcessId = {process_id}\";"
        "if($null -eq $p){exit 3};"
        f"$g=Get-Process -Id {process_id} -ErrorAction Stop;"
        "$o=[pscustomobject]@{"
        "pid=[int]$p.ProcessId;"
        "name=[string]$p.Name;"
        "executable_path=[string]$p.ExecutablePath;"
        "command_line=[string]$p.CommandLine;"
        "process_creation_time_utc=$g.StartTime.ToUniversalTime().ToString('o');"
        "metadata_source='CIM_AND_GET_PROCESS'"
        "};"
        "$o|ConvertTo-Json -Compress"
    )
    primary = _run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', cim_script], timeout=4.0)
    attempts = [{key: value for key, value in primary.items() if key != 'stdout'}]
    if primary.get('returncode') == 0:
        try:
            payload = json.loads(str(primary.get('stdout') or '').strip())
        except Exception as exc:
            attempts[-1]['parse_error'] = f'{type(exc).__name__}: {exc}'
        else:
            if isinstance(payload, dict):
                try:
                    payload['pid'] = int(payload.get('pid'))
                except (TypeError, ValueError):
                    pass
                else:
                    return payload, {'status': 'READY', 'source': 'CIM_AND_GET_PROCESS', 'attempts': attempts}

    # Fallback intentionally avoids CIM/WMI.  It is sufficient for process-
    # generation safety even when command line / executable path are unavailable.
    fallback_script = (
        "$ErrorActionPreference='Stop';"
        f"$g=Get-Process -Id {process_id} -ErrorAction Stop;"
        "$path=''; try{$path=[string]$g.Path}catch{};"
        "$o=[pscustomobject]@{"
        "pid=[int]$g.Id;"
        "name=([string]$g.ProcessName + '.exe');"
        "executable_path=$path;"
        "command_line='';"
        "process_creation_time_utc=$g.StartTime.ToUniversalTime().ToString('o');"
        "metadata_source='GET_PROCESS_FALLBACK'"
        "};"
        "$o|ConvertTo-Json -Compress"
    )
    fallback = _run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', fallback_script], timeout=4.0)
    attempts.append({key: value for key, value in fallback.items() if key != 'stdout'})
    if fallback.get('returncode') == 0:
        try:
            payload = json.loads(str(fallback.get('stdout') or '').strip())
        except Exception as exc:
            attempts[-1]['parse_error'] = f'{type(exc).__name__}: {exc}'
        else:
            if isinstance(payload, dict):
                try:
                    payload['pid'] = int(payload.get('pid'))
                except (TypeError, ValueError):
                    pass
                else:
                    return payload, {'status': 'READY', 'source': 'GET_PROCESS_FALLBACK', 'attempts': attempts}
    return None, {'status': 'UNAVAILABLE', 'pid': process_id, 'attempts': attempts}


def windows_process_metadata(pid: int) -> dict | None:
    metadata, _diagnostics = windows_process_metadata_diagnostic(pid)
    return metadata


def windows_tcp_listeners(port: int) -> tuple[list[dict], dict]:
    """Return LISTENING rows for one port plus command diagnostics."""
    try:
        wanted = int(port)
    except (TypeError, ValueError):
        return [], {'error': f'invalid port: {port!r}'}
    if os.name != 'nt':
        return [], {'status': 'WINDOWS_ONLY'}
    netstat = _run(['netstat', '-ano', '-p', 'tcp'])
    rows = parse_netstat_tcp(str(netstat.get('stdout') or ''))
    listeners = [
        row for row in rows
        if str(row.get('state') or '').upper() == 'LISTENING' and _endpoint_port(str(row.get('local') or '')) == wanted
    ]
    return listeners, {key: value for key, value in netstat.items() if key != 'stdout'}


def collect_windows_network_diagnostics(
    pids: Iterable[int] = (), *, listening_ports: Iterable[int] = ()
) -> dict:
    requested = sorted({int(pid) for pid in pids if int(pid) > 0})
    ports = sorted({int(port) for port in listening_ports if 0 < int(port) <= 65535})
    result = {
        'platform': platform.platform(),
        'status': 'WINDOWS_ONLY' if os.name != 'nt' else 'COLLECTED',
        'requested_pids': requested,
        'requested_listening_ports': ports,
        'tcp_connections': [],
        'listening_owners': [],
        'services': {},
    }
    if os.name != 'nt':
        return result

    netstat = _run(['netstat', '-ano', '-p', 'tcp'])
    result['netstat'] = {
        key: value for key, value in netstat.items() if key not in {'stdout'}
    }
    all_rows = parse_netstat_tcp(str(netstat.get('stdout') or ''))
    if requested or ports:
        rows = [
            row for row in all_rows
            if int(row.get('pid') or 0) in requested
            or _endpoint_port(str(row.get('local') or '')) in ports
        ]
    else:
        rows = all_rows
    result['tcp_connections'] = rows

    owner_pids = sorted({
        int(row.get('pid') or 0)
        for row in all_rows
        if str(row.get('state') or '').upper() == 'LISTENING'
        and _endpoint_port(str(row.get('local') or '')) in ports
        and int(row.get('pid') or 0) > 0
    })
    for pid in owner_pids:
        metadata, metadata_diag = windows_process_metadata_diagnostic(pid)
        if metadata is not None:
            result['listening_owners'].append({**metadata, 'metadata_probe': metadata_diag})
        else:
            result['listening_owners'].append({
                'pid': pid,
                'metadata_status': 'UNAVAILABLE',
                'metadata_probe': metadata_diag,
            })

    for service in ('npcap', 'npf'):
        result['services'][service] = _run(['sc', 'query', service], timeout=3.0)
    return result

"""Bounded host diagnostics used only for debugging and certification evidence."""

from __future__ import annotations

from anka_platform.contracts.canonical_state import CanonicalActorSnapshot, CanonicalSnapshot
from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id


def _actor(snapshot: CanonicalSnapshot, actor_id: int) -> CanonicalActorSnapshot | None:
    if not snapshot.fight.present:
        return None
    return next((item for item in snapshot.fight.actors if item.actor_id == actor_id), None)


def local_turn_readiness_payload(snapshot: CanonicalSnapshot) -> dict:
    """Return pure Canonical turn-start resource readiness evidence.

    Unchanged AP/MP can legitimately arrive immediately before TURN_STARTED.
    The reducer freezes one resource-freshness floor when each authoritative
    turn is accepted: ACTIVE for the first turn, TURN_ENDED for a proven
    handoff, or TURN_STARTED itself when the handoff boundary is missing.

    This function is deliberately infrastructure-neutral.  It is consumed by
    both the deterministic fight controller and the physical execution layer,
    so the core never imports execution/protocol/capture infrastructure.
    """
    fight = snapshot.fight
    if not fight.present or fight.turn_observed_revision <= 0:
        return {"status": "READY", "missing_requirements": []}

    local_actor_id = authoritative_canonical_local_actor_id(snapshot)
    active = fight.active_actor_id
    if local_actor_id is None or active.status is not ValueStatus.KNOWN or int(local_actor_id) != int(active.value):
        return {"status": "READY", "missing_requirements": []}

    actor_id = int(local_actor_id)
    actor = _actor(snapshot, actor_id)
    if actor is None:
        return {
            "status": "WAITING",
            "action_kind": "turn_start",
            "basis_revision": fight.turn_observed_revision,
            "current_revision": snapshot.revision,
            "missing_requirements": [f"actor:{actor_id}:snapshot"],
        }

    if int(fight.turn_resource_floor_revision or 0) > 0:
        freshness_floor = int(fight.turn_resource_floor_revision)
        readiness_basis = str(fight.turn_resource_floor_basis or "POST_TURN_STRICT")
    else:
        # Backward-compatible fail-closed behavior for snapshots serialized
        # before the per-turn watermark existed.
        freshness_floor = int(fight.turn_observed_revision)
        readiness_basis = "LEGACY_POST_TURN_STRICT"

    missing: list[str] = []
    if actor.ap.status is not ValueStatus.KNOWN or actor.observed.ap_revision <= freshness_floor:
        missing.append(f"actor:{actor_id}:ap")
    if actor.mp.status is not ValueStatus.KNOWN or actor.observed.mp_revision <= freshness_floor:
        missing.append(f"actor:{actor_id}:mp")

    payload = {
        "status": "READY" if not missing else "WAITING",
        "action_kind": "turn_start",
        "basis_revision": fight.turn_observed_revision,
        "freshness_floor_revision": freshness_floor,
        "readiness_basis": readiness_basis,
        "ap_revision": int(actor.observed.ap_revision),
        "mp_revision": int(actor.observed.mp_revision),
        "missing_requirements": missing,
    }
    if missing:
        payload["current_revision"] = snapshot.revision
    else:
        payload["settled_revision"] = snapshot.revision
    return payload

from __future__ import annotations

from contextlib import contextmanager
from threading import RLock, get_ident
from time import monotonic_ns
from typing import Iterator


class InputArbiter:
    """Serialize physical UI send sequences across Dofus account lanes.

    The lock is re-entrant so one action may lease at a high level and reuse
    helpers that also lease defensively. Ownership is diagnostic only; it never
    authorizes an action by itself.
    """

    def __init__(self, *, max_wait_seconds: float | None = 60.0) -> None:
        self._lock = RLock()
        self._state_lock = RLock()
        self._active_owner: str | None = None
        self._owner_thread: int | None = None
        self._owner_started_monotonic_ns: int | None = None
        self._depth = 0
        self._previous_owner: str | None = None
        self._last_released_owner: str | None = None
        self._handoff_changed = False
        self._handoff_sequence = 0
        self._waiter_count = 0
        self._max_wait_seconds = None if max_wait_seconds is None else max(0.0, float(max_wait_seconds))

    @property
    def active_owner(self) -> str | None:
        with self._state_lock:
            return self._active_owner

    @property
    def previous_owner(self) -> str | None:
        with self._state_lock:
            return self._previous_owner

    @property
    def last_released_owner(self) -> str | None:
        with self._state_lock:
            return self._last_released_owner

    @property
    def handoff_changed(self) -> bool:
        with self._state_lock:
            return bool(self._handoff_changed)

    @property
    def handoff_sequence(self) -> int:
        with self._state_lock:
            return int(self._handoff_sequence)

    def snapshot(self) -> dict[str, object]:
        """Return one internally consistent diagnostic view of lease ownership.

        Reading the individual properties one-by-one can span a handoff and
        produce a combination of fields that never existed at one instant.
        Diagnostics should use this atomic snapshot instead.  It is read-only
        and does not authorize or acquire the physical-input lease.
        """
        with self._state_lock:
            owner_age_ms = None
            if self._owner_started_monotonic_ns is not None:
                owner_age_ms = max(0.0, (monotonic_ns() - self._owner_started_monotonic_ns) / 1_000_000.0)
            return {
                "active_owner": self._active_owner,
                "owner_thread": self._owner_thread,
                "owner_started_monotonic_ns": self._owner_started_monotonic_ns,
                "owner_age_ms": owner_age_ms,
                "depth": int(self._depth),
                "previous_owner": self._previous_owner,
                "last_released_owner": self._last_released_owner,
                "handoff_changed": bool(self._handoff_changed),
                "handoff_sequence": int(self._handoff_sequence),
                "waiter_count": int(self._waiter_count),
                "max_wait_seconds": self._max_wait_seconds,
                "authority": "DIAGNOSTIC_ONLY",
            }

    @contextmanager
    def lease(self, account_id: str) -> Iterator[None]:
        account = str(account_id).strip()
        if not account:
            raise ValueError("account_id must not be empty")
        thread_id = get_ident()
        with self._state_lock:
            self._waiter_count += 1
        acquired = False
        lease_registered = False
        try:
            if self._max_wait_seconds is None:
                self._lock.acquire()
                acquired = True
            else:
                acquired = bool(self._lock.acquire(timeout=self._max_wait_seconds))
            if not acquired:
                with self._state_lock:
                    owner_age_ms = None
                    if self._owner_started_monotonic_ns is not None:
                        owner_age_ms = max(
                            0.0,
                            (monotonic_ns() - self._owner_started_monotonic_ns) / 1_000_000.0,
                        )
                    raise RuntimeError(
                        "input arbiter owner appears stuck; refusing to steal physical-input lease "
                        f"active_owner={self._active_owner!r} owner_thread={self._owner_thread} "
                        f"owner_age_ms={owner_age_ms}"
                    )
            with self._state_lock:
                self._waiter_count = max(0, self._waiter_count - 1)
                if self._depth and self._owner_thread == thread_id and self._active_owner != account:
                    raise RuntimeError(
                        f"input lease re-entry changed owner: {self._active_owner!r} -> {account!r}"
                    )
                if self._depth == 0:
                    previous = self._last_released_owner
                    self._previous_owner = previous
                    self._handoff_changed = previous is not None and previous != account
                    if self._handoff_changed:
                        self._handoff_sequence += 1
                    self._active_owner = account
                    self._owner_thread = thread_id
                    self._owner_started_monotonic_ns = monotonic_ns()
                self._depth += 1
                lease_registered = True
            yield
        finally:
            if not acquired:
                with self._state_lock:
                    self._waiter_count = max(0, self._waiter_count - 1)
            else:
                if lease_registered:
                    with self._state_lock:
                        self._depth -= 1
                        if self._depth == 0:
                            self._last_released_owner = self._active_owner
                            self._active_owner = None
                            self._owner_thread = None
                            self._owner_started_monotonic_ns = None
                self._lock.release()

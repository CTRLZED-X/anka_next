from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from anka_platform.contracts.canonical_state import CanonicalActorSnapshot, CanonicalSnapshot
from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import authoritative_canonical_local_actor_id


class SettlementReadiness(str, Enum):
    READY = "READY"
    WAITING = "WAITING"


@dataclass(frozen=True, slots=True)
class SettlementRequirement:
    actor_id: int
    field: str
    after_revision: int
    # REVISION accepts any newer observation of the field. RESOURCE_DECREASE is
    # stronger: it accepts either an explicit ResourceChanged watermark or a
    # newer numerically lower value than the pre-action baseline. This prevents
    # a repeated stale AP/MP stats snapshot from falsely settling a spend.
    mode: str = "REVISION"
    baseline_value: int | None = None

    @property
    def key(self) -> str:
        return f"actor:{self.actor_id}:{self.field}"


@dataclass(frozen=True, slots=True)
class PendingSettlement:
    action_kind: str
    basis_revision: int
    server_confirmed_revision: int
    requirements: tuple[SettlementRequirement, ...]


def _actor(snapshot: CanonicalSnapshot, actor_id: int) -> CanonicalActorSnapshot | None:
    if not snapshot.fight.present:
        return None
    return next((item for item in snapshot.fight.actors if item.actor_id == actor_id), None)


def observation_revision(snapshot: CanonicalSnapshot, requirement: SettlementRequirement) -> int:
    actor = _actor(snapshot, requirement.actor_id)
    if actor is None:
        return 0
    attr = f"{requirement.field}_revision"
    return int(getattr(actor.observed, attr, 0))


def requirement_satisfied(snapshot: CanonicalSnapshot, requirement: SettlementRequirement) -> bool:
    actor = _actor(snapshot, requirement.actor_id)
    if actor is None:
        return False
    revision = observation_revision(snapshot, requirement)
    if str(requirement.mode).upper() != "RESOURCE_DECREASE":
        return revision > requirement.after_revision

    field = str(requirement.field)
    if field not in {"ap", "mp"}:
        return False
    explicit_revision = int(getattr(actor.observed, f"{field}_resource_revision", 0))
    if explicit_revision > requirement.after_revision:
        return True
    semantic = getattr(actor, field, None)
    baseline = requirement.baseline_value
    return bool(
        baseline is not None
        and semantic is not None
        and semantic.status is ValueStatus.KNOWN
        and revision > requirement.after_revision
        and int(semantic.value) < int(baseline)
    )


def missing_requirements(snapshot: CanonicalSnapshot, pending: PendingSettlement) -> tuple[str, ...]:
    return tuple(
        requirement.key
        for requirement in pending.requirements
        if not requirement_satisfied(snapshot, requirement)
    )


def readiness_payload(snapshot: CanonicalSnapshot, pending: PendingSettlement | None) -> dict:
    if pending is None:
        return {"status": SettlementReadiness.READY.value, "missing_requirements": []}
    missing = missing_requirements(snapshot, pending)
    if not missing:
        return {
            "status": SettlementReadiness.READY.value,
            "action_kind": pending.action_kind,
            "basis_revision": pending.basis_revision,
            "server_confirmed_revision": pending.server_confirmed_revision,
            "settled_revision": snapshot.revision,
            "missing_requirements": [],
        }
    return {
        "status": SettlementReadiness.WAITING.value,
        "action_kind": pending.action_kind,
        "basis_revision": pending.basis_revision,
        "server_confirmed_revision": pending.server_confirmed_revision,
        "current_revision": snapshot.revision,
        "missing_requirements": list(missing),
    }

# Backward-compatible import surface.  The pure turn-start readiness rule lives
# outside execution because deterministic core orchestration consumes it too.
from anka_platform.canonical_readiness import local_turn_readiness_payload  # noqa: E402,F401

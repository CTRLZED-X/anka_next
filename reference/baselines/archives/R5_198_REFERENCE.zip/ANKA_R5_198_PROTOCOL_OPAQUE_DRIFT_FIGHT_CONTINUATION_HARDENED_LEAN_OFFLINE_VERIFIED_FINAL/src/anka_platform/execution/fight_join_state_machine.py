from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class PendingJoinAttempt:
    """Input-free settlement context for one already-sent follower join click.

    The stable fight instance owns the retry fence.  Once physical input was sent,
    later calls must observe this attempt before they can ever authorize another
    click.  This prevents a slow client transition from being mistaken for a
    no-interaction result merely because presentation metadata changed or vanished
    while Dofus was loading the combat scene.
    """

    fight_instance_id: int
    presentation_id: int | None
    physical_attempt: int
    sent_after_monotonic_ms: int
    client_instance_id: str | None
    join_method: str
    protocol_presentation_ready: bool | None
    join_readiness_source: str | None
    join_target_diagnostics: dict | None
    before_world_map_id: int | None
    before_world_cell_id: int | None
    before_transition_revision: int
    # Exact semantic correlation target for revisions whose JOIN_FIGHT_REQUEST
    # carries a leader/controller actor id.  Keeping it on the pending physical
    # transaction prevents an unrelated/manual join request on the same client
    # from being accepted as proof for this retry fence.
    leader_actor_id: int | None = None
    local_actor_id: int | None = None
    local_actor_source: str | None = None
    local_actor_rank: int | None = None
    semantic_request_observed: bool | None = None
    semantic_request_evidence: dict | None = None
    context_transition_map_id: int | None = None
    context_transition_revision: int | None = None


@dataclass(slots=True)
class FightJoinAttemptLedger:
    """Per-runtime physical retry fence for follower fight joining.

    Target acquisition may be retried without input, but one fight instance gets
    at most two physical click attempts even if presentation metadata arrives later.
    After a click, the ledger also owns a pending settlement record so repeated
    script calls remain observe-only while the Dofus client is still entering the
    fight.  A proven target miss or closed lifecycle is terminal for that fight.
    """

    max_physical_attempts: int = 2
    _attempts: dict[tuple[int, int | None], int] = field(default_factory=dict)
    _terminal: dict[tuple[int, int | None], tuple[str, str]] = field(default_factory=dict)
    _pending: dict[tuple[int, int | None], PendingJoinAttempt] = field(default_factory=dict)

    @staticmethod
    def key(fight_instance_id: int, presentation_id: int | None) -> tuple[int, int | None]:
        # fight_instance_id is the stable retry authority. presentation_id may be
        # absent on the first discovery observation and appear milliseconds later
        # through richer presentation evidence; it must never reset the physical
        # click budget or pending attempt.
        return int(fight_instance_id), None

    def attempts(self, fight_instance_id: int, presentation_id: int | None) -> int:
        return self._attempts.get(self.key(fight_instance_id, presentation_id), 0)

    def terminal(self, fight_instance_id: int, presentation_id: int | None) -> tuple[str, str] | None:
        return self._terminal.get(self.key(fight_instance_id, presentation_id))

    def pending(self, fight_instance_id: int, presentation_id: int | None) -> PendingJoinAttempt | None:
        return self._pending.get(self.key(fight_instance_id, presentation_id))

    def pending_attempts(self) -> tuple[PendingJoinAttempt, ...]:
        """Return current unresolved join attempts without exposing mutable storage.

        Join settlement begins while the follower can still be in WORLD state, so
        callers that need to know whether live server truth is currently required
        cannot key the lookup from the follower's canonical fight snapshot alone.
        """
        return tuple(self._pending.values())

    def can_click(self, fight_instance_id: int, presentation_id: int | None) -> bool:
        key = self.key(fight_instance_id, presentation_id)
        return (
            key not in self._terminal
            and key not in self._pending
            and self._attempts.get(key, 0) < self.max_physical_attempts
        )

    def record_click(self, fight_instance_id: int, presentation_id: int | None) -> int:
        key = self.key(fight_instance_id, presentation_id)
        value = self._attempts.get(key, 0) + 1
        self._attempts[key] = value
        return value

    def mark_pending(self, pending: PendingJoinAttempt) -> None:
        key = self.key(pending.fight_instance_id, pending.presentation_id)
        self._pending[key] = pending

    def clear_pending(self, fight_instance_id: int, presentation_id: int | None) -> None:
        self._pending.pop(self.key(fight_instance_id, presentation_id), None)

    def mark_terminal(self, fight_instance_id: int, presentation_id: int | None, status: str, detail: str) -> None:
        key = self.key(fight_instance_id, presentation_id)
        self._pending.pop(key, None)
        self._terminal[key] = (str(status), str(detail))

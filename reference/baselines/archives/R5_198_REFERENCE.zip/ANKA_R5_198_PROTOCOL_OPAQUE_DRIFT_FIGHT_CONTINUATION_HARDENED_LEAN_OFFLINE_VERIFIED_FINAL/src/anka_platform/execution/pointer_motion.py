from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Protocol


class PointerCoordinateMode(str, Enum):
    SCREEN = "SCREEN"
    PHYSICAL_SCREEN = "PHYSICAL_SCREEN"


@dataclass(frozen=True, slots=True)
class PointerPosition:
    x: int
    y: int


@dataclass(frozen=True, slots=True)
class PointerMotionConfig:
    """Bounded production defaults for smooth pointer delivery.

    R5.165 keeps minimum-jerk forward progression, but ports TrajectoryLab_v2's
    correlated-knot lateral geometry with ANKA-specific safety constraints: several smooth
    low-frequency direction changes plus a very small tapered micro-wobble.
    Random parameters are sampled once per movement; there is no per-frame
    independent jitter and exact endpoint arrival remains a hard contract.
    """

    enabled: bool = True
    # R5.164: live evidence showed ~500 px motions completing in ~130 ms with
    # ~300 Hz unique-position delivery.  Preserve responsive interaction while
    # moving the distance-sensitive timing into a more deliberate human range.
    min_duration_seconds: float = 0.070
    max_duration_seconds: float = 0.950
    duration_per_pixel_seconds: float = 0.00030
    duration_variation_fraction: float = 0.10
    sample_rate_hz: float = 105.0
    max_step_pixels: float = 24.0
    max_samples: int = 512
    # R5.161: preserve near-straight very short moves, but make medium/long
    # pointer paths visibly yet conservatively curved.  The previous V1 sampler
    # drew the signed primary bend uniformly through zero, so a large fraction
    # of otherwise long moves were almost perfectly straight.
    max_lateral_deviation_pixels: float = 24.0
    min_lateral_fraction_of_distance: float = 0.012
    lateral_fraction_of_distance: float = 0.035
    secondary_lateral_fraction: float = 0.006
    # Late corrective submovement: a small coherent second adjustment near the
    # target, opposite the primary bend most of the time. This makes the path
    # look less like one perfect mathematical arc without adding frame jitter.
    late_correction_fraction_of_distance: float = 0.009
    max_late_correction_pixels: float = 5.0
    # Correlated-knot profile.  The knot count is a target for medium/long
    # movement and is distance-banded down for shorter corrections.
    lateral_knot_count: int = 7
    lateral_knot_irregularity: float = 0.62
    lateral_knot_residual_fraction: float = 0.46
    micro_wobble_fraction_of_distance: float = 0.0022
    max_micro_wobble_pixels: float = 2.0
    correction_start_min_fraction: float = 0.62
    correction_start_max_fraction: float = 0.78
    curvature_start_distance_pixels: float = 24.0
    curvature_full_distance_pixels: float = 160.0
    max_time_skew: float = 0.12
    interference_tolerance_pixels: float = 12.0
    exact_arrival_required: bool = True

    def validate(self) -> None:
        if self.min_duration_seconds < 0:
            raise ValueError("min_duration_seconds must be non-negative")
        if self.max_duration_seconds < self.min_duration_seconds:
            raise ValueError("max_duration_seconds must be >= min_duration_seconds")
        if self.duration_per_pixel_seconds < 0:
            raise ValueError("duration_per_pixel_seconds must be non-negative")
        if not 0 <= self.duration_variation_fraction <= 0.5:
            raise ValueError("duration_variation_fraction must be between 0 and 0.5")
        if self.sample_rate_hz <= 0:
            raise ValueError("sample_rate_hz must be positive")
        if self.max_step_pixels <= 0:
            raise ValueError("max_step_pixels must be positive")
        if self.max_samples < 2:
            raise ValueError("max_samples must be >= 2")
        if self.max_lateral_deviation_pixels < 0:
            raise ValueError("max_lateral_deviation_pixels must be non-negative")
        if self.min_lateral_fraction_of_distance < 0:
            raise ValueError("min_lateral_fraction_of_distance must be non-negative")
        if self.lateral_fraction_of_distance < self.min_lateral_fraction_of_distance:
            raise ValueError("lateral_fraction_of_distance must be >= min_lateral_fraction_of_distance")
        if self.secondary_lateral_fraction < 0:
            raise ValueError("secondary_lateral_fraction must be non-negative")
        if self.late_correction_fraction_of_distance < 0:
            raise ValueError("late_correction_fraction_of_distance must be non-negative")
        if self.max_late_correction_pixels < 0:
            raise ValueError("max_late_correction_pixels must be non-negative")
        if self.lateral_knot_count < 1:
            raise ValueError("lateral_knot_count must be >= 1")
        if not 0.0 <= self.lateral_knot_irregularity <= 1.0:
            raise ValueError("lateral_knot_irregularity must be between 0 and 1")
        if not 0.0 <= self.lateral_knot_residual_fraction <= 1.0:
            raise ValueError("lateral_knot_residual_fraction must be between 0 and 1")
        if self.micro_wobble_fraction_of_distance < 0:
            raise ValueError("micro_wobble_fraction_of_distance must be non-negative")
        if self.max_micro_wobble_pixels < 0:
            raise ValueError("max_micro_wobble_pixels must be non-negative")
        if not 0.0 <= self.correction_start_min_fraction < 1.0:
            raise ValueError("correction_start_min_fraction must be in [0, 1)")
        if not self.correction_start_min_fraction <= self.correction_start_max_fraction < 1.0:
            raise ValueError("correction_start_max_fraction must be >= min and < 1")
        if self.curvature_start_distance_pixels < 0:
            raise ValueError("curvature_start_distance_pixels must be non-negative")
        if self.curvature_full_distance_pixels <= self.curvature_start_distance_pixels:
            raise ValueError("curvature_full_distance_pixels must be > curvature_start_distance_pixels")
        if not 0 <= self.max_time_skew <= 0.5:
            raise ValueError("max_time_skew must be between 0 and 0.5")
        if self.interference_tolerance_pixels < 0:
            raise ValueError("interference_tolerance_pixels must be non-negative")


@dataclass(frozen=True, slots=True)
class PointerMotionPlan:
    start: PointerPosition
    target: PointerPosition
    distance_pixels: float
    duration_seconds: float
    sample_interval_seconds: float
    points: tuple[PointerPosition, ...]
    # Original normalized emission times for each unique integer coordinate.
    # Integer rounding can collapse several minimum-jerk samples to one pixel;
    # preserving these fractions prevents de-duplication from flattening the
    # slow-start / slow-finish temporal profile.
    time_fractions: tuple[float, ...]
    seed: int
    primary_lateral_pixels: float
    secondary_lateral_pixels: float
    late_correction_pixels: float
    correction_start_fraction: float
    submovement_count: int
    time_skew: float
    lateral_knot_count: int
    lateral_direction_changes: int
    micro_wobble_pixels: float
    micro_frequency_primary: float
    micro_frequency_secondary: float
    knot_irregularity: float
    max_lateral_deviation_pixels: float
    max_lateral_fraction: float
    path_length_pixels: float
    tortuosity: float
    max_emitted_step_pixels: float
    effective_emission_rate_hz: float


@dataclass(frozen=True, slots=True)
class PointerMotionResult:
    success: bool
    failure_code: str | None
    plan: PointerMotionPlan | None
    final_position: PointerPosition | None
    emitted_positions: int
    elapsed_seconds: float
    legacy_direct_fallback: bool = False

    def diagnostics(self) -> dict:
        plan = self.plan
        return {
            "motion_status": "ARRIVED" if self.success else "BLOCKED",
            "motion_failure_code": self.failure_code,
            "motion_profile": "MINIMUM_JERK_LATERAL_V1",
            "motion_profile_variant": "TRAJECTORYLAB_V2_SAFE_CORRELATED_KNOTS_V2",
            "motion_model_version": 4,
            "motion_start": [plan.start.x, plan.start.y] if plan is not None else None,
            "motion_target": [plan.target.x, plan.target.y] if plan is not None else None,
            "motion_final": (
                [self.final_position.x, self.final_position.y]
                if self.final_position is not None else None
            ),
            "motion_distance_px": plan.distance_pixels if plan is not None else None,
            "motion_planned_duration_ms": (
                round(plan.duration_seconds * 1000.0, 3) if plan is not None else None
            ),
            "motion_actual_duration_ms": round(self.elapsed_seconds * 1000.0, 3),
            "motion_planned_chord_speed_px_s": (
                round(plan.distance_pixels / plan.duration_seconds, 3)
                if plan is not None and plan.duration_seconds > 0.0 else None
            ),
            "motion_actual_chord_speed_px_s": (
                round(plan.distance_pixels / self.elapsed_seconds, 3)
                if plan is not None and self.elapsed_seconds > 0.0 else None
            ),
            "motion_timing_overrun_ms": (
                round(max(0.0, self.elapsed_seconds - plan.duration_seconds) * 1000.0, 3)
                if plan is not None else None
            ),
            "motion_timing_ratio": (
                round(self.elapsed_seconds / plan.duration_seconds, 4)
                if plan is not None and plan.duration_seconds > 0 else None
            ),
            "motion_sample_count": len(plan.points) if plan is not None else 0,
            "motion_emitted_positions": int(self.emitted_positions),
            "motion_seed": plan.seed if plan is not None else None,
            "motion_primary_lateral_px": (
                round(plan.primary_lateral_pixels, 4) if plan is not None else None
            ),
            "motion_secondary_lateral_px": (
                round(plan.secondary_lateral_pixels, 4) if plan is not None else None
            ),
            "motion_late_correction_px": (
                round(plan.late_correction_pixels, 4) if plan is not None else None
            ),
            "motion_correction_start_fraction": (
                round(plan.correction_start_fraction, 5) if plan is not None else None
            ),
            "motion_submovement_count": int(plan.submovement_count) if plan is not None else 0,
            "motion_time_skew": round(plan.time_skew, 5) if plan is not None else None,
            "motion_lateral_knot_count": int(plan.lateral_knot_count) if plan is not None else 0,
            "motion_lateral_direction_changes": (
                int(plan.lateral_direction_changes) if plan is not None else 0
            ),
            "motion_micro_wobble_px": (
                round(plan.micro_wobble_pixels, 4) if plan is not None else None
            ),
            "motion_micro_frequency_primary": (
                round(plan.micro_frequency_primary, 4) if plan is not None else None
            ),
            "motion_micro_frequency_secondary": (
                round(plan.micro_frequency_secondary, 4) if plan is not None else None
            ),
            "motion_knot_irregularity": (
                round(plan.knot_irregularity, 4) if plan is not None else None
            ),
            "motion_max_lateral_deviation_px": (
                round(plan.max_lateral_deviation_pixels, 4) if plan is not None else None
            ),
            "motion_max_lateral_fraction": (
                round(plan.max_lateral_fraction, 6) if plan is not None else None
            ),
            "motion_path_length_px": (
                round(plan.path_length_pixels, 4) if plan is not None else None
            ),
            "motion_tortuosity": round(plan.tortuosity, 6) if plan is not None else None,
            "motion_max_emitted_step_px": (
                round(plan.max_emitted_step_pixels, 4) if plan is not None else None
            ),
            # Compatibility field retained for older exporters.  It is the
            # planner's unique-point emission density, not an observation of OS
            # delivery timing.  R5.161 also exports explicit planned/actual names
            # so a runtime bundle cannot confuse the two.
            "motion_effective_emission_rate_hz": (
                round(plan.effective_emission_rate_hz, 3) if plan is not None else None
            ),
            "motion_planned_emission_rate_hz": (
                round(plan.effective_emission_rate_hz, 3) if plan is not None else None
            ),
            "motion_actual_emission_rate_hz": (
                round(float(self.emitted_positions) / self.elapsed_seconds, 3)
                if self.elapsed_seconds > 0.0 else None
            ),
            "motion_exact_arrival": bool(
                self.success
                and plan is not None
                and self.final_position is not None
                and self.final_position == plan.target
            ),
            "motion_legacy_direct_fallback": bool(self.legacy_direct_fallback),
        }


@dataclass(frozen=True, slots=True)
class SafeEndpointSelection:
    selected: PointerPosition
    seed: int
    candidate_count: int
    repeated_previous: bool


class SafeEndpointSelector:
    """Choose only among caller-certified safe points, biased toward nominal.

    This class never invents geometry and never adds arbitrary X/Y noise. If a
    caller cannot provide certified alternatives, it must use the exact nominal
    point instead.
    """

    def __init__(self, *, seed_source: Callable[[], int] | None = None) -> None:
        self.seed_source = seed_source or (lambda: random.SystemRandom().getrandbits(63))

    def choose(
        self,
        *,
        nominal: PointerPosition,
        candidates: tuple[PointerPosition, ...],
        previous: PointerPosition | None = None,
        seed: int | None = None,
    ) -> SafeEndpointSelection:
        unique: list[PointerPosition] = []
        seen: set[tuple[int, int]] = set()
        for point in candidates:
            key = (int(point.x), int(point.y))
            if key not in seen:
                seen.add(key)
                unique.append(point)
        if not unique:
            unique = [nominal]

        actual_seed = int(self.seed_source() if seed is None else seed)
        rng = random.Random(actual_seed)
        distances = [math.hypot(float(p.x - nominal.x), float(p.y - nominal.y)) for p in unique]
        max_distance = max(distances, default=0.0)
        sigma = max(1.0, max_distance * 0.55)
        weights = [math.exp(-0.5 * (distance / sigma) ** 2) for distance in distances]

        selected = rng.choices(unique, weights=weights, k=1)[0]
        repeated = previous is not None and selected == previous
        if repeated and len(unique) > 1 and rng.random() < 0.65:
            alternatives = [(point, weight) for point, weight in zip(unique, weights) if point != previous]
            if alternatives:
                selected = rng.choices(
                    [point for point, _ in alternatives],
                    weights=[weight for _, weight in alternatives],
                    k=1,
                )[0]
                repeated = False
        return SafeEndpointSelection(
            selected=selected,
            seed=actual_seed,
            candidate_count=len(unique),
            repeated_previous=repeated,
        )


class PointerMotionBackend(Protocol):
    def cursor_position(self, mode: PointerCoordinateMode) -> PointerPosition | None: ...
    def move_cursor(self, mode: PointerCoordinateMode, position: PointerPosition) -> bool: ...


class PointerMotionPlanner:
    def __init__(self, config: PointerMotionConfig | None = None) -> None:
        self.config = config or PointerMotionConfig()
        self.config.validate()

    @staticmethod
    def minimum_jerk(t: float) -> float:
        t = min(1.0, max(0.0, float(t)))
        return (10.0 * t**3) - (15.0 * t**4) + (6.0 * t**5)

    @staticmethod
    def _smoothstep(t: float) -> float:
        u = min(1.0, max(0.0, float(t)))
        return u * u * (3.0 - 2.0 * u)

    @classmethod
    def _smooth_knot_value(cls, knots: list[tuple[float, float]], position: float) -> float:
        if not knots:
            return 0.0
        t = min(1.0, max(0.0, float(position)))
        if t <= knots[0][0]:
            return float(knots[0][1])
        if t >= knots[-1][0]:
            return float(knots[-1][1])
        for left, right in zip(knots, knots[1:]):
            if t <= right[0]:
                span = max(1e-9, float(right[0] - left[0]))
                u = cls._smoothstep((t - left[0]) / span)
                return float(left[1]) * (1.0 - u) + float(right[1]) * u
        return float(knots[-1][1])

    @staticmethod
    def _direction_changes(values: list[float], *, epsilon: float = 0.05) -> int:
        previous_sign = 0
        changes = 0
        for a, b in zip(values, values[1:]):
            delta = float(b - a)
            if abs(delta) <= epsilon:
                continue
            sign = 1 if delta > 0 else -1
            if previous_sign and sign != previous_sign:
                changes += 1
            previous_sign = sign
        return changes

    def plan(
        self,
        *,
        start: PointerPosition,
        target: PointerPosition,
        seed: int,
    ) -> PointerMotionPlan:
        dx = float(target.x - start.x)
        dy = float(target.y - start.y)
        distance = math.hypot(dx, dy)
        if distance <= 0.0:
            return PointerMotionPlan(
                start=start,
                target=target,
                distance_pixels=0.0,
                duration_seconds=0.0,
                sample_interval_seconds=0.0,
                points=(target,),
                time_fractions=(1.0,),
                seed=int(seed),
                primary_lateral_pixels=0.0,
                secondary_lateral_pixels=0.0,
                late_correction_pixels=0.0,
                correction_start_fraction=1.0,
                submovement_count=1,
                time_skew=0.0,
                lateral_knot_count=0,
                lateral_direction_changes=0,
                micro_wobble_pixels=0.0,
                micro_frequency_primary=0.0,
                micro_frequency_secondary=0.0,
                knot_irregularity=0.0,
                max_lateral_deviation_pixels=0.0,
                max_lateral_fraction=0.0,
                path_length_pixels=0.0,
                tortuosity=1.0,
                max_emitted_step_pixels=0.0,
                effective_emission_rate_hz=0.0,
            )

        rng = random.Random(int(seed))
        cfg = self.config
        base_duration = cfg.min_duration_seconds + distance * cfg.duration_per_pixel_seconds
        base_duration = min(cfg.max_duration_seconds, max(cfg.min_duration_seconds, base_duration))
        variation = rng.uniform(-cfg.duration_variation_fraction, cfg.duration_variation_fraction)
        duration = min(
            cfg.max_duration_seconds,
            max(cfg.min_duration_seconds, base_duration * (1.0 + variation)),
        )

        by_time = int(math.ceil(duration * cfg.sample_rate_hz)) + 1
        # Minimum-jerk progression has a peak normalized velocity of 1.875, so
        # dividing only the chord distance by max_step_pixels does *not* bound
        # the largest emitted spatial jump.  Reserve a small additional margin
        # for the coherent lateral bend and integer rounding.
        by_distance = int(math.ceil((distance * 2.25) / cfg.max_step_pixels)) + 1
        sample_count = max(3, min(cfg.max_samples, max(by_time, by_distance)))
        interval = duration / max(1, sample_count - 1)

        # Curvature is distance-sensitive.  Short pointing corrections stay
        # almost straight, while medium/long moves receive one coherent bend.
        # The smoothstep ramp avoids a visible threshold at the short/medium
        # boundary.  Critically, sign and magnitude are sampled separately, so
        # long moves no longer have a high probability of an almost-zero bend.
        curvature_progress = (
            (distance - cfg.curvature_start_distance_pixels)
            / (cfg.curvature_full_distance_pixels - cfg.curvature_start_distance_pixels)
        )
        curvature_progress = min(1.0, max(0.0, curvature_progress))
        curvature_scale = curvature_progress * curvature_progress * (3.0 - 2.0 * curvature_progress)
        max_lateral = min(
            cfg.max_lateral_deviation_pixels,
            distance * cfg.lateral_fraction_of_distance,
        ) * curvature_scale
        min_lateral = min(
            max_lateral,
            distance * cfg.min_lateral_fraction_of_distance * curvature_scale,
        )
        if max_lateral > 0:
            primary_sign = -1.0 if rng.random() < 0.5 else 1.0
            primary = primary_sign * rng.uniform(min_lateral, max_lateral)
        else:
            primary = 0.0
        secondary_bound = min(
            max_lateral * 0.30,
            distance * cfg.secondary_lateral_fraction * curvature_scale,
        )
        secondary = rng.uniform(-secondary_bound, secondary_bound) if secondary_bound > 0 else 0.0
        correction_start = (
            rng.uniform(cfg.correction_start_min_fraction, cfg.correction_start_max_fraction)
            if curvature_scale > 0.0 else 1.0
        )
        correction_bound = min(
            cfg.max_late_correction_pixels,
            distance * cfg.late_correction_fraction_of_distance * curvature_scale,
            abs(primary) * 0.45,
        )
        if correction_bound > 0.0:
            # A corrective submovement usually bends back toward the chord. A
            # minority of same-side corrections prevents a rigid S-curve template.
            correction_sign = (-1.0 if primary >= 0 else 1.0) if rng.random() < 0.82 else (1.0 if primary >= 0 else -1.0)
            late_correction = correction_sign * rng.uniform(correction_bound * 0.45, correction_bound)
        else:
            late_correction = 0.0
        time_skew = rng.uniform(-cfg.max_time_skew, cfg.max_time_skew) if cfg.max_time_skew > 0 else 0.0

        ux = dx / distance
        uy = dy / distance
        px = -uy
        py = ux

        # TrajectoryLab_v2-inspired spatial profile.  Interior knots are sampled
        # once, correlated with the previous offset and tapered near endpoints.
        # The minimum-jerk scalar remains the *only* along-chord progression, so
        # forward motion cannot reverse even when the lateral hand-drawn shape
        # changes direction several times.
        if curvature_scale <= 0.0:
            knot_count = 0
            lateral_knots: list[tuple[float, float]] = [(0.0, 0.0), (1.0, 0.0)]
            micro_wobble = 0.0
            micro_f1 = 0.0
            micro_f2 = 0.0
            micro_phase1 = 0.0
            micro_phase2 = 0.0
            micro_weight2 = 0.0
        else:
            distance_band = min(1.0, max(0.0, distance / max(1.0, cfg.curvature_full_distance_pixels)))
            knot_count = max(2, min(cfg.lateral_knot_count, int(round(2 + distance_band * (cfg.lateral_knot_count - 2)))))
            lateral_knots = [(0.0, 0.0)]
            # Faithful safe port of TrajectoryLab_v2's useful spatial idea:
            # correlated irregular lateral knots with occasional stronger local
            # corrections and an endpoint taper.  We intentionally do *not* port
            # the lab's per-sample forwardJitter random-frequency expression;
            # ANKA keeps minimum-jerk monotonic along-chord progression instead.
            previous = rng.uniform(-0.30, 0.30) * max_lateral
            correlation = 0.35 + (1.0 - cfg.lateral_knot_irregularity) * 0.45
            for knot_index in range(1, knot_count + 1):
                base = knot_index / float(knot_count + 1)
                gap = 1.0 / float(knot_count + 1)
                knot_t = min(
                    0.975,
                    max(
                        0.025,
                        base + rng.uniform(-0.28, 0.28) * gap * cfg.lateral_knot_irregularity,
                    ),
                )
                target_offset = rng.uniform(-max_lateral, max_lateral)
                value = previous * correlation + target_offset * (1.0 - correlation)
                if rng.random() < 0.28 + 0.30 * cfg.lateral_knot_irregularity:
                    value += rng.uniform(-0.55, 0.55) * max_lateral
                value *= math.sin(math.pi * knot_t)
                value = min(max_lateral * 1.15, max(-max_lateral * 1.15, value))
                previous = value
                lateral_knots.append((knot_t, value))
            lateral_knots.append((1.0, 0.0))
            lateral_knots.sort(key=lambda item: item[0])
            micro_wobble = min(
                cfg.max_micro_wobble_pixels,
                distance * cfg.micro_wobble_fraction_of_distance * curvature_scale,
            )
            micro_f1 = rng.uniform(1.4, 2.7)
            micro_f2 = rng.uniform(3.0, 5.5)
            micro_phase1 = rng.uniform(0.0, math.tau)
            micro_phase2 = rng.uniform(0.0, math.tau)
            micro_weight2 = rng.uniform(0.18, 0.42)

        points: list[PointerPosition] = []
        time_fractions: list[float] = []
        lateral_samples: list[float] = []
        for index in range(sample_count):
            t = index / float(sample_count - 1)
            # Small coherent asymmetry changes where peak velocity occurs without
            # changing endpoints. For |skew| <= 0.5, t + skew*t*(1-t) remains
            # monotonic, and minimum-jerk still gives zero-speed endpoints.
            warped_t = min(1.0, max(0.0, t + time_skew * t * (1.0 - t)))
            s = self.minimum_jerk(warped_t)
            lateral = self._smooth_knot_value(lateral_knots, s)
            # Preserve R5.161/R5.162's proven medium-distance visible-curvature
            # envelope underneath the TrajectoryLab-style local bends.  The
            # residual is one coherent tapered arc (not jitter), so correlated
            # knots change direction around a human-like hand-drawn bias instead
            # of accidentally cancelling into an almost-straight path.
            if primary != 0.0 and cfg.lateral_knot_residual_fraction > 0.0:
                lateral += (
                    primary
                    * cfg.lateral_knot_residual_fraction
                    * math.sin(math.pi * s)
                )
            if micro_wobble > 0.0:
                taper = math.sin(math.pi * s) ** 0.9
                lateral += micro_wobble * taper * (
                    math.sin(math.tau * micro_f1 * s + micro_phase1)
                    + micro_weight2 * math.sin(math.tau * micro_f2 * s + micro_phase2)
                )
            if s > correction_start and correction_start < 1.0:
                correction_u = (s - correction_start) / (1.0 - correction_start)
                lateral += late_correction * math.sin(math.pi * correction_u)
            # The spatial contract remains conservative even when knot and
            # corrective components align on the same side.
            # Keep the historical medium-distance safety envelope even when
            # knot + residual + correction + micro components align.  Longer
            # movements may use the configured absolute cap, while ~450 px
            # paths remain below the R5.161 16.5 px regression ceiling.
            lateral_limit = min(
                cfg.max_lateral_deviation_pixels,
                max_lateral + abs(late_correction) + micro_wobble * 1.4,
                distance * 0.035,
            )
            if lateral_limit > 0.0:
                lateral = min(lateral_limit, max(-lateral_limit, lateral))
            lateral_samples.append(float(lateral))
            x = start.x + dx * s + px * lateral
            y = start.y + dy * s + py * lateral
            position = PointerPosition(int(round(x)), int(round(y)))
            if not points or position != points[-1]:
                points.append(position)
                time_fractions.append(float(t))
            else:
                # Consecutive equal integer coordinates represent real elapsed
                # time near a slow section of the trajectory. Keep the *latest*
                # sample time rather than dropping that temporal information.
                time_fractions[-1] = float(t)

        if points[0] != start:
            points.insert(0, start)
            time_fractions.insert(0, 0.0)
        else:
            # The first unique coordinate is the observed start. Its own time is
            # irrelevant because it is never emitted, but keep the contract
            # explicit for diagnostics/tests.
            time_fractions[0] = 0.0
        if points[-1] != target:
            points.append(target)
            time_fractions.append(1.0)
        else:
            points[-1] = target
            time_fractions[-1] = 1.0

        interval = duration / max(1, len(points) - 1)

        # Persist geometry metrics computed from the actual integer path.  This
        # makes one runtime bundle sufficient to assess trajectory quality rather
        # than inferring it from the random control amplitudes.
        denom = dx * dx + dy * dy
        max_deviation = 0.0
        for point in points:
            if denom <= 0.0:
                break
            rel_x = float(point.x - start.x)
            rel_y = float(point.y - start.y)
            # Perpendicular distance to the start->target chord.
            deviation = abs(dx * rel_y - dy * rel_x) / distance
            max_deviation = max(max_deviation, deviation)
        path_length = sum(
            math.hypot(float(b.x - a.x), float(b.y - a.y))
            for a, b in zip(points, points[1:])
        )
        max_fraction = max_deviation / distance if distance > 0.0 else 0.0
        tortuosity = path_length / distance if distance > 0.0 else 1.0
        emitted_steps = [
            math.hypot(float(b.x - a.x), float(b.y - a.y))
            for a, b in zip(points, points[1:])
        ]
        max_emitted_step = max(emitted_steps, default=0.0)
        effective_rate = (
            float(max(0, len(points) - 1)) / duration if duration > 0.0 else 0.0
        )
        # max_step_pixels is a safety contract, not merely a sampling hint. If
        # the bounded plan budget cannot preserve the *actual integer-coordinate*
        # emitted-step bound (for example an implausibly large cross-desktop
        # target), fail closed before any pointer movement.
        if max_emitted_step > cfg.max_step_pixels:
            raise ValueError(
                "pointer plan exceeds max_step_pixels within bounded sample budget: "
                f"{max_emitted_step:.3f} > {cfg.max_step_pixels:.3f}"
            )
        return PointerMotionPlan(
            start=start,
            target=target,
            distance_pixels=distance,
            duration_seconds=duration,
            sample_interval_seconds=interval,
            points=tuple(points),
            time_fractions=tuple(time_fractions),
            seed=int(seed),
            primary_lateral_pixels=primary,
            secondary_lateral_pixels=secondary,
            late_correction_pixels=late_correction,
            correction_start_fraction=correction_start,
            submovement_count=(2 if abs(late_correction) > 0.0 else 1),
            time_skew=time_skew,
            lateral_knot_count=knot_count,
            lateral_direction_changes=self._direction_changes(lateral_samples),
            micro_wobble_pixels=micro_wobble,
            micro_frequency_primary=micro_f1,
            micro_frequency_secondary=micro_f2,
            knot_irregularity=(cfg.lateral_knot_irregularity if knot_count else 0.0),
            max_lateral_deviation_pixels=max_deviation,
            max_lateral_fraction=max_fraction,
            path_length_pixels=path_length,
            tortuosity=tortuosity,
            max_emitted_step_pixels=max_emitted_step,
            effective_emission_rate_hz=effective_rate,
        )


class PointerMotionService:
    """Single physical pointer-motion authority above raw OS cursor primitives."""

    def __init__(
        self,
        *,
        backend: PointerMotionBackend,
        config: PointerMotionConfig | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic: Callable[[], float] = time.monotonic,
        seed_source: Callable[[], int] | None = None,
    ) -> None:
        self.backend = backend
        self.config = config or PointerMotionConfig()
        self.config.validate()
        self.planner = PointerMotionPlanner(self.config)
        self.sleep = sleep
        self.monotonic = monotonic
        self.seed_source = seed_source or (lambda: random.SystemRandom().getrandbits(63))

    @staticmethod
    def _distance(a: PointerPosition, b: PointerPosition) -> float:
        return math.hypot(float(a.x - b.x), float(a.y - b.y))

    def move_to(
        self,
        *,
        target: PointerPosition,
        mode: PointerCoordinateMode,
        focus_guard: Callable[[], bool] | None = None,
        seed: int | None = None,
    ) -> PointerMotionResult:
        started = self.monotonic()
        start = self.backend.cursor_position(mode)
        if start is None:
            return PointerMotionResult(
                success=False,
                failure_code="INPUT_CURSOR_POSITION_UNAVAILABLE",
                plan=None,
                final_position=None,
                emitted_positions=0,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )
        if focus_guard is not None and not bool(focus_guard()):
            return PointerMotionResult(
                success=False,
                failure_code="INPUT_FOREGROUND_LOST_DURING_MOVE",
                plan=None,
                final_position=start,
                emitted_positions=0,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )

        actual_seed = int(self.seed_source() if seed is None else seed)
        try:
            plan = self.planner.plan(start=start, target=target, seed=actual_seed)
        except ValueError:
            return PointerMotionResult(
                success=False,
                failure_code="INPUT_POINTER_PLAN_UNSAFE",
                plan=None,
                final_position=start,
                emitted_positions=0,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )
        if start == target:
            return PointerMotionResult(
                success=True,
                failure_code=None,
                plan=plan,
                final_position=start,
                emitted_positions=0,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )

        if not self.config.enabled:
            ok = bool(self.backend.move_cursor(mode, target))
            final = self.backend.cursor_position(mode)
            exact = final == target
            return PointerMotionResult(
                success=bool(ok and (exact or not self.config.exact_arrival_required)),
                failure_code=None if ok and (exact or not self.config.exact_arrival_required) else "INPUT_CURSOR_ARRIVAL_MISMATCH",
                plan=plan,
                final_position=final,
                emitted_positions=1 if ok else 0,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )

        emitted = 0
        expected_current = start
        movement_started = self.monotonic()
        movable_points = plan.points[1:]
        movable_times = plan.time_fractions[1:]
        # R5.160: schedule against absolute deadlines instead of sleeping one
        # interval after each OS move. Relative sleeps accumulate SendInput,
        # Python and scheduler overhead and made live motion ~20% slower than the
        # planner requested. Use each unique point's original normalized sample
        # time so integer-coordinate de-duplication does not flatten the
        # minimum-jerk slow-start / slow-finish profile.
        for position, time_fraction in zip(movable_points, movable_times):
            if plan.duration_seconds > 0 and movable_points:
                deadline = movement_started + plan.duration_seconds * float(time_fraction)
                delay = deadline - self.monotonic()
                if delay > 0:
                    self.sleep(delay)
            if focus_guard is not None and not bool(focus_guard()):
                return PointerMotionResult(
                    success=False,
                    failure_code="INPUT_FOREGROUND_LOST_DURING_MOVE",
                    plan=plan,
                    final_position=self.backend.cursor_position(mode),
                    emitted_positions=emitted,
                    elapsed_seconds=max(0.0, self.monotonic() - started),
                )

            observed = self.backend.cursor_position(mode)
            if observed is None:
                return PointerMotionResult(
                    success=False,
                    failure_code="INPUT_CURSOR_POSITION_UNAVAILABLE",
                    plan=plan,
                    final_position=None,
                    emitted_positions=emitted,
                    elapsed_seconds=max(0.0, self.monotonic() - started),
                )
            if self._distance(observed, expected_current) > self.config.interference_tolerance_pixels:
                return PointerMotionResult(
                    success=False,
                    failure_code="INPUT_CURSOR_INTERFERENCE",
                    plan=plan,
                    final_position=observed,
                    emitted_positions=emitted,
                    elapsed_seconds=max(0.0, self.monotonic() - started),
                )

            if not self.backend.move_cursor(mode, position):
                return PointerMotionResult(
                    success=False,
                    failure_code="INPUT_CURSOR_MOVE_FAILED",
                    plan=plan,
                    final_position=self.backend.cursor_position(mode),
                    emitted_positions=emitted,
                    elapsed_seconds=max(0.0, self.monotonic() - started),
                )
            emitted += 1
            expected_current = position

        final = self.backend.cursor_position(mode)
        if focus_guard is not None and not bool(focus_guard()):
            return PointerMotionResult(
                success=False,
                failure_code="INPUT_FOREGROUND_LOST_DURING_MOVE",
                plan=plan,
                final_position=final,
                emitted_positions=emitted,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )
        exact = final == target
        if self.config.exact_arrival_required and not exact:
            return PointerMotionResult(
                success=False,
                failure_code="INPUT_CURSOR_ARRIVAL_MISMATCH",
                plan=plan,
                final_position=final,
                emitted_positions=emitted,
                elapsed_seconds=max(0.0, self.monotonic() - started),
            )
        return PointerMotionResult(
            success=True,
            failure_code=None,
            plan=plan,
            final_position=final,
            emitted_positions=emitted,
            elapsed_seconds=max(0.0, self.monotonic() - started),
        )

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from threading import RLock
from typing import Callable

from anka_platform.execution.settlement import PendingSettlement, SettlementRequirement


class ExecutionSafetyStoreError(RuntimeError):
    """Durable execution-safety state could not be changed safely."""


class ExecutionSafetyStore:
    """Durable non-game execution safety state stored beside canonical truth.

    This is not a second game-state authority. It persists only unresolved
    physical-action safety obligations so process restart cannot clear them.

    R5.182 invariant: every mutation is an explicit SQLite transaction. Any
    mutation failure is rolled back and fences further writes for this store
    instance. Physical execution must treat a fenced store as NOT READY.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._write_healthy = True
        self._last_failure: dict | None = None
        self._connection = sqlite3.connect(self.path, check_same_thread=False)
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA busy_timeout=5000")
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS execution_safety_state (
                singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                uncertain_detail TEXT,
                uncertain_json TEXT,
                pending_json TEXT,
                world_interaction_json TEXT,
                prepared_input_json TEXT
            )
            """
        )
        columns = {str(row[1]) for row in self._connection.execute("PRAGMA table_info(execution_safety_state)")}
        if "world_interaction_json" not in columns:
            self._connection.execute("ALTER TABLE execution_safety_state ADD COLUMN world_interaction_json TEXT")
        if "uncertain_json" not in columns:
            self._connection.execute("ALTER TABLE execution_safety_state ADD COLUMN uncertain_json TEXT")
        if "prepared_input_json" not in columns:
            self._connection.execute("ALTER TABLE execution_safety_state ADD COLUMN prepared_input_json TEXT")
        self._connection.execute(
            "INSERT OR IGNORE INTO execution_safety_state(singleton, uncertain_detail, pending_json) VALUES (1, NULL, NULL)"
        )
        self._connection.commit()

    def health(self) -> dict:
        with self._lock:
            return {
                "status": "READY" if self._write_healthy else "FENCED",
                "write_healthy": bool(self._write_healthy),
                "last_failure": dict(self._last_failure) if self._last_failure is not None else None,
                "db_path": str(self.path),
            }

    def _require_write_healthy(self) -> None:
        if not self._write_healthy:
            failure = self._last_failure or {}
            raise ExecutionSafetyStoreError(
                "execution safety store is fenced after a prior persistence failure"
                + (f": {failure.get('detail')}" if failure.get("detail") else "")
            )

    def _mutate(self, operation: str, callback: Callable[[sqlite3.Connection], None]) -> None:
        with self._lock:
            self._require_write_healthy()
            try:
                self._connection.execute("BEGIN IMMEDIATE")
                callback(self._connection)
                self._connection.commit()
            except Exception as exc:
                rollback_error: Exception | None = None
                try:
                    self._connection.rollback()
                except Exception as rollback_exc:  # pragma: no cover - catastrophic sqlite failure
                    rollback_error = rollback_exc
                self._write_healthy = False
                self._last_failure = {
                    "operation": str(operation),
                    "error_type": type(exc).__name__,
                    "detail": str(exc),
                    "rollback_error": (
                        f"{type(rollback_error).__name__}: {rollback_error}" if rollback_error is not None else None
                    ),
                }
                detail = f"{operation} failed: {type(exc).__name__}: {exc}"
                if rollback_error is not None:
                    detail += f"; rollback failed: {type(rollback_error).__name__}: {rollback_error}"
                raise ExecutionSafetyStoreError(detail) from exc

    def uncertain_detail(self) -> str | None:
        with self._lock:
            row = self._connection.execute(
                "SELECT uncertain_detail FROM execution_safety_state WHERE singleton=1"
            ).fetchone()
            return str(row[0]) if row and row[0] is not None else None

    def uncertain_context(self) -> dict | None:
        with self._lock:
            row = self._connection.execute(
                "SELECT uncertain_json FROM execution_safety_state WHERE singleton=1"
            ).fetchone()
            if not row or row[0] is None:
                return None
            try:
                value = json.loads(str(row[0]))
            except Exception as exc:
                raise ValueError("durable execution uncertainty context is not valid JSON") from exc
            if not isinstance(value, dict):
                raise ValueError("durable execution uncertainty context is not an object")
            return dict(value)

    def set_uncertain(self, detail: str, context: dict | None = None) -> None:
        encoded = None if context is None else json.dumps(
            dict(context), sort_keys=True, separators=(",", ":"), default=str
        )
        self._mutate(
            "set_uncertain",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET uncertain_detail=?, uncertain_json=? WHERE singleton=1",
                (str(detail), encoded),
            ),
        )

    def clear_uncertain(self) -> None:
        self._mutate(
            "clear_uncertain",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET uncertain_detail=NULL, uncertain_json=NULL WHERE singleton=1"
            ),
        )

    def prepared_input(self) -> dict | None:
        with self._lock:
            row = self._connection.execute(
                "SELECT prepared_input_json FROM execution_safety_state WHERE singleton=1"
            ).fetchone()
            if not row or row[0] is None:
                return None
            try:
                value = json.loads(str(row[0]))
            except Exception as exc:
                raise ValueError("durable prepared physical-input state is not valid JSON") from exc
            if not isinstance(value, dict):
                raise ValueError("durable prepared physical-input state is not an object")
            return dict(value)

    def prepare_input(self, payload: dict) -> None:
        encoded = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str)
        self._mutate(
            "prepare_input",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET prepared_input_json=? WHERE singleton=1",
                (encoded,),
            ),
        )

    def clear_prepared_input(self) -> None:
        self._mutate(
            "clear_prepared_input",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET prepared_input_json=NULL WHERE singleton=1"
            ),
        )

    def pending(self) -> PendingSettlement | None:
        with self._lock:
            row = self._connection.execute(
                "SELECT pending_json FROM execution_safety_state WHERE singleton=1"
            ).fetchone()
            if not row or row[0] is None:
                return None
            raw = json.loads(str(row[0]))
            return PendingSettlement(
                action_kind=str(raw["action_kind"]),
                basis_revision=int(raw["basis_revision"]),
                server_confirmed_revision=int(raw["server_confirmed_revision"]),
                requirements=tuple(
                    SettlementRequirement(
                        actor_id=int(item["actor_id"]),
                        field=str(item["field"]),
                        after_revision=int(item["after_revision"]),
                        mode=str(item.get("mode") or "REVISION"),
                        baseline_value=(
                            int(item["baseline_value"])
                            if item.get("baseline_value") is not None else None
                        ),
                    )
                    for item in raw.get("requirements", [])
                ),
            )

    def set_pending(self, pending: PendingSettlement | None) -> None:
        payload = None
        if pending is not None:
            payload = json.dumps(
                {
                    "action_kind": pending.action_kind,
                    "basis_revision": pending.basis_revision,
                    "server_confirmed_revision": pending.server_confirmed_revision,
                    "requirements": [
                        {
                            "actor_id": item.actor_id,
                            "field": item.field,
                            "after_revision": item.after_revision,
                            "mode": item.mode,
                            "baseline_value": item.baseline_value,
                        }
                        for item in pending.requirements
                    ],
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        self._mutate(
            "set_pending",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET pending_json=? WHERE singleton=1", (payload,)
            ),
        )

    def world_interaction(self) -> dict | None:
        with self._lock:
            row = self._connection.execute(
                "SELECT world_interaction_json FROM execution_safety_state WHERE singleton=1"
            ).fetchone()
            if not row or row[0] is None:
                return None
            try:
                value = json.loads(str(row[0]))
            except Exception as exc:
                raise ValueError("durable world-interaction safety state is not valid JSON") from exc
            if not isinstance(value, dict):
                raise ValueError("durable world-interaction safety state is not an object")
            return dict(value)

    def set_world_interaction(self, payload: dict | None) -> None:
        encoded = None if payload is None else json.dumps(
            dict(payload), sort_keys=True, separators=(",", ":"), default=str
        )
        self._mutate(
            "set_world_interaction",
            lambda con: con.execute(
                "UPDATE execution_safety_state SET world_interaction_json=? WHERE singleton=1",
                (encoded,),
            ),
        )

    def close(self) -> None:
        with self._lock:
            try:
                self._connection.rollback()
            except Exception:
                pass
            self._connection.close()

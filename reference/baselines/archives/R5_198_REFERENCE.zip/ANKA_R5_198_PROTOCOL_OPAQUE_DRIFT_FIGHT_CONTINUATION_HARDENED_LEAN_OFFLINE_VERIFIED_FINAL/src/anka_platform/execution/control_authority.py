from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from enum import Enum
from threading import RLock
from typing import Mapping

from anka_platform.contracts.correlation import CorrelationContext, correlation_mapping
from uuid import uuid4


class ControlAuthorityBusyError(RuntimeError):
    """Raised when a second control owner attempts to steal the live permit."""

    def __init__(self, current: "ControlPermit", *, requested_mode: str, requested_source: str) -> None:
        self.current = current
        self.requested_mode = str(requested_mode)
        self.requested_source = str(requested_source)
        super().__init__(
            "CONTROL_AUTHORITY_BUSY: "
            f"current_mode={current.mode.value} current_source={current.source} "
            f"session_id={current.session_id!r} run_id={current.run_id!r}; "
            f"requested_mode={self.requested_mode} requested_source={self.requested_source}"
        )


class ControlMode(str, Enum):
    DISARMED = "DISARMED"
    SESSION = "SESSION_CONTROL"
    MANUAL = "MANUAL_SCRIPT_CONTROL"
    CERTIFICATION = "CERTIFICATION_CONTROL"
    LEGACY_PERMISSIVE = "LEGACY_PERMISSIVE"


@dataclass(frozen=True, slots=True)
class ControlPermit:
    authorization_id: str
    mode: ControlMode
    issued_utc: str
    source: str
    session_id: str | None = None
    run_id: str | None = None
    script_name: str | None = None

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["mode"] = self.mode.value
        return payload


class ControlAuthorityStore:
    """Process-wide physical-control lease.

    Production execution services share one strict store.  The store starts
    DISARMED and only explicit operator actions may arm it.  This makes physical
    input authorization independent of whichever workflow happens to call
    ExecutionService.

    Narrow unit tests/legacy composition may opt into ``legacy_permissive``;
    production composition must never use that mode.
    """

    def __init__(self, *, legacy_permissive: bool = False) -> None:
        self._lock = RLock()
        self._permit: ControlPermit | None = None
        self._legacy_permissive = bool(legacy_permissive)
        self._history: list[dict] = []
        # Bounded history is intentionally small because authorization checks can
        # be high frequency.  Preserve the latest causal lease-loss event outside
        # that ring so hundreds of consequence denials cannot evict the reason
        # physical control was originally revoked from a forensic bundle.
        self._disarm_root_event: dict | None = None
        self._last_disarm_event: dict | None = None
        self._first_denial_after_disarm: dict | None = None

    @classmethod
    def legacy_permissive(cls) -> "ControlAuthorityStore":
        return cls(legacy_permissive=True)

    def _record(self, event: str, permit: ControlPermit | None, **extra) -> None:
        row = {
            "event": str(event),
            "observed_utc": datetime.now(timezone.utc).isoformat(),
            "permit": permit.to_dict() if permit is not None else None,
            **extra,
        }
        if str(event) == "ARMED":
            self._disarm_root_event = None
            self._first_denial_after_disarm = None
        elif str(event) == "DISARMED":
            if self._disarm_root_event is None:
                self._disarm_root_event = dict(row)
                self._first_denial_after_disarm = None
            self._last_disarm_event = dict(row)
        elif str(event) == "AUTHORIZATION_DENIED" and permit is None:
            if self._first_denial_after_disarm is None:
                self._first_denial_after_disarm = dict(row)
        self._history.append(row)
        if len(self._history) > 256:
            del self._history[:-256]

    def _reject_busy(self, current: ControlPermit, *, requested_mode: ControlMode, requested_source: str) -> None:
        self._record(
            "CONTROL_ACQUIRE_DENIED",
            current,
            failure_code="CONTROL_AUTHORITY_BUSY",
            requested_mode=requested_mode.value,
            requested_source=str(requested_source),
        )
        raise ControlAuthorityBusyError(
            current, requested_mode=requested_mode.value, requested_source=str(requested_source)
        )

    def arm_session(self, *, session_id: str, authorization_id: str, source: str) -> dict:
        session_token = str(session_id)
        authorization_token = str(authorization_id)
        source_token = str(source)
        with self._lock:
            current = self._permit
            if current is not None:
                if (
                    current.mode is ControlMode.SESSION
                    and current.session_id == session_token
                    and current.authorization_id == authorization_token
                ):
                    self._record("ARM_IDEMPOTENT", current)
                    return current.to_dict()
                self._reject_busy(current, requested_mode=ControlMode.SESSION, requested_source=source_token)
            permit = ControlPermit(
                authorization_id=authorization_token,
                mode=ControlMode.SESSION,
                issued_utc=datetime.now(timezone.utc).isoformat(),
                source=source_token,
                session_id=session_token,
            )
            self._permit = permit
            self._record("ARMED", permit)
            return permit.to_dict()

    def arm_manual(self, *, script_name: str, source: str = "SCRIPT_STUDIO_MANUAL_RUN") -> dict:
        source_token = str(source)
        with self._lock:
            current = self._permit
            if current is not None:
                self._reject_busy(current, requested_mode=ControlMode.MANUAL, requested_source=source_token)
            permit = ControlPermit(
                authorization_id=uuid4().hex,
                mode=ControlMode.MANUAL,
                issued_utc=datetime.now(timezone.utc).isoformat(),
                source=source_token,
                script_name=str(script_name),
            )
            self._permit = permit
            self._record("ARMED", permit)
            return permit.to_dict()

    def arm_certification(self, *, source: str = "WINDOWS_CERTIFICATION") -> dict:
        source_token = str(source)
        with self._lock:
            current = self._permit
            if current is not None:
                self._reject_busy(current, requested_mode=ControlMode.CERTIFICATION, requested_source=source_token)
            permit = ControlPermit(
                authorization_id=uuid4().hex,
                mode=ControlMode.CERTIFICATION,
                issued_utc=datetime.now(timezone.utc).isoformat(),
                source=source_token,
            )
            self._permit = permit
            self._record("ARMED", permit)
            return permit.to_dict()

    def bind_run(self, run_id: str, *, session_id: str | None = None, script_name: str | None = None) -> dict | None:
        token = str(run_id)
        with self._lock:
            current = self._permit
            if current is None:
                return None
            if session_id is not None and current.session_id not in {None, str(session_id)}:
                return None
            if script_name is not None and current.script_name not in {None, str(script_name)}:
                return None
            if current.run_id is not None and current.run_id != token:
                self._record(
                    "RUN_BIND_DENIED", current, failure_code="CONTROL_RUN_ALREADY_BOUND", requested_run_id=token
                )
                return None
            updated = ControlPermit(
                authorization_id=current.authorization_id,
                mode=current.mode,
                issued_utc=current.issued_utc,
                source=current.source,
                session_id=current.session_id,
                run_id=token,
                script_name=current.script_name or (str(script_name) if script_name is not None else None),
            )
            self._permit = updated
            self._record("RUN_BOUND", updated)
            return updated.to_dict()

    def disarm(self, *, reason: str, run_id: str | None = None, session_id: str | None = None) -> dict:
        with self._lock:
            current = self._permit
            if current is not None:
                if run_id is not None:
                    requested_run = str(run_id)
                    # Run-terminal events are asynchronous. Never let a stale
                    # terminal event disarm a newly armed but not-yet-bound
                    # session/certification permit. A run-scoped disarm must
                    # prove exact ownership.
                    if current.run_id is None or current.run_id != requested_run:
                        self._record(
                            "DISARM_SKIPPED", current, reason=str(reason),
                            failure_code="CONTROL_RUN_NOT_OWNER", requested_run_id=requested_run,
                        )
                        return self.status()
                if session_id is not None and current.session_id not in {None, str(session_id)}:
                    self._record(
                        "DISARM_SKIPPED", current, reason=str(reason),
                        failure_code="CONTROL_SESSION_NOT_OWNER", requested_session_id=str(session_id),
                    )
                    return self.status()
            self._permit = None
            self._record("DISARMED", current, reason=str(reason))
            return self.status()

    def authorize(self, *, runtime_context: Mapping | CorrelationContext | None, operation: str, account_id: str | None = None) -> dict:
        context = correlation_mapping(runtime_context)
        with self._lock:
            if self._legacy_permissive:
                return {
                    "allowed": True,
                    "mode": ControlMode.LEGACY_PERMISSIVE.value,
                    "operation": str(operation),
                    "account_id": account_id,
                }
            permit = self._permit
            if permit is None:
                denied = {
                    "allowed": False,
                    "failure_code": "CONTROL_AUTHORITY_DISARMED",
                    "detail": "physical input is disarmed; explicit Launch or explicit manual/certification control is required",
                    "mode": ControlMode.DISARMED.value,
                    "operation": str(operation),
                    "account_id": account_id,
                    "retry_allowed": False,
                    "first_missing_boundary": "CONTROL_AUTHORITY",
                    "likely_owner": "EXECUTION_CONTROL",
                }
                self._record("AUTHORIZATION_DENIED", None, request={
                    "operation": str(operation), "account_id": account_id, "runtime_context": context,
                }, failure_code=denied["failure_code"])
                return denied

            run_id = str(context.get("run_id")) if context.get("run_id") is not None else None
            session_id = str(context.get("session_id")) if context.get("session_id") is not None else None
            script_name = str(context.get("script_name")) if context.get("script_name") is not None else None

            if permit.mode is ControlMode.SESSION:
                if not session_id or session_id != permit.session_id:
                    self._record("AUTHORIZATION_DENIED", permit, request={"operation":str(operation),"account_id":account_id,"runtime_context":context}, failure_code="CONTROL_SESSION_MISMATCH")
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_SESSION_MISMATCH",
                        "detail": f"input requires session {permit.session_id!r}; request session={session_id!r}",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
                # A Script Studio Launch authorization is necessary but not
                # sufficient for physical control.  Every production campaign
                # input must also belong to a concrete ScriptSupervisor run.
                # This closes the pre-run window where a pending Launch had a
                # session permit but no worker/run yet.
                if not run_id:
                    self._record(
                        "AUTHORIZATION_DENIED", permit,
                        request={"operation":str(operation),"account_id":account_id,"runtime_context":context},
                        failure_code="CONTROL_RUN_REQUIRED",
                    )
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_RUN_REQUIRED",
                        "detail": "session physical control requires a concrete launched run_id",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
                if permit.run_id is None:
                    self._record(
                        "AUTHORIZATION_DENIED", permit,
                        request={"operation":str(operation),"account_id":account_id,"runtime_context":context},
                        failure_code="CONTROL_RUN_NOT_BOUND",
                    )
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_RUN_NOT_BOUND",
                        "detail": "session control permit has not been atomically bound to the launched run",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
                if run_id != permit.run_id:
                    self._record("AUTHORIZATION_DENIED", permit, request={"operation":str(operation),"account_id":account_id,"runtime_context":context}, failure_code="CONTROL_RUN_MISMATCH")
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_RUN_MISMATCH",
                        "detail": f"input requires run {permit.run_id!r}; request run={run_id!r}",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
            elif permit.mode is ControlMode.MANUAL:
                if permit.script_name and script_name != permit.script_name:
                    self._record("AUTHORIZATION_DENIED", permit, request={"operation":str(operation),"account_id":account_id,"runtime_context":context}, failure_code="CONTROL_SCRIPT_MISMATCH")
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_SCRIPT_MISMATCH",
                        "detail": f"manual control belongs to {permit.script_name!r}; request script={script_name!r}",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
                if permit.run_id is not None and run_id != permit.run_id:
                    self._record("AUTHORIZATION_DENIED", permit, request={"operation":str(operation),"account_id":account_id,"runtime_context":context}, failure_code="CONTROL_RUN_MISMATCH")
                    return {
                        "allowed": False,
                        "failure_code": "CONTROL_RUN_MISMATCH",
                        "detail": f"manual control belongs to run {permit.run_id!r}; request run={run_id!r}",
                        "permit": permit.to_dict(),
                        "operation": str(operation),
                        "account_id": account_id,
                        "retry_allowed": False,
                        "first_missing_boundary": "CONTROL_AUTHORITY",
                        "likely_owner": "EXECUTION_CONTROL",
                    }
            elif permit.mode is ControlMode.CERTIFICATION:
                # Explicit certification may own direct bootstrap operations before
                # a manual certification worker exists.  The user intentionally
                # opted into a control-capable certification command.
                pass

            return {
                "allowed": True,
                "mode": permit.mode.value,
                "authorization_id": permit.authorization_id,
                "session_id": permit.session_id,
                "run_id": permit.run_id,
                "script_name": permit.script_name,
                "operation": str(operation),
                "account_id": account_id,
            }

    def status(self) -> dict:
        with self._lock:
            permit = self._permit
            return {
                "armed": permit is not None or self._legacy_permissive,
                "mode": (ControlMode.LEGACY_PERMISSIVE.value if self._legacy_permissive else (permit.mode.value if permit else ControlMode.DISARMED.value)),
                "permit": permit.to_dict() if permit is not None else None,
                "history": [dict(row) for row in self._history[-64:]],
                "disarm_root_event": (
                    dict(self._disarm_root_event) if self._disarm_root_event is not None else None
                ),
                "last_disarm_event": (
                    dict(self._last_disarm_event) if self._last_disarm_event is not None else None
                ),
                "first_denial_after_disarm": (
                    dict(self._first_denial_after_disarm)
                    if self._first_denial_after_disarm is not None
                    else None
                ),
            }

from __future__ import annotations

from pathlib import Path
from typing import Callable
import time

from anka_game_kernel.api.kernel import GameKernel
from anka_platform.calibration.models import CalibrationSettings
from anka_platform.execution.service import ExecutionService, PhysicalSendState
from anka_platform.execution.arbiter import InputArbiter


class RuntimeActionService(ExecutionService):
    """R4 compatibility constructor. All behavior lives in ExecutionService."""

    def __init__(
        self, kernel: GameKernel, state, projection, input_driver, calibration: CalibrationSettings, *,
        sleep: Callable[[float], None] = time.sleep,
        confirmation_interval_seconds: float = 0.1,
        max_confirmation_polls: int = 20,
        timing=None,
        execution_db_path: str | Path | None = None,
        observability=None,
        critical_debug_export: Callable[[], object] | None = None,
        account_id: str = "legacy",
        input_arbiter: InputArbiter | None = None,
    ) -> None:
        super().__init__(
            state, projection, input_driver, kernel=kernel, calibration=calibration, sleep=sleep,
            confirmation_interval_seconds=confirmation_interval_seconds,
            max_confirmation_polls=max_confirmation_polls, timing=timing, execution_db_path=execution_db_path,
            observability=observability, critical_debug_export=critical_debug_export,
            account_id=account_id, input_arbiter=input_arbiter,
        )


__all__ = ["RuntimeActionService", "ExecutionService", "PhysicalSendState"]

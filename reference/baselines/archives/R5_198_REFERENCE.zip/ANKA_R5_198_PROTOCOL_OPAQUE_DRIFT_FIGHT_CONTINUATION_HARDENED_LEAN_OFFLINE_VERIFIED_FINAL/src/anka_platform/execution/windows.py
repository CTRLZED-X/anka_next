from __future__ import annotations

import os
import hashlib
import inspect
import math
import random
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Protocol

from anka_platform.calibration.models import CalibrationPoint
from anka_platform.contracts.projection import ScreenPoint
from anka_platform.execution.service import PhysicalSendState
from anka_platform.execution.pointer_motion import (
    PointerCoordinateMode,
    PointerMotionConfig,
    PointerMotionService,
    PointerPosition,
    SafeEndpointSelector,
)


class WindowInputApi(Protocol):
    def visible_windows(self) -> list[tuple[int, str]]: ...
    def set_foreground(self, hwnd: int) -> bool: ...
    def foreground_window(self) -> int | None: ...
    def cursor_screen_position(self) -> tuple[int, int] | None: ...
    def cursor_physical_screen_position(self) -> tuple[int, int] | None: ...
    def click_screen(self, x: int, y: int) -> int: ...
    def move_screen(self, x: int, y: int) -> bool: ...
    def move_physical_screen(self, x: int, y: int) -> bool: ...
    def client_size(self, hwnd: int) -> tuple[int, int]: ...
    def client_to_screen(self, hwnd: int, x: int, y: int) -> tuple[int, int]: ...
    def client_to_physical_screen(self, hwnd: int, x: int, y: int) -> tuple[int, int]: ...
    def click_physical_screen(self, x: int, y: int) -> int: ...
    def mouse_left_down(self) -> int: ...
    def mouse_left_up(self) -> int: ...
    def window_dpi(self, hwnd: int) -> int | None: ...
    def window_process_id(self, hwnd: int) -> int: ...
    def process_creation_time(self, pid: int) -> int: ...
    def is_minimized(self, hwnd: int) -> bool: ...
    def restore_window(self, hwnd: int) -> bool: ...
    def bring_to_top(self, hwnd: int) -> bool: ...
    def activate_thread_window(self, hwnd: int) -> bool: ...
    def current_thread_id(self) -> int: ...
    def window_thread_id(self, hwnd: int) -> int: ...
    def attach_thread_input(self, source_tid: int, target_tid: int, attach: bool) -> bool: ...
    def current_process_integrity_rid(self) -> int: ...
    def process_integrity_rid(self, pid: int) -> int: ...
    def send_key(self, key: str) -> int: ...


class NativeWin32Api:
    def __init__(self) -> None:
        if os.name != "nt":
            raise RuntimeError("NativeWin32Api is available only on Windows")
        import ctypes
        from ctypes import wintypes
        self.ctypes = ctypes
        self.wintypes = wintypes
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

        # Explicit Win64 signatures are critical here.  ctypes defaults to c_int
        # return values, which can truncate HANDLE/SID pointers on 64-bit Windows.
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        self.kernel32.GetCurrentProcessId.restype = wintypes.DWORD
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        self.user32.AttachThreadInput.restype = wintypes.BOOL
        self.advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
        self.advapi32.OpenProcessToken.restype = wintypes.BOOL
        self.advapi32.GetTokenInformation.argtypes = [
            wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)
        ]
        self.advapi32.GetTokenInformation.restype = wintypes.BOOL
        self.advapi32.GetSidSubAuthorityCount.argtypes = [ctypes.c_void_p]
        self.advapi32.GetSidSubAuthorityCount.restype = ctypes.POINTER(ctypes.c_ubyte)
        self.advapi32.GetSidSubAuthority.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        self.advapi32.GetSidSubAuthority.restype = ctypes.POINTER(wintypes.DWORD)

    def visible_windows(self) -> list[tuple[int, str]]:
        ctypes = self.ctypes
        wintypes = self.wintypes
        result: list[tuple[int, str]] = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @callback_type
        def callback(hwnd, _lparam):
            if not self.user32.IsWindowVisible(hwnd):
                return True
            length = self.user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buffer = ctypes.create_unicode_buffer(length + 1)
            self.user32.GetWindowTextW(hwnd, buffer, length + 1)
            title = buffer.value.strip()
            if title:
                result.append((int(hwnd), title))
            return True

        self.user32.EnumWindows(callback, 0)
        return result

    def set_foreground(self, hwnd: int) -> bool:
        return bool(self.user32.SetForegroundWindow(hwnd))

    def foreground_window(self) -> int | None:
        hwnd = self.user32.GetForegroundWindow()
        return int(hwnd) if hwnd else None

    def cursor_screen_position(self) -> tuple[int, int] | None:
        point = self.wintypes.POINT()
        if not self.user32.GetCursorPos(self.ctypes.byref(point)):
            return None
        return int(point.x), int(point.y)

    def cursor_physical_screen_position(self) -> tuple[int, int] | None:
        getter = getattr(self.user32, "GetPhysicalCursorPos", None)
        if getter is None:
            return None
        point = self.wintypes.POINT()
        try:
            if getter(self.ctypes.byref(point)):
                return int(point.x), int(point.y)
        except AttributeError:
            return None
        return None

    def is_minimized(self, hwnd: int) -> bool:
        return bool(self.user32.IsIconic(int(hwnd)))

    def restore_window(self, hwnd: int) -> bool:
        SW_RESTORE = 9
        # ShowWindowAsync returns the previous visibility state rather than a strict
        # success flag, so issue the request and validate later through foreground.
        self.user32.ShowWindowAsync(int(hwnd), SW_RESTORE)
        return True

    def bring_to_top(self, hwnd: int) -> bool:
        return bool(self.user32.BringWindowToTop(int(hwnd)))

    def activate_thread_window(self, hwnd: int) -> bool:
        # Inside an AttachThreadInput group, SetActiveWindow/SetFocus can move
        # the active/focus state to the exact target top-level window before
        # SetForegroundWindow performs the policy-controlled foreground switch.
        self.user32.SetActiveWindow(int(hwnd))
        self.user32.SetFocus(int(hwnd))
        return True

    def current_thread_id(self) -> int:
        return int(self.kernel32.GetCurrentThreadId())

    def window_thread_id(self, hwnd: int) -> int:
        pid = self.wintypes.DWORD()
        tid = self.user32.GetWindowThreadProcessId(int(hwnd), self.ctypes.byref(pid))
        if not tid:
            raise RuntimeError("GetWindowThreadProcessId failed")
        return int(tid)

    def attach_thread_input(self, source_tid: int, target_tid: int, attach: bool) -> bool:
        if int(source_tid) == int(target_tid):
            return True
        # AttachThreadInput requires both threads to have USER message queues.
        # Touch the current thread queue before attaching so a FastAPI worker
        # thread can participate reliably even though the ANKA server is hidden.
        msg = self.wintypes.MSG()
        PM_NOREMOVE = 0x0000
        self.user32.PeekMessageW(self.ctypes.byref(msg), 0, 0, 0, PM_NOREMOVE)
        return bool(self.user32.AttachThreadInput(int(source_tid), int(target_tid), bool(attach)))

    def client_size(self, hwnd: int) -> tuple[int, int]:
        rect = self.wintypes.RECT()
        if not self.user32.GetClientRect(hwnd, self.ctypes.byref(rect)):
            raise RuntimeError("GetClientRect failed")
        return int(rect.right - rect.left), int(rect.bottom - rect.top)

    def client_to_screen(self, hwnd: int, x: int, y: int) -> tuple[int, int]:
        point = self.wintypes.POINT(int(x), int(y))
        if not self.user32.ClientToScreen(hwnd, self.ctypes.byref(point)):
            raise RuntimeError("ClientToScreen failed")
        return int(point.x), int(point.y)

    def client_to_physical_screen(self, hwnd: int, x: int, y: int) -> tuple[int, int]:
        """Translate client coordinates into explicit physical desktop pixels.

        ClientToScreen follows the calling process DPI context.  The explicit
        LogicalToPhysicalPointForPerMonitorDPI conversion removes ambiguity when
        ANKA and the injected Unity bridge run under different DPI awareness.
        """
        point = self.wintypes.POINT(int(x), int(y))
        if not self.user32.ClientToScreen(hwnd, self.ctypes.byref(point)):
            raise RuntimeError("ClientToScreen failed")
        converter = getattr(self.user32, "LogicalToPhysicalPointForPerMonitorDPI", None)
        if converter is not None:
            try:
                if not converter(int(hwnd), self.ctypes.byref(point)):
                    raise RuntimeError("LogicalToPhysicalPointForPerMonitorDPI failed")
            except AttributeError:
                pass
        return int(point.x), int(point.y)

    def window_dpi(self, hwnd: int) -> int | None:
        getter = getattr(self.user32, "GetDpiForWindow", None)
        if getter is None:
            return None
        try:
            value = int(getter(int(hwnd)))
            return value if value > 0 else None
        except Exception:
            return None

    def click_physical_screen(self, x: int, y: int) -> int:
        # Physical-pixel mode must never silently fall back to logical screen
        # coordinates because that would make DPI-sensitive click delivery unsafe.
        if not self.move_physical_screen(int(x), int(y)):
            return 0
        return self._send_left_click_events()

    def window_process_id(self, hwnd: int) -> int:
        pid=self.wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd,self.ctypes.byref(pid))
        if not pid.value:
            raise RuntimeError("GetWindowThreadProcessId failed")
        return int(pid.value)

    def process_creation_time(self, pid: int) -> int:
        PROCESS_QUERY_LIMITED_INFORMATION=0x1000
        handle=self.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,False,int(pid))
        if not handle:
            raise RuntimeError("OpenProcess failed")
        try:
            creation=self.wintypes.FILETIME(); exit_time=self.wintypes.FILETIME()
            kernel=self.wintypes.FILETIME(); user=self.wintypes.FILETIME()
            if not self.kernel32.GetProcessTimes(handle,self.ctypes.byref(creation),self.ctypes.byref(exit_time),self.ctypes.byref(kernel),self.ctypes.byref(user)):
                raise RuntimeError("GetProcessTimes failed")
            return (int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime)
        finally:
            self.kernel32.CloseHandle(handle)

    def current_process_integrity_rid(self) -> int:
        return self.process_integrity_rid(int(self.kernel32.GetCurrentProcessId()))

    def process_integrity_rid(self, pid: int) -> int:
        ctypes = self.ctypes
        wintypes = self.wintypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        TOKEN_QUERY = 0x0008
        TokenIntegrityLevel = 25

        class SID_AND_ATTRIBUTES(ctypes.Structure):
            _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", wintypes.DWORD)]

        class TOKEN_MANDATORY_LABEL(ctypes.Structure):
            _fields_ = [("Label", SID_AND_ATTRIBUTES)]

        process = self.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not process:
            raise RuntimeError("OpenProcess(integrity) failed")
        token = wintypes.HANDLE()
        try:
            if not self.advapi32.OpenProcessToken(process, TOKEN_QUERY, ctypes.byref(token)):
                raise RuntimeError("OpenProcessToken failed")
            needed = wintypes.DWORD()
            self.advapi32.GetTokenInformation(token, TokenIntegrityLevel, None, 0, ctypes.byref(needed))
            if int(needed.value) <= 0:
                raise RuntimeError("GetTokenInformation(size) failed")
            buffer = ctypes.create_string_buffer(int(needed.value))
            if not self.advapi32.GetTokenInformation(
                token, TokenIntegrityLevel, buffer, int(needed.value), ctypes.byref(needed)
            ):
                raise RuntimeError("GetTokenInformation failed")
            label = ctypes.cast(buffer, ctypes.POINTER(TOKEN_MANDATORY_LABEL)).contents
            sid = label.Label.Sid
            if not sid:
                raise RuntimeError("integrity SID unavailable")
            count_ptr = self.advapi32.GetSidSubAuthorityCount(sid)
            if not count_ptr or int(count_ptr.contents.value) <= 0:
                raise RuntimeError("integrity SID subauthority unavailable")
            rid_ptr = self.advapi32.GetSidSubAuthority(sid, int(count_ptr.contents.value) - 1)
            if not rid_ptr:
                raise RuntimeError("integrity RID unavailable")
            return int(rid_ptr.contents.value)
        finally:
            if token:
                self.kernel32.CloseHandle(token)
            self.kernel32.CloseHandle(process)

    def _send_mouse_button_event(self, flags: int) -> int:
        ctypes = self.ctypes
        wintypes = self.wintypes
        ULONG_PTR = wintypes.WPARAM

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [
                ("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR),
            ]
        class INPUTUNION(ctypes.Union):
            _fields_ = [("mi", MOUSEINPUT)]
        class INPUT(ctypes.Structure):
            _anonymous_ = ("u",)
            _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]

        INPUT_MOUSE = 0
        event = INPUT(type=INPUT_MOUSE, mi=MOUSEINPUT(0, 0, 0, int(flags), 0, 0))
        return int(self.user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)))

    def mouse_left_down(self) -> int:
        return self._send_mouse_button_event(0x0002)

    def mouse_left_up(self) -> int:
        return self._send_mouse_button_event(0x0004)

    def send_key(self, key: str) -> int:
        token = str(key).strip().upper()
        if token in {"ESC", "ESCAPE"}:
            virtual_key = 0x1B
        else:
            if not token.startswith("F") or not token[1:].isdigit():
                raise ValueError("supported keys are ESC and F1..F24")
            number = int(token[1:])
            if not 1 <= number <= 24:
                raise ValueError("supported keys are ESC and F1..F24")
            virtual_key = 0x70 + number - 1
        KEYEVENTF_KEYUP = 0x0002
        self.user32.keybd_event(virtual_key, 0, 0, 0)
        self.user32.keybd_event(virtual_key, 0, KEYEVENTF_KEYUP, 0)
        return 2

    def _send_left_click_events(self) -> int:
        # Legacy combined delivery remains available for older test/dummy APIs.
        # Native ANKA callers use the split DOWN/hold/UP transaction below.
        down = self.mouse_left_down()
        if down <= 0:
            return 0
        up = self.mouse_left_up()
        return int(down + up)

    def move_screen(self, x: int, y: int) -> bool:
        return bool(self.user32.SetCursorPos(int(x), int(y)))

    def move_physical_screen(self, x: int, y: int) -> bool:
        setter = getattr(self.user32, "SetPhysicalCursorPos", None)
        if setter is None:
            return False
        try:
            return bool(setter(int(x), int(y)))
        except AttributeError:
            return False

    def click_screen(self, x: int, y: int) -> int:
        if not self.move_screen(int(x), int(y)):
            return 0
        return self._send_left_click_events()


class IdentityContinuityState(str, Enum):
    VERIFIED_SAME = "VERIFIED_SAME"
    VERIFIED_CHANGED = "VERIFIED_CHANGED"
    UNAVAILABLE = "UNAVAILABLE"


class _WindowApiPointerBackend:
    def __init__(self, api: WindowInputApi) -> None:
        self.api = api

    def supports_position(self, mode: PointerCoordinateMode) -> bool:
        name = (
            "cursor_physical_screen_position"
            if mode is PointerCoordinateMode.PHYSICAL_SCREEN
            else "cursor_screen_position"
        )
        return callable(getattr(self.api, name, None))

    def cursor_position(self, mode: PointerCoordinateMode) -> PointerPosition | None:
        name = (
            "cursor_physical_screen_position"
            if mode is PointerCoordinateMode.PHYSICAL_SCREEN
            else "cursor_screen_position"
        )
        reader = getattr(self.api, name, None)
        if not callable(reader):
            return None
        try:
            value = reader()
        except Exception:
            return None
        if value is None:
            return None
        return PointerPosition(x=int(value[0]), y=int(value[1]))

    def move_cursor(self, mode: PointerCoordinateMode, position: PointerPosition) -> bool:
        name = "move_physical_screen" if mode is PointerCoordinateMode.PHYSICAL_SCREEN else "move_screen"
        mover = getattr(self.api, name, None)
        if not callable(mover):
            return False
        return bool(mover(int(position.x), int(position.y)))


@dataclass(frozen=True, slots=True)
class DofusWindowIdentity:
    hwnd: int
    pid: int
    process_creation_time: int
    client_instance_id: str
    title: str


@dataclass(slots=True)
class DofusWindowInputDriver:
    api: WindowInputApi
    title_contains: str = "Dofus"
    activation_hotkey: str | None = None
    # External AutoHotkey is never assumed to exist. ANKA owns account/window
    # switching through exact HWND/PID identity. A hotkey can be retained as an
    # explicit emergency fallback for legacy deployments, but it is disabled by
    # default so forgetting to start window.ahk cannot redirect F7/F8 elsewhere.
    activation_hotkey_fallback_enabled: bool = False
    sleep: Callable[[float], None] = time.sleep
    focus_attempts: int = 3
    focus_poll_seconds: float = 0.05
    focus_stable_checks: int = 2
    ui_hover_seconds: float = 0.09
    projection_hover_seconds: float = 0.03
    mouse_hold_seconds: float = 0.05
    post_click_settle_seconds: float = 0.08
    focus_activation_settle_seconds: float = 0.5
    pointer_motion_config: PointerMotionConfig = field(default_factory=PointerMotionConfig)
    _bound_hwnd: int | None = None
    _expected_identity: DofusWindowIdentity | None = None
    _last_diagnostic: dict = field(default_factory=dict)
    # Immutable copy of the most recent physical pointer/input boundary. Window
    # identity/focus diagnostics may freely replace _last_diagnostic afterwards
    # without erasing the evidence that belonged to the completed transaction.
    _last_physical_evidence: dict = field(default_factory=dict, init=False, repr=False)
    _physical_evidence_sequence: int = field(default=0, init=False, repr=False)
    _pointer_backend: _WindowApiPointerBackend = field(init=False, repr=False)
    _pointer_motion: PointerMotionService = field(init=False, repr=False)
    _endpoint_selector: SafeEndpointSelector = field(init=False, repr=False)
    _last_safe_endpoint_by_source: dict[str, PointerPosition] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        self.pointer_motion_config.validate()
        self._pointer_backend = _WindowApiPointerBackend(self.api)
        self._pointer_motion = PointerMotionService(
            backend=self._pointer_backend,
            config=self.pointer_motion_config,
            sleep=self.sleep,
        )
        self._endpoint_selector = SafeEndpointSelector()

    @classmethod
    def native(
        cls, *, title_contains: str = "Dofus", activation_hotkey: str | None = None,
        activation_hotkey_fallback_enabled: bool = False,
    ) -> "DofusWindowInputDriver":
        return cls(
            api=NativeWin32Api(), title_contains=title_contains, activation_hotkey=activation_hotkey,
            activation_hotkey_fallback_enabled=bool(activation_hotkey_fallback_enabled),
        )

    def _select_unique(self) -> int | None:
        token = self.title_contains.casefold()
        matched = [(hwnd,title) for hwnd, title in self.api.visible_windows() if token in title.casefold()]
        if len(matched) != 1:
            self._bound_hwnd = None
            self._last_diagnostic = {
                "status":"BLOCKED",
                "failure_code":"WINDOW_NOT_FOUND" if not matched else "WINDOW_AMBIGUOUS",
                "matching_window_count":len(matched),
                "matching_windows":[{"hwnd":int(hwnd),"title":str(title)} for hwnd,title in matched[:10]],
            }
            return None
        hwnd,title=matched[0]
        self._bound_hwnd = hwnd
        self._last_diagnostic={
            "status":"WINDOW_SELECTED","failure_code":None,"matching_window_count":1,
            "hwnd":int(hwnd),"title":str(title),
        }
        return hwnd

    def debug_status(self) -> dict:
        return dict(self._last_diagnostic)

    def _commit_physical_evidence(self, *, boundary: str) -> dict:
        self._physical_evidence_sequence += 1
        evidence = dict(self._last_diagnostic)
        evidence["physical_evidence_sequence"] = int(self._physical_evidence_sequence)
        evidence["physical_evidence_boundary"] = str(boundary)
        self._last_physical_evidence = evidence
        return dict(evidence)

    def last_input_transaction(self) -> dict:
        """Return immutable evidence for the last physical input boundary.

        Unlike debug_status(), this snapshot is not overwritten by later window
        identity/focus checks. It is a non-breaking bridge toward a fully typed
        InputTransactionResult contract.
        """
        return dict(self._last_physical_evidence)

    def identity(self) -> DofusWindowIdentity | None:
        """Return the exact unique top-level Dofus process identity for this title token."""
        hwnd=self._select_unique()
        if hwnd is None:
            return None
        if not hasattr(self.api,'window_process_id') or not hasattr(self.api,'process_creation_time'):
            self._last_diagnostic.update({"status":"BLOCKED","failure_code":"WINDOW_IDENTITY_UNAVAILABLE"})
            return None
        try:
            pid=int(self.api.window_process_id(hwnd))
            created=int(self.api.process_creation_time(pid))
        except Exception as exc:
            self._last_diagnostic.update({
                "status":"BLOCKED","failure_code":"WINDOW_IDENTITY_UNAVAILABLE",
                "detail":f"{type(exc).__name__}: {exc}",
            })
            return None
        title=next((str(title) for candidate,title in self.api.visible_windows() if int(candidate)==int(hwnd)), self.title_contains)
        raw=f'{hwnd}:{pid}:{created}'.encode('utf-8')
        client_instance_id='win-' + hashlib.sha256(raw).hexdigest()[:32]
        result=DofusWindowIdentity(
            hwnd=int(hwnd), pid=pid, process_creation_time=created,
            client_instance_id=client_instance_id, title=title,
        )
        self._last_diagnostic.update({
            "status":"WINDOW_IDENTIFIED","failure_code":None,"hwnd":int(hwnd),
            "pid":pid,"process_creation_time":created,"client_instance_id":client_instance_id,"title":title,
        })
        return result

    def bind_identity(self, identity: DofusWindowIdentity | None = None) -> DofusWindowIdentity | None:
        """Freeze the exact HWND/PID/process generation used by this runtime lane.

        Legacy single-client callers may keep using the driver without binding. Party
        runtimes bind once at startup and every later input must prove continuity.
        """
        resolved = identity or self.identity()
        if resolved is None:
            return None
        self._expected_identity = resolved
        self._bound_hwnd = int(resolved.hwnd)
        self._last_diagnostic.update({
            "status": "WINDOW_IDENTITY_BOUND",
            "failure_code": None,
            "expected_hwnd": int(resolved.hwnd),
            "expected_pid": int(resolved.pid),
            "expected_process_creation_time": int(resolved.process_creation_time),
            "expected_client_instance_id": str(resolved.client_instance_id),
        })
        return resolved

    def verify_bound_identity_state(self) -> IdentityContinuityState:
        """Classify continuity using the cheapest exact-generation proof first.

        R5.152 keeps HWND -> PID -> process creation time as the authority.  A
        stable bound HWND therefore does not need an expensive EnumWindows scan
        on every runtime-health check.  Full enumeration is a *fallback only*
        when the bound HWND cannot be queried, so we can still distinguish a
        positive same-account replacement from temporary observation failure.
        """
        expected = self._expected_identity
        if expected is None:
            # Legacy mode has no immutable generation to compare. A unique visible
            # window is enough to preserve old behavior; inability to discover one
            # is observational unavailability rather than a proven replacement.
            return (
                IdentityContinuityState.VERIFIED_SAME
                if self._select_unique() is not None
                else IdentityContinuityState.UNAVAILABLE
            )

        # Hot-path proof: process ownership is the generation authority.  Do not
        # enumerate every desktop window when the exact bound HWND remains valid.
        try:
            pid = int(self.api.window_process_id(int(expected.hwnd)))
            created = int(self.api.process_creation_time(pid))
        except Exception as direct_exc:
            # Only now pay for desktop enumeration.  It is diagnostic/replacement
            # evidence, not part of the normal stable-identity proof.
            try:
                visible = {int(hwnd): str(title) for hwnd, title in self.api.visible_windows()}
            except Exception as enum_exc:
                self._last_diagnostic = {
                    "status": "BLOCKED",
                    "failure_code": "WINDOW_IDENTITY_UNAVAILABLE",
                    "detail": (
                        f"bound HWND query failed: {type(direct_exc).__name__}: {direct_exc}; "
                        f"window enumeration failed: {type(enum_exc).__name__}: {enum_exc}"
                    ),
                    "expected_hwnd": int(expected.hwnd),
                    "expected_pid": int(expected.pid),
                    "expected_process_creation_time": int(expected.process_creation_time),
                    "expected_client_instance_id": str(expected.client_instance_id),
                    "identity_continuity": IdentityContinuityState.UNAVAILABLE.value,
                    "verification_mode": "BOUND_HWND_FAST_PATH_THEN_ENUM_FALLBACK",
                }
                return IdentityContinuityState.UNAVAILABLE

            title = visible.get(int(expected.hwnd))
            candidates = [
                (int(hwnd), str(candidate_title))
                for hwnd, candidate_title in visible.items()
                if int(hwnd) != int(expected.hwnd)
                and self.title_contains.casefold() in str(candidate_title).casefold()
            ]
            if len(candidates) == 1:
                candidate_hwnd, candidate_title = candidates[0]
                try:
                    candidate_pid = int(self.api.window_process_id(candidate_hwnd))
                    candidate_created = int(self.api.process_creation_time(candidate_pid))
                except Exception:
                    candidate_pid = None
                    candidate_created = None
                if (
                    candidate_pid is not None
                    and candidate_created is not None
                    and (
                        candidate_pid != int(expected.pid)
                        or candidate_created != int(expected.process_creation_time)
                    )
                ):
                    self._last_diagnostic = {
                        "status": "BLOCKED",
                        "failure_code": "WINDOW_IDENTITY_CHANGED",
                        "detail": "bound HWND became unavailable and a unique same-account window belongs to a different process generation",
                        "expected_hwnd": int(expected.hwnd),
                        "replacement_hwnd": candidate_hwnd,
                        "expected_pid": int(expected.pid),
                        "replacement_pid": candidate_pid,
                        "expected_process_creation_time": int(expected.process_creation_time),
                        "replacement_process_creation_time": candidate_created,
                        "expected_client_instance_id": str(expected.client_instance_id),
                        "replacement_title": candidate_title,
                        "identity_continuity": IdentityContinuityState.VERIFIED_CHANGED.value,
                        "verification_mode": "ENUM_FALLBACK_REPLACEMENT_PROOF",
                    }
                    return IdentityContinuityState.VERIFIED_CHANGED
            self._last_diagnostic = {
                "status": "BLOCKED",
                "failure_code": "WINDOW_IDENTITY_UNAVAILABLE",
                "detail": f"{type(direct_exc).__name__}: {direct_exc}",
                "expected_hwnd": int(expected.hwnd),
                "expected_pid": int(expected.pid),
                "expected_process_creation_time": int(expected.process_creation_time),
                "expected_client_instance_id": str(expected.client_instance_id),
                "expected_visible": title is not None,
                "visible_title": title,
                "identity_continuity": IdentityContinuityState.UNAVAILABLE.value,
                "verification_mode": "BOUND_HWND_FAST_PATH_THEN_ENUM_FALLBACK",
            }
            return IdentityContinuityState.UNAVAILABLE

        if pid != int(expected.pid) or created != int(expected.process_creation_time):
            self._last_diagnostic = {
                "status": "BLOCKED",
                "failure_code": "WINDOW_IDENTITY_CHANGED",
                "detail": "bound HWND now belongs to a different process generation",
                "expected_hwnd": int(expected.hwnd),
                "actual_hwnd": int(expected.hwnd),
                "expected_pid": int(expected.pid),
                "actual_pid": pid,
                "expected_process_creation_time": int(expected.process_creation_time),
                "actual_process_creation_time": created,
                "expected_client_instance_id": str(expected.client_instance_id),
                "identity_continuity": IdentityContinuityState.VERIFIED_CHANGED.value,
                "verification_mode": "BOUND_HWND_FAST_PATH",
            }
            return IdentityContinuityState.VERIFIED_CHANGED

        self._bound_hwnd = int(expected.hwnd)
        self._last_diagnostic = {
            "status": "WINDOW_IDENTITY_VERIFIED",
            "failure_code": None,
            "hwnd": int(expected.hwnd),
            "pid": pid,
            "process_creation_time": created,
            "client_instance_id": str(expected.client_instance_id),
            # Do not enumerate just to refresh a title.  The bound title is
            # diagnostic metadata; PID + process creation time is the authority.
            "title": str(expected.title or self.title_contains),
            "identity_continuity": IdentityContinuityState.VERIFIED_SAME.value,
            "verification_mode": "BOUND_HWND_FAST_PATH",
        }
        return IdentityContinuityState.VERIFIED_SAME

    def verify_bound_identity(self) -> bool:
        """Backward-compatible Boolean view of :meth:`verify_bound_identity_state`."""
        return self.verify_bound_identity_state() is IdentityContinuityState.VERIFIED_SAME

    def client_instance_id(self) -> str | None:
        """Return the bound continuity token, or discover one in legacy mode."""
        if self._expected_identity is not None:
            return self._expected_identity.client_instance_id
        identity=self.identity()
        return identity.client_instance_id if identity is not None else None

    def observed_client_version(self) -> str | None:
        """Return a four-component Dofus build from the bound window title when available."""
        title = None
        if self._expected_identity is not None:
            title = self._expected_identity.title
        elif isinstance(self._last_diagnostic, dict):
            title = self._last_diagnostic.get("title")
        match = re.search(r"(?<!\d)(\d+\.\d+\.\d+\.\d+)(?!\d)", str(title or ""))
        return match.group(1) if match else None

    def cancel_current_action(self) -> PhysicalSendState:
        """Send ESC to return the focused Dofus client to a neutral targeting UI.

        This is intentionally narrower than the activation-hotkey path. It is used
        only after ANKA has certainly selected a spell slot but decides not to emit
        the semantic target click. A failed/partial ESC leaves the transaction
        uncertain so subsequent map clicks cannot be reinterpreted by stale UI mode.
        """
        hwnd = self._bound_hwnd
        if hwnd is None or self.api.foreground_window() != hwnd:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "input": "UI_CANCEL", "key": "ESC",
                "detail": "UI cancel target is not the foreground bound Dofus window",
            })
            self._commit_physical_evidence(boundary="UI_CANCEL")
            return PhysicalSendState.NOT_SENT
        if not hasattr(self.api, "send_key"):
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "input": "UI_CANCEL", "key": "ESC", "detail": "keyboard API unavailable",
            })
            self._commit_physical_evidence(boundary="UI_CANCEL")
            return PhysicalSendState.NOT_SENT
        try:
            sent = int(self.api.send_key("ESC"))
        except Exception as exc:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "input": "UI_CANCEL", "key": "ESC",
                "detail": f"UI cancel failed: {type(exc).__name__}: {exc}",
            })
            self._commit_physical_evidence(boundary="UI_CANCEL")
            return PhysicalSendState.NOT_SENT
        final_foreground = self.api.foreground_window()
        complete = sent >= 2 and final_foreground == int(hwnd)
        self._last_diagnostic.update({
            "input": "UI_CANCEL", "key": "ESC", "sendinput_count": sent,
            "transaction_complete": bool(complete),
            "target_hwnd": int(hwnd), "foreground_after_transaction": final_foreground,
        })
        if complete:
            self._last_diagnostic.update({"status": "SENT", "failure_code": None})
            self._commit_physical_evidence(boundary="UI_CANCEL")
            return PhysicalSendState.SENT
        if sent > 0:
            self._last_diagnostic.update({"status": "UNCERTAIN", "failure_code": "INPUT_UNCERTAIN"})
            self._commit_physical_evidence(boundary="UI_CANCEL")
            return PhysicalSendState.UNCERTAIN
        self._last_diagnostic.update({"status": "BLOCKED", "failure_code": "INPUT_NOT_SENT"})
        self._commit_physical_evidence(boundary="UI_CANCEL")
        return PhysicalSendState.NOT_SENT

    def _foreground_is_stable(self, hwnd: int) -> bool:
        checks = max(1, int(self.focus_stable_checks))
        for index in range(checks):
            if self.api.foreground_window() != int(hwnd):
                return False
            if index + 1 < checks and self.focus_poll_seconds > 0:
                self.sleep(float(self.focus_poll_seconds))
        return True

    def _attempt_attached_focus(self, hwnd: int, attempt_detail: dict) -> bool:
        required = ("current_thread_id", "window_thread_id", "attach_thread_input")
        if not all(hasattr(self.api, name) for name in required):
            attempt_detail["attach_thread_input"] = "UNSUPPORTED"
            return False
        current_tid = int(self.api.current_thread_id())
        foreground_hwnd = self.api.foreground_window()
        target_tid = int(self.api.window_thread_id(int(hwnd)))
        candidate_tids: list[int] = [target_tid]
        if foreground_hwnd is not None:
            try:
                foreground_tid = int(self.api.window_thread_id(int(foreground_hwnd)))
                if foreground_tid not in candidate_tids:
                    candidate_tids.append(foreground_tid)
            except Exception as exc:
                attempt_detail["foreground_thread_error"] = f"{type(exc).__name__}: {exc}"
        attached: list[int] = []
        attempt_detail["current_thread_id"] = current_tid
        attempt_detail["target_thread_id"] = target_tid
        try:
            for tid in candidate_tids:
                if tid == current_tid:
                    continue
                try:
                    if self.api.attach_thread_input(current_tid, tid, True):
                        attached.append(tid)
                except Exception as exc:
                    attempt_detail.setdefault("attach_errors", []).append(
                        {"thread_id": tid, "detail": f"{type(exc).__name__}: {exc}"}
                    )
            attempt_detail["attached_thread_ids"] = list(attached)
            if hasattr(self.api, "bring_to_top"):
                try:
                    attempt_detail["attached_bring_to_top"] = bool(self.api.bring_to_top(int(hwnd)))
                except Exception as exc:
                    attempt_detail["attached_bring_to_top_error"] = f"{type(exc).__name__}: {exc}"
            if hasattr(self.api, "activate_thread_window"):
                try:
                    attempt_detail["attached_activate_thread_window"] = bool(self.api.activate_thread_window(int(hwnd)))
                except Exception as exc:
                    attempt_detail["attached_activate_thread_window_error"] = f"{type(exc).__name__}: {exc}"
            attempt_detail["attached_set_foreground"] = bool(self.api.set_foreground(int(hwnd)))
            if self._foreground_is_stable(int(hwnd)):
                return True
            attempt_detail["attached_foreground_hwnd"] = self.api.foreground_window()
            return False
        finally:
            for tid in reversed(attached):
                try:
                    self.api.attach_thread_input(current_tid, tid, False)
                except Exception:
                    pass

    def ensure_target_focused(self) -> bool:
        if self._expected_identity is not None:
            if not self.verify_bound_identity():
                return False
            hwnd = int(self._expected_identity.hwnd)
        else:
            hwnd = self._select_unique()
            if hwnd is None:
                return False

        initial_foreground = self.api.foreground_window()
        attempts: list[dict] = []
        if initial_foreground == hwnd and self._foreground_is_stable(hwnd):
            self._last_diagnostic.update({
                "status": "WINDOW_READY", "failure_code": None, "foreground_hwnd": hwnd,
                "target_hwnd": hwnd, "initial_foreground_hwnd": initial_foreground,
                "focus_method": "ALREADY_FOREGROUND", "focus_attempts": attempts,
                "focus_switched": False,
            })
            return True

        minimized = False
        if hasattr(self.api, "is_minimized"):
            try:
                minimized = bool(self.api.is_minimized(hwnd))
            except Exception as exc:
                attempts.append({"phase": "MINIMIZED_CHECK", "error": f"{type(exc).__name__}: {exc}"})
        if minimized and hasattr(self.api, "restore_window"):
            try:
                restored = bool(self.api.restore_window(hwnd))
                attempts.append({"phase": "RESTORE", "result": restored})
                if self.focus_poll_seconds > 0:
                    self.sleep(float(self.focus_poll_seconds))
            except Exception as exc:
                attempts.append({"phase": "RESTORE", "error": f"{type(exc).__name__}: {exc}"})

        for attempt_no in range(1, max(1, int(self.focus_attempts)) + 1):
            direct: dict = {"attempt": attempt_no, "method": "DIRECT"}
            if hasattr(self.api, "bring_to_top"):
                try:
                    direct["bring_to_top"] = bool(self.api.bring_to_top(hwnd))
                except Exception as exc:
                    direct["bring_to_top_error"] = f"{type(exc).__name__}: {exc}"
            try:
                direct["set_foreground"] = bool(self.api.set_foreground(hwnd))
            except Exception as exc:
                direct["set_foreground"] = False
                direct["set_foreground_error"] = f"{type(exc).__name__}: {exc}"
            direct["foreground_hwnd"] = self.api.foreground_window()
            attempts.append(direct)
            if self._foreground_is_stable(hwnd):
                self._last_diagnostic.update({
                    "status": "WINDOW_READY", "failure_code": None, "foreground_hwnd": hwnd,
                    "target_hwnd": hwnd, "initial_foreground_hwnd": initial_foreground,
                    "focus_method": "DIRECT", "focus_attempts": attempts,
                    "focus_switched": initial_foreground != hwnd,
                })
                if initial_foreground != hwnd and self.focus_activation_settle_seconds > 0:
                    self.sleep(float(self.focus_activation_settle_seconds))
                return True

            attached: dict = {"attempt": attempt_no, "method": "ATTACH_THREAD_INPUT"}
            try:
                attached_ok = self._attempt_attached_focus(hwnd, attached)
            except Exception as exc:
                attached_ok = False
                attached["error"] = f"{type(exc).__name__}: {exc}"
            attempts.append(attached)
            if attached_ok:
                self._last_diagnostic.update({
                    "status": "WINDOW_READY", "failure_code": None, "foreground_hwnd": hwnd,
                    "target_hwnd": hwnd, "initial_foreground_hwnd": initial_foreground,
                    "focus_method": "ATTACH_THREAD_INPUT", "focus_attempts": attempts,
                    "focus_switched": initial_foreground != hwnd,
                })
                if initial_foreground != hwnd and self.focus_activation_settle_seconds > 0:
                    self.sleep(float(self.focus_activation_settle_seconds))
                return True
            if self.focus_poll_seconds > 0:
                self.sleep(float(self.focus_poll_seconds))

        if self.activation_hotkey_fallback_enabled and self.activation_hotkey and hasattr(self.api, "send_key"):
            hotkey_attempt = {"method": "HOTKEY_FALLBACK", "key": str(self.activation_hotkey)}
            try:
                hotkey_attempt["send_count"] = int(self.api.send_key(str(self.activation_hotkey)))
                if self.focus_activation_settle_seconds > 0:
                    self.sleep(float(self.focus_activation_settle_seconds))
                hotkey_attempt["foreground_hwnd"] = self.api.foreground_window()
                attempts.append(hotkey_attempt)
                if self._foreground_is_stable(hwnd) and self.verify_bound_identity():
                    self._last_diagnostic.update({
                        "status": "WINDOW_READY", "failure_code": None, "foreground_hwnd": hwnd,
                        "target_hwnd": hwnd, "initial_foreground_hwnd": initial_foreground,
                        "focus_method": "HOTKEY_FALLBACK", "activation_hotkey": str(self.activation_hotkey),
                        "focus_attempts": attempts, "focus_switched": initial_foreground != hwnd,
                    })
                    return True
            except Exception as exc:
                hotkey_attempt["error"] = f"{type(exc).__name__}: {exc}"
                if hotkey_attempt not in attempts:
                    attempts.append(hotkey_attempt)
        elif self.activation_hotkey:
            attempts.append({
                "method": "HOTKEY_FALLBACK",
                "key": str(self.activation_hotkey),
                "status": "DISABLED",
                "detail": "external activation hotkeys are not trusted unless explicitly enabled",
            })

        self._last_diagnostic.update({
            "status": "BLOCKED", "failure_code": "WINDOW_FOCUS_FAILED",
            "detail": "bounded foreground acquisition failed before any game input was sent",
            "target_hwnd": hwnd, "initial_foreground_hwnd": initial_foreground,
            "final_foreground_hwnd": self.api.foreground_window(), "focus_attempts": attempts,
        })
        return False

    @staticmethod
    def _reference_client_profile(
        actual_width: int, actual_height: int, expected_width: int, expected_height: int,
    ) -> dict | None:
        if min(actual_width, actual_height, expected_width, expected_height) <= 0:
            return None
        sx = float(actual_width) / float(expected_width)
        sy = float(actual_height) / float(expected_height)
        if abs(sx - 1.0) <= 0.002 and abs(sy - 1.0) <= 0.002:
            return {"coordinate_mode": "REFERENCE_CLIENT_PIXELS", "scale_x": 1.0, "scale_y": 1.0}
        if abs(sx - sy) > 0.02:
            return None
        supported = (
            1/3.0, 1/2.5, 1/2.25, 1/2.0, 1/1.75, 1/1.5, 1/1.25,
            1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 3.0,
        )
        avg = (sx + sy) / 2.0
        nearest = min(supported, key=lambda value: abs(value - avg))
        if abs(sx - nearest) > 0.03 or abs(sy - nearest) > 0.03:
            return None
        return {
            "coordinate_mode": "DPI_SCALED_REFERENCE_CLIENT_PIXELS",
            "scale_x": sx, "scale_y": sy, "effective_scale": nearest,
        }

    def _translate_reference_client_point(
        self, hwnd: int, point: CalibrationPoint, *, expected_width: int, expected_height: int,
    ) -> tuple[int, int, int, int, dict] | None:
        width, height = self.api.client_size(hwnd)
        profile = self._reference_client_profile(width, height, expected_width, expected_height)
        if profile is None:
            return None
        actual_x = int(round(int(point.x) * float(profile["scale_x"])))
        actual_y = int(round(int(point.y) * float(profile["scale_y"])))
        if not (0 <= actual_x < int(width) and 0 <= actual_y < int(height)):
            return None
        if hasattr(self.api, "client_to_physical_screen"):
            screen_x, screen_y = self.api.client_to_physical_screen(hwnd, actual_x, actual_y)
            profile = {**profile, "screen_coordinate_mode": "PHYSICAL_SCREEN_PIXELS"}
        else:
            screen_x, screen_y = self.api.client_to_screen(hwnd, actual_x, actual_y)
            profile = {**profile, "screen_coordinate_mode": "CALLER_SCREEN_PIXELS"}
        return int(width), int(height), int(screen_x), int(screen_y), {
            **profile, "actual_client_point": [actual_x, actual_y],
        }

    def client_passive_input_readiness(
        self, point: CalibrationPoint, *, expected_width: int, expected_height: int
    ) -> dict:
        """Validate the exact bound client for future input without foreground mutation.

        Script Studio and other control-plane observers must remain passive.  This
        method is therefore limited to read-only identity, geometry/translation, DPI
        and integrity checks.  It never restores, activates, focuses, sends a key,
        moves the cursor, or clicks.  Execution still calls ``ensure_target_focused``
        immediately before an authorized physical action.
        """
        if not point.verified:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "detail": "required calibration point is not verified",
                "foreground_required": False,
            })
            return {"ready": False, **self.debug_status()}

        if self._expected_identity is not None:
            if not self.verify_bound_identity():
                payload = self.debug_status()
                payload["foreground_required"] = False
                return {"ready": False, **payload}
            hwnd = int(self._expected_identity.hwnd)
        else:
            hwnd = self._select_unique()
            if hwnd is None:
                payload = self.debug_status()
                payload["foreground_required"] = False
                return {"ready": False, **payload}

        try:
            translated = self._translate_reference_client_point(
                int(hwnd), point, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        except Exception as exc:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "detail": f"client coordinate translation failed: {type(exc).__name__}: {exc}",
                "foreground_required": False,
            })
            return {"ready": False, **self.debug_status()}
        if translated is None:
            try:
                width, height = self.api.client_size(int(hwnd))
            except Exception:
                width, height = 0, 0
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "CLIENT_SIZE_MISMATCH",
                "expected_client_size": [int(expected_width), int(expected_height)],
                "actual_client_size": [int(width), int(height)],
                "foreground_required": False,
            })
            return {"ready": False, **self.debug_status()}
        width, height, screen_x, screen_y, coordinate_profile = translated

        current_integrity = None
        target_integrity = None
        if hasattr(self.api, "current_process_integrity_rid") and hasattr(self.api, "process_integrity_rid"):
            try:
                target_pid = (
                    int(self._expected_identity.pid)
                    if self._expected_identity is not None
                    else int(self.api.window_process_id(int(hwnd)))
                )
                current_integrity = int(self.api.current_process_integrity_rid())
                target_integrity = int(self.api.process_integrity_rid(target_pid))
            except Exception as exc:
                self._last_diagnostic.update({
                    "status": "BLOCKED", "failure_code": "INPUT_INTEGRITY_UNAVAILABLE",
                    "detail": f"integrity check failed: {type(exc).__name__}: {exc}",
                    "actual_client_size": [int(width), int(height)],
                    "foreground_required": False,
                })
                return {"ready": False, **self.debug_status()}
            if target_integrity > current_integrity:
                self._last_diagnostic.update({
                    "status": "BLOCKED", "failure_code": "INPUT_INTEGRITY_MISMATCH",
                    "detail": "target Dofus process has higher integrity than ANKA; SendInput would be unsafe/unreliable",
                    "current_integrity_rid": current_integrity, "target_integrity_rid": target_integrity,
                    "actual_client_size": [int(width), int(height)],
                    "foreground_required": False,
                })
                return {"ready": False, **self.debug_status()}

        foreground = None
        try:
            foreground = self.api.foreground_window()
        except Exception:
            foreground = None
        self._last_diagnostic.update({
            "status": "WINDOW_INPUT_PASSIVE_READY", "failure_code": None, "ready": True,
            "target_hwnd": int(hwnd), "foreground_hwnd": foreground,
            "foreground_required": False, "focus_switched": False,
            "expected_client_size": [int(expected_width), int(expected_height)],
            "reference_client_size": [int(expected_width), int(expected_height)],
            "actual_client_size": [int(width), int(height)],
            "client_point": [int(point.x), int(point.y)],
            "actual_client_point": coordinate_profile.get("actual_client_point"),
            "screen_point": [int(screen_x), int(screen_y)],
            "coordinate_mode": coordinate_profile.get("coordinate_mode"),
            "screen_coordinate_mode": coordinate_profile.get("screen_coordinate_mode"),
            "reference_to_actual_scale": [coordinate_profile.get("scale_x"), coordinate_profile.get("scale_y")],
            "window_dpi": self.api.window_dpi(int(hwnd)) if hasattr(self.api, "window_dpi") else None,
            "current_integrity_rid": current_integrity, "target_integrity_rid": target_integrity,
            "sendinput_count": 0,
        })
        return {"ready": True, **self.debug_status()}

    def client_input_readiness(
        self, point: CalibrationPoint, *, expected_width: int, expected_height: int
    ) -> dict:
        """Prove exact-window reference-client input prerequisites without sending game input."""
        if not point.verified:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "detail": "required calibration point is not verified",
            })
            return {"ready": False, **self.debug_status()}
        if not self.ensure_target_focused():
            return {"ready": False, **self.debug_status()}
        hwnd = self._bound_hwnd
        if hwnd is None:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "WINDOW_NOT_FOUND",
                "detail": "bound HWND unavailable after focus",
            })
            return {"ready": False, **self.debug_status()}
        try:
            translated = self._translate_reference_client_point(
                hwnd, point, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        except Exception as exc:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "detail": f"client coordinate translation failed: {type(exc).__name__}: {exc}",
            })
            return {"ready": False, **self.debug_status()}
        if translated is None:
            try:
                width, height = self.api.client_size(hwnd)
            except Exception:
                width, height = 0, 0
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "CLIENT_SIZE_MISMATCH",
                "expected_client_size": [int(expected_width), int(expected_height)],
                "actual_client_size": [int(width), int(height)],
            })
            return {"ready": False, **self.debug_status()}
        width, height, screen_x, screen_y, coordinate_profile = translated

        current_integrity = None
        target_integrity = None
        if hasattr(self.api, "current_process_integrity_rid") and hasattr(self.api, "process_integrity_rid"):
            try:
                target_pid = (
                    int(self._expected_identity.pid)
                    if self._expected_identity is not None
                    else int(self.api.window_process_id(hwnd))
                )
                current_integrity = int(self.api.current_process_integrity_rid())
                target_integrity = int(self.api.process_integrity_rid(target_pid))
            except Exception as exc:
                self._last_diagnostic.update({
                    "status": "BLOCKED", "failure_code": "INPUT_INTEGRITY_UNAVAILABLE",
                    "detail": f"integrity check failed: {type(exc).__name__}: {exc}",
                    "actual_client_size": [int(width), int(height)],
                })
                return {"ready": False, **self.debug_status()}
            if target_integrity > current_integrity:
                self._last_diagnostic.update({
                    "status": "BLOCKED", "failure_code": "INPUT_INTEGRITY_MISMATCH",
                    "detail": "target Dofus process has higher integrity than ANKA; SendInput would be unsafe/unreliable",
                    "current_integrity_rid": current_integrity, "target_integrity_rid": target_integrity,
                    "actual_client_size": [int(width), int(height)],
                })
                return {"ready": False, **self.debug_status()}
        if self.api.foreground_window() != hwnd:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "WINDOW_FOCUS_FAILED",
                "detail": "target lost foreground during readiness verification",
                "target_hwnd": int(hwnd), "final_foreground_hwnd": self.api.foreground_window(),
            })
            return {"ready": False, **self.debug_status()}
        self._last_diagnostic.update({
            "status": "WINDOW_INPUT_READY", "failure_code": None, "ready": True,
            "target_hwnd": int(hwnd), "foreground_hwnd": int(hwnd),
            "expected_client_size": [int(expected_width), int(expected_height)],
            "reference_client_size": [int(expected_width), int(expected_height)],
            "actual_client_size": [int(width), int(height)],
            "client_point": [int(point.x), int(point.y)],
            "actual_client_point": coordinate_profile.get("actual_client_point"),
            "screen_point": [int(screen_x), int(screen_y)],
            "coordinate_mode": coordinate_profile.get("coordinate_mode"),
            "screen_coordinate_mode": coordinate_profile.get("screen_coordinate_mode"),
            "reference_to_actual_scale": [coordinate_profile.get("scale_x"), coordinate_profile.get("scale_y")],
            "window_dpi": self.api.window_dpi(hwnd) if hasattr(self.api, "window_dpi") else None,
            "current_integrity_rid": current_integrity, "target_integrity_rid": target_integrity,
            "sendinput_count": 0,
        })
        return {"ready": True, **self.debug_status()}

    def _hover_seconds_for_source(self, source: str | None) -> float:
        value = str(source or "")
        if value.startswith("projection:"):
            return max(0.0, float(self.projection_hover_seconds))
        return max(0.0, float(self.ui_hover_seconds))

    def _window_identity_snapshot(self, hwnd: int | None) -> dict | None:
        """Best-effort forensic identity for any foreground window.

        This helper is diagnostic only and never changes focus. It intentionally
        tolerates partial/dummy APIs so test and non-Windows callers keep working.
        """
        if hwnd is None:
            return None
        row: dict[str, object] = {"hwnd": int(hwnd)}
        try:
            title = next(
                (str(title) for candidate, title in self.api.visible_windows() if int(candidate) == int(hwnd)),
                None,
            )
            if title is not None:
                row["title"] = title
        except Exception:
            pass
        try:
            if hasattr(self.api, "window_process_id"):
                pid = int(self.api.window_process_id(int(hwnd)))
                row["pid"] = pid
                if hasattr(self.api, "process_creation_time"):
                    try:
                        row["process_creation_time"] = int(self.api.process_creation_time(pid))
                    except Exception:
                        pass
        except Exception:
            pass
        return row

    def _move_pointer_to(
        self,
        *,
        hwnd: int,
        x: int,
        y: int,
        physical: bool,
    ) -> bool:
        mode = (
            PointerCoordinateMode.PHYSICAL_SCREEN
            if physical
            else PointerCoordinateMode.SCREEN
        )
        move_name = "move_physical_screen" if physical else "move_screen"
        mover = getattr(self.api, move_name, None)
        if not callable(mover):
            self._last_diagnostic.update({
                "status": "BLOCKED",
                "failure_code": "INPUT_CURSOR_MOVE_UNAVAILABLE",
                "cursor_moved": False,
            })
            return False

        # Compatibility is deliberately limited to non-production/dummy APIs
        # that do not expose a cursor reader. NativeWin32Api always exposes the
        # real position and therefore always traverses PointerMotionService.
        if not self._pointer_backend.supports_position(mode):
            moved = bool(mover(int(x), int(y)))
            self._last_diagnostic.update({
                "motion_status": "ARRIVED" if moved else "BLOCKED",
                "motion_failure_code": None if moved else "INPUT_CURSOR_MOVE_FAILED",
                "motion_profile": "LEGACY_DIRECT_NO_CURSOR_READER",
                "motion_target": [int(x), int(y)],
                "motion_final": [int(x), int(y)] if moved else None,
                "motion_sample_count": 1 if moved else 0,
                "motion_emitted_positions": 1 if moved else 0,
                "motion_exact_arrival": bool(moved),
                "motion_legacy_direct_fallback": True,
                "cursor_moved": bool(moved),
            })
            return moved

        result = self._pointer_motion.move_to(
            target=PointerPosition(x=int(x), y=int(y)),
            mode=mode,
            focus_guard=lambda: self.api.foreground_window() == int(hwnd),
        )
        self._last_diagnostic.update(result.diagnostics())
        self._last_diagnostic["cursor_moved"] = bool(result.success)
        if not result.success:
            self._last_diagnostic.update({
                "status": "BLOCKED",
                "failure_code": str(result.failure_code or "INPUT_CURSOR_MOVE_FAILED"),
                "transaction_complete": False,
                "target_hwnd": int(hwnd),
            })
        return bool(result.success)

    def _split_click_transaction(
        self,
        *,
        hwnd: int,
        x: int,
        y: int,
        physical: bool,
        source: str | None,
        pre_down_guard: Callable[[dict | None], bool | tuple[bool, dict | None]] | None = None,
    ) -> PhysicalSendState | None:
        """Deliver a robust mouse transaction when the API exposes split events.

        Returning ``None`` means the backing API does not support the split path
        and the caller may use the legacy combined click implementation.
        """
        if not (hasattr(self.api, "mouse_left_down") and hasattr(self.api, "mouse_left_up")):
            return None
        move_name = "move_physical_screen" if physical else "move_screen"
        if not hasattr(self.api, move_name):
            return None
        if self.api.foreground_window() != int(hwnd):
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_FOREGROUND_LOST_BEFORE_CLICK",
                "transaction_complete": False, "foreground_before_transaction": self.api.foreground_window(),
                "target_hwnd": int(hwnd),
            })
            return PhysicalSendState.NOT_SENT

        if not self._move_pointer_to(
            hwnd=int(hwnd), x=int(x), y=int(y), physical=bool(physical),
        ):
            return PhysicalSendState.NOT_SENT

        hover = self._hover_seconds_for_source(source)
        if hover > 0:
            self.sleep(hover)
        if self.api.foreground_window() != int(hwnd):
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_FOREGROUND_LOST_BEFORE_CLICK",
                "transaction_complete": False, "foreground_after_hover": self.api.foreground_window(),
                "target_hwnd": int(hwnd), "cursor_moved": True,
            })
            return PhysicalSendState.NOT_SENT

        # R5.160: smooth pointer travel widens the interval between semantic
        # admission and mouse DOWN. Run the caller's final semantic guard only
        # after exact cursor arrival/hover and immediately before DOWN. A failed
        # guard is a proven pre-input block: no button event has been emitted.
        if pre_down_guard is not None:
            guard_detail: dict | None = None
            try:
                guard_context = {
                    "selected_screen_point": [int(x), int(y)],
                    "physical_screen_coordinates": bool(physical),
                    "source": source,
                }
                try:
                    signature = inspect.signature(pre_down_guard)
                    accepts_context = bool(signature.parameters)
                except (TypeError, ValueError):
                    accepts_context = True
                guard_result = pre_down_guard(guard_context) if accepts_context else pre_down_guard()
                if isinstance(guard_result, tuple):
                    guard_allowed = bool(guard_result[0])
                    if len(guard_result) > 1 and isinstance(guard_result[1], dict):
                        guard_detail = dict(guard_result[1])
                else:
                    guard_allowed = bool(guard_result)
            except Exception as exc:
                guard_allowed = False
                guard_detail = {
                    "guard_exception": f"{type(exc).__name__}: {exc}",
                }
            if not guard_allowed:
                self._last_diagnostic.update({
                    "status": "BLOCKED",
                    "failure_code": "INPUT_PRE_DOWN_GUARD_BLOCKED",
                    "transaction_complete": False,
                    "physical_send_state": PhysicalSendState.NOT_SENT.value,
                    "target_hwnd": int(hwnd),
                    "cursor_moved": True,
                    "pre_down_guard": guard_detail or {},
                })
                return PhysicalSendState.NOT_SENT
            self._last_diagnostic["pre_down_guard"] = {
                "allowed": True,
                **(guard_detail or {}),
            }

        transaction_started_monotonic_ms = int(time.monotonic() * 1000)
        foreground_before_down = self.api.foreground_window()
        down = int(self.api.mouse_left_down())
        foreground_after_down = self.api.foreground_window()
        up = 0
        if down <= 0:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_MOUSE_DOWN_NOT_SENT",
                "transaction_complete": False, "mouse_down_count": down, "mouse_up_count": 0,
                "input_delivery": "SPLIT_SENDINPUT", "target_hwnd": int(hwnd),
                "foreground_before_down": foreground_before_down,
                "foreground_after_down": foreground_after_down,
                "transaction_started_monotonic_ms": transaction_started_monotonic_ms,
                "transaction_finished_monotonic_ms": int(time.monotonic() * 1000),
            })
            return PhysicalSendState.NOT_SENT

        try:
            if self.mouse_hold_seconds > 0:
                self.sleep(float(self.mouse_hold_seconds))
        finally:
            # Always release once DOWN was accepted. Capture focus immediately
            # before and after UP so a post-click focus steal is distinguishable
            # from a genuinely dangerous mid-click transition.
            foreground_before_up = self.api.foreground_window()
            up = int(self.api.mouse_left_up())
            foreground_after_up = self.api.foreground_window()

        if self.post_click_settle_seconds > 0:
            self.sleep(float(self.post_click_settle_seconds))
        final_foreground = self.api.foreground_window()
        transaction_finished_monotonic_ms = int(time.monotonic() * 1000)
        complete = (
            down >= 1 and up >= 1
            and foreground_before_down == int(hwnd)
            and foreground_after_down == int(hwnd)
            and foreground_before_up == int(hwnd)
            and foreground_after_up == int(hwnd)
            and final_foreground == int(hwnd)
        )
        if down >= 1 and up >= 1 and foreground_before_up == int(hwnd) and foreground_after_up != int(hwnd):
            delivery_classification = "UNCERTAIN_POST_UP_FOCUS_LOSS"
        elif down >= 1 and (foreground_after_down != int(hwnd) or foreground_before_up != int(hwnd)):
            delivery_classification = "UNCERTAIN_MID_CLICK_FOCUS_LOSS"
        elif down >= 1 and up >= 1 and foreground_after_up == int(hwnd) and final_foreground != int(hwnd):
            delivery_classification = "COMPLETE_CLICK_POST_SETTLE_FOCUS_LOSS"
        elif down >= 1 and up < 1:
            delivery_classification = "UNCERTAIN_MOUSE_UP_NOT_SENT"
        else:
            delivery_classification = "CERTAIN_COMPLETE" if complete else "UNCERTAIN_CLICK_TRANSACTION"
        foreground_phases = {
            "before_down": foreground_before_down,
            "after_down": foreground_after_down,
            "before_up": foreground_before_up,
            "after_up": foreground_after_up,
            "after_settle": final_foreground,
        }
        unexpected = {}
        for phase_name, phase_hwnd in foreground_phases.items():
            if phase_hwnd is not None and int(phase_hwnd) != int(hwnd):
                snap = self._window_identity_snapshot(phase_hwnd)
                if snap is not None:
                    unexpected[phase_name] = snap
        self._last_diagnostic.update({
            "transaction_started_monotonic_ms": transaction_started_monotonic_ms,
            "transaction_finished_monotonic_ms": transaction_finished_monotonic_ms,
            "input_delivery": "SPLIT_SENDINPUT",
            "physical_delivery_classification": delivery_classification,
            "mouse_down_count": int(down),
            "mouse_up_count": int(up),
            "sendinput_count": int(down + up),
            "transaction_complete": bool(complete),
            "foreground_before_down": foreground_before_down,
            "foreground_after_down": foreground_after_down,
            "foreground_before_up": foreground_before_up,
            "foreground_after_up": foreground_after_up,
            "foreground_after_settle": final_foreground,
            "foreground_after_transaction": final_foreground,
            "unexpected_foreground_windows": unexpected,
            "target_hwnd": int(hwnd),
            "cursor_moved": True,
            "hover_seconds": hover,
            "mouse_hold_seconds": max(0.0, float(self.mouse_hold_seconds)),
            "post_click_settle_seconds": max(0.0, float(self.post_click_settle_seconds)),
        })
        if complete:
            self._last_diagnostic.update({"status": "SENT", "failure_code": None})
            return PhysicalSendState.SENT
        failure = (
            "INPUT_FOREGROUND_LOST_DURING_CLICK"
            if any(
                value is not None and int(value) != int(hwnd)
                for value in (foreground_after_down, foreground_before_up, foreground_after_up, final_foreground)
            )
            else "INPUT_MOUSE_UP_NOT_SENT"
        )
        self._last_diagnostic.update({"status": "UNCERTAIN", "failure_code": failure})
        return PhysicalSendState.UNCERTAIN

    def click(self, point: ScreenPoint) -> PhysicalSendState:
        hwnd = self._bound_hwnd
        if hwnd is None or self.api.foreground_window() != hwnd:
            self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT","detail":"screen click target is not foreground"})
            self._commit_physical_evidence(boundary="SCREEN_CLICK")
            return PhysicalSendState.NOT_SENT
        transaction = self._split_click_transaction(
            hwnd=int(hwnd), x=int(point.x), y=int(point.y), physical=False, source="screen:generic",
        )
        if transaction is not None:
            self._last_diagnostic.update({
                "input":"SCREEN_CLICK", "screen_point":[int(point.x),int(point.y)],
            })
            self._commit_physical_evidence(boundary="SCREEN_CLICK")
            return transaction
        sent = self.api.click_screen(point.x, point.y)
        self._last_diagnostic.update({
            "input":"SCREEN_CLICK","screen_point":[int(point.x),int(point.y)],
            "sendinput_count":int(sent), "input_delivery": "LEGACY_COMBINED_SENDINPUT",
            "transaction_complete": sent >= 2,
        })
        if sent >= 2:
            self._last_diagnostic.update({"status":"SENT","failure_code":None})
            self._commit_physical_evidence(boundary="SCREEN_CLICK")
            return PhysicalSendState.SENT
        if sent == 1:
            self._last_diagnostic.update({"status":"UNCERTAIN","failure_code":"INPUT_UNCERTAIN"})
            self._commit_physical_evidence(boundary="SCREEN_CLICK")
            return PhysicalSendState.UNCERTAIN
        self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT"})
        self._commit_physical_evidence(boundary="SCREEN_CLICK")
        return PhysicalSendState.NOT_SENT

    def move_client(
        self,
        point: CalibrationPoint,
        *,
        expected_width: int,
        expected_height: int,
    ) -> bool:
        """Move the cursor to a verified reference-client point without clicking."""
        hwnd = self._bound_hwnd
        if hwnd is None or self.api.foreground_window() != hwnd or not point.verified:
            self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT","detail":"client move preconditions failed"})
            self._commit_physical_evidence(boundary="CLIENT_MOVE")
            return False
        try:
            translated = self._translate_reference_client_point(
                hwnd, point, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        except Exception as exc:
            self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT","detail":f"client move translation failed: {type(exc).__name__}: {exc}"})
            self._commit_physical_evidence(boundary="CLIENT_MOVE")
            return False
        if translated is None:
            self._commit_physical_evidence(boundary="CLIENT_MOVE")
            return False
        width, height, screen_x, screen_y, coordinate_profile = translated
        physical = coordinate_profile.get("screen_coordinate_mode") == "PHYSICAL_SCREEN_PIXELS"
        moved = self._move_pointer_to(
            hwnd=int(hwnd), x=int(screen_x), y=int(screen_y), physical=bool(physical),
        )
        self._last_diagnostic.update({
            "input":"CLIENT_MOVE","client_point":[int(point.x),int(point.y)],
            "screen_point":[int(screen_x),int(screen_y)],"cursor_moved":bool(moved),
            "reference_client_size":[int(expected_width),int(expected_height)],
            "actual_client_size":[int(width),int(height)],
        })
        self._commit_physical_evidence(boundary="CLIENT_MOVE")
        return moved

    def activity_nudge_client(
        self,
        *,
        expected_width: int,
        expected_height: int,
        seed: int | None = None,
    ) -> bool:
        """Perform one small non-click cursor nudge inside the bound client.

        R5.159's heartbeat always moved to reference point (32, 32), producing a
        large, repetitive sweep on every active turn. The heartbeat only needs a
        benign physical activity signal, so R5.160 keeps the cursor near its real
        current position and moves a short bounded distance inside the client.
        """
        hwnd = self._bound_hwnd
        if hwnd is None or self.api.foreground_window() != hwnd:
            self._last_diagnostic.update({
                "status": "BLOCKED",
                "failure_code": "INPUT_NOT_SENT",
                "detail": "activity nudge target is not foreground",
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False
        probe = CalibrationPoint(x=0, y=0, verified=True, source="combat:turn_activity_heartbeat")
        try:
            translated = self._translate_reference_client_point(
                int(hwnd), probe, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        except Exception as exc:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_NOT_SENT",
                "detail": f"activity nudge translation failed: {type(exc).__name__}: {exc}",
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False
        if translated is None:
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False
        width, height, origin_x, origin_y, coordinate_profile = translated
        physical = coordinate_profile.get("screen_coordinate_mode") == "PHYSICAL_SCREEN_PIXELS"
        mode = PointerCoordinateMode.PHYSICAL_SCREEN if physical else PointerCoordinateMode.SCREEN
        current = self._pointer_backend.cursor_position(mode)
        if current is None:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_CURSOR_POSITION_UNAVAILABLE",
                "detail": "activity nudge cannot observe the current cursor",
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False
        try:
            if physical and hasattr(self.api, "client_to_physical_screen"):
                end_x, end_y = self.api.client_to_physical_screen(int(hwnd), max(0, int(width) - 1), max(0, int(height) - 1))
            else:
                end_x, end_y = self.api.client_to_screen(int(hwnd), max(0, int(width) - 1), max(0, int(height) - 1))
        except Exception as exc:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "INPUT_CURSOR_MOVE_UNAVAILABLE",
                "detail": f"activity nudge client bounds unavailable: {type(exc).__name__}: {exc}",
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False

        left, right = sorted((int(origin_x), int(end_x)))
        top, bottom = sorted((int(origin_y), int(end_y)))
        margin = max(6, min(18, int(min(max(1, right-left), max(1, bottom-top)) * 0.02)))
        inner_left, inner_right = left + margin, right - margin
        inner_top, inner_bottom = top + margin, bottom - margin
        if inner_left > inner_right or inner_top > inner_bottom:
            self._last_diagnostic.update({
                "status": "BLOCKED", "failure_code": "CLIENT_SIZE_MISMATCH",
                "detail": "activity nudge has no safe client interior",
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False

        actual_seed = int(self._endpoint_selector.seed_source() if seed is None else seed)
        rng = random.Random(actual_seed)
        inside = inner_left <= current.x <= inner_right and inner_top <= current.y <= inner_bottom
        if inside:
            radius = rng.uniform(8.0, 18.0)
            angle = rng.uniform(0.0, 2.0 * math.pi)
            target_x = int(round(current.x + radius * math.cos(angle)))
            target_y = int(round(current.y + radius * math.sin(angle)))
            target_x = min(inner_right, max(inner_left, target_x))
            target_y = min(inner_bottom, max(inner_top, target_y))
            if target_x == current.x and target_y == current.y:
                candidate_x = current.x + (8 if current.x + 8 <= inner_right else -8)
                target_x = min(inner_right, max(inner_left, candidate_x))
        else:
            # A heartbeat is optional liveness assistance, not authorization to
            # reclaim a cursor the user/OS moved outside the bound client.
            # R5.159's fixed-corner strategy could create a long sweep here;
            # R5.160 fails closed instead and lets the fight controller proceed
            # without a heartbeat. Normal semantic actions will later acquire
            # the input lease and move to their own verified targets.
            self._last_diagnostic.update({
                "status": "SKIPPED",
                "failure_code": "HEARTBEAT_CURSOR_OUTSIDE_CLIENT",
                "detail": "activity nudge skipped because the real cursor is outside the bound Dofus client",
                "input": "CLIENT_ACTIVITY_NUDGE",
                "heartbeat_strategy": "RELATIVE_CLIENT_NUDGE_V1",
                "heartbeat_seed": int(actual_seed),
                "heartbeat_cursor_was_inside_client": False,
                "heartbeat_start_screen_point": [int(current.x), int(current.y)],
                "reference_client_size": [int(expected_width), int(expected_height)],
                "actual_client_size": [int(width), int(height)],
            })
            self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
            return False

        moved = self._move_pointer_to(
            hwnd=int(hwnd), x=int(target_x), y=int(target_y), physical=bool(physical),
        )
        self._last_diagnostic.update({
            "input": "CLIENT_ACTIVITY_NUDGE",
            "heartbeat_strategy": "RELATIVE_CLIENT_NUDGE_V1",
            "heartbeat_seed": int(actual_seed),
            "heartbeat_cursor_was_inside_client": bool(inside),
            "heartbeat_start_screen_point": [int(current.x), int(current.y)],
            "heartbeat_target_screen_point": [int(target_x), int(target_y)],
            "heartbeat_nudge_distance_px": round(math.hypot(target_x-current.x, target_y-current.y), 3),
            "reference_client_size": [int(expected_width), int(expected_height)],
            "actual_client_size": [int(width), int(height)],
        })
        self._commit_physical_evidence(boundary="CLIENT_ACTIVITY_NUDGE")
        return bool(moved)

    def click_client_safe(
        self,
        point: CalibrationPoint,
        *,
        safe_points: tuple[CalibrationPoint, ...],
        expected_width: int,
        expected_height: int,
    ) -> PhysicalSendState:
        """Click one caller-certified safe point, biased toward the nominal target.

        No geometry is invented here. When no certified alternatives exist, the
        exact nominal point is used. This keeps UI calibration targets exact while
        allowing bridge-proven cell interiors to vary safely.
        """
        candidates = tuple(
            PointerPosition(x=int(candidate.x), y=int(candidate.y))
            for candidate in safe_points
            if candidate.verified
        )
        if not candidates:
            return self.click_client(
                point, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        nominal = PointerPosition(x=int(point.x), y=int(point.y))
        source_key = str(point.source or "unknown")
        selection = self._endpoint_selector.choose(
            nominal=nominal,
            candidates=candidates,
            previous=self._last_safe_endpoint_by_source.get(source_key),
        )
        selected = CalibrationPoint(
            x=int(selection.selected.x),
            y=int(selection.selected.y),
            verified=True,
            source=point.source,
        )
        state = self.click_client(
            selected, expected_width=int(expected_width), expected_height=int(expected_height),
        )
        self._last_diagnostic.update({
            "semantic_client_point": [int(point.x), int(point.y)],
            "selected_safe_client_point": [int(selected.x), int(selected.y)],
            "safe_endpoint_candidate_count": int(selection.candidate_count),
            "safe_endpoint_seed": int(selection.seed),
            "safe_endpoint_varied": bool(selected.x != point.x or selected.y != point.y),
            "safe_endpoint_repeated_previous": bool(selection.repeated_previous),
        })
        if state is not PhysicalSendState.NOT_SENT:
            self._last_safe_endpoint_by_source[source_key] = selection.selected
        self._commit_physical_evidence(boundary="CLIENT_CLICK_SAFE")
        return state

    def click_client_guarded(
        self,
        point: CalibrationPoint,
        *,
        expected_width: int,
        expected_height: int,
        pre_down_guard: Callable[[dict | None], bool | tuple[bool, dict | None]],
    ) -> PhysicalSendState:
        """Click only if a final caller-owned semantic guard still passes at DOWN."""
        return self.click_client(
            point,
            expected_width=int(expected_width),
            expected_height=int(expected_height),
            _pre_down_guard=pre_down_guard,
        )

    def click_client_safe_guarded(
        self,
        point: CalibrationPoint,
        *,
        safe_points: tuple[CalibrationPoint, ...],
        expected_width: int,
        expected_height: int,
        pre_down_guard: Callable[[dict | None], bool | tuple[bool, dict | None]],
    ) -> PhysicalSendState:
        """Safe-endpoint selection plus the immediate pre-DOWN semantic guard."""
        candidates = tuple(
            PointerPosition(x=int(candidate.x), y=int(candidate.y))
            for candidate in safe_points
            if candidate.verified
        )
        if not candidates:
            return self.click_client_guarded(
                point,
                expected_width=int(expected_width),
                expected_height=int(expected_height),
                pre_down_guard=pre_down_guard,
            )
        nominal = PointerPosition(x=int(point.x), y=int(point.y))
        source_key = str(point.source or "unknown")
        selection = self._endpoint_selector.choose(
            nominal=nominal,
            candidates=candidates,
            previous=self._last_safe_endpoint_by_source.get(source_key),
        )
        selected = CalibrationPoint(
            x=int(selection.selected.x), y=int(selection.selected.y),
            verified=True, source=point.source,
        )
        state = self.click_client_guarded(
            selected,
            expected_width=int(expected_width),
            expected_height=int(expected_height),
            pre_down_guard=pre_down_guard,
        )
        self._last_diagnostic.update({
            "semantic_client_point": [int(point.x), int(point.y)],
            "selected_safe_client_point": [int(selected.x), int(selected.y)],
            "safe_endpoint_candidate_count": int(selection.candidate_count),
            "safe_endpoint_seed": int(selection.seed),
            "safe_endpoint_varied": bool(selected.x != point.x or selected.y != point.y),
            "safe_endpoint_repeated_previous": bool(selection.repeated_previous),
        })
        if state is not PhysicalSendState.NOT_SENT:
            self._last_safe_endpoint_by_source[source_key] = selection.selected
        self._commit_physical_evidence(boundary="CLIENT_CLICK_SAFE_GUARDED")
        return state

    def click_client(
        self,
        point: CalibrationPoint,
        *,
        expected_width: int,
        expected_height: int,
        _pre_down_guard: Callable[[dict | None], bool | tuple[bool, dict | None]] | None = None,
    ) -> PhysicalSendState:
        """Click a verified reference-client point with explicit DPI-safe translation."""
        hwnd = self._bound_hwnd
        if hwnd is None or self.api.foreground_window() != hwnd or not point.verified:
            self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT","detail":"client click preconditions failed"})
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return PhysicalSendState.NOT_SENT
        try:
            translated = self._translate_reference_client_point(
                hwnd, point, expected_width=int(expected_width), expected_height=int(expected_height),
            )
        except Exception as exc:
            self._last_diagnostic.update({
                "status":"BLOCKED","failure_code":"INPUT_NOT_SENT",
                "detail":f"client coordinate translation failed: {type(exc).__name__}: {exc}",
            })
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return PhysicalSendState.NOT_SENT
        if translated is None:
            try:
                width, height = self.api.client_size(hwnd)
            except Exception:
                width, height = 0, 0
            self._last_diagnostic.update({
                "status":"BLOCKED","failure_code":"CLIENT_SIZE_MISMATCH",
                "expected_client_size":[int(expected_width),int(expected_height)],
                "actual_client_size":[int(width),int(height)],
            })
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return PhysicalSendState.NOT_SENT
        width, height, screen_x, screen_y, coordinate_profile = translated
        physical = coordinate_profile.get("screen_coordinate_mode") == "PHYSICAL_SCREEN_PIXELS"
        effective_pre_down_guard = _pre_down_guard
        if _pre_down_guard is not None:
            def effective_pre_down_guard(context=None):
                payload = dict(context or {})
                payload["selected_client_point"] = [int(point.x), int(point.y)]
                payload["reference_client_size"] = [int(expected_width), int(expected_height)]
                payload["actual_client_size"] = [int(width), int(height)]
                try:
                    signature = inspect.signature(_pre_down_guard)
                    accepts_context = bool(signature.parameters)
                except (TypeError, ValueError):
                    accepts_context = True
                return _pre_down_guard(payload) if accepts_context else _pre_down_guard()
        transaction = self._split_click_transaction(
            hwnd=int(hwnd), x=int(screen_x), y=int(screen_y), physical=bool(physical), source=point.source,
            pre_down_guard=effective_pre_down_guard,
        )
        sent = int(self._last_diagnostic.get("sendinput_count", 0)) if transaction is not None else 0
        if transaction is None:
            transaction_started_monotonic_ms = int(time.monotonic() * 1000)
            if hasattr(self.api, "click_physical_screen") and physical:
                sent = self.api.click_physical_screen(screen_x, screen_y)
            else:
                sent = self.api.click_screen(screen_x, screen_y)
            self._last_diagnostic.update({
                "input_delivery": "LEGACY_COMBINED_SENDINPUT",
                "transaction_complete": sent >= 2,
                "transaction_started_monotonic_ms": transaction_started_monotonic_ms,
                "transaction_finished_monotonic_ms": int(time.monotonic() * 1000),
            })
        self._last_diagnostic.update({
            "input":"CLIENT_CLICK",
            "client_point":[int(point.x),int(point.y)],
            "actual_client_point":coordinate_profile.get("actual_client_point"),
            "screen_point":[int(screen_x),int(screen_y)],
            "sendinput_count":int(sent),
            "reference_client_size":[int(expected_width),int(expected_height)],
            "actual_client_size":[int(width),int(height)],
            "coordinate_mode":coordinate_profile.get("coordinate_mode"),
            "screen_coordinate_mode":coordinate_profile.get("screen_coordinate_mode"),
            "reference_to_actual_scale":[coordinate_profile.get("scale_x"),coordinate_profile.get("scale_y")],
            "window_dpi":self.api.window_dpi(hwnd) if hasattr(self.api, "window_dpi") else None,
        })
        if transaction is not None:
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return transaction
        if sent >= 2:
            self._last_diagnostic.update({"status":"SENT","failure_code":None})
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return PhysicalSendState.SENT
        if sent == 1:
            self._last_diagnostic.update({"status":"UNCERTAIN","failure_code":"INPUT_UNCERTAIN"})
            self._commit_physical_evidence(boundary="CLIENT_CLICK")
            return PhysicalSendState.UNCERTAIN
        self._last_diagnostic.update({"status":"BLOCKED","failure_code":"INPUT_NOT_SENT"})
        self._commit_physical_evidence(boundary="CLIENT_CLICK")
        return PhysicalSendState.NOT_SENT


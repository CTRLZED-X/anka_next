from __future__ import annotations

"""Stable runtime-operation contracts behind the single ExecutionService authority.

This module contains no physical input implementation.  It describes how a
public runtime operation maps to an ExecutionService private handler and which
result/request contract rules apply.  Keeping this table out of the giant
service prevents dispatch metadata from being duplicated across callers.
"""

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping


@dataclass(frozen=True, slots=True)
class RuntimeOperationSpec:
    name: str
    handler_name: str
    domain: str
    normalize_combat_result: bool = False
    inject_execution_action_id: bool = False
    mark_correlated_runtime: bool = False


_SPECS = (
    RuntimeOperationSpec("change_map", "_change_map", "WORLD"),
    RuntimeOperationSpec("bootstrap_change_map", "_bootstrap_change_map", "STARTUP"),
    RuntimeOperationSpec("launch_fight", "_launch_fight", "WORLD", inject_execution_action_id=True),
    RuntimeOperationSpec("join_fight", "_join_fight", "FIGHT_ENTRY"),
    RuntimeOperationSpec("place_fighter", "_place_fighter", "FIGHT_PREPARATION"),
    RuntimeOperationSpec("choose_challenge", "_choose_challenge", "FIGHT_PREPARATION"),
    RuntimeOperationSpec("ready_fight", "_ready_fight", "FIGHT_PREPARATION"),
    RuntimeOperationSpec("ready_fight_send", "_ready_fight_send", "FIGHT_PREPARATION"),
    RuntimeOperationSpec("ready_fight_probe", "_ready_fight_probe", "FIGHT_PREPARATION"),
    RuntimeOperationSpec(
        "cast_spell", "_cast_spell", "COMBAT", normalize_combat_result=True,
        mark_correlated_runtime=True,
    ),
    RuntimeOperationSpec("move_fight", "_move_fight", "COMBAT", normalize_combat_result=True),
    RuntimeOperationSpec("end_turn", "_end_turn", "COMBAT", normalize_combat_result=True),
)

RUNTIME_OPERATION_SPECS: Mapping[str, RuntimeOperationSpec] = MappingProxyType(
    {spec.name: spec for spec in _SPECS}
)


def runtime_operation_spec(operation: str) -> RuntimeOperationSpec | None:
    return RUNTIME_OPERATION_SPECS.get(str(operation))


def prepare_handler_request(
    spec: RuntimeOperationSpec,
    request: Mapping[str, object],
    *,
    runtime_context: Mapping[str, object],
    action_id: str,
) -> dict:
    result = dict(request)
    if spec.inject_execution_action_id:
        result["_execution_action_id"] = str(action_id)
    if spec.mark_correlated_runtime:
        result["_correlated_runtime"] = bool(runtime_context)
    return result


def decorate_transaction_observation(result: Mapping[str, object], *, action_id: str) -> dict:
    """Classify physical origin vs passive observations without changing semantics."""
    row = dict(result)
    origin = row.get("origin_action_id")
    if origin is None:
        transaction = row.get("transaction")
        if isinstance(transaction, Mapping):
            origin = transaction.get("origin_action_id")
    if origin is None:
        pending = row.get("pending_transaction")
        if isinstance(pending, Mapping):
            origin = pending.get("origin_action_id")
    if origin:
        origin = str(origin)
        row.setdefault("origin_action_id", origin)
        is_origin = origin == str(action_id)
        row.setdefault("record_kind", "PHYSICAL_ACTION" if is_origin else "TRANSACTION_OBSERVATION")
        row.setdefault("physical_input_event", bool(is_origin))
        row.setdefault("observation_of_action_id", None if is_origin else origin)
    else:
        row.setdefault("record_kind", "ACTION_RESULT")
    return row

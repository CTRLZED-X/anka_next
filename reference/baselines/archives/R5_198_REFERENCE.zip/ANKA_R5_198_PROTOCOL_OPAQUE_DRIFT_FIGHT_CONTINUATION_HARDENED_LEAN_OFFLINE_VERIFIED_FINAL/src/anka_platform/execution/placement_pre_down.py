from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from anka_platform.contracts.common import ValueStatus


@dataclass(slots=True)
class FightPlacementPreDownGuard:
    """Revalidate fight placement after pointer travel but before mouse DOWN.

    Placement selection and smooth pointer travel are separated in time.  This
    guard closes that TOCTOU window without owning physical input: it rechecks
    canonical fight/side/occupancy truth and the exact projection generation.
    """

    snapshot: Callable[[], Any]
    identity_resolver: Callable[[Any, dict], Any]
    projection_resolver: Callable[..., tuple[Any | None, dict | None]]
    payload: dict
    fight_instance_id: int | None
    semantic_map_id: int
    local_actor_id: int
    target_cell_id: int
    original_projection: Any
    block: dict | None = None

    @staticmethod
    def _not_sent_block(code: str, detail: str, **extra: Any) -> dict:
        return {
            "status": "BLOCKED",
            "failure_code": str(code),
            "detail": str(detail),
            "retry_allowed": True,
            "physical_send_state": "NOT_SENT",
            "admission_stage": "PRE_DOWN",
            **extra,
        }

    def _semantic_block(self, current: Any) -> dict | None:
        fight = current.fight
        identity = self.identity_resolver(current, self.payload)
        phase = (
            str(fight.phase.value)
            if fight.phase.status is ValueStatus.KNOWN and fight.phase.value is not None
            else None
        )
        map_id = (
            int(fight.map_id.value)
            if fight.map_id.status is ValueStatus.KNOWN and fight.map_id.value is not None
            else None
        )
        identity_actor = int(identity.actor_id) if getattr(identity, "resolved", False) else None
        if (
            not fight.present
            or fight.fight_instance_id != self.fight_instance_id
            or phase != "PLACEMENT"
            or map_id != int(self.semantic_map_id)
            or identity_actor != int(self.local_actor_id)
        ):
            return self._not_sent_block(
                "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                "fight generation, placement phase, map, or local identity changed during placement pointer travel",
                canonical_revision=int(current.revision),
                fight_instance_id=fight.fight_instance_id,
                fight_phase=phase,
                semantic_fight_map_id=map_id,
                actor_id=identity_actor,
            )

        local = next(
            (actor for actor in fight.actors if int(actor.actor_id) == int(self.local_actor_id)),
            None,
        )
        if local is None or local.cell_id.status is not ValueStatus.KNOWN:
            return self._not_sent_block(
                "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                "local placement CellId is no longer confirmed immediately before mouse DOWN",
                canonical_revision=int(current.revision),
            )
        local_cell = int(local.cell_id.value)
        defender = {int(cell) for cell in fight.legal_placement_defender_cells}
        challenger = {int(cell) for cell in fight.legal_placement_challenger_cells}
        in_defender = local_cell in defender
        in_challenger = local_cell in challenger
        legal = defender if in_defender and not in_challenger else challenger if in_challenger and not in_defender else None
        if legal is None or int(self.target_cell_id) not in legal:
            return self._not_sent_block(
                "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                "local placement side or legal target set changed during placement pointer travel",
                canonical_revision=int(current.revision),
                current_cell_id=local_cell,
                target_cell_id=int(self.target_cell_id),
            )
        occupied = {
            int(actor.cell_id.value)
            for actor in fight.actors
            if int(actor.actor_id) != int(self.local_actor_id)
            and actor.cell_id.status is ValueStatus.KNOWN
        }
        if int(self.target_cell_id) in occupied:
            return self._not_sent_block(
                "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                "target placement CellId became occupied during placement pointer travel",
                canonical_revision=int(current.revision),
                target_cell_id=int(self.target_cell_id),
            )
        return None

    def __call__(self, _delivery_context: dict | None = None):
        current = self.snapshot()
        semantic_block = self._semantic_block(current)
        if semantic_block is not None:
            self.block = semantic_block
            return False, semantic_block

        projection, projection_block = self.projection_resolver(
            int(self.semantic_map_id),
            int(self.target_cell_id),
            purpose="FIGHT_PLACEMENT_CLICK",
            label="fight placement pre-down projection",
        )
        if projection_block is not None or projection is None:
            self.block = dict(projection_block or self._not_sent_block(
                "PROJECTION_STALE",
                "placement projection is unavailable immediately before mouse DOWN",
            ))
            self.block.setdefault("retry_allowed", True)
            self.block.setdefault("physical_send_state", "NOT_SENT")
            self.block.setdefault("admission_stage", "PRE_DOWN")
            return False, self.block

        original = self.original_projection
        projection_changed = bool(
            int(projection.map_revision) != int(original.map_revision)
            or int(projection.runtime_generation) != int(original.runtime_generation)
            or projection.client_point != original.client_point
            or tuple(projection.safe_client_points) != tuple(original.safe_client_points)
            or projection.source_client_width != original.source_client_width
            or projection.source_client_height != original.source_client_height
        )
        if projection_changed:
            self.block = self._not_sent_block(
                "PROJECTION_STALE",
                "placement projection changed during smooth pointer travel",
                target_cell_id=int(self.target_cell_id),
                projection_before={
                    "map_revision": int(original.map_revision),
                    "runtime_generation": int(original.runtime_generation),
                },
                projection_current={
                    "map_revision": int(projection.map_revision),
                    "runtime_generation": int(projection.runtime_generation),
                },
            )
            return False, self.block
        return True, {
            "admission_stage": "PRE_DOWN",
            "canonical_revision": int(current.revision),
            "fight_instance_id": current.fight.fight_instance_id,
            "target_cell_id": int(self.target_cell_id),
        }

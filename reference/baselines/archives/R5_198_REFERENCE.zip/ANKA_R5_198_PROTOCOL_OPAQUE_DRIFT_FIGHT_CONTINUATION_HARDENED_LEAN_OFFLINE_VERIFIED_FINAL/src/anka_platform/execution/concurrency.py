from __future__ import annotations

"""Execution lifecycle diagnostics without creating a second authority.

The tracker never serializes physical input and never authorizes actions. The
per-account ``ExecutionService`` lock and shared ``InputArbiter`` remain the
actual execution serialization authorities. This module only publishes which
phase an operation has reached so a live bundle can distinguish waiting for the
execution lock from handler work and post-action diagnostics.
"""

from contextlib import contextmanager
from dataclasses import dataclass
from enum import StrEnum
from threading import Condition, RLock, get_ident
from time import monotonic, monotonic_ns
from typing import Iterator, Mapping


class ExecutionLifecyclePhase(StrEnum):
    CREATED = "CREATED"
    START_OBSERVABILITY = "START_OBSERVABILITY"
    AUTHORIZATION = "AUTHORIZATION"
    WAITING_EXECUTION_LOCK = "WAITING_EXECUTION_LOCK"
    EXECUTING = "EXECUTING"
    RESULT_OBSERVABILITY = "RESULT_OBSERVABILITY"
    COMPLETED = "COMPLETED"


class ExecutionLifecycleGate:
    """Serialize one account's complete execution lifecycle.

    The gate is broader than the mutable-state lock: it remains owned while
    post-action safety/observability callbacks run, preventing a second action
    from overtaking a critical result before synchronous control fencing has a
    chance to run.  It does not authorize input and it never replaces the
    shared cross-account :class:`InputArbiter`.

    Same-thread re-entry is rejected explicitly instead of deadlocking.
    """

    def __init__(self, *, max_wait_seconds: float | None = 60.0) -> None:
        self._condition = Condition(RLock())
        self._owner_thread: int | None = None
        self._owner_operation: str | None = None
        self._owner_started_monotonic_ns: int | None = None
        self._waiter_count = 0
        self._handoff_sequence = 0
        self._max_wait_seconds = None if max_wait_seconds is None else max(0.0, float(max_wait_seconds))

    @contextmanager
    def lease(self, operation: str) -> Iterator[None]:
        thread_id = get_ident()
        name = str(operation)
        with self._condition:
            if self._owner_thread == thread_id:
                raise RuntimeError(
                    f"execution lifecycle re-entry is forbidden while {self._owner_operation!r} is active"
                )
            self._waiter_count += 1
            started_wait = monotonic()
            try:
                while self._owner_thread is not None:
                    if self._max_wait_seconds is None:
                        self._condition.wait()
                        continue
                    remaining = self._max_wait_seconds - (monotonic() - started_wait)
                    if remaining <= 0:
                        owner_age_ms = None
                        if self._owner_started_monotonic_ns is not None:
                            owner_age_ms = max(
                                0.0,
                                (monotonic_ns() - self._owner_started_monotonic_ns) / 1_000_000.0,
                            )
                        raise RuntimeError(
                            "execution lifecycle owner appears stuck; refusing to steal lease "
                            f"owner_thread={self._owner_thread} owner_operation={self._owner_operation!r} "
                            f"owner_age_ms={owner_age_ms}"
                        )
                    self._condition.wait(timeout=remaining)
                self._owner_thread = thread_id
                self._owner_operation = name
                self._owner_started_monotonic_ns = monotonic_ns()
                self._handoff_sequence += 1
            finally:
                self._waiter_count = max(0, self._waiter_count - 1)
        try:
            yield
        finally:
            with self._condition:
                if self._owner_thread == thread_id:
                    self._owner_thread = None
                    self._owner_operation = None
                    self._owner_started_monotonic_ns = None
                    self._condition.notify_all()

    def snapshot(self) -> dict[str, object]:
        with self._condition:
            owner_age_ms = None
            if self._owner_started_monotonic_ns is not None:
                owner_age_ms = max(0.0, (monotonic_ns() - self._owner_started_monotonic_ns) / 1_000_000.0)
            return {
                "owner_thread": self._owner_thread,
                "owner_operation": self._owner_operation,
                "owner_started_monotonic_ns": self._owner_started_monotonic_ns,
                "owner_age_ms": owner_age_ms,
                "waiter_count": int(self._waiter_count),
                "handoff_sequence": int(self._handoff_sequence),
                "max_wait_seconds": self._max_wait_seconds,
                "authority": "SERIALIZATION_ONLY",
            }


@dataclass(frozen=True, slots=True)
class ActiveExecutionOperation:
    sequence: int
    operation: str
    action_id: str
    account_id: str
    thread_id: int
    started_monotonic_ns: int
    run_id: str | None = None
    request_id: str | None = None

    def as_dict(self) -> dict[str, object]:
        return {
            "sequence": self.sequence,
            "operation": self.operation,
            "action_id": self.action_id,
            "account_id": self.account_id,
            "thread_id": self.thread_id,
            "started_monotonic_ns": self.started_monotonic_ns,
            "run_id": self.run_id,
            "request_id": self.request_id,
        }


class ExecutionOperationTracker:
    def __init__(self) -> None:
        self._lock = RLock()
        self._sequence = 0
        self._active: ActiveExecutionOperation | None = None
        self._active_phase = ExecutionLifecyclePhase.CREATED
        self._phase_history: list[dict[str, object]] = []
        self._last_completed: dict[str, object] | None = None

    @contextmanager
    def track(
        self,
        *,
        operation: str,
        action_id: str,
        account_id: str,
        runtime_context: Mapping[str, object] | None = None,
    ) -> Iterator[ActiveExecutionOperation]:
        runtime = dict(runtime_context or {})
        with self._lock:
            self._sequence += 1
            active = ActiveExecutionOperation(
                sequence=self._sequence,
                operation=str(operation),
                action_id=str(action_id),
                account_id=str(account_id),
                thread_id=get_ident(),
                started_monotonic_ns=monotonic_ns(),
                run_id=str(runtime.get("run_id")) if runtime.get("run_id") is not None else None,
                request_id=str(runtime.get("request_id")) if runtime.get("request_id") is not None else None,
            )
            self._active = active
            self._active_phase = ExecutionLifecyclePhase.CREATED
            self._phase_history = [{
                "phase": ExecutionLifecyclePhase.CREATED.value,
                "monotonic_ns": active.started_monotonic_ns,
            }]
        try:
            yield active
        finally:
            finished = monotonic_ns()
            with self._lock:
                # A different sequence can only appear through programmer error;
                # never erase newer evidence if that ever happens.
                if self._active is not None and self._active.sequence == active.sequence:
                    self._append_phase_locked(ExecutionLifecyclePhase.COMPLETED, finished)
                    self._last_completed = {
                        **active.as_dict(),
                        "phase": ExecutionLifecyclePhase.COMPLETED.value,
                        "phase_history": tuple(dict(row) for row in self._phase_history),
                        "finished_monotonic_ns": finished,
                        "duration_ms": max(0.0, (finished - active.started_monotonic_ns) / 1_000_000.0),
                    }
                    self._active = None
                    self._active_phase = ExecutionLifecyclePhase.COMPLETED
                    self._phase_history = []

    def transition(self, sequence: int, phase: ExecutionLifecyclePhase | str) -> None:
        """Publish a diagnostic phase transition for the current operation.

        A stale sequence is ignored rather than mutating evidence for a newer
        operation. This method never acquires execution/input authority.
        """
        normalized = phase if isinstance(phase, ExecutionLifecyclePhase) else ExecutionLifecyclePhase(str(phase))
        now = monotonic_ns()
        with self._lock:
            if self._active is None or self._active.sequence != int(sequence):
                return
            if self._active_phase is normalized:
                return
            self._append_phase_locked(normalized, now)

    def _append_phase_locked(self, phase: ExecutionLifecyclePhase, when_ns: int) -> None:
        self._active_phase = phase
        self._phase_history.append({"phase": phase.value, "monotonic_ns": int(when_ns)})

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            active = self._active.as_dict() if self._active is not None else None
            if active is not None:
                active = {
                    **active,
                    "phase": self._active_phase.value,
                    "phase_history": tuple(dict(row) for row in self._phase_history),
                }
            return {
                "schema_version": 2,
                "active": active,
                "last_completed": dict(self._last_completed) if self._last_completed is not None else None,
                "sequence": self._sequence,
                "authority": "DIAGNOSTIC_ONLY",
            }

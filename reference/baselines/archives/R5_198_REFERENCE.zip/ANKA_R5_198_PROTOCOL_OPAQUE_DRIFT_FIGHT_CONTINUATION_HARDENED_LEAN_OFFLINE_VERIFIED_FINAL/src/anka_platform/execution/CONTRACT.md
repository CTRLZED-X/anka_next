# Execution Contract

Execution is the only physical-action authority. It owns account/window routing, projection use, input safety, settlement and confirmation.

Callers submit semantic operations. They must not click, focus windows or retry uncertain physical actions themselves. Uncertain or conflicting outcomes remain fail-closed until authoritative settlement/progress exists.

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import StrEnum

from anka_game_kernel.domain.ids import CellId, MapId
from anka_platform.integration.action_feasibility import (
    ActionFeasibilityStatus,
    KernelActionFeasibilityService,
)
from anka_platform.integration.kernel_context import KernelContextAdapter, KernelContextUnavailable
from anka_platform.integration.fight_geometry import fight_context_map_definition
from anka_platform.integration.client_interaction import (
    SpellTargetInteractionStatus,
    evaluate_spell_target_interaction_admissibility,
)
from anka_platform.integration.live_spell_readiness import (
    LiveSpellReadinessService,
    LiveSpellReadinessStatus,
)
from anka_platform.integration.safe_cast_probe import (
    assumptions_match,
    prepare_safe_probe_snapshot,
)


class FightActionAdmissionStatus(StrEnum):
    ADMITTED = "ADMITTED"
    REJECTED = "REJECTED"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True, slots=True)
class FightActionAdmissionResult:
    status: FightActionAdmissionStatus
    reason: str
    basis_revision: int
    readiness: dict
    kernel_legal: bool | None = None
    kernel_certainty: str | None = None
    kernel_missing_inputs: tuple[str, ...] = ()
    tactical_target_actor_id: int | None = None
    tactical_target_cell_id: int | None = None
    tactical_target_affected: bool | None = None
    tactical_target_effect_orders: tuple[int, ...] = ()
    admission_mode: str = "STRICT"
    probe_assumptions: tuple[str, ...] = ()
    strict_status: str | None = None
    strict_reason: str | None = None
    client_interaction: dict | None = None

    @property
    def admitted(self) -> bool:
        return self.status is FightActionAdmissionStatus.ADMITTED

    def as_dict(self) -> dict:
        return {
            "status": self.status.value,
            "reason": self.reason,
            "basis_revision": int(self.basis_revision),
            "readiness": dict(self.readiness),
            "kernel_legal": self.kernel_legal,
            "kernel_certainty": self.kernel_certainty,
            "kernel_missing_inputs": list(self.kernel_missing_inputs),
            "tactical_target_actor_id": self.tactical_target_actor_id,
            "tactical_target_cell_id": self.tactical_target_cell_id,
            "tactical_target_affected": self.tactical_target_affected,
            "tactical_target_effect_orders": list(self.tactical_target_effect_orders),
            "admission_mode": str(self.admission_mode),
            "probe_assumptions": list(self.probe_assumptions),
            "strict_status": self.strict_status,
            "strict_reason": self.strict_reason,
            "client_interaction": (dict(self.client_interaction) if self.client_interaction is not None else None),
        }


@dataclass(frozen=True, slots=True)
class FightActionAdmissionService:
    kernel: object

    def admit_cast(
        self,
        snapshot,
        *,
        actor_id: int,
        spell_id: int,
        grade: int,
        target_cell_id: int,
        target_actor_id: int | None = None,
        action_intent=None,
        admission_mode: str = "STRICT",
        probe_assumptions: tuple[str, ...] = (),
    ) -> FightActionAdmissionResult:
        """Admit a CAST, optionally using a narrowly bounded client-validation probe.

        Safe-probe mode can only resolve a STRICT ``UNKNOWN``. It can never
        override a strict rejection. The latest Canonical snapshot is copied and
        only allowlisted assumptions are injected; the same normal readiness and
        Kernel feasibility checks then run again.
        """
        strict = self._admit_cast_strict(
            snapshot, actor_id=actor_id, spell_id=spell_id, grade=grade,
            target_cell_id=target_cell_id, target_actor_id=target_actor_id,
            action_intent=action_intent,
        )
        mode = str(admission_mode or "STRICT").strip().upper()
        if mode != "CLIENT_VALIDATE_SAFE_PROBE" or strict.status is not FightActionAdmissionStatus.UNKNOWN:
            return strict

        prepared = prepare_safe_probe_snapshot(
            kernel=self.kernel, snapshot=snapshot, actor_id=actor_id,
            spell_id=spell_id, grade=grade,
        )
        if prepared is None:
            return replace(
                strict, admission_mode="CLIENT_VALIDATE_SAFE_PROBE",
                strict_status=strict.status.value, strict_reason=strict.reason,
            )
        if not assumptions_match(probe_assumptions, prepared.assumptions):
            return FightActionAdmissionResult(
                FightActionAdmissionStatus.UNKNOWN,
                "SAFE_PROBE_ASSUMPTION_MISMATCH", int(snapshot.revision),
                strict.readiness, kernel_legal=None,
                kernel_certainty=strict.kernel_certainty,
                kernel_missing_inputs=strict.kernel_missing_inputs,
                admission_mode="CLIENT_VALIDATE_SAFE_PROBE",
                probe_assumptions=prepared.assumptions,
                strict_status=strict.status.value, strict_reason=strict.reason,
            )

        probed = self._admit_cast_strict(
            prepared.snapshot, actor_id=actor_id, spell_id=spell_id, grade=grade,
            target_cell_id=target_cell_id, target_actor_id=target_actor_id,
            action_intent=action_intent,
        )
        prefix = (
            "SAFE_PROBE_ADMITTED" if probed.status is FightActionAdmissionStatus.ADMITTED
            else "SAFE_PROBE_REJECTED" if probed.status is FightActionAdmissionStatus.REJECTED
            else "SAFE_PROBE_STILL_UNKNOWN"
        )
        return replace(
            probed, reason=f"{prefix}:{probed.reason}",
            admission_mode="CLIENT_VALIDATE_SAFE_PROBE",
            probe_assumptions=prepared.assumptions,
            strict_status=strict.status.value, strict_reason=strict.reason,
        )

    def _admit_cast_strict(
        self,
        snapshot,
        *,
        actor_id: int,
        spell_id: int,
        grade: int,
        target_cell_id: int,
        target_actor_id: int | None = None,
        action_intent=None,
    ) -> FightActionAdmissionResult:
        readiness = LiveSpellReadinessService(self.kernel).evaluate(
            snapshot,
            actor_id=int(actor_id),
            spell_id=int(spell_id),
            grade=int(grade),
            target_cell_id=int(target_cell_id),
            target_actor_id=(int(target_actor_id) if target_actor_id is not None else None),
        )
        if readiness.status is LiveSpellReadinessStatus.REJECTED:
            return FightActionAdmissionResult(
                FightActionAdmissionStatus.REJECTED,
                f"SPELL_READINESS:{readiness.reason}",
                int(snapshot.revision),
                readiness.as_dict(),
            )
        if readiness.status is LiveSpellReadinessStatus.UNKNOWN:
            return FightActionAdmissionResult(
                FightActionAdmissionStatus.UNKNOWN,
                f"SPELL_READINESS:{readiness.reason}",
                int(snapshot.revision),
                readiness.as_dict(),
            )
        try:
            context = KernelContextAdapter(self.kernel).fight_context(
                snapshot,
                spell_grade_overrides={(int(actor_id), int(spell_id)): int(grade)},
            )
            fight = snapshot.fight
            if fight.map_id.value is None:
                raise KernelContextUnavailable("fight map is not known")
            map_definition = fight_context_map_definition(
                self.kernel, context, fallback_semantic_map_id=int(fight.map_id.value)
            )
            feasibility = KernelActionFeasibilityService(self.kernel).evaluate_cast(
                context=context,
                map_definition=map_definition,
                actor_id=int(actor_id),
                spell_id=int(spell_id),
                grade=int(grade),
                target_cell_id=int(target_cell_id),
                target_actor_id=(int(target_actor_id) if target_actor_id is not None else None),
                action_intent=action_intent,
            )
        except Exception as exc:
            return FightActionAdmissionResult(
                FightActionAdmissionStatus.UNKNOWN,
                f"KERNEL_ADMISSION_UNAVAILABLE:{type(exc).__name__}:{exc}",
                int(snapshot.revision),
                readiness.as_dict(),
            )

        status = {
            ActionFeasibilityStatus.LEGAL: FightActionAdmissionStatus.ADMITTED,
            ActionFeasibilityStatus.ILLEGAL: FightActionAdmissionStatus.REJECTED,
            ActionFeasibilityStatus.UNKNOWN: FightActionAdmissionStatus.UNKNOWN,
        }[feasibility.status]
        interaction = None
        reason = "CAST_ADMITTED" if status is FightActionAdmissionStatus.ADMITTED else feasibility.reason
        if status is FightActionAdmissionStatus.ADMITTED:
            # Client interaction admissibility is a mandatory second boundary after
            # deterministic Kernel mechanics.  Never silently skip it because a
            # custom/test kernel omitted fight_queries: the shared evaluator then
            # returns UNKNOWN and admission fails closed before physical input.
            interaction = evaluate_spell_target_interaction_admissibility(
                kernel=self.kernel, map_definition=map_definition, context=context,
                target_cell=CellId(int(target_cell_id)),
            )
            if interaction.status is SpellTargetInteractionStatus.REJECTED:
                status = FightActionAdmissionStatus.REJECTED
                reason = f"CLIENT_INTERACTION:{interaction.reason}"
            elif interaction.status is SpellTargetInteractionStatus.UNKNOWN:
                status = FightActionAdmissionStatus.UNKNOWN
                reason = f"CLIENT_INTERACTION:{interaction.reason}"
        return FightActionAdmissionResult(
            status,
            reason,
            int(snapshot.revision),
            readiness.as_dict(),
            kernel_legal=(
                True if feasibility.status is ActionFeasibilityStatus.LEGAL
                else False if feasibility.status is ActionFeasibilityStatus.ILLEGAL
                else None
            ),
            kernel_certainty=feasibility.certainty,
            kernel_missing_inputs=feasibility.missing_inputs,
            tactical_target_actor_id=feasibility.tactical_target_actor_id,
            tactical_target_cell_id=feasibility.tactical_target_cell_id,
            tactical_target_affected=feasibility.tactical_target_affected,
            tactical_target_effect_orders=feasibility.tactical_target_effect_orders,
            client_interaction=(interaction.as_dict() if interaction is not None else None),
        )

    def admit_move(
        self,
        snapshot,
        *,
        actor_id: int,
        target_cell_id: int,
    ) -> FightActionAdmissionResult:
        """Kernel-certify one fight MOVE against the supplied semantic snapshot."""
        readiness = {"status": "NOT_APPLICABLE", "kind": "MOVE"}
        try:
            context = KernelContextAdapter(self.kernel).fight_context(snapshot)
            if context.map_id is None:
                raise KernelContextUnavailable("fight map is not known")
            fight = snapshot.fight
            semantic_map_id = getattr(getattr(fight, "map_id", None), "value", None)
            map_definition = fight_context_map_definition(
                self.kernel, context,
                fallback_semantic_map_id=(int(semantic_map_id) if semantic_map_id is not None else None),
            )
            feasibility = KernelActionFeasibilityService(self.kernel).evaluate_move(
                context=context,
                map_definition=map_definition,
                actor_id=int(actor_id),
                target_cell_id=int(target_cell_id),
            )
        except Exception as exc:
            return FightActionAdmissionResult(
                FightActionAdmissionStatus.UNKNOWN,
                f"KERNEL_MOVE_ADMISSION_UNAVAILABLE:{type(exc).__name__}:{exc}",
                int(snapshot.revision),
                readiness,
            )
        projection = feasibility.kernel_result
        movement = getattr(projection, "movement", None)
        path = tuple(int(item) for item in getattr(movement, "path", ()) or ())
        step_count = getattr(movement, "step_count", None)
        readiness = {
            "status": "EVALUATED",
            "kind": "MOVE",
            "path": list(path),
            "step_count": (None if step_count is None else int(step_count)),
            "projection_complete": bool(feasibility.projection_complete),
        }
        status = {
            ActionFeasibilityStatus.LEGAL: FightActionAdmissionStatus.ADMITTED,
            ActionFeasibilityStatus.ILLEGAL: FightActionAdmissionStatus.REJECTED,
            ActionFeasibilityStatus.UNKNOWN: FightActionAdmissionStatus.UNKNOWN,
        }[feasibility.status]
        return FightActionAdmissionResult(
            status,
            "MOVE_ADMITTED" if status is FightActionAdmissionStatus.ADMITTED else feasibility.reason,
            int(snapshot.revision),
            readiness,
            kernel_legal=(
                True if feasibility.status is ActionFeasibilityStatus.LEGAL
                else False if feasibility.status is ActionFeasibilityStatus.ILLEGAL
                else None
            ),
            kernel_certainty=feasibility.certainty,
            kernel_missing_inputs=feasibility.missing_inputs,
        )


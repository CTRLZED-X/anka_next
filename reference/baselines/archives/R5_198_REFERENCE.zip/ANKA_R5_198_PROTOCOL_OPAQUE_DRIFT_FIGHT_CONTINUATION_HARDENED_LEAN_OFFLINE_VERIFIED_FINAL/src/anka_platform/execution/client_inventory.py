from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re
from typing import Mapping, Any

from anka_platform.execution.windows import WindowInputApi


@dataclass(frozen=True, slots=True)
class DiscoveredDofusClient:
    hwnd: int
    pid: int
    process_creation_time: int
    client_instance_id: str
    title: str
    matched_account_id: str | None = None

    def to_dict(self) -> dict:
        return {
            "hwnd": self.hwnd,
            "pid": self.pid,
            "process_creation_time": self.process_creation_time,
            "client_instance_id": self.client_instance_id,
            "title": self.title,
            "matched_account_id": self.matched_account_id,
        }


class DofusClientInventory:
    """Read-only inventory of exact visible Dofus client generations.

    Discovery never focuses, clicks, restores, or otherwise mutates a window.
    """

    def __init__(self, api: WindowInputApi, *, title_token: str = "Dofus") -> None:
        self.api = api
        self.title_token = str(title_token).strip().casefold()


    @staticmethod
    def _looks_like_dofus_title(title_text: str) -> bool:
        folded = str(title_text).strip().casefold()
        if not folded:
            return False
        if any(token in folded for token in ("file explorer", "visual studio code", "notepad", "powershell", "command prompt", "windows terminal")):
            return False
        if folded.startswith("dofus ") or folded == "dofus":
            return True
        if " - dofus" in folded:
            return True
        # Modern client titles can be "Character - Class - 3.6.11.15 - Release"
        # without the literal Dofus token. Unknown-account onboarding may still
        # surface those, but ordinary Explorer/project titles must not.
        return bool(re.search(r"\b\d+\.\d+\.\d+\.\d+\b", folded) and "release" in folded)

    @staticmethod
    def _known_fields(value: Any) -> tuple[str, str]:
        if isinstance(value, Mapping):
            return str(value.get("character_name") or ""), str(value.get("window_title_contains") or "")
        return str(getattr(value, "character_name", "")), str(getattr(value, "window_title_contains", ""))

    def snapshot(self, known_profiles: Mapping[str, Any] | None = None) -> tuple[DiscoveredDofusClient, ...]:
        known_profiles = known_profiles or {}
        result: list[DiscoveredDofusClient] = []
        for hwnd, title in self.api.visible_windows():
            title_text = str(title).strip()
            matches_known = []
            for account_id, profile in known_profiles.items():
                character, token = self._known_fields(profile)
                if (token and token.casefold() in title_text.casefold()) or (character and character.casefold() in title_text.casefold()):
                    matches_known.append(str(account_id))
            if not matches_known and not self._looks_like_dofus_title(title_text):
                continue
            try:
                pid = int(self.api.window_process_id(int(hwnd)))
                created = int(self.api.process_creation_time(pid))
            except Exception:
                continue
            raw = f"{int(hwnd)}:{pid}:{created}".encode("utf-8")
            result.append(DiscoveredDofusClient(
                hwnd=int(hwnd), pid=pid, process_creation_time=created,
                client_instance_id="win-" + hashlib.sha256(raw).hexdigest()[:32],
                title=title_text,
                matched_account_id=(matches_known[0] if len(matches_known) == 1 else None),
            ))
        return tuple(sorted(result, key=lambda item: (item.title.casefold(), item.hwnd)))

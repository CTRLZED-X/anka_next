from __future__ import annotations

from anka_platform.control_correlation import invoke_correlated_activation
from anka_platform.contracts.correlation import CorrelationContext, correlation_mapping

from enum import Enum
from typing import Mapping, Any


class SemanticOperation(str, Enum):
    CHANGE_MAP = "change_map"
    LAUNCH_FIGHT = "launch_fight"
    JOIN_FIGHT = "join_fight"
    PLACE = "place_fighter"
    CHOOSE_CHALLENGE = "choose_challenge"
    READY = "ready_fight"
    READY_SEND = "ready_fight_send"
    CAST = "cast_spell"
    FIGHT_MOVE = "move_fight"
    END_TURN = "end_turn"


class ExecutionCoordinator:
    """Single semantic execution boundary over proven per-account executors.

    This class intentionally delegates to the existing lane execution services;
    it does not alter projection, input, confirmation or settlement behavior.
    """

    def __init__(self, *, party=None, fallback_handler=None, window_control=None) -> None:
        self.party = party
        self.fallback_handler = fallback_handler
        self.window_control = window_control

    @staticmethod
    def _normalize(operation: SemanticOperation | str) -> SemanticOperation:
        if isinstance(operation, SemanticOperation):
            return operation
        try:
            return SemanticOperation(str(operation))
        except ValueError as exc:
            raise ValueError(f"unsupported semantic operation: {operation}") from exc

    def _handler_for(self, account_id: str | None):
        if account_id is not None and self.party is not None:
            lane = self.party.require(str(account_id))
            return lane.handle_action
        if self.fallback_handler is not None:
            return self.fallback_handler
        raise RuntimeError("execution authority unavailable")

    def execute(
        self,
        account_id: str | None,
        operation: SemanticOperation | str,
        payload: Mapping[str, Any],
        *,
        correlation: Mapping[str, Any] | CorrelationContext | None = None,
    ) -> dict:
        semantic = self._normalize(operation)
        request = dict(payload)
        normalized_correlation = correlation_mapping(correlation)
        if normalized_correlation:
            request["_runtime"] = normalized_correlation
        result = self._handler_for(account_id)(semantic.value, request)
        return dict(result)

    def activate(self, account_id: str, *, correlation: Mapping[str, Any] | CorrelationContext | None = None) -> dict:
        if self.window_control is not None:
            return dict(self.window_control.activate(str(account_id), correlation=correlation_mapping(correlation)))
        if self.party is None:
            raise RuntimeError("window activation requires party runtime")
        lane = self.party.require(str(account_id))
        activate = getattr(lane.execution, "activate_window", None)
        if not callable(activate):
            raise RuntimeError(f"window activation unavailable for account: {account_id}")
        
        return invoke_correlated_activation(
            activate, runtime_context=correlation_mapping(correlation)
        )

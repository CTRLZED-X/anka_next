from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Mapping, Any

from anka_platform.control_correlation import invoke_correlated_activation
from anka_platform.contracts.correlation import CorrelationContext, correlation_mapping


class WindowControlFacade:
    """Account-aware window-control boundary over the proven execution lanes.

    It intentionally delegates activation/identity behavior to the existing
    per-account execution/input stack.  No Win32 or click semantics live here.
    """

    def __init__(self, party) -> None:
        self.party = party

    def activate(self, account_id: str, *, correlation: Mapping[str, Any] | CorrelationContext | None = None) -> dict:
        if self.party is None:
            raise RuntimeError("window activation requires party runtime")
        lane = self.party.require(str(account_id))
        activate = getattr(lane.execution, "activate_window", None)
        if not callable(activate):
            raise RuntimeError(f"window activation unavailable for account: {account_id}")
        
        return invoke_correlated_activation(
            activate, runtime_context=correlation_mapping(correlation)
        )

    def identity(self, account_id: str) -> dict | None:
        if self.party is None:
            return None
        lane = self.party.require(str(account_id))
        input_driver = getattr(lane.execution, "input", None)
        identity = getattr(input_driver, "identity", None)
        if not callable(identity):
            return None
        value = identity()
        if value is None:
            return None
        if is_dataclass(value):
            return dict(asdict(value))
        if hasattr(value, "__dict__"):
            return dict(value.__dict__)
        return {"value": str(value)}

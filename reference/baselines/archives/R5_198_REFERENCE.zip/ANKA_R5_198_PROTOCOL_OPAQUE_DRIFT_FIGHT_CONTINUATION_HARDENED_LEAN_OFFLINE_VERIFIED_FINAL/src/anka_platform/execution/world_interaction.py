from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from enum import Enum
from typing import Any
from uuid import uuid4


class SemanticRequestState(str, Enum):
    """Evidence state for the client-side semantic request after physical input."""

    UNKNOWN = "UNKNOWN"
    ABSENT = "ABSENT"
    OBSERVED = "OBSERVED"


class WorldInteractionDisposition(str, Enum):
    """What the execution owner is allowed to do next for one interaction."""

    WAIT = "WAIT"
    RETRY = "RETRY"
    CONFIRMED = "CONFIRMED"
    FAILED = "FAILED"
    UNCERTAIN = "UNCERTAIN"


@dataclass(frozen=True, slots=True)
class PendingWorldInteraction:
    """Generation-scoped physical world interaction receipt.

    This object deliberately separates *mouse delivery* from *Dofus semantic
    acceptance*.  A duplicate click is safe only after bounded protocol evidence
    proves that the first click emitted no certified request.
    """

    operation: str
    map_id: int
    entity_id: int
    cell_id: int
    selected_revision: int
    attempt_index: int
    transaction_id: str
    origin_action_id: str | None
    sent_after_monotonic_ms: int
    client_instance_id: str | None
    created_monotonic_ms: int
    input_evidence: dict[str, Any] | None = None
    observability_session_id: str | None = None
    semantic_state: SemanticRequestState = SemanticRequestState.UNKNOWN
    semantic_kind: str | None = None
    semantic_evidence: dict[str, Any] | None = None
    protocol_window_evidence: dict[str, Any] | None = None
    capture_coverage_evidence: dict[str, Any] | None = None
    request_observed_monotonic_ms: int | None = None
    last_observed_monotonic_ms: int | None = None
    target_observation_count: int = 0
    target_observations: tuple[dict[str, Any], ...] = ()

    @property
    def logical_key(self) -> tuple[str, int, int]:
        return (str(self.operation), int(self.map_id), int(self.entity_id))

    def with_observation(
        self,
        *,
        now_monotonic_ms: int,
        state: SemanticRequestState,
        kind: str | None = None,
        evidence: dict[str, Any] | None = None,
        protocol_window_evidence: dict[str, Any] | None = None,
    ) -> "PendingWorldInteraction":
        # Positive semantic evidence is monotonic. A later bounded-journal query
        # must never erase proof that Dofus already accepted the interaction.
        if self.semantic_state is SemanticRequestState.OBSERVED:
            return replace(self, last_observed_monotonic_ms=int(now_monotonic_ms))
        observed_at = self.request_observed_monotonic_ms
        if state is SemanticRequestState.OBSERVED and observed_at is None:
            observed_at = int(now_monotonic_ms)
        return replace(
            self,
            semantic_state=state,
            semantic_kind=(kind if state is SemanticRequestState.OBSERVED else self.semantic_kind),
            semantic_evidence=(dict(evidence) if isinstance(evidence, dict) else self.semantic_evidence),
            protocol_window_evidence=(
                dict(protocol_window_evidence)
                if isinstance(protocol_window_evidence, dict)
                else self.protocol_window_evidence
            ),
            request_observed_monotonic_ms=observed_at,
            last_observed_monotonic_ms=int(now_monotonic_ms),
        )

    def with_capture_coverage(self, evidence: dict[str, Any] | None) -> "PendingWorldInteraction":
        return replace(
            self,
            capture_coverage_evidence=(dict(evidence) if isinstance(evidence, dict) else self.capture_coverage_evidence),
        )

    def with_target_observation(self, observation: dict[str, Any]) -> "PendingWorldInteraction":
        """Keep a compact evolution trace without turning safety state into a log.

        Canonical revisions can advance for unrelated reasons while a monster group
        remains physically unchanged.  Consecutive observations with the same
        meaningful target state therefore replace the tail record; actual target
        changes append a new record.  The history is bounded so a long settlement
        cannot grow durable state without limit.
        """
        item = dict(observation)
        signature_keys = (
            "fight_present", "world_map_id", "monster_groups_complete",
            "group_present", "group_cell_id",
        )
        history = list(self.target_observations)
        if history and all(history[-1].get(key) == item.get(key) for key in signature_keys):
            history[-1] = item
        else:
            history.append(item)
            if len(history) > 12:
                history = history[-12:]
        return replace(
            self,
            target_observation_count=int(self.target_observation_count) + 1,
            target_observations=tuple(history),
        )

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["semantic_state"] = self.semantic_state.value
        payload["logical_key"] = list(self.logical_key)
        return payload

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "PendingWorldInteraction":
        return cls(
            operation=str(raw["operation"]),
            map_id=int(raw["map_id"]),
            entity_id=int(raw["entity_id"]),
            cell_id=int(raw["cell_id"]),
            selected_revision=int(raw["selected_revision"]),
            attempt_index=max(1, int(raw.get("attempt_index") or 1)),
            transaction_id=str(raw.get("transaction_id") or f"legacy-{raw.get('operation')}-{raw.get('map_id')}-{raw.get('entity_id')}-{raw.get('sent_after_monotonic_ms') }"),
            origin_action_id=(str(raw["origin_action_id"]) if raw.get("origin_action_id") else None),
            sent_after_monotonic_ms=int(raw["sent_after_monotonic_ms"]),
            client_instance_id=(str(raw["client_instance_id"]) if raw.get("client_instance_id") else None),
            created_monotonic_ms=int(raw.get("created_monotonic_ms") or raw["sent_after_monotonic_ms"]),
            input_evidence=(dict(raw.get("input_evidence")) if isinstance(raw.get("input_evidence"), dict) else None),
            observability_session_id=(
                str(raw["observability_session_id"]) if raw.get("observability_session_id") else None
            ),
            semantic_state=SemanticRequestState(str(raw.get("semantic_state") or SemanticRequestState.UNKNOWN.value)),
            semantic_kind=(str(raw["semantic_kind"]) if raw.get("semantic_kind") is not None else None),
            semantic_evidence=(dict(raw.get("semantic_evidence")) if isinstance(raw.get("semantic_evidence"), dict) else None),
            protocol_window_evidence=(
                dict(raw.get("protocol_window_evidence"))
                if isinstance(raw.get("protocol_window_evidence"), dict) else None
            ),
            capture_coverage_evidence=(
                dict(raw.get("capture_coverage_evidence"))
                if isinstance(raw.get("capture_coverage_evidence"), dict) else None
            ),
            request_observed_monotonic_ms=(
                int(raw["request_observed_monotonic_ms"])
                if raw.get("request_observed_monotonic_ms") is not None else None
            ),
            last_observed_monotonic_ms=(
                int(raw["last_observed_monotonic_ms"])
                if raw.get("last_observed_monotonic_ms") is not None else None
            ),
            target_observation_count=max(0, int(raw.get("target_observation_count") or 0)),
            target_observations=tuple(
                dict(item) for item in (raw.get("target_observations") or ()) if isinstance(item, dict)
            )[-12:],
        )


class WorldInteractionLedger:
    """Bounded in-memory ledger for world interactions that may safely retry."""

    def __init__(self, *, max_physical_attempts: int = 3) -> None:
        self.max_physical_attempts = max(1, int(max_physical_attempts))
        self._pending: PendingWorldInteraction | None = None
        self._attempts: dict[tuple[str, int, int], int] = {}
        # Retry pacing is an execution-owned safety obligation, not advisory
        # worker behavior. A RETRYABLE result records a not-before time for the
        # same logical target so a buggy/fast caller cannot immediately emit a
        # duplicate physical click. The monotonic value is durable across normal
        # process restart on the same OS boot; absurd/stale values are ignored by
        # retry_wait_remaining_ms().
        self._retry_not_before_ms: dict[tuple[str, int, int], int] = {}

    @property
    def pending(self) -> PendingWorldInteraction | None:
        return self._pending

    def pending_for(self, *, operation: str, map_id: int, entity_id: int) -> PendingWorldInteraction | None:
        pending = self._pending
        if pending is None:
            return None
        if pending.logical_key != (str(operation), int(map_id), int(entity_id)):
            return None
        return pending

    def begin(
        self,
        *,
        operation: str,
        map_id: int,
        entity_id: int,
        cell_id: int,
        selected_revision: int,
        sent_after_monotonic_ms: int,
        origin_action_id: str | None = None,
        transaction_id: str | None = None,
        client_instance_id: str | None,
        created_monotonic_ms: int,
        input_evidence: dict[str, Any] | None = None,
        observability_session_id: str | None = None,
    ) -> PendingWorldInteraction:
        key = (str(operation), int(map_id), int(entity_id))
        # Retry history is meaningful only for the currently reacquired logical
        # target. Dropping unrelated keys bounds memory and prevents a group seen
        # much later from inheriting stale attempts from an abandoned target.
        previous_count = int(self._attempts.get(key, 0))
        previous_not_before = self._retry_not_before_ms.get(key)
        self._attempts = ({key: previous_count} if previous_count else {})
        self._retry_not_before_ms = ({key: int(previous_not_before)} if previous_not_before is not None else {})
        count = previous_count + 1
        self._attempts[key] = count
        pending = PendingWorldInteraction(
            operation=str(operation),
            map_id=int(map_id),
            entity_id=int(entity_id),
            cell_id=int(cell_id),
            selected_revision=int(selected_revision),
            attempt_index=count,
            transaction_id=str(transaction_id or uuid4().hex),
            origin_action_id=(str(origin_action_id) if origin_action_id else None),
            sent_after_monotonic_ms=int(sent_after_monotonic_ms),
            client_instance_id=(str(client_instance_id) if client_instance_id else None),
            created_monotonic_ms=int(created_monotonic_ms),
            input_evidence=(dict(input_evidence) if isinstance(input_evidence, dict) else None),
            observability_session_id=(str(observability_session_id) if observability_session_id else None),
            last_observed_monotonic_ms=int(created_monotonic_ms),
        )
        self._pending = pending
        return pending

    def update(self, pending: PendingWorldInteraction) -> PendingWorldInteraction:
        self._pending = pending
        return pending

    def attempts_for(self, *, operation: str, map_id: int, entity_id: int) -> int:
        return int(self._attempts.get((str(operation), int(map_id), int(entity_id)), 0))

    def set_retry_not_before(
        self, pending: PendingWorldInteraction, *, not_before_monotonic_ms: int
    ) -> None:
        self._retry_not_before_ms[pending.logical_key] = max(0, int(not_before_monotonic_ms))

    def retry_wait_remaining_ms(
        self, *, operation: str, map_id: int, entity_id: int, now_monotonic_ms: int
    ) -> int:
        key = (str(operation), int(map_id), int(entity_id))
        target = self._retry_not_before_ms.get(key)
        if target is None:
            return 0
        now = int(now_monotonic_ms)
        # A very large future delta indicates a stale monotonic value after an
        # OS reboot or clock-domain mismatch. Retry pacing is not authorization;
        # attempt budget and semantic safety evidence remain durable, so drop only
        # the stale pacing timestamp rather than blocking the installation forever.
        delta = int(target) - now
        if delta <= 0 or delta > 120_000:
            self._retry_not_before_ms.pop(key, None)
            return 0
        return delta

    def retry_allowed(self, pending: PendingWorldInteraction) -> bool:
        return (
            pending.semantic_state is SemanticRequestState.ABSENT
            and int(pending.attempt_index) < self.max_physical_attempts
        )

    def snapshot(self) -> dict[str, Any] | None:
        if self._pending is None and not self._attempts:
            return None
        return {
            "schema_version": 3,
            "max_physical_attempts": int(self.max_physical_attempts),
            "pending": (self._pending.to_dict() if self._pending is not None else None),
            "attempts": [
                {
                    "operation": key[0],
                    "map_id": int(key[1]),
                    "entity_id": int(key[2]),
                    "count": int(count),
                }
                for key, count in sorted(self._attempts.items())
            ],
            "retry_not_before": [
                {
                    "operation": key[0],
                    "map_id": int(key[1]),
                    "entity_id": int(key[2]),
                    "monotonic_ms": int(value),
                }
                for key, value in sorted(self._retry_not_before_ms.items())
            ],
        }

    def restore(self, payload: dict[str, Any] | None) -> PendingWorldInteraction | None:
        if not isinstance(payload, dict):
            return None
        self._attempts.clear()
        self._retry_not_before_ms.clear()
        self._pending = None
        # R5.117 schema keeps retry budget durable even between a RETRYABLE
        # result and the next physical attempt. Accept the R5.116 raw-pending
        # shape as a backward-compatible migration path.
        if int(payload.get("schema_version") or 0) >= 2 or "pending" in payload:
            for item in payload.get("attempts") or ():
                if not isinstance(item, dict):
                    continue
                try:
                    key = (str(item["operation"]), int(item["map_id"]), int(item["entity_id"]))
                    count = max(0, int(item.get("count") or 0))
                except (KeyError, TypeError, ValueError):
                    continue
                if count:
                    self._attempts[key] = count
            for item in payload.get("retry_not_before") or ():
                if not isinstance(item, dict):
                    continue
                try:
                    key = (str(item["operation"]), int(item["map_id"]), int(item["entity_id"]))
                    value = max(0, int(item.get("monotonic_ms") or 0))
                except (KeyError, TypeError, ValueError):
                    continue
                if value:
                    self._retry_not_before_ms[key] = value
            raw_pending = payload.get("pending")
            if isinstance(raw_pending, dict):
                pending = PendingWorldInteraction.from_dict(raw_pending)
                self._pending = pending
                self._attempts[pending.logical_key] = max(
                    int(self._attempts.get(pending.logical_key, 0)), int(pending.attempt_index)
                )
                return pending
            return None

        pending = PendingWorldInteraction.from_dict(payload)
        self._pending = pending
        self._attempts[pending.logical_key] = max(
            int(self._attempts.get(pending.logical_key, 0)), int(pending.attempt_index)
        )
        return pending

    def clear_pending(self) -> None:
        # Deliberately preserve the current logical target's attempt count. A
        # RETRYABLE result is a safety budget obligation and process restart must
        # not reset it back to attempt #1.
        self._pending = None

    def clear_recoverable_history_for_new_campaign(self) -> bool:
        """Clear only settled retry bookkeeping at a new campaign boundary.

        A pending transaction is an unresolved physical-input obligation and must
        survive campaign/run changes.  When no transaction is pending, the
        remaining attempt/backoff entries came from a prior RETRYABLE disposition
        whose semantic non-acceptance was already proven; those counters are not
        authorization and must not make an unrelated fresh SessionPlan inherit an
        exhausted retry budget.
        """
        if self._pending is not None:
            return False
        self._attempts.clear()
        self._retry_not_before_ms.clear()
        return True

    def finish(self, pending: PendingWorldInteraction) -> None:
        key = pending.logical_key
        self._pending = None
        self._attempts.pop(key, None)
        self._retry_not_before_ms.pop(key, None)

    def abandon_other_target(self, *, operation: str, map_id: int, entity_id: int) -> None:
        pending = self._pending
        if pending is None:
            return
        if pending.logical_key != (str(operation), int(map_id), int(entity_id)):
            # A pending semantic-positive interaction must never be silently
            # discarded. The caller is responsible for fail-closed handling.
            if pending.semantic_state is not SemanticRequestState.OBSERVED:
                self._pending = None
                self._attempts.pop(pending.logical_key, None)
                self._retry_not_before_ms.pop(pending.logical_key, None)

from __future__ import annotations

import math
import time
from contextlib import nullcontext
from dataclasses import dataclass, replace
from enum import Enum
from threading import RLock
from pathlib import Path
from typing import Callable, Protocol
from uuid import uuid4

from anka_game_kernel.api.kernel import GameKernel
from anka_game_kernel.domain.ids import MapId
from anka_platform.calibration.models import CalibrationPoint, CalibrationSettings
from anka_platform.contracts.actions import FightMoveToCellAction, WorldMoveToCellAction
from anka_platform.contracts.canonical_state import CanonicalSnapshot
from anka_platform.contracts.common import ValueStatus
from anka_platform.local_fighter_identity import (
    LocalFighterIdentityStatus,
    authoritative_canonical_local_actor_id,
    canonical_local_identity_authority,
    resolve_local_fighter_identity,
)
from anka_platform.contracts.projection import ProjectionResult, ProjectionStatus, ScreenPoint
from anka_platform.execution.safety import ExecutionSafetyStore, ExecutionSafetyStoreError
from anka_platform.execution.control_authority import ControlAuthorityStore
from anka_platform.execution.fight_action_admission import (
    FightActionAdmissionService, FightActionAdmissionStatus,
)
from anka_platform.execution.arbiter import InputArbiter
from anka_platform.execution.fight_join_state_machine import FightJoinAttemptLedger, PendingJoinAttempt
from anka_platform.execution.placement_pre_down import FightPlacementPreDownGuard
from anka_platform.execution.world_interaction import (
    PendingWorldInteraction, SemanticRequestState, WorldInteractionLedger,
)
from anka_platform.protocol.compatibility import certify_negative_semantic_evidence
from anka_platform.protocol.registry import default_protocol_registry
from anka_platform.protocol.wire_semantics import ProtocolWireBinding, ProtocolWireSemantic
from anka_platform.observability.models import FailureCode
from anka_platform.contracts.combat_action import ActionIntent
from anka_platform.maps.routing import ensure_world_route
from anka_platform.integration.fight_geometry import FightGeometryUnavailable, resolve_fight_geometry
from anka_platform.execution.settlement import (
    PendingSettlement, SettlementRequirement, readiness_payload, missing_requirements,
    local_turn_readiness_payload,
)
from anka_platform.execution.operation_contracts import (
    decorate_transaction_observation, prepare_handler_request, runtime_operation_spec,
)
from anka_platform.execution.concurrency import (
    ExecutionLifecycleGate, ExecutionLifecyclePhase, ExecutionOperationTracker,
)


class PhysicalSendState(str, Enum):
    NOT_SENT = "NOT_SENT"
    SENT = "SENT"
    UNCERTAIN = "UNCERTAIN"


class ExecutionStatus(str, Enum):
    BLOCKED = "BLOCKED"
    CONFIRMED = "CONFIRMED"
    CONFIRMED_UNSETTLED = "CONFIRMED_UNSETTLED"
    SETTLED = "SETTLED"
    UNCERTAIN = "UNCERTAIN"


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    action_id: str
    status: ExecutionStatus
    send_state: PhysicalSendState
    detail: str
    confirmed_revision: int | None = None
    settled_revision: int | None = None


class StateProvider(Protocol):
    def snapshot(self) -> CanonicalSnapshot: ...


class ProjectionProvider(Protocol):
    def resolve_current(
        self, map_id: int, cell_id: int, *, purpose: str = "ANKA_SCREEN_PROJECTION",
        target_entity_id: int | None = None,
    ) -> ProjectionResult: ...


class RuntimeInputDriver(Protocol):
    def ensure_target_focused(self) -> bool: ...
    def click(self, point: ScreenPoint) -> PhysicalSendState: ...
    def click_client(
        self,
        point: CalibrationPoint,
        *,
        expected_width: int,
        expected_height: int,
    ) -> PhysicalSendState: ...
    def cancel_current_action(self) -> PhysicalSendState: ...
    def observed_client_version(self) -> str | None: ...


class ExecutionService:
    """Parent-process physical authority used by isolated scripts.

    Policy lives in scripts and mechanics live in the Kernel.  This service only
    validates the latest confirmed identity, performs calibrated/projected UI
    input, and waits for a newer canonical fact proving the requested outcome.
    Physical input is never retried blindly. A bounded retry is permitted only
    when exact-generation observability positively proves that the client did
    not emit the certified semantic request for the previous attempt.
    """

    def __init__(
        self,
        state: StateProvider,
        projection: ProjectionProvider,
        input_driver: RuntimeInputDriver,
        *,
        kernel: GameKernel | None = None,
        calibration: CalibrationSettings | None = None,
        sleep: Callable[[float], None] = time.sleep,
        monotonic_clock: Callable[[], float] = time.monotonic,
        monotonic_ns_clock: Callable[[], int] = time.monotonic_ns,
        confirmation_interval_seconds: float = 0.1,
        max_confirmation_polls: int = 20,
        timing=None,
        execution_db_path: str | Path | None = None,
        observability=None,
        critical_debug_export: Callable[[], object] | None = None,
        account_id: str = "legacy",
        input_arbiter: InputArbiter | None = None,
        runtime_health_provider: Callable[[], dict] | None = None,
        control_authority: ControlAuthorityStore | None = None,
        protocol_adapter_id: str | None = None,
    ) -> None:
        self.kernel = kernel
        self.state = state
        self.projection = projection
        self.input = input_driver
        self.calibration = calibration or CalibrationSettings()
        self.sleep = sleep
        self.monotonic_clock = monotonic_clock
        self.monotonic_ns_clock = monotonic_ns_clock
        self._timing = timing
        self.confirmation_interval_seconds = (
            float(timing.poll_interval_seconds) if timing is not None else float(confirmation_interval_seconds)
        )
        self.max_confirmation_polls = int(max_confirmation_polls)
        self._lock = RLock()
        self._execution_lifecycle_gate = ExecutionLifecycleGate()
        self._operation_tracker = ExecutionOperationTracker()
        self._attempted: set[tuple[int, str, tuple[tuple[str, object], ...]]] = set()
        self._attempted_revision: int | None = None
        self._sent_action_ids: set[str] = set()
        self._safety = ExecutionSafetyStore(execution_db_path) if execution_db_path is not None else None
        self._pending_settlement: PendingSettlement | None = self._safety.pending() if self._safety is not None else None
        self._uncertain_detail: str | None = self._safety.uncertain_detail() if self._safety is not None else None
        self._uncertain_context: dict | None = None
        self._prepared_input_context: dict | None = None
        if self._safety is not None:
            try:
                self._prepared_input_context = self._safety.prepared_input()
            except Exception as exc:
                self._prepared_input_context = {
                    "kind": "DURABLE_PREPARED_INPUT_CORRUPT",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            try:
                self._uncertain_context = self._safety.uncertain_context()
            except Exception as exc:
                # A corrupt uncertainty descriptor must never make an unresolved
                # physical action eligible for automatic clearing. Preserve the
                # old fail-closed detail and mark the context as non-reconcilable.
                self._uncertain_context = {
                    "kind": "DURABLE_UNCERTAINTY_CONTEXT_CORRUPT",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            if self._prepared_input_context is not None:
                # A process can die after durably preparing an input and before it
                # can persist the semantic outcome. On restart that marker is an
                # unresolved physical-action obligation, never permission to retry.
                self._uncertain_detail = self._uncertain_detail or (
                    "DURABLE_PREPARED_INPUT_RECOVERY: a physical input may have been sent before restart; "
                    "automatic retry is forbidden until reconciled"
                )
                if self._uncertain_context is None:
                    self._uncertain_context = {
                        "kind": "PREPARED_PHYSICAL_INPUT_RECOVERY",
                        **dict(self._prepared_input_context),
                    }
        self.observability = observability
        self.critical_debug_export = critical_debug_export
        self.account_id = str(account_id)
        self.input_arbiter = input_arbiter
        self.runtime_health_provider = runtime_health_provider
        self.protocol_adapter_id = str(protocol_adapter_id).strip() if protocol_adapter_id else None
        # Raw Dofus wire names/layouts are owned by the protocol manifest.
        # Legacy/narrow unit construction historically omitted an adapter id; in
        # that case resolve the repository's single registered adapter inside the
        # protocol boundary rather than hard-coding wire names in execution.
        profile_adapter_id = self.protocol_adapter_id
        if profile_adapter_id is None:
            manifests = default_protocol_registry().manifests()
            profile_adapter_id = manifests[0].adapter_id if len(manifests) == 1 else None
        try:
            self._protocol_wire_profile = (
                default_protocol_registry().require_manifest(profile_adapter_id).wire_profile
                if profile_adapter_id is not None else None
            )
        except LookupError:
            self._protocol_wire_profile = None
        # R5.140 combat semantic boundary. Production fight orchestration binds
        # the same CombatFrameAssembler used by FightAI. Physical identity and
        # settlement continue to use the local Canonical lane; only Kernel
        # admission consumes the cross-account certified semantic frame.
        self._combat_frame_provider: Callable[[str], object] | None = None
        # R5.141 same-session positive semantic evidence.  A newer client build
        # never inherits negative wire semantics from an older adapter.  Instead,
        # repeated exact server-confirmed CAST_REQUEST correlations may certify only
        # that spell for this exact client instance/session.
        self._session_cast_semantic_proofs: dict[tuple[str, str, int], set[str]] = {}
        # R5.145 same-session MOVE semantics. The adapter exposes outbound movement only through the semantic MOVE_REQUEST binding,
        # and a newer client build must prove that mapping in this exact client instance
        # before absence of MOVE_REQUEST can close a sent click as a
        # local client rejection. Positive target-confirmed moves build that proof.
        self._session_move_semantic_proofs: dict[tuple[str, str], set[str]] = {}
        self._session_end_turn_semantic_proofs: dict[tuple[str, str], set[str]] = {}
        # Production composition injects one shared strict authority. Narrow
        # unit/legacy construction remains permissive so existing mechanical
        # tests can focus on their local contract without manufacturing an
        # application Launch lifecycle.
        self.control_authority = control_authority or ControlAuthorityStore.legacy_permissive()
        self._fight_join_ledger = FightJoinAttemptLedger(max_physical_attempts=2)
        self._world_interaction_semantic_grace_seconds = max(
            self.confirmation_interval_seconds,
            float(getattr(timing, "world_interaction_semantic_grace_seconds", 1.25)) if timing is not None else 1.25,
        )
        self._world_interaction_retry_backoff_seconds = max(
            0.0,
            float(getattr(timing, "world_interaction_retry_backoff_seconds", 0.75)) if timing is not None else 0.75,
        )
        self._world_interaction_ledger = WorldInteractionLedger(
            max_physical_attempts=(
                int(getattr(timing, "world_interaction_max_attempts", 3)) if timing is not None else 3
            )
        )
        if self._safety is not None:
            try:
                self._world_interaction_ledger.restore(self._safety.world_interaction())
            except Exception as exc:
                # Corrupt durable safety evidence is itself an unresolved
                # physical-action obligation.  Process restart must never turn
                # unreadable state into permission for a fresh click.
                detail = (
                    "DURABLE_WORLD_INTERACTION_STATE_CORRUPT: "
                    f"{type(exc).__name__}: {exc}; physical retry forbidden"
                )
                self._uncertain_detail = detail
                try:
                    self._safety.set_uncertain(detail)
                except Exception:
                    pass


    def bind_combat_frame_provider(self, provider: Callable[[str], object] | None) -> None:
        """Bind the shared immutable combat-frame provider used by FightAI.

        This does not transfer physical-input authority.  It only ensures that
        execution admission evaluates mechanics against the same certified party
        semantics as planning.
        """
        with self._lock:
            self._combat_frame_provider = provider

    def concurrency_status(self) -> dict:
        """Read-only execution concurrency snapshot; never authorizes input."""
        value = self._operation_tracker.snapshot()
        value["lifecycle_gate"] = self._execution_lifecycle_gate.snapshot()
        if self.input_arbiter is not None:
            try:
                snapshot = getattr(self.input_arbiter, "snapshot", None)
                if callable(snapshot):
                    value["input_arbiter"] = dict(snapshot())
                else:
                    # Compatibility for injected legacy arbiters. Production
                    # InputArbiter exposes an atomic snapshot.
                    value["input_arbiter"] = {
                        "active_owner": self.input_arbiter.active_owner,
                        "previous_owner": self.input_arbiter.previous_owner,
                        "last_released_owner": self.input_arbiter.last_released_owner,
                        "handoff_changed": self.input_arbiter.handoff_changed,
                        "handoff_sequence": self.input_arbiter.handoff_sequence,
                    }
            except Exception:
                value["input_arbiter"] = {"status": "UNAVAILABLE"}
        return value

    def activate_window(self, *, runtime_context: dict | None = None) -> dict:
        with self._execution_lifecycle_gate.lease("activate_window"):
            return self._activate_window_lifecycle(runtime_context=runtime_context)

    def _activate_window_lifecycle(self, *, runtime_context: dict | None = None) -> dict:
        """Acquire physical input ownership and prove this account is foreground.

        This sends no game action.  R5.178 keeps all mutable execution checks
        serialized under the per-account lock, but publishes the result only
        after that lock is released so observability/control-fencing callbacks
        can never join the execution lock order.
        """
        runtime = dict(runtime_context or {})
        run_id = runtime.get("run_id")
        request_id = runtime.get("request_id")
        action_id = uuid4().hex
        basis_revision = None
        with self._operation_tracker.track(
            operation="activate_window", action_id=action_id, account_id=self.account_id,
            runtime_context=runtime,
        ) as tracked:
            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.START_OBSERVABILITY)
            if self.observability is not None:
                try:
                    snapshot = self.state.snapshot()
                    basis_revision = int(snapshot.revision)
                    fight_instance_id = (
                        int(snapshot.fight.fight_instance_id)
                        if snapshot.fight.present and snapshot.fight.fight_instance_id is not None
                        else None
                    )
                    client_instance_id = (
                        self.input.client_instance_id()
                        if hasattr(self.input, "client_instance_id") else None
                    )
                    self.observability.record_action_start(
                        action_id=action_id,
                        operation="activate_window",
                        basis_revision=basis_revision,
                        intent={"runtime_context": runtime},
                        run_id=run_id, request_id=request_id,
                        account_id=self.account_id,
                        client_instance_id=client_instance_id,
                        fight_instance_id=fight_instance_id,
                    )
                except Exception:
                    pass

            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.AUTHORIZATION)
            authority = self.control_authority.authorize(
                runtime_context=runtime, operation="activate_window", account_id=self.account_id
            )
            if authority.get("allowed") is not True:
                result = {
                    "status": "BLOCKED",
                    "failure_code": str(authority.get("failure_code") or "CONTROL_AUTHORITY_BLOCKED"),
                    "detail": str(authority.get("detail") or "physical control is not authorized"),
                    "retry_allowed": False,
                    "first_missing_boundary": str(
                        authority.get("first_missing_boundary") or "TURN_OWNER_CONTROL_AUTHORIZATION"
                    ),
                    "likely_owner": str(authority.get("likely_owner") or "EXECUTION_CONTROL"),
                    "control_authority": authority,
                    "account_id": self.account_id,
                    "action_id": action_id,
                    "physical_send_state": PhysicalSendState.NOT_SENT.value,
                }
            else:
                self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.WAITING_EXECUTION_LOCK)
                with self._lock:
                    self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.EXECUTING)
                    result = self._activate_window_locked(
                        authority=dict(authority), action_id=action_id,
                    )

            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.RESULT_OBSERVABILITY)
            self._record_observed_result(
                action_id=action_id, operation="activate_window", result=result,
                run_id=run_id, request_id=request_id, basis_revision=basis_revision,
            )
            return result

    def _activate_window_locked(self, *, authority: dict, action_id: str) -> dict:
        """Mutable activation half; caller must own the per-account lock."""
        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return {
                **dict(runtime_block),
                "account_id": self.account_id,
                "action_id": action_id,
                "retry_allowed": True,
                "control_authority": dict(authority),
            }
        with self._input_lease():
            ready = bool(self.input.ensure_target_focused())
            diagnostic = {}
            debug_status = getattr(self.input, "debug_status", None)
            if callable(debug_status):
                try:
                    value = debug_status()
                    if isinstance(value, dict):
                        diagnostic = dict(value)
                except Exception:
                    diagnostic = {}
        if not ready:
            code = str(diagnostic.get("failure_code") or "WINDOW_FOCUS_FAILED")
            non_retryable = code in {
                "WINDOW_IDENTITY_CHANGED", "WINDOW_NOT_FOUND", "WINDOW_AMBIGUOUS",
                "INPUT_INTEGRITY_MISMATCH", "CLIENT_SIZE_MISMATCH", "DPI_CONTEXT_FAILURE",
            }
            return {
                "status": "BLOCKED",
                "failure_code": code,
                "detail": diagnostic.get("detail") or "target Dofus window could not be proven foreground",
                "retry_allowed": not non_retryable,
                "first_missing_boundary": "TURN_OWNER_WINDOW_ACTIVATION",
                "likely_owner": "WINDOW_INPUT",
                "account_id": self.account_id,
                "action_id": action_id,
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "control_authority": dict(authority),
                "window": diagnostic,
            }
        return {
            "status": "WINDOW_READY",
            "account_id": self.account_id,
            "action_id": action_id,
            "focus_switched": bool(diagnostic.get("focus_switched", False)),
            "focus_method": diagnostic.get("focus_method"),
            "foreground_hwnd": diagnostic.get("foreground_hwnd"),
            "control_authority": dict(authority),
            "window": diagnostic,
        }

    def turn_activity_heartbeat(self, *, runtime_context: dict | None = None) -> dict:
        with self._execution_lifecycle_gate.lease("turn_activity_heartbeat"):
            return self._turn_activity_heartbeat_lifecycle(runtime_context=runtime_context)

    def _turn_activity_heartbeat_lifecycle(self, *, runtime_context: dict | None = None) -> dict:
        """Send one verified non-click cursor movement for the active combat turn.

        Mutable readiness/input work is serialized, while journaling happens
        after the execution lock is released.  This preserves the single input
        authority and removes observability from the lock dependency graph.
        """
        runtime = dict(runtime_context or {})
        run_id = runtime.get("run_id")
        request_id = runtime.get("request_id")
        action_id = uuid4().hex
        basis_revision = None
        with self._operation_tracker.track(
            operation="turn_activity_heartbeat", action_id=action_id, account_id=self.account_id,
            runtime_context=runtime,
        ) as tracked:
            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.START_OBSERVABILITY)
            if self.observability is not None:
                try:
                    snapshot = self.state.snapshot()
                    basis_revision = int(snapshot.revision)
                    fight_instance_id = (
                        int(snapshot.fight.fight_instance_id)
                        if snapshot.fight.present and snapshot.fight.fight_instance_id is not None
                        else None
                    )
                    client_instance_id = (
                        self.input.client_instance_id()
                        if hasattr(self.input, "client_instance_id") else None
                    )
                    self.observability.record_action_start(
                        action_id=action_id,
                        operation="turn_activity_heartbeat",
                        basis_revision=basis_revision,
                        intent={"runtime_context": runtime, "physical_click": False},
                        run_id=run_id, request_id=request_id,
                        account_id=self.account_id,
                        client_instance_id=client_instance_id,
                        fight_instance_id=fight_instance_id,
                    )
                except Exception:
                    pass

            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.AUTHORIZATION)
            authority = self.control_authority.authorize(
                runtime_context=runtime, operation="turn_activity_heartbeat", account_id=self.account_id
            )
            if authority.get("allowed") is not True:
                result = {
                    "status": "BLOCKED",
                    "failure_code": str(authority.get("failure_code") or "CONTROL_AUTHORITY_BLOCKED"),
                    "detail": str(authority.get("detail") or "physical control is not authorized"),
                    "retry_allowed": False,
                    "physical_input_event": False,
                    "physical_click": False,
                    "control_authority": dict(authority),
                }
            else:
                self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.WAITING_EXECUTION_LOCK)
                with self._lock:
                    self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.EXECUTING)
                    result = self._turn_activity_heartbeat_locked(authority=dict(authority))

            row = dict(result)
            row.setdefault("account_id", self.account_id)
            row.setdefault("action_id", action_id)
            if "physical_send_state" not in row:
                row["physical_send_state"] = (
                    PhysicalSendState.SENT.value
                    if row.get("physical_input_event") is True
                    else PhysicalSendState.NOT_SENT.value
                )
            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.RESULT_OBSERVABILITY)
            self._record_observed_result(
                action_id=action_id, operation="turn_activity_heartbeat", result=row,
                run_id=run_id, request_id=request_id, basis_revision=basis_revision,
            )
            return row

    def _turn_activity_heartbeat_locked(self, *, authority: dict) -> dict:
        """Mutable heartbeat half; caller must own the per-account lock."""
        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return {
                **dict(runtime_block), "status": "BLOCKED", "retry_allowed": True,
                "physical_input_event": False, "physical_click": False,
                "control_authority": dict(authority),
            }
        if self._uncertain_detail is not None or self._pending_settlement is not None:
            return {
                "status": "SKIPPED",
                "reason": "COMBAT_INPUT_FENCE_ACTIVE",
                "detail": self._uncertain_detail or "pending action settlement",
                "physical_input_event": False,
                "physical_click": False,
                "control_authority": dict(authority),
            }
        size = self.calibration.client_size
        nudger = getattr(self.input, "activity_nudge_client", None)
        mover = getattr(self.input, "move_client", None)
        if size is None or (not callable(nudger) and not callable(mover)):
            return {
                "status": "SKIPPED",
                "reason": "HEARTBEAT_MOVE_UNAVAILABLE",
                "physical_input_event": False,
                "physical_click": False,
                "control_authority": dict(authority),
            }
        heartbeat_strategy = "RELATIVE_CLIENT_NUDGE_V1" if callable(nudger) else "LEGACY_FIXED_POINT"
        legacy_client_point = None
        with self._input_lease():
            if not self.input.ensure_target_focused():
                return {
                    "status": "BLOCKED", "failure_code": "WINDOW_FOCUS_FAILED",
                    "detail": "heartbeat target window could not be certified foreground",
                    "retry_allowed": True, "physical_input_event": False,
                    "physical_click": False, "control_authority": dict(authority),
                }
            if callable(nudger):
                moved = bool(nudger(
                    expected_width=int(size.width), expected_height=int(size.height),
                ))
            else:
                # Compatibility only for old/dummy drivers. Production
                # DofusWindowInputDriver uses the relative bounded nudge.
                x = max(8, min(int(size.width) - 1, 32))
                y = max(8, min(int(size.height) - 1, 32))
                legacy_client_point = [x, y]
                moved = bool(mover(
                    CalibrationPoint(x=x, y=y, verified=True, source="combat:turn_activity_heartbeat"),
                    expected_width=int(size.width), expected_height=int(size.height),
                ))
        input_diagnostic = {}
        if hasattr(self.input, "debug_status"):
            try:
                value = self.input.debug_status()
                input_diagnostic = dict(value) if isinstance(value, dict) else {}
            except Exception:
                input_diagnostic = {}
        heartbeat_input_code = str(input_diagnostic.get("failure_code") or "") or None
        heartbeat_skipped = heartbeat_input_code == "HEARTBEAT_CURSOR_OUTSIDE_CLIENT"
        return {
            "status": "HEARTBEAT_SENT" if moved else ("SKIPPED" if heartbeat_skipped else "BLOCKED"),
            "failure_code": None if moved or heartbeat_skipped else (heartbeat_input_code or "INPUT_NOT_SENT"),
            "reason": heartbeat_input_code if heartbeat_skipped else None,
            "detail": (
                "verified non-click cursor movement sent"
                if moved else (
                    "heartbeat intentionally skipped because the real cursor is outside the bound client"
                    if heartbeat_skipped else
                    "heartbeat cursor move was not sent"
                )
            ),
            "retry_allowed": False if heartbeat_skipped else (not moved),
            "physical_input_event": bool(moved),
            "physical_click": False,
            "control_authority": dict(authority),
            "heartbeat_strategy": heartbeat_strategy,
            "client_point": legacy_client_point,
            "heartbeat_nudge_distance_px": input_diagnostic.get("heartbeat_nudge_distance_px"),
            "heartbeat_target_screen_point": input_diagnostic.get("heartbeat_target_screen_point"),
            "heartbeat_cursor_was_inside_client": input_diagnostic.get("heartbeat_cursor_was_inside_client"),
            "heartbeat_input_failure_code": heartbeat_input_code,
            "physical_input_evidence": input_diagnostic,
        }

    def execute(
        self,
        action: WorldMoveToCellAction | FightMoveToCellAction,
        *,
        runtime_context: dict | None = None,
    ) -> ExecutionResult:
        operation = "move_fight" if isinstance(action, FightMoveToCellAction) else "world_move_to_cell"
        with self._execution_lifecycle_gate.lease(operation):
            result = self._execute_typed_lifecycle(action, runtime_context=runtime_context)
            self._finalize_prepared_input_from_result({
                "status": result.status.value,
                "physical_send_state": result.send_state.value,
                "retry_allowed": False,
                "safe_replan": False,
            })
            return result

    def _execute_typed_lifecycle(
        self,
        action: WorldMoveToCellAction | FightMoveToCellAction,
        *,
        runtime_context: dict | None = None,
    ) -> ExecutionResult:
        """Typed movement entrypoint using the same physical authority and safety fence."""
        operation = "move_fight" if isinstance(action, FightMoveToCellAction) else "world_move_to_cell"
        authority = self.control_authority.authorize(
            runtime_context=runtime_context,
            operation=operation,
            account_id=self.account_id,
        )
        if authority.get("allowed") is not True:
            return ExecutionResult(
                action.action_id,
                ExecutionStatus.BLOCKED,
                PhysicalSendState.NOT_SENT,
                str(authority.get("failure_code") or "CONTROL_AUTHORITY_BLOCKED")
                + ": "
                + str(authority.get("detail") or "physical control is not authorized"),
            )
        with self._lock:
            runtime_block = self._guard_runtime_health()
            if runtime_block is not None:
                return ExecutionResult(
                    action.action_id, ExecutionStatus.BLOCKED, PhysicalSendState.NOT_SENT,
                    str(runtime_block.get("detail") or "runtime health not ready")
                )
            if self._uncertain_detail is not None:
                return self._blocked_result(action.action_id, f"UNCERTAIN_FENCE active: {self._uncertain_detail}")
            before = self.state.snapshot()
            if self._pending_settlement is not None:
                pending_state = readiness_payload(before, self._pending_settlement)
                if pending_state.get("status") != "READY":
                    return self._blocked_result(
                        action.action_id,
                        "ACTION_SETTLEMENT_FENCE active: prior physical action is confirmed but live state is not settled",
                    )
                self._pending_settlement = None
                if self._safety is not None:
                    self._safety.set_pending(None)
            if action.action_id in self._sent_action_ids:
                return self._blocked_result(action.action_id, "action_id was already physically attempted")
            if before.revision != action.expected_state_revision:
                return self._blocked_result(action.action_id, f"stale action: expected revision {action.expected_state_revision}, current {before.revision}")
            target_map = self._validate_typed_action(before, action)
            if target_map is None:
                return self._blocked_result(action.action_id, "action does not match confirmed live state")
            purpose = "FIGHT_MOVE_CLICK" if isinstance(action, FightMoveToCellAction) else "WORLD_MOVE_CLICK"
            with self._input_lease():
                if not self.input.ensure_target_focused():
                    return self._blocked_result(action.action_id, "target Dofus window is not uniquely focused")
                projection, projection_block = self._resolve_safe_cell(
                    target_map, action.target_cell_id, purpose=purpose, label="typed movement target",
                )
                if projection_block is not None:
                    return self._blocked_result(action.action_id, str(projection_block.get("detail") or "projection blocked"))
                latest = self.state.snapshot()
                if self._confirmed_typed(latest, action):
                    return ExecutionResult(
                        action.action_id, ExecutionStatus.CONFIRMED, PhysicalSendState.NOT_SENT,
                        "target state became confirmed before physical input", latest.revision, latest.revision,
                    )
                if self._validate_typed_action(latest, action) != target_map:
                    return self._blocked_result(action.action_id, "live state changed before physical input; replan required")
                assert projection is not None and projection.point is not None
                send_state = self._send_projection(projection)
            if send_state is PhysicalSendState.NOT_SENT:
                return self._blocked_result(action.action_id, "physical input was not sent")
            self._sent_action_ids.add(action.action_id)
            if send_state is PhysicalSendState.UNCERTAIN:
                detail = "physical send state is uncertain; retry forbidden"
                self._uncertain_detail = detail
                if self._safety is not None:
                    self._safety.set_uncertain(detail)
                return ExecutionResult(action.action_id, ExecutionStatus.UNCERTAIN, send_state, detail)
            confirmed_revision: int | None = None
            typed_move_pending: PendingSettlement | None = None
            typed_move_baseline_mp: int | None = None
            if isinstance(action, FightMoveToCellAction) and before.fight.present:
                before_actor = next((item for item in before.fight.actors if item.actor_id == action.actor_id), None)
                if (
                    before_actor is not None
                    and before_actor.mp.status is ValueStatus.KNOWN
                    and before_actor.mp.value is not None
                ):
                    typed_move_baseline_mp = int(before_actor.mp.value)
            confirmation_remaining = self._confirmation_poll_budget(operation)
            settlement_remaining = self._settlement_poll_budget(operation)
            while confirmation_remaining > 0 or (confirmed_revision is not None and settlement_remaining > 0):
                current = self.state.snapshot()
                if current.revision > before.revision:
                    if isinstance(action, FightMoveToCellAction):
                        actor = next((item for item in current.fight.actors if item.actor_id == action.actor_id), None) if current.fight.present else None
                        cell_confirmed = (
                            actor is not None
                            and actor.cell_id.status is ValueStatus.KNOWN
                            and actor.cell_id.value == action.target_cell_id
                            and actor.observed.cell_revision > before.revision
                        )
                        if cell_confirmed and confirmed_revision is None:
                            confirmed_revision = int(actor.observed.cell_revision)
                            confirmation_remaining = 0
                            if typed_move_baseline_mp is not None:
                                typed_move_pending = PendingSettlement(
                                    action_kind="move_fight",
                                    basis_revision=int(before.revision),
                                    server_confirmed_revision=confirmed_revision,
                                    requirements=(
                                        SettlementRequirement(
                                            int(action.actor_id),
                                            "mp",
                                            confirmed_revision,
                                            mode="RESOURCE_DECREASE",
                                            baseline_value=typed_move_baseline_mp,
                                        ),
                                    ),
                                )
                        if (
                            confirmed_revision is not None
                            and typed_move_pending is not None
                            and not missing_requirements(current, typed_move_pending)
                        ):
                            self._pending_settlement = None
                            if self._safety is not None:
                                self._safety.set_pending(None)
                            return ExecutionResult(
                                action.action_id, ExecutionStatus.SETTLED, send_state,
                                "fight movement confirmed and authoritative remaining MP settled",
                                confirmed_revision, current.revision,
                            )
                    elif self._confirmed_typed(current, action):
                        return ExecutionResult(action.action_id, ExecutionStatus.CONFIRMED, send_state, "confirmed by newer canonical state", current.revision, current.revision)
                if confirmed_revision is None:
                    confirmation_remaining -= 1
                else:
                    settlement_remaining -= 1
                self.sleep(self.confirmation_interval_seconds)
            if isinstance(action, FightMoveToCellAction) and confirmed_revision is not None:
                if typed_move_pending is not None:
                    self._pending_settlement = typed_move_pending
                    if self._safety is not None:
                        self._safety.set_pending(typed_move_pending)
                return ExecutionResult(
                    action.action_id, ExecutionStatus.CONFIRMED_UNSETTLED, send_state,
                    "fight movement reached the target cell but authoritative remaining MP has not settled",
                    confirmed_revision, None,
                )
            detail = "input was sent but canonical confirmation did not arrive"
            self._uncertain_detail = detail
            if self._safety is not None:
                self._safety.set_uncertain(detail)
            return ExecutionResult(action.action_id, ExecutionStatus.UNCERTAIN, send_state, detail)

    def handle(self, operation: str, payload: dict) -> dict:
        with self._execution_lifecycle_gate.lease(operation):
            return self._handle_lifecycle(operation, payload)

    def _handle_lifecycle(self, operation: str, payload: dict) -> dict:
        """Execute one registered runtime operation under the per-account state lock.

        R5.178 deliberately releases the execution critical section before
        observability/incident callbacks run.  Action state, uncertainty and
        durable safety mutation remain serialized; diagnostics remain read-only
        consumers and cannot participate in the execution lock order.
        """
        action_id = uuid4().hex
        runtime_hint = (payload.get("_runtime") if isinstance(payload, dict) else None)
        with self._operation_tracker.track(
            operation=operation, action_id=action_id, account_id=self.account_id,
            runtime_context=runtime_hint if isinstance(runtime_hint, dict) else None,
        ) as tracked:
            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.WAITING_EXECUTION_LOCK)
            with self._lock:
                self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.EXECUTING)
                result, run_id, request_id, basis_revision = self._handle_locked(
                    operation, payload, action_id=action_id,
                )
            # Never hold the execution-state lock while calling the observability
            # journal / incident callback.  Those components may perform filesystem
            # work or control fencing and must not create a lock inversion with
            # status/reconciliation readers.
            self._operation_tracker.transition(tracked.sequence, ExecutionLifecyclePhase.RESULT_OBSERVABILITY)
            self._record_observed_result(
                action_id=action_id, operation=operation, result=result, run_id=run_id,
                request_id=request_id, basis_revision=basis_revision,
            )
            return result

    def _handle_locked(
        self, operation: str, payload: dict, *, action_id: str,
    ) -> tuple[dict, object, object, int | None]:
        """State-mutating half of :meth:`handle`; caller must own ``self._lock``."""
        request = dict(payload)
        runtime = dict(request.pop("_runtime", {}) or {})
        run_id = runtime.get("run_id")
        request_id = runtime.get("request_id")
        authority = self.control_authority.authorize(
            runtime_context=runtime, operation=operation, account_id=self.account_id
        )
        if authority.get("allowed") is not True:
            result = {
                "status": "BLOCKED",
                "failure_code": str(authority.get("failure_code") or "CONTROL_AUTHORITY_BLOCKED"),
                "detail": str(authority.get("detail") or "physical control is not authorized"),
                "control_authority": authority,
                "retry_allowed": False,
                "first_missing_boundary": str(authority.get("first_missing_boundary") or "CONTROL_AUTHORITY"),
                "likely_owner": str(authority.get("likely_owner") or "EXECUTION_CONTROL"),
                "action_id": action_id,
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
            }
            return result, run_id, request_id, None

        basis_revision = None
        basis_fight_instance_id = None
        client_instance_id = None
        if hasattr(self.input, "client_instance_id"):
            try:
                client_instance_id = self.input.client_instance_id()
            except Exception:
                client_instance_id = None
        if self.observability is not None:
            try:
                basis_snapshot = self.state.snapshot()
                basis_revision = int(basis_snapshot.revision)
                if basis_snapshot.fight.present and basis_snapshot.fight.fight_instance_id is not None:
                    basis_fight_instance_id = int(basis_snapshot.fight.fight_instance_id)
                self.observability.record_action_start(
                    action_id=action_id, operation=operation, basis_revision=basis_revision, intent=request,
                    run_id=run_id, request_id=request_id, account_id=self.account_id,
                    client_instance_id=client_instance_id, fight_instance_id=basis_fight_instance_id,
                )
            except Exception:
                pass

        spec = runtime_operation_spec(operation)
        if spec is None:
            result = self._blocked(f"unsupported runtime action: {operation}")
        else:
            handler = getattr(self, spec.handler_name)
            try:
                handler_request = prepare_handler_request(
                    spec, request, runtime_context=runtime, action_id=action_id,
                )
                result = handler(handler_request)
            except (KeyError, TypeError, ValueError) as exc:
                result = self._blocked(f"invalid {operation} request: {exc}")

        result = dict(result)
        if spec is not None and spec.normalize_combat_result:
            input_diagnostic = self._result_input_diagnostic(result)
            result = self._normalize_combat_result_contract(
                operation, result, input_diagnostic=input_diagnostic,
            )
        result.setdefault("action_id", action_id)

        # A SENT operation may move into a passive reconciliation transaction.
        # Preserve the exact physical origin in durable safety state before the
        # lock is released and diagnostics are notified.
        if (
            str(result.get("status") or "").upper() in {"RECONCILING", "IN_PROGRESS"}
            and (
                self._uncertainty_is_combat_move()
                or self._uncertainty_is_combat_cast()
                or self._uncertainty_is_combat_end_turn()
                or self._uncertainty_is_world_transition()
                or self._uncertainty_is_fight_placement()
            )
        ):
            context = dict(self._uncertain_context or {})
            context.setdefault("origin_action_id", str(action_id))
            context.setdefault("operation", str(operation))
            self._uncertain_context = context
            if self._safety is not None and self._uncertain_detail is not None:
                self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)
            result.setdefault("origin_action_id", str(action_id))
            result.setdefault("record_kind", "PHYSICAL_ACTION")
            result.setdefault("physical_input_event", True)

        result.setdefault("control_authority", dict(authority))
        self._finalize_prepared_input_from_result(result)
        result = decorate_transaction_observation(result, action_id=action_id)
        return result, run_id, request_id, basis_revision

    @staticmethod
    def _normalize_combat_result_contract(
        operation: str, result: dict, *, input_diagnostic: dict | None = None,
    ) -> dict:
        """Make every non-success combat outcome diagnostically classifiable.

        This is an observability/liveness contract only.  It never upgrades an
        UNKNOWN/UNCERTAIN action into a retry-safe action and it never fabricates
        a physical send state.  Precise handler evidence always wins; generic
        values exist only so the controller/debugger never receives an
        unclassifiable terminal combat result.
        """
        row = dict(result or {})
        status = str(row.get("status") or "UNKNOWN").upper()
        if status in {"CONFIRMED", "SETTLED", "SUCCESS", "OK"}:
            return row

        failure_code = str(row.get("failure_code") or "").strip()
        if not failure_code:
            detail = str(row.get("detail") or "")
            # Preserve the most causal lower-boundary classification we can prove.
            # R5.145 normalization is allowed to fill missing structure, but must
            # never hide a precise input/window failure behind a generic combat code.
            if status == "UNCERTAIN":
                failure_code = (
                    FailureCode.INPUT_UNCERTAIN.value
                    if ("send state" in detail.lower() or "certainly sent" in detail.lower())
                    else FailureCode.ACTION_CONFIRM_TIMEOUT.value
                )
            elif status == "CONFIRMED_UNSETTLED":
                failure_code = FailureCode.ACTION_SETTLEMENT_TIMEOUT.value
            elif status == "BLOCKED":
                diagnostic_code = str((input_diagnostic or {}).get("failure_code") or "").strip()
                if diagnostic_code:
                    failure_code = diagnostic_code
                elif "UNCERTAIN_FENCE" in detail:
                    failure_code = FailureCode.ACTION_UNCERTAIN_FENCE.value
                elif "projection" in detail.lower():
                    failure_code = FailureCode.PROJECTION_STALE.value
                elif "not sent" in detail.lower():
                    failure_code = FailureCode.INPUT_NOT_SENT.value
                elif "settled/decision-ready" in detail or "runtime health" in detail:
                    failure_code = FailureCode.ACTION_BLOCKED_READINESS.value
            if not failure_code:
                failure_code = FailureCode.COMBAT_ACTION_UNCLASSIFIED.value
            row["failure_code"] = failure_code

        # Infer NOT_SENT only for known pre-input failures; never infer SENT from timeout.
        pre_input_codes = {
            FailureCode.WINDOW_NOT_FOUND.value, FailureCode.WINDOW_AMBIGUOUS.value,
            FailureCode.WINDOW_IDENTITY_CHANGED.value, FailureCode.WINDOW_FOCUS_FAILED.value,
            FailureCode.CLIENT_SIZE_MISMATCH.value, FailureCode.INPUT_INTEGRITY_MISMATCH.value,
            FailureCode.INPUT_INTEGRITY_UNAVAILABLE.value, FailureCode.DPI_CONTEXT_FAILURE.value,
            FailureCode.PROJECTION_BRIDGE_OFFLINE.value, FailureCode.PROJECTION_MAP_MISMATCH.value,
            FailureCode.PROJECTION_STALE.value, FailureCode.PROJECTION_CELL_UNAVAILABLE.value,
            FailureCode.PROJECTION_OUTSIDE_VIEWPORT.value, FailureCode.SPELL_TARGET_INTERACTION_UNVERIFIED.value,
            FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value,
            FailureCode.CAST_ADMISSION_REJECTED.value, FailureCode.CAST_ADMISSION_UNKNOWN.value,
            FailureCode.MOVE_ADMISSION_REJECTED.value, FailureCode.MOVE_ADMISSION_UNKNOWN.value,
            FailureCode.INVALID_COMBAT_ACTION_CONTRACT.value, FailureCode.ACTION_BLOCKED_READINESS.value,
            FailureCode.ACTION_EXECUTION_LEASE_DENIED.value, FailureCode.CONTROL_AUTHORITY_DISARMED.value,
            FailureCode.CONTROL_SESSION_MISMATCH.value, FailureCode.CONTROL_RUN_REQUIRED.value,
            FailureCode.CONTROL_RUN_MISMATCH.value, FailureCode.CONTROL_SCRIPT_MISMATCH.value,
            FailureCode.CONTROL_AUTHORITY_BLOCKED.value, FailureCode.CONTROL_CORRELATION_UNSUPPORTED.value,
            FailureCode.INPUT_NOT_SENT.value,
            "DOMAIN_CHANGED_BEFORE_INPUT", "FIGHT_STATE_CHANGED_BEFORE_INPUT",
            "FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET", "CAST_TARGET_AUTHORIZATION_STALE",
            "LOCAL_FIGHTER_IDENTITY_CONFLICT", "LOCAL_FIGHTER_IDENTITY_NOT_CONVERGED",
        }
        if "physical_send_state" not in row:
            if failure_code in pre_input_codes:
                row["physical_send_state"] = PhysicalSendState.NOT_SENT.value
            elif failure_code == FailureCode.INPUT_UNCERTAIN.value:
                row["physical_send_state"] = PhysicalSendState.UNCERTAIN.value
            else:
                row["physical_send_state"] = "UNKNOWN"
        row.setdefault("safe_replan", False)
        row.setdefault("reconciliation_required", status == "RECONCILING")

        boundary = None
        owner = None
        if failure_code == FailureCode.COMBAT_MOVE_RESOURCE_PENDING.value:
            boundary, owner = "COMBAT_MOVE_RESOURCE_SETTLEMENT", "CANONICAL_STATE"
        elif failure_code == FailureCode.COMBAT_MOVE_CAUSALITY_PENDING.value:
            boundary, owner = "COMBAT_MOVE_SETTLEMENT", "EXECUTION_SERVICE"
        elif failure_code == FailureCode.COMBAT_CAST_CAUSALITY_PENDING.value:
            boundary, owner = "COMBAT_CAST_SETTLEMENT", "EXECUTION_SERVICE"
        elif failure_code == FailureCode.COMBAT_END_TURN_CAUSALITY_PENDING.value:
            boundary, owner = "COMBAT_END_TURN_SETTLEMENT", "EXECUTION_SERVICE"
        elif failure_code == FailureCode.CLIENT_CAST_REJECTED.value:
            boundary, owner = "CLIENT_SEMANTIC_CAST_REQUEST", "CLIENT_INTERACTION"
        elif failure_code == FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value:
            boundary, owner = "CLIENT_TARGET_INTERACTION_SURFACE", "CLIENT_INTERACTION"
        elif failure_code == FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value:
            boundary, owner = "WORLD_DESTINATION_CONFIRMATION", "LIVE_CONFIRMATION_OR_TRANSPORT"
        elif failure_code == FailureCode.WORLD_TRANSITION_TARGET_MISMATCH.value:
            boundary, owner = "WORLD_DESTINATION_INTEGRITY", "CANONICAL_WORLD_OR_ROUTE_EXECUTION"
        elif failure_code in {
            FailureCode.CAST_ADMISSION_REJECTED.value, FailureCode.CAST_ADMISSION_UNKNOWN.value,
            FailureCode.MOVE_ADMISSION_REJECTED.value, FailureCode.MOVE_ADMISSION_UNKNOWN.value,
        }:
            boundary, owner = "LATEST_STATE_ADMISSION", "EXECUTION_ADMISSION"
        elif failure_code == FailureCode.INVALID_COMBAT_ACTION_CONTRACT.value:
            boundary, owner = "FIGHT_ACTION_CONTRACT", "FIGHT_RUNTIME"
        elif failure_code in {
            FailureCode.WINDOW_NOT_FOUND.value, FailureCode.WINDOW_AMBIGUOUS.value,
            FailureCode.WINDOW_IDENTITY_CHANGED.value, FailureCode.WINDOW_FOCUS_FAILED.value,
            FailureCode.CLIENT_SIZE_MISMATCH.value, FailureCode.INPUT_INTEGRITY_MISMATCH.value,
            FailureCode.INPUT_INTEGRITY_UNAVAILABLE.value, FailureCode.DPI_CONTEXT_FAILURE.value,
        }:
            boundary, owner = "WINDOW_IDENTITY_OR_FOCUS", "WINDOW_INPUT"
        elif failure_code in {
            FailureCode.PROJECTION_BRIDGE_OFFLINE.value, FailureCode.PROJECTION_MAP_MISMATCH.value,
            FailureCode.PROJECTION_STALE.value, FailureCode.PROJECTION_CELL_UNAVAILABLE.value,
            FailureCode.PROJECTION_OUTSIDE_VIEWPORT.value, FailureCode.SPELL_TARGET_INTERACTION_UNVERIFIED.value,
        }:
            boundary, owner = "SCREEN_PROJECTION", "PROJECTION"
        elif failure_code == FailureCode.INPUT_NOT_SENT.value:
            boundary, owner = "PHYSICAL_INPUT_SEND", "INPUT_DRIVER"
        elif failure_code in {FailureCode.INPUT_UNCERTAIN.value, FailureCode.ACTION_UNCERTAIN_FENCE.value}:
            boundary, owner = "PHYSICAL_INPUT_CERTAINTY", "INPUT_DRIVER"
        elif failure_code == FailureCode.ACTION_EXECUTION_LEASE_DENIED.value:
            boundary, owner = "INPUT_ARBITER_LEASE", "INPUT_ARBITER"
        elif failure_code in {
            FailureCode.CONTROL_AUTHORITY_DISARMED.value, FailureCode.CONTROL_SESSION_MISMATCH.value,
            FailureCode.CONTROL_RUN_REQUIRED.value, FailureCode.CONTROL_RUN_MISMATCH.value,
            FailureCode.CONTROL_SCRIPT_MISMATCH.value, FailureCode.CONTROL_AUTHORITY_BLOCKED.value,
            FailureCode.CONTROL_CORRELATION_UNSUPPORTED.value,
        }:
            boundary, owner = "CONTROL_AUTHORITY", "EXECUTION_CONTROL"
        elif failure_code == FailureCode.ACTION_BLOCKED_READINESS.value:
            boundary, owner = "SEMANTIC_CONTROL_READINESS", "FIGHT_RUNTIME"
        elif failure_code in {FailureCode.ACTION_CONFIRM_TIMEOUT.value, FailureCode.ACTION_SETTLEMENT_TIMEOUT.value}:
            boundary, owner = "CANONICAL_SETTLEMENT", "STATE_SETTLEMENT"
        elif failure_code in {"DOMAIN_CHANGED_BEFORE_INPUT", "FIGHT_STATE_CHANGED_BEFORE_INPUT"}:
            boundary, owner = "PRE_INPUT_STATE_REVALIDATION", "EXECUTION_SERVICE"
        elif failure_code in {"FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET", "CAST_TARGET_AUTHORIZATION_STALE"}:
            boundary, owner = "PRE_TARGET_STATE_REVALIDATION", "EXECUTION_SERVICE"
        elif failure_code in {"LOCAL_FIGHTER_IDENTITY_CONFLICT", "LOCAL_FIGHTER_IDENTITY_NOT_CONVERGED"}:
            boundary, owner = "LOCAL_FIGHTER_IDENTITY", "CANONICAL_STATE"
        elif failure_code == FailureCode.COMBAT_ACTION_UNCLASSIFIED.value:
            boundary, owner = "COMBAT_EXECUTION", "EXECUTION_SERVICE"
        row.setdefault("first_missing_boundary", boundary or "COMBAT_EXECUTION")
        row.setdefault("likely_owner", owner or "EXECUTION_SERVICE")
        row.setdefault("operation", str(operation))
        return row

    def _input_debug_snapshot(self) -> dict:
        """Return one best-effort immutable snapshot of the physical input boundary.

        The driver diagnostic is mutable and later focus/identity checks may replace
        it. Callers that have just attempted physical input must persist this
        snapshot in the action result immediately rather than asking the driver
        again after semantic settlement polling.
        """
        # Prefer immutable physical-boundary evidence over mutable debug_status().
        if hasattr(self.input, "last_input_transaction"):
            try:
                value = self.input.last_input_transaction()
                if isinstance(value, dict) and value:
                    return dict(value)
            except Exception:
                pass
        if not hasattr(self.input, "debug_status"):
            return {}
        try:
            value = self.input.debug_status()
            return dict(value) if isinstance(value, dict) else {}
        except Exception:
            return {}

    def _result_input_diagnostic(self, result: dict) -> dict:
        explicit = result.get("physical_input_evidence")
        if isinstance(explicit, dict) and explicit:
            return dict(explicit)
        # Do not attach the driver's *previous* transaction to a current action
        # that explicitly proves no physical input was sent. In R5.162 repeated
        # projection blockers inherited stale F7/map-click diagnostics, making a
        # pre-input acquisition race look like fresh mouse activity.
        if str(result.get("physical_send_state") or "").upper() == PhysicalSendState.NOT_SENT.value:
            return {
                "status": "NO_CURRENT_ACTION_INPUT",
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "current_action_input_evidence": False,
            }
        ready = result.get("ready_input_evidence")
        if isinstance(ready, dict):
            after = ready.get("after")
            if isinstance(after, dict) and after:
                return dict(after)
        phases = result.get("physical_input_phases")
        if isinstance(phases, list):
            for raw in reversed(phases):
                if not isinstance(raw, dict):
                    continue
                evidence = raw.get("input_evidence")
                if isinstance(evidence, dict) and evidence:
                    return dict(evidence)
        return self._input_debug_snapshot()

    def _record_observed_result(self, *, action_id: str, operation: str, result: dict, run_id, request_id, basis_revision) -> None:
        if self.observability is None:
            return
        status = str(result.get("status") or "UNKNOWN")
        detail = str(result.get("detail") or "")
        input_diagnostic = self._result_input_diagnostic(result)
        code = None
        explicit_code = result.get("failure_code")
        has_explicit_code = bool(explicit_code)
        if explicit_code:
            try:
                code = FailureCode(str(explicit_code))
            except ValueError:
                code = str(explicit_code)
        if code is None and status == "UNCERTAIN":
            code = FailureCode.INPUT_UNCERTAIN if ("send state" in detail or "certainly sent" in detail) else FailureCode.ACTION_CONFIRM_TIMEOUT
        elif code is None and status == "CONFIRMED_UNSETTLED":
            code = FailureCode.ACTION_SETTLEMENT_TIMEOUT
        elif code is None and status == "BLOCKED":
            if "UNCERTAIN_FENCE" in detail:
                code = FailureCode.ACTION_UNCERTAIN_FENCE
            elif "projection" in detail.lower():
                code = FailureCode.PROJECTION_STALE
            elif "not sent" in detail.lower():
                code = FailureCode.INPUT_NOT_SENT
            elif "settled/decision-ready" in detail or "runtime health" in detail:
                code = FailureCode.ACTION_BLOCKED_READINESS
        arbiter_diagnostic = {}
        if self.input_arbiter is not None:
            try:
                snapshot = getattr(self.input_arbiter, "snapshot", None)
                if callable(snapshot):
                    arbiter_diagnostic = dict(snapshot())
                else:
                    arbiter_diagnostic = {
                        "active_owner": self.input_arbiter.active_owner,
                        "previous_owner": self.input_arbiter.previous_owner,
                        "last_released_owner": self.input_arbiter.last_released_owner,
                        "handoff_changed": self.input_arbiter.handoff_changed,
                        "handoff_sequence": self.input_arbiter.handoff_sequence,
                    }
            except Exception:
                arbiter_diagnostic = {}
        diagnostic_code=input_diagnostic.get("failure_code")
        if status == "BLOCKED" and diagnostic_code and not has_explicit_code:
            # A precise input-boundary code (for example WINDOW_NOT_FOUND) is
            # more causal than an inferred generic INPUT_NOT_SENT classification.
            # Never override an explicit result failure such as CONTROL_* though.
            try:
                code=FailureCode(str(diagnostic_code))
            except ValueError:
                code=str(diagnostic_code)
        try:
            self.observability.record_action_result(
                action_id=action_id, status=status, failure_code=code, detail=detail or None,
                confirmed_revision=result.get("confirmed_revision") or result.get("server_confirmed_revision"),
                settled_revision=result.get("settled_revision"),
                result=dict(result),
            )
            # Projection staleness is a pre-input acquisition race and is normally
            # recoverable by re-reading canonical/projection state.  Keep it in the
            # forensic journal, but do not promote a successful automatic recovery
            # into a critical incident bundle.
            if status in {"IN_PROGRESS", "RETRYABLE", "RECONCILING"}:
                severity = "WARNING" if status in {"RETRYABLE", "RECONCILING"} else "INFO"
            elif code is FailureCode.PROJECTION_STALE and status == "BLOCKED":
                severity = "WARNING"
            elif code is FailureCode.CONTROL_AUTHORITY_DISARMED and status == "BLOCKED":
                # Consequence-only denial after an earlier incident revoked the
                # run permit. Keep it searchable without flooding the ERROR
                # stream or obscuring the first causal failure.
                severity = "INFO"
            elif code in {
                FailureCode.CAST_ADMISSION_REJECTED, FailureCode.CAST_ADMISSION_UNKNOWN,
                FailureCode.MOVE_ADMISSION_REJECTED, FailureCode.MOVE_ADMISSION_UNKNOWN,
            } and status == "BLOCKED":
                # Pre-input safety gate: no semantic game action was sent. Keep
                # forensic visibility without classifying successful fail-closed
                # admission/replan as a terminal mission execution error.
                severity = "WARNING"
            elif code is FailureCode.CLIENT_CAST_REJECTED and status == "BLOCKED":
                # Physical mouse input occurred, but continuous transport evidence
                # proves Dofus emitted no semantic cast request. Safe to replan,
                # but still important enough to preserve as an anomaly.
                severity = "WARNING"
            elif (
                str(code or "") == "READY_PREARMED_FOREGROUND_LOST"
                and status == "BLOCKED"
                and result.get("retry_allowed") is True
                and str(result.get("physical_send_state") or "NOT_SENT").upper() == "NOT_SENT"
            ):
                # A pre-armed Ready window losing foreground is a *successful
                # fail-closed recovery boundary*: no click was sent and the party
                # controller will re-arm on a later tick. It must remain visible
                # without poisoning successful-run root-cause selection.
                severity = "WARNING"
            else:
                severity = "ERROR" if (code is not None and status in {"UNCERTAIN", "FAILED", "BLOCKED", "CONFIRMED_UNSETTLED"}) else "INFO"
            self.observability.record_event(
                component="execution", event_type=f"action_{status.lower()}",
                severity=severity, failure_code=code,
                run_id=run_id, request_id=request_id, action_id=action_id, canonical_revision=basis_revision,
                account_id=self.account_id,
                client_instance_id=(self.input.client_instance_id() if hasattr(self.input, "client_instance_id") else None),
                context={
                    "operation": operation, "detail": detail, "result": result,
                    "input": input_diagnostic, "arbiter": arbiter_diagnostic,
                },
            )
        except Exception:
            # Diagnostics are fail-open with respect to game execution. The journal
            # has its own emergency fallback; observability must never become a
            # second execution failure mode.
            pass
        finally:
            if code in {
                FailureCode.INPUT_UNCERTAIN, FailureCode.INPUT_NOT_SENT, FailureCode.WINDOW_NOT_FOUND,
                FailureCode.WINDOW_AMBIGUOUS, FailureCode.WINDOW_IDENTITY_CHANGED, FailureCode.WINDOW_FOCUS_FAILED,
                FailureCode.CLIENT_SIZE_MISMATCH, FailureCode.INPUT_INTEGRITY_MISMATCH,
                FailureCode.ACTION_CONFIRM_TIMEOUT, FailureCode.ACTION_SETTLEMENT_TIMEOUT,
                FailureCode.ACTION_UNCERTAIN_FENCE,
                FailureCode.WORLD_TRANSITION_TARGET_MISMATCH,
                FailureCode.CONTROL_SESSION_MISMATCH,
                FailureCode.CONTROL_RUN_REQUIRED, FailureCode.CONTROL_RUN_MISMATCH,
                FailureCode.CONTROL_SCRIPT_MISMATCH, FailureCode.CONTROL_AUTHORITY_BLOCKED,
                FailureCode.CONTROL_CORRELATION_UNSUPPORTED,
                FailureCode.WORLD_INTERACTION_RETRY_EXHAUSTED,
                FailureCode.WORLD_INTERACTION_SETTLEMENT_TIMEOUT, FailureCode.WORLD_INTERACTION_TARGET_MISMATCH,
                FailureCode.WORLD_INTERACTION_EVIDENCE_UNAVAILABLE,
                # Client-side rejection is rare and indicates a remaining
                # readiness/interaction mismatch, so preserve one incident bundle.
                FailureCode.CLIENT_CAST_REJECTED,
            } and self.critical_debug_export is not None:
                try:
                    try:
                        self.critical_debug_export(
                            failure_code=(code.value if isinstance(code, FailureCode) else str(code or "UNREGISTERED_RUNTIME_FAILURE")),
                            component="execution",
                            account_id=self.account_id,
                            context={
                                "operation": operation, "action_id": action_id,
                                "request_id": request_id, "run_id": run_id,
                                "status": status, "detail": detail,
                                "result": dict(result),
                            },
                        )
                    except TypeError:
                        # Backward-compatible callback contract for lightweight
                        # harnesses and single-account legacy wiring.
                        self.critical_debug_export()
                except Exception:
                    pass

    def _readiness_from_snapshot(self, current: CanonicalSnapshot) -> dict:
        if self._uncertain_detail is not None:
            return {
                "status": "BLOCKED",
                "reason": "UNCERTAIN_FENCE",
                "missing_requirements": ["manual_or_authoritative_uncertain_resolution"],
                "detail": self._uncertain_detail,
            }
        if self._pending_settlement is not None:
            payload = readiness_payload(current, self._pending_settlement)
            if payload["status"] != "READY":
                return payload
            self._pending_settlement = None
            if self._safety is not None:
                self._safety.set_pending(None)
        return local_turn_readiness_payload(current)

    def _guard_runtime_health(self) -> dict | None:
        if self.runtime_health_provider is None:
            return None
        try:
            health = dict(self.runtime_health_provider())
        except Exception as exc:
            return self._blocked(f"runtime health unavailable: {type(exc).__name__}: {exc}")
        if health.get("status") == "READY":
            return None
        blockers = [str(item) for item in (health.get("blockers") or ()) if str(item)]
        detail = ", ".join(blockers) if blockers else str(health.get("detail") or "UNKNOWN")
        return self._blocked(f"runtime health not ready: {detail}")

    def _guard_readiness(self, current: CanonicalSnapshot) -> dict | None:
        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return runtime_block

        # R5.151: a world-transition click may be physically SENT while its map
        # confirmation arrives after the short execution confirmation window.
        # Treat that as a durable passive transaction, not a generic uncertain
        # fence.  Active reconciliation is deliberately stricter than terminal
        # cleanup: it only clears when the intended destination itself is freshly
        # observed, so no duplicate world click can be emitted while the original
        # request might still be in flight.
        if self._uncertainty_is_world_transition():
            reconciliation = self._reconcile_world_transition_uncertainty_locked(
                reason="ACTIVE_RUNTIME_READINESS", require_target_match=True
            )
            reconciliation_status = str(reconciliation.get("status") or "").upper()
            if reconciliation_status == "MISMATCH":
                context = dict(self._uncertain_context or {})
                return {
                    "status": "UNCERTAIN",
                    "failure_code": FailureCode.WORLD_TRANSITION_TARGET_MISMATCH.value,
                    "detail": "world transition resolved to a fresh authoritative map different from the requested destination",
                    "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                    "retry_allowed": False,
                    "physical_retry_allowed": False,
                    "safe_replan": False,
                    "reconciliation_required": False,
                    "input_quarantined": True,
                    "first_missing_boundary": "WORLD_DESTINATION_INTEGRITY",
                    "likely_owner": "CANONICAL_WORLD_OR_ROUTE_EXECUTION",
                    "origin_action_id": context.get("origin_action_id"),
                    "source_map_id": context.get("source_map_id"),
                    "target_map_id": context.get("target_map_id"),
                    "observed_map_id": reconciliation.get("current_world_map_id"),
                    "basis_revision": context.get("basis_revision"),
                    "reconciliation": reconciliation,
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": context.get("origin_action_id"),
                }
            if reconciliation_status != "RECONCILED":
                context = dict(self._uncertain_context or {})
                return {
                    "status": "RECONCILING",
                    "failure_code": FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                    "detail": self._uncertain_detail or "world transition confirmation is still pending",
                    "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                    "retry_allowed": True,
                    "physical_retry_allowed": False,
                    "safe_replan": False,
                    "reconciliation_required": True,
                    "input_quarantined": True,
                    "first_missing_boundary": "WORLD_DESTINATION_CONFIRMATION",
                    "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
                    "origin_action_id": context.get("origin_action_id"),
                    "source_map_id": context.get("source_map_id"),
                    "target_map_id": context.get("target_map_id"),
                    "basis_revision": context.get("basis_revision"),
                    "reconciliation": reconciliation,
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": context.get("origin_action_id"),
                }
            current = self.state.snapshot()

        if self._uncertainty_is_fight_placement():
            reconciliation = self._reconcile_fight_placement_uncertainty_locked(
                reason="ACTIVE_RUNTIME_READINESS"
            )
            if str(reconciliation.get("status") or "").upper() != "RECONCILED":
                context = dict(self._uncertain_context or {})
                return {
                    "status": "IN_PROGRESS",
                    "failure_code": FailureCode.FIGHT_PLACEMENT_CAUSALITY_PENDING.value,
                    "detail": self._uncertain_detail or "fight placement confirmation is still pending",
                    "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                    "retry_allowed": True,
                    "physical_retry_allowed": False,
                    "safe_replan": False,
                    "reconciliation_required": True,
                    "input_quarantined": True,
                    "first_missing_boundary": "FIGHT_PLACEMENT_CONFIRMATION",
                    "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
                    "origin_action_id": context.get("origin_action_id"),
                    "fight_instance_id": context.get("fight_instance_id"),
                    "actor_id": context.get("actor_id"),
                    "target_cell_id": context.get("target_cell_id"),
                    "reconciliation": reconciliation,
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": context.get("origin_action_id"),
                }
            current = self.state.snapshot()

        # R5.164: combat transactions are generation-scoped, but their durable
        # uncertainty fence lives in ExecutionService.  The R5.163 live run
        # proved that a SENT End Turn could remain unresolved until the fight
        # terminally disappeared; the next WORLD action then saw a generic
        # ACTION_UNCERTAIN_FENCE and the incident layer correctly (but
        # unnecessarily) revoked control.  Reconcile every supported combat
        # uncertainty here before interpreting it as an opaque safety failure.
        # This emits no input.  A finished/changed fight, turn handoff or exact
        # canonical action evidence can close the old transaction; otherwise
        # input stays quarantined and the caller receives the precise causal
        # pending code rather than a hard generic fence.
        combat_reconciliation = None
        if self._uncertainty_is_combat_move():
            combat_reconciliation = self._reconcile_combat_move_uncertainty_locked(
                reason="ACTIVE_RUNTIME_READINESS"
            )
        elif self._uncertainty_is_combat_cast():
            combat_reconciliation = self._reconcile_combat_cast_uncertainty_locked(
                reason="ACTIVE_RUNTIME_READINESS"
            )
        elif self._uncertainty_is_combat_end_turn():
            combat_reconciliation = self._reconcile_combat_end_turn_uncertainty_locked(
                reason="ACTIVE_RUNTIME_READINESS"
            )

        if combat_reconciliation is not None:
            reconciliation_status = str(combat_reconciliation.get("status") or "").upper()
            if reconciliation_status == "RECONCILED":
                current = self.state.snapshot()
            elif reconciliation_status == "WAITING":
                context = dict(self._uncertain_context or {})
                failure_code = str(
                    combat_reconciliation.get("failure_code")
                    or FailureCode.ACTION_UNCERTAIN_FENCE.value
                )
                return {
                    **dict(combat_reconciliation),
                    "status": "RECONCILING",
                    "failure_code": failure_code,
                    "detail": self._uncertain_detail or str(
                        combat_reconciliation.get("reason")
                        or "combat action confirmation is still pending"
                    ),
                    "physical_send_state": str(
                        combat_reconciliation.get("physical_send_state")
                        or context.get("physical_send_state")
                        or PhysicalSendState.UNCERTAIN.value
                    ),
                    "retry_allowed": True,
                    "physical_retry_allowed": False,
                    "safe_replan": False,
                    "reconciliation_required": True,
                    "input_quarantined": True,
                    "origin_action_id": combat_reconciliation.get("origin_action_id")
                    or context.get("origin_action_id"),
                    "reconciliation": dict(combat_reconciliation),
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": combat_reconciliation.get("origin_action_id")
                    or context.get("origin_action_id"),
                }
            # RETAINED/NOT_APPLICABLE is deliberately *not* softened. An
            # incomplete or unrecognised durable fence remains a hard safety
            # condition and falls through to the generic fail-closed path.

        readiness = self._readiness_from_snapshot(current)
        if readiness["status"] == "READY":
            return None
        if readiness.get("reason") == "UNCERTAIN_FENCE":
            context = dict(self._uncertain_context or {})
            return {
                "status": "BLOCKED",
                "failure_code": FailureCode.ACTION_UNCERTAIN_FENCE.value,
                "detail": f"UNCERTAIN_FENCE active: {readiness.get('detail') or 'physical outcome unresolved'}",
                "physical_send_state": str(
                    context.get("physical_send_state") or PhysicalSendState.UNCERTAIN.value
                ),
                "retry_allowed": False,
                "physical_retry_allowed": False,
                "safe_replan": False,
                "reconciliation_required": True,
                "input_quarantined": True,
                "first_missing_boundary": "EXECUTION_SAFETY",
                "likely_owner": "EXECUTION_SERVICE",
                "origin_action_id": context.get("origin_action_id"),
                "origin_operation": context.get("operation"),
                "origin_fight_instance_id": context.get("fight_instance_id"),
                "uncertainty_context": context,
                "record_kind": "TRANSACTION_OBSERVATION" if context.get("origin_action_id") else "ACTION_RESULT",
                "physical_input_event": False,
                "observation_of_action_id": context.get("origin_action_id"),
            }
        return self._blocked(
            "confirmed live state is not settled/decision-ready; "
            f"waiting for {', '.join(readiness.get('missing_requirements') or [])}"
        )

    def _decision_readiness_unlocked(self) -> dict:
        return self._readiness_from_snapshot(self.state.snapshot())

    def decision_readiness(self) -> dict:
        with self._lock:
            return self._decision_readiness_unlocked()

    def _attempt_key(self, revision: int, operation: str, payload: dict) -> tuple[int, str, tuple[tuple[str, object], ...]]:
        normalized: list[tuple[str, object]] = []
        for key, value in sorted(payload.items()):
            if isinstance(value, (str, int, float, bool, type(None))):
                normalized.append((str(key), value))
            else:
                normalized.append((str(key), repr(value)))
        return revision, operation, tuple(normalized)

    def _advance_attempt_revision(self, revision: int) -> None:
        revision = int(revision)
        if self._attempted_revision != revision:
            self._attempted.clear()
            self._attempted_revision = revision

    def _mark_sent(self, key) -> None:
        self._advance_attempt_revision(int(key[0]))
        self._attempted.add(key)

    def _guard_new_attempt(self, key) -> dict | None:
        self._advance_attempt_revision(int(key[0]))
        if key in self._attempted:
            return self._blocked("same physical action was already attempted at this canonical revision; retry forbidden")
        return None

    def _preparation_local_identity(self, snapshot: CanonicalSnapshot, payload: dict | None = None):
        data = dict(payload or {})
        causal_actor_id = data.get("local_actor_id_hint")
        causal_source = data.get("local_actor_source")
        # Do not bridge account ownership from world.player_actor_id. The live
        # R5.162 failure demonstrated that provisional JPQ transition evidence
        # can identify another controlled party member. Only an explicit
        # generation-scoped causal hint may bridge delayed canonical identity.
        return resolve_local_fighter_identity(
            snapshot,
            expected_fight_instance_id=data.get("fight_instance_id"),
            causal_actor_id=causal_actor_id,
            causal_source=causal_source,
        )

    def _semantic_control_readiness(
        self,
        control: str,
        snapshot: CanonicalSnapshot,
        *,
        local_actor_id: int | None = None,
    ) -> dict:
        """Return whether a fixed UI control is semantically valid *now*.

        Calibration answers where a control is when rendered; it is never proof
        that the control is currently present.  This gate keeps those concerns
        separate so future fixed-coordinate controls cannot repeat the R5.83
        JOIN_FIGHT misclick class.
        """
        name = str(control).upper()
        fight = snapshot.fight

        if name == "JOIN_FIGHT":
            lifecycle = fight.discovered_join_lifecycle
            joinable = fight.discovered_joinable
            presentation = fight.discovered_presentation_id
            ready = (
                presentation.status is ValueStatus.KNOWN
                and lifecycle.status is ValueStatus.KNOWN
                and str(lifecycle.value) == "PRESENTED"
                and joinable.status is ValueStatus.KNOWN
                and joinable.value is True
            )
            return {
                "ready": bool(ready),
                "satisfied": False,
                "code": None if ready else "PRESENTATION_NOT_READY",
                "detail": "same-generation JOIN_FIGHT presentation is proven" if ready else "fight exists but JOIN_FIGHT presentation is not proven",
            }

        if name == "READY":
            if not fight.present:
                return {"ready": False, "satisfied": False, "code": "CONTROL_STATE_NOT_READY", "detail": "no fight is present"}
            local_id = int(local_actor_id) if local_actor_id is not None else None
            if local_id is None:
                local_id = authoritative_canonical_local_actor_id(snapshot)
            if local_id is not None:
                actor = next((item for item in fight.actors if int(item.actor_id) == local_id), None)
                if (
                    actor is not None
                    and actor.placement_ready.status is ValueStatus.KNOWN
                    and actor.placement_ready.value is True
                ):
                    return {
                        "ready": False,
                        "satisfied": True,
                        "code": None,
                        "detail": "local fighter Ready acknowledgement is already confirmed",
                        "actor_id": local_id,
                        "ready_revision": int(actor.observed.ready_revision),
                    }
            if fight.active_actor_id.status is ValueStatus.KNOWN:
                return {
                    "ready": False,
                    "satisfied": False,
                    "code": "READY_ACK_MISSING_AFTER_ACTIVE",
                    "detail": "fight is already active but the local fighter Ready acknowledgement is not proven",
                }
            phase = fight.phase
            ready = phase.status is ValueStatus.KNOWN and str(phase.value) == "PLACEMENT"
            return {
                "ready": bool(ready),
                "satisfied": False,
                "code": None if ready else "CONTROL_STATE_NOT_READY",
                "detail": "fight placement phase is proven" if ready else "placement phase is not proven; fixed preparation control must not be clicked",
            }

        if name == "CHOOSE_CHALLENGE":
            if not fight.present:
                return {"ready": False, "satisfied": False, "code": "CONTROL_STATE_NOT_READY", "detail": "no fight is present"}
            if fight.active_actor_id.status is ValueStatus.KNOWN:
                return {"ready": False, "satisfied": True, "code": None, "detail": "fight is already active; challenge preparation control is no longer needed"}
            phase = fight.phase
            ready = phase.status is ValueStatus.KNOWN and str(phase.value) == "PLACEMENT"
            return {
                "ready": bool(ready),
                "satisfied": False,
                "code": None if ready else "CONTROL_STATE_NOT_READY",
                "detail": "fight placement phase is proven" if ready else "placement phase is not proven; fixed preparation control must not be clicked",
            }

        if name == "END_TURN":
            if not fight.present:
                return {"ready": False, "satisfied": False, "code": "CONTROL_STATE_NOT_READY", "detail": "no fight is present"}
            local_id = authoritative_canonical_local_actor_id(snapshot)
            active = fight.active_actor_id
            ready = (
                local_id is not None
                and active.status is ValueStatus.KNOWN
                and int(local_id) == int(active.value)
            )
            if ready and fight.phase.status is ValueStatus.KNOWN and str(fight.phase.value) != "ACTIVE":
                ready = False
            return {
                "ready": bool(ready),
                "satisfied": False,
                "code": None if ready else "CONTROL_STATE_NOT_READY",
                "detail": "local actor owns the active turn" if ready else "local active turn is not proven; END_TURN must not be clicked",
            }

        return {"ready": True, "satisfied": False, "code": None, "detail": "no semantic gate is defined for this control"}

    def _client_point(self, group: str, key: str | int) -> tuple[CalibrationPoint, int, int] | None:
        size = self.calibration.client_size
        if size is None:
            return None
        if group == "spell_slots":
            point = self.calibration.spell_slots.get(int(key))
        elif group == "controls":
            point = self.calibration.resolve_control(str(key))
        elif group == "directions":
            point = self.calibration.directions.get(str(key).upper())
        else:
            point = None
        if point is None or not point.verified:
            return None
        return point, size.width, size.height

    def _input_lease(self):
        if self.input_arbiter is None:
            return nullcontext()
        return self.input_arbiter.lease(self.account_id)

    def _execution_safety_block(self) -> str | None:
        """Return a fail-closed persistence blocker before physical input."""
        if self._safety is None:
            return None
        health = self._safety.health()
        if health.get("write_healthy") is not True:
            return "EXECUTION_SAFETY_STORE_FENCED: durable physical-action safety persistence is unavailable"
        return None

    def _guarded_physical_send(self, *, purpose: str, sender: Callable[[], PhysicalSendState], context: dict | None = None) -> PhysicalSendState:
        """Durably prepare a physical input before allowing the driver to send it.

        The marker intentionally survives SENT/UNCERTAIN delivery until the
        operation reaches a semantically safe terminal result or replaces it
        with another durable safety obligation. A crash in between therefore
        becomes a restart fence instead of permission for a blind retry.
        """
        if self._safety is None:
            return sender()
        blocker = self._execution_safety_block()
        if blocker is not None:
            self._uncertain_detail = blocker
            self._uncertain_context = {"kind": "EXECUTION_SAFETY_STORE_FENCED", "purpose": str(purpose)}
            return PhysicalSendState.NOT_SENT
        prior = self._safety.prepared_input()
        payload = {
            "kind": "PHYSICAL_INPUT_PREPARED",
            "purpose": str(purpose),
            "account_id": self.account_id,
            "prepared_monotonic_ns": int(self.monotonic_ns_clock()),
            **dict(context or {}),
        }
        if prior is not None:
            payload["previous_obligation"] = dict(prior)
        try:
            self._safety.prepare_input(payload)
        except ExecutionSafetyStoreError as exc:
            self._uncertain_detail = f"EXECUTION_SAFETY_PREPARE_FAILED: {exc}"
            self._uncertain_context = {"kind": "EXECUTION_SAFETY_PREPARE_FAILED", "purpose": str(purpose)}
            return PhysicalSendState.NOT_SENT
        try:
            sent = sender()
        except Exception:
            # Delivery is now unknown. Keep the durable prepared marker intact.
            raise
        if sent is PhysicalSendState.NOT_SENT:
            try:
                if prior is None:
                    self._safety.clear_prepared_input()
                else:
                    self._safety.prepare_input(prior)
            except ExecutionSafetyStoreError as exc:
                self._uncertain_detail = f"EXECUTION_SAFETY_RESOLUTION_FAILED: {exc}"
                self._uncertain_context = {"kind": "EXECUTION_SAFETY_RESOLUTION_FAILED", "purpose": str(purpose)}
        return sent

    def _finalize_prepared_input_from_result(self, result: dict) -> None:
        """Clear write-ahead input only after a safe semantic terminal boundary."""
        if self._safety is None:
            return
        try:
            prepared = self._safety.prepared_input()
        except Exception:
            return
        if prepared is None:
            return
        status = str(result.get("status") or "").upper()
        safe_terminal = status in {"CONFIRMED", "SETTLED", "SUCCESS", "OK", "READY"}
        explicitly_safe_replan = (
            result.get("safe_replan") is True
            and result.get("retry_allowed") is True
            and result.get("reconciliation_required") is not True
        )
        replaced_by_durable_obligation = False
        try:
            replaced_by_durable_obligation = bool(
                self._safety.uncertain_detail()
                or self._safety.pending() is not None
                or self._safety.world_interaction() is not None
            )
        except Exception:
            replaced_by_durable_obligation = False
        if not (safe_terminal or explicitly_safe_replan or replaced_by_durable_obligation):
            return
        try:
            self._safety.clear_prepared_input()
            self._prepared_input_context = None
        except ExecutionSafetyStoreError as exc:
            self._uncertain_detail = f"EXECUTION_SAFETY_FINALIZE_FAILED: {exc}"
            self._uncertain_context = {"kind": "EXECUTION_SAFETY_FINALIZE_FAILED", "prepared_input": dict(prepared)}

    def _send_client(self, item: tuple[CalibrationPoint, int, int]) -> PhysicalSendState:
        point, width, height = item
        if not self.input.ensure_target_focused():
            return PhysicalSendState.NOT_SENT
        return self._guarded_physical_send(
            purpose="CLIENT_CONTROL_CLICK",
            context={"x": int(point.x), "y": int(point.y)},
            sender=lambda: self.input.click_client(point, expected_width=width, expected_height=height),
        )

    def _send_client_prearmed(self, item: tuple[CalibrationPoint, int, int]) -> PhysicalSendState:
        """Click only if the previously armed target is still foreground.

        Ready is special because live evidence showed the first semantic click could
        be swallowed when foreground activation and the game-control click happened
        in one transaction.  The party controller therefore arms the account on an
        earlier tick.  This helper deliberately skips ``ensure_target_focused``:
        ``click_client`` itself is foreground-only and will return NOT_SENT if the
        target lost focus.  A lost focus must trigger re-arming, never an implicit
        focus switch followed immediately by Ready input.
        """
        point, width, height = item
        return self._guarded_physical_send(
            purpose="PREARMED_CLIENT_CONTROL_CLICK",
            context={"x": int(point.x), "y": int(point.y)},
            sender=lambda: self.input.click_client(point, expected_width=width, expected_height=height),
        )

    def _send_screen(self, point: ScreenPoint) -> PhysicalSendState:
        if not self.input.ensure_target_focused():
            return PhysicalSendState.NOT_SENT
        return self._guarded_physical_send(
            purpose="SCREEN_CLICK",
            context={"x": int(point.x), "y": int(point.y)},
            sender=lambda: self.input.click(point),
        )

    def _projection_reference_client_point(self, projection: ProjectionResult) -> ScreenPoint | None:
        """Normalize bridge client coordinates into the calibration reference client.

        The injected Unity bridge and the external ANKA process can run under
        different Windows DPI-awareness contexts.  A bridge-relative client point
        is therefore only comparable to calibration after normalizing by the client
        dimensions observed by the bridge when that point was produced.
        """
        size = self.calibration.client_size
        point = projection.client_point
        if size is None or point is None:
            return None
        source_width = projection.source_client_width
        source_height = projection.source_client_height
        if source_width is None or source_height is None:
            return point
        return ScreenPoint(
            x=int(round(int(point.x) * int(size.width) / int(source_width))),
            y=int(round(int(point.y) * int(size.height) / int(source_height))),
        )

    def _projection_reference_safe_client_points(self, projection: ProjectionResult) -> tuple[ScreenPoint, ...]:
        size = self.calibration.client_size
        if size is None or not projection.safe_client_points:
            return ()
        source_width = projection.source_client_width
        source_height = projection.source_client_height
        if source_width is None or source_height is None:
            return tuple(projection.safe_client_points)
        return tuple(
            ScreenPoint(
                x=int(round(int(candidate.x) * int(size.width) / int(source_width))),
                y=int(round(int(candidate.y) * int(size.height) / int(source_height))),
            )
            for candidate in projection.safe_client_points
        )

    def _send_projection(
        self,
        projection: ProjectionResult,
        *,
        pre_down_guard=None,
    ) -> PhysicalSendState:
        """Send a projected cell/entity click through ANKA's client-coordinate authority.

        The Unity bridge may run under a different Windows DPI-awareness context, so
        its absolute screen point is diagnostic only.  Physical input is recomputed
        from a normalized client-relative point by the bound Windows input driver.
        """
        size = self.calibration.client_size
        reference_point = self._projection_reference_client_point(projection)
        if size is None or reference_point is None:
            return PhysicalSendState.NOT_SENT
        point = CalibrationPoint(
            x=int(reference_point.x), y=int(reference_point.y),
            verified=True, source=f"projection:{projection.purpose}",
        )
        safe_reference_points = self._projection_reference_safe_client_points(projection)
        safe_click = getattr(self.input, "click_client_safe", None)
        safe_guarded_click = getattr(self.input, "click_client_safe_guarded", None)
        guarded_click = getattr(self.input, "click_client_guarded", None)
        if safe_reference_points:
            safe_points = tuple(
                CalibrationPoint(
                    x=int(candidate.x), y=int(candidate.y), verified=True,
                    source=f"projection:{projection.purpose}",
                )
                for candidate in safe_reference_points
            )
            if pre_down_guard is not None and callable(safe_guarded_click):
                return self._guarded_physical_send(
                    purpose=str(projection.purpose or "PROJECTION_CLICK"),
                    context={"map_id": int(projection.map_id), "cell_id": int(projection.cell_id)},
                    sender=lambda: safe_guarded_click(
                        point, safe_points=safe_points,
                        expected_width=int(size.width), expected_height=int(size.height),
                        pre_down_guard=pre_down_guard,
                    ),
                )
            if callable(safe_click) and pre_down_guard is None:
                return self._guarded_physical_send(
                    purpose=str(projection.purpose or "PROJECTION_CLICK"),
                    context={"map_id": int(projection.map_id), "cell_id": int(projection.cell_id)},
                    sender=lambda: safe_click(
                        point, safe_points=safe_points,
                        expected_width=int(size.width), expected_height=int(size.height),
                    ),
                )
        if pre_down_guard is not None and callable(guarded_click):
            return self._guarded_physical_send(
                purpose=str(projection.purpose or "PROJECTION_CLICK"),
                context={"map_id": int(projection.map_id), "cell_id": int(projection.cell_id)},
                sender=lambda: guarded_click(
                    point, expected_width=int(size.width), expected_height=int(size.height),
                    pre_down_guard=pre_down_guard,
                ),
            )
        if pre_down_guard is not None:
            # Compatibility for old/dummy input implementations. Production
            # DofusWindowInputDriver runs the guard after pointer arrival.
            guard_result = pre_down_guard(None)
            allowed = bool(guard_result[0]) if isinstance(guard_result, tuple) else bool(guard_result)
            if not allowed:
                return PhysicalSendState.NOT_SENT
        return self._guarded_physical_send(
            purpose=str(projection.purpose or "PROJECTION_CLICK"),
            context={"map_id": int(projection.map_id), "cell_id": int(projection.cell_id)},
            sender=lambda: self.input.click_client(
                point, expected_width=int(size.width), expected_height=int(size.height)
            ),
        )

    def _observed_client_version(self) -> str | None:
        provider = getattr(self.input, "observed_client_version", None)
        if not callable(provider):
            return None
        try:
            value = provider()
        except Exception:
            return None
        token = str(value or "").strip()
        return token or None

    def _wire_binding(self, semantic: ProtocolWireSemantic) -> ProtocolWireBinding | None:
        profile = self._protocol_wire_profile
        if profile is None:
            return None
        try:
            return profile.binding(semantic)
        except KeyError:
            return None

    def _negative_semantic_certification(self, semantic: ProtocolWireSemantic) -> dict:
        certification = certify_negative_semantic_evidence(
            adapter_id=self.protocol_adapter_id or getattr(self._protocol_wire_profile, "adapter_id", None),
            observed_client_version=self._observed_client_version(),
            semantic=semantic,
        )
        return {
            "certified": bool(certification.certified),
            "adapter_id": certification.adapter_id,
            "observed_client_version": certification.observed_client_version,
            "message_name": certification.message_name,
            "semantic": semantic.value,
            "reason": certification.reason,
        }

    def _cast_request_payload_matches(
        self, evidence: dict | None, *, spell_id: int, target_cell_id: int,
    ) -> bool:
        binding = self._wire_binding(ProtocolWireSemantic.CAST_REQUEST)
        return bool(
            binding is not None
            and binding.matches_ints(
                evidence, spell_id=int(spell_id), target_cell_id=int(target_cell_id)
            )
        )

    def _record_session_cast_semantic_proof(
        self, *, spell_id: int, target_cell_id: int, after_monotonic_ms: int, client_instance_id: str | None,
    ) -> dict:
        version = self._observed_client_version()
        if not client_instance_id or not version:
            return {"recorded": False, "reason": "CLIENT_IDENTITY_OR_VERSION_UNKNOWN"}
        available, evidence = self._protocol_semantic_evidence_since(
            semantic=ProtocolWireSemantic.CAST_REQUEST,
            after_monotonic_ms=int(after_monotonic_ms), client_instance_id=client_instance_id,
        )
        if not available or not self._cast_request_payload_matches(
            evidence, spell_id=int(spell_id), target_cell_id=int(target_cell_id)
        ):
            return {"recorded": False, "reason": "EXACT_CAST_REQUEST_CORRELATION_NOT_OBSERVED", "evidence": evidence}
        token = str(evidence.get("id") or evidence.get("monotonic_ms") or evidence.get("payload_sha256") or "")
        if not token:
            return {"recorded": False, "reason": "CAST_REQUEST_CORRELATION_IDENTITY_MISSING", "evidence": evidence}
        key = (str(client_instance_id), str(version), int(spell_id))
        bucket = self._session_cast_semantic_proofs.setdefault(key, set())
        bucket.add(token)
        return {
            "recorded": True, "client_instance_id": str(client_instance_id),
            "observed_client_version": str(version), "spell_id": int(spell_id),
            "proof_count": len(bucket), "evidence": evidence,
        }

    def _cast_negative_semantic_certification(
        self, *, spell_id: int, client_instance_id: str | None,
    ) -> dict:
        exact = self._negative_semantic_certification(ProtocolWireSemantic.CAST_REQUEST)
        if exact.get("certified"):
            return {**exact, "provenance": "EXACT_BUILD_CONTRACT"}
        version = self._observed_client_version()
        key = (str(client_instance_id or ""), str(version or ""), int(spell_id))
        proof_count = len(self._session_cast_semantic_proofs.get(key, set()))
        if client_instance_id and version and proof_count >= 3:
            return {
                "certified": True,
                "adapter_id": self.protocol_adapter_id,
                "observed_client_version": str(version),
                "message_name": (self._wire_binding(ProtocolWireSemantic.CAST_REQUEST).message_name if self._wire_binding(ProtocolWireSemantic.CAST_REQUEST) else None),
                "reason": (
                    "same-session exact spell-specific CAST_REQUEST semantics learned from "
                    f"{proof_count} server-confirmed CAST correlations"
                ),
                "provenance": "SAME_SESSION_POSITIVE_CORRELATION",
                "spell_id": int(spell_id),
                "proof_count": int(proof_count),
                "client_instance_id": str(client_instance_id),
            }
        return {
            **exact,
            "provenance": "UNCERTIFIED",
            "spell_id": int(spell_id),
            "proof_count": int(proof_count),
            "client_instance_id": client_instance_id,
        }

    def _record_session_move_semantic_proof(
        self, *, after_monotonic_ms: int, client_instance_id: str | None, target_cell_id: int,
    ) -> dict:
        """Learn MOVE semantics only from an exact, server-confirmed destination correlation."""
        version = self._observed_client_version()
        if not client_instance_id or not version:
            return {"recorded": False, "reason": "CLIENT_IDENTITY_OR_VERSION_UNKNOWN"}
        available, evidence = self._move_request_evidence_since(
            after_monotonic_ms=int(after_monotonic_ms),
            client_instance_id=client_instance_id,
            target_cell_id=int(target_cell_id),
        )
        if not available or not isinstance(evidence, dict):
            return {"recorded": False, "reason": "MOVE_TARGET_CORRELATION_NOT_OBSERVED", "evidence": evidence}
        token = str(evidence.get("id") or evidence.get("monotonic_ms") or evidence.get("payload_sha256") or "")
        if not token:
            return {"recorded": False, "reason": "MOVE_CORRELATION_IDENTITY_MISSING", "evidence": evidence}
        key = (str(client_instance_id), str(version))
        bucket = self._session_move_semantic_proofs.setdefault(key, set())
        bucket.add(token)
        return {
            "recorded": True, "client_instance_id": str(client_instance_id),
            "observed_client_version": str(version), "target_cell_id": int(target_cell_id),
            "proof_count": len(bucket),
            "message_name": (self._wire_binding(ProtocolWireSemantic.MOVE_REQUEST).message_name if self._wire_binding(ProtocolWireSemantic.MOVE_REQUEST) else None), "evidence": evidence,
        }

    def _move_negative_semantic_certification(self, *, client_instance_id: str | None) -> dict:
        """Certify negative MOVE_REQUEST evidence only after repeated same-session positive moves."""
        version = self._observed_client_version()
        key = (str(client_instance_id or ""), str(version or ""))
        proof_count = len(self._session_move_semantic_proofs.get(key, set()))
        certified = bool(client_instance_id and version and proof_count >= 3)
        return {
            "certified": certified,
            "provenance": "SAME_SESSION_CONFIRMED_MOVE_REQUEST" if certified else "UNCERTIFIED",
            "message_name": (self._wire_binding(ProtocolWireSemantic.MOVE_REQUEST).message_name if self._wire_binding(ProtocolWireSemantic.MOVE_REQUEST) else None),
            "client_instance_id": client_instance_id,
            "observed_client_version": version,
            "proof_count": int(proof_count),
            "reason": (
                f"same-session MOVE request semantics learned from {proof_count} target-confirmed moves"
                if certified else
                "negative MOVE semantics require at least 3 same-session target-confirmed move correlations"
            ),
        }

    def _record_session_end_turn_semantic_proof(
        self, *, after_monotonic_ms: int, client_instance_id: str | None,
    ) -> dict:
        """Learn END_TURN_REQUEST semantics only from authoritative turn handoffs."""
        version = self._observed_client_version()
        if not client_instance_id or not version:
            return {"recorded": False, "reason": "CLIENT_IDENTITY_OR_VERSION_UNKNOWN"}
        available, evidence = self._protocol_semantic_evidence_since(
            semantic=ProtocolWireSemantic.END_TURN_REQUEST,
            after_monotonic_ms=int(after_monotonic_ms), client_instance_id=client_instance_id,
        )
        if not available or not isinstance(evidence, dict):
            return {"recorded": False, "reason": "JVV_CORRELATION_NOT_OBSERVED", "evidence": evidence}
        token = str(evidence.get("id") or evidence.get("monotonic_ms") or evidence.get("payload_sha256") or "")
        if not token:
            return {"recorded": False, "reason": "JVV_CORRELATION_IDENTITY_MISSING", "evidence": evidence}
        key = (str(client_instance_id), str(version))
        bucket = self._session_end_turn_semantic_proofs.setdefault(key, set())
        bucket.add(token)
        return {
            "recorded": True, "client_instance_id": str(client_instance_id),
            "observed_client_version": str(version), "proof_count": len(bucket),
            "message_name": (self._wire_binding(ProtocolWireSemantic.END_TURN_REQUEST).message_name if self._wire_binding(ProtocolWireSemantic.END_TURN_REQUEST) else None), "evidence": evidence,
        }

    def _end_turn_negative_semantic_certification(self, *, client_instance_id: str | None) -> dict:
        version = self._observed_client_version()
        key = (str(client_instance_id or ""), str(version or ""))
        proof_count = len(self._session_end_turn_semantic_proofs.get(key, set()))
        certified = bool(client_instance_id and version and proof_count >= 3)
        return {
            "certified": certified,
            "provenance": "SAME_SESSION_CONFIRMED_END_TURN_JVV" if certified else "UNCERTIFIED",
            "message_name": (self._wire_binding(ProtocolWireSemantic.END_TURN_REQUEST).message_name if self._wire_binding(ProtocolWireSemantic.END_TURN_REQUEST) else None),
            "client_instance_id": client_instance_id,
            "observed_client_version": version,
            "proof_count": int(proof_count),
            "reason": (
                f"same-session END_TURN_REQUEST semantics learned from {proof_count} confirmed turn handoffs"
                if certified else
                "negative END_TURN_REQUEST semantics require at least 3 same-session confirmed turn handoffs"
            ),
        }

    def _neutralize_selected_spell(self, *, reason: str) -> tuple[dict, dict | None]:
        """Cancel a certainly selected spell before any non-cast replan can click the map.

        Once the slot click is SENT, returning directly to FightAI without restoring
        a neutral UI is unsafe: a future movement/map click could be interpreted as
        the still-selected spell target.  ESC is therefore a required transaction
        phase for every pre-target abort and proven local client rejection.
        """
        try:
            focused = bool(self.input.ensure_target_focused())
        except Exception:
            focused = False
        if not focused:
            evidence = {
                "phase": "UI_NEUTRALIZE", "reason": str(reason),
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "neutralized": False, "detail": "target Dofus window could not be re-focused for UI neutralization",
            }
            return evidence, self._uncertain(
                "spell slot was selected but target focus could not be proven for UI neutralization; subsequent map clicks are fenced",
                ui_neutralization=evidence,
            )
        cancel = getattr(self.input, "cancel_current_action", None)
        if not callable(cancel):
            evidence = {
                "phase": "UI_NEUTRALIZE", "reason": str(reason),
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "neutralized": False, "detail": "input driver has no UI-neutralization contract",
            }
            return evidence, self._uncertain(
                "spell slot was selected but UI neutralization is unavailable; subsequent map clicks are fenced",
                ui_neutralization=evidence,
            )
        try:
            state = self._guarded_physical_send(
                purpose="UI_NEUTRALIZE_ESCAPE",
                context={"reason": str(reason)},
                sender=cancel,
            )
        except Exception as exc:
            state = PhysicalSendState.NOT_SENT
            detail = f"{type(exc).__name__}: {exc}"
        else:
            detail = None
        evidence = {
            "phase": "UI_NEUTRALIZE", "reason": str(reason),
            "physical_send_state": getattr(state, "value", str(state)),
            "neutralized": state is PhysicalSendState.SENT,
            "physical_input_evidence": self._input_debug_snapshot(),
        }
        if detail is not None:
            evidence["detail"] = detail
        if state is PhysicalSendState.SENT:
            return evidence, None
        return evidence, self._uncertain(
            "spell slot was selected but UI neutralization was not certainly sent; subsequent map clicks are fenced",
            ui_neutralization=evidence,
        )

    def _safe_world_rect(self) -> tuple[int, int, int, int] | None:
        """Derive the physically clickable world rectangle from verified UI calibration.

        Unity projection describes where a logical cell lands in the client, but the
        Dofus HUD overlays part of that client.  The safe rectangle deliberately
        excludes the edge-transition hotspots and the bottom action/phase controls.
        """
        size = self.calibration.client_size
        if size is None:
            return None
        left = self.calibration.directions.get("LEFT")
        right = self.calibration.directions.get("RIGHT")
        top = self.calibration.directions.get("TOP")
        if not all(point is not None and point.verified for point in (left, right, top)):
            return None
        # Only full-width bottom HUD controls constrain the global world-click
        # rectangle. Side overlays such as JOIN_FIGHT occupy a local region and
        # must not clip every projected world cell below their y-coordinate.
        ui_points = [point for point in self.calibration.spell_slots.values() if point.verified]
        phase_button = self.calibration.resolve_control("PHASE_BUTTON")
        if phase_button is not None and phase_button.verified:
            ui_points.append(phase_button)
        if not ui_points:
            return None
        margin = 16
        x_min = max(0, int(left.x) + margin)
        x_max = min(int(size.width) - 1, int(right.x) - margin)
        y_min = max(0, int(top.y) + margin)
        y_max = min(int(size.height) - 1, min(int(point.y) for point in ui_points) - margin)
        if x_min > x_max or y_min > y_max:
            return None
        return x_min, y_min, x_max, y_max

    def _projection_blocker(
        self, projection: ProjectionResult, *, label: str, require_spell_anchor: bool = False,
    ) -> dict | None:
        spell_target = require_spell_anchor and str(projection.purpose or "").upper() == "SPELL_TARGET_CLICK"
        if projection.status is not ProjectionStatus.READY or projection.point is None or projection.client_point is None:
            detail = str(projection.detail or "")
            anchor_failure = spell_target and (
                "rendered" in detail.lower()
                or "cell anchor" in detail.lower()
                or "cell::" in detail.lower()
                or "runtime-grid" in detail.lower()
                or "runtime grid" in detail.lower()
            )
            if anchor_failure:
                return {
                    "status": "BLOCKED",
                    "failure_code": FailureCode.SPELL_TARGET_INTERACTION_UNVERIFIED.value,
                    "detail": (
                        f"SPELL_TARGET_INTERACTION_UNVERIFIED: {label} projection interaction "
                        f"authority is not certified ({projection.status.value}: {detail})"
                    ),
                    "retry_allowed": False,
                    "physical_send_state": PhysicalSendState.NOT_SENT.value,
                    "projection_purpose": projection.purpose,
                    "cell_id": int(projection.cell_id),
                    "projection_status": projection.status.value,
                    "projection_diagnostics": projection.diagnostics,
                }
            if projection.target_entity_id is not None and projection.status in {
                ProjectionStatus.ENTITY_MISMATCH, ProjectionStatus.SOURCE_UNVERIFIED, ProjectionStatus.NOT_READY,
            }:
                status_code = FailureCode.PROJECTION_ENTITY_UNVERIFIED.value
            else:
                status_code = {
                    ProjectionStatus.BRIDGE_UNAVAILABLE: FailureCode.PROJECTION_BRIDGE_OFFLINE.value,
                    ProjectionStatus.MAP_MISMATCH: FailureCode.PROJECTION_MAP_MISMATCH.value,
                    ProjectionStatus.CELL_UNAVAILABLE: FailureCode.PROJECTION_CELL_UNAVAILABLE.value,
                    ProjectionStatus.OUTSIDE_VIEWPORT: FailureCode.PROJECTION_OUTSIDE_VIEWPORT.value,
                }.get(projection.status, FailureCode.PROJECTION_STALE.value)
            retry_after = (
                1.0 if projection.target_entity_id is not None and status_code == FailureCode.PROJECTION_ENTITY_UNVERIFIED.value
                else 0.25 if projection.status is ProjectionStatus.ENTITY_MISMATCH
                else 0.20 if projection.status in {ProjectionStatus.NOT_READY, ProjectionStatus.STALE}
                else 0.35
            )
            return {
                "status": "BLOCKED",
                "failure_code": status_code,
                "detail": (
                    f"{label} projection blocked: {projection.status.value}"
                    + (f": {detail}" if detail else "")
                ),
                "retry_allowed": True,
                "retry_after_seconds": retry_after,
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "projection_purpose": projection.purpose,
                "projection_status": projection.status.value,
                "projection_map_id": int(projection.map_id),
                "cell_id": int(projection.cell_id),
                "target_entity_id": projection.target_entity_id,
                "entity_anchor_cell_id": projection.entity_anchor_cell_id,
                "entity_nearest_cell_id": projection.entity_nearest_cell_id,
                "projection_diagnostics": projection.diagnostics,
            }
        if projection.target_entity_id is not None:
            if not projection.entity_anchor_verified:
                return self._blocked(f"ENTITY_ANCHOR_UNVERIFIED: {label} target entity anchor is not verified")
            if projection.verified_by_runtime_grid is not True:
                return self._blocked(f"ENTITY_ANCHOR_UNVERIFIED: {label} target entity is not verified against the runtime grid")
        if (
            require_spell_anchor
            and str(projection.purpose or "").upper() == "SPELL_TARGET_CLICK"
            and projection.verified_by_runtime_grid is not True
        ):
            return {
                "status": "BLOCKED",
                "failure_code": FailureCode.SPELL_TARGET_INTERACTION_UNVERIFIED.value,
                "detail": f"SPELL_TARGET_INTERACTION_UNVERIFIED: {label} runtime-grid projection authority is not verified",
                "retry_allowed": False,
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "projection_purpose": projection.purpose,
                "cell_id": int(projection.cell_id),
                "projection_diagnostics": projection.diagnostics,
            }
        rect = self._safe_world_rect()
        if rect is None:
            return self._blocked(f"PROJECTION_UI_SAFETY_UNAVAILABLE: {label} has no verified safe world rectangle")
        x_min, y_min, x_max, y_max = rect
        point = self._projection_reference_client_point(projection)
        if point is None:
            return self._blocked(f"PROJECTION_CLIENT_SPACE_UNAVAILABLE: {label} has no normalized client point")
        if x_min <= point.x <= x_max and y_min <= point.y <= y_max:
            return None
        return {
            "status": "BLOCKED",
            "failure_code": "PROJECTION_UI_OCCLUDED",
            "detail": f"PROJECTION_UI_OCCLUDED: {label} client point ({point.x},{point.y}) is outside safe world rectangle",
            "retry_allowed": True,
            "retry_after_seconds": 0.35,
            "physical_send_state": PhysicalSendState.NOT_SENT.value,
            "projection_purpose": projection.purpose,
            "projection_status": projection.status.value,
            "projection_map_id": int(projection.map_id),
            "cell_id": int(projection.cell_id),
            "target_entity_id": projection.target_entity_id,
            "projection_diagnostics": projection.diagnostics,
            "client_point": [int(point.x), int(point.y)],
            "screen_point": [int(projection.point.x), int(projection.point.y)],
            "safe_world_rect": [x_min, y_min, x_max, y_max],
        }

    @staticmethod
    def _snapshot_cell_has_actor(snapshot: CanonicalSnapshot, cell_id: int) -> bool:
        for actor in snapshot.fight.actors:
            alive = actor.alive
            if alive.status is ValueStatus.KNOWN and alive.value is False:
                continue
            cell = actor.cell_id
            if cell.status is ValueStatus.KNOWN and int(cell.value) == int(cell_id):
                return True
        return False

    def _empty_non_walkable_spell_target_block(
        self, snapshot: CanonicalSnapshot, projection: ProjectionResult, *, label: str,
    ) -> dict | None:
        if projection.statically_walkable is not False:
            return None
        # Direct actor targets are a distinct client interaction surface.  A
        # monster/player may occupy a cell that is not a legal movement
        # destination, so never reject a positively verified entity anchor merely
        # because the underlying static movement flag is false.
        if (
            getattr(projection, "target_entity_id", None) is not None
            and getattr(projection, "entity_anchor_verified", False) is True
            and int(getattr(projection, "entity_anchor_cell_id", -1)) == int(projection.cell_id)
        ):
            return None
        if self._snapshot_cell_has_actor(snapshot, int(projection.cell_id)):
            return None
        return {
            "status": "BLOCKED",
            "failure_code": FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value,
            "detail": (
                f"SPELL_TARGET_EMPTY_NON_WALKABLE: {label} cell {int(projection.cell_id)} "
                "is empty and positively non-walkable; client target click suppressed"
            ),
            "retry_allowed": False,
            "safe_replan": True,
            "quarantine_candidate": True,
            "physical_send_state": PhysicalSendState.NOT_SENT.value,
            "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
            "cell_id": int(projection.cell_id),
            "statically_walkable": False,
            "projection_status": getattr(projection.status, "value", str(projection.status)),
        }

    def _resolve_safe_cell(
        self, map_id: int, cell_id: int, *, purpose: str, label: str,
        target_entity_id: int | None = None, require_spell_anchor: bool = False,
    ) -> tuple[ProjectionResult | None, dict | None]:
        requested_map_id = int(map_id)
        projection_map_id = requested_map_id
        geometry_evidence = None
        purpose_upper = str(purpose or "").upper()
        if self.kernel is not None and (purpose_upper.startswith("FIGHT_") or purpose_upper.startswith("SPELL_TARGET")):
            snapshot = self.state.snapshot()
            if snapshot.fight.present and snapshot.fight.map_id.status is ValueStatus.KNOWN:
                semantic_map_id = int(snapshot.fight.map_id.value)
                if semantic_map_id == requested_map_id:
                    try:
                        binding = resolve_fight_geometry(self.kernel, snapshot)
                    except FightGeometryUnavailable as exc:
                        failure_code = "FIGHT_GEOMETRY_PENDING" if exc.retryable else "FIGHT_GEOMETRY_UNAVAILABLE"
                        return None, {
                            "status": "BLOCKED",
                            "failure_code": failure_code,
                            "detail": f"{label} cannot be projected because fight geometry is unavailable: {exc}",
                            "retry_allowed": bool(exc.retryable),
                            "retry_after_seconds": (0.25 if exc.retryable else None),
                            "physical_send_state": PhysicalSendState.NOT_SENT.value,
                            "semantic_fight_map_id": semantic_map_id,
                            "fight_instance_id": snapshot.fight.fight_instance_id,
                            "fight_geometry_reason": exc.reason_code,
                            "fight_geometry": dict(exc.evidence),
                        }
                    projection_map_id = int(binding.geometry_map_id)
                    geometry_evidence = binding.as_dict()
        projection = self.projection.resolve_current(
            projection_map_id, int(cell_id), purpose=str(purpose),
            target_entity_id=int(target_entity_id) if target_entity_id is not None else None,
        )
        if geometry_evidence is not None:
            diagnostics = dict(projection.diagnostics or {})
            diagnostics.update({
                "semantic_fight_map_id": requested_map_id,
                "projection_geometry_map_id": projection_map_id,
                "fight_geometry_binding": geometry_evidence,
            })
            projection = projection.model_copy(update={"diagnostics": diagnostics})
        blocked = self._projection_blocker(
            projection, label=label, require_spell_anchor=bool(require_spell_anchor),
        )
        return (None, blocked) if blocked is not None else (projection, None)

    def _confirmation_poll_budget(self, operation: str) -> int:
        if self._timing is not None:
            return int(self._timing.confirmation_polls(operation))
        return self.max_confirmation_polls

    def _settlement_poll_budget(self, operation: str) -> int:
        if self._timing is not None:
            return int(self._timing.settlement_polls(operation))
        return self.max_confirmation_polls

    def _wait_for_with_last(
        self, before_revision: int, predicate: Callable[[CanonicalSnapshot], bool], *, operation: str
    ) -> tuple[CanonicalSnapshot | None, CanonicalSnapshot | None]:
        last: CanonicalSnapshot | None = None
        for _ in range(self._confirmation_poll_budget(operation)):
            current = self.state.snapshot()
            last = current
            if current.revision > before_revision and predicate(current):
                return current, current
            self.sleep(self.confirmation_interval_seconds)
        return None, last

    def _wait_for(
        self, before_revision: int, predicate: Callable[[CanonicalSnapshot], bool], *, operation: str
    ) -> CanonicalSnapshot | None:
        confirmed, _last = self._wait_for_with_last(before_revision, predicate, operation=operation)
        return confirmed

    def _protocol_evidence_since(
        self,
        *,
        message_name: str,
        direction: str,
        after_monotonic_ms: int,
        client_instance_id: str | None = None,
    ) -> tuple[bool, dict | None]:
        """Return (query_available, newest matching protocol evidence).

        The journal is diagnostic infrastructure, so absence of a query method is
        treated as UNKNOWN rather than as evidence that the protocol message did
        not occur.  When the query is available, however, the bounded per-session
        protocol trace lets fixed-coordinate controls prove whether Dofus actually
        emitted the certified request after the mouse transaction.
        """
        query = getattr(self.observability, "latest_protocol_message", None) if self.observability is not None else None
        if not callable(query):
            return False, None
        try:
            result = query(
                message_name=str(message_name),
                direction=str(direction),
                account_id=self.account_id,
                client_instance_id=client_instance_id,
                after_monotonic_ms=int(after_monotonic_ms),
            )
        except Exception:
            return False, None
        return True, dict(result) if isinstance(result, dict) else None

    def _protocol_semantic_evidence_since(
        self, *, semantic: ProtocolWireSemantic, after_monotonic_ms: int,
        client_instance_id: str | None = None,
    ) -> tuple[bool, dict | None]:
        """Query protocol evidence by stable semantic instead of raw wire name."""
        binding = self._wire_binding(semantic)
        if binding is None:
            return False, None
        return self._protocol_evidence_since(
            message_name=binding.message_name, direction=binding.direction,
            after_monotonic_ms=int(after_monotonic_ms), client_instance_id=client_instance_id,
        )

    def _protocol_semantic_matching_ints_since(
        self,
        *,
        semantic: ProtocolWireSemantic,
        after_monotonic_ms: int,
        client_instance_id: str | None = None,
        **expected: int,
    ) -> tuple[bool, dict | None]:
        """Return exact semantic request evidence, not merely a wire-name hit.

        Revision-local manifests already describe the protobuf fields that make
        a request semantically meaningful.  Use those fields when the protocol
        distinguishes opposite intents with the same message name (notably
        READY=true versus an omitted/false Ready value).  The journal remains
        protocol-neutral; it only supplies bounded raw observations.

        Older/dummy observability implementations may expose only
        ``latest_protocol_message``.  In that case we still fail closed by
        accepting the newest row only when its payload matches exactly.
        """
        binding = self._wire_binding(semantic)
        if binding is None:
            return False, None
        query = getattr(self.observability, "protocol_messages_since", None) if self.observability is not None else None
        if callable(query):
            try:
                rows = query(
                    message_name=binding.message_name,
                    direction=binding.direction,
                    account_id=self.account_id,
                    client_instance_id=client_instance_id,
                    after_monotonic_ms=int(after_monotonic_ms),
                    limit=64,
                )
            except Exception:
                return False, None
            for row in rows or ():
                evidence = dict(row) if isinstance(row, dict) else None
                if evidence is not None and binding.matches_ints(evidence, **expected):
                    return True, evidence
            return True, None

        available, evidence = self._protocol_semantic_evidence_since(
            semantic=semantic,
            after_monotonic_ms=int(after_monotonic_ms),
            client_instance_id=client_instance_id,
        )
        if not available or evidence is None:
            return available, None
        return True, evidence if binding.matches_ints(evidence, **expected) else None

    def _move_request_evidence_since(
        self, *, after_monotonic_ms: int, client_instance_id: str | None, target_cell_id: int,
    ) -> tuple[bool, dict | None]:
        """Return movement request evidence correlated to the requested destination when supported.

        Newer protocol manifests can expose a revision-local target-cell decoder
        for their packed route representation.  Older certified revisions did
        not expose that field, so they retain their historical message-level
        correlation rather than inheriting a guessed wire layout.
        """
        binding = self._wire_binding(ProtocolWireSemantic.MOVE_REQUEST)
        if binding is None:
            return False, None
        try:
            binding.field("target_cell_id")
        except KeyError:
            return self._protocol_semantic_evidence_since(
                semantic=ProtocolWireSemantic.MOVE_REQUEST,
                after_monotonic_ms=int(after_monotonic_ms),
                client_instance_id=client_instance_id,
            )
        return self._protocol_semantic_matching_ints_since(
            semantic=ProtocolWireSemantic.MOVE_REQUEST,
            after_monotonic_ms=int(after_monotonic_ms),
            client_instance_id=client_instance_id,
            target_cell_id=int(target_cell_id),
        )

    def _protocol_activity_since(
        self, *, after_monotonic_ms: int, client_instance_id: str | None = None,
        direction: str | None = None,
    ) -> tuple[bool, dict | None]:
        query = getattr(self.observability, "latest_protocol_activity", None) if self.observability is not None else None
        if not callable(query):
            return False, None
        try:
            result = query(
                account_id=self.account_id,
                client_instance_id=client_instance_id,
                direction=direction,
                after_monotonic_ms=int(after_monotonic_ms),
            )
        except Exception:
            return False, None
        return True, dict(result) if isinstance(result, dict) else None

    def _protocol_window_summary_since(
        self, *, after_monotonic_ms: int, client_instance_id: str | None = None,
        direction: str | None = None,
    ) -> tuple[bool, dict | None]:
        query = getattr(self.observability, "protocol_window_summary", None) if self.observability is not None else None
        if not callable(query):
            return False, None
        try:
            result = query(
                account_id=self.account_id,
                client_instance_id=client_instance_id,
                direction=direction,
                after_monotonic_ms=int(after_monotonic_ms),
            )
        except Exception:
            return False, None
        return True, dict(result) if isinstance(result, dict) else None

    def _runtime_health_snapshot(self) -> tuple[bool, dict | None]:
        if self.runtime_health_provider is None:
            return False, None
        try:
            value = self.runtime_health_provider()
        except Exception as exc:
            return True, {"status": "UNAVAILABLE", "error": f"{type(exc).__name__}: {exc}"}
        return True, dict(value) if isinstance(value, dict) else {"status": "INVALID"}

    def _capture_coverage(
        self,
        *,
        client_instance_id: str | None,
        required_through_monotonic_ms: int,
        require_exact_client_instance: bool = False,
    ) -> tuple[bool, dict]:
        """Prove capture survived through a complete semantic-acceptance window.

        Negative protocol evidence is useful only when the transport itself is
        proven alive for the same client generation through the time boundary at
        which absence is being asserted. This generic helper is shared by world
        interactions and R5.135 cast causality.
        """
        available, health = self._runtime_health_snapshot()
        if not available or not isinstance(health, dict):
            return False, {
                "covered": False,
                "reason": "RUNTIME_HEALTH_PROVIDER_UNAVAILABLE",
                "required_through_monotonic_ms": int(required_through_monotonic_ms),
            }
        capture = dict(health.get("capture") or {}) if isinstance(health.get("capture"), dict) else {}
        raw_segment = capture.get("last_segment_monotonic")
        try:
            last_segment_ms = int(float(raw_segment) * 1000) if raw_segment is not None else None
        except (TypeError, ValueError):
            last_segment_ms = None
        observed_client = capture.get("client_instance_id")
        if require_exact_client_instance:
            client_matches = bool(
                client_instance_id
                and observed_client is not None
                and str(observed_client) == str(client_instance_id)
            )
        else:
            client_matches = (
                not client_instance_id
                or observed_client is None
                or str(observed_client) == str(client_instance_id)
            )
        covered = bool(
            str(health.get("status") or "").upper() == "READY"
            and int(capture.get("segment_count") or 0) > 0
            and last_segment_ms is not None
            and last_segment_ms >= int(required_through_monotonic_ms)
            and client_matches
        )
        return covered, {
            "covered": covered,
            "health_status": health.get("status"),
            "required_through_monotonic_ms": int(required_through_monotonic_ms),
            "last_segment_monotonic_ms": last_segment_ms,
            "segment_count": int(capture.get("segment_count") or 0),
            "message_count": int(capture.get("message_count") or 0),
            "capture_id": capture.get("capture_id"),
            "capture_account_id": capture.get("account_id"),
            "capture_client_instance_id": observed_client,
            "expected_client_instance_id": client_instance_id,
            "client_instance_matches": client_matches,
            "exact_client_instance_required": bool(require_exact_client_instance),
            "blockers": list(health.get("blockers") or ()),
        }

    def _capture_coverage_for_world_interaction(
        self,
        pending: PendingWorldInteraction,
        *,
        required_through_monotonic_ms: int,
    ) -> tuple[bool, dict]:
        """Backward-compatible world-interaction wrapper around generic coverage."""
        return self._capture_coverage(
            client_instance_id=pending.client_instance_id,
            required_through_monotonic_ms=required_through_monotonic_ms,
        )

    @staticmethod
    def _world_target_observation(
        snapshot: CanonicalSnapshot,
        pending: PendingWorldInteraction,
        *,
        observed_monotonic_ms: int,
    ) -> dict:
        map_id = None
        if snapshot.world.map_id.status is ValueStatus.KNOWN:
            map_id = int(snapshot.world.map_id.value)
        group = next((item for item in snapshot.world.monster_groups if int(item.group_id) == int(pending.entity_id)), None)
        cell_id = None
        if group is not None and group.cell_id.status is ValueStatus.KNOWN:
            cell_id = int(group.cell_id.value)
        return {
            "observed_monotonic_ms": int(observed_monotonic_ms),
            "revision": int(snapshot.revision),
            "fight_present": bool(snapshot.fight.present),
            "world_map_id": map_id,
            "monster_groups_complete": bool(snapshot.world.monster_groups_complete),
            "group_present": group is not None,
            "group_cell_id": cell_id,
        }

    def _bootstrap_change_map(self, payload: dict) -> dict:
        """One guarded edge transition used only to acquire authoritative MapId.

        The supplied source map may be the controlled-start bootstrap assumption.
        It is validated against Kernel topology but is never written into
        Canonical State.  Success requires a newer authoritative R4 destination
        MapId after the physical edge click.
        """
        source = int(payload["source_map_id"])
        target = int(payload["target_map_id"])
        before = self.state.snapshot()
        if self._uncertain_detail is not None:
            if self._uncertainty_is_world_transition():
                reconciliation = self._reconcile_world_transition_uncertainty_locked(
                    reason="ACTIVE_BOOTSTRAP_READINESS", require_target_match=True
                )
                if str(reconciliation.get("status") or "").upper() != "RECONCILED":
                    context = dict(self._uncertain_context or {})
                    return {
                        "status": "RECONCILING",
                        "failure_code": FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                        "detail": self._uncertain_detail or "bootstrap world transition confirmation is still pending",
                        "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                        "retry_allowed": True,
                        "physical_retry_allowed": False,
                        "safe_replan": False,
                        "reconciliation_required": True,
                        "input_quarantined": True,
                        "first_missing_boundary": "WORLD_DESTINATION_CONFIRMATION",
                        "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
                        "origin_action_id": context.get("origin_action_id"),
                        "source_map_id": context.get("source_map_id"),
                        "target_map_id": context.get("target_map_id"),
                        "basis_revision": context.get("basis_revision"),
                        "reconciliation": reconciliation,
                        "record_kind": "TRANSACTION_OBSERVATION",
                        "physical_input_event": False,
                        "observation_of_action_id": context.get("origin_action_id"),
                    }
                before = self.state.snapshot()
            else:
                return self._blocked(f"UNCERTAIN_FENCE active: {self._uncertain_detail}")
        if self._pending_settlement is not None:
            return self._blocked("pending action settlement exists; bootstrap input is forbidden")
        if before.fight.present:
            return self._blocked("cannot bootstrap world map while a fight is present")
        known = before.world.map_id
        if known.status is ValueStatus.KNOWN and int(known.value) == target:
            return {
                "status": "CONFIRMED",
                "confirmed_revision": int(before.revision),
                "confirmed_map_id": target,
                "bootstrap_source_map_id": source,
                "detail": "bootstrap destination already confirmed after passive reconciliation",
            }
        if known.status is ValueStatus.KNOWN and int(known.value) != source:
            return self._blocked("bootstrap source map conflicts with authoritative Canonical map")
        if self.kernel is None:
            return self._blocked("Kernel unavailable for bootstrap world routing")
        ensure_map = getattr(self.kernel, "ensure_map", None)
        if callable(ensure_map):
            ensure_map(MapId(source)); ensure_map(MapId(target))
        route = self.kernel.world.route(MapId(source), MapId(target))
        if not route.reachable or len(route.steps) != 1:
            return self._blocked("bootstrap transition must be one direct Kernel-validated map edge")
        step = route.steps[0]
        if int(step.target_map_id) != target:
            return self._blocked("bootstrap target does not match the direct Kernel route")
        calibrated = self._client_point("directions", step.direction.value)
        if calibrated is None:
            return self._blocked(f"direction calibration is not verified: {step.direction.value}")
        key = self._attempt_key(before.revision, "bootstrap_change_map", {
            "source": source, "target": target, "direction": step.direction.value,
        })
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked
        with self._input_lease():
            authorized = self.state.snapshot()
            if authorized.fight.present:
                return {
                    "status": "BLOCKED",
                    "failure_code": "DOMAIN_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "STARTUP_WORLD_COMMAND_AUTHORIZATION",
                    "likely_owner": "STARTUP_CONVERGENCE",
                    "retry_allowed": False,
                    "detail": "fight became present before bootstrap input; no click was sent",
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                }
            authorized_map = authorized.world.map_id
            if authorized_map.status is ValueStatus.KNOWN and int(authorized_map.value) != source:
                return {
                    "status": "BLOCKED",
                    "failure_code": "DOMAIN_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "STARTUP_WORLD_COMMAND_AUTHORIZATION",
                    "likely_owner": "STARTUP_CONVERGENCE",
                    "retry_allowed": False,
                    "detail": "authoritative map changed before bootstrap input; stale assumed-start action was cancelled",
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                    "bootstrap_source_map_id": source,
                    "authorization_map_id": int(authorized_map.value),
                }
            sent = self._send_client(calibrated)
        if sent is PhysicalSendState.NOT_SENT:
            return self._blocked("bootstrap world-transition input was not sent")
        self._mark_sent(key)
        if sent is PhysicalSendState.UNCERTAIN:
            return self._reconciling(
                "bootstrap world-transition send state is uncertain; passive destination reconciliation required",
                uncertainty_context={
                    "kind": "WORLD_TRANSITION",
                    "operation": "bootstrap_change_map",
                    "source_map_id": source,
                    "target_map_id": target,
                    "direction": step.direction.value,
                    "basis_revision": int(before.revision),
                    "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                },
                failure_code=FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.UNCERTAIN.value,
                retry_allowed=True, physical_retry_allowed=False, safe_replan=False,
                reconciliation_required=True, input_quarantined=True,
                first_missing_boundary="WORLD_DESTINATION_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
        confirmed = self._wait_for(
            before.revision,
            lambda snapshot: (not snapshot.fight.present
                and snapshot.world.map_id.status is ValueStatus.KNOWN
                and int(snapshot.world.map_id.value) == target),
            operation="bootstrap_change_map",
        )
        if confirmed is None:
            latest = self.state.snapshot()
            latest_map = latest.world.map_id
            if (
                int(latest.revision) > int(before.revision)
                and latest_map.status is ValueStatus.KNOWN
                and latest_map.value is not None
                and int(latest_map.value) not in {source, target}
            ):
                return self._uncertain(
                    "bootstrap transition produced a fresh authoritative unexpected destination map",
                    uncertainty_context={
                        "kind": "WORLD_TRANSITION_MISMATCH",
                        "operation": "bootstrap_change_map",
                        "source_map_id": source, "target_map_id": target,
                        "observed_map_id": int(latest_map.value),
                        "basis_revision": int(before.revision),
                    },
                    failure_code=FailureCode.WORLD_TRANSITION_TARGET_MISMATCH.value,
                    physical_send_state=PhysicalSendState.SENT.value,
                    retry_allowed=False, safe_replan=False,
                    first_missing_boundary="WORLD_DESTINATION_INTEGRITY",
                    likely_owner="CANONICAL_WORLD_OR_ROUTE_EXECUTION",
                    observed_revision=int(latest.revision),
                    observed_map_id=int(latest_map.value),
                )
            return self._reconciling(
                "bootstrap transition was sent but authoritative destination confirmation is still pending",
                uncertainty_context={
                    "kind": "WORLD_TRANSITION",
                    "operation": "bootstrap_change_map",
                    "source_map_id": source,
                    "target_map_id": target,
                    "direction": step.direction.value,
                    "basis_revision": int(before.revision),
                    "physical_send_state": PhysicalSendState.SENT.value,
                },
                failure_code=FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.SENT.value,
                retry_allowed=True, physical_retry_allowed=False, safe_replan=False,
                reconciliation_required=True, input_quarantined=True,
                first_missing_boundary="WORLD_DESTINATION_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
        return {
            "status":"CONFIRMED", "confirmed_revision":confirmed.revision,
            "confirmed_map_id":target, "bootstrap_source_map_id":source,
            "direction":step.direction.value,
            "detail":"authoritative R4 destination MapId confirmed after bootstrap transition",
        }

    def _change_map(self, payload: dict) -> dict:
        target = int(payload["target_map_id"])
        before = self.state.snapshot()
        readiness_block = self._guard_readiness(before)
        if readiness_block is not None:
            return readiness_block
        if before.fight.present:
            return self._blocked("cannot change world map while a fight is present")
        current = before.world.map_id
        if current.status is not ValueStatus.KNOWN:
            return self._blocked("current world map is not confirmed")
        source = int(current.value)
        if self.kernel is None:
            return self._blocked("Kernel unavailable for world routing")
        route = ensure_world_route(self.kernel, MapId(source), MapId(target))
        if not route.reachable:
            return self._blocked(f"Kernel world route unavailable: {route.reason}")
        if not route.steps:
            return {"status": "CONFIRMED", "confirmed_revision": before.revision, "confirmed_map_id": source, "detail": "already on requested map"}
        step = route.steps[0]
        calibrated = self._client_point("directions", step.direction.value)
        if calibrated is None:
            return self._blocked(f"direction calibration is not verified: {step.direction.value}")
        key = self._attempt_key(before.revision, "change_map", {"source": source, "target": int(step.target_map_id), "direction": step.direction.value})
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked
        with self._input_lease():
            # Final domain authorization occurs under the same input lease as the
            # physical send.  Route planning may have been correct milliseconds
            # earlier but a leader launch can move this lane into a different
            # lifecycle domain asynchronously.  Never emit a world edge from that
            # stale authorization.
            authorized = self.state.snapshot()
            if authorized.fight.present:
                return {
                    "status": "BLOCKED",
                    "failure_code": "DOMAIN_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "WORLD_COMMAND_AUTHORIZATION",
                    "likely_owner": "WORLD_TO_FIGHT_TRANSITION",
                    "retry_allowed": False,
                    "detail": "fight became present before world-map input; no click was sent",
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                }
            if (
                authorized.world.map_id.status is not ValueStatus.KNOWN
                or int(authorized.world.map_id.value) != source
            ):
                return {
                    "status": "BLOCKED",
                    "failure_code": "DOMAIN_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "WORLD_COMMAND_AUTHORIZATION",
                    "likely_owner": "WORLD_TO_FIGHT_TRANSITION",
                    "retry_allowed": False,
                    "detail": "world-map identity changed before input; stale route command was cancelled",
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                    "selected_source_map_id": source,
                    "authorization_map_id": (
                        int(authorized.world.map_id.value)
                        if authorized.world.map_id.status is ValueStatus.KNOWN
                        else None
                    ),
                }
            sent = self._send_client(calibrated)
        if sent is PhysicalSendState.NOT_SENT:
            return self._blocked("world transition input was not sent")
        self._mark_sent(key)
        expected = int(step.target_map_id)
        if sent is PhysicalSendState.UNCERTAIN:
            return self._reconciling(
                "world transition send state is uncertain; passive destination reconciliation required",
                uncertainty_context={
                    "kind": "WORLD_TRANSITION",
                    "operation": "change_map",
                    "source_map_id": source,
                    "target_map_id": expected,
                    "direction": step.direction.value,
                    "basis_revision": int(before.revision),
                    "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                },
                failure_code=FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.UNCERTAIN.value,
                retry_allowed=True,
                physical_retry_allowed=False,
                safe_replan=False,
                reconciliation_required=True,
                input_quarantined=True,
                first_missing_boundary="WORLD_DESTINATION_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
        confirmed = self._wait_for(
            before.revision,
            lambda s: not s.fight.present
            and s.world.map_id.status is ValueStatus.KNOWN
            and int(s.world.map_id.value) == expected,
            operation="change_map",
        )
        if confirmed is None:
            latest = self.state.snapshot()
            latest_map = latest.world.map_id
            if (
                int(latest.revision) > int(before.revision)
                and latest_map.status is ValueStatus.KNOWN
                and latest_map.value is not None
                and int(latest_map.value) not in {source, expected}
            ):
                return self._uncertain(
                    "world transition produced a fresh authoritative unexpected destination map",
                    uncertainty_context={
                        "kind": "WORLD_TRANSITION_MISMATCH",
                        "operation": "change_map",
                        "source_map_id": source, "target_map_id": expected,
                        "observed_map_id": int(latest_map.value),
                        "basis_revision": int(before.revision),
                    },
                    failure_code=FailureCode.WORLD_TRANSITION_TARGET_MISMATCH.value,
                    physical_send_state=PhysicalSendState.SENT.value,
                    retry_allowed=False, safe_replan=False,
                    first_missing_boundary="WORLD_DESTINATION_INTEGRITY",
                    likely_owner="CANONICAL_WORLD_OR_ROUTE_EXECUTION",
                    observed_revision=int(latest.revision),
                    observed_map_id=int(latest_map.value),
                )
            return self._reconciling(
                "world transition was sent but destination confirmation is still pending; input quarantined",
                uncertainty_context={
                    "kind": "WORLD_TRANSITION",
                    "operation": "change_map",
                    "source_map_id": source,
                    "target_map_id": expected,
                    "direction": step.direction.value,
                    "basis_revision": int(before.revision),
                    "physical_send_state": PhysicalSendState.SENT.value,
                },
                failure_code=FailureCode.WORLD_TRANSITION_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.SENT.value,
                retry_allowed=True,
                physical_retry_allowed=False,
                safe_replan=False,
                reconciliation_required=True,
                input_quarantined=True,
                first_missing_boundary="WORLD_DESTINATION_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
        return {"status": "CONFIRMED", "confirmed_revision": confirmed.revision, "confirmed_map_id": expected, "detail": f"confirmed {step.direction.value} transition"}

    def _decode_world_attack_target(self, evidence: dict | None) -> int | None:
        """Decode the active profile's world-attack target from journal evidence."""
        binding = self._wire_binding(ProtocolWireSemantic.WORLD_ATTACK_REQUEST)
        if binding is None:
            return None
        return binding.decode_int(evidence, "target_group_id")

    def _persist_world_interaction(self) -> None:
        if self._safety is None:
            return
        self._safety.set_world_interaction(self._world_interaction_ledger.snapshot())

    def _update_world_interaction(self, pending: PendingWorldInteraction) -> PendingWorldInteraction:
        updated = self._world_interaction_ledger.update(pending)
        self._persist_world_interaction()
        return updated

    def _clear_world_interaction(self) -> None:
        self._world_interaction_ledger.clear_pending()
        self._persist_world_interaction()

    def _finish_world_interaction(self, pending: PendingWorldInteraction) -> None:
        self._world_interaction_ledger.finish(pending)
        self._persist_world_interaction()

    def _launch_request_evidence(
        self, pending: PendingWorldInteraction
    ) -> tuple[SemanticRequestState, str | None, dict | None, dict | None]:
        """Classify semantic acceptance for one already-sent monster click.

        Exact WORLD_ATTACK_REQUEST target evidence is strongest. A MOVE_REQUEST
        emitted by the same client after this transaction proves that Dofus accepted the click as a
        world interaction even if it is still walking toward the group; that is
        sufficient to forbid a duplicate click, but not to confirm fight entry.
        """
        current_session_id = getattr(self.observability, "session_id", None) if self.observability is not None else None
        if pending.observability_session_id and str(current_session_id or "") != str(pending.observability_session_id):
            return SemanticRequestState.UNKNOWN, None, None, {
                "reason": "OBSERVABILITY_SESSION_CHANGED",
                "sent_session_id": pending.observability_session_id,
                "current_session_id": current_session_id,
            }
        if pending.client_instance_id and hasattr(self.input, "client_instance_id"):
            try:
                current_client_instance_id = self.input.client_instance_id()
            except Exception:
                current_client_instance_id = None
            if current_client_instance_id and str(current_client_instance_id) != str(pending.client_instance_id):
                return SemanticRequestState.UNKNOWN, None, None, {
                    "reason": "CLIENT_INSTANCE_CHANGED",
                    "sent_client_instance_id": pending.client_instance_id,
                    "current_client_instance_id": current_client_instance_id,
                }

        window_available, protocol_window = self._protocol_window_summary_since(
            after_monotonic_ms=int(pending.sent_after_monotonic_ms),
            client_instance_id=pending.client_instance_id,
            direction="client_to_server",
        )
        attack_available, attack_request = self._protocol_semantic_matching_ints_since(
            semantic=ProtocolWireSemantic.WORLD_ATTACK_REQUEST,
            after_monotonic_ms=int(pending.sent_after_monotonic_ms),
            client_instance_id=pending.client_instance_id,
            target_group_id=int(pending.entity_id),
        )
        if attack_available and attack_request is None:
            # Retain the newest mismatching attack for diagnostics, while exact
            # matching above searches the bounded window so later/manual traffic
            # cannot erase valid semantic proof of this transaction.
            _, attack_request = self._protocol_semantic_evidence_since(
                semantic=ProtocolWireSemantic.WORLD_ATTACK_REQUEST,
                after_monotonic_ms=int(pending.sent_after_monotonic_ms),
                client_instance_id=pending.client_instance_id,
            )
        move_available, move_request = self._protocol_semantic_evidence_since(
            semantic=ProtocolWireSemantic.MOVE_REQUEST,
            after_monotonic_ms=int(pending.sent_after_monotonic_ms),
            client_instance_id=pending.client_instance_id,
        )
        if attack_request is not None:
            target = self._decode_world_attack_target(attack_request)
            enriched = {**dict(attack_request), "decoded_target_group_id": target}
            if target == int(pending.entity_id):
                return SemanticRequestState.OBSERVED, "ATTACK_WORLD_MONSTER_GROUP_REQUEST", enriched, {
                    "protocol_window": protocol_window if window_available else None,
                }
            # A different attack request from the same exact client after ANKA's
            # click is positive semantic evidence, but it cannot authorize the
            # requested target.  Keep it as a target-mismatch condition.
            return SemanticRequestState.OBSERVED, "ATTACK_WORLD_MONSTER_GROUP_REQUEST_MISMATCH", enriched, {
                "protocol_window": protocol_window if window_available else None,
            }
        if move_request is not None:
            return SemanticRequestState.OBSERVED, "MOVE_REQUEST", dict(move_request), {
                "protocol_window": protocol_window if window_available else None,
            }
        activity_available, activity = self._protocol_activity_since(
            after_monotonic_ms=int(pending.sent_after_monotonic_ms),
            client_instance_id=pending.client_instance_id,
            direction="client_to_server",
        )
        if attack_available and move_available and activity_available and activity is not None:
            return SemanticRequestState.ABSENT, None, None, {
                "protocol_window_advanced": True,
                "latest_protocol_activity": activity,
                "protocol_window": protocol_window if window_available else None,
            }
        return SemanticRequestState.UNKNOWN, None, None, {
            "reason": "PROTOCOL_WINDOW_NOT_ADVANCED" if attack_available and move_available and activity_available else "PROTOCOL_QUERY_UNAVAILABLE",
            "attack_query_available": bool(attack_available),
            "move_query_available": bool(move_available),
            "activity_query_available": bool(activity_available),
            "window_query_available": bool(window_available),
            "latest_protocol_activity": activity,
            "protocol_window": protocol_window if window_available else None,
        }

    def _confirmed_launch_result(self, pending: PendingWorldInteraction, confirmed: CanonicalSnapshot) -> dict:
        result = {
            "status": "CONFIRMED",
            "confirmed_revision": int(confirmed.revision),
            "detail": "fight start confirmed from the exact generation-scoped launch transaction",
            "launch_group_id": int(pending.entity_id),
            "launch_map_id": int(pending.map_id),
            "launch_cell_id": int(pending.cell_id),
            "attempt_index": int(pending.attempt_index),
            "semantic_request_state": pending.semantic_state.value,
            "semantic_request_kind": pending.semantic_kind,
            "semantic_request_observed": pending.semantic_state is SemanticRequestState.OBSERVED,
            "semantic_request_evidence": pending.semantic_evidence,
            "protocol_window_evidence": pending.protocol_window_evidence,
            "transaction_id": pending.transaction_id,
            "origin_action_id": pending.origin_action_id,
            "transaction": pending.to_dict(),
        }
        if pending.input_evidence:
            result.update(dict(pending.input_evidence))
        if confirmed.fight.fight_instance_id is not None:
            result["fight_instance_id"] = int(confirmed.fight.fight_instance_id)
        if confirmed.fight.initiating_actor_id.status is ValueStatus.KNOWN:
            result["leader_actor_id"] = int(confirmed.fight.initiating_actor_id.value)
        if confirmed.fight.origin_world_entity_id.status is ValueStatus.KNOWN:
            result["origin_world_entity_id"] = int(confirmed.fight.origin_world_entity_id.value)
        return result

    def _observe_pending_launch(
        self,
        pending: PendingWorldInteraction,
        *,
        poll_for_semantic_grace: bool = False,
    ) -> dict:
        """Observe a launch transaction without sending another physical click."""
        # Request absence must never be inferred from a short "semantic grace".
        # The real R5.116 second-fight failure did not show its first post-click
        # outbound packet until ~3.5 s. More importantly, unrelated outbound
        # traffic may appear before the eventual MOVE_REQUEST/WORLD_ATTACK_REQUEST. Therefore a
        # duplicate click is eligible only after the *entire* configured launch
        # confirmation window has elapsed, followed by a small journal-settle
        # margin so a correlated protocol row cannot arrive just behind the
        # coverage row used to prove absence.
        confirmation_polls = self._confirmation_poll_budget("launch_fight")
        settlement_polls = self._settlement_poll_budget("launch_fight")
        confirmation_ms = int(confirmation_polls * self.confirmation_interval_seconds * 1000)
        settlement_ms = int(settlement_polls * self.confirmation_interval_seconds * 1000)
        acceptance_deadline_ms = max(
            int(self._world_interaction_semantic_grace_seconds * 1000),
            confirmation_ms,
        )
        protocol_settle_ms = max(250, int(self.confirmation_interval_seconds * 3 * 1000))
        negative_decision_ms = acceptance_deadline_ms + protocol_settle_ms
        settlement_deadline_ms = max(
            confirmation_ms + settlement_ms,
            negative_decision_ms + settlement_ms,
        )
        if poll_for_semantic_grace:
            polls = max(
                2,
                int(math.ceil(negative_decision_ms / (self.confirmation_interval_seconds * 1000))) + 2,
            )
        else:
            polls = 1
        evidence_query_available = False
        negative_evidence_confirmed = False

        for index in range(max(1, polls)):
            current = self.state.snapshot()
            now_ms = int(self.monotonic_clock() * 1000)
            pending = self._update_world_interaction(
                pending.with_target_observation(
                    self._world_target_observation(
                        current,
                        pending,
                        observed_monotonic_ms=now_ms,
                    )
                )
            )
            if current.revision > int(pending.selected_revision) and current.fight.present:
                origin = current.fight.origin_world_entity_id
                if origin.status is ValueStatus.KNOWN and int(origin.value) != int(pending.entity_id):
                    self._finish_world_interaction(pending)
                    return self._uncertain(
                        "fight appeared after launch input but the selected group/fight origin was not confirmed: observed origin does not match the selected monster group",
                        failure_code="WORLD_INTERACTION_TARGET_MISMATCH",
                        retry_allowed=False,
                        launch_group_id=int(pending.entity_id),
                        observed_origin_world_entity_id=int(origin.value),
                        transaction=pending.to_dict(),
                    )
                self._finish_world_interaction(pending)
                return self._confirmed_launch_result(pending, current)

            previous_semantic_state = pending.semantic_state
            state, kind, evidence, unavailable = self._launch_request_evidence(pending)
            if isinstance(unavailable, dict) and unavailable.get("reason") in {
                "OBSERVABILITY_SESSION_CHANGED", "CLIENT_INSTANCE_CHANGED"
            }:
                self._finish_world_interaction(pending)
                return self._uncertain(
                    "unresolved world interaction crossed a process/client evidence generation; blind retry is forbidden",
                    failure_code="WORLD_INTERACTION_EVIDENCE_UNAVAILABLE",
                    retry_allowed=False,
                    launch_group_id=int(pending.entity_id),
                    semantic_request_observed=(
                        True if pending.semantic_state is SemanticRequestState.OBSERVED else None
                    ),
                    semantic_request_state=pending.semantic_state.value,
                    first_missing_boundary="WORLD_INTERACTION_SETTLEMENT_CONTINUITY",
                    likely_owner="WORLD_INTERACTION_EXECUTION",
                    continuity_break=dict(unavailable),
                    transaction=pending.to_dict(),
                )
            evidence_query_available = (
                state is SemanticRequestState.ABSENT
                or (state is SemanticRequestState.OBSERVED and kind is not None)
            )
            updated = pending.with_observation(
                now_monotonic_ms=now_ms,
                state=state,
                kind=kind,
                evidence=evidence,
                protocol_window_evidence=(
                    unavailable.get("protocol_window")
                    if isinstance(unavailable, dict) and isinstance(unavailable.get("protocol_window"), dict)
                    else unavailable if isinstance(unavailable, dict) else None
                ),
            )
            pending = self._update_world_interaction(updated)

            if kind == "ATTACK_WORLD_MONSTER_GROUP_REQUEST_MISMATCH":
                self._finish_world_interaction(pending)
                return self._uncertain(
                    "Dofus emitted an attack request for a different monster group after the launch click",
                    failure_code="WORLD_INTERACTION_TARGET_MISMATCH",
                    retry_allowed=False,
                    launch_group_id=int(pending.entity_id),
                    semantic_request_observed=True,
                    semantic_request_kind=kind,
                    semantic_request_evidence=evidence,
                    transaction=pending.to_dict(),
                )

            if state is SemanticRequestState.OBSERVED:
                # Positive semantic request evidence permanently closes the
                # duplicate-click gate. The short execution settlement window is
                # only a responsiveness budget; if exact fight creation is late,
                # the durable transaction remains observe-only until the parent
                # campaign watchdog decides that progress has truly stalled.
                elapsed_ms = max(0, now_ms - int(pending.sent_after_monotonic_ms))
                request_observed_ms = int(pending.request_observed_monotonic_ms or pending.sent_after_monotonic_ms)
                request_relative_ms = min(
                    acceptance_deadline_ms,
                    max(0, request_observed_ms - int(pending.sent_after_monotonic_ms)),
                )
                request_relative_deadline_ms = request_relative_ms + settlement_ms
                deadline_ms = max(confirmation_ms + settlement_ms, request_relative_deadline_ms)
                if elapsed_ms >= deadline_ms:
                    missing_boundary = (
                        "CANONICAL_FIGHT_CREATION"
                        if pending.semantic_kind == "ATTACK_WORLD_MONSTER_GROUP_REQUEST"
                        else "WORLD_ATTACK_REQUEST_AFTER_MOVE"
                    )
                    return {
                        "status": "IN_PROGRESS",
                        "failure_code": "WORLD_INTERACTION_SETTLING",
                        "detail": (
                            "Dofus accepted the world interaction but exact fight creation is later than the short "
                            "settlement window; the original transaction remains quarantined for passive reconciliation"
                        ),
                        "retry_allowed": False,
                        "physical_retry_allowed": False,
                        "passive_reconciliation": True,
                        "inner_settlement_window_elapsed": True,
                        "attempt_index": int(pending.attempt_index),
                        "launch_group_id": int(pending.entity_id),
                        "semantic_request_observed": True,
                        "semantic_request_state": pending.semantic_state.value,
                        "semantic_request_kind": pending.semantic_kind,
                        "semantic_request_evidence": pending.semantic_evidence,
                        "elapsed_seconds": elapsed_ms / 1000.0,
                        "short_window_seconds": deadline_ms / 1000.0,
                        "first_missing_boundary": missing_boundary,
                        "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
                        "transaction_id": pending.transaction_id,
                        "origin_action_id": pending.origin_action_id,
                        "transaction": pending.to_dict(),
                    }
                return {
                    "status": "IN_PROGRESS",
                    "failure_code": "WORLD_INTERACTION_SETTLING",
                    "detail": "Dofus accepted the world interaction; waiting for exact fight creation without duplicate input",
                    "retry_allowed": False,
                    "attempt_index": int(pending.attempt_index),
                    "launch_group_id": int(pending.entity_id),
                    "semantic_request_observed": True,
                    "semantic_request_state": pending.semantic_state.value,
                    "semantic_request_kind": pending.semantic_kind,
                    "semantic_request_evidence": pending.semantic_evidence,
                    "elapsed_seconds": elapsed_ms / 1000.0,
                    "timeout_seconds": deadline_ms / 1000.0,
                    "transaction_id": pending.transaction_id,
                    "origin_action_id": pending.origin_action_id,
                    "transaction": pending.to_dict(),
                }

            if state is SemanticRequestState.ABSENT:
                elapsed_ms = max(0, now_ms - int(pending.sent_after_monotonic_ms))
                coverage_ok = False
                if elapsed_ms >= negative_decision_ms:
                    coverage_ok, coverage_evidence = self._capture_coverage_for_world_interaction(
                        pending,
                        required_through_monotonic_ms=(
                            int(pending.sent_after_monotonic_ms) + int(negative_decision_ms)
                        ),
                    )
                    pending = self._update_world_interaction(
                        pending.with_capture_coverage(coverage_evidence)
                    )
                # Request absence is deliberately sampled twice.  The protocol
                # trace is populated asynchronously; a single activity row can
                # become visible just before the correlated semantic request row.  Two
                # consecutive outbound-covered ABSENT observations, separated by
                # at least one poll, close that insertion race before a duplicate
                # physical click can be authorized.
                if (
                    previous_semantic_state is SemanticRequestState.ABSENT
                    and elapsed_ms >= negative_decision_ms
                    and coverage_ok
                ):
                    negative_evidence_confirmed = True
                    break

            if index + 1 < polls:
                self.sleep(self.confirmation_interval_seconds)

        # When the bounded trace is available, absence after the semantic grace
        # window is *positive negative evidence*: the client did not accept this
        # physical click. That makes a bounded reacquire/retry safe.
        if (
            negative_evidence_confirmed
            and evidence_query_available
            and pending.semantic_state is SemanticRequestState.ABSENT
        ):
            if self._world_interaction_ledger.retry_allowed(pending):
                attempts = int(pending.attempt_index)
                backoff_seconds = min(5.0, self._world_interaction_retry_backoff_seconds * max(1, attempts))
                retry_not_before_ms = int(self.monotonic_clock() * 1000) + int(backoff_seconds * 1000)
                self._world_interaction_ledger.set_retry_not_before(
                    pending, not_before_monotonic_ms=retry_not_before_ms
                )
                self._clear_world_interaction()
                return {
                    "status": "RETRYABLE",
                    "failure_code": "WORLD_INTERACTION_REQUEST_NOT_OBSERVED",
                    "detail": "physical click was sent but no certified Dofus world request was emitted; reacquire and bounded retry are safe",
                    "retry_allowed": True,
                    "retry_after_seconds": backoff_seconds,
                    "retry_not_before_monotonic_ms": retry_not_before_ms,
                    "attempt_index": attempts,
                    "max_attempts": int(self._world_interaction_ledger.max_physical_attempts),
                    "launch_group_id": int(pending.entity_id),
                    "semantic_request_observed": False,
                    "semantic_request_state": SemanticRequestState.ABSENT.value,
                    "protocol_window_evidence": pending.protocol_window_evidence,
                    "capture_coverage_evidence": pending.capture_coverage_evidence,
                    "first_missing_boundary": "CLIENT_SEMANTIC_ACCEPTANCE",
                    "likely_owner": "WORLD_INTERACTION_EXECUTION",
                    "transaction_id": pending.transaction_id,
                    "origin_action_id": pending.origin_action_id,
                    "transaction": pending.to_dict(),
                }
            self._finish_world_interaction(pending)
            return {
                "status": "FAILED",
                "failure_code": "WORLD_INTERACTION_RETRY_EXHAUSTED",
                "detail": "Dofus repeatedly ignored the projected monster interaction; safe retry budget is exhausted",
                "retry_allowed": False,
                "attempt_index": int(pending.attempt_index),
                "max_attempts": int(self._world_interaction_ledger.max_physical_attempts),
                "launch_group_id": int(pending.entity_id),
                "semantic_request_observed": False,
                "semantic_request_state": SemanticRequestState.ABSENT.value,
                "protocol_window_evidence": pending.protocol_window_evidence,
                "capture_coverage_evidence": pending.capture_coverage_evidence,
                "first_missing_boundary": "CLIENT_SEMANTIC_ACCEPTANCE",
                "likely_owner": "WORLD_INTERACTION_EXECUTION",
                "transaction_id": pending.transaction_id,
                "origin_action_id": pending.origin_action_id,
                "transaction": pending.to_dict(),
            }

        # A first outbound-covered ABSENT sample is not enough to retry: wait for
        # a second consecutive sample so a just-behind semantic request insert can win.
        elapsed_ms = max(0, int(self.monotonic_clock() * 1000) - int(pending.sent_after_monotonic_ms))
        if evidence_query_available and pending.semantic_state is SemanticRequestState.ABSENT:
            deadline_ms = negative_decision_ms
            if elapsed_ms < deadline_ms:
                return {
                    "status": "IN_PROGRESS",
                    "failure_code": "WORLD_INTERACTION_NEGATIVE_EVIDENCE_SETTLING",
                    "detail": "outbound capture is healthy and no launch request is visible yet; waiting for a second consecutive absence observation before any retry",
                    "retry_allowed": False,
                    "attempt_index": int(pending.attempt_index),
                    "launch_group_id": int(pending.entity_id),
                    "semantic_request_observed": False,
                    "semantic_request_state": SemanticRequestState.ABSENT.value,
                    "elapsed_seconds": elapsed_ms / 1000.0,
                    "timeout_seconds": deadline_ms / 1000.0,
                    "transaction_id": pending.transaction_id,
                    "origin_action_id": pending.origin_action_id,
                    "transaction": pending.to_dict(),
                }

        # Without proven outbound coverage, request absence is UNKNOWN and can
        # never authorize a duplicate click. Keep observing the same transaction
        # until its overall launch deadline; then fail closed with causal evidence.
        deadline_ms = settlement_deadline_ms
        if elapsed_ms < deadline_ms:
            return {
                "status": "IN_PROGRESS",
                "failure_code": "WORLD_INTERACTION_EVIDENCE_PENDING",
                "detail": "launch input was sent; outbound semantic-request coverage is not yet sufficient for retry or failure classification",
                "retry_allowed": False,
                "attempt_index": int(pending.attempt_index),
                "launch_group_id": int(pending.entity_id),
                "semantic_request_observed": None,
                "semantic_request_state": SemanticRequestState.UNKNOWN.value,
                "elapsed_seconds": elapsed_ms / 1000.0,
                "timeout_seconds": deadline_ms / 1000.0,
                "transaction_id": pending.transaction_id,
                "origin_action_id": pending.origin_action_id,
                "transaction": pending.to_dict(),
            }

        return {
            "status": "IN_PROGRESS",
            "failure_code": "WORLD_INTERACTION_EVIDENCE_PENDING",
            "detail": (
                "launch input was sent but semantic acceptance/fight creation is still unresolved; "
                "blind retry is forbidden and the original transaction remains under passive reconciliation"
            ),
            "retry_allowed": False,
            "physical_retry_allowed": False,
            "passive_reconciliation": True,
            "inner_settlement_window_elapsed": True,
            "launch_group_id": int(pending.entity_id),
            "semantic_request_observed": None,
            "semantic_request_state": SemanticRequestState.UNKNOWN.value,
            "protocol_window_evidence": pending.protocol_window_evidence,
            "capture_coverage_evidence": pending.capture_coverage_evidence,
            "first_missing_boundary": "CLIENT_SEMANTIC_ACCEPTANCE",
            "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
            "transaction_id": pending.transaction_id,
            "origin_action_id": pending.origin_action_id,
            "transaction": pending.to_dict(),
        }

    def _launch_fight(self, payload: dict) -> dict:
        group_id = int(payload["group_id"])
        origin_action_id = str(payload.get("_execution_action_id") or "") or None
        selected = self.state.snapshot()

        # A physical world interaction already in flight owns the next decision.
        # Observe it *before* generic readiness/map gates: during world->fight
        # transition those gates may legitimately become unsettled, but that must
        # never hide the transaction whose outcome we are waiting to prove.
        pending = self._world_interaction_ledger.pending
        if pending is not None and pending.operation == "launch_fight":
            observed = self._observe_pending_launch(pending)
            if int(pending.entity_id) == group_id:
                return observed
            if str(observed.get("status") or "") in {"FAILED", "UNCERTAIN"}:
                return observed
            return {
                "status": "IN_PROGRESS",
                "failure_code": "WORLD_INTERACTION_PENDING_OTHER_TARGET",
                "detail": "another world interaction owns settlement; requested target input is deferred until that transaction resolves",
                "retry_allowed": False,
                "requested_group_id": group_id,
                "pending_group_id": int(pending.entity_id),
                "pending_result": observed,
                "pending_transaction": pending.to_dict(),
            }

        readiness_block = self._guard_readiness(selected)
        if readiness_block is not None:
            return readiness_block

        if selected.world.map_id.status is not ValueStatus.KNOWN:
            return self._blocked("current world map is not confirmed")

        selected_map_id = int(selected.world.map_id.value)

        if selected.fight.present:
            return self._blocked("fight is already present")
        world = selected.world
        if not world.monster_groups_complete:
            return self._blocked("monster-group snapshot is incomplete")
        selected_group = next((g for g in world.monster_groups if g.group_id == group_id), None)
        if selected_group is None:
            return self._blocked("monster group is not present in the confirmed complete snapshot")
        if selected_group.cell_id.status is not ValueStatus.KNOWN:
            return self._blocked("monster group cell is not confirmed")

        selected_cell_id = int(selected_group.cell_id.value)

        # Retry pacing is owned by Execution, not by a worker-side sleep. A caller
        # may poll immediately after RETRYABLE, but no second physical click is
        # permitted until the durable not-before obligation expires.
        now_ms = int(self.monotonic_clock() * 1000)
        retry_wait_ms = self._world_interaction_ledger.retry_wait_remaining_ms(
            operation="launch_fight", map_id=selected_map_id, entity_id=group_id,
            now_monotonic_ms=now_ms,
        )
        self._persist_world_interaction()
        if retry_wait_ms > 0:
            return {
                "status": "IN_PROGRESS",
                "failure_code": "WORLD_INTERACTION_RETRY_BACKOFF",
                "detail": "safe world-interaction retry is paced by the execution transaction; no physical input was sent",
                "retry_allowed": False,
                "retry_after_seconds": retry_wait_ms / 1000.0,
                "retry_not_before_monotonic_ms": now_ms + retry_wait_ms,
                "attempt_index": self._world_interaction_ledger.attempts_for(
                    operation="launch_fight", map_id=selected_map_id, entity_id=group_id
                ),
                "launch_group_id": group_id,
                "launch_map_id": selected_map_id,
                "first_missing_boundary": "CLIENT_SEMANTIC_ACCEPTANCE",
                "likely_owner": "WORLD_INTERACTION_EXECUTION",
            }

        # Projection is an input-free bridge query. Resolve the selected target
        # once *before* taking the global input lease or changing foreground.
        # R5.162 spent ~25 s repeatedly focusing the CRA window while the same
        # moving monster group was known to be ENTITY_MISMATCH. A failed
        # preflight must never perturb either account's foreground state.
        _preflight_projection, preflight_blocked = self._resolve_safe_cell(
            selected_map_id, selected_cell_id, purpose="MONSTER_GROUP_CLICK",
            label="monster group", target_entity_id=group_id,
        )
        if preflight_blocked is not None:
            preflight_blocked.update({
                "launch_group_id": group_id,
                "selected_revision": int(selected.revision),
                "selected_cell_id": selected_cell_id,
                "current_revision": int(selected.revision),
                "current_cell_id": selected_cell_id,
                "projection_stage": "PRE_FOCUS_PREFLIGHT",
            })
            return preflight_blocked

        focus_acquired_monotonic_ns: int | None = None
        final_snapshot: CanonicalSnapshot | None = None
        final_projection: ProjectionResult | None = None
        final_map_id: int | None = None
        final_cell_id: int | None = None
        key = None
        send_state = PhysicalSendState.NOT_SENT
        input_send_monotonic_ns: int | None = None
        projection_health_before_input: dict | None = None
        window_debug_before_input: dict | None = None
        window_debug_after_input: dict | None = None
        client_instance_id = None
        if hasattr(self.input, "client_instance_id"):
            try:
                client_instance_id = self.input.client_instance_id()
            except Exception:
                client_instance_id = None

        with self._input_lease():
            if not self.input.ensure_target_focused():
                return self._blocked("target Dofus window is not uniquely focused")
            focus_acquired_monotonic_ns = self.monotonic_ns_clock()

            for _ in range(3):
                current = self.state.snapshot()
                if current.fight.present:
                    return self._blocked("fight became present before launch input; no click was sent")
                if current.world.map_id.status is not ValueStatus.KNOWN:
                    return self._blocked("TARGET_MOVING: current world MapId became unknown before launch input")
                current_group = next((g for g in current.world.monster_groups if g.group_id == group_id), None)
                if current_group is None or current_group.cell_id.status is not ValueStatus.KNOWN:
                    return self._blocked("TARGET_MOVING: selected monster group disappeared or lost its current CellId before launch input")
                map_id = int(current.world.map_id.value)
                cell_id = int(current_group.cell_id.value)

                projection, blocked = self._resolve_safe_cell(
                    map_id, cell_id, purpose="MONSTER_GROUP_CLICK", label="monster group",
                    target_entity_id=group_id,
                )
                if blocked is not None:
                    blocked.update({
                        "launch_group_id": group_id,
                        "selected_revision": int(selected.revision),
                        "selected_cell_id": selected_cell_id,
                        "current_revision": int(current.revision),
                        "current_cell_id": cell_id,
                    })
                    return blocked

                revalidated = self.state.snapshot()
                revalidated_group = next((g for g in revalidated.world.monster_groups if g.group_id == group_id), None)
                stable = (
                    not revalidated.fight.present
                    and revalidated.world.map_id.status is ValueStatus.KNOWN
                    and int(revalidated.world.map_id.value) == map_id
                    and revalidated_group is not None
                    and revalidated_group.cell_id.status is ValueStatus.KNOWN
                    and int(revalidated_group.cell_id.value) == cell_id
                )
                if not stable:
                    continue

                next_attempt = self._world_interaction_ledger.attempts_for(
                    operation="launch_fight", map_id=map_id, entity_id=group_id
                ) + 1
                key = self._attempt_key(
                    revalidated.revision, "launch_fight",
                    {"map_id": map_id, "group_id": group_id, "cell_id": cell_id, "attempt_index": next_attempt},
                )
                blocked_attempt = self._guard_new_attempt(key)
                if blocked_attempt is not None:
                    return blocked_attempt
                final_snapshot = revalidated
                final_projection = projection
                final_map_id = map_id
                final_cell_id = cell_id
                health_fn = getattr(self.projection, "health", None)
                if callable(health_fn):
                    try:
                        raw_health = dict(health_fn() or {})
                        projection_health_before_input = {
                            key: raw_health.get(key)
                            for key in (
                                "available", "loaded_map_id", "map_context", "combat_id",
                                "map_generation", "coordinate_generation", "direct_ready",
                                "source_verified", "resolved_cell_count", "source_client_width",
                                "source_client_height", "cell_geometry_fingerprint",
                            )
                            if key in raw_health
                        }
                    except Exception as exc:
                        projection_health_before_input = {"health_error": f"{type(exc).__name__}: {exc}"}
                debug_status = getattr(self.input, "debug_status", None)
                if callable(debug_status):
                    try:
                        raw_window = debug_status()
                        window_debug_before_input = dict(raw_window) if isinstance(raw_window, dict) else None
                    except Exception as exc:
                        window_debug_before_input = {"debug_error": f"{type(exc).__name__}: {exc}"}
                input_send_monotonic_ns = self.monotonic_ns_clock()
                send_state = self._send_projection(projection)
                if callable(debug_status):
                    try:
                        raw_window = debug_status()
                        window_debug_after_input = dict(raw_window) if isinstance(raw_window, dict) else None
                    except Exception as exc:
                        window_debug_after_input = {"debug_error": f"{type(exc).__name__}: {exc}"}
                break
            else:
                return {
                    "status": "BLOCKED",
                    "detail": "TARGET_MOVING: selected monster group did not keep a stable MapId+CellId long enough for safe input",
                    "launch_group_id": group_id,
                    "selected_revision": int(selected.revision),
                    "selected_cell_id": selected_cell_id,
                }

        if send_state is PhysicalSendState.NOT_SENT:
            return self._blocked("fight-launch click was not sent")
        assert key is not None and final_snapshot is not None and final_projection is not None
        assert final_map_id is not None and final_cell_id is not None
        self._mark_sent(key)
        if send_state is PhysicalSendState.UNCERTAIN:
            return self._uncertain(
                "fight-launch send state is uncertain; retry forbidden",
                failure_code="INPUT_UNCERTAIN",
                retry_allowed=False,
            )

        rect = self._safe_world_rect()
        reference_client_point = self._projection_reference_client_point(final_projection)
        input_evidence = {
            "projection_purpose": final_projection.purpose,
            "target_entity_id": final_projection.target_entity_id,
            "entity_anchor_verified": bool(final_projection.entity_anchor_verified),
            "entity_anchor_cell_id": final_projection.entity_anchor_cell_id,
            "entity_nearest_cell_id": final_projection.entity_nearest_cell_id,
            "exact_cell_anchor_verified": bool(final_projection.exact_cell_anchor_verified),
            "exact_cell_anchor_hierarchy": final_projection.exact_cell_anchor_hierarchy,
            "exact_cell_anchor_planar_error": final_projection.exact_cell_anchor_planar_error,
            "coordinate_space": final_projection.coordinate_space,
            "source_client_size": (
                [int(final_projection.source_client_width), int(final_projection.source_client_height)]
                if final_projection.source_client_width is not None and final_projection.source_client_height is not None
                else None
            ),
            "client_point": [int(final_projection.client_point.x), int(final_projection.client_point.y)],
            "reference_client_point": (
                [int(reference_client_point.x), int(reference_client_point.y)]
                if reference_client_point is not None else None
            ),
            "screen_point": [int(final_projection.point.x), int(final_projection.point.y)],
            "safe_world_rect": list(rect) if rect is not None else None,
            "focus_acquired_monotonic_ns": focus_acquired_monotonic_ns,
            "input_send_monotonic_ns": input_send_monotonic_ns,
            "launch_revision": int(final_snapshot.revision),
            "selected_revision": int(selected.revision),
            "selected_cell_id": int(selected_cell_id),
            "final_target_revision": int(final_snapshot.revision),
            "final_target_cell_id": int(final_cell_id),
            "selected_map_id": int(final_map_id),
            "projection_health_before_input": projection_health_before_input,
            "window_debug_before_input": window_debug_before_input,
            "window_debug_after_input": window_debug_after_input,
        }
        pending = self._world_interaction_ledger.begin(
            operation="launch_fight",
            map_id=int(final_map_id),
            entity_id=int(group_id),
            cell_id=int(final_cell_id),
            selected_revision=int(final_snapshot.revision),
            sent_after_monotonic_ms=int((input_send_monotonic_ns or self.monotonic_ns_clock()) // 1_000_000),
            origin_action_id=origin_action_id,
            client_instance_id=client_instance_id,
            created_monotonic_ms=int(self.monotonic_clock() * 1000),
            input_evidence=input_evidence,
            observability_session_id=(
                str(getattr(self.observability, "session_id"))
                if self.observability is not None and getattr(self.observability, "session_id", None)
                else None
            ),
        )
        self._persist_world_interaction()
        return self._observe_pending_launch(pending, poll_for_semantic_grace=True)

    def _join_request_payload_matches(self, evidence: dict | None, *, pending: PendingJoinAttempt) -> bool:
        """Require outbound join evidence to target this exact fight transaction.

        A raw message-name match is not sufficient once the protocol exposes
        stable fight/leader fields.  Otherwise a manual or stale join request on
        the same Dofus client could accidentally satisfy another pending retry
        fence.  Revisions without a certified field binding remain unavailable
        rather than being guessed here.
        """
        binding = self._wire_binding(ProtocolWireSemantic.JOIN_FIGHT_REQUEST)
        if binding is None or not isinstance(evidence, dict):
            return False
        expected = {"fight_instance_id": int(pending.fight_instance_id)}
        if pending.leader_actor_id is not None:
            expected["leader_actor_id"] = int(pending.leader_actor_id)
        return bool(binding.matches_ints(evidence, **expected))

    def _join_request_evidence(self, pending: PendingJoinAttempt) -> tuple[PendingJoinAttempt, bool]:
        """Refresh exact outbound join-request evidence for one sent transaction.

        JOIN_FIGHT_REQUEST evidence is a semantic *request* observation only. It
        never proves that the follower entered the fight; exact Canonical fight
        presence remains the success authority.  When the manifest exposes
        request identity fields, the evidence must match this pending fight (and
        its leader when known), not merely the raw wire message name.
        """
        # Positive request evidence is monotonic.  Once the journal has proven
        # that this physical transaction emitted the exact semantic join request,
        # later bounded-journal rotation or a transient query failure must never
        # erase that proof and accidentally reopen the physical retry gate.
        if pending.semantic_request_observed is True:
            return pending, True
        expected = {"fight_instance_id": int(pending.fight_instance_id)}
        if pending.leader_actor_id is not None:
            expected["leader_actor_id"] = int(pending.leader_actor_id)
        evidence_available, request = self._protocol_semantic_matching_ints_since(
            semantic=ProtocolWireSemantic.JOIN_FIGHT_REQUEST,
            after_monotonic_ms=int(pending.sent_after_monotonic_ms),
            client_instance_id=pending.client_instance_id,
            **expected,
        )
        if not evidence_available:
            return pending, False
        # If no exact row matched, preserve the newest same-semantic row for
        # diagnostics. This makes a mismatch visible without allowing a newer
        # unrelated/manual join to hide an earlier exact request from the same
        # physical transaction window.
        if request is None:
            _, request = self._protocol_semantic_evidence_since(
                semantic=ProtocolWireSemantic.JOIN_FIGHT_REQUEST,
                after_monotonic_ms=int(pending.sent_after_monotonic_ms),
                client_instance_id=pending.client_instance_id,
            )
        observed = self._join_request_payload_matches(request, pending=pending)
        evidence = dict(request) if isinstance(request, dict) else None
        if evidence is not None:
            evidence["semantic_payload_match"] = bool(observed)
            evidence["expected_fight_instance_id"] = int(pending.fight_instance_id)
            if pending.leader_actor_id is not None:
                evidence["expected_leader_actor_id"] = int(pending.leader_actor_id)
        return replace(
            pending,
            semantic_request_observed=bool(observed),
            semantic_request_evidence=(evidence if evidence is not None else pending.semantic_request_evidence),
        ), True

    def _observe_pending_join(
        self,
        *,
        expected_id: int,
        expected_origin: int | None,
        presentation_id: int | None,
        discovery: dict,
        pending: PendingJoinAttempt,
    ) -> dict:
        """Observe an already-sent follower join without sending more input.

        Slow Dofus fight-scene loads can change MapId several seconds before the
        expected fight lifecycle becomes authoritative.  During that interval the
        only safe behavior is to keep observing the same physical attempt.  A
        second click is permitted only after a full operation-specific settlement
        window proves *both* no authoritative interaction and, when protocol
        evidence is available, no outbound JOIN_FIGHT_REQUEST.
        """
        pending, evidence_available = self._join_request_evidence(pending)
        self._fight_join_ledger.mark_pending(pending)
        context_transition_map_id = pending.context_transition_map_id
        context_transition_revision = pending.context_transition_revision

        # Negative target-miss observations are deliberately deferred until the
        # full join settlement window closes.  Canonical world activity can land
        # during focus/hover immediately before the physical click, while the
        # correlated outbound join request may not reach the bounded journal until a few
        # milliseconds later.  Returning TARGET_MISS immediately would let stale
        # pre-click evidence outrank positive transaction evidence.
        target_miss_detail: str | None = None
        target_miss_kind: str | None = None
        target_miss_transition_actor_id: int | None = None

        for _ in range(self._confirmation_poll_budget("join_fight")):
            after = self.state.snapshot()
            if after.fight.present and after.fight.fight_instance_id == expected_id:
                origin_ok = (
                    expected_origin is None
                    or after.fight.origin_world_entity_id.status is not ValueStatus.KNOWN
                    or int(after.fight.origin_world_entity_id.value) == int(expected_origin)
                )
                if origin_ok:
                    pending, refreshed_available = self._join_request_evidence(pending)
                    evidence_available = evidence_available or refreshed_available
                    self._fight_join_ledger.clear_pending(expected_id, presentation_id)
                    return {
                        "status": "CONFIRMED",
                        **discovery,
                        "retry_allowed": False,
                        "manual_fallback_allowed": False,
                        "confirmed_revision": int(after.revision),
                        "confirmed_fight_instance_id": int(expected_id),
                        "join_method": pending.join_method,
                        "physical_join_attempt": int(pending.physical_attempt),
                        "protocol_presentation_ready": pending.protocol_presentation_ready,
                        "join_readiness_source": pending.join_readiness_source,
                        "join_target_diagnostics": pending.join_target_diagnostics,
                        "sent_after_monotonic_ms": int(pending.sent_after_monotonic_ms),
                        "client_instance_id": pending.client_instance_id,
                        "semantic_request_observed": pending.semantic_request_observed,
                        "semantic_request_evidence": pending.semantic_request_evidence,
                        "join_settlement_pending": False,
                        "context_transition_observed": context_transition_map_id is not None,
                        "context_transition_map_id": context_transition_map_id,
                        "context_transition_revision": context_transition_revision,
                        "local_actor_id": (int(pending.local_actor_id) if pending.local_actor_id is not None else None),
                        # Join success proves membership in the fight, not which
                        # actor belongs to this client. Preserve the authority
                        # that existed before input instead of relabeling a weak
                        # transition guess as JOIN_CAUSAL_LOCAL.
                        "local_actor_source": pending.local_actor_source,
                        "local_actor_rank": pending.local_actor_rank,
                        "detail": "follower join confirmed by exact follower fight placement; local actor identity provenance was preserved",
                    }

            # Directional transition evidence can only prove a target miss when it
            # belongs to this local player and no correlated outbound join request
            # has been proven for the physical join transaction.  The live R5.113
            # failure demonstrated that unrelated actors can emit transition events
            # during the hover-to-click interval; those events must never terminate
            # ENU's join.  Refresh request evidence before applying any negative
            # heuristic so positive transaction evidence has strict precedence.
            after_transition_revision = int(getattr(after.world, "last_transition_revision", 0) or 0)
            if after_transition_revision > int(pending.before_transition_revision):
                pending, refreshed_available = self._join_request_evidence(pending)
                evidence_available = evidence_available or refreshed_available
                self._fight_join_ledger.mark_pending(pending)
                transition_actor = after.world.last_transition_actor_id
                transition_actor_id = (
                    int(transition_actor.value)
                    if transition_actor.status is ValueStatus.KNOWN
                    else None
                )
                transition_is_local = (
                    pending.local_actor_id is not None
                    and transition_actor_id is not None
                    and int(transition_actor_id) == int(pending.local_actor_id)
                )
                if transition_is_local and pending.semantic_request_observed is not True:
                    direction = after.world.last_transition_direction
                    direction_value = direction.value if direction.status is ValueStatus.KNOWN else "UNKNOWN"
                    target_miss_detail = (
                        f"join transaction observed a new local-player world transition ({direction_value}) at canonical "
                        f"revision {after_transition_revision}; no correlated outbound JOIN_FIGHT_REQUEST has been proven yet"
                    )
                    target_miss_kind = "WORLD_TRANSITION"
                    target_miss_transition_actor_id = transition_actor_id

            after_map = after.world.map_id
            after_cell = after.world.player_cell_id
            same_world_map = (
                pending.before_world_map_id is not None
                and after_map.status is ValueStatus.KNOWN
                and int(after_map.value) == int(pending.before_world_map_id)
            )
            if (
                same_world_map
                and pending.before_world_cell_id is not None
                and after_cell.status is ValueStatus.KNOWN
                and int(after_cell.value) != int(pending.before_world_cell_id)
            ):
                pending, refreshed_available = self._join_request_evidence(pending)
                evidence_available = evidence_available or refreshed_available
                self._fight_join_ledger.mark_pending(pending)
                if pending.semantic_request_observed is not True and target_miss_detail is None:
                    target_miss_detail = (
                        f"join transaction changed follower world CellId {int(pending.before_world_cell_id)}"
                        f"->{int(after_cell.value)}; no correlated outbound JOIN_FIGHT_REQUEST has been proven yet"
                    )
                    target_miss_kind = "WORLD_CELL_MOVEMENT"

            if (
                pending.before_world_map_id is not None
                and after_map.status is ValueStatus.KNOWN
                and int(after_map.value) != int(pending.before_world_map_id)
            ):
                context_transition_map_id = int(after_map.value)
                context_transition_revision = int(after.revision)
                if (
                    context_transition_map_id != pending.context_transition_map_id
                    or context_transition_revision != pending.context_transition_revision
                ):
                    pending = replace(
                        pending,
                        context_transition_map_id=context_transition_map_id,
                        context_transition_revision=context_transition_revision,
                    )
                    self._fight_join_ledger.mark_pending(pending)

            # A presentation may close while the client is legitimately loading
            # into combat.  Do not convert that close into failure when the same
            # physical attempt has semantic outbound join-request evidence or a combat-context MapId
            # transition.  Otherwise the close is authoritative.
            joinable = after.fight.discovered_joinable
            if joinable.status is ValueStatus.KNOWN and joinable.value is False:
                pending, refreshed_available = self._join_request_evidence(pending)
                evidence_available = evidence_available or refreshed_available
                self._fight_join_ledger.mark_pending(pending)
                if pending.semantic_request_observed is not True and context_transition_map_id is None:
                    detail = "join window closed after click without evidence that the follower join request was accepted"
                    self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "WINDOW_CLOSED", detail)
                    return {
                        "status": "WINDOW_CLOSED",
                        **discovery,
                        "retry_allowed": False,
                        "manual_fallback_allowed": False,
                        "join_failure_code": "WINDOW_CLOSED",
                        "join_method": pending.join_method,
                        "physical_join_attempt": int(pending.physical_attempt),
                        "semantic_request_observed": pending.semantic_request_observed,
                        "semantic_request_evidence": pending.semantic_request_evidence,
                        "detail": detail,
                    }

            self.sleep(self.confirmation_interval_seconds)

        # Close the journal insertion race only after the whole operation-specific
        # confirmation window has elapsed.  This is still input-free.
        pending, refreshed_available = self._join_request_evidence(pending)
        evidence_available = evidence_available or refreshed_available
        pending = replace(
            pending,
            context_transition_map_id=context_transition_map_id,
            context_transition_revision=context_transition_revision,
        )

        # Positive transaction evidence always outranks negative world heuristics.
        # Only after the entire operation-specific settlement window has elapsed
        # may a local-player transition/cell change become TARGET_MISS, and even
        # then only when no outbound join request was proven. This closes both the
        # unrelated-actor bug and the pre-click/capture-insertion race seen live.
        if target_miss_detail is not None and pending.semantic_request_observed is not True:
            detail = (
                f"{target_miss_detail}; full join settlement window elapsed without a correlated outbound JOIN_FIGHT_REQUEST "
                "or exact fight confirmation, so the physical target is classified as a miss"
            )
            self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "TARGET_MISS", detail)
            return {
                "status": "TARGET_MISS",
                **discovery,
                "retry_allowed": False,
                "manual_fallback_allowed": False,
                "join_failure_code": "TARGET_MISS",
                "join_method": pending.join_method,
                "physical_join_attempt": int(pending.physical_attempt),
                "target_miss_kind": target_miss_kind,
                "transition_actor_id": target_miss_transition_actor_id,
                "local_actor_id": pending.local_actor_id,
                "semantic_request_observed": pending.semantic_request_observed,
                "semantic_request_evidence": pending.semantic_request_evidence,
                "join_settlement_pending": False,
                "detail": detail,
            }

        if pending.semantic_request_observed is True or context_transition_map_id is not None:
            self._fight_join_ledger.mark_pending(pending)
            reason = (
                "outbound JOIN_FIGHT_REQUEST is proven"
                if pending.semantic_request_observed is True
                else "combat-context MapId transition is in progress"
            )
            return {
                "status": "JOIN_SETTLING",
                **discovery,
                "retry_allowed": False,
                "manual_fallback_allowed": False,
                "join_failure_code": "JOIN_SETTLING",
                "join_method": pending.join_method,
                "physical_join_attempt": int(pending.physical_attempt),
                "protocol_presentation_ready": pending.protocol_presentation_ready,
                "join_readiness_source": pending.join_readiness_source,
                "join_target_diagnostics": pending.join_target_diagnostics,
                "sent_after_monotonic_ms": int(pending.sent_after_monotonic_ms),
                "client_instance_id": pending.client_instance_id,
                "semantic_request_observed": pending.semantic_request_observed,
                "semantic_request_evidence": pending.semantic_request_evidence,
                "join_settlement_pending": True,
                "context_transition_observed": context_transition_map_id is not None,
                "context_transition_map_id": context_transition_map_id,
                "context_transition_revision": context_transition_revision,
                "detail": (
                    f"follower join is still settling after the bounded confirmation window; {reason}; "
                    "no additional physical input is allowed while this attempt is pending"
                ),
            }

        # When protocol evidence is available, only proven absence of outbound
        # semantic join-request evidence after the full grace window can authorize the one controlled second
        # click.  If the journal is unavailable, preserve the historical bounded
        # two-click compatibility policy only when there is also no authoritative
        # interaction/context transition; a pending transition is always observe-only.
        no_interaction_proven = (
            context_transition_map_id is None
            and (
                (evidence_available and pending.semantic_request_observed is False)
                or not evidence_available
            )
        )
        if no_interaction_proven:
            self._fight_join_ledger.clear_pending(expected_id, presentation_id)
            if int(pending.physical_attempt) < int(self._fight_join_ledger.max_physical_attempts):
                return {
                    "status": "RETRYABLE",
                    **discovery,
                    "retry_allowed": True,
                    "manual_fallback_allowed": False,
                    "join_failure_code": "NO_JOIN_REQUEST" if evidence_available else "NO_INTERACTION",
                    "physical_join_attempt": int(pending.physical_attempt),
                    "join_method": pending.join_method,
                    "protocol_presentation_ready": pending.protocol_presentation_ready,
                    "join_readiness_source": pending.join_readiness_source,
                    "join_target_diagnostics": pending.join_target_diagnostics,
                    "sent_after_monotonic_ms": int(pending.sent_after_monotonic_ms),
                    "client_instance_id": pending.client_instance_id,
                    "semantic_request_observed": pending.semantic_request_observed,
                    "semantic_request_evidence": pending.semantic_request_evidence,
                    "join_settlement_pending": False,
                    "detail": (
                        "the first proven join target produced no outbound JOIN_FIGHT_REQUEST and no authoritative interaction "
                        "during the full confirmation window; one controlled retry is allowed"
                        if evidence_available
                        else "the first proven join target produced no authoritative interaction during the full "
                        "confirmation window; protocol request evidence is unavailable, so only the existing bounded "
                        "single retry policy is preserved"
                    ),
                }
            detail = (
                "second proven join click produced no outbound JOIN_FIGHT_REQUEST or authoritative interaction"
                if evidence_available
                else "second proven join click produced no authoritative interaction"
            )
            self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "NO_INTERACTION", detail)
            return {
                "status": "NO_INTERACTION",
                **discovery,
                "retry_allowed": False,
                "manual_fallback_allowed": False,
                "join_failure_code": "NO_INTERACTION",
                "physical_join_attempt": int(pending.physical_attempt),
                "join_method": pending.join_method,
                "semantic_request_observed": pending.semantic_request_observed,
                "semantic_request_evidence": pending.semantic_request_evidence,
                "join_settlement_pending": False,
                "detail": detail,
            }

        self._fight_join_ledger.mark_pending(pending)
        return {
            "status": "JOIN_SETTLING",
            **discovery,
            "retry_allowed": False,
            "manual_fallback_allowed": False,
            "join_failure_code": "JOIN_EVIDENCE_UNAVAILABLE",
            "physical_join_attempt": int(pending.physical_attempt),
            "join_method": pending.join_method,
            "protocol_presentation_ready": pending.protocol_presentation_ready,
            "join_readiness_source": pending.join_readiness_source,
            "join_target_diagnostics": pending.join_target_diagnostics,
            "sent_after_monotonic_ms": int(pending.sent_after_monotonic_ms),
            "client_instance_id": pending.client_instance_id,
            "semantic_request_observed": None,
            "semantic_request_evidence": None,
            "join_settlement_pending": True,
            "context_transition_observed": context_transition_map_id is not None,
            "context_transition_map_id": context_transition_map_id,
            "context_transition_revision": context_transition_revision,
            "detail": (
                "follower join confirmation is still pending and outbound JOIN_FIGHT_REQUEST evidence is unavailable; "
                "blind retry is forbidden and the existing physical attempt remains observe-only"
            ),
        }

    def _join_fight(self, payload: dict) -> dict:
        reference = payload.get("fight_reference")
        if not isinstance(reference, dict) or not reference:
            return self._blocked("join_fight requires a non-empty fight_reference")
        if "fight_instance_id" not in reference:
            return self._blocked("join_fight requires fight_reference.fight_instance_id")

        current = self.state.snapshot()
        expected_id = int(reference["fight_instance_id"])
        expected_leader = reference.get("leader_actor_id")
        expected_origin = reference.get("origin_world_entity_id")

        discovered_id = current.fight.discovered_fight_instance_id
        discovered_leader = current.fight.discovered_leader_actor_id
        discovered_origin = current.fight.discovered_origin_world_entity_id
        matches = discovered_id.status is ValueStatus.KNOWN and int(discovered_id.value) == expected_id
        if expected_leader is not None:
            matches = matches and discovered_leader.status is ValueStatus.KNOWN and int(discovered_leader.value) == int(expected_leader)
        if expected_origin is not None:
            matches = matches and discovered_origin.status is ValueStatus.KNOWN and int(discovered_origin.value) == int(expected_origin)

        presentation_sv = current.fight.discovered_presentation_id
        presentation_id = int(presentation_sv.value) if presentation_sv.status is ValueStatus.KNOWN else None
        discovery = {
            "wire_discovery_confirmed": bool(matches),
            "discovered_fight_instance_id": int(discovered_id.value) if discovered_id.status is ValueStatus.KNOWN else None,
            "discovered_leader_actor_id": int(discovered_leader.value) if discovered_leader.status is ValueStatus.KNOWN else None,
            "discovered_origin_world_entity_id": int(discovered_origin.value) if discovered_origin.status is ValueStatus.KNOWN else None,
            "discovered_presentation_id": presentation_id,
            "discovered_join_lifecycle": (
                str(current.fight.discovered_join_lifecycle.value)
                if current.fight.discovered_join_lifecycle.status is ValueStatus.KNOWN else None
            ),
            "discovered_joinable": (
                bool(current.fight.discovered_joinable.value)
                if current.fight.discovered_joinable.status is ValueStatus.KNOWN else None
            ),
            "discovered_team_position_cells": list(current.fight.discovered_team_position_cells),
        }

        terminal = self._fight_join_ledger.terminal(expected_id, presentation_id)
        if terminal is not None:
            status, detail = terminal
            return {"status": status, **discovery, "retry_allowed": False, "manual_fallback_allowed": False, "detail": detail}

        # A prior physical click owns the fight generation until it settles.  This
        # check intentionally precedes discovery/join-window gating because Dofus
        # may clear world-side presentation metadata while loading the combat map.
        pending = self._fight_join_ledger.pending(expected_id, presentation_id)
        if pending is not None:
            return self._observe_pending_join(
                expected_id=expected_id,
                expected_origin=(int(expected_origin) if expected_origin is not None else None),
                presentation_id=presentation_id,
                discovery=discovery,
                pending=pending,
            )

        if current.fight.present and current.fight.fight_instance_id == expected_id:
            origin = current.fight.origin_world_entity_id
            if expected_origin is None or origin.status is not ValueStatus.KNOWN or int(origin.value) == int(expected_origin):
                canonical_raw, canonical_rank, canonical_source = canonical_local_identity_authority(current)
                canonical_local = authoritative_canonical_local_actor_id(current)
                local_actor_id = canonical_local
                return {
                    "status": "CONFIRMED", "confirmed_revision": current.revision,
                    "confirmed_fight_instance_id": expected_id, "wire_discovery_confirmed": bool(matches),
                    "retry_allowed": False, "manual_fallback_allowed": False,
                    "join_settlement_pending": False,
                    "local_actor_id": local_actor_id,
                    "local_actor_source": (
                        f"CANONICAL_LOCAL_PLAYER:{canonical_source or 'UNKNOWN'}" if canonical_local is not None else None
                    ),
                    "local_actor_rank": (int(canonical_rank) if canonical_local is not None else None),
                    "provisional_local_actor_id": (int(canonical_raw) if canonical_raw is not None and canonical_local is None else None),
                    "detail": "requested follower fight is already present",
                }

        if not matches:
            return {
                "status": "BLOCKED", **discovery, "retry_allowed": True, "manual_fallback_allowed": False,
                "join_failure_code": "DISCOVERY_NOT_READY",
                "detail": "protocol follower fight discovery does not match the requested fight; no join input was sent",
            }

        joinable = current.fight.discovered_joinable
        if joinable.status is ValueStatus.KNOWN and joinable.value is False:
            detail = "protocol lifecycle closed the follower join window before input"
            self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "WINDOW_CLOSED", detail)
            return {
                "status": "WINDOW_CLOSED", **discovery, "retry_allowed": False, "manual_fallback_allowed": False,
                "join_failure_code": "WINDOW_CLOSED", "detail": detail,
            }

        lifecycle = current.fight.discovered_join_lifecycle
        presentation_ready = (
            presentation_id is not None
            and lifecycle.status is ValueStatus.KNOWN
            and str(lifecycle.value) == "PRESENTED"
            and joinable.status is ValueStatus.KNOWN
            and joinable.value is True
        )
        protocol_presentation_ready = bool(presentation_ready)
        join_readiness_source = "PROTOCOL_PRESENTATION" if presentation_ready else "LIVE_FIGHT_ENTRY_PENDING"
        # Exact protocol discovery owns fight identity, but presentation is only
        # one admissible target-readiness proof. Some protocol revisions can emit
        # discovery without a richer presentation event. In that case the calibrated
        # fixed JOIN_FIGHT coordinate remains forbidden; only the account-local
        # Unity resolver may authorize input by proving the exact fight object.

        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return {**runtime_block, **discovery, "retry_allowed": True, "manual_fallback_allowed": False}

        launch_map_id = reference.get("launch_map_id")
        launch_cell_id = reference.get("launch_cell_id")
        join_method = "PENDING_TARGET_PROOF"
        if launch_map_id is None or launch_cell_id is None:
            return {
                "status": "BLOCKED", **discovery, "retry_allowed": False, "manual_fallback_allowed": False,
                "join_failure_code": "LAUNCH_CONTEXT_MISSING",
                "protocol_presentation_ready": bool(presentation_ready),
                "join_readiness_source": "PROTOCOL_PRESENTATION" if presentation_ready else "LIVE_FIGHT_ENTRY_PENDING",
                "detail": "live fight-entry targeting requires leader launch MapId and launch CellId; no input was sent",
            }
        if current.world.map_id.status is not ValueStatus.KNOWN or int(current.world.map_id.value) != int(launch_map_id):
            return {
                "status": "BLOCKED", **discovery, "retry_allowed": False, "manual_fallback_allowed": False,
                "join_failure_code": "FOLLOWER_WORLD_MAP_MISMATCH",
                "protocol_presentation_ready": bool(presentation_ready),
                "join_readiness_source": "PROTOCOL_PRESENTATION" if presentation_ready else "LIVE_FIGHT_ENTRY_PENDING",
                "detail": "follower world MapId does not match the leader launch MapId; no join input was sent",
            }
        presentation_map = current.fight.discovered_world_map_id
        if presentation_map.status is ValueStatus.KNOWN and int(presentation_map.value) != int(launch_map_id):
            return {
                "status": "BLOCKED", **discovery, "retry_allowed": False, "manual_fallback_allowed": False,
                "join_failure_code": "PRESENTATION_MAP_MISMATCH",
                "detail": "same-generation JOIN_FIGHT presentation belongs to a different world MapId; no input was sent",
            }

        attempts = self._fight_join_ledger.attempts(expected_id, presentation_id)
        if attempts >= 2:
            detail = "two controlled follower join clicks produced no authoritative interaction"
            self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "NO_INTERACTION", detail)
            return {"status":"NO_INTERACTION", **discovery, "retry_allowed":False, "manual_fallback_allowed":False, "detail":detail}

        with self._input_lease():
            if not self.input.ensure_target_focused():
                return {
                    "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                    "detail":"target Dofus window is not uniquely focused",
                }
            latest = self.state.snapshot()
            if latest.fight.present and latest.fight.fight_instance_id == expected_id:
                latest_origin = latest.fight.origin_world_entity_id
                if expected_origin is not None and latest_origin.status is ValueStatus.KNOWN and int(latest_origin.value) != int(expected_origin):
                    detail = "expected fight id became present with a conflicting authoritative origin entity; no join input was sent"
                    self._fight_join_ledger.mark_terminal(expected_id, presentation_id, "IDENTITY_MISMATCH", detail)
                    return {
                        "status":"IDENTITY_MISMATCH", **discovery, "retry_allowed":False, "manual_fallback_allowed":False,
                        "join_failure_code":"IDENTITY_MISMATCH", "join_method":join_method, "detail":detail,
                    }
                return {
                    "status":"CONFIRMED", **discovery, "retry_allowed":False, "manual_fallback_allowed":False,
                    "confirmed_revision":latest.revision, "confirmed_fight_instance_id":expected_id,
                    "join_method":join_method, "detail":"requested follower fight became present before join input",
                }

            # Revalidate exact discovery after focus acquisition and before any
            # hover/click.  A different presentation can replace the original in
            # this small interval; stale pre-focus identity must never authorize
            # physical input into the wrong fight.
            latest_id = latest.fight.discovered_fight_instance_id
            latest_leader = latest.fight.discovered_leader_actor_id
            latest_origin = latest.fight.discovered_origin_world_entity_id
            latest_matches = latest_id.status is ValueStatus.KNOWN and int(latest_id.value) == expected_id
            if expected_leader is not None:
                latest_matches = latest_matches and latest_leader.status is ValueStatus.KNOWN and int(latest_leader.value) == int(expected_leader)
            if expected_origin is not None:
                latest_matches = latest_matches and latest_origin.status is ValueStatus.KNOWN and int(latest_origin.value) == int(expected_origin)
            if not latest_matches:
                return {
                    "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                    "join_failure_code":"DISCOVERY_CHANGED_BEFORE_INPUT",
                    "detail":"follower fight discovery changed after focus acquisition; no join input was sent",
                }

            latest_joinable = latest.fight.discovered_joinable
            if latest_joinable.status is ValueStatus.KNOWN and latest_joinable.value is False:
                detail="protocol lifecycle closed the follower join window before physical input"
                self._fight_join_ledger.mark_terminal(expected_id,presentation_id,"WINDOW_CLOSED",detail)
                return {"status":"WINDOW_CLOSED",**discovery,"retry_allowed":False,"manual_fallback_allowed":False,
                        "join_failure_code":"WINDOW_CLOSED","join_method":join_method,
                        "protocol_presentation_ready":protocol_presentation_ready,
                        "join_readiness_source":join_readiness_source,"detail":detail}
            latest_lifecycle = latest.fight.discovered_join_lifecycle
            latest_presentation = latest.fight.discovered_presentation_id
            latest_presentation_ready = (
                latest_presentation.status is ValueStatus.KNOWN
                and latest_lifecycle.status is ValueStatus.KNOWN
                and str(latest_lifecycle.value) == "PRESENTED"
                and latest_joinable.status is ValueStatus.KNOWN
                and latest_joinable.value is True
            )
            if latest.world.map_id.status is not ValueStatus.KNOWN or int(latest.world.map_id.value) != int(launch_map_id):
                return {
                    "status":"BLOCKED", **discovery, "retry_allowed":False, "manual_fallback_allowed":False,
                    "detail":"follower world MapId changed before live fight-entry join input",
                }

            latest_presentation = latest.fight.discovered_presentation_id
            if latest_presentation.status is ValueStatus.KNOWN:
                presentation_id = int(latest_presentation.value)
            anchor_sv = latest.fight.discovered_join_anchor_cell_id
            join_anchor_cell_id = int(anchor_sv.value) if anchor_sv.status is ValueStatus.KNOWN else None
            candidate_cell_ids = tuple(int(x) for x in latest.fight.discovered_team_position_cells if 0 <= int(x) <= 559)

            # A fixed calibrated control is safe only when protocol proves the
            # same-generation presentation. Without semantic presentation evidence, force bridge proof.
            join_control = self._client_point("controls", "JOIN_FIGHT") if latest_presentation_ready else None
            projection = None
            join_target_diagnostics: dict = {}
            protocol_presentation_ready = bool(latest_presentation_ready)
            join_readiness_source = "PROTOCOL_PRESENTATION" if latest_presentation_ready else "LIVE_FIGHT_ENTRY_PENDING"

            if join_control is not None:
                join_method = "CALIBRATED_JOIN_CONTROL"
                target_point, target_width, target_height = join_control
                mover = getattr(self.input, "move_client", None)
                if not callable(mover):
                    return {
                        "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                        "join_failure_code":"HOVER_UNAVAILABLE",
                        "detail":"verified JOIN_FIGHT control is available but deterministic hover refresh is unavailable",
                    }
                neutral = CalibrationPoint(x=32, y=32, verified=True, source="fight_join:hover_neutral")
                if mover(neutral, expected_width=int(target_width), expected_height=int(target_height)) is False:
                    return {
                        "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                        "join_failure_code":"NEUTRAL_HOVER_FAILED",
                        "detail":"neutral hover refresh could not be sent",
                    }
                self.sleep(0.08)
                if mover(target_point, expected_width=int(target_width), expected_height=int(target_height)) is False:
                    return {
                        "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                        "join_failure_code":"TARGET_HOVER_FAILED",
                        "detail":"JOIN_FIGHT target hover refresh could not be sent",
                    }
                self.sleep(0.12)
                join_target_diagnostics = {
                    "target_kind":"JOIN_FIGHT_CONTROL",
                    "reference_client_point":[int(target_point.x), int(target_point.y)],
                    "reference_client_size":[int(target_width), int(target_height)],
                    "source":str(target_point.source),
                }
            else:
                join_method = "LIVE_FIGHT_ENTRY"
                resolve_fight_entry = getattr(self.projection, "resolve_fight_entry", None)
                if not callable(resolve_fight_entry):
                    return {
                        "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                        "protocol_presentation_ready": protocol_presentation_ready,
                        "join_readiness_source": join_readiness_source,
                        "join_failure_code":"TARGET_PROOF_UNAVAILABLE",
                        "detail":"live fight-entry projection resolver is unavailable and no safe follower join target is currently proven; no input was sent",
                    }
                projection = resolve_fight_entry(
                    map_id=int(launch_map_id), launch_cell_id=int(launch_cell_id), fight_instance_id=expected_id,
                    leader_actor_id=int(expected_leader) if expected_leader is not None else None,
                    origin_world_entity_id=int(expected_origin) if expected_origin is not None else None,
                    presentation_id=presentation_id, candidate_cell_ids=candidate_cell_ids,
                    join_anchor_cell_id=join_anchor_cell_id,
                )
                projection_block = self._projection_blocker(projection, label="fight-entry follower join")
                if projection_block is not None:
                    projection_block.update(discovery)
                    projection_block.update({
                        "retry_allowed": True, "manual_fallback_allowed": False,
                        "join_failure_code": "TARGET_NOT_READY",
                        "join_method": "LIVE_FIGHT_ENTRY",
                        "protocol_presentation_ready": protocol_presentation_ready,
                        "join_readiness_source": join_readiness_source,
                        "fight_entry_diagnostics": projection.diagnostics,
                    })
                    return projection_block

                size = self.calibration.client_size
                reference_point = self._projection_reference_client_point(projection)
                mover = getattr(self.input, "move_client", None)
                if not callable(mover) or size is None or reference_point is None:
                    return {
                        "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                        "join_failure_code":"HOVER_UNAVAILABLE",
                        "fight_entry_diagnostics":projection.diagnostics,
                        "detail":"live fight-entry target is proven but deterministic hover refresh is unavailable",
                    }
                neutral = CalibrationPoint(x=32, y=32, verified=True, source="fight_join:hover_neutral")
                target = CalibrationPoint(x=int(reference_point.x), y=int(reference_point.y), verified=True, source="fight_join:hover_target")
                if mover(neutral, expected_width=int(size.width), expected_height=int(size.height)) is False:
                    return {"status":"BLOCKED",**discovery,"retry_allowed":True,"manual_fallback_allowed":False,"detail":"neutral hover refresh could not be sent"}
                self.sleep(0.08)
                if mover(target, expected_width=int(size.width), expected_height=int(size.height)) is False:
                    return {"status":"BLOCKED",**discovery,"retry_allowed":True,"manual_fallback_allowed":False,"detail":"target hover refresh could not be sent"}
                self.sleep(0.12)
                join_readiness_source = "LIVE_FIGHT_ENTRY_PROOF"
                join_target_diagnostics = {
                    "target_kind":"LIVE_FIGHT_ENTRY",
                    "reference_client_point":[int(target.x), int(target.y)],
                    "reference_client_size":[int(size.width), int(size.height)],
                    "fight_entry_diagnostics":projection.diagnostics,
                }

            attempt_index = attempts + 1
            key = self._attempt_key(
                latest.revision, "join_fight",
                {"fight_instance_id":expected_id,"presentation_id":presentation_id,"physical_attempt":attempt_index,"join_method":join_method},
            )
            blocked = self._guard_new_attempt(key)
            if blocked is not None:
                return {**blocked, **discovery, "retry_allowed":False, "manual_fallback_allowed":False}
            before_cell = latest.world.player_cell_id
            before_map = latest.world.map_id
            before_transition_revision = int(getattr(latest.world, "last_transition_revision", 0) or 0)
            local_actor_raw, local_actor_rank, local_actor_source = canonical_local_identity_authority(latest)
            local_actor_id = authoritative_canonical_local_actor_id(latest)
            if local_actor_id is None:
                local_actor_source = None
                local_actor_rank = None
            sent_after_ms = int(self.monotonic_clock() * 1000)
            if join_control is not None:
                target_point, target_width, target_height = join_control
                sent = self._guarded_physical_send(
                    purpose="FIGHT_JOIN_CONTROL_CLICK",
                    context={"fight_instance_id": int(expected_id)},
                    sender=lambda: self.input.click_client(
                        target_point, expected_width=int(target_width), expected_height=int(target_height),
                    ),
                )
            else:
                assert projection is not None
                sent = self._send_projection(projection)

            input_debug = getattr(self.input, "debug_status", None)
            if callable(input_debug):
                try:
                    diagnostic = input_debug()
                except Exception as exc:
                    diagnostic = {"status":"DIAGNOSTIC_UNAVAILABLE","detail":f"{type(exc).__name__}: {exc}"}
                if isinstance(diagnostic, dict):
                    join_target_diagnostics["input_driver"] = dict(diagnostic)
                    physical_started = diagnostic.get("transaction_started_monotonic_ms")
                    if physical_started is not None:
                        sent_after_ms = int(physical_started)

        if sent is PhysicalSendState.NOT_SENT:
            return {
                "status":"BLOCKED", **discovery, "retry_allowed":True, "manual_fallback_allowed":False,
                "detail":f"{join_method} input was not sent",
            }
        self._mark_sent(key)
        physical_attempt = self._fight_join_ledger.record_click(expected_id,presentation_id)
        if sent is PhysicalSendState.UNCERTAIN:
            detail=f"{join_method} send state is uncertain; automatic retry forbidden"
            self._fight_join_ledger.mark_terminal(expected_id,presentation_id,"UNCERTAIN",detail)
            result=self._uncertain(detail)
            result.update(discovery)
            result.update({"retry_allowed":False,"manual_fallback_allowed":False})
            return result

        client_instance_id = None
        if hasattr(self.input, "client_instance_id"):
            try:
                client_instance_id = self.input.client_instance_id()
            except Exception:
                client_instance_id = None
        pending = PendingJoinAttempt(
            fight_instance_id=int(expected_id),
            presentation_id=(int(presentation_id) if presentation_id is not None else None),
            physical_attempt=int(physical_attempt),
            sent_after_monotonic_ms=int(sent_after_ms),
            client_instance_id=(str(client_instance_id) if client_instance_id else None),
            join_method=str(join_method),
            protocol_presentation_ready=bool(protocol_presentation_ready),
            join_readiness_source=str(join_readiness_source),
            join_target_diagnostics=dict(join_target_diagnostics),
            before_world_map_id=(int(before_map.value) if before_map.status is ValueStatus.KNOWN else None),
            before_world_cell_id=(int(before_cell.value) if before_cell.status is ValueStatus.KNOWN else None),
            before_transition_revision=int(before_transition_revision),
            leader_actor_id=(
                int(expected_leader)
                if expected_leader is not None
                else (int(latest_leader.value) if latest_leader.status is ValueStatus.KNOWN else None)
            ),
            local_actor_id=(int(local_actor_id) if local_actor_id is not None else None),
            local_actor_source=(
                f"CANONICAL_LOCAL_PLAYER:{local_actor_source or 'UNKNOWN'}" if local_actor_id is not None else None
            ),
            local_actor_rank=(int(local_actor_rank) if local_actor_rank is not None else None),
        )
        self._fight_join_ledger.mark_pending(pending)
        return self._observe_pending_join(
            expected_id=expected_id,
            expected_origin=(int(expected_origin) if expected_origin is not None else None),
            presentation_id=presentation_id,
            discovery=discovery,
            pending=pending,
        )

    def _place_fighter(self, payload: dict) -> dict:
        before = self.state.snapshot()
        if self._uncertainty_is_fight_placement():
            reconciliation = self._reconcile_fight_placement_uncertainty_locked(
                reason="PLACEMENT_WORKFLOW_POLL"
            )
            if str(reconciliation.get("status") or "").upper() != "RECONCILED":
                context = dict(self._uncertain_context or {})
                return {
                    "status": "IN_PROGRESS",
                    "failure_code": FailureCode.FIGHT_PLACEMENT_CAUSALITY_PENDING.value,
                    "detail": self._uncertain_detail or "fight placement confirmation is still pending",
                    "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                    "retry_allowed": True, "physical_retry_allowed": False,
                    "safe_replan": False, "reconciliation_required": True,
                    "input_quarantined": True,
                    "first_missing_boundary": "FIGHT_PLACEMENT_CONFIRMATION",
                    "likely_owner": "LIVE_CONFIRMATION_OR_TRANSPORT",
                    "origin_action_id": context.get("origin_action_id"),
                    "fight_instance_id": context.get("fight_instance_id"),
                    "actor_id": context.get("actor_id"),
                    "target_cell_id": context.get("target_cell_id"),
                    "reconciliation": reconciliation,
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": context.get("origin_action_id"),
                }
            before = self.state.snapshot()
        elif self._uncertain_detail is not None:
            # Never bypass an unrelated unresolved input transaction.
            return self._blocked(f"UNCERTAIN_FENCE active: {self._uncertain_detail}")
        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return runtime_block
        if not before.fight.present:
            return self._blocked("no fight is present")
        if before.fight.active_actor_id.status is ValueStatus.KNOWN:
            return self._blocked("fight is already active; placement is closed")
        if before.fight.phase.status is ValueStatus.KNOWN and str(before.fight.phase.value) != "PLACEMENT":
            return self._blocked("fight is not in placement phase")
        identity = self._preparation_local_identity(before, payload)
        if identity.status is LocalFighterIdentityStatus.CONFLICT:
            return {
                **self._blocked(identity.detail),
                "failure_code": "LOCAL_FIGHTER_IDENTITY_CONFLICT",
                "local_identity": identity.to_dict(),
            }
        if not identity.resolved:
            return {
                **self._blocked(identity.detail),
                "failure_code": "LOCAL_FIGHTER_IDENTITY_NOT_CONVERGED",
                "local_identity": identity.to_dict(),
            }
        if before.fight.map_id.status is not ValueStatus.KNOWN:
            return self._blocked("fight MapId is not confirmed")
        local_id = int(identity.actor_id)
        local_actor = next((item for item in before.fight.actors if int(item.actor_id) == local_id), None)
        if local_actor is None or local_actor.cell_id.status is not ValueStatus.KNOWN:
            return self._blocked("local placement CellId is not confirmed")
        current_cell = int(local_actor.cell_id.value)
        defender = set(int(cell) for cell in before.fight.legal_placement_defender_cells)
        challenger = set(int(cell) for cell in before.fight.legal_placement_challenger_cells)
        in_defender = current_cell in defender
        in_challenger = current_cell in challenger
        if in_defender == in_challenger:
            return self._blocked("cannot determine local legal placement side from current CellId")
        legal = defender if in_defender else challenger
        target_cell = int(payload["target_cell_id"])
        if target_cell not in legal:
            return self._blocked("target CellId is not in the local side legal placement set")
        occupied = {
            int(actor.cell_id.value)
            for actor in before.fight.actors
            if int(actor.actor_id) != local_id and actor.cell_id.status is ValueStatus.KNOWN
        }
        if target_cell in occupied:
            return self._blocked("target placement CellId is occupied")
        if target_cell == current_cell:
            return {
                "status": "CONFIRMED", "confirmed_revision": before.revision,
                "target_cell_id": target_cell, "detail": "local fighter is already on the selected legal placement CellId",
            }
        map_id = int(before.fight.map_id.value)
        key = self._attempt_key(before.revision, "place_fighter", {"actor_id": local_id, "target_cell_id": target_cell})
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked
        with self._input_lease():
            if not self.input.ensure_target_focused():
                return self._blocked("target Dofus window is not uniquely focused")
            projection, projection_block = self._resolve_safe_cell(
                map_id, target_cell, purpose="FIGHT_PLACEMENT_CLICK", label="fight placement target",
            )
            if projection_block is not None:
                return projection_block
            latest = self.state.snapshot()
            if not latest.fight.present or latest.fight.active_actor_id.status is ValueStatus.KNOWN:
                return self._blocked("fight placement state changed before physical input")
            latest_identity = self._preparation_local_identity(latest, payload)
            if not latest_identity.resolved or int(latest_identity.actor_id) != local_id:
                return {
                    **self._blocked(latest_identity.detail),
                    "failure_code": (
                        "LOCAL_FIGHTER_IDENTITY_CONFLICT"
                        if latest_identity.status is LocalFighterIdentityStatus.CONFLICT
                        else "LOCAL_FIGHTER_IDENTITY_NOT_CONVERGED"
                    ),
                    "local_identity": latest_identity.to_dict(),
                }
            if latest.fight.map_id.status is not ValueStatus.KNOWN or int(latest.fight.map_id.value) != map_id:
                return self._blocked("fight MapId changed before placement input")
            occupied_latest = {
                int(actor.cell_id.value) for actor in latest.fight.actors
                if int(actor.actor_id) != local_id and actor.cell_id.status is ValueStatus.KNOWN
            }
            if target_cell in occupied_latest:
                return self._blocked("target placement CellId became occupied before input")
            assert projection is not None and projection.point is not None
            pre_down = FightPlacementPreDownGuard(
                snapshot=self.state.snapshot,
                identity_resolver=self._preparation_local_identity,
                projection_resolver=self._resolve_safe_cell,
                payload=payload,
                fight_instance_id=before.fight.fight_instance_id,
                semantic_map_id=map_id,
                local_actor_id=local_id,
                target_cell_id=target_cell,
                original_projection=projection,
            )
            sent = self._send_projection(projection, pre_down_guard=pre_down)
            placement_input_evidence = self._input_debug_snapshot()
        if sent is PhysicalSendState.NOT_SENT and pre_down.block is not None:
            blocked = dict(pre_down.block)
            blocked["physical_input_evidence"] = placement_input_evidence
            return blocked
        if sent is PhysicalSendState.NOT_SENT:
            blocked = self._blocked("placement input was not sent")
            blocked["physical_input_evidence"] = placement_input_evidence
            return blocked
        self._mark_sent(key)
        if sent is PhysicalSendState.UNCERTAIN:
            pending = self._reconciling(
                "placement delivery is uncertain; passive actor-cell reconciliation required",
                uncertainty_context={
                    "kind": "FIGHT_PLACEMENT",
                    "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                    "basis_revision": int(before.revision),
                    "fight_instance_id": before.fight.fight_instance_id,
                    "actor_id": int(local_id),
                    "target_cell_id": int(target_cell),
                },
                failure_code=FailureCode.FIGHT_PLACEMENT_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.UNCERTAIN.value,
                retry_allowed=True, physical_retry_allowed=False, safe_replan=False,
                reconciliation_required=True, input_quarantined=True,
                first_missing_boundary="FIGHT_PLACEMENT_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
            pending["status"] = "IN_PROGRESS"
            pending["physical_input_evidence"] = dict(placement_input_evidence)
            return pending

        def _placed(snapshot: CanonicalSnapshot) -> bool:
            if not snapshot.fight.present:
                return False
            actor = next((item for item in snapshot.fight.actors if int(item.actor_id) == local_id), None)
            return (
                actor is not None
                and actor.cell_id.status is ValueStatus.KNOWN
                and int(actor.cell_id.value) == target_cell
                and actor.observed.cell_revision > before.revision
            )

        confirmed = self._wait_for(before.revision, _placed, operation="place_fighter")
        if confirmed is None:
            pending = self._reconciling(
                "placement click was sent but actor-cell confirmation is still pending; input quarantined",
                uncertainty_context={
                    "kind": "FIGHT_PLACEMENT",
                    "physical_send_state": PhysicalSendState.SENT.value,
                    "basis_revision": int(before.revision),
                    "fight_instance_id": before.fight.fight_instance_id,
                    "actor_id": int(local_id),
                    "target_cell_id": int(target_cell),
                },
                failure_code=FailureCode.FIGHT_PLACEMENT_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.SENT.value,
                retry_allowed=True, physical_retry_allowed=False, safe_replan=False,
                reconciliation_required=True, input_quarantined=True,
                first_missing_boundary="FIGHT_PLACEMENT_CONFIRMATION",
                likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            )
            pending["status"] = "IN_PROGRESS"
            pending["physical_input_evidence"] = dict(placement_input_evidence)
            return pending
        return {
            "status": "CONFIRMED", "confirmed_revision": confirmed.revision,
            "target_cell_id": target_cell, "detail": "placement CellId confirmed by newer canonical actor position",
            "physical_input_evidence": dict(placement_input_evidence),
        }

    def _choose_challenge(self, payload: dict) -> dict:
        """Fail closed until challenge-selection input is protocol-certified.

        The current calibration maps challenge/Ready/end-turn to the same phase
        control, while R4 has no certified outbound challenge selection request.
        Production preparation is therefore observe-only for challenges.
        """
        before = self.state.snapshot()
        runtime_block = self._guard_runtime_health()
        if runtime_block is not None:
            return runtime_block
        return {
            "status": "BLOCKED",
            "failure_code": "CHALLENGE_SELECTION_UNCERTIFIED",
            "detail": "automatic challenge selection is disabled; placement and Ready remain certified",
            "canonical_revision": int(before.revision),
        }

    def _ready_fight_send(self, payload: dict) -> dict:
        """Send READY and distinguish physical delivery from semantic request/ack.

        R5.111 keeps the non-blocking party design, but a successful SendInput
        transaction is no longer treated as proof that Dofus accepted READY.  The
        controller receives three pieces of evidence:

        * local fighter-ready canonical acknowledgement (authoritative success),
        * outbound READY_REQUEST observed in the bounded protocol trace,
        * or no semantic request evidence after the physical click (safe retry
          candidate, bounded by the parent mission controller).
        """
        before = self.state.snapshot()
        readiness_block = self._guard_readiness(before)
        if readiness_block is not None:
            return readiness_block
        if not before.fight.present:
            return self._blocked("no fight is present")

        identity = self._preparation_local_identity(before, payload)
        if identity.status is LocalFighterIdentityStatus.CONFLICT:
            return {
                "status": "BLOCKED",
                "failure_code": "LOCAL_FIGHTER_IDENTITY_CONFLICT",
                "retry_allowed": False,
                "local_identity": identity.to_dict(),
                "detail": identity.detail,
            }
        if not identity.resolved:
            return {
                "status": "BLOCKED",
                "failure_code": "LOCAL_FIGHTER_IDENTITY_NOT_CONVERGED",
                "retry_allowed": True,
                "local_identity": identity.to_dict(),
                "detail": identity.detail,
            }
        local_actor_id = int(identity.actor_id)
        semantic = self._semantic_control_readiness("READY", before, local_actor_id=local_actor_id)
        if semantic.get("satisfied"):
            return {
                "status": "CONFIRMED",
                "confirmed_revision": before.revision,
                "ready_actor_id": semantic.get("actor_id"),
                "ready_revision": semantic.get("ready_revision"),
                "semantic_request_observed": None,
                "retry_allowed": False,
                "detail": str(semantic.get("detail") or "Ready is already satisfied"),
            }
        if not semantic["ready"]:
            return self._blocked(str(semantic["detail"]))

        control = self._client_point("controls", "READY")
        if control is None:
            return self._blocked("READY calibration is not verified")

        attempt_index = max(1, int(payload.get("attempt_index", 1)))
        ready_sequence_ordinal = max(1, int(payload.get("ready_sequence_ordinal", attempt_index)))
        first_ready_interaction_for_fight = bool(
            payload.get("first_ready_interaction_for_fight", ready_sequence_ordinal == 1)
        )
        fight_instance_id = before.fight.fight_instance_id
        key = self._attempt_key(
            before.revision,
            "ready_fight_send",
            {
                "fight_instance_id": fight_instance_id,
                "actor_id": local_actor_id,
                "attempt_index": attempt_index,
            },
        )
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked

        sent_after_ms = int(self.monotonic_clock() * 1000)
        with self._input_lease():
            authorized = self.state.snapshot()
            authorized_identity = self._preparation_local_identity(authorized, payload)
            authorized_semantic = self._semantic_control_readiness(
                "READY", authorized, local_actor_id=(int(authorized_identity.actor_id) if authorized_identity.resolved else None)
            )
            if (
                not authorized.fight.present
                or authorized.fight.fight_instance_id != fight_instance_id
                or not authorized_identity.resolved
                or int(authorized_identity.actor_id) != local_actor_id
            ):
                return {
                    "status": "BLOCKED",
                    "failure_code": "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "READY_COMMAND_AUTHORIZATION",
                    "likely_owner": "FIGHT_PREPARATION",
                    "retry_allowed": True,
                    "detail": "fight identity/local actor changed before Ready input; no click was sent",
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                    "selected_fight_instance_id": fight_instance_id,
                    "authorization_fight_instance_id": authorized.fight.fight_instance_id,
                }
            if authorized_semantic.get("satisfied"):
                return {
                    "status": "CONFIRMED",
                    "confirmed_revision": int(authorized.revision),
                    "ready_actor_id": authorized_semantic.get("actor_id"),
                    "ready_revision": authorized_semantic.get("ready_revision"),
                    "semantic_request_observed": None,
                    "retry_allowed": False,
                    "detail": str(
                        authorized_semantic.get("detail")
                        or "Ready became satisfied before physical input"
                    ),
                }
            if not authorized_semantic.get("ready"):
                return {
                    "status": "BLOCKED",
                    "failure_code": "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "READY_COMMAND_AUTHORIZATION",
                    "likely_owner": "FIGHT_PREPARATION",
                    "retry_allowed": True,
                    "detail": (
                        "Ready lifecycle state changed before physical input; no click was sent: "
                        + str(authorized_semantic.get("detail") or "control no longer ready")
                    ),
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                }
            ready_prime_evidence: dict = {}
            prime_seconds = max(0.0, float(payload.get("ready_first_interaction_prime_seconds", 0.0) or 0.0))
            force_ready_pointer_prime = bool(payload.get("force_ready_pointer_prime", False))
            prime_requested = bool(first_ready_interaction_for_fight or force_ready_pointer_prime)
            if prime_requested and prime_seconds > 0.0 and hasattr(self.input, "move_client"):
                point, width, height = control
                prime_started_ms = int(self.monotonic_clock() * 1000)
                excursion_evidence: dict | None = None
                try:
                    # A recovery prime must actually re-enter the Ready control.
                    # Moving to the same coordinate again does not reset hover/UI
                    # state when the cursor is already there. Use a bounded,
                    # click-free in-client excursion, then return to the exact
                    # calibrated Ready endpoint. This never invents a click target.
                    if force_ready_pointer_prime:
                        excursion_px = max(0, int(payload.get("ready_recovery_pointer_excursion_pixels", 0) or 0))
                        if excursion_px > 0:
                            margin = 6
                            ex = int(point.x)
                            ey = int(point.y)
                            if int(point.y) - excursion_px >= margin:
                                ey = int(point.y) - excursion_px
                            elif int(point.y) + excursion_px < int(height) - margin:
                                ey = int(point.y) + excursion_px
                            elif int(point.x) - excursion_px >= margin:
                                ex = int(point.x) - excursion_px
                            else:
                                ex = min(int(width) - margin - 1, int(point.x) + excursion_px)
                            excursion = CalibrationPoint(
                                x=max(0, ex), y=max(0, ey), verified=True, source="READY_RECOVERY_POINTER_EXCURSION"
                            )
                            excursion_ok = bool(self.input.move_client(
                                excursion, expected_width=width, expected_height=height,
                            ))
                            excursion_evidence = {
                                "point": [int(excursion.x), int(excursion.y)],
                                "arrived": bool(excursion_ok),
                                "input": self._input_debug_snapshot(),
                            }
                            if not excursion_ok:
                                raise RuntimeError("Ready recovery pointer excursion did not arrive")
                            self.sleep(min(0.10, max(0.03, prime_seconds * 0.20)))
                    primed = bool(self.input.move_client(
                        point, expected_width=width, expected_height=height,
                    ))
                except Exception as exc:
                    primed = False
                    ready_prime_evidence = {
                        "status": "BLOCKED",
                        "failure_code": "READY_POINTER_PRIME_EXCEPTION",
                        "detail": f"{type(exc).__name__}: {exc}",
                    }
                if not ready_prime_evidence:
                    ready_prime_evidence = self._input_debug_snapshot()
                ready_prime_evidence.update({
                    "prime_started_monotonic_ms": prime_started_ms,
                    "prime_seconds": prime_seconds,
                    "prime_cursor_arrived": bool(primed),
                    "prime_mode": "RECOVERY_REENTRY" if force_ready_pointer_prime else "FIRST_INTERACTION",
                    "recovery_episode": payload.get("ready_recovery_episode"),
                    "excursion": excursion_evidence,
                })
                if not primed:
                    return {
                        **self._blocked("Ready pointer prime did not reach the verified control"),
                        "failure_code": "READY_POINTER_PRIME_FAILED",
                        "retry_allowed": True,
                        "ready_prime_evidence": ready_prime_evidence,
                    }
                self.sleep(prime_seconds)
                prime_authorized = self.state.snapshot()
                prime_identity = self._preparation_local_identity(prime_authorized, payload)
                prime_semantic = self._semantic_control_readiness(
                    "READY",
                    prime_authorized,
                    local_actor_id=(int(prime_identity.actor_id) if prime_identity.resolved else None),
                )
                if (
                    not prime_authorized.fight.present
                    or prime_authorized.fight.fight_instance_id != fight_instance_id
                    or not prime_identity.resolved
                    or int(prime_identity.actor_id) != local_actor_id
                    or not prime_semantic.get("ready")
                ):
                    return {
                        "status": "BLOCKED",
                        "failure_code": "READY_STATE_CHANGED_DURING_POINTER_PRIME",
                        "first_missing_boundary": "READY_FIRST_INTERACTION_PRIME",
                        "likely_owner": "FIGHT_PREPARATION",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "ready_prime_evidence": ready_prime_evidence,
                        "detail": "Ready state changed during hover-only first-interaction priming; no click was sent",
                    }
                ready_prime_evidence.update({
                    "prime_finished_monotonic_ms": int(self.monotonic_clock() * 1000),
                    "post_prime_revision": int(prime_authorized.revision),
                    "post_prime_semantic_ready": True,
                })

            try:
                ready_input_before = dict(self.input.debug_status()) if hasattr(self.input, "debug_status") else {}
            except Exception:
                ready_input_before = {}
            prearmed_foreground = bool(payload.get("prearmed_foreground", False))
            sent = (
                self._send_client_prearmed(control)
                if prearmed_foreground
                else self._send_client(control)
            )
            # Persist the immutable click boundary before later debug queries can replace it.
            ready_input_after = self._input_debug_snapshot()
        ready_input_evidence = {
            "selected_revision": int(before.revision),
            "authorization_revision": int(authorized.revision),
            "selected_fight_instance_id": fight_instance_id,
            "authorization_fight_instance_id": authorized.fight.fight_instance_id,
            "actor_id": local_actor_id,
            "attempt_index": attempt_index,
            "ready_sequence_ordinal": ready_sequence_ordinal,
            "first_ready_interaction_for_fight": first_ready_interaction_for_fight,
            "control_reference_client": {
                "x": int(control[0].x), "y": int(control[0].y),
                "reference_width": int(control[1]), "reference_height": int(control[2]),
            },
            "before": ready_input_before,
            "after": ready_input_after,
            "physical_send_state": sent.value,
            "prearmed_foreground_required": bool(payload.get("prearmed_foreground", False)),
            "placement_complete_age_seconds": payload.get("placement_complete_age_seconds"),
            "ready_control_settle_seconds": payload.get("ready_control_settle_seconds"),
            "ready_ui_quiescence_seconds": payload.get("ready_ui_quiescence_seconds"),
            "ready_effective_settle_seconds": payload.get("ready_effective_settle_seconds"),
            "ready_first_interaction_prime_seconds": payload.get("ready_first_interaction_prime_seconds"),
            "force_ready_pointer_prime": bool(payload.get("force_ready_pointer_prime", False)),
            "ready_recovery_episode": payload.get("ready_recovery_episode"),
            "ready_recovery_pointer_excursion_pixels": payload.get("ready_recovery_pointer_excursion_pixels"),
            "prime": dict(ready_prime_evidence),
        }
        # Prefer the driver's physical mouse transaction boundary.  The old
        # pre-focus timestamp could precede the click by hundreds of milliseconds
        # and accidentally correlate unrelated client traffic with READY.
        if hasattr(self.input, "debug_status"):
            try:
                input_diagnostic = ready_input_after or self.input.debug_status()
                physical_started = (
                    input_diagnostic.get("transaction_started_monotonic_ms")
                    if isinstance(input_diagnostic, dict) else None
                )
                if physical_started is not None:
                    sent_after_ms = int(physical_started)
            except Exception:
                pass
        if sent is PhysicalSendState.NOT_SENT:
            prearmed = bool(payload.get("prearmed_foreground", False))
            return {
                **self._blocked(
                    "pre-armed Ready target lost foreground before input; re-arm on a later tick"
                    if prearmed else "Ready input was not sent"
                ),
                "failure_code": (
                    "READY_PREARMED_FOREGROUND_LOST" if prearmed else "READY_PHYSICAL_INPUT_NOT_SENT"
                ),
                "retry_allowed": bool(prearmed),
                "ready_input_evidence": ready_input_evidence,
            }
        self._mark_sent(key)
        if sent is PhysicalSendState.UNCERTAIN:
            return {
                **self._uncertain("Ready send state is uncertain; retry forbidden"),
                "ready_input_evidence": ready_input_evidence,
            }

        # A jyk acknowledgement may already have arrived while SendInput and the
        # post-click settle delay were completing.  Accept only the local actor.
        after = self.state.snapshot()
        actor = next((item for item in after.fight.actors if int(item.actor_id) == local_actor_id), None)
        if (
            after.fight.present
            and after.fight.fight_instance_id == fight_instance_id
            and actor is not None
            and actor.placement_ready.status is ValueStatus.KNOWN
            and actor.placement_ready.value is True
            and int(actor.observed.ready_revision) > int(before.revision)
        ):
            return {
                "status": "CONFIRMED",
                "confirmed_revision": int(after.revision),
                "ready_actor_id": local_actor_id,
                "ready_revision": int(actor.observed.ready_revision),
                "attempt_index": attempt_index,
                "ready_sequence_ordinal": ready_sequence_ordinal,
                "first_ready_interaction_for_fight": first_ready_interaction_for_fight,
                "semantic_request_observed": True,
                "retry_allowed": False,
                "ready_input_evidence": ready_input_evidence,
                "detail": "Ready confirmed by newer local fighter-ready canonical acknowledgement",
            }

        client_instance_id = None
        if hasattr(self.input, "client_instance_id"):
            try:
                client_instance_id = self.input.client_instance_id()
            except Exception:
                client_instance_id = None
        evidence_available, request = self._protocol_semantic_matching_ints_since(
            semantic=ProtocolWireSemantic.READY_REQUEST,
            after_monotonic_ms=sent_after_ms,
            client_instance_id=client_instance_id,
            ready_value=1,
        )
        request_observed = request is not None if evidence_available else None
        retry_allowed = bool(evidence_available and request is None)
        detail = (
            "Ready mouse transaction produced outbound READY_REQUEST; waiting for local fighter-ready canonical acknowledgement"
            if request_observed is True
            else "Ready mouse transaction produced no outbound READY_REQUEST evidence; bounded retry is allowed"
            if request_observed is False
            else "Ready input sent; semantic request evidence unavailable, waiting fail-closed for local acknowledgement"
        )
        return {
            "status": "SENT",
            "sent_revision": int(before.revision),
            "ready_actor_id": local_actor_id,
            "fight_instance_id": fight_instance_id,
            "attempt_index": attempt_index,
            "ready_sequence_ordinal": ready_sequence_ordinal,
            "first_ready_interaction_for_fight": first_ready_interaction_for_fight,
            "sent_after_monotonic_ms": sent_after_ms,
            "client_instance_id": client_instance_id,
            "semantic_request_observed": request_observed,
            "semantic_request_evidence": request,
            "ready_input_evidence": ready_input_evidence,
            "ready_ack_pending": True,
            "retry_allowed": retry_allowed,
            "detail": detail,
        }

    def _ready_fight_probe(self, payload: dict) -> dict:
        """Refresh semantic evidence for a prior READY mouse transaction.

        This operation is input-free.  It exists to close the capture-insertion
        race between a physical click returning and the bounded protocol journal
        receiving the outbound READY_REQUEST.  A retry is allowed only after a
        later probe still proves that no READY_REQUEST was emitted for the same
        account/client/fight attempt.
        """
        snapshot = self.state.snapshot()
        if not snapshot.fight.present:
            return {"status": "BLOCKED", "failure_code": "READY_FIGHT_GONE", "detail": "fight is no longer present"}

        expected_fight = payload.get("fight_instance_id")
        if expected_fight is not None and snapshot.fight.fight_instance_id != int(expected_fight):
            return {
                "status": "BLOCKED",
                "failure_code": "READY_FIGHT_GENERATION_CHANGED",
                "detail": "Ready probe fight generation no longer matches the live fight",
            }

        identity = self._preparation_local_identity(snapshot, payload)
        if not identity.resolved:
            return {
                "status": "BLOCKED",
                "failure_code": (
                    "LOCAL_FIGHTER_IDENTITY_CONFLICT"
                    if identity.status is LocalFighterIdentityStatus.CONFLICT
                    else "READY_LOCAL_ACTOR_UNKNOWN"
                ),
                "local_identity": identity.to_dict(),
                "detail": identity.detail,
            }
        local_actor_id = int(identity.actor_id)
        expected_actor = payload.get("actor_id")
        if expected_actor is not None and int(expected_actor) != local_actor_id:
            return {
                "status": "BLOCKED",
                "failure_code": "READY_LOCAL_ACTOR_CHANGED",
                "detail": "Ready probe local actor no longer matches the attempted fighter",
            }

        actor = next((item for item in snapshot.fight.actors if int(item.actor_id) == local_actor_id), None)
        if actor is not None and actor.placement_ready.status is ValueStatus.KNOWN and actor.placement_ready.value is True:
            return {
                "status": "CONFIRMED",
                "confirmed_revision": int(snapshot.revision),
                "ready_actor_id": local_actor_id,
                "ready_revision": int(actor.observed.ready_revision),
                "semantic_request_observed": True,
                "retry_allowed": False,
                "detail": "local fighter Ready acknowledgement is confirmed",
            }

        sent_after_ms = payload.get("sent_after_monotonic_ms")
        if sent_after_ms is None:
            return {
                "status": "PENDING",
                "semantic_request_observed": None,
                "retry_allowed": False,
                "detail": "Ready request correlation timestamp is unavailable; blind retry is forbidden",
            }

        client_instance_id = payload.get("client_instance_id")
        evidence_available, request = self._protocol_semantic_matching_ints_since(
            semantic=ProtocolWireSemantic.READY_REQUEST,
            after_monotonic_ms=int(sent_after_ms),
            client_instance_id=str(client_instance_id) if client_instance_id else None,
            ready_value=1,
        )
        request_observed = request is not None if evidence_available else None
        return {
            "status": "PENDING",
            "attempt_index": int(payload.get("attempt_index") or 1),
            "sent_after_monotonic_ms": int(sent_after_ms),
            "client_instance_id": client_instance_id,
            "semantic_request_observed": request_observed,
            "semantic_request_evidence": request,
            "ready_ack_pending": True,
            "retry_allowed": bool(evidence_available and request is None),
            "detail": (
                "late outbound READY_REQUEST evidence is now visible; blind retry is forbidden"
                if request_observed is True
                else "no outbound READY_REQUEST is visible after the correlation grace period; bounded retry remains allowed"
                if request_observed is False
                else "Ready protocol evidence remains unavailable; waiting fail-closed for local acknowledgement"
            ),
        }

    def _ready_fight(self, payload: dict) -> dict:
        """Compatibility Ready action with semantic local-fighter confirmation.

        Historically this action accepted the first ACTIVE turn as proof that
        Ready succeeded.  Dofus can auto-start the fight timer even when this
        client never emitted READY_REQUEST, so ACTIVE is not sufficient.  Reuse
        the non-blocking sender and wait only for this account's local jyk
        acknowledgement.
        """
        result = dict(self._ready_fight_send(payload))
        status = str(result.get("status") or "UNKNOWN")
        if status in {"BLOCKED", "UNCERTAIN", "SETTLED"}:
            return result
        if status == "CONFIRMED":
            return result
        if status != "SENT":
            return self._blocked(f"unexpected Ready send status: {status}")

        actor_id = result.get("ready_actor_id")
        fight_instance_id = result.get("fight_instance_id")
        if actor_id is None:
            return self._blocked("Ready was sent but local fighter identity is unavailable")

        def local_ready(snapshot: CanonicalSnapshot) -> bool:
            if not snapshot.fight.present or snapshot.fight.fight_instance_id != fight_instance_id:
                return False
            actor = next((item for item in snapshot.fight.actors if int(item.actor_id) == int(actor_id)), None)
            return bool(
                actor is not None
                and actor.placement_ready.status is ValueStatus.KNOWN
                and actor.placement_ready.value is True
            )

        basis_revision = int(result.get("sent_revision") or 0)
        confirmed = self._wait_for(basis_revision, local_ready, operation="ready_fight")
        if confirmed is None:
            semantic_request = result.get("semantic_request_observed")
            return {
                "status": "BLOCKED",
                "failure_code": "READY_ACK_TIMEOUT" if semantic_request is not False else "READY_REQUEST_NOT_OBSERVED",
                "ready_actor_id": int(actor_id),
                "fight_instance_id": fight_instance_id,
                "semantic_request_observed": semantic_request,
                "retry_allowed": bool(result.get("retry_allowed", False)),
                "detail": (
                    "Ready request was sent but the local fighter acknowledgement was not confirmed"
                    if semantic_request is not False
                    else "Ready mouse transaction produced no outbound READY_REQUEST; semantic Ready was not confirmed"
                ),
            }
        actor = next((item for item in confirmed.fight.actors if int(item.actor_id) == int(actor_id)), None)
        return {
            "status": "CONFIRMED",
            "confirmed_revision": int(confirmed.revision),
            "ready_actor_id": int(actor_id),
            "ready_revision": int(actor.observed.ready_revision) if actor is not None else None,
            "semantic_request_observed": result.get("semantic_request_observed"),
            "retry_allowed": False,
            "detail": "Ready confirmed by local fighter jyk acknowledgement",
        }

    def _move_admission_gate(
        self, snapshot: CanonicalSnapshot, *, actor_id: int, target_cell_id: int, stage: str,
    ) -> tuple[dict | None, dict | None]:
        """Kernel-certify movement against the same shared semantic frame as FightAI."""
        if self.kernel is None:
            return None, None
        semantic_snapshot, frame_evidence, frame_error = self._combat_semantic_snapshot_for_admission(
            snapshot, stage=stage,
        )
        if frame_error is not None or semantic_snapshot is None:
            return None, {
                "status": "BLOCKED",
                "failure_code": FailureCode.MOVE_ADMISSION_UNKNOWN.value,
                "detail": str(frame_error or "COMBAT_FRAME_UNAVAILABLE"),
                "retry_allowed": True,
                "physical_send_state": PhysicalSendState.NOT_SENT.value,
                "admission_stage": str(stage),
                "combat_frame": frame_evidence,
            }
        admission = FightActionAdmissionService(self.kernel).admit_move(
            semantic_snapshot, actor_id=int(actor_id), target_cell_id=int(target_cell_id),
        )
        evidence = admission.as_dict()
        evidence["stage"] = str(stage)
        evidence.update(frame_evidence)
        if admission.admitted:
            return evidence, None
        failure_code = (
            FailureCode.MOVE_ADMISSION_REJECTED.value
            if admission.status is FightActionAdmissionStatus.REJECTED
            else FailureCode.MOVE_ADMISSION_UNKNOWN.value
        )
        return evidence, {
            "status": "BLOCKED",
            "failure_code": failure_code,
            "detail": admission.reason,
            "retry_allowed": admission.status is FightActionAdmissionStatus.UNKNOWN,
            "physical_send_state": PhysicalSendState.NOT_SENT.value,
            "admission_stage": str(stage),
            "admission": evidence,
        }

    def _move_fight(self, payload: dict) -> dict:
        actor_id = int(payload["actor_id"])
        target_cell = int(payload["target_cell_id"])
        before = self.state.snapshot()
        readiness_block = self._guard_readiness(before)
        if readiness_block is not None:
            return readiness_block
        fight = before.fight
        local_id = authoritative_canonical_local_actor_id(before)
        if not fight.present:
            return self._blocked("no fight is present")
        if fight.map_id.status is not ValueStatus.KNOWN:
            return self._blocked("fight map is not confirmed")
        if local_id is None or int(local_id) != actor_id:
            return self._blocked("fight movement is restricted to the authoritative local actor")
        if fight.active_actor_id.status is not ValueStatus.KNOWN or int(fight.active_actor_id.value) != actor_id:
            return self._blocked("it is not the confirmed local actor turn")
        actor = next((item for item in fight.actors if item.actor_id == actor_id), None)
        if actor is None or actor.cell_id.status is not ValueStatus.KNOWN:
            return self._blocked("local actor cell is not confirmed")
        if int(actor.cell_id.value) == target_cell:
            return {"status": "SETTLED", "server_confirmed_revision": before.revision, "settled_revision": before.revision, "detail": "actor already on target cell"}
        if actor.mp.status is not ValueStatus.KNOWN:
            return self._blocked("CURRENT_MP_UNKNOWN: current MP baseline is not evidence-backed")
        map_id = int(fight.map_id.value)
        key = self._attempt_key(before.revision, "move_fight", {"actor_id": actor_id, "target_cell_id": target_cell})
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked
        admission_evidence: dict | None = None
        movement_projection_evidence: dict | None = None
        move_input_evidence: dict = {}

        def with_move_input(result: dict) -> dict:
            row = dict(result)
            if move_input_evidence:
                row["physical_input_evidence"] = dict(move_input_evidence)
            return row

        with self._input_lease():
            if not self.input.ensure_target_focused():
                return self._blocked("target Dofus window is not uniquely focused")
            # Cheap projection preflight avoids performing admission for a cell
            # that cannot currently be mapped, but is never reused for the click.
            _preflight_projection, projection_block = self._resolve_safe_cell(
                map_id, target_cell, purpose="FIGHT_MOVE_PREFLIGHT", label="fight movement preflight",
            )
            if projection_block is not None:
                return projection_block
            latest = self.state.snapshot()
            latest_actor = next((item for item in latest.fight.actors if item.actor_id == actor_id), None) if latest.fight.present else None
            if (
                not latest.fight.present
                or latest.fight.map_id.status is not ValueStatus.KNOWN
                or int(latest.fight.map_id.value) != map_id
                or latest.fight.active_actor_id.status is not ValueStatus.KNOWN
                or int(latest.fight.active_actor_id.value) != actor_id
                or latest_actor is None
            ):
                return self._blocked("fight movement live state changed before physical input")
            admission_evidence, admission_block = self._move_admission_gate(
                latest, actor_id=actor_id, target_cell_id=target_cell, stage="PRE_TARGET",
            )
            if admission_block is not None:
                return admission_block
            projection, projection_block = self._resolve_safe_cell(
                map_id, target_cell, purpose="FIGHT_MOVE_CLICK", label="fight movement target",
            )
            if projection_block is not None:
                return projection_block
            assert projection is not None and projection.point is not None
            movement_projection_evidence = {
                "status": getattr(projection.status, "value", str(projection.status)),
                "map_id": int(projection.map_id),
                "cell_id": int(projection.cell_id),
                "map_revision": int(projection.map_revision),
                "runtime_generation": int(projection.runtime_generation),
                "point": projection.point.model_dump(mode="json") if projection.point is not None else None,
            }
            # Canonical revision churn is not itself a semantic invalidation. In
            # the R5.159 live run actor-effect observations advanced the revision
            # sixteen times while the same move remained legal. Re-admit against
            # the newest semantic frame instead of requiring raw revision equality.
            final_authorization = self.state.snapshot()
            final_actor = (
                next((item for item in final_authorization.fight.actors if item.actor_id == actor_id), None)
                if final_authorization.fight.present else None
            )
            if (
                not final_authorization.fight.present
                or final_authorization.fight.map_id.status is not ValueStatus.KNOWN
                or int(final_authorization.fight.map_id.value) != map_id
                or final_authorization.fight.active_actor_id.status is not ValueStatus.KNOWN
                or int(final_authorization.fight.active_actor_id.value) != actor_id
                or final_actor is None
            ):
                return {
                    "status": "BLOCKED",
                    "failure_code": FailureCode.MOVE_ADMISSION_UNKNOWN.value,
                    "detail": "MOVE_STATE_CHANGED_AFTER_PROJECTION: fight/map/turn identity changed",
                    "retry_allowed": True,
                    "physical_send_state": PhysicalSendState.NOT_SENT.value,
                    "authorized_revision": int(latest.revision),
                    "current_revision": int(final_authorization.revision),
                    "admission": admission_evidence,
                    "target_projection": movement_projection_evidence,
                }
            post_projection_admission, post_projection_block = self._move_admission_gate(
                final_authorization, actor_id=actor_id, target_cell_id=target_cell,
                stage="POST_PROJECTION",
            )
            if post_projection_block is not None:
                post_projection_block = dict(post_projection_block)
                post_projection_block.update({
                    "authorized_revision": int(latest.revision),
                    "current_revision": int(final_authorization.revision),
                    "previous_admission": admission_evidence,
                    "target_projection": movement_projection_evidence,
                })
                return post_projection_block
            if post_projection_admission is not None:
                admission_evidence = post_projection_admission

            pre_down_move_block: dict | None = None
            pre_down_move_admission: dict | None = None

            def move_pre_down_guard(delivery_context=None):
                nonlocal pre_down_move_block, pre_down_move_admission, admission_evidence
                guarded = self.state.snapshot()
                guarded_actor = (
                    next((item for item in guarded.fight.actors if item.actor_id == actor_id), None)
                    if guarded.fight.present else None
                )
                if (
                    not guarded.fight.present
                    or guarded.fight.map_id.status is not ValueStatus.KNOWN
                    or int(guarded.fight.map_id.value) != map_id
                    or guarded.fight.active_actor_id.status is not ValueStatus.KNOWN
                    or int(guarded.fight.active_actor_id.value) != actor_id
                    or guarded_actor is None
                ):
                    pre_down_move_block = {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.MOVE_ADMISSION_UNKNOWN.value,
                        "detail": "MOVE_STATE_CHANGED_BEFORE_MOUSE_DOWN: fight/map/turn identity changed during pointer travel",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "admission_stage": "PRE_DOWN",
                        "current_revision": int(guarded.revision),
                    }
                    return False, pre_down_move_block
                current_projection, current_projection_block = self._resolve_safe_cell(
                    map_id, target_cell, purpose="FIGHT_MOVE_CLICK",
                    label="fight movement pre-down projection",
                )
                if current_projection_block is not None or current_projection is None:
                    pre_down_move_block = dict(current_projection_block or {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.PROJECTION_STALE.value,
                        "detail": "movement projection unavailable immediately before mouse DOWN",
                        "retry_allowed": True,
                    })
                    pre_down_move_block.setdefault("physical_send_state", PhysicalSendState.NOT_SENT.value)
                    return False, pre_down_move_block
                selected_client = None
                if isinstance(delivery_context, dict):
                    raw_selected = delivery_context.get("selected_client_point")
                    if isinstance(raw_selected, (list, tuple)) and len(raw_selected) == 2:
                        try:
                            selected_client = (int(raw_selected[0]), int(raw_selected[1]))
                        except Exception:
                            selected_client = None
                current_nominal = self._projection_reference_client_point(current_projection)
                current_safe = self._projection_reference_safe_client_points(current_projection)
                allowed_points = {
                    (int(item.x), int(item.y))
                    for item in (current_safe or ((current_nominal,) if current_nominal is not None else ()))
                }
                if selected_client is not None and selected_client not in allowed_points:
                    pre_down_move_block = {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.PROJECTION_STALE.value,
                        "detail": "selected movement endpoint is no longer certified by the current projection",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "admission_stage": "PRE_DOWN",
                        "selected_client_point": list(selected_client),
                        "current_certified_client_points": [list(item) for item in sorted(allowed_points)],
                    }
                    return False, pre_down_move_block
                projection_changed = bool(
                    int(current_projection.map_revision) != int(projection.map_revision)
                    or int(current_projection.runtime_generation) != int(projection.runtime_generation)
                    or current_projection.client_point != projection.client_point
                )
                if projection_changed:
                    pre_down_move_block = {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.PROJECTION_STALE.value,
                        "detail": "movement projection changed during smooth pointer travel",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "admission_stage": "PRE_DOWN",
                        "projection_before": movement_projection_evidence,
                        "projection_current": {
                            "map_revision": int(current_projection.map_revision),
                            "runtime_generation": int(current_projection.runtime_generation),
                            "client_point": (
                                current_projection.client_point.model_dump(mode="json")
                                if current_projection.client_point is not None else None
                            ),
                        },
                    }
                    return False, pre_down_move_block
                pre_down_move_admission, block = self._move_admission_gate(
                    guarded, actor_id=actor_id, target_cell_id=target_cell, stage="PRE_DOWN",
                )
                if block is not None:
                    pre_down_move_block = dict(block)
                    return False, pre_down_move_block
                if pre_down_move_admission is not None:
                    admission_evidence = pre_down_move_admission
                return True, {
                    "admission_stage": "PRE_DOWN",
                    "canonical_revision": int(guarded.revision),
                    "semantic_admission": pre_down_move_admission,
                }

            move_semantic_after_ms = int(self.monotonic_clock() * 1000)
            move_client_instance_id = None
            if hasattr(self.input, "client_instance_id"):
                try:
                    move_client_instance_id = self.input.client_instance_id()
                except Exception:
                    move_client_instance_id = None
            sent = self._send_projection(projection, pre_down_guard=move_pre_down_guard)
            move_input_evidence = self._input_debug_snapshot()
            if sent is PhysicalSendState.NOT_SENT and pre_down_move_block is not None:
                result = dict(pre_down_move_block)
                result.setdefault("target_projection", movement_projection_evidence)
                result.setdefault("admission", admission_evidence)
                return with_move_input(result)
        if sent is PhysicalSendState.NOT_SENT:
            return with_move_input(self._blocked("fight movement input was not sent"))
        self._mark_sent(key)
        if sent is PhysicalSendState.UNCERTAIN:
            return with_move_input(self._reconciling(
                "fight movement physical delivery is uncertain; input quarantined pending authoritative reconciliation",
                uncertainty_context={
                    "kind": "COMBAT_MOVE",
                    "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                    "basis_revision": int(before.revision),
                    "fight_instance_id": fight.fight_instance_id,
                    "actor_id": int(actor_id),
                    "origin_cell_id": int(actor.cell_id.value),
                    "target_cell_id": int(target_cell),
                    "basis_mp_value": int(actor.mp.value),
                    "basis_mp_revision": int(actor.observed.mp_revision),
                    "sent_after_monotonic_ms": int(move_semantic_after_ms),
                    "client_instance_id": move_client_instance_id,
                    "negative_move_absence_samples": 0,
                },
                failure_code=FailureCode.COMBAT_MOVE_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.UNCERTAIN.value,
                semantic_move_send_state="UNCERTAIN",
                retry_allowed=True,
                safe_replan=False,
                reconciliation_required=True,
                input_quarantined=True,
                first_missing_boundary="COMBAT_MOVE_PHYSICAL_OR_SEMANTIC_CAUSALITY",
                likely_owner="EXECUTION_SERVICE",
            ))

        confirmed_revision: int | None = None
        pending: PendingSettlement | None = None
        move_semantic_proof: dict | None = None
        confirmation_remaining = self._confirmation_poll_budget("move_fight")
        settlement_remaining = self._settlement_poll_budget("move_fight")
        while confirmation_remaining > 0 or (pending is not None and settlement_remaining > 0):
            current = self.state.snapshot()
            if current.revision > before.revision and current.fight.present:
                current_actor = next((item for item in current.fight.actors if item.actor_id == actor_id), None)
                if current_actor is not None:
                    if (
                        confirmed_revision is None
                        and current_actor.cell_id.status is ValueStatus.KNOWN
                        and int(current_actor.cell_id.value) == target_cell
                        and current_actor.observed.cell_revision > before.revision
                    ):
                        confirmed_revision = current_actor.observed.cell_revision
                        confirmation_remaining = 0
                        move_semantic_proof = self._record_session_move_semantic_proof(
                            after_monotonic_ms=int(move_semantic_after_ms),
                            client_instance_id=move_client_instance_id,
                            target_cell_id=int(target_cell),
                        )
                        pending = PendingSettlement(
                            action_kind="move_fight",
                            basis_revision=before.revision,
                            server_confirmed_revision=confirmed_revision,
                            requirements=(
                                SettlementRequirement(actor_id, "cell", before.revision),
                                SettlementRequirement(
                                    actor_id, "mp", confirmed_revision,
                                    mode="RESOURCE_DECREASE",
                                    baseline_value=int(actor.mp.value),
                                ),
                            ),
                        )
                    if pending is not None and not missing_requirements(current, pending):
                        self._pending_settlement = None
                        if self._safety is not None:
                            self._safety.set_pending(None)
                        return with_move_input({
                            "status": "SETTLED",
                            "server_confirmed_revision": pending.server_confirmed_revision,
                            "settled_revision": current.revision,
                            "detail": "fight movement confirmed and live cell/MP refreshed",
                            "admission": admission_evidence,
                            "target_projection": movement_projection_evidence,
                            "semantic_move_send_state": "OBSERVED" if (move_semantic_proof or {}).get("recorded") else "UNKNOWN",
                            "semantic_move_evidence": move_semantic_proof,
                        })
            if pending is None:
                confirmation_remaining -= 1
            else:
                settlement_remaining -= 1
            self.sleep(self.confirmation_interval_seconds)

        if pending is not None:
            self._pending_settlement = pending
            if self._safety is not None:
                self._safety.set_pending(pending)
            current = self.state.snapshot()
            return with_move_input({
                "status": "CONFIRMED_UNSETTLED",
                "server_confirmed_revision": pending.server_confirmed_revision,
                "current_revision": current.revision,
                "missing_requirements": list(missing_requirements(current, pending)),
                "detail": "movement was confirmed but decision-critical live state has not settled",
                "admission": admission_evidence,
                "target_projection": movement_projection_evidence,
                "semantic_move_send_state": "OBSERVED" if (move_semantic_proof or {}).get("recorded") else "UNKNOWN",
                "semantic_move_evidence": move_semantic_proof,
            })
        move_request_available, move_request = self._move_request_evidence_since(
            after_monotonic_ms=int(move_semantic_after_ms),
            client_instance_id=move_client_instance_id,
            target_cell_id=int(target_cell),
        )
        return with_move_input(self._reconciling(
            "fight movement input was sent but target cell was not server-confirmed",
            uncertainty_context={
                "kind": "COMBAT_MOVE",
                "basis_revision": int(before.revision),
                "fight_instance_id": fight.fight_instance_id,
                "actor_id": int(actor_id),
                "origin_cell_id": int(actor.cell_id.value),
                "target_cell_id": int(target_cell),
                "basis_mp_value": int(actor.mp.value),
                "basis_mp_revision": int(actor.observed.mp_revision),
                "basis_active_actor_id": (
                    int(fight.active_actor_id.value)
                    if fight.active_actor_id.status is ValueStatus.KNOWN and fight.active_actor_id.value is not None
                    else None
                ),
                "sent_after_monotonic_ms": int(move_semantic_after_ms),
                "client_instance_id": move_client_instance_id,
                "negative_move_absence_samples": 0,
            },
            failure_code="COMBAT_MOVE_CAUSALITY_PENDING",
            physical_send_state=PhysicalSendState.SENT.value,
            semantic_move_send_state=("OBSERVED" if move_request_available and move_request is not None else "UNKNOWN"),
            semantic_move_evidence=(dict(move_request) if isinstance(move_request, dict) else None),
            retry_allowed=True,
            safe_replan=False,
            reconciliation_required=True,
            first_missing_boundary="COMBAT_MOVE_SETTLEMENT",
            likely_owner="EXECUTION_SERVICE",
            admission=admission_evidence,
            target_projection=movement_projection_evidence,
        ))

    def _combat_semantic_snapshot_for_admission(
        self, snapshot: CanonicalSnapshot, *, stage: str,
    ) -> tuple[CanonicalSnapshot | None, dict[str, object], str | None]:
        """Return the shared semantic snapshot iff it matches the caller lane revision."""
        if self._combat_frame_provider is None:
            return snapshot, {}, None
        try:
            frame = self._combat_frame_provider(self.account_id)
            frame_owner_revision = int(getattr(frame, "owner_revision"))
            evidence = (
                dict(frame.diagnostics())
                if callable(getattr(frame, "diagnostics", None)) else {}
            )
            evidence["admission_frame_stage"] = str(stage)
            if frame_owner_revision != int(snapshot.revision):
                return None, evidence, (
                    "COMBAT_FRAME_ADVANCED_DURING_ADMISSION: local Canonical revision "
                    f"{int(snapshot.revision)} != frame owner revision {frame_owner_revision}"
                )
            return getattr(frame, "owner_snapshot"), evidence, None
        except Exception as exc:
            return None, {}, f"COMBAT_FRAME_UNAVAILABLE:{type(exc).__name__}:{exc}"

    def _cast_admission_gate(
        self,
        snapshot: CanonicalSnapshot,
        payload: dict,
        *,
        actor_id: int,
        spell_id: int,
        target_cell_id: int,
        stage: str,
        slot_already_selected: bool = False,
    ) -> tuple[dict | None, dict | None]:
        """Revalidate one CAST against the latest evidence immediately before semantics.

        Slot selection is a physical UI input but does not itself emit the Dofus cast
        request. R5.135 therefore runs this gate both before slot selection and again
        before the target click, closing the planning/admission and slot/target TOCTOU
        windows without pretending the first UI click was a server-side cast.
        """
        if self.kernel is None:
            return None, None
        grade_raw = payload.get("grade")
        if grade_raw is None:
            if payload.get("_correlated_runtime"):
                return None, {
                    "status": "BLOCKED",
                    "failure_code": FailureCode.CAST_ADMISSION_UNKNOWN.value,
                    "detail": "CAST_GRADE_REQUIRED: pre-input Kernel admission requires the selected spell grade",
                    "retry_allowed": True,
                    "physical_send_state": (
                        PhysicalSendState.SENT.value if slot_already_selected
                        else PhysicalSendState.NOT_SENT.value
                    ),
                    "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                    "admission_stage": str(stage),
                }
            # Backward compatibility for uncorrelated legacy/unit callers. Production
            # combat actions are correlated and cannot pass this branch.
            return None, None

        semantic_snapshot, combat_frame_evidence, frame_error = self._combat_semantic_snapshot_for_admission(
            snapshot, stage=stage,
        )
        if frame_error is not None or semantic_snapshot is None:
            return None, {
                "status": "BLOCKED",
                "failure_code": FailureCode.CAST_ADMISSION_UNKNOWN.value,
                "detail": str(frame_error or "COMBAT_FRAME_UNAVAILABLE"),
                "retry_allowed": True,
                "physical_send_state": (
                    PhysicalSendState.SENT.value if slot_already_selected
                    else PhysicalSendState.NOT_SENT.value
                ),
                "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                "admission_stage": str(stage),
                "combat_frame": combat_frame_evidence,
            }

        action_intent_payload = payload.get("action_intent")
        action_intent = None
        if action_intent_payload is not None:
            try:
                action_intent = ActionIntent.from_payload(action_intent_payload)
            except (TypeError, ValueError) as exc:
                return None, {
                    "status": "BLOCKED",
                    "failure_code": FailureCode.INVALID_COMBAT_ACTION_CONTRACT.value,
                    "detail": f"ACTION_INTENT_MALFORMED: {exc}",
                    "retry_allowed": False,
                    "safe_replan": True,
                    "quarantine_candidate": True,
                    "physical_send_state": (
                        PhysicalSendState.SENT.value if slot_already_selected
                        else PhysicalSendState.NOT_SENT.value
                    ),
                    "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                    "admission_stage": str(stage),
                    "combat_frame": combat_frame_evidence,
                }
        admission = FightActionAdmissionService(self.kernel).admit_cast(
            semantic_snapshot,
            actor_id=int(actor_id),
            spell_id=int(spell_id),
            grade=int(grade_raw),
            target_cell_id=int(target_cell_id),
            target_actor_id=(
                int(payload["target_actor_id"])
                if payload.get("target_actor_id") is not None else None
            ),
            action_intent=action_intent,
            admission_mode=str(payload.get("admission_mode") or "STRICT"),
            probe_assumptions=tuple(payload.get("probe_assumptions") or ()),
        )
        evidence = admission.as_dict()
        evidence["stage"] = str(stage)
        evidence.update(combat_frame_evidence)
        if admission.admitted:
            return evidence, None
        interaction = admission.client_interaction if isinstance(admission.client_interaction, dict) else {}
        if (
            admission.status is FightActionAdmissionStatus.REJECTED
            and interaction.get("surface") == "EMPTY_NON_WALKABLE"
        ):
            failure_code = FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value
        else:
            failure_code = (
                FailureCode.CAST_ADMISSION_REJECTED.value
                if admission.status is FightActionAdmissionStatus.REJECTED
                else FailureCode.CAST_ADMISSION_UNKNOWN.value
            )
        safe_client_rejection = failure_code == FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value
        return evidence, {
            "status": "BLOCKED",
            "failure_code": failure_code,
            "detail": admission.reason,
            "retry_allowed": admission.status is FightActionAdmissionStatus.UNKNOWN,
            "safe_replan": bool(safe_client_rejection),
            "quarantine_candidate": bool(safe_client_rejection),
            "physical_send_state": (
                PhysicalSendState.SENT.value if slot_already_selected
                else PhysicalSendState.NOT_SENT.value
            ),
            "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
            "admission_stage": str(stage),
            "admission": evidence,
        }

    def _cast_spell(self, payload: dict) -> dict:
        spell_id = int(payload["spell_id"])
        target_cell = int(payload["target_cell_id"])
        slot_index = int(payload["slot_index"])
        physical_input_phases: list[dict] = []

        def phase(
            name: str,
            send_state: PhysicalSendState,
            *,
            input_evidence: dict | None = None,
            **extra,
        ) -> dict:
            item = {
                "phase": str(name),
                "physical_send_state": getattr(send_state, "value", str(send_state)),
                **extra,
            }
            # Only pointer-bearing CAST phases own pointer-motion evidence. ESC
            # neutralization can leave the driver's previous mouse fields intact;
            # attaching them here would double-count a stale trajectory.  Callers
            # may pass a snapshot captured immediately at the send boundary so a
            # later ESC cannot overwrite a PRE_DOWN-aborted target trajectory.
            if str(name) in {"SPELL_SLOT_CLICK", "SPELL_TARGET_CLICK"}:
                item["input_evidence"] = dict(
                    input_evidence if input_evidence is not None else self._input_debug_snapshot()
                )
            physical_input_phases.append(item)
            return item

        def projection_payload(projection: ProjectionResult) -> dict:
            return {
                "status": getattr(projection.status, "value", str(projection.status)),
                "map_id": int(projection.map_id),
                "cell_id": int(projection.cell_id),
                "map_revision": int(projection.map_revision),
                "runtime_generation": int(projection.runtime_generation),
                "target_entity_id": projection.target_entity_id,
                "entity_anchor_verified": bool(projection.entity_anchor_verified),
                "entity_anchor_cell_id": projection.entity_anchor_cell_id,
                "entity_nearest_cell_id": projection.entity_nearest_cell_id,
                "exact_cell_anchor_verified": bool(projection.exact_cell_anchor_verified),
                "exact_cell_anchor_hierarchy": projection.exact_cell_anchor_hierarchy,
                "exact_cell_anchor_planar_error": projection.exact_cell_anchor_planar_error,
                "statically_walkable": projection.statically_walkable,
                "projectable": projection.projectable,
                "verified_by_dofus_picker": projection.verified_by_dofus_picker,
                "verified_by_runtime_grid": projection.verified_by_runtime_grid,
                "coordinate_space": projection.coordinate_space,
                "point": projection.point.model_dump(mode="json") if projection.point is not None else None,
                "client_point": projection.client_point.model_dump(mode="json") if projection.client_point is not None else None,
                "target_hierarchy": projection.target_hierarchy,
                "confidence": projection.confidence,
                "diagnostics": projection.diagnostics,
                "detail": projection.detail,
            }

        def with_phases(result: dict, **extra) -> dict:
            result = dict(result)
            result["physical_input_phases"] = [dict(item) for item in physical_input_phases]
            result.update(extra)
            return result

        def abort_after_slot(result: dict, *, reason: str, safe_replan: bool, quarantine_candidate: bool = False) -> dict:
            neutralization, neutralization_failure = self._neutralize_selected_spell(reason=reason)
            phase(
                "UI_NEUTRALIZE",
                PhysicalSendState(str(neutralization.get("physical_send_state") or PhysicalSendState.NOT_SENT.value)),
                reason=str(reason), neutralized=bool(neutralization.get("neutralized")),
                detail=neutralization.get("detail"),
            )
            if neutralization_failure is not None:
                return with_phases(
                    neutralization_failure,
                    ui_neutralization=neutralization,
                    original_cast_abort=dict(result),
                )
            result = dict(result)
            result["ui_neutralization"] = neutralization
            result["safe_replan"] = bool(safe_replan)
            result["quarantine_candidate"] = bool(quarantine_candidate)
            # abort_after_slot is reachable only after the spell-slot click was
            # positively SENT.  Override any pre-input template value carried by
            # the underlying blocker so transaction causality cannot claim that
            # no physical input occurred.  The target click itself was not sent.
            result["physical_send_state"] = PhysicalSendState.SENT.value
            result["semantic_cast_send_state"] = PhysicalSendState.NOT_SENT.value
            return with_phases(result)

        before = self.state.snapshot()
        readiness_block = self._guard_readiness(before)
        if readiness_block is not None:
            return readiness_block
        fight = before.fight
        local_id = authoritative_canonical_local_actor_id(before)
        if not fight.present:
            return self._blocked("no fight is present")
        if fight.map_id.status is not ValueStatus.KNOWN:
            return self._blocked("fight map is not confirmed")
        if local_id is None:
            return self._blocked("authoritative local fight actor is not confirmed")
        if fight.active_actor_id.status is not ValueStatus.KNOWN or int(fight.active_actor_id.value) != local_id:
            return self._blocked("it is not the confirmed local actor turn")
        local_actor = next((item for item in fight.actors if item.actor_id == local_id), None)
        if local_actor is None or local_actor.ap.status is not ValueStatus.KNOWN:
            return self._blocked("CURRENT_AP_UNKNOWN: current AP baseline is not evidence-backed")
        slot = self._client_point("spell_slots", slot_index)
        if slot is None:
            return self._blocked(f"spell slot {slot_index} calibration is not verified")
        map_id = int(fight.map_id.value)
        key = self._attempt_key(before.revision, "cast_spell", {
            "spell_id": spell_id, "target_cell_id": target_cell, "slot_index": slot_index,
        })
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked

        admission_evidence: dict | None = None
        projection_evidence: dict | None = None
        cast_confirmation_basis_revision = int(before.revision)
        cast_semantic_after_ms = 0
        cast_client_instance_id = None

        with self._input_lease():
            if not self.input.ensure_target_focused():
                return self._blocked("target Dofus window is not uniquely focused")

            # Preflight target projection before entering spell-targeting mode.
            _preflight_projection, projection_block = self._resolve_safe_cell(
                map_id, target_cell, purpose="SPELL_TARGET_PREFLIGHT", label="spell target preflight",
            )
            if projection_block is not None:
                return projection_block

            latest = self.state.snapshot()
            latest_local_id = authoritative_canonical_local_actor_id(latest)
            if (
                not latest.fight.present
                or latest.fight.map_id.status is not ValueStatus.KNOWN
                or int(latest.fight.map_id.value) != map_id
                or latest_local_id is None
                or int(latest_local_id) != local_id
                or latest.fight.active_actor_id.status is not ValueStatus.KNOWN
                or int(latest.fight.active_actor_id.value) != local_id
            ):
                return self._blocked("spell-cast live state changed before physical input")

            interaction_projection_block = self._empty_non_walkable_spell_target_block(
                latest, _preflight_projection, label="spell target preflight",
            )
            if interaction_projection_block is not None:
                return interaction_projection_block

            admission_evidence, admission_block = self._cast_admission_gate(
                latest, payload, actor_id=local_id, spell_id=spell_id,
                target_cell_id=target_cell, stage="PRE_SLOT",
            )
            if admission_block is not None:
                return admission_block
            cast_confirmation_basis_revision = int(
                admission_evidence.get("basis_revision", before.revision)
                if admission_evidence is not None else before.revision
            )

            point, width, height = slot
            cast_physical_after_ms = int(self.monotonic_clock() * 1000)
            if hasattr(self.input, "client_instance_id"):
                try:
                    cast_client_instance_id = self.input.client_instance_id()
                except Exception:
                    cast_client_instance_id = None
            slot_send = self._guarded_physical_send(
                purpose="SPELL_SLOT_CLICK",
                context={"spell_id": int(spell_id), "slot_index": int(slot_index), "target_cell_id": int(target_cell)},
                sender=lambda: self.input.click_client(point, expected_width=width, expected_height=height),
            )
            phase("SPELL_SLOT_CLICK", slot_send, spell_id=spell_id, slot_index=slot_index)
            if slot_send is PhysicalSendState.NOT_SENT:
                return with_phases(self._blocked("spell-slot input was not sent"))
            self._mark_sent(key)
            if slot_send is PhysicalSendState.UNCERTAIN:
                return with_phases(self._reconciling(
                    "spell-slot physical delivery is uncertain; input quarantined until cast/turn causality closes",
                    uncertainty_context={
                        "kind": "COMBAT_CAST",
                        "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                        "cast_phase": "SPELL_SLOT_CLICK",
                        "basis_revision": int(before.revision),
                        "fight_instance_id": fight.fight_instance_id,
                        "actor_id": int(local_id),
                        "spell_id": int(spell_id),
                        "target_cell_id": int(target_cell),
                        "sent_after_monotonic_ms": int(cast_physical_after_ms),
                        "client_instance_id": cast_client_instance_id,
                    },
                    failure_code=FailureCode.COMBAT_CAST_CAUSALITY_PENDING.value,
                    physical_send_state=PhysicalSendState.UNCERTAIN.value,
                    semantic_cast_send_state="UNCERTAIN",
                    retry_allowed=True, safe_replan=False, reconciliation_required=True,
                    input_quarantined=True,
                    first_missing_boundary="COMBAT_CAST_SLOT_PHYSICAL_CAUSALITY",
                    likely_owner="EXECUTION_SERVICE",
                ))

            # After slot selection, every abort must neutralize targeting before replanning.
            target_authorization = self.state.snapshot()
            target_local_id = authoritative_canonical_local_actor_id(target_authorization)
            if (
                not target_authorization.fight.present
                or target_authorization.fight.map_id.status is not ValueStatus.KNOWN
                or int(target_authorization.fight.map_id.value) != map_id
                or target_local_id is None
                or int(target_local_id) != local_id
                or target_authorization.fight.active_actor_id.status is not ValueStatus.KNOWN
                or int(target_authorization.fight.active_actor_id.value) != local_id
            ):
                return abort_after_slot({
                    "status": "BLOCKED",
                    "failure_code": "FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET",
                    "detail": "fight/turn ownership changed after spell selection and before target click",
                    "retry_allowed": True,
                }, reason="FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET", safe_replan=True)

            second_admission, second_block = self._cast_admission_gate(
                target_authorization, payload, actor_id=local_id, spell_id=spell_id,
                target_cell_id=target_cell, stage="PRE_TARGET", slot_already_selected=True,
            )
            if second_block is not None:
                return abort_after_slot(
                    second_block,
                    reason=str(second_block.get("failure_code") or "PRE_TARGET_ADMISSION_BLOCKED"),
                    safe_replan=True,
                    quarantine_candidate=True,
                )
            if second_admission is not None:
                admission_evidence = second_admission
                cast_confirmation_basis_revision = int(
                    second_admission.get("basis_revision", cast_confirmation_basis_revision)
                )

            # R5.139: PRE_TARGET authorizes semantics first; only then acquire the
            # exact target projection that will be physically clicked. The former
            # implementation reused a projection resolved before PRE_SLOT, leaving
            # a projection-generation TOCTOU gap.
            projection, projection_block = self._resolve_safe_cell(
                map_id, target_cell, purpose="SPELL_TARGET_CLICK", label="spell target",
                require_spell_anchor=bool(payload.get("_correlated_runtime")),
            )
            if projection_block is not None:
                return abort_after_slot(
                    projection_block,
                    reason="POST_ADMISSION_TARGET_PROJECTION_BLOCKED",
                    safe_replan=True,
                )
            assert projection is not None and projection.point is not None
            projection_evidence = projection_payload(projection)

            # Projection acquisition may race Canonical updates. Revision churn
            # alone is not a semantic failure; re-admit on the newest state.
            final_authorization = self.state.snapshot()
            final_local_id = authoritative_canonical_local_actor_id(final_authorization)
            if (
                not final_authorization.fight.present
                or final_authorization.fight.map_id.status is not ValueStatus.KNOWN
                or int(final_authorization.fight.map_id.value) != map_id
                or final_local_id is None
                or int(final_local_id) != local_id
                or final_authorization.fight.active_actor_id.status is not ValueStatus.KNOWN
                or int(final_authorization.fight.active_actor_id.value) != local_id
            ):
                return abort_after_slot({
                    "status": "BLOCKED",
                    "failure_code": "FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET",
                    "detail": "fight/map/turn identity changed while resolving the target projection",
                    "retry_allowed": True,
                    "authorized_revision": int(target_authorization.revision),
                    "current_revision": int(final_authorization.revision),
                }, reason="FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET", safe_replan=True)

            post_projection_admission, post_projection_block = self._cast_admission_gate(
                final_authorization, payload, actor_id=local_id, spell_id=spell_id,
                target_cell_id=target_cell, stage="POST_PROJECTION", slot_already_selected=True,
            )
            if post_projection_block is not None:
                return abort_after_slot(
                    post_projection_block,
                    reason=str(post_projection_block.get("failure_code") or "POST_PROJECTION_ADMISSION_BLOCKED"),
                    safe_replan=True, quarantine_candidate=True,
                )
            if post_projection_admission is not None:
                admission_evidence = post_projection_admission
                cast_confirmation_basis_revision = int(
                    post_projection_admission.get("basis_revision", cast_confirmation_basis_revision)
                )

            final_interaction_block = self._empty_non_walkable_spell_target_block(
                final_authorization, projection, label="spell target final authorization",
            )
            if final_interaction_block is not None:
                return abort_after_slot(
                    final_interaction_block,
                    reason=FailureCode.SPELL_TARGET_EMPTY_NON_WALKABLE.value,
                    safe_replan=True,
                    quarantine_candidate=True,
                )

            pre_down_cast_block: dict | None = None
            pre_down_cast_admission: dict | None = None

            def cast_pre_down_guard(delivery_context=None):
                nonlocal pre_down_cast_block, pre_down_cast_admission, admission_evidence, cast_confirmation_basis_revision
                guarded = self.state.snapshot()
                guarded_local_id = authoritative_canonical_local_actor_id(guarded)
                if (
                    not guarded.fight.present
                    or guarded.fight.map_id.status is not ValueStatus.KNOWN
                    or int(guarded.fight.map_id.value) != map_id
                    or guarded_local_id is None
                    or int(guarded_local_id) != local_id
                    or guarded.fight.active_actor_id.status is not ValueStatus.KNOWN
                    or int(guarded.fight.active_actor_id.value) != local_id
                ):
                    pre_down_cast_block = {
                        "status": "BLOCKED",
                        "failure_code": "FIGHT_STATE_CHANGED_BEFORE_CAST_TARGET",
                        "detail": "fight/map/turn identity changed during smooth target-pointer travel",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                        "admission_stage": "PRE_DOWN",
                        "current_revision": int(guarded.revision),
                    }
                    return False, pre_down_cast_block
                current_projection, current_projection_block = self._resolve_safe_cell(
                    map_id, target_cell, purpose="SPELL_TARGET_CLICK",
                    label="spell target pre-down projection",
                    require_spell_anchor=bool(payload.get("_correlated_runtime")),
                )
                if current_projection_block is not None or current_projection is None:
                    pre_down_cast_block = dict(current_projection_block or {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.PROJECTION_STALE.value,
                        "detail": "spell target projection unavailable immediately before mouse DOWN",
                        "retry_allowed": True,
                    })
                    pre_down_cast_block.setdefault("physical_send_state", PhysicalSendState.NOT_SENT.value)
                    pre_down_cast_block.setdefault("semantic_cast_send_state", PhysicalSendState.NOT_SENT.value)
                    return False, pre_down_cast_block
                projection_changed = bool(
                    int(current_projection.map_revision) != int(projection.map_revision)
                    or int(current_projection.runtime_generation) != int(projection.runtime_generation)
                    or current_projection.client_point != projection.client_point
                )
                if projection_changed:
                    pre_down_cast_block = {
                        "status": "BLOCKED",
                        "failure_code": FailureCode.PROJECTION_STALE.value,
                        "detail": "spell target projection changed during smooth pointer travel",
                        "retry_allowed": True,
                        "physical_send_state": PhysicalSendState.NOT_SENT.value,
                        "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                        "admission_stage": "PRE_DOWN",
                    }
                    return False, pre_down_cast_block
                interaction_block = self._empty_non_walkable_spell_target_block(
                    guarded, current_projection, label="spell target pre-down authorization",
                )
                if interaction_block is not None:
                    pre_down_cast_block = dict(interaction_block)
                    pre_down_cast_block.setdefault("physical_send_state", PhysicalSendState.NOT_SENT.value)
                    pre_down_cast_block.setdefault("semantic_cast_send_state", PhysicalSendState.NOT_SENT.value)
                    return False, pre_down_cast_block
                pre_down_cast_admission, block = self._cast_admission_gate(
                    guarded, payload, actor_id=local_id, spell_id=spell_id,
                    target_cell_id=target_cell, stage="PRE_DOWN", slot_already_selected=True,
                )
                if block is not None:
                    pre_down_cast_block = dict(block)
                    return False, pre_down_cast_block
                if pre_down_cast_admission is not None:
                    admission_evidence = pre_down_cast_admission
                    cast_confirmation_basis_revision = int(
                        pre_down_cast_admission.get("basis_revision", cast_confirmation_basis_revision)
                    )
                return True, {
                    "admission_stage": "PRE_DOWN",
                    "canonical_revision": int(guarded.revision),
                    "semantic_admission": pre_down_cast_admission,
                }

            cast_semantic_after_ms = int(self.monotonic_clock() * 1000)
            if hasattr(self.input, "client_instance_id"):
                try:
                    cast_client_instance_id = self.input.client_instance_id()
                except Exception:
                    cast_client_instance_id = None
            target_send = self._send_projection(projection, pre_down_guard=cast_pre_down_guard)
            # Snapshot the target-pointer evidence *before* any abort neutralizes
            # targeting mode.  PRE_DOWN can legitimately return NOT_SENT after a
            # full smooth pointer travel, and that trajectory is critical forensic
            # evidence even though mouse DOWN never occurred.
            target_input_evidence = self._input_debug_snapshot()
            phase(
                "SPELL_TARGET_CLICK", target_send, input_evidence=target_input_evidence,
                spell_id=spell_id, target_cell_id=target_cell, projection=projection_evidence,
            )
            if target_send is PhysicalSendState.NOT_SENT and pre_down_cast_block is not None:
                return abort_after_slot(
                    pre_down_cast_block,
                    reason=str(pre_down_cast_block.get("failure_code") or "PRE_DOWN_CAST_BLOCKED"),
                    safe_replan=True, quarantine_candidate=True,
                )
            if target_send is not PhysicalSendState.SENT:
                physical_state = (
                    PhysicalSendState.UNCERTAIN.value
                    if target_send is PhysicalSendState.UNCERTAIN
                    else "PARTIAL_SLOT_SENT_TARGET_NOT_SENT"
                )
                return with_phases(self._reconciling(
                    "spell slot was sent but target delivery is not causally closed; input quarantined",
                    uncertainty_context={
                        "kind": "COMBAT_CAST",
                        "physical_send_state": physical_state,
                        "cast_phase": "SPELL_TARGET_CLICK",
                        "basis_revision": int(cast_confirmation_basis_revision),
                        "fight_instance_id": fight.fight_instance_id,
                        "actor_id": int(local_id),
                        "spell_id": int(spell_id),
                        "target_cell_id": int(target_cell),
                        "sent_after_monotonic_ms": int(cast_semantic_after_ms),
                        "client_instance_id": cast_client_instance_id,
                    },
                    failure_code=FailureCode.COMBAT_CAST_CAUSALITY_PENDING.value,
                    physical_send_state=physical_state,
                    semantic_cast_send_state="UNCERTAIN",
                    retry_allowed=True, safe_replan=False, reconciliation_required=True,
                    input_quarantined=True,
                    first_missing_boundary="COMBAT_CAST_TARGET_PHYSICAL_OR_SEMANTIC_CAUSALITY",
                    likely_owner="EXECUTION_SERVICE",
                    admission=admission_evidence, target_projection=projection_evidence,
                ))

        confirmed_snapshot: CanonicalSnapshot | None = None
        pending: PendingSettlement | None = None
        confirmation_remaining = self._confirmation_poll_budget("cast_spell")
        settlement_remaining = self._settlement_poll_budget("cast_spell")
        while confirmation_remaining > 0 or (pending is not None and settlement_remaining > 0):
            current = self.state.snapshot()
            if current.revision > before.revision:
                if confirmed_snapshot is None and current.fight.present:
                    persistent_casts = getattr(current.fight, "confirmed_casts_this_fight", ())
                    cast_history = persistent_casts if persistent_casts else current.fight.confirmed_casts_this_turn
                    for cast in cast_history:
                        if cast.observed_revision <= cast_confirmation_basis_revision:
                            continue
                        if cast.caster_actor_id != local_id or cast.spell_id != spell_id:
                            continue
                        if cast.target_cell_id.status is ValueStatus.KNOWN and int(cast.target_cell_id.value) == target_cell:
                            confirmed_snapshot = current
                            confirmation_remaining = 0
                            pending = PendingSettlement(
                                action_kind="cast_spell",
                                basis_revision=cast_confirmation_basis_revision,
                                server_confirmed_revision=cast.observed_revision,
                                requirements=(
                                    SettlementRequirement(
                                        local_id, "ap", int(cast.observed_revision),
                                        mode="RESOURCE_DECREASE",
                                        baseline_value=int(local_actor.ap.value),
                                    ),
                                ),
                            )
                            self._record_session_cast_semantic_proof(
                                spell_id=spell_id, target_cell_id=target_cell,
                                after_monotonic_ms=int(cast_semantic_after_ms),
                                client_instance_id=cast_client_instance_id,
                            )
                            break
                if pending is not None and not missing_requirements(current, pending):
                    self._pending_settlement = None
                    if self._safety is not None:
                        self._safety.set_pending(None)
                    return with_phases({
                        "status": "SETTLED",
                        "server_confirmed_revision": pending.server_confirmed_revision,
                        "settled_revision": current.revision,
                        "detail": "spell cast confirmed and live AP refreshed",
                        "note": "damage/effects may be separate live observations and are not inferred from AP settlement",
                        "admission": admission_evidence,
                        "target_projection": projection_evidence,
                        "semantic_cast_send_state": PhysicalSendState.SENT.value,
                    })
            if pending is None:
                confirmation_remaining -= 1
            else:
                settlement_remaining -= 1
            self.sleep(self.confirmation_interval_seconds)

        if pending is not None:
            self._pending_settlement = pending
            if self._safety is not None:
                self._safety.set_pending(pending)
            current = self.state.snapshot()
            return with_phases({
                "status": "CONFIRMED_UNSETTLED",
                "server_confirmed_revision": pending.server_confirmed_revision,
                "current_revision": current.revision,
                "missing_requirements": list(missing_requirements(current, pending)),
                "detail": "spell was server-confirmed but decision-critical live state has not settled",
                "admission": admission_evidence,
                "target_projection": projection_evidence,
                "semantic_cast_send_state": PhysicalSendState.SENT.value,
            })

        # Absence of one known wire name is stronger than positive protocol
        # evidence. It may classify CLIENT_CAST_REJECTED only when the exact
        # observed client build is certified for that negative semantic contract.
        negative_certification = self._cast_negative_semantic_certification(
            spell_id=spell_id, client_instance_id=cast_client_instance_id,
        )
        causality_samples: list[dict] = []
        negative_evidence_confirmed = False
        cast_request = None
        request_query_available = False
        activity_query_available = False
        later_outbound = None
        coverage_ok = False
        coverage: dict = {}
        for sample_index in range(4):
            request_query_available, cast_request = self._protocol_semantic_evidence_since(
                semantic=ProtocolWireSemantic.CAST_REQUEST,
                after_monotonic_ms=int(cast_semantic_after_ms),
                client_instance_id=cast_client_instance_id,
            )
            activity_query_available, later_outbound = self._protocol_activity_since(
                after_monotonic_ms=int(cast_semantic_after_ms),
                client_instance_id=cast_client_instance_id, direction="client_to_server",
            )
            later_outbound_ms = (
                int(later_outbound.get("monotonic_ms"))
                if isinstance(later_outbound, dict) and later_outbound.get("monotonic_ms") is not None
                else None
            )
            required_through_ms = later_outbound_ms if later_outbound_ms is not None else int(cast_semantic_after_ms)
            coverage_ok, coverage = self._capture_coverage(
                client_instance_id=cast_client_instance_id,
                required_through_monotonic_ms=required_through_ms,
                require_exact_client_instance=True,
            )
            sample = {
                "sample_index": int(sample_index + 1),
                "required_through_monotonic_ms": required_through_ms,
                "request_query_available": bool(request_query_available),
                "request_observed": cast_request is not None if request_query_available else None,
                "request_evidence": dict(cast_request) if isinstance(cast_request, dict) else None,
                "outbound_activity_query_available": bool(activity_query_available),
                "later_outbound_activity": dict(later_outbound) if isinstance(later_outbound, dict) else None,
                "capture_coverage": coverage,
                "negative_semantic_contract": dict(negative_certification),
            }
            causality_samples.append(sample)
            sample_is_proven_absent = bool(
                negative_certification.get("certified")
                and request_query_available
                and cast_request is None
                and activity_query_available
                and later_outbound is not None
                and coverage_ok
            )
            if not sample_is_proven_absent:
                if request_query_available and cast_request is not None:
                    break
                if sample_index < 3:
                    self.sleep(self.confirmation_interval_seconds)
                    continue
                break
            previous_proven = bool(
                len(causality_samples) >= 2
                and bool((causality_samples[-2].get("negative_semantic_contract") or {}).get("certified"))
                and causality_samples[-2].get("request_query_available")
                and causality_samples[-2].get("request_observed") is False
                and causality_samples[-2].get("outbound_activity_query_available")
                and causality_samples[-2].get("later_outbound_activity") is not None
                and bool((causality_samples[-2].get("capture_coverage") or {}).get("covered"))
            )
            if previous_proven:
                negative_evidence_confirmed = True
                break
            if sample_index < 3:
                self.sleep(self.confirmation_interval_seconds)

        causality = {
            "semantic_request": ProtocolWireSemantic.CAST_REQUEST.value,
            "sent_after_monotonic_ms": int(cast_semantic_after_ms),
            "negative_evidence_rule": "CERTIFIED_NEGATIVE_SEMANTICS_PLUS_TWO_CONSECUTIVE_OUTBOUND_COVERED_ABSENT_SAMPLES",
            "negative_semantic_contract": dict(negative_certification),
            "negative_evidence_confirmed": bool(negative_evidence_confirmed),
            "samples": causality_samples,
            "request_query_available": bool(request_query_available),
            "request_observed": cast_request is not None if request_query_available else None,
            "request_evidence": dict(cast_request) if isinstance(cast_request, dict) else None,
            "outbound_activity_query_available": bool(activity_query_available),
            "later_outbound_activity": dict(later_outbound) if isinstance(later_outbound, dict) else None,
            "capture_coverage": coverage,
            "client_instance_id": cast_client_instance_id,
            "confirmation_basis_revision": int(cast_confirmation_basis_revision),
            "admission": admission_evidence,
            "target_projection": projection_evidence,
        }
        if negative_evidence_confirmed:
            # The target click was physically sent but the certified protocol says
            # no semantic cast request left the client. The spell can therefore
            # still be selected; neutralize before allowing any alternate action.
            with self._input_lease():
                neutralization, neutralization_failure = self._neutralize_selected_spell(
                    reason="CLIENT_CAST_REJECTED"
                )
            phase(
                "UI_NEUTRALIZE",
                PhysicalSendState(str(neutralization.get("physical_send_state") or PhysicalSendState.NOT_SENT.value)),
                reason="CLIENT_CAST_REJECTED", neutralized=bool(neutralization.get("neutralized")),
                detail=neutralization.get("detail"),
            )
            if neutralization_failure is not None:
                return with_phases(
                    neutralization_failure,
                    ui_neutralization=neutralization,
                    cast_causality=causality,
                    admission=admission_evidence,
                    target_projection=projection_evidence,
                )
            return with_phases({
                "status": "BLOCKED",
                "failure_code": FailureCode.CLIENT_CAST_REJECTED.value,
                "detail": (
                    "CLIENT_CAST_REJECTED: physical target click was sent, negative semantic causality is certified for this client/spell context, "
                    "and two same-generation capture-covered observations found later outbound traffic with no CAST_REQUEST"
                ),
                "retry_allowed": False,
                "safe_replan": True,
                "quarantine_candidate": True,
                "physical_send_state": PhysicalSendState.SENT.value,
                "semantic_cast_send_state": PhysicalSendState.NOT_SENT.value,
                "ui_neutralization": neutralization,
                "cast_causality": causality,
                "admission": admission_evidence,
                "target_projection": projection_evidence,
            })
        # R5.151: once the target click and semantic CAST request have been sent,
        # a short confirmation-window miss is not proof that the action failed.
        # Persist the exact transaction identity and let the controller passively
        # reconcile fresh Canonical truth.  This prevents slow/stalled transport
        # from converting a recoverable late confirmation into a global control
        # fence, while still quarantining all new physical input until causality
        # is closed.
        semantic_request_observed = bool(request_query_available and cast_request is not None)
        return with_phases(self._reconciling(
            "spell input was sent but server confirmation is still pending; input quarantined",
            uncertainty_context={
                "kind": "COMBAT_CAST",
                "physical_send_state": PhysicalSendState.SENT.value,
                "cast_phase": "SERVER_CONFIRMATION",
                "basis_revision": int(cast_confirmation_basis_revision),
                "fight_instance_id": fight.fight_instance_id,
                "actor_id": int(local_id),
                "spell_id": int(spell_id),
                "target_cell_id": int(target_cell),
                "sent_after_monotonic_ms": int(cast_semantic_after_ms),
                "client_instance_id": cast_client_instance_id,
                "semantic_request_observed": semantic_request_observed,
            },
            failure_code=FailureCode.COMBAT_CAST_CAUSALITY_PENDING.value,
            physical_send_state=PhysicalSendState.SENT.value,
            semantic_cast_send_state=("OBSERVED" if semantic_request_observed else "UNKNOWN"),
            retry_allowed=True,
            safe_replan=False,
            reconciliation_required=True,
            input_quarantined=True,
            first_missing_boundary="SERVER_CONFIRMED_CAST_EVENT",
            likely_owner="LIVE_CONFIRMATION_OR_TRANSPORT",
            cast_causality=causality,
            admission=admission_evidence,
            target_projection=projection_evidence,
        ))

    def _end_turn(self, payload: dict) -> dict:
        before = self.state.snapshot()
        readiness_block = self._guard_readiness(before)
        if readiness_block is not None:
            return readiness_block
        fight = before.fight
        local_id = authoritative_canonical_local_actor_id(before)
        if not fight.present:
            return self._blocked("no fight is present")
        if local_id is None:
            return self._blocked("authoritative local fight actor is not confirmed")
        if fight.active_actor_id.status is not ValueStatus.KNOWN or int(fight.active_actor_id.value) != local_id:
            return self._blocked("it is not the confirmed local actor turn")
        semantic = self._semantic_control_readiness("END_TURN", before)
        if not semantic["ready"]:
            return self._blocked(str(semantic["detail"]))
        control = self._client_point("controls", "END_TURN")
        if control is None:
            return self._blocked("END_TURN calibration is not verified")
        key = self._attempt_key(before.revision, "end_turn", {})
        blocked = self._guard_new_attempt(key)
        if blocked:
            return blocked
        with self._input_lease():
            authorized = self.state.snapshot()
            authorized_local_id = authoritative_canonical_local_actor_id(authorized)
            authorized_semantic = self._semantic_control_readiness("END_TURN", authorized)
            if (
                not authorized.fight.present
                or authorized.fight.fight_instance_id != before.fight.fight_instance_id
                or authorized_local_id is None
                or int(authorized_local_id) != local_id
                or not authorized_semantic.get("ready")
            ):
                return {
                    "status": "BLOCKED",
                    "failure_code": "FIGHT_STATE_CHANGED_BEFORE_INPUT",
                    "first_missing_boundary": "END_TURN_COMMAND_AUTHORIZATION",
                    "likely_owner": "FIGHT_ACTIVE_CONTROL",
                    "retry_allowed": True,
                    "detail": (
                        "fight/turn ownership changed before End Turn input; no click was sent: "
                        + str(authorized_semantic.get("detail") or "control no longer ready")
                    ),
                    "selected_revision": int(before.revision),
                    "authorization_revision": int(authorized.revision),
                    "selected_fight_instance_id": before.fight.fight_instance_id,
                    "authorization_fight_instance_id": authorized.fight.fight_instance_id,
                }
            end_turn_semantic_after_ms = int(time.monotonic() * 1000)
            end_turn_client_instance_id = None
            if hasattr(self.input, "client_instance_id"):
                try:
                    end_turn_client_instance_id = self.input.client_instance_id()
                except Exception:
                    end_turn_client_instance_id = None
            sent = self._send_client(control)
            end_turn_input_evidence = self._input_debug_snapshot()
        if sent is PhysicalSendState.NOT_SENT:
            blocked = self._blocked("End Turn input was not sent")
            blocked["physical_input_evidence"] = end_turn_input_evidence
            return blocked
        self._mark_sent(key)
        if sent is PhysicalSendState.UNCERTAIN:
            input_diagnostic = dict(end_turn_input_evidence)
            result = self._reconciling(
                "End Turn physical delivery is uncertain; input quarantined pending authoritative reconciliation",
                uncertainty_context={
                    "kind": "COMBAT_END_TURN",
                    "physical_send_state": PhysicalSendState.UNCERTAIN.value,
                    "basis_revision": int(before.revision),
                    "fight_instance_id": fight.fight_instance_id,
                    "actor_id": int(local_id),
                    "basis_round": (int(fight.round.value) if fight.round.status is ValueStatus.KNOWN else None),
                    "basis_turn_index": (int(fight.turn_index.value) if fight.turn_index.status is ValueStatus.KNOWN else None),
                    "sent_after_monotonic_ms": int(end_turn_semantic_after_ms),
                    "client_instance_id": end_turn_client_instance_id,
                    "negative_end_turn_absence_samples": 0,
                },
                failure_code=FailureCode.COMBAT_END_TURN_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.UNCERTAIN.value,
                semantic_end_turn_send_state="UNCERTAIN",
                retry_allowed=True,
                safe_replan=False,
                reconciliation_required=True,
                input_quarantined=True,
                first_missing_boundary="COMBAT_END_TURN_PHYSICAL_OR_SEMANTIC_CAUSALITY",
                likely_owner="EXECUTION_SERVICE",
                input_transaction_complete=input_diagnostic.get("transaction_complete"),
                input_delivery=input_diagnostic.get("input_delivery"),
                input_delivery_classification=input_diagnostic.get("physical_delivery_classification"),
            )
            result["physical_input_evidence"] = dict(end_turn_input_evidence)
            return result
        def _turn_ended(snapshot: CanonicalSnapshot) -> bool:
            if not snapshot.fight.present:
                return True
            active = snapshot.fight.active_actor_id
            if active.status is ValueStatus.KNOWN:
                return int(active.value) != local_id
            # R4 jwc is reduced to this explicit UNKNOWN boundary before jwd
            # announces the next active actor.  That server boundary is enough
            # to confirm the End Turn action without waiting for the next turn.
            return active.status is ValueStatus.UNKNOWN and active.detail == "turn ended; awaiting next turn start"

        confirmed, last_observed = self._wait_for_with_last(before.revision, _turn_ended, operation="end_turn")
        if confirmed is None:
            last_revision = int(last_observed.revision) if last_observed is not None else int(before.revision)
            outcome_class = (
                "STATE_CHANGED_UNCONFIRMED"
                if last_revision > int(before.revision)
                else "INPUT_NO_CONFIRMED_EFFECT"
            )
            input_diagnostic: dict = dict(end_turn_input_evidence)
            request_available, end_turn_request = self._protocol_semantic_evidence_since(
                semantic=ProtocolWireSemantic.END_TURN_REQUEST,
                after_monotonic_ms=int(end_turn_semantic_after_ms),
                client_instance_id=end_turn_client_instance_id,
            )
            result = self._reconciling(
                "End Turn was sent but turn-end/next-turn evidence was not confirmed",
                uncertainty_context={
                    "kind": "COMBAT_END_TURN",
                    "basis_revision": int(before.revision),
                    "fight_instance_id": fight.fight_instance_id,
                    "actor_id": int(local_id),
                    "basis_round": (int(fight.round.value) if fight.round.status is ValueStatus.KNOWN else None),
                    "basis_turn_index": (int(fight.turn_index.value) if fight.turn_index.status is ValueStatus.KNOWN else None),
                    "sent_after_monotonic_ms": int(end_turn_semantic_after_ms),
                    "client_instance_id": end_turn_client_instance_id,
                    "negative_end_turn_absence_samples": 0,
                },
                failure_code=FailureCode.COMBAT_END_TURN_CAUSALITY_PENDING.value,
                physical_send_state=PhysicalSendState.SENT.value,
                semantic_end_turn_send_state=("OBSERVED" if request_available and end_turn_request is not None else "UNKNOWN"),
                semantic_end_turn_evidence=(dict(end_turn_request) if isinstance(end_turn_request, dict) else None),
                retry_allowed=True,
                safe_replan=False,
                reconciliation_required=True,
                first_missing_boundary="COMBAT_END_TURN_SETTLEMENT",
                likely_owner="EXECUTION_SERVICE",
                outcome_class=outcome_class,
                basis_revision=int(before.revision),
                last_observed_revision=last_revision,
                confirmation_evidence="EXPECTED_TURN_BOUNDARY_NOT_OBSERVED",
                input_transaction_complete=input_diagnostic.get("transaction_complete"),
                input_delivery=input_diagnostic.get("input_delivery"),
            )
            result["physical_input_evidence"] = dict(end_turn_input_evidence)
            return result
        end_turn_semantic_proof = self._record_session_end_turn_semantic_proof(
            after_monotonic_ms=int(end_turn_semantic_after_ms),
            client_instance_id=end_turn_client_instance_id,
        )
        active = confirmed.fight.active_actor_id
        confirmation = (
            "TURN_END_BOUNDARY"
            if confirmed.fight.present and active.status is ValueStatus.UNKNOWN
            and active.detail == "turn ended; awaiting next turn start"
            else "TURN_OWNER_CHANGED"
        )
        return {
            "status": "CONFIRMED", "confirmed_revision": confirmed.revision,
            "confirmation": confirmation, "detail": "turn end confirmed",
            "semantic_end_turn_send_state": "OBSERVED" if end_turn_semantic_proof.get("recorded") else "UNKNOWN",
            "semantic_end_turn_evidence": end_turn_semantic_proof,
            "physical_input_evidence": dict(end_turn_input_evidence),
        }

    @staticmethod
    def _validate_typed_action(snapshot: CanonicalSnapshot, action: WorldMoveToCellAction | FightMoveToCellAction) -> int | None:
        if isinstance(action, WorldMoveToCellAction):
            if snapshot.fight.present:
                return None
            world_map = snapshot.world.map_id
            if world_map.status is not ValueStatus.KNOWN or world_map.value != action.map_id:
                return None
            return action.map_id
        if not snapshot.fight.present:
            return None
        fight_map = snapshot.fight.map_id
        if fight_map.status is not ValueStatus.KNOWN:
            return None
        active = snapshot.fight.active_actor_id
        if active.status is ValueStatus.KNOWN and active.value != action.actor_id:
            return None
        if not any(actor.actor_id == action.actor_id for actor in snapshot.fight.actors):
            return None
        return int(fight_map.value)

    @staticmethod
    def _confirmed_typed(snapshot: CanonicalSnapshot, action: WorldMoveToCellAction | FightMoveToCellAction) -> bool:
        if isinstance(action, WorldMoveToCellAction):
            return (
                not snapshot.fight.present
                and snapshot.world.map_id.status is ValueStatus.KNOWN
                and snapshot.world.map_id.value == action.map_id
                and snapshot.world.player_cell_id.status is ValueStatus.KNOWN
                and snapshot.world.player_cell_id.value == action.target_cell_id
            )
        if not snapshot.fight.present:
            return False
        for actor in snapshot.fight.actors:
            if actor.actor_id == action.actor_id:
                return actor.cell_id.status is ValueStatus.KNOWN and actor.cell_id.value == action.target_cell_id
        return False

    @staticmethod
    def _blocked_result(action_id: str, detail: str) -> ExecutionResult:
        return ExecutionResult(action_id, ExecutionStatus.BLOCKED, PhysicalSendState.NOT_SENT, detail)

    @staticmethod
    def _blocked(detail: str) -> dict:
        return {"status": "BLOCKED", "detail": detail}

    def _uncertain(self, detail: str, *, uncertainty_context: dict | None = None, **evidence) -> dict:
        self._uncertain_detail = str(detail)
        self._uncertain_context = dict(uncertainty_context) if uncertainty_context is not None else None
        if self._safety is not None:
            self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)
        return {"status": "UNCERTAIN", "detail": detail, **evidence}

    def _reconciling(self, detail: str, *, uncertainty_context: dict, **evidence) -> dict:
        """Persist a combat action whose physical/semantic outcome is observable.

        This state is deliberately non-terminal: no further physical input is
        permitted while causality is ambiguous, but the runtime may passively
        observe Canonical State until the old transaction becomes causally closed.
        """
        self._uncertain_detail = str(detail)
        self._uncertain_context = dict(uncertainty_context)
        if self._safety is not None:
            self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)
        return {"status": "RECONCILING", "detail": detail, **evidence}

    def _clear_uncertainty_locked(self) -> tuple[str | None, dict]:
        previous_detail = self._uncertain_detail
        previous_context = dict(self._uncertain_context or {})
        self._uncertain_detail = None
        self._uncertain_context = None
        if self._safety is not None:
            self._safety.clear_uncertain()
        return previous_detail, previous_context

    def _uncertainty_is_fight_placement(self) -> bool:
        return str((self._uncertain_context or {}).get("kind") or "").upper() == "FIGHT_PLACEMENT"

    def _reconcile_fight_placement_uncertainty_locked(self, *, reason: str) -> dict:
        if self._uncertain_detail is None:
            return {"status": "NO_UNCERTAINTY"}
        if not self._uncertainty_is_fight_placement():
            return {"status": "NOT_APPLICABLE", "reason": "NON_FIGHT_PLACEMENT_UNCERTAINTY"}
        context = dict(self._uncertain_context or {})
        current = self.state.snapshot()
        try:
            basis_revision = int(context.get("basis_revision"))
            expected_fight = int(context.get("fight_instance_id"))
            actor_id = int(context.get("actor_id"))
            target_cell = int(context.get("target_cell_id"))
        except (TypeError, ValueError):
            return {"status": "WAITING", "reason": "PLACEMENT_RECONCILIATION_CONTEXT_INCOMPLETE"}

        outcome = None
        confirmed_revision = None
        if not current.fight.present:
            if int(current.revision) > basis_revision:
                outcome = "FIGHT_ENDED"
        elif current.fight.fight_instance_id != expected_fight:
            if int(current.revision) > basis_revision:
                outcome = "FIGHT_GENERATION_CHANGED"
        else:
            actor = next((item for item in current.fight.actors if int(item.actor_id) == actor_id), None)
            if actor is not None and actor.cell_id.status is ValueStatus.KNOWN and int(actor.cell_id.value) == target_cell:
                try:
                    cell_revision = int(actor.observed.cell_revision)
                except (TypeError, ValueError, AttributeError):
                    cell_revision = int(current.revision)
                if cell_revision > basis_revision or int(current.revision) > basis_revision:
                    outcome = "PLACEMENT_CONFIRMED"
                    confirmed_revision = max(cell_revision, int(current.revision))
            if outcome is None:
                active = current.fight.active_actor_id
                phase = current.fight.phase
                preparation_closed = (
                    active.status is ValueStatus.KNOWN
                    or (phase.status is ValueStatus.KNOWN and str(phase.value) != "PLACEMENT")
                )
                if preparation_closed and int(current.revision) > basis_revision:
                    outcome = "PLACEMENT_PHASE_ENDED"

        common = {
            "failure_code": FailureCode.FIGHT_PLACEMENT_CAUSALITY_PENDING.value,
            "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
            "basis_revision": basis_revision, "canonical_revision": int(current.revision),
            "fight_instance_id": expected_fight, "actor_id": actor_id,
            "target_cell_id": target_cell, "origin_action_id": context.get("origin_action_id"),
            "record_kind": "TRANSACTION_OBSERVATION", "physical_input_event": False,
            "observation_of_action_id": context.get("origin_action_id"),
        }
        if outcome is None:
            return {
                "status": "WAITING", "reason": "FIGHT_PLACEMENT_AWAITING_AUTHORITATIVE_CELL",
                "retry_allowed": True, "physical_retry_allowed": False,
                "input_quarantined": True, "reconciliation_required": True, **common,
            }
        previous_detail, previous_context = self._clear_uncertainty_locked()
        result = {
            "status": "RECONCILED", "reason": str(reason), "outcome": outcome,
            "safe_to_continue": True, "physical_input_sent": False,
            "confirmed_revision": confirmed_revision,
            "previous_detail": previous_detail, "previous_context": previous_context, **common,
        }
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution", event_type="fight_placement_uncertainty_reconciled",
                    severity="INFO", failure_code=None, canonical_revision=int(current.revision),
                    account_id=self.account_id, context=dict(result),
                )
            except Exception:
                pass
        return result

    def _uncertainty_is_combat_move(self) -> bool:
        return str((self._uncertain_context or {}).get("kind") or "").upper() == "COMBAT_MOVE"

    def _uncertainty_is_combat_end_turn(self) -> bool:
        return str((self._uncertain_context or {}).get("kind") or "").upper() == "COMBAT_END_TURN"

    def _uncertainty_is_combat_cast(self) -> bool:
        return str((self._uncertain_context or {}).get("kind") or "").upper() == "COMBAT_CAST"

    def _reconcile_combat_move_uncertainty_locked(self, *, reason: str) -> dict:
        """Passively reconcile a SENT fight MOVE using fresh authoritative truth.

        No input is emitted here.  Fresh cell evidence, a turn handoff, or fight
        termination closes the old action transaction.  Until one of those is
        observed, the physical-input fence remains active and the controller must
        only WAIT.
        """
        if self._uncertain_detail is None:
            return {"status": "NO_UNCERTAINTY"}
        if not self._uncertainty_is_combat_move():
            return {"status": "NOT_APPLICABLE", "reason": "NON_COMBAT_MOVE_UNCERTAINTY"}
        if self._pending_settlement is not None:
            return {"status": "WAITING", "reason": "PENDING_SETTLEMENT"}

        context = dict(self._uncertain_context or {})
        try:
            basis_revision = int(context["basis_revision"])
            actor_id = int(context["actor_id"])
            origin_cell = int(context["origin_cell_id"])
            target_cell = int(context["target_cell_id"])
        except (KeyError, TypeError, ValueError):
            return {"status": "RETAINED", "reason": "COMBAT_MOVE_CONTEXT_INVALID", "context": context}
        fight_instance = context.get("fight_instance_id")
        current = self.state.snapshot()

        outcome = None
        actual_cell = None
        current_actor = None
        evidence_revision = int(current.revision)
        fresh_cell_revision = None
        if not current.fight.present or (
            fight_instance is not None
            and current.fight.fight_instance_id is not None
            and int(current.fight.fight_instance_id) != int(fight_instance)
        ):
            outcome = "FIGHT_ENDED_OR_CHANGED"
        else:
            current_actor = next((item for item in current.fight.actors if int(item.actor_id) == actor_id), None)
            if current_actor is not None and current_actor.cell_id.status is ValueStatus.KNOWN:
                try:
                    cell_revision = int(current_actor.observed.cell_revision)
                except (TypeError, ValueError):
                    cell_revision = -1
                if cell_revision > basis_revision:
                    fresh_cell_revision = cell_revision
                    actual_cell = int(current_actor.cell_id.value)
                    if actual_cell == target_cell:
                        outcome = "TARGET_REACHED"
                    elif actual_cell == origin_cell:
                        outcome = "NO_MOVE_OBSERVED"
                    else:
                        outcome = "MOVED_TO_OTHER_CELL"
            if outcome is None and current.fight.active_actor_id.status is ValueStatus.KNOWN:
                active_actor = int(current.fight.active_actor_id.value)
                if active_actor != actor_id and int(current.revision) > basis_revision:
                    outcome = "TURN_ADVANCED"

        # A fresh cell is sufficient to prove that MOVE changed game state, but it
        # is not sufficient to authorize another move in the *same* actor turn.
        # R5.161 could release TARGET_REACHED here while MP still carried a stale
        # pre-move value. Require explicit resource-change evidence or a newer
        # numerically lower MP observation before clearing the transaction fence.
        basis_mp_value = context.get("basis_mp_value")
        same_actor_turn = bool(
            current.fight.present
            and current.fight.active_actor_id.status is ValueStatus.KNOWN
            and int(current.fight.active_actor_id.value) == actor_id
        )
        if (
            outcome in {"TARGET_REACHED", "MOVED_TO_OTHER_CELL"}
            and same_actor_turn
            and basis_mp_value is not None
        ):
            resource_pending = PendingSettlement(
                action_kind="move_fight",
                basis_revision=basis_revision,
                server_confirmed_revision=int(fresh_cell_revision or current.revision),
                requirements=(
                    SettlementRequirement(
                        actor_id, "mp", int(fresh_cell_revision or current.revision),
                        mode="RESOURCE_DECREASE",
                        baseline_value=int(basis_mp_value),
                    ),
                ),
            )
            resource_missing = missing_requirements(current, resource_pending)
            if resource_missing:
                context["confirmed_move_outcome"] = outcome
                context["confirmed_move_cell_id"] = actual_cell
                context["confirmed_move_cell_revision"] = fresh_cell_revision
                context["resource_settlement_missing"] = list(resource_missing)
                self._uncertain_context = dict(context)
                if self._safety is not None and self._uncertain_detail is not None:
                    self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)
                return {
                    "status": "WAITING",
                    "reason": "COMBAT_MOVE_RESOURCE_AWAITING_AUTHORITATIVE_EVIDENCE",
                    "failure_code": FailureCode.COMBAT_MOVE_RESOURCE_PENDING.value,
                    "retry_allowed": True,
                    "physical_retry_allowed": False,
                    "input_quarantined": True,
                    "reconciliation_required": True,
                    "safe_to_continue": False,
                    "first_missing_boundary": "COMBAT_MOVE_RESOURCE_SETTLEMENT",
                    "likely_owner": "CANONICAL_STATE",
                    "basis_revision": basis_revision,
                    "canonical_revision": int(current.revision),
                    "actor_id": actor_id,
                    "origin_cell_id": origin_cell,
                    "target_cell_id": target_cell,
                    "actual_cell_id": actual_cell,
                    "movement_outcome": outcome,
                    "basis_mp_value": int(basis_mp_value),
                    "current_mp_value": (
                        int(current_actor.mp.value)
                        if current_actor is not None and current_actor.mp.status is ValueStatus.KNOWN
                        else None
                    ),
                    "current_mp_revision": (
                        int(current_actor.observed.mp_revision) if current_actor is not None else 0
                    ),
                    "current_mp_resource_revision": (
                        int(current_actor.observed.mp_resource_revision) if current_actor is not None else 0
                    ),
                    "missing_requirements": list(resource_missing),
                    "origin_action_id": context.get("origin_action_id"),
                    "fight_instance_id": context.get("fight_instance_id"),
                    "operation": str(context.get("operation") or "move_fight"),
                    "record_kind": "TRANSACTION_OBSERVATION",
                    "physical_input_event": False,
                    "observation_of_action_id": context.get("origin_action_id"),
                }

        semantic_request_state = "UNKNOWN"
        semantic_request_evidence = None
        negative_semantic_contract = None
        capture_coverage = None
        latest_outbound_activity = None
        if outcome is None:
            sent_after_ms = context.get("sent_after_monotonic_ms")
            client_instance_id = context.get("client_instance_id")
            try:
                sent_after_ms = int(sent_after_ms)
            except (TypeError, ValueError):
                sent_after_ms = None
            if sent_after_ms is not None:
                request_available, move_request = self._move_request_evidence_since(
                    after_monotonic_ms=sent_after_ms,
                    client_instance_id=client_instance_id,
                    target_cell_id=int(target_cell),
                )
                if request_available and isinstance(move_request, dict):
                    semantic_request_state = "OBSERVED"
                    semantic_request_evidence = dict(move_request)
                    context["negative_move_absence_samples"] = 0
                    context["semantic_move_send_state"] = semantic_request_state
                    context["semantic_move_evidence"] = semantic_request_evidence
                else:
                    negative_semantic_contract = self._move_negative_semantic_certification(
                        client_instance_id=client_instance_id,
                    )
                    activity_available, outbound = self._protocol_activity_since(
                        after_monotonic_ms=sent_after_ms,
                        client_instance_id=client_instance_id, direction="client_to_server",
                    )
                    latest_outbound_activity = dict(outbound) if isinstance(outbound, dict) else None
                    outbound_ms = (
                        int(outbound.get("monotonic_ms"))
                        if isinstance(outbound, dict) and outbound.get("monotonic_ms") is not None
                        else sent_after_ms
                    )
                    coverage_ok, coverage = self._capture_coverage(
                        client_instance_id=client_instance_id,
                        required_through_monotonic_ms=int(outbound_ms),
                        require_exact_client_instance=True,
                    )
                    capture_coverage = coverage
                    proven_absent_sample = bool(
                        negative_semantic_contract.get("certified")
                        and request_available
                        and move_request is None
                        and activity_available
                        and outbound is not None
                        and coverage_ok
                    )
                    if proven_absent_sample:
                        samples = int(context.get("negative_move_absence_samples") or 0) + 1
                        context["negative_move_absence_samples"] = samples
                        context["semantic_move_send_state"] = "ABSENT_SAMPLE"
                        context["negative_semantic_contract"] = dict(negative_semantic_contract)
                        context["capture_coverage"] = dict(coverage)
                        context["latest_outbound_activity"] = latest_outbound_activity
                        if samples >= 2:
                            semantic_request_state = "PROVEN_ABSENT"
                            outcome = "NO_SEMANTIC_MOVE_REQUEST"
                    else:
                        context["semantic_move_send_state"] = "UNKNOWN"
                self._uncertain_context = dict(context)
                if self._safety is not None and self._uncertain_detail is not None:
                    self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)

        if outcome is None:
            return {
                "status": "WAITING",
                "reason": "COMBAT_MOVE_AWAITING_AUTHORITATIVE_EVIDENCE",
                "failure_code": "COMBAT_MOVE_CAUSALITY_PENDING",
                "retry_allowed": True,
                "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
                "first_missing_boundary": "COMBAT_MOVE_SETTLEMENT",
                "likely_owner": "EXECUTION_SERVICE",
                "basis_revision": basis_revision,
                "canonical_revision": int(current.revision),
                "actor_id": actor_id,
                "origin_cell_id": origin_cell,
                "target_cell_id": target_cell,
                "semantic_move_send_state": semantic_request_state,
                "semantic_move_evidence": semantic_request_evidence,
                "negative_semantic_contract": negative_semantic_contract,
                "capture_coverage": capture_coverage,
                "latest_outbound_activity": latest_outbound_activity,
                "negative_move_absence_samples": int(context.get("negative_move_absence_samples") or 0),
                "origin_action_id": context.get("origin_action_id"),
                "fight_instance_id": context.get("fight_instance_id"),
                "operation": str(context.get("operation") or "move_fight"),
                "record_kind": "TRANSACTION_OBSERVATION",
                "physical_input_event": False,
                "observation_of_action_id": context.get("origin_action_id"),
            }

        previous_detail, previous_context = self._clear_uncertainty_locked()
        result = {
            "status": "RECONCILED",
            "reason": str(reason),
            "outcome": outcome,
            "safe_to_continue": True,
            "physical_input_sent": False,
            "basis_revision": basis_revision,
            "canonical_revision": int(current.revision),
            "evidence_revision": fresh_cell_revision or evidence_revision,
            "actor_id": actor_id,
            "origin_cell_id": origin_cell,
            "target_cell_id": target_cell,
            "actual_cell_id": actual_cell,
            "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
            "semantic_move_send_state": semantic_request_state,
            "semantic_move_evidence": semantic_request_evidence,
            "negative_semantic_contract": negative_semantic_contract,
            "capture_coverage": capture_coverage,
            "latest_outbound_activity": latest_outbound_activity,
            "previous_detail": previous_detail,
            "previous_context": previous_context,
            "origin_action_id": context.get("origin_action_id"),
            "fight_instance_id": context.get("fight_instance_id"),
            "operation": str(context.get("operation") or "move_fight"),
            "record_kind": "TRANSACTION_OBSERVATION",
            "physical_input_event": False,
            "observation_of_action_id": context.get("origin_action_id"),
        }
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution", event_type="combat_move_uncertainty_reconciled",
                    severity="INFO", failure_code=None, canonical_revision=int(current.revision),
                    account_id=self.account_id, context=dict(result),
                )
            except Exception:
                pass
        return result

    def _reconcile_combat_cast_uncertainty_locked(self, *, reason: str) -> dict:
        """Passively close a physically ambiguous CAST without issuing input.

        A slot/target transaction can be ambiguous while the game remains healthy.
        The safe response is to quarantine all further input and observe canonical
        cast history/turn ownership.  A confirmed matching cast may resume the same
        turn only after the local AP observation is at least as fresh as that cast;
        otherwise natural turn/fight progress closes the old transaction.
        """
        if self._uncertain_detail is None:
            return {"status": "NO_UNCERTAINTY"}
        if not self._uncertainty_is_combat_cast():
            return {"status": "NOT_APPLICABLE", "reason": "NON_COMBAT_CAST_UNCERTAINTY"}
        context = dict(self._uncertain_context or {})
        try:
            basis_revision = int(context["basis_revision"])
            actor_id = int(context["actor_id"])
            spell_id = int(context["spell_id"])
        except (KeyError, TypeError, ValueError):
            return {"status": "RETAINED", "reason": "COMBAT_CAST_CONTEXT_INVALID", "context": context}
        target_cell = context.get("target_cell_id")
        try:
            target_cell = int(target_cell) if target_cell is not None else None
        except (TypeError, ValueError):
            target_cell = None
        fight_instance = context.get("fight_instance_id")
        current = self.state.snapshot()
        outcome = None
        cast_evidence = None
        settled_ap_revision = None

        if not current.fight.present or (
            fight_instance is not None and current.fight.fight_instance_id is not None
            and int(current.fight.fight_instance_id) != int(fight_instance)
        ):
            outcome = "FIGHT_ENDED_OR_CHANGED"
        else:
            persistent_casts = getattr(current.fight, "confirmed_casts_this_fight", ())
            cast_history = persistent_casts if persistent_casts else current.fight.confirmed_casts_this_turn
            matching = []
            for cast in cast_history:
                try:
                    observed_revision = int(cast.observed_revision)
                except (TypeError, ValueError):
                    continue
                if observed_revision <= basis_revision:
                    continue
                if int(cast.caster_actor_id) != actor_id or int(cast.spell_id) != spell_id:
                    continue
                if target_cell is not None:
                    cell = getattr(cast, "target_cell_id", None)
                    if getattr(cell, "status", None) is ValueStatus.KNOWN and int(cell.value) != target_cell:
                        continue
                matching.append(cast)
            if matching:
                cast = max(matching, key=lambda item: int(item.observed_revision))
                cast_revision = int(cast.observed_revision)
                local_actor = next((item for item in current.fight.actors if int(item.actor_id) == actor_id), None)
                if local_actor is not None:
                    try:
                        settled_ap_revision = int(local_actor.observed.ap_revision)
                    except (TypeError, ValueError, AttributeError):
                        settled_ap_revision = None
                cast_evidence = {
                    "observed_revision": cast_revision,
                    "caster_actor_id": int(cast.caster_actor_id),
                    "spell_id": int(cast.spell_id),
                    "target_cell_id": (
                        int(cast.target_cell_id.value)
                        if getattr(cast.target_cell_id, "status", None) is ValueStatus.KNOWN
                        else None
                    ),
                }
                if settled_ap_revision is not None and settled_ap_revision >= cast_revision:
                    outcome = "CAST_CONFIRMED"
            if outcome is None and current.fight.active_actor_id.status is ValueStatus.KNOWN:
                if int(current.fight.active_actor_id.value) != actor_id and int(current.revision) > basis_revision:
                    outcome = "TURN_ADVANCED"
            elif (
                outcome is None
                and current.fight.active_actor_id.status is ValueStatus.UNKNOWN
                and current.fight.active_actor_id.detail == "turn ended; awaiting next turn start"
                and int(current.revision) > basis_revision
            ):
                outcome = "TURN_END_BOUNDARY"

        semantic_cast_send_state = (
            "OBSERVED"
            if bool(context.get("semantic_request_observed")) or cast_evidence is not None
            else "UNKNOWN"
        )
        common = {
            "failure_code": FailureCode.COMBAT_CAST_CAUSALITY_PENDING.value,
            "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.UNCERTAIN.value),
            "semantic_cast_send_state": semantic_cast_send_state,
            "semantic_request_observed": bool(context.get("semantic_request_observed")),
            "basis_revision": basis_revision,
            "canonical_revision": int(current.revision),
            "actor_id": actor_id,
            "spell_id": spell_id,
            "target_cell_id": target_cell,
            "cast_phase": context.get("cast_phase"),
            "cast_evidence": cast_evidence,
            "settled_ap_revision": settled_ap_revision,
            "origin_action_id": context.get("origin_action_id"),
            "fight_instance_id": context.get("fight_instance_id"),
            "operation": str(context.get("operation") or "cast_spell"),
            "record_kind": "TRANSACTION_OBSERVATION",
            "physical_input_event": False,
            "observation_of_action_id": context.get("origin_action_id"),
        }
        if outcome is None:
            return {
                "status": "WAITING",
                "reason": (
                    "COMBAT_CAST_CONFIRMED_AWAITING_RESOURCE_SETTLEMENT"
                    if cast_evidence is not None else "COMBAT_CAST_AWAITING_AUTHORITATIVE_EVIDENCE"
                ),
                "retry_allowed": True,
                "input_quarantined": True,
                "first_missing_boundary": "COMBAT_CAST_SETTLEMENT",
                "likely_owner": "EXECUTION_SERVICE",
                **common,
            }
        previous_detail, previous_context = self._clear_uncertainty_locked()
        result = {
            "status": "RECONCILED", "reason": str(reason), "outcome": outcome,
            "safe_to_continue": True, "physical_input_sent": False,
            "previous_detail": previous_detail, "previous_context": previous_context, **common,
        }
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution", event_type="combat_cast_uncertainty_reconciled",
                    severity="INFO", failure_code=None, canonical_revision=int(current.revision),
                    account_id=self.account_id, context=dict(result),
                )
            except Exception:
                pass
        return result

    def _reconcile_combat_end_turn_uncertainty_locked(self, *, reason: str) -> dict:
        if self._uncertain_detail is None:
            return {"status": "NO_UNCERTAINTY"}
        if not self._uncertainty_is_combat_end_turn():
            return {"status": "NOT_APPLICABLE", "reason": "NON_COMBAT_END_TURN_UNCERTAINTY"}
        context = dict(self._uncertain_context or {})
        try:
            basis_revision = int(context["basis_revision"])
            actor_id = int(context["actor_id"])
        except (KeyError, TypeError, ValueError):
            return {"status": "RETAINED", "reason": "COMBAT_END_TURN_CONTEXT_INVALID", "context": context}
        fight_instance = context.get("fight_instance_id")
        current = self.state.snapshot()
        outcome = None
        if not current.fight.present or (
            fight_instance is not None and current.fight.fight_instance_id is not None
            and int(current.fight.fight_instance_id) != int(fight_instance)
        ):
            outcome = "FIGHT_ENDED_OR_CHANGED"
        else:
            active = current.fight.active_actor_id
            if active.status is ValueStatus.KNOWN and int(active.value) != actor_id and int(current.revision) > basis_revision:
                outcome = "TURN_ADVANCED"
            elif active.status is ValueStatus.UNKNOWN and active.detail == "turn ended; awaiting next turn start" and int(current.revision) > basis_revision:
                outcome = "TURN_END_BOUNDARY"

        semantic_state = "UNKNOWN"
        semantic_evidence = None
        negative_contract = None
        capture_coverage = None
        latest_outbound_activity = None
        if outcome is None:
            try:
                sent_after_ms = int(context.get("sent_after_monotonic_ms"))
            except (TypeError, ValueError):
                sent_after_ms = None
            client_instance_id = context.get("client_instance_id")
            if sent_after_ms is not None:
                available, request = self._protocol_semantic_evidence_since(
                    semantic=ProtocolWireSemantic.END_TURN_REQUEST,
                    after_monotonic_ms=sent_after_ms, client_instance_id=client_instance_id,
                )
                if available and isinstance(request, dict):
                    semantic_state = "OBSERVED"
                    semantic_evidence = dict(request)
                    context["negative_end_turn_absence_samples"] = 0
                else:
                    negative_contract = self._end_turn_negative_semantic_certification(
                        client_instance_id=client_instance_id
                    )
                    activity_available, outbound = self._protocol_activity_since(
                        after_monotonic_ms=sent_after_ms, client_instance_id=client_instance_id,
                        direction="client_to_server",
                    )
                    latest_outbound_activity = dict(outbound) if isinstance(outbound, dict) else None
                    outbound_ms = (
                        int(outbound.get("monotonic_ms"))
                        if isinstance(outbound, dict) and outbound.get("monotonic_ms") is not None
                        else sent_after_ms
                    )
                    coverage_ok, coverage = self._capture_coverage(
                        client_instance_id=client_instance_id,
                        required_through_monotonic_ms=int(outbound_ms),
                        require_exact_client_instance=True,
                    )
                    capture_coverage = coverage
                    proven_absent = bool(
                        negative_contract.get("certified") and available and request is None
                        and activity_available and outbound is not None and coverage_ok
                    )
                    if proven_absent:
                        samples = int(context.get("negative_end_turn_absence_samples") or 0) + 1
                        context["negative_end_turn_absence_samples"] = samples
                        semantic_state = "ABSENT_SAMPLE"
                        if samples >= 2:
                            semantic_state = "PROVEN_ABSENT"
                            outcome = "NO_SEMANTIC_END_TURN_REQUEST"
                context["semantic_end_turn_send_state"] = semantic_state
                self._uncertain_context = dict(context)
                if self._safety is not None and self._uncertain_detail is not None:
                    self._safety.set_uncertain(self._uncertain_detail, self._uncertain_context)

        common = {
            "failure_code": FailureCode.COMBAT_END_TURN_CAUSALITY_PENDING.value,
            "physical_send_state": str(context.get("physical_send_state") or PhysicalSendState.SENT.value),
            "basis_revision": basis_revision, "canonical_revision": int(current.revision),
            "actor_id": actor_id, "semantic_end_turn_send_state": semantic_state,
            "semantic_end_turn_evidence": semantic_evidence,
            "negative_semantic_contract": negative_contract,
            "capture_coverage": capture_coverage,
            "latest_outbound_activity": latest_outbound_activity,
            "negative_end_turn_absence_samples": int(context.get("negative_end_turn_absence_samples") or 0),
            "origin_action_id": context.get("origin_action_id"),
            "fight_instance_id": context.get("fight_instance_id"),
            "operation": str(context.get("operation") or "end_turn"),
            "record_kind": "TRANSACTION_OBSERVATION", "physical_input_event": False,
            "observation_of_action_id": context.get("origin_action_id"),
        }
        if outcome is None:
            return {
                "status": "WAITING", "reason": "COMBAT_END_TURN_AWAITING_AUTHORITATIVE_EVIDENCE",
                "retry_allowed": True, "first_missing_boundary": "COMBAT_END_TURN_SETTLEMENT",
                "likely_owner": "EXECUTION_SERVICE", **common,
            }
        previous_detail, previous_context = self._clear_uncertainty_locked()
        result = {
            "status": "RECONCILED", "reason": str(reason), "outcome": outcome,
            "safe_to_continue": True, "physical_input_sent": False,
            "previous_detail": previous_detail, "previous_context": previous_context, **common,
        }
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution", event_type="combat_end_turn_uncertainty_reconciled",
                    severity="INFO", failure_code=None, canonical_revision=int(current.revision),
                    account_id=self.account_id, context=dict(result),
                )
            except Exception:
                pass
        return result

    def _retire_terminal_combat_settlement_locked(self, *, current: CanonicalSnapshot, reason: str) -> dict | None:
        """Retire a fight-scoped resource settlement after authoritative fight exit.

        AP/MP settlement is decision-critical only while the originating fight can
        still accept another action.  Once Canonical State proves there is no
        fight, an old ``cast_spell``/``move_fight`` settlement can never become
        useful again and keeping it blocks the next campaign forever.  Clearing it
        at this exact terminal boundary is safe because no physical retry occurs
        and no gameplay fact is fabricated.
        """
        pending = self._pending_settlement
        if pending is None or current.fight.present:
            return None
        if str(pending.action_kind) not in {"move_fight", "cast_spell"}:
            return None
        retired = {
            "action_kind": str(pending.action_kind),
            "basis_revision": int(pending.basis_revision),
            "server_confirmed_revision": int(pending.server_confirmed_revision),
            "requirements": [
                {
                    "actor_id": int(req.actor_id),
                    "field": str(req.field),
                    "after_revision": int(req.after_revision),
                    "mode": str(req.mode),
                    "baseline_value": req.baseline_value,
                }
                for req in pending.requirements
            ],
            "terminal_revision": int(current.revision),
            "reason": str(reason),
        }
        self._pending_settlement = None
        if self._safety is not None:
            self._safety.set_pending(None)
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution",
                    event_type="combat_pending_settlement_retired_at_fight_exit",
                    severity="INFO",
                    failure_code=None,
                    canonical_revision=int(current.revision),
                    account_id=self.account_id,
                    context=dict(retired),
                )
            except Exception:
                pass
        return retired

    def reconcile_combat_action_uncertainty(self, reason: str = "COMBAT_CONTROLLER_POLL") -> dict:
        """Passively reconcile all fight-scoped execution safety obligations.

        The historical name is retained for API compatibility, but R5.164 also
        retires CONFIRMED_UNSETTLED AP/MP obligations once authoritative state
        proves the originating fight has ended.  This is required for clean
        world re-entry and for a new campaign after the final fight.
        """
        token = str(reason or "COMBAT_CONTROLLER_POLL").strip() or "COMBAT_CONTROLLER_POLL"
        with self._lock:
            current = self.state.snapshot()
            retired_pending = self._retire_terminal_combat_settlement_locked(
                current=current, reason=token
            )
            if self._uncertainty_is_combat_move():
                result = self._reconcile_combat_move_uncertainty_locked(reason=token)
            elif self._uncertainty_is_combat_cast():
                result = self._reconcile_combat_cast_uncertainty_locked(reason=token)
            elif self._uncertainty_is_combat_end_turn():
                result = self._reconcile_combat_end_turn_uncertainty_locked(reason=token)
            elif self._uncertain_detail is None:
                if retired_pending is not None:
                    result = {
                        "status": "RECONCILED",
                        "reason": token,
                        "outcome": "FIGHT_ENDED_PENDING_SETTLEMENT_RETIRED",
                        "safe_to_continue": True,
                        "physical_input_sent": False,
                    }
                else:
                    result = {"status": "NO_UNCERTAINTY"}
            else:
                result = {
                    "status": "NOT_APPLICABLE",
                    "reason": "NON_RECONCILABLE_COMBAT_UNCERTAINTY",
                }
            if retired_pending is not None:
                result = {**dict(result), "retired_pending_settlement": retired_pending}
            return result

    @staticmethod
    def _legacy_world_transition_uncertainty(detail: str | None) -> bool:
        token = str(detail or "").strip().lower()
        return token in {
            "world transition send state is uncertain; retry forbidden",
            "world transition was sent but destination map was not confirmed",
            "bootstrap world-transition send state is uncertain; retry forbidden",
            "bootstrap transition was sent but authoritative r4 destination mapid was not confirmed",
        }

    def _uncertainty_is_world_transition(self) -> bool:
        context = self._uncertain_context or {}
        if str(context.get("kind") or "").upper() == "WORLD_TRANSITION":
            return True
        # R5.130 and older safety databases did not persist structured
        # uncertainty context. Keep a deliberately narrow migration path for the
        # exact transition fences emitted by those releases.
        return self._legacy_world_transition_uncertainty(self._uncertain_detail)

    @staticmethod
    def _known_event_map_id(event) -> int | None:
        value = getattr(event, "map_id", None)
        if value is None or getattr(value, "status", None) is not ValueStatus.KNOWN:
            return None
        raw = getattr(value, "value", None)
        return int(raw) if raw is not None else None

    def _fresh_world_truth_evidence(self, *, current: CanonicalSnapshot, confirmed_map_id: int) -> dict:
        """Return evidence that world truth was refreshed after the uncertain edge.

        Snapshot revision alone is insufficient: unrelated NPC traffic can advance
        the canonical sequence while the local map value is merely carried forward.
        When the real CanonicalStateStore query surface is available, require a
        post-fence world-domain event that explicitly carries the currently known
        map. Legacy fences without a persisted basis use the current-process
        startup revision as their conservative migration watermark.
        """
        context = dict(self._uncertain_context or {})
        basis = context.get("basis_revision")
        basis_kind = "UNCERTAINTY_BASIS"
        if basis is None:
            status = getattr(self.state, "runtime_status", None)
            if callable(status):
                try:
                    runtime = status() or {}
                    basis = runtime.get("startup_revision")
                    basis_kind = "PROCESS_STARTUP"
                except Exception:
                    basis = None
        try:
            basis_revision = int(basis) if basis is not None else None
        except (TypeError, ValueError):
            basis_revision = None

        if basis_revision is not None and int(current.revision) <= basis_revision:
            return {
                "fresh": False, "reason": "WORLD_TRUTH_NOT_NEWER_THAN_FENCE",
                "basis_revision": basis_revision, "basis_kind": basis_kind,
                "current_revision": int(current.revision),
            }

        query = getattr(self.state, "events_after", None)
        if callable(query) and basis_revision is not None:
            try:
                events = query(basis_revision, limit=2000)
            except Exception as exc:
                return {
                    "fresh": False, "reason": "WORLD_TRUTH_QUERY_FAILED",
                    "basis_revision": basis_revision, "basis_kind": basis_kind,
                    "detail": f"{type(exc).__name__}: {exc}",
                }
            accepted_kinds = {
                "world_map_observed",
                "world_actor_position_observed",
                "monster_group_snapshot_observed",
                "monster_group_observed",
                "monster_group_moved_observed",
            }
            for envelope in events:
                event = getattr(envelope, "event", None)
                kind = str(getattr(event, "kind", "") or "")
                if kind not in accepted_kinds:
                    continue
                event_map_id = self._known_event_map_id(event)
                if event_map_id != int(confirmed_map_id):
                    continue
                identity = getattr(envelope, "identity", None)
                sequence = getattr(identity, "sequence", None)
                try:
                    sequence_value = int(sequence)
                except (TypeError, ValueError):
                    sequence_value = None
                if sequence_value is not None and sequence_value <= basis_revision:
                    continue
                return {
                    "fresh": True, "reason": "POST_FENCE_WORLD_EVENT",
                    "basis_revision": basis_revision, "basis_kind": basis_kind,
                    "evidence_revision": sequence_value,
                    "evidence_kind": kind,
                    "confirmed_world_map_id": int(confirmed_map_id),
                }
            return {
                "fresh": False, "reason": "WORLD_TRUTH_NOT_REFRESHED_AFTER_FENCE",
                "basis_revision": basis_revision, "basis_kind": basis_kind,
                "current_revision": int(current.revision),
                "confirmed_world_map_id": int(confirmed_map_id),
            }

        # Narrow test/legacy adapter fallback. Production CanonicalStateStore has
        # events_after(); simple mechanical test doubles do not. A structured
        # uncertainty still requires the snapshot revision to have advanced.
        if basis_revision is not None:
            return {
                "fresh": int(current.revision) > basis_revision,
                "reason": "REVISION_FALLBACK_NO_EVENT_QUERY",
                "basis_revision": basis_revision, "basis_kind": basis_kind,
                "current_revision": int(current.revision),
            }
        return {"fresh": False, "reason": "NO_WORLD_FRESHNESS_WATERMARK"}

    def _reconcile_world_transition_uncertainty_locked(
        self, *, reason: str, require_target_match: bool = False
    ) -> dict:
        """Passively retire only a reconcilable world-transition uncertainty.

        A world edge has one authoritative externally observable effect: the
        account's current world MapId. If there is no pending transaction or
        settlement, no fight is present, and Canonical State knows the current
        world MapId, a *new* campaign can safely replan from that truth. Generic
        click/combat uncertainty remains fail-closed.

        This method sends no input and is safe to call from Stop cleanup and
        preflight. It is intentionally conservative about every other fence.
        """
        if self._uncertain_detail is None:
            return {"status": "NO_UNCERTAINTY"}
        if not self._uncertainty_is_world_transition():
            return {"status": "RETAINED", "reason": "NON_WORLD_TRANSITION_UNCERTAINTY"}
        if self._pending_settlement is not None:
            return {"status": "RETAINED", "reason": "PENDING_SETTLEMENT"}
        if self._world_interaction_ledger.pending is not None:
            return {"status": "RETAINED", "reason": "PENDING_WORLD_INTERACTION"}
        current = self.state.snapshot()
        if current.fight.present:
            return {"status": "RETAINED", "reason": "FIGHT_PRESENT", "revision": int(current.revision)}
        world_map = current.world.map_id
        if world_map.status is not ValueStatus.KNOWN or world_map.value is None:
            return {"status": "RETAINED", "reason": "WORLD_MAP_UNKNOWN", "revision": int(current.revision)}

        if require_target_match:
            context = dict(self._uncertain_context or {})
            expected_target = context.get("target_map_id")
            try:
                expected_target = int(expected_target) if expected_target is not None else None
            except (TypeError, ValueError):
                expected_target = None
            if expected_target is None:
                return {
                    "status": "RETAINED",
                    "reason": "ACTIVE_WORLD_TARGET_ID_UNAVAILABLE",
                    "revision": int(current.revision),
                }
            if int(world_map.value) != expected_target:
                source_map = context.get("source_map_id")
                try:
                    source_map = int(source_map) if source_map is not None else None
                except (TypeError, ValueError):
                    source_map = None
                # Remaining on the source map is ordinary late confirmation. A
                # *different* fresh authoritative map, however, contradicts the
                # requested route edge and must never be retired as harmless
                # latency. Certify freshness before escalating so unrelated
                # revision churn cannot create a false mismatch.
                if source_map is None or int(world_map.value) == source_map:
                    return {
                        "status": "RETAINED",
                        "reason": "ACTIVE_WORLD_TARGET_NOT_CONFIRMED",
                        "revision": int(current.revision),
                        "current_world_map_id": int(world_map.value),
                        "source_map_id": source_map,
                        "target_map_id": expected_target,
                    }
                mismatch_freshness = self._fresh_world_truth_evidence(
                    current=current, confirmed_map_id=int(world_map.value)
                )
                if mismatch_freshness.get("fresh") is True:
                    return {
                        "status": "MISMATCH",
                        "reason": "FRESH_UNEXPECTED_WORLD_DESTINATION",
                        "revision": int(current.revision),
                        "current_world_map_id": int(world_map.value),
                        "source_map_id": source_map,
                        "target_map_id": expected_target,
                        "freshness": mismatch_freshness,
                    }
                return {
                    "status": "RETAINED",
                    "reason": "UNEXPECTED_WORLD_DESTINATION_NOT_YET_FRESH",
                    "revision": int(current.revision),
                    "current_world_map_id": int(world_map.value),
                    "source_map_id": source_map,
                    "target_map_id": expected_target,
                    "freshness": mismatch_freshness,
                }

        previous_detail = self._uncertain_detail
        previous_context = dict(self._uncertain_context or {})
        confirmed_map_id = int(world_map.value)
        freshness = self._fresh_world_truth_evidence(
            current=current, confirmed_map_id=confirmed_map_id
        )
        if freshness.get("fresh") is not True:
            return {
                "status": "RETAINED",
                "reason": str(freshness.get("reason") or "WORLD_TRUTH_NOT_FRESH"),
                "canonical_revision": int(current.revision),
                "confirmed_world_map_id": confirmed_map_id,
                "freshness": freshness,
            }
        self._uncertain_detail = None
        self._uncertain_context = None
        if self._safety is not None:
            self._safety.clear_uncertain()
        if self.observability is not None:
            try:
                self.observability.record_event(
                    component="execution",
                    event_type="uncertain_fence_reconciled",
                    severity="INFO",
                    failure_code=None,
                    canonical_revision=int(current.revision),
                    account_id=self.account_id,
                    context={
                        "reason": str(reason),
                        "fence_kind": "WORLD_TRANSITION",
                        "previous_detail": previous_detail,
                        "previous_context": previous_context,
                        "confirmed_world_map_id": confirmed_map_id,
                        "freshness": freshness,
                        "physical_input_sent": False,
                    },
                )
            except Exception:
                pass
        return {
            "status": "RECONCILED",
            "reason": str(reason),
            "previous_detail": previous_detail,
            "confirmed_world_map_id": confirmed_map_id,
            "canonical_revision": int(current.revision),
            "freshness": freshness,
        }

    def reconcile_terminal_safety(self, reason: str) -> dict:
        """Passively reconcile terminal-run safety state before session release.

        Terminal cleanup owns both world-transition uncertainty and fight-scoped
        execution obligations.  The latter matters when the final winning action
        ended the fight before its AP/MP/turn settlement completed: there is no
        world re-entry step after TARGET_WINS_REACHED, so session release is the
        last guaranteed lifecycle boundary at which that state can be retired.
        """
        token = str(reason or "").strip() or "SESSION_TERMINAL"
        with self._lock:
            current = self.state.snapshot()
            combat = (
                self.reconcile_combat_action_uncertainty(reason=token)
                if not current.fight.present else {"status": "FIGHT_PRESENT"}
            )
            world = self._reconcile_world_transition_uncertainty_locked(reason=token)
            return {
                "status": (
                    "RECONCILED"
                    if str(combat.get("status") or "") == "RECONCILED"
                    or str(world.get("status") or "") == "RECONCILED"
                    else str(world.get("status") or combat.get("status") or "NO_UNCERTAINTY")
                ),
                "reason": token,
                "combat_reconciliation": dict(combat),
                "world_transition_reconciliation": dict(world),
            }

    def campaign_start_safety_status(self) -> dict:
        """Return passive safety blockers relevant to starting a new campaign.

        This is intentionally separate from turn/decision readiness and runtime
        health. An in-flight action can be healthy during an active run while still
        making a *new* SessionPlan unsafe to start. The method sends no input.
        R5.164 may passively reconcile old *generation-scoped combat* obligations
        after authoritative fight exit and an old *world-transition* uncertainty
        when fresh world truth makes that action's outcome irrelevant to a new
        plan. Generic/ambiguous durable obligations remain fail-closed.
        """
        with self._lock:
            current = self.state.snapshot()
            combat_reconciliation = (
                self.reconcile_combat_action_uncertainty(reason="CAMPAIGN_START_PREFLIGHT")
                if not current.fight.present else {"status": "FIGHT_PRESENT"}
            )
            reconciliation = self._reconcile_world_transition_uncertainty_locked(
                reason="CAMPAIGN_START_PREFLIGHT"
            )
            blockers: list[str] = []
            pending_settlement_payload = None
            if self._pending_settlement is not None:
                current = self.state.snapshot()
                missing = list(missing_requirements(current, self._pending_settlement))
                if missing:
                    blockers.append("EXECUTION_PENDING_SETTLEMENT")
                    pending_settlement_payload = {
                        "action_kind": self._pending_settlement.action_kind,
                        "basis_revision": int(self._pending_settlement.basis_revision),
                        "server_confirmed_revision": int(self._pending_settlement.server_confirmed_revision),
                        "missing_requirements": missing,
                    }
            pending_world = self._world_interaction_ledger.pending
            pending_world_payload = None
            if pending_world is not None:
                blockers.append("EXECUTION_PENDING_WORLD_INTERACTION")
                pending_world_payload = {
                    "operation": pending_world.operation,
                    "map_id": int(pending_world.map_id),
                    "entity_id": int(pending_world.entity_id),
                    "cell_id": int(pending_world.cell_id),
                    "transaction_id": pending_world.transaction_id,
                    "origin_action_id": pending_world.origin_action_id,
                    "attempt_index": int(pending_world.attempt_index),
                    "semantic_state": pending_world.semantic_state.value,
                    "semantic_kind": pending_world.semantic_kind,
                    "client_instance_id": pending_world.client_instance_id,
                }
            if self._uncertain_detail is not None:
                blockers.append("EXECUTION_UNCERTAIN_FENCE")
            return {
                "ready": not blockers,
                "status": "READY" if not blockers else "BLOCKED",
                "blockers": list(dict.fromkeys(blockers)),
                "uncertain_detail": self._uncertain_detail,
                "uncertain_context": dict(self._uncertain_context or {}) or None,
                "combat_reconciliation": dict(combat_reconciliation),
                "world_transition_reconciliation": dict(reconciliation),
                "uncertainty_reconciliation": reconciliation,
                "pending_settlement": pending_settlement_payload,
                "pending_world_interaction": pending_world_payload,
            }

    def continuity_pending_status(self) -> dict:
        """Return the *current* unresolved execution obligation, without input.

        This is deliberately not a history accessor.  Campaign continuity must
        never infer a live transport dependency from the most recently completed
        action: a successful Ready/CAST from minutes ago is diagnostic history,
        not permission to HOLD the campaign when the socket is merely quiet.

        The payload is intentionally small and read-only so the parent runtime can
        decide whether a short server->client silence is relevant to an action
        that is genuinely awaiting authoritative truth right now.
        """
        with self._lock:
            if self._pending_settlement is not None:
                pending = self._pending_settlement
                return {
                    "active": True,
                    "status": "CONFIRMED_UNSETTLED",
                    "kind": str(pending.action_kind),
                    "basis_revision": int(pending.basis_revision),
                    "server_confirmed_revision": int(pending.server_confirmed_revision),
                    "requires_server_to_client_truth": True,
                }

            if self._uncertain_detail is not None:
                context = dict(self._uncertain_context or {})
                return {
                    "active": True,
                    "status": "RECONCILING",
                    "kind": str(context.get("kind") or "EXECUTION_UNCERTAINTY"),
                    "origin_action_id": context.get("origin_action_id"),
                    "fight_instance_id": context.get("fight_instance_id"),
                    "basis_revision": context.get("basis_revision"),
                    "physical_send_state": context.get("physical_send_state"),
                    "requires_server_to_client_truth": True,
                }

            pending_world = self._world_interaction_ledger.pending
            if pending_world is not None:
                return {
                    "active": True,
                    "status": "WORLD_INTERACTION_SETTLING",
                    "kind": str(pending_world.operation),
                    "origin_action_id": pending_world.origin_action_id,
                    "transaction_id": pending_world.transaction_id,
                    "attempt_index": int(pending_world.attempt_index),
                    "semantic_state": pending_world.semantic_state.value,
                    "requires_server_to_client_truth": True,
                }

            # Follower join settlement is owned by a generation-scoped ledger.
            # Do not derive this lookup from the canonical fight snapshot: while
            # a follower is entering combat it can still legitimately be in WORLD
            # state, exactly when transport continuity protection is most useful.
            pending_joins = self._fight_join_ledger.pending_attempts()
            if pending_joins:
                pending_join = max(
                    pending_joins, key=lambda item: int(item.sent_after_monotonic_ms)
                )
                return {
                    "active": True,
                    "status": "JOIN_SETTLING",
                    "kind": "JOIN_FIGHT",
                    "fight_instance_id": int(pending_join.fight_instance_id),
                    "attempt_index": int(pending_join.physical_attempt),
                    "semantic_request_observed": pending_join.semantic_request_observed,
                    "pending_join_count": len(pending_joins),
                    "requires_server_to_client_truth": True,
                }

            return {
                "active": False,
                "status": "IDLE",
                "kind": None,
                "requires_server_to_client_truth": False,
            }

    def prepare_new_campaign(self, session_id: str) -> dict:
        """Prepare recoverable execution bookkeeping for a fresh SessionPlan.

        This deliberately does *not* clear an uncertain fence, pending settlement,
        or pending world interaction. Those represent unresolved physical input and
        remain fail-closed across runs/restarts. Only retry counters/backoff history
        with no pending transaction may be discarded.
        """
        token = str(session_id).strip()
        if not token:
            raise ValueError("session_id is required")
        with self._lock:
            self._reconcile_world_transition_uncertainty_locked(
                reason=f"PREPARE_NEW_CAMPAIGN:{token}"
            )
            # Refresh ordinary settlement from current canonical truth before
            # deciding whether it blocks the new campaign. This sends no input.
            if self._pending_settlement is not None and self._uncertain_detail is None:
                try:
                    self._readiness_from_snapshot(self.state.snapshot())
                except Exception:
                    pass
            pending = self._world_interaction_ledger.pending
            if pending is not None:
                return {
                    "status": "RETAINED_UNRESOLVED",
                    "session_id": token,
                    "uncertain_fence": self._uncertain_detail is not None,
                    "pending_world_interaction": pending.to_dict(),
                    "pending_settlement": self._pending_settlement is not None,
                }
            cleared = self._world_interaction_ledger.clear_recoverable_history_for_new_campaign()
            self._persist_world_interaction()
            return {
                "status": "RECOVERABLE_HISTORY_CLEARED" if cleared else "UNCHANGED",
                "session_id": token,
                "uncertain_fence": self._uncertain_detail is not None,
                "pending_world_interaction": None,
                "pending_settlement": self._pending_settlement is not None,
            }

    def reset_uncertain_fence(self, reason: str) -> None:
        if not str(reason).strip():
            raise ValueError("reset reason is required")
        with self._lock:
            self._uncertain_detail = None
            self._uncertain_context = None
            if self._safety is not None:
                self._safety.clear_uncertain()

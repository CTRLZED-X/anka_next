from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Protocol

import yaml


class CalibrationApi(Protocol):
    def capture_click_point(self, title_contains: str) -> dict: ...


class NativeCalibrationApi:
    VK_LBUTTON = 0x01
    VK_ESCAPE = 0x1B

    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("interactive calibration requires Windows")
        import ctypes
        from ctypes import wintypes

        self.ctypes = ctypes
        self.wintypes = wintypes
        self.user32 = ctypes.windll.user32

    def _title(self, hwnd):
        n = self.user32.GetWindowTextLengthW(hwnd)
        buf = self.ctypes.create_unicode_buffer(n + 1)
        self.user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value

    def _pressed(self, virtual_key: int) -> bool:
        return bool(self.user32.GetAsyncKeyState(int(virtual_key)) & 0x8000)

    def capture_click_point(self, title_contains: str) -> dict:
        """Capture one fresh left click from the requested foreground Dofus window.

        The first mouse click used merely to bring Dofus to the foreground is not
        accepted: capture arms only after the matching Dofus window is foreground
        and the left button has returned to the released state.
        """
        needle = str(title_contains).casefold()

        # First wait until the requested Dofus window is foreground and no click
        # is in progress. This naturally ignores a mouse click used only to focus
        # the Dofus client from the command window.
        while True:
            if self._pressed(self.VK_ESCAPE):
                raise RuntimeError("calibration cancelled by user")
            hwnd = self.user32.GetForegroundWindow()
            title = self._title(hwnd)
            if needle in title.casefold() and not self._pressed(self.VK_LBUTTON):
                armed_hwnd = hwnd
                break
            time.sleep(0.02)

        # Wait for a fresh click. If focus changes before the click, restart the
        # arming process instead of accepting a coordinate from another window.
        while True:
            if self._pressed(self.VK_ESCAPE):
                raise RuntimeError("calibration cancelled by user")
            hwnd = self.user32.GetForegroundWindow()
            title = self._title(hwnd)
            if hwnd != armed_hwnd or needle not in title.casefold():
                return self.capture_click_point(title_contains)
            if self._pressed(self.VK_LBUTTON):
                pt = self.wintypes.POINT()
                self.user32.GetCursorPos(self.ctypes.byref(pt))
                screen = (pt.x, pt.y)
                self.user32.ScreenToClient(hwnd, self.ctypes.byref(pt))
                rect = self.wintypes.RECT()
                self.user32.GetClientRect(hwnd, self.ctypes.byref(rect))
                while self._pressed(self.VK_LBUTTON):
                    time.sleep(0.01)
                return {
                    "client_x": int(pt.x),
                    "client_y": int(pt.y),
                    "screen_x": int(screen[0]),
                    "screen_y": int(screen[1]),
                    "client_width": int(rect.right - rect.left),
                    "client_height": int(rect.bottom - rect.top),
                    "window_title": title,
                }
            time.sleep(0.01)


def _windows_confirmation_beep() -> None:
    if os.name != "nt":
        return
    try:
        import winsound

        winsound.Beep(880, 80)
    except Exception:
        try:
            import winsound

            winsound.MessageBeep()
        except Exception:
            pass


@dataclass
class InteractiveCalibrator:
    config_path: Path
    api: CalibrationApi
    sleep: Callable[[float], None] = time.sleep
    printer: Callable[[str], None] = print
    beeper: Callable[[], None] = _windows_confirmation_beep
    title_contains: str = "Dofus"

    def __init__(
        self,
        config_path: str | Path,
        *,
        api: CalibrationApi | None = None,
        sleep=time.sleep,
        printer=print,
        beeper: Callable[[], None] | None = None,
        title_contains="Dofus",
        profile_name: str | None = None,
    ):
        self.config_path = Path(config_path).resolve()
        self.api = api or NativeCalibrationApi()
        self.sleep = sleep
        self.printer = printer
        self.beeper = beeper or _windows_confirmation_beep
        self.title_contains = title_contains
        self.profile_name = profile_name

    def _handoff(self):
        self.printer("Go to the Dofus window and click each requested target in order.")
        self.printer("A short beep confirms every detected click. Press ESC to cancel.")
        self.printer("If you click once only to focus Dofus, that focus click is ignored.")

    def _load(self):
        raw = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) if self.config_path.exists() else {}
        return raw if isinstance(raw, dict) else {}

    def _save(self, raw):
        self.config_path.write_text(yaml.safe_dump(raw, sort_keys=False, allow_unicode=True), encoding="utf-8")

    def _capture(self, label):
        self.printer(f"{label}: CLICK it now")
        if hasattr(self.api, "capture_click_point"):
            point = self.api.capture_click_point(self.title_contains)
        else:
            # Backwards-compatible test/dry-run adapter support. Production
            # NativeCalibrationApi no longer exposes F8 capture.
            point = self.api.capture_f8_point(self.title_contains)  # type: ignore[attr-defined]
        self.beeper()
        self.printer(f"DETECTED: {label}")
        return point

    @staticmethod
    def _stored(point):
        return {
            "x": int(point["client_x"]),
            "y": int(point["client_y"]),
            "verified": True,
            "source": "user_click_calibration",
        }

    def _calibration_target(self, raw, *, explicit_profile: str | None = None):
        cal = raw.setdefault("calibration", {})
        profile = explicit_profile if explicit_profile is not None else self.profile_name
        if profile and str(profile).strip().casefold() not in {"default", "legacy"}:
            profiles = cal.setdefault("profiles", {})
            return profiles.setdefault(str(profile), {})
        return cal

    def _apply_size(self, cal, point):
        size = {"width": int(point["client_width"]), "height": int(point["client_height"])}
        existing = cal.get("client_size")
        if existing and existing != size:
            raise RuntimeError(f"client size changed during calibration: {existing} -> {size}")
        cal["client_size"] = size

    @staticmethod
    def _interpolate_row(first: dict, last: dict, start_slot: int, end_slot: int) -> dict[str, dict]:
        count = int(end_slot) - int(start_slot)
        if count <= 0:
            raise ValueError("spell row requires at least two anchors")
        result = {}
        for offset, slot in enumerate(range(int(start_slot), int(end_slot) + 1)):
            ratio = offset / count
            x = round(int(first["client_x"]) + (int(last["client_x"]) - int(first["client_x"])) * ratio)
            y = round(int(first["client_y"]) + (int(last["client_y"]) - int(first["client_y"])) * ratio)
            result[str(slot)] = {
                "x": int(x),
                "y": int(y),
                "verified": True,
                "source": "user_click_shared_ui_interpolated",
            }
        return result

    def calibrate_spell_anchors(self):
        """Legacy four-anchor category retained for compatibility."""
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw, explicit_profile="shared")
        anchors = []
        for label in (
            "Spell slot 1 (top-left)",
            "Spell slot 11 (top-right)",
            "Spell slot 12 (bottom-left)",
            "Spell slot 22 (bottom-right)",
        ):
            point = self._capture(label)
            self._apply_size(cal, point)
            anchors.append(point)
        slots = {}
        slots.update(self._interpolate_row(anchors[0], anchors[1], 1, 11))
        slots.update(self._interpolate_row(anchors[2], anchors[3], 12, 22))
        cal["spell_slots"] = slots
        self._save(raw)
        return tuple(anchors)

    def calibrate_phase_button(self):
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw, explicit_profile="shared")
        point = self._capture("PHASE_BUTTON (Challenge / Ready / End Turn)")
        self._apply_size(cal, point)
        cal.setdefault("controls", {})["PHASE_BUTTON"] = self._stored(point)
        self._save(raw)
        return point

    def calibrate_shared_ui(self):
        """Legacy one-command shared calibration, now using clicks instead of F8.

        The R5.67 recommended workflow uses the three category commands, but
        this compatibility command keeps the previous four-anchor geometry.
        """
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw, explicit_profile="shared")
        captures = []
        anchors = []
        for label in (
            "Spell slot 1 (top-left)",
            "Spell slot 11 (top-right)",
            "Spell slot 12 (bottom-left)",
            "Spell slot 22 (bottom-right)",
        ):
            point = self._capture(label)
            self._apply_size(cal, point)
            captures.append(point)
            anchors.append(point)
        slots = {}
        slots.update(self._interpolate_row(anchors[0], anchors[1], 1, 11))
        slots.update(self._interpolate_row(anchors[2], anchors[3], 12, 22))
        cal["spell_slots"] = slots

        phase = self._capture("PHASE_BUTTON (Challenge / Ready / End Turn)")
        self._apply_size(cal, phase)
        captures.append(phase)
        cal.setdefault("controls", {})["PHASE_BUTTON"] = self._stored(phase)

        directions = cal.setdefault("directions", {})
        for name in ("RIGHT", "BOTTOM", "LEFT", "TOP"):
            point = self._capture(name)
            self._apply_size(cal, point)
            captures.append(point)
            directions[name] = self._stored(point)
        self._save(raw)
        return tuple(captures)

    def calibrate_spell_bar(self):
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw)
        slots = cal.setdefault("spell_slots", {})
        results = []
        for slot in range(1, 23):
            point = self._capture(f"Spell slot {slot}/22")
            self._apply_size(cal, point)
            slots[str(slot)] = self._stored(point)
            results.append(point)
        self._save(raw)
        return tuple(results)

    def calibrate_spell_slot(self, slot: int):
        slot = int(slot)
        if not 1 <= slot <= 22:
            raise ValueError("spell slot index must be between 1 and 22")
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw)
        slots = cal.setdefault("spell_slots", {})
        point = self._capture(f"Spell slot {slot}")
        self._apply_size(cal, point)
        slots[str(slot)] = self._stored(point)
        self._save(raw)
        return point

    def calibrate_control(self, name: str):
        name = name.upper()
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw)
        controls = cal.setdefault("controls", {})
        point = self._capture(name)
        self._apply_size(cal, point)
        controls[name] = self._stored(point)
        self._save(raw)
        return point

    def calibrate_directions(self):
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw)
        directions = cal.setdefault("directions", {})
        out = []
        for name in ("RIGHT", "BOTTOM", "LEFT", "TOP"):
            point = self._capture(name)
            self._apply_size(cal, point)
            directions[name] = self._stored(point)
            out.append(point)
        self._save(raw)
        return tuple(out)

    def calibrate_direction(self, name: str):
        name = str(name).upper()
        if name not in {"RIGHT", "BOTTOM", "LEFT", "TOP"}:
            raise ValueError(f"unknown direction: {name}")
        self._handoff()
        raw = self._load()
        cal = self._calibration_target(raw)
        directions = cal.setdefault("directions", {})
        point = self._capture(name)
        self._apply_size(cal, point)
        directions[name] = self._stored(point)
        self._save(raw)
        return point

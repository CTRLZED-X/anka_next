from __future__ import annotations

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, model_validator


class CalibrationPoint(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", populate_by_name=True)

    x: int = Field(ge=0)
    y: int = Field(ge=0)
    verified: bool = False
    source: str = Field(default="unknown", validation_alias=AliasChoices("source", "provenance"))


class ClientSize(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    width: int = Field(gt=0)
    height: int = Field(gt=0)


class CalibrationProfile(BaseModel):
    """One client-relative UI calibration profile.

    This type deliberately contains only runtime UI controls. MapId/CellId
    projection belongs to the automatic Unity bridge and must never be stored
    here.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    client_size: ClientSize | None = None
    spell_slots: dict[int, CalibrationPoint] = Field(default_factory=dict)
    controls: dict[str, CalibrationPoint] = Field(default_factory=dict)
    directions: dict[str, CalibrationPoint] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_points(self) -> "CalibrationProfile":
        if any(slot < 1 or slot > 22 for slot in self.spell_slots):
            raise ValueError("spell slot index must be between 1 and 22")
        if self.client_size is None:
            return self
        for group in (self.spell_slots, self.controls, self.directions):
            for point in group.values():
                if point.x >= self.client_size.width or point.y >= self.client_size.height:
                    raise ValueError(
                        f"calibration point ({point.x},{point.y}) is outside calibrated client "
                        f"{self.client_size.width}x{self.client_size.height}"
                    )
        return self

    _CONTROL_ALIASES = {
        "READY": "PHASE_BUTTON",
        "END_TURN": "PHASE_BUTTON",
        "CHOOSE_CHALLENGE": "PHASE_BUTTON",
    }

    def resolve_control(self, key: str) -> CalibrationPoint | None:
        """Resolve a semantic UI control to its calibrated point.

        Dedicated controls win. Fight-phase semantics fall back to the shared
        PHASE_BUTTON used by the live Dofus UI. This is the single authority
        consumed by both execution and static/script preflight.
        """
        token = str(key).strip().upper()
        if not token:
            return None
        point = self.controls.get(token)
        if point is not None:
            return point
        alias = self._CONTROL_ALIASES.get(token)
        return self.controls.get(alias) if alias else None

    def has_verified_control(self, key: str) -> bool:
        point = self.resolve_control(key)
        return point is not None and bool(point.verified)


class CalibrationSettings(CalibrationProfile):
    """Backward-compatible UI calibration settings with named account profiles.

    The legacy root fields remain the default profile so existing R5.58
    configuration and scripts continue to work. New multi-account lanes use a
    named profile selected by account configuration.
    """

    profiles: dict[str, CalibrationProfile] = Field(default_factory=dict)

    def profile(self, name: str | None) -> CalibrationProfile:
        if name is None or str(name).strip().casefold() in {"", "default", "legacy"}:
            return CalibrationProfile(
                client_size=self.client_size,
                spell_slots=self.spell_slots,
                controls=self.controls,
                directions=self.directions,
            )
        return self.profiles.get(str(name), CalibrationProfile())

    def has_profile(self, name: str | None) -> bool:
        if name is None or str(name).strip().casefold() in {"", "default", "legacy"}:
            return self.client_size is not None or bool(self.spell_slots or self.controls or self.directions)
        return str(name) in self.profiles

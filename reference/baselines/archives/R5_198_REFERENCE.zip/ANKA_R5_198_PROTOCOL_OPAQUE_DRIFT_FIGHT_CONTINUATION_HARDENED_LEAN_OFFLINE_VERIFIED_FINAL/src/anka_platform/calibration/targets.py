from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CalibrationTarget:
    key: str
    label: str


def targets_for(group: str) -> tuple[CalibrationTarget, ...]:
    normalized = group.strip().lower()
    if normalized == "spell-bar":
        return tuple(CalibrationTarget(f"spell_slot_{i}", f"Spell bar slot {i}") for i in range(1, 23))
    if normalized in {"end-turn", "end_turn"}:
        return (CalibrationTarget("END_TURN", "End Turn button"),)
    if normalized in {"choose-challenge", "choose_challenge"}:
        return (CalibrationTarget("CHOOSE_CHALLENGE", "Choose Challenge control"),)
    if normalized == "ready":
        return (CalibrationTarget("READY", "Fight Ready button"),)
    if normalized in {"join-fight", "join_fight"}:
        return (CalibrationTarget("JOIN_FIGHT", "Join group fight button"),)
    if normalized == "directions":
        return tuple(CalibrationTarget(key, f"World transition {key}") for key in ("RIGHT", "BOTTOM", "LEFT", "TOP"))
    raise ValueError(f"unknown calibration group: {group}")

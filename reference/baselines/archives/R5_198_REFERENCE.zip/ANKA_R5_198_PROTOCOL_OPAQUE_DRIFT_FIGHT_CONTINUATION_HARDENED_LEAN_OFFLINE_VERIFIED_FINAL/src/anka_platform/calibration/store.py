from __future__ import annotations

from pathlib import Path

import yaml

from anka_platform.calibration.models import CalibrationPoint


class CalibrationStore:
    def __init__(self, config_path: str | Path) -> None:
        self.config_path = Path(config_path).resolve()

    def save_point(
        self,
        key: str,
        point: CalibrationPoint,
        *,
        profile_name: str | None = None,
        client_size: tuple[int, int] | None = None,
    ) -> None:
        raw = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
        if not isinstance(raw, dict):
            raise ValueError("platform config root must be a mapping")
        calibration = dict(raw.get("calibration") or {})
        target = calibration
        if profile_name and str(profile_name).strip().casefold() not in {"default", "legacy"}:
            profiles = dict(calibration.get("profiles") or {})
            target = dict(profiles.get(str(profile_name)) or {})
            profiles[str(profile_name)] = target
            calibration["profiles"] = profiles

        if client_size is not None:
            width, height = (int(client_size[0]), int(client_size[1]))
            target["client_size"] = {"width": width, "height": height}
        else:
            target.setdefault("client_size", {"width": 1920, "height": 974})

        payload = point.model_dump(mode="json")
        if key.startswith("spell_slot_"):
            slot = int(key.removeprefix("spell_slot_"))
            if not 1 <= slot <= 22:
                raise ValueError("spell slot index must be between 1 and 22")
            group = dict(target.get("spell_slots") or {})
            group[slot] = payload
            target["spell_slots"] = group
        elif key in {"END_TURN", "CHOOSE_CHALLENGE", "READY", "JOIN_FIGHT", "PHASE_BUTTON"}:
            group = dict(target.get("controls") or {})
            group[key] = payload
            target["controls"] = group
        elif key in {"RIGHT", "BOTTOM", "LEFT", "TOP"}:
            group = dict(target.get("directions") or {})
            group[key] = payload
            target["directions"] = group
        else:
            raise ValueError(f"unknown calibration key: {key}")
        raw["calibration"] = calibration
        self.config_path.write_text(yaml.safe_dump(raw, sort_keys=False, allow_unicode=True), encoding="utf-8")
    def export_profile(self, profile_name: str, output_path: str | Path) -> Path:
        raw = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
        calibration = dict(raw.get("calibration") or {})
        profiles = dict(calibration.get("profiles") or {})
        profile = profiles.get(str(profile_name))
        if not isinstance(profile, dict):
            raise ValueError(f"shared calibration is incomplete: profile {profile_name!r} is missing")

        client_size = profile.get("client_size")
        spell_slots = dict(profile.get("spell_slots") or {})
        controls = dict(profile.get("controls") or {})
        directions = dict(profile.get("directions") or {})
        required_slots = {str(i) for i in range(1, 23)}
        missing = []
        if not isinstance(client_size, dict) or not client_size.get("width") or not client_size.get("height"):
            missing.append("client_size")
        if set(map(str, spell_slots.keys())) != required_slots:
            missing.append("spell_slots_1_22")
        phase = controls.get("PHASE_BUTTON")
        if not isinstance(phase, dict) or not phase.get("verified"):
            missing.append("PHASE_BUTTON")
        for name in ("RIGHT", "BOTTOM", "LEFT", "TOP"):
            point = directions.get(name)
            if not isinstance(point, dict) or not point.get("verified"):
                missing.append(name)
        for key, point in spell_slots.items():
            if not isinstance(point, dict) or not point.get("verified"):
                missing.append(f"spell_slot_{key}")
        if missing:
            raise ValueError("shared calibration is incomplete: " + ", ".join(missing))

        payload = {
            "schema_version": 1,
            "kind": "ANKA_SHARED_UI_CALIBRATION",
            "profile_name": str(profile_name),
            "client_size": client_size,
            "spell_slots": spell_slots,
            "controls": {"PHASE_BUTTON": phase},
            "directions": {name: directions[name] for name in ("RIGHT", "BOTTOM", "LEFT", "TOP")},
        }
        output = Path(output_path).resolve()
        output.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
        return output


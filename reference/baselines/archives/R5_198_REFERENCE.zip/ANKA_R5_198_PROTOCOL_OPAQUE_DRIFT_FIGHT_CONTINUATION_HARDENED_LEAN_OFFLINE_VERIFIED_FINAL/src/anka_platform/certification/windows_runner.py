from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import time
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from anka_platform import __version__ as PLATFORM_VERSION
from anka_platform.certification.windows_live import WindowsLiveCertificateStore, validate_windows_certificate
from anka_platform.control_plane import resolve_control_plane_endpoint
from anka_platform.live_preflight import assess_party_preflight_payload


class HttpCertificationApi:
    def __init__(self, base_url: str, *, timeout_seconds: float = 5.0) -> None:
        self.base_url = base_url.rstrip('/')
        self.timeout_seconds = float(timeout_seconds)

    def _request(self, path: str, *, method: str = 'GET', body: bytes | None = None) -> bytes:
        request = Request(
            self.base_url + path,
            data=body,
            method=method,
            headers={'Accept':'application/json','Content-Type':'application/json','User-Agent':f'ANKA-{PLATFORM_VERSION}-certification'},
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                return response.read()
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise RuntimeError(f'{method} {path} failed: {type(exc).__name__}: {exc}') from exc

    def get_json(self, path: str) -> dict[str, Any]:
        payload=json.loads(self._request(path).decode('utf-8'))
        if not isinstance(payload,dict): raise RuntimeError(f'GET {path} did not return a JSON object')
        return payload

    def post_json(self, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body=json.dumps(payload or {}).encode('utf-8')
        raw=json.loads(self._request(path,method='POST',body=body).decode('utf-8'))
        if not isinstance(raw,dict): raise RuntimeError(f'POST {path} did not return a JSON object')
        return raw

    def download(self, path: str) -> bytes:
        return self._request(path,method='POST',body=b'{}')




def copy_latest_debug_bundle(runtime_directory: str | Path, target: str | Path) -> Path | None:
    runtime = Path(runtime_directory).resolve()
    target_path = Path(target).resolve()
    debug = runtime / "debug"
    candidates: list[Path] = []
    pointer = debug / "latest_debug.path"
    if pointer.is_file():
        try:
            candidates.append(Path(pointer.read_text(encoding="utf-8").strip()))
        except Exception:
            pass
    metadata = debug / "latest_debug.json"
    if metadata.is_file():
        try:
            raw = json.loads(metadata.read_text(encoding="utf-8"))
            candidates.append(Path(str(raw.get("bundle_path") or "")))
        except Exception:
            pass
    candidates.extend(sorted(debug.glob("incident_*.zip"), key=lambda item: (item.stat().st_mtime_ns, item.name), reverse=True))
    source = next((item for item in candidates if item.is_file()), None)
    if source is None:
        return None
    target_path.parent.mkdir(parents=True, exist_ok=True)
    temp = target_path.with_suffix(target_path.suffix + ".tmp")
    shutil.copyfile(source, temp)
    temp.replace(target_path)
    return source.resolve()

def _default_static_readiness(config_path: Path) -> bool:
    from anka_platform.config import load_platform_config
    from anka_platform.readiness import assess_readiness
    config=load_platform_config(config_path)
    return bool(assess_readiness(config).phase1_ready)


class WindowsCertificationRunner:
    WORLD_SCRIPT='certify_party_world_loop.py'
    FIGHT_SCRIPT='certify_party_single_fight.py'

    def __init__(
        self,
        *,
        config_path: str | Path,
        platform_url: str,
        api=None,
        printer: Callable[[str],None]=print,
        sleep: Callable[[float],None]=time.sleep,
        static_readiness: Callable[[Path],bool]=_default_static_readiness,
        platform_version: str=PLATFORM_VERSION,
        runtime_directory: str | Path | None=None,
        poll_seconds: float=0.5,
        run_timeout_seconds: float=900.0,
        preflight_timeout_seconds: float=90.0,
        preflight_poll_seconds: float=0.5,
        clock: Callable[[],float]=time.monotonic,
    ) -> None:
        self.config_path=Path(config_path).resolve()
        self.platform_url=platform_url.rstrip('/')
        self.api=api or HttpCertificationApi(self.platform_url)
        self.printer=printer
        self.sleep=sleep
        self.static_readiness=static_readiness
        self.platform_version=str(platform_version)
        self.runtime_directory=(Path(runtime_directory).resolve() if runtime_directory is not None else (self.config_path.parent/'runtime').resolve())
        self.poll_seconds=max(0.0,float(poll_seconds))
        self.run_timeout_seconds=max(1.0,float(run_timeout_seconds))
        self.preflight_timeout_seconds=max(0.0,float(preflight_timeout_seconds))
        self.preflight_poll_seconds=max(0.0,float(preflight_poll_seconds))
        self.clock=clock
        self.certificate_path=self.runtime_directory/'certification'/'windows_live.json'
        self.debug_path=self.runtime_directory/'certification'/'last_failure_debug.zip'
        self.success_debug_path=self.runtime_directory/'certification'/'last_success_debug.zip'
        self.session_log_path=self.runtime_directory/'session.log'

    def _print(self, message: str) -> None:
        text=str(message)
        self.printer(text)
        try:
            self.session_log_path.parent.mkdir(parents=True,exist_ok=True)
            stamp=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
            with self.session_log_path.open('a',encoding='utf-8') as handle:
                handle.write(f'[{stamp}] {text}\n')
        except OSError:
            pass

    def _export_debug(self, *, success: bool=False) -> bool:
        target=self.success_debug_path if success else self.debug_path
        label='CERT_SUCCESS_DEBUG_BUNDLE' if success else 'CERT_DEBUG_BUNDLE'
        try:
            payload=self.api.download('/api/debug/export')
            if not payload:
                raise RuntimeError('debug export returned an empty body')
            target.parent.mkdir(parents=True,exist_ok=True)
            temp=target.with_suffix(target.suffix+'.tmp')
            temp.write_bytes(payload)
            temp.replace(target)
            self._print(f'{label}={target}')
            return True
        except Exception as exc:
            self._print(f'{label}_EXPORT_FAILED={type(exc).__name__}:{exc}')
            recovered=copy_latest_debug_bundle(self.runtime_directory,target)
            if recovered is not None:
                self._print(f'{label}_RECOVERED_FROM_IMMUTABLE={recovered}')
                self._print(f'{label}={target}')
                return True
            self._print(f'{label}_RECOVERY_FAILED=NO_IMMUTABLE_INCIDENT')
            return False

    def _collect_projection_discovery(self) -> None:
        try:
            result=self.api.post_json('/api/party/projection-discover',{})
            self._print('CERT_PROJECTION_DISCOVERY=' + str(result.get('status') or 'CAPTURED'))
        except Exception as exc:
            self._print(f'CERT_PROJECTION_DISCOVERY_FAILED={type(exc).__name__}:{exc}')

    def _record_failure(self, code: str, detail: str) -> None:
        try:
            self.api.post_json('/api/debug/incident', {
                'failure_code': str(code),
                'detail': str(detail or ''),
                'component': 'windows_certification',
            })
        except Exception as exc:
            self._print(f'CERT_DEBUG_INCIDENT_RECORD_FAILED={type(exc).__name__}:{exc}')

    def _fail(self, code: str, detail: str='', *, exit_code: int=5) -> int:
        message=f'WINDOWS_CERTIFICATION=BLOCKED code={code}'
        if detail: message+=f' detail={detail}'
        self._print(message)
        self._record_failure(code, detail)
        self._export_debug()
        return int(exit_code)

    @staticmethod
    def _required_protocol_decoder_blockers(preflight: dict[str,Any]) -> tuple[str,...]:
        blockers=[]
        accounts=preflight.get('accounts') or {}
        if isinstance(accounts,dict):
            for account_id,raw in accounts.items():
                account=raw if isinstance(raw,dict) else {}
                if account.get('required') is not True:
                    continue
                ready=account.get('protocol_decoder_ready')
                if ready is None:
                    # Compatibility with retained R4-only preflight payloads.
                    ready=str(account.get('protocol_dialect') or 'UNKNOWN') == 'R4'
                if ready is not True:
                    mode=account.get('protocol_decoder_mode') or account.get('protocol_dialect') or 'UNKNOWN'
                    blockers.append(f'PROTOCOL_DECODER_NOT_READY:{account_id}:{mode}')
        return tuple(blockers)

    @staticmethod
    def _required_r4_blockers(preflight: dict[str,Any]) -> tuple[str,...]:
        """Compatibility alias retained for older callers/tests."""
        return WindowsCertificationRunner._required_protocol_decoder_blockers(preflight)

    @staticmethod
    def _passive_r4_blockers(preflight: dict[str,Any]) -> tuple[str,...]:
        blockers: list[str] = []
        if preflight.get('enabled') is not True:
            blockers.append('PARTY_MODE_DISABLED')
        for account_id in preflight.get('missing_required') or ():
            blockers.append(f'{account_id}:PARTY_REQUIRED_ACCOUNT_MISSING')
        backend=preflight.get('capture_backend') or {}
        if backend:
            if backend.get('running') is not True:
                blockers.append('CAPTURE_BACKEND_NOT_RUNNING')
            if backend.get('error'):
                blockers.append('CAPTURE_BACKEND_ERROR')
            if int(backend.get('packet_count') or 0) <= 0:
                blockers.append('CAPTURE_NO_TRAFFIC')
        accounts=preflight.get('accounts') or {}
        if not isinstance(accounts,dict) or not accounts:
            blockers.append('PARTY_NO_BOUND_ACCOUNTS')
            return tuple(dict.fromkeys(blockers))
        required_count=0
        for account_id, raw in accounts.items():
            account=raw if isinstance(raw,dict) else {}
            if account.get('required') is not True:
                continue
            required_count += 1
            runtime_health=account.get('runtime_health') or {}
            for blocker in runtime_health.get('blockers') or ():
                token=str(blocker).strip()
                if token:
                    blockers.append(f'{account_id}:{token}')
            capture=account.get('capture') or {}
            if int(capture.get('message_count') or 0) <= 0:
                blockers.append(f'{account_id}:CAPTURE_NO_PROTOCOL_MESSAGES')
            if int(capture.get('canonical_event_count') or 0) <= 0:
                blockers.append(f'{account_id}:CAPTURE_NO_CANONICAL_EVENTS')
            if bool(capture.get('canonical_state_failure_active')):
                blockers.append(f'{account_id}:CAPTURE_CANONICAL_STATE_FAILURE')
            elif capture.get('last_error'):
                blockers.append(f'{account_id}:CAPTURE_TRANSFORM_ERROR')
            decoder_ready=account.get('protocol_decoder_ready')
            if decoder_ready is None:
                decoder_ready=str(account.get('protocol_dialect') or 'UNKNOWN') == 'R4'
            if decoder_ready is not True:
                mode=account.get('protocol_decoder_mode') or account.get('protocol_dialect') or 'UNKNOWN'
                blockers.append(f'PROTOCOL_DECODER_NOT_READY:{account_id}:{mode}')
        if required_count == 0:
            blockers.append('PARTY_NO_REQUIRED_ACCOUNTS')
        return tuple(dict.fromkeys(blockers))

    @staticmethod
    def _full_preflight_blockers(preflight: dict[str,Any]) -> tuple[str,...]:
        assessed=assess_party_preflight_payload(preflight)
        blockers=list(assessed.blockers)
        blockers.extend(WindowsCertificationRunner._required_protocol_decoder_blockers(preflight))
        return tuple(dict.fromkeys(blockers))

    def _wait_preflight(self, stage: str, blocker_fn, *, stable_polls: int=1) -> dict[str,Any]:
        deadline=self.clock()+self.preflight_timeout_seconds
        last_blockers: tuple[str,...] | None=None
        last_payload: dict[str,Any] = {}
        stable_required=max(1,int(stable_polls))
        stable_count=0
        while True:
            last_payload=self.api.get_json('/api/party/preflight')
            blockers=tuple(blocker_fn(last_payload))
            if not blockers:
                stable_count += 1
                if stable_count >= stable_required:
                    return last_payload
                self.sleep(self.preflight_poll_seconds)
                continue
            stable_count=0
            if blockers != last_blockers:
                self._print(f'CERT_WAIT={stage} blockers=' + ','.join(blockers))
                last_blockers=blockers
            if self.clock() >= deadline:
                raise TimeoutError(f'{stage}_TIMEOUT:' + ','.join(blockers))
            self.sleep(self.preflight_poll_seconds)

    def _wait_passive_r4(self) -> dict[str,Any]:
        return self._wait_preflight('PASSIVE_R4', self._passive_r4_blockers)

    def _verify_window_input_ready(self) -> dict[str,Any]:
        payload=self.api.post_json('/api/party/window-input-readiness',{})
        if payload.get('ready') is not True or str(payload.get('status') or '') != 'READY':
            raise RuntimeError('WINDOW_INPUT_READY_BLOCKED:' + json.dumps(payload,sort_keys=True,separators=(',',':')))
        return payload

    @staticmethod
    def _needs_world_map_bootstrap(preflight: dict[str,Any]) -> bool:
        accounts=preflight.get('accounts') or {}
        if not isinstance(accounts,dict):
            return False
        for account in accounts.values():
            if not isinstance(account,dict) or account.get('required') is not True:
                continue
            sync=account.get('sync') or {}
            if str(sync.get('status') or '') == 'WAITING_FOR_CANONICAL_MAP':
                return True
        return False

    def _wait_world_map_bootstrap(self) -> dict[str,Any]:
        deadline=self.clock()+self.preflight_timeout_seconds
        last_detail: str | None=None
        while True:
            assessment=self.api.get_json('/api/party/world-map-bootstrap')
            status=str(assessment.get('status') or 'UNKNOWN')
            if status == 'CONFIRMED':
                return assessment
            if status == 'READY':
                result=self.api.post_json('/api/party/world-map-bootstrap',{})
                start_status=str(result.get('status') or 'UNKNOWN')
                if start_status == 'CONFIRMED':
                    return result
                operation_id=str(result.get('operation_id') or '').strip()
                if start_status not in {'ACCEPTED','RUNNING','WAITING','WAITING_CONFIRMATION','SETTLING'} or not operation_id:
                    raise RuntimeError('WORLD_MAP_BOOTSTRAP_START_FAILED:' + json.dumps(result,sort_keys=True,separators=(',',':')))
                last_operation_detail: str | None=None
                while True:
                    operation=self.api.get_json('/api/operations/' + quote(operation_id,safe=''))
                    operation_status=str(operation.get('status') or 'UNKNOWN')
                    if operation_status == 'CONFIRMED':
                        return operation
                    if bool(operation.get('terminal')) or operation_status in {'BLOCKED','FAILED','UNRESOLVED','INTERRUPTED','CANCELLED'}:
                        raise RuntimeError('WORLD_MAP_BOOTSTRAP_OPERATION_FAILED:' + json.dumps(operation,sort_keys=True,separators=(',',':')))
                    operation_detail=(
                        f"operation_id={operation_id} status={operation_status} "
                        f"phase={operation.get('phase') or 'UNKNOWN'}"
                    )
                    if operation_detail != last_operation_detail:
                        self._print('CERT_WAIT=WORLD_MAP_BOOTSTRAP_OPERATION ' + operation_detail)
                        last_operation_detail=operation_detail
                    if self.clock() >= deadline:
                        raise TimeoutError('WORLD_MAP_BOOTSTRAP_TIMEOUT:' + operation_detail)
                    self.sleep(self.preflight_poll_seconds)
            if status == 'BLOCKED':
                raise RuntimeError('WORLD_MAP_BOOTSTRAP_BLOCKED:' + str(assessment.get('code') or assessment.get('detail') or 'UNKNOWN'))
            detail=(
                f"status={status} code={assessment.get('code') or 'UNKNOWN'} "
                f"waiting={','.join(str(x) for x in assessment.get('waiting_accounts') or ())}"
            )
            if detail != last_detail:
                self._print('CERT_WAIT=WORLD_MAP_BOOTSTRAP ' + detail)
                last_detail=detail
            if self.clock() >= deadline:
                raise TimeoutError('WORLD_MAP_BOOTSTRAP_TIMEOUT:' + detail)
            self.sleep(self.preflight_poll_seconds)

    def _wait_full_preflight(self) -> dict[str,Any]:
        return self._wait_preflight('PROJECTION_WARMUP', self._full_preflight_blockers, stable_polls=3)

    def _script_preflight(self, name: str) -> None:
        payload=self.api.get_json('/api/scripts/' + quote(name,safe=''))
        preflight=payload.get('preflight') or {}
        if preflight.get('ready') is not True:
            raise RuntimeError(f'{name}:SCRIPT_PREFLIGHT_BLOCKED:' + ','.join(str(x) for x in preflight.get('missing') or ()))

    def _run_script(self, name: str, *, pass_marker: str) -> dict[str,Any]:
        self._script_preflight(name)
        started=self.api.post_json('/api/control/certification/scripts/' + quote(name,safe='') + '/run',{})
        run_id=str(started.get('run_id') or '')
        if not run_id: raise RuntimeError(f'{name}:RUN_ID_MISSING')
        deadline=time.monotonic()+self.run_timeout_seconds
        seen=0; last={}
        while time.monotonic() <= deadline:
            last=self.api.get_json('/api/runs/' + quote(run_id,safe=''))
            logs=[str(x) for x in (last.get('logs') or ())]
            for line in logs[seen:]:
                self._print(line)
                if 'CERT_JOIN_MANUAL_REQUIRED' in line:
                    raise RuntimeError(f'{name}:MANUAL_JOIN_FORBIDDEN:{line}')
            seen=len(logs)
            state=str(last.get('state') or '')
            if state in {'COMPLETED','FAILED','STOPPED'}:
                if state != 'COMPLETED':
                    raise RuntimeError(f'{name}:RUN_{state}:{last.get("error") or ""}')
                if not any(pass_marker in line for line in logs):
                    failure=next((line for line in reversed(logs) if '=FAIL' in line), '')
                    raise RuntimeError(f'{name}:PASS_MARKER_MISSING:{failure}')
                return {'run_id':run_id,'state':state,'logs':logs}
            self.sleep(self.poll_seconds)
        raise RuntimeError(f'{name}:RUN_TIMEOUT')

    def _run_controlled(self, *, force: bool=False) -> int:
        try:
            if not self.static_readiness(self.config_path):
                return self._fail('STATIC_READINESS_BLOCKED',exit_code=3)
        except Exception as exc:
            return self._fail('STATIC_READINESS_ERROR',f'{type(exc).__name__}:{exc}',exit_code=3)

        try:
            passive_preflight=self._wait_passive_r4()
        except Exception as exc:
            text=str(exc)
            if 'PROTOCOL_DIALECT_NOT_R4' in text:
                self._print(text)
            code='PASSIVE_R4_TIMEOUT' if 'PASSIVE_R4_TIMEOUT' in text else 'PASSIVE_R4_BLOCKED'
            return self._fail(code,text)
        self._print('CERT_STAGE=PASSIVE_R4 PASS')

        window_input: dict[str,Any] | None = None
        bootstrap_stage: dict[str,Any] = {'status':'PASS','mode':'NOT_REQUIRED'}
        if self._needs_world_map_bootstrap(passive_preflight):
            try:
                window_input=self._verify_window_input_ready()
            except Exception as exc:
                return self._fail('WINDOW_INPUT_READY_BLOCKED',str(exc))
            self._print('CERT_STAGE=WINDOW_INPUT_READY PASS')
            try:
                bootstrap=self._wait_world_map_bootstrap()
            except Exception as exc:
                text=str(exc)
                if 'WORLD_MAP_BOOTSTRAP_TIMEOUT' in text:
                    code='WORLD_MAP_BOOTSTRAP_TIMEOUT'
                else:
                    code='WORLD_MAP_BOOTSTRAP_BLOCKED'
                self._collect_projection_discovery()
                return self._fail(code,text)
            bootstrap_stage={
                'status':'PASS',
                'mode':str(bootstrap.get('mode') or 'FINGERPRINT_TRANSITION'),
                'source_map_id':bootstrap.get('source_map_id'),
                'target_map_id':bootstrap.get('target_map_id'),
                'direction':bootstrap.get('direction'),
            }
            self._print(
                'CERT_STAGE=WORLD_MAP_BOOTSTRAP PASS'
                f" source={bootstrap.get('source_map_id')} target={bootstrap.get('target_map_id')}"
                f" direction={bootstrap.get('direction')}"
            )
        else:
            self._print('CERT_STAGE=WORLD_MAP_BOOTSTRAP PASS mode=NOT_REQUIRED')

        try:
            preflight=self._wait_full_preflight()
        except Exception as exc:
            text=str(exc)
            code='PROJECTION_WARMUP_TIMEOUT' if 'PROJECTION_WARMUP_TIMEOUT' in text else 'PROJECTION_WARMUP_BLOCKED'
            self._collect_projection_discovery()
            return self._fail(code,text)
        self._print('CERT_STAGE=PROJECTION_READY PASS')

        current=validate_windows_certificate(
            self.certificate_path,
            config_path=self.config_path,
            party_preflight=preflight,
            platform_version=self.platform_version,
        )
        if current.ready and not force:
            self._print('WINDOWS_CERTIFICATION=ALREADY_VALID')
            self._export_debug(success=True)
            return 0

        if window_input is None:
            try:
                window_input=self._verify_window_input_ready()
            except Exception as exc:
                return self._fail('WINDOW_INPUT_READY_BLOCKED',str(exc))
            self._print('CERT_STAGE=WINDOW_INPUT_READY PASS')

        stages: dict[str,dict[str,Any]]={
            'PASSIVE_R4':{
                'status':'PASS',
                'accounts':{
                    account_id:{'protocol_dialect':account.get('protocol_dialect'),'client_instance_id':account.get('client_instance_id')}
                    for account_id,account in (passive_preflight.get('accounts') or {}).items()
                    if isinstance(account,dict) and account.get('required') is True
                },
            },
            'WINDOW_INPUT_READY':{'status':'PASS','accounts':(window_input or {}).get('accounts') or {}},
            'WORLD_MAP_BOOTSTRAP':bootstrap_stage,
            'PROJECTION_READY':{'status':'PASS'},
        }

        try:
            # Search/fight first: certification should exercise the normal live
            # workflow instead of forcing a full patrol before the first fight.
            fight=self._run_script(self.FIGHT_SCRIPT,pass_marker='CERT_SINGLE_FIGHT=PASS outcome=WIN')
            self._wait_full_preflight()
            stages['SINGLE_FIGHT']={
                'status':'PASS','run_id':fight['run_id'],'automatic_join_only':True
            }
            self._print('CERT_STAGE=SINGLE_FIGHT PASS')

            world=self._run_script(self.WORLD_SCRIPT,pass_marker='CERT_WORLD_LOOP=PASS')
            final_preflight=self._wait_full_preflight()
            stages['WORLD_LOOP']={'status':'PASS','run_id':world['run_id']}
            self._print('CERT_STAGE=WORLD_LOOP PASS')
        except Exception as exc:
            detail=f'{type(exc).__name__}:{exc}'
            code='SCRIPT_PREFLIGHT_BLOCKED' if 'SCRIPT_PREFLIGHT_BLOCKED' in str(exc) else 'CONTROLLED_LIVE_STAGE_FAILED'
            return self._fail(code,detail)

        WindowsLiveCertificateStore(self.certificate_path).write_pass(
            config_path=self.config_path,
            party_preflight=final_preflight,
            platform_version=self.platform_version,
            stages=stages,
            extra={'platform_url':self.platform_url},
        )
        self._print(f'WINDOWS_CERTIFICATE={self.certificate_path}')
        self._print('WINDOWS_CERTIFICATION=PASSED')
        self._export_debug(success=True)
        return 0


    def run(self, *, force: bool=False) -> int:
        """Run the control-capable Windows certification under an explicit permit.

        Certification is intentionally different from normal startup/preflight: it
        may move characters and start a fight.  R5.120 requires the platform to be
        explicitly armed for CERTIFICATION_CONTROL before any such path can execute,
        and always disarms it again on exit.
        """
        armed = False
        try:
            permit = self.api.post_json('/api/control/certification/arm', {
                'source': 'WINDOWS_CERTIFICATION_RUNNER',
            })
            if str(permit.get('mode') or '') != 'CERTIFICATION_CONTROL':
                return self._fail(
                    'CERTIFICATION_CONTROL_AUTHORITY_BLOCKED',
                    'platform did not grant CERTIFICATION_CONTROL',
                )
            armed = True
            self._print('CERT_CONTROL_AUTHORITY=ARMED mode=CERTIFICATION_CONTROL')
            return self._run_controlled(force=force)
        except Exception as exc:
            return self._fail(
                'CERTIFICATION_CONTROL_AUTHORITY_BLOCKED',
                f'{type(exc).__name__}:{exc}',
            )
        finally:
            if armed:
                try:
                    self.api.post_json('/api/control/certification/disarm', {
                        'reason': 'WINDOWS_CERTIFICATION_FINISHED',
                    })
                    self._print('CERT_CONTROL_AUTHORITY=DISARMED')
                except Exception as exc:
                    self._print(f'CERT_CONTROL_DISARM_FAILED={type(exc).__name__}:{exc}')

def _parser() -> argparse.ArgumentParser:
    parser=argparse.ArgumentParser(description='ANKA Windows live certification')
    parser.add_argument('--config',type=Path,default=Path('config.yaml'))
    parser.add_argument('--platform-url',default=None, help='advanced override; defaults to config.web host/port')
    parser.add_argument('--force',action='store_true')
    return parser


def main(argv=None) -> int:
    args=_parser().parse_args(argv)
    platform_url = args.platform_url or resolve_control_plane_endpoint(args.config).base_url
    return WindowsCertificationRunner(config_path=args.config,platform_url=platform_url).run(force=args.force)


if __name__ == '__main__':
    raise SystemExit(main())

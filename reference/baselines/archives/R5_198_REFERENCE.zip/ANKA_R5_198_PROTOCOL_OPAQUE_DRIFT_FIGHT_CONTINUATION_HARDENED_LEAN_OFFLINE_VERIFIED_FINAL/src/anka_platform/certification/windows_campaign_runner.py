from __future__ import annotations

import argparse
from pathlib import Path
import time
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.parse import quote

from anka_platform.certification.windows_runner import HttpCertificationApi, copy_latest_debug_bundle
from anka_platform.control_plane import resolve_control_plane_endpoint


class WindowsCampaignRunner:
    """Run the currently applied generic campaign through the normal control plane.

    Historical releases directly launched ``party_square_6_8_five_fights.py`` and
    parsed ``wins=5 attempts=5`` log strings.  That bypassed the immutable
    SessionPlan lifecycle and froze certification to one account/route/budget
    shape.  R5.117 certifies the same path Script Studio uses: an applied
    SessionPlan is launched by ApplicationService, whose mission launcher is the
    generic parent-owned ``campaign_runtime.py`` worker.

    ``WindowsCampaignRunner`` is kept as the public class name so existing batch
    entrypoints do not break; its semantics are now configuration-agnostic.
    """

    SCRIPT = "campaign_runtime.py"

    def __init__(
        self,
        *,
        platform_url: str,
        api=None,
        printer: Callable[[str], None] = print,
        sleep: Callable[[float], None] = time.sleep,
        runtime_directory: str | Path = "runtime",
        poll_seconds: float = 0.5,
        run_timeout_seconds: float = 7200.0,
        session_id: str | None = None,
    ) -> None:
        self.platform_url = platform_url.rstrip("/")
        self.api = api or HttpCertificationApi(self.platform_url)
        self.printer = printer
        self.sleep = sleep
        self.runtime_directory = Path(runtime_directory).resolve()
        self.poll_seconds = max(0.0, float(poll_seconds))
        self.run_timeout_seconds = max(1.0, float(run_timeout_seconds))
        self.session_id = str(session_id).strip() if session_id is not None else None
        self.debug_path = self.runtime_directory / "certification" / "last_campaign_debug.zip"
        self.success_debug_path = self.runtime_directory / "certification" / "last_campaign_success_debug.zip"
        self.session_log_path = self.runtime_directory / "session.log"

    def _print(self, message: str) -> None:
        text = str(message)
        self.printer(text)
        try:
            self.session_log_path.parent.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            with self.session_log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"[{stamp}] {text}\n")
        except OSError:
            pass

    def _export_debug(self, *, success: bool = False) -> bool:
        target = self.success_debug_path if success else self.debug_path
        label = "CAMPAIGN_SUCCESS_DEBUG_BUNDLE" if success else "CAMPAIGN_DEBUG_BUNDLE"
        try:
            payload = self.api.download("/api/debug/export")
            if not payload:
                raise RuntimeError("debug export returned an empty body")
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_suffix(target.suffix + ".tmp")
            temp.write_bytes(payload)
            temp.replace(target)
            self._print(f"{label}={target}")
            return True
        except Exception as exc:
            self._print(f"{label}_EXPORT_FAILED={type(exc).__name__}:{exc}")
            recovered = copy_latest_debug_bundle(self.runtime_directory, target)
            if recovered is not None:
                self._print(f"{label}_RECOVERED_FROM_IMMUTABLE={recovered}")
                self._print(f"{label}={target}")
                return True
            self._print(f"{label}_RECOVERY_FAILED=NO_IMMUTABLE_INCIDENT")
            return False

    def _fail(self, detail: str, *, code: int = 6) -> int:
        self._print(f"CAMPAIGN_CERTIFICATION=FAILED detail={detail}")
        self._export_debug()
        return int(code)

    @staticmethod
    def _find_session(state: dict, session_id: str | None) -> tuple[str, dict] | None:
        active = [dict(item) for item in state.get("active_sessions") or () if isinstance(item, dict)]
        applied = [dict(item) for item in state.get("applied_sessions") or () if isinstance(item, dict)]
        token = str(session_id or state.get("focused_session_id") or "").strip()
        if token:
            for item in (*active, *applied):
                if str(item.get("session_id") or "") == token:
                    return ("ACTIVE" if item in active else "APPLIED", item)
            return None
        if len(active) == 1:
            return "ACTIVE", active[0]
        if not active and len(applied) == 1:
            return "APPLIED", applied[0]
        return None

    def _resolve_or_launch_run(self) -> tuple[str, str]:
        try:
            state = dict(self.api.get_json("/api/studio/state") or {})
        except Exception as exc:
            raise RuntimeError(f"STUDIO_STATE_ERROR:{type(exc).__name__}:{exc}") from exc
        selected = self._find_session(state, self.session_id)
        if selected is None:
            raise RuntimeError(
                "SESSION_SELECTION_REQUIRED: apply exactly one Script Studio session "
                "or pass --session-id before campaign certification"
            )
        kind, item = selected
        session_id = str(item.get("session_id") or "").strip()
        if not session_id:
            raise RuntimeError("SESSION_ID_MISSING")

        if kind == "ACTIVE":
            run_id = str(item.get("run_id") or "").strip()
            if not run_id:
                raise RuntimeError(f"ACTIVE_SESSION_RUN_ID_MISSING:{session_id}")
            return session_id, run_id

        try:
            preflight = dict(
                self.api.get_json(
                    "/api/studio/session/applied/" + quote(session_id, safe="") + "/preflight"
                )
                or {}
            )
        except Exception as exc:
            raise RuntimeError(f"SESSION_PREFLIGHT_ERROR:{type(exc).__name__}:{exc}") from exc
        if preflight.get("ready") is not True:
            blockers = ",".join(str(x) for x in preflight.get("blockers") or ())
            raise RuntimeError(f"SESSION_PREFLIGHT_BLOCKED:{blockers or 'NOT_READY'}")

        try:
            started = dict(
                self.api.post_json(
                    "/api/studio/session/launch-applied",
                    {"applied_session_id": session_id},
                )
                or {}
            )
        except Exception as exc:
            raise RuntimeError(f"SESSION_LAUNCH_ERROR:{type(exc).__name__}:{exc}") from exc
        run = dict(started.get("run") or {})
        run_id = str(run.get("run_id") or "").strip()
        if not run_id:
            raise RuntimeError(f"RUN_ID_MISSING:session_id={session_id}")
        return session_id, run_id

    def run(self) -> int:
        try:
            certification = self.api.get_json("/api/certification/windows")
        except Exception as exc:
            return self._fail(f"CERTIFICATION_STATUS_ERROR:{type(exc).__name__}:{exc}", code=5)
        if certification.get("ready") is not True:
            blockers = ",".join(str(x) for x in certification.get("blockers") or ())
            self._print(f"CAMPAIGN=BLOCKED blockers={blockers or 'WINDOWS_CERTIFICATION_NOT_READY'}")
            return 5

        try:
            session_id, run_id = self._resolve_or_launch_run()
        except Exception as exc:
            return self._fail(str(exc))

        self._print(f"CAMPAIGN_CERTIFICATION_SESSION_ID={session_id}")
        self._print(f"CAMPAIGN_CERTIFICATION_RUN_ID={run_id}")
        deadline = time.monotonic() + self.run_timeout_seconds
        seen = 0
        last: dict[str, Any] = {}
        while time.monotonic() <= deadline:
            try:
                last = self.api.get_json("/api/runs/" + quote(run_id, safe=""))
            except Exception as exc:
                return self._fail(f"RUN_STATUS_ERROR:{type(exc).__name__}:{exc}")
            logs = [str(x) for x in (last.get("logs") or ())]
            for line in logs[seen:]:
                self._print(line)
            seen = len(logs)
            state = str(last.get("state") or "")
            if state == "COMPLETED":
                # campaign_runtime.py uses ANKA_EXPLICIT_SUCCESS and can only
                # complete after the frozen SessionPlan's terminal success
                # condition has been declared by the worker.
                script_name = str(last.get("script_name") or self.SCRIPT)
                if script_name and script_name != self.SCRIPT:
                    return self._fail(f"UNEXPECTED_CAMPAIGN_WORKER:{script_name}")
                self._print("CAMPAIGN_CERTIFICATION=PASSED")
                self._export_debug(success=True)
                return 0
            if state in {"FAILED", "STOPPED"}:
                error = str(last.get("error") or "")
                return self._fail(f"RUN_{state}:{error}")
            self.sleep(self.poll_seconds)
        return self._fail("RUN_TIMEOUT")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run and monitor the currently applied ANKA campaign through the normal control plane"
    )
    parser.add_argument("--config", type=Path, default=Path("config.yaml"))
    parser.add_argument("--platform-url", default=None, help="advanced override; defaults to config.web host/port")
    parser.add_argument("--runtime-directory", type=Path, default=Path("runtime"))
    parser.add_argument("--session-id", default=None)
    return parser


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    return WindowsCampaignRunner(
        platform_url=args.platform_url or resolve_control_plane_endpoint(args.config).base_url,
        runtime_directory=args.runtime_directory,
        session_id=args.session_id,
    ).run()


if __name__ == "__main__":
    raise SystemExit(main())

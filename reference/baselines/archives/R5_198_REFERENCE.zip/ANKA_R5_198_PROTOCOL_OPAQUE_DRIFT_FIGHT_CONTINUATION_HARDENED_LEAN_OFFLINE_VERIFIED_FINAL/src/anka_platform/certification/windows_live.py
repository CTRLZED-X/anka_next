from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

REQUIRED_CERTIFICATION_STAGES: tuple[str, ...] = (
    "PASSIVE_R4",
    "WORLD_LOOP",
    "SINGLE_FIGHT",
)


@dataclass(frozen=True, slots=True)
class WindowsCertificateValidation:
    ready: bool
    blockers: tuple[str, ...]
    detail: dict[str, Any]


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _required_account_identities(party_preflight: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    accounts = party_preflight.get("accounts") or {}
    result: dict[str, dict[str, Any]] = {}
    if not isinstance(accounts, Mapping):
        return result
    for raw_account_id, raw in accounts.items():
        account = raw if isinstance(raw, Mapping) else {}
        if account.get("required") is not True:
            continue
        account_id = str(raw_account_id)
        result[account_id] = {
            "client_instance_id": account.get("client_instance_id"),
            "pid": account.get("pid"),
            "process_creation_time": account.get("process_creation_time"),
        }
    return result


class WindowsLiveCertificateStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).resolve()

    def load(self) -> dict[str, Any] | None:
        if not self.path.is_file():
            return None
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return payload if isinstance(payload, dict) else None

    def write_pass(
        self,
        *,
        config_path: str | Path,
        party_preflight: Mapping[str, Any],
        platform_version: str,
        stages: Mapping[str, Mapping[str, Any]],
        extra: Mapping[str, Any] | None = None,
    ) -> Path:
        config = Path(config_path).resolve()
        normalized_stages = {str(k): dict(v) for k, v in stages.items()}
        payload: dict[str, Any] = {
            "schema_version": 1,
            "status": "PASSED",
            "issued_at_utc": datetime.now(timezone.utc).isoformat(),
            "platform_version": str(platform_version),
            "config_sha256": _sha256_file(config),
            "required_accounts": _required_account_identities(party_preflight),
            "stages": normalized_stages,
        }
        if extra:
            payload["extra"] = dict(extra)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        return self.path


def validate_windows_certificate(
    certificate_path: str | Path,
    *,
    config_path: str | Path,
    party_preflight: Mapping[str, Any],
    platform_version: str,
) -> WindowsCertificateValidation:
    store = WindowsLiveCertificateStore(certificate_path)
    certificate = store.load()
    blockers: list[str] = []
    if certificate is None:
        blockers.append("WINDOWS_CERTIFICATE_MISSING")
        return WindowsCertificateValidation(False, tuple(blockers), {"certificate": None})

    if certificate.get("status") != "PASSED":
        blockers.append("WINDOWS_CERTIFICATE_NOT_PASSED")
    if str(certificate.get("platform_version") or "") != str(platform_version):
        blockers.append("WINDOWS_CERTIFICATE_PLATFORM_VERSION_CHANGED")

    config = Path(config_path).resolve()
    try:
        current_config_sha = _sha256_file(config)
    except OSError:
        current_config_sha = None
        blockers.append("WINDOWS_CERTIFICATE_CONFIG_UNAVAILABLE")
    if current_config_sha is not None and certificate.get("config_sha256") != current_config_sha:
        blockers.append("WINDOWS_CERTIFICATE_CONFIG_CHANGED")

    if party_preflight.get("ready") is not True:
        blockers.append("WINDOWS_CERTIFICATE_LIVE_PREFLIGHT_NOT_READY")

    current_identities = _required_account_identities(party_preflight)
    certified_identities = certificate.get("required_accounts") or {}
    if not isinstance(certified_identities, Mapping):
        blockers.append("WINDOWS_CERTIFICATE_ACCOUNT_IDENTITIES_INVALID")
        certified_identities = {}
    for account_id, current in current_identities.items():
        certified = certified_identities.get(account_id)
        if not isinstance(certified, Mapping) or any(
            certified.get(key) != current.get(key)
            for key in ("client_instance_id", "pid", "process_creation_time")
        ):
            blockers.append(f"WINDOWS_CERTIFICATE_ACCOUNT_IDENTITY_CHANGED:{account_id}")
    for account_id in certified_identities:
        if account_id not in current_identities:
            blockers.append(f"WINDOWS_CERTIFICATE_ACCOUNT_MISSING:{account_id}")

    stages = certificate.get("stages") or {}
    if not isinstance(stages, Mapping):
        stages = {}
    for stage in REQUIRED_CERTIFICATION_STAGES:
        record = stages.get(stage)
        if not isinstance(record, Mapping) or str(record.get("status")) != "PASS":
            blockers.append(f"WINDOWS_CERTIFICATE_STAGE_NOT_PASSED:{stage}")

    blockers = list(dict.fromkeys(blockers))
    return WindowsCertificateValidation(
        ready=not blockers,
        blockers=tuple(blockers),
        detail={
            "certificate": certificate,
            "current_required_accounts": current_identities,
            "current_config_sha256": current_config_sha,
        },
    )

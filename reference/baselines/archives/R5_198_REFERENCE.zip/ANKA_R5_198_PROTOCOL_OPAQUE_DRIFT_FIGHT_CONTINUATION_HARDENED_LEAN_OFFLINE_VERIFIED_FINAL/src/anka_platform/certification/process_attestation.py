from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

_REQUIRED_IDENTITY_FIELDS = ("client_instance_id", "pid", "process_creation_time")


def _as_mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _required_accounts(party_preflight: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    accounts = _as_mapping(party_preflight.get("accounts"))
    return {
        str(account_id): _as_mapping(payload)
        for account_id, payload in accounts.items()
        if _as_mapping(payload).get("required") is True
    }


def _identity_payload(account: Mapping[str, Any]) -> dict[str, Any]:
    return {field: account.get(field) for field in _REQUIRED_IDENTITY_FIELDS}


def _identity_complete(identity: Mapping[str, Any]) -> bool:
    return all(identity.get(field) not in (None, "") for field in _REQUIRED_IDENTITY_FIELDS)


def _signature(generation: Any, accounts: Mapping[str, Mapping[str, Any]]) -> str:
    payload = {
        "generation": generation,
        "accounts": {account_id: dict(identity) for account_id, identity in sorted(accounts.items())},
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()




def _assess_identity_readiness(
    accounts: Mapping[str, Mapping[str, Any]],
    window_input_readiness: Mapping[str, Any],
) -> tuple[bool, list[str], dict[str, dict[str, Any]]]:
    blockers: list[str] = []
    identities: dict[str, dict[str, Any]] = {}
    if not accounts:
        blockers.append("REQUIRED_ACCOUNT_IDENTITIES_UNAVAILABLE")
    input_accounts = _as_mapping(window_input_readiness.get("accounts"))
    for account_id, account in sorted(accounts.items()):
        identity = _identity_payload(account)
        identities[account_id] = identity
        if not _identity_complete(identity):
            blockers.append(f"ACCOUNT_IDENTITY_INCOMPLETE:{account_id}")
        runtime_health = _as_mapping(account.get("runtime_health"))
        health_window = _as_mapping(runtime_health.get("window"))
        if health_window.get("status") != "WINDOW_IDENTITY_VERIFIED":
            blockers.append(f"WINDOW_IDENTITY_NOT_VERIFIED:{account_id}")
        else:
            for field in _REQUIRED_IDENTITY_FIELDS:
                if health_window.get(field) != identity.get(field):
                    blockers.append(f"WINDOW_IDENTITY_MISMATCH:{account_id}:{field}")
        input_status = _as_mapping(input_accounts.get(account_id))
        if input_status.get("ready") is not True:
            code = str(input_status.get("failure_code") or input_status.get("code") or input_status.get("status") or "NOT_READY")
            blockers.append(f"WINDOW_INPUT_NOT_READY:{account_id}:{code}")
    if window_input_readiness.get("ready") is not True and not any(
        item.startswith("WINDOW_INPUT_NOT_READY:") for item in blockers
    ):
        blockers.append("WINDOW_INPUT_NOT_READY")
    blockers = list(dict.fromkeys(blockers))
    return (not blockers), blockers, identities

def assess_process_attestation(
    party_preflight: Mapping[str, Any] | None,
    window_input_readiness: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Assess the exact current Dofus process generation without sending input.

    This is deliberately cheaper than the legacy deep live-certification campaign.
    It is recomputed from current party/window generations so Dofus can be opened or
    restarted after a SessionPlan is applied without requiring the operator to run a
    separate certification command.  Launch remains fail-closed until the current
    required accounts, runtime, projection/capture health, and no-click window/input
    readiness are all valid.
    """

    party = _as_mapping(party_preflight)
    window = _as_mapping(window_input_readiness)
    waiting_for = [str(item) for item in (party.get("missing_required") or ()) if str(item).strip()]
    accounts = _required_accounts(party)
    identity_ready, identity_blockers, identities = _assess_identity_readiness(accounts, window)

    if party.get("ready") is not True:
        party_blockers = [str(item).strip() for item in (party.get("blockers") or ()) if str(item).strip()]
        fault = _as_mapping(party.get("generation_fault"))
        fault_code = str(fault.get("code") or "").strip()
        if waiting_for:
            status = "WAITING_FOR_CLIENTS"
            reason = "REQUIRED_CLIENTS_MISSING"
            blockers = ["PROCESS_ATTESTATION_WAITING_FOR_CLIENTS"]
        elif fault_code in {"PARTY_GENERATION_CHANGED", "PARTY_GENERATION_INVALIDATED"}:
            status = "RECONCILING"
            reason = fault_code
            blockers = ["PROCESS_ATTESTATION_RECONCILING"]
        elif any(token in {"PARTY_GENERATION_RECONCILING", "PARTY_RUNTIME_NOT_READY"} for token in party_blockers):
            status = "RECONCILING"
            reason = next((token for token in party_blockers if token in {"PARTY_GENERATION_RECONCILING", "PARTY_RUNTIME_NOT_READY"}), "PARTY_RECONCILING")
            blockers = ["PROCESS_ATTESTATION_RECONCILING"]
        elif party_blockers and all(
            token.split(":", 1)[-1] in {"CANONICAL_MAP_UNKNOWN", "PROJECTION_SYNC_NO_OBSERVATION"}
            for token in party_blockers
        ):
            status = "CONVERGING"
            reason = "WORLD_STATE_CONVERGENCE_PENDING"
            blockers = ["PROCESS_ATTESTATION_CANONICAL_MAP_CONVERGENCE"]
        else:
            status = "BLOCKED"
            reason = fault_code or (party_blockers[0] if party_blockers else "PARTY_RUNTIME_NOT_READY")
            blockers = ["PROCESS_ATTESTATION_PARTY_BLOCKED"]
        blockers.extend(f"PARTY:{token}" for token in party_blockers)
        return {
            "ready": False,
            "status": status,
            "reason": reason,
            "affected_account_id": fault.get("account_id"),
            "generation": party.get("generation"),
            "waiting_for_accounts": waiting_for,
            "accounts": identities,
            "identity_ready": bool(identity_ready),
            "identity_blockers": list(identity_blockers),
            "world_state_ready": False,
            "signature": _signature(party.get("generation"), identities) if identities else None,
            "blockers": list(dict.fromkeys(blockers)),
            "mode": "AUTOMATIC_PROCESS_ATTESTATION",
        }

    blockers: list[str] = list(identity_blockers)
    for account_id, account in sorted(accounts.items()):
        projection = _as_mapping(account.get("projection"))
        if projection.get("ready") is not True:
            blockers.append(f"PROJECTION_NOT_READY:{account_id}")
        capture = _as_mapping(account.get("capture"))
        if capture.get("last_error") not in (None, ""):
            blockers.append(f"CAPTURE_ERROR:{account_id}")
    blockers = list(dict.fromkeys(blockers))
    ready = not blockers
    return {
        "ready": ready,
        "status": "READY" if ready else "BLOCKED",
        "generation": party.get("generation"),
        "waiting_for_accounts": [],
        "accounts": identities,
        "identity_ready": bool(identity_ready),
        "identity_blockers": list(identity_blockers),
        "world_state_ready": bool(party.get("ready") is True),
        "signature": _signature(party.get("generation"), identities) if identities else None,
        "blockers": blockers,
        "mode": "AUTOMATIC_PROCESS_ATTESTATION",
    }

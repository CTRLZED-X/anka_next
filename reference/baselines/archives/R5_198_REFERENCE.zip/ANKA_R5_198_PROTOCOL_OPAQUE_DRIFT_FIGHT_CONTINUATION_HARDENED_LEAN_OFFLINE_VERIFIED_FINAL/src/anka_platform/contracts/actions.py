from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ActionBase(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    action_id: str = Field(min_length=1)
    expected_state_revision: int = Field(ge=0)


class WorldMoveToCellAction(ActionBase):
    kind: Literal["world_move_to_cell"] = "world_move_to_cell"
    map_id: int
    target_cell_id: int


class CastSpellAction(ActionBase):
    kind: Literal["cast_spell"] = "cast_spell"
    actor_id: int
    spell_id: int
    target_cell_id: int


class FightMoveToCellAction(ActionBase):
    kind: Literal["fight_move_to_cell"] = "fight_move_to_cell"
    actor_id: int
    target_cell_id: int


class EndTurnAction(ActionBase):
    kind: Literal["end_turn"] = "end_turn"
    actor_id: int

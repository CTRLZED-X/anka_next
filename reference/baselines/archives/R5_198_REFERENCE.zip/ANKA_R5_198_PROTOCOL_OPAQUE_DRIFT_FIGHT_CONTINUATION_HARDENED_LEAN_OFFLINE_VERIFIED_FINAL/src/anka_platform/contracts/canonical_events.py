from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, model_validator

from anka_platform.contracts.common import SemanticValue
from anka_platform.contracts.versions import ContractVersion


class EventIdentity(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    event_id: str = Field(min_length=1)
    sequence: int = Field(ge=0)


class EventProvenance(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    adapter_id: str = Field(min_length=1)
    protocol_build: str = Field(min_length=1)
    source: Literal["live", "replay"]
    capture_id: str | None = None
    account_id: str | None = None
    client_instance_id: str | None = None
    flow_id: str | None = None
    packet_number: int | None = None
    frame_number: int | None = None
    wire_name: str | None = None
    wire_action_id: int | None = None
    confidence: str | None = None
    payload_sha256: str | None = None


class WorldMapObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["world_map_observed"] = "world_map_observed"
    map_id: SemanticValue[int]
    world_x: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    world_y: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    player_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    player_cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class WorldActorPositionObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["world_actor_position_observed"] = "world_actor_position_observed"
    actor_id: int
    map_id: SemanticValue[int]
    cell_id: SemanticValue[int]
    path: tuple[int, ...] = ()
    actor_kind: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)




class ObservedMonsterMember(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    monster_id: int
    level: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class ObservedMonsterGroup(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    group_id: int
    cell_id: SemanticValue[int]
    members: tuple[ObservedMonsterMember, ...] = ()
    # Backward-compatible identity list. `members` is the canonical relational form.
    member_ids: tuple[int, ...] = ()

    @model_validator(mode="before")
    @classmethod
    def _normalize_members(cls, data):
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        members = tuple(normalized.get("members") or ())
        member_ids = tuple(int(value) for value in (normalized.get("member_ids") or ()))
        if members and not member_ids:
            derived = []
            for member in members:
                if isinstance(member, ObservedMonsterMember):
                    derived.append(int(member.monster_id))
                elif isinstance(member, dict) and "monster_id" in member:
                    derived.append(int(member["monster_id"]))
            normalized["member_ids"] = tuple(derived)
        elif member_ids and not members:
            normalized["members"] = tuple({"monster_id": value} for value in member_ids)
        elif members and member_ids:
            derived = tuple(
                int(member.monster_id) if isinstance(member, ObservedMonsterMember) else int(member["monster_id"])
                for member in members
            )
            if derived != member_ids:
                raise ValueError("monster group members and member_ids disagree")
        return normalized


class MonsterGroupSnapshotObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["monster_group_snapshot_observed"] = "monster_group_snapshot_observed"
    map_id: SemanticValue[int]
    groups: tuple[ObservedMonsterGroup, ...] = ()
    complete_snapshot: bool = True


class LocalPlayerObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["local_player_observed"] = "local_player_observed"
    actor_id: int
    # Preserve the authority that produced local identity.  R4 can observe a
    # foreign actor in the JPQ->JPW transition slot, so a naked actor id is not
    # sufficient to decide whether combat may bind this account to that fighter.
    identity_source: str = "LEGACY_UNSPECIFIED"
    identity_rank: int = Field(default=20, ge=0)


class SpellCooldownEntry(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    spell_id: int
    remaining_turns: int = Field(ge=0)


class SpellCooldownSnapshotObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["spell_cooldown_snapshot_observed"] = "spell_cooldown_snapshot_observed"
    actor_id: int
    cooldowns: tuple[SpellCooldownEntry, ...] = ()
    complete_snapshot: bool = True


class MonsterGroupObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["monster_group_observed"] = "monster_group_observed"
    group_id: int
    map_id: SemanticValue[int]
    cell_id: SemanticValue[int]
    members: tuple[ObservedMonsterMember, ...] = ()
    member_ids: tuple[int, ...] = ()

    @model_validator(mode="before")
    @classmethod
    def _normalize_members(cls, data):
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        members = tuple(normalized.get("members") or ())
        member_ids = tuple(int(value) for value in (normalized.get("member_ids") or ()))
        if members and not member_ids:
            derived = []
            for member in members:
                if isinstance(member, ObservedMonsterMember):
                    derived.append(int(member.monster_id))
                elif isinstance(member, dict) and "monster_id" in member:
                    derived.append(int(member["monster_id"]))
            normalized["member_ids"] = tuple(derived)
        elif member_ids and not members:
            normalized["members"] = tuple({"monster_id": value} for value in member_ids)
        elif members and member_ids:
            derived = tuple(
                int(member.monster_id) if isinstance(member, ObservedMonsterMember) else int(member["monster_id"])
                for member in members
            )
            if derived != member_ids:
                raise ValueError("monster group members and member_ids disagree")
        return normalized


class FightLifecycleObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_lifecycle_observed"] = "fight_lifecycle_observed"
    fight_id: SemanticValue[int]
    phase: Literal["STARTED", "PLACEMENT", "ACTIVE", "ENDED"]
    map_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    fight_type: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    reason: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    fight_instance_id: int | None = None
    origin_world_entity_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    initiating_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class FightActorObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_actor_observed"] = "fight_actor_observed"
    actor_id: int
    team_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    alive: SemanticValue[bool] = Field(default_factory=SemanticValue[bool].not_observed)
    # Extensible identity semantics. Current adapters must leave these unobserved
    # unless the packet evidence proves them.
    actor_type: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    static_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    level: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class FightActorRosterObserved(BaseModel):
    """Observed fighter membership/occupancy boundary for one fight generation.

    ``complete_snapshot`` is deliberately explicit. Per-actor observations
    accumulate over time, while some wire messages (notably R4 ``kkr``) are
    partial occupancy batches whose omissions are not negative evidence. Only
    a protocol source independently certified as complete may set this flag.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_actor_roster_observed"] = "fight_actor_roster_observed"
    actor_ids: tuple[int, ...]
    complete_snapshot: bool
    source: str = Field(min_length=1)


class FightStatsObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_stats_observed"] = "fight_stats_observed"
    actor_id: int
    hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    max_hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    # Cumulative max-HP already lost to erosion during the current fight. This
    # is distinct from the current erosion percentage characteristic. Adapters
    # should publish it only when a fresh-fight zero baseline or an absolute
    # value is authoritative.
    eroded_hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    ap: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    mp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    range_bonus: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class FightTurnObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_turn_observed"] = "fight_turn_observed"
    round: int = Field(ge=0)
    turn_index: int = Field(ge=0)
    active_actor_id: SemanticValue[int]


class ActorStatesObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["actor_states_observed"] = "actor_states_observed"
    actor_id: int
    state_ids: tuple[int, ...]
    complete_snapshot: bool


class SpellCastObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["spell_cast_observed"] = "spell_cast_observed"
    caster_actor_id: int
    spell_id: int
    target_cell_id: SemanticValue[int]
    grade_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class DisplacementObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["displacement_observed"] = "displacement_observed"
    actor_id: int
    from_cell_id: SemanticValue[int]
    to_cell_id: SemanticValue[int]


class HealthChangedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["health_changed_observed"] = "health_changed_observed"
    actor_id: int
    previous_hp: SemanticValue[int]
    current_hp: SemanticValue[int]


class ActorDeathObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["actor_death_observed"] = "actor_death_observed"
    actor_id: int



class ObservedEffect(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    effect_id: int
    effect_instance_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    source_spell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    state_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    source_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    remaining_turns: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    stack_count: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class ActorEffectsObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["actor_effects_observed"] = "actor_effects_observed"
    actor_id: int
    effects: tuple[ObservedEffect, ...]
    complete_snapshot: bool


class FightMovementObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["fight_movement_observed"] = "fight_movement_observed"
    actor_id: int
    from_cell_id: SemanticValue[int]
    to_cell_id: SemanticValue[int]
    path: tuple[int, ...] = ()


class ResourceChangedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["resource_changed_observed"] = "resource_changed_observed"
    actor_id: int
    resource: Literal["AP", "MP", "RANGE"]
    previous_value: SemanticValue[int]
    current_value: SemanticValue[int]
    delta: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class VitalityChangedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["vitality_changed_observed"] = "vitality_changed_observed"
    actor_id: int
    change_kind: Literal["DAMAGE", "HEAL"]
    source_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    amount: SemanticValue[int]
    max_hp_loss: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    previous_hp: SemanticValue[int]
    current_hp: SemanticValue[int]


class SummonCreatedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    kind: Literal["summon_created_observed"] = "summon_created_observed"
    summon_actor_id: int
    summoner_actor_id: int
    cell_id: SemanticValue[int]
    creature_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    creature_grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class MonsterGroupMovedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["monster_group_moved_observed"] = "monster_group_moved_observed"
    group_id: int
    map_id: SemanticValue[int]
    cell_id: SemanticValue[int]
    path: tuple[int, ...] = ()


class WorldEntityRemovedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["world_entity_removed_observed"] = "world_entity_removed_observed"
    entity_id: int


class FightRoundObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_round_observed"] = "fight_round_observed"
    round: int = Field(ge=0)


class FightTurnEndedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_turn_ended_observed"] = "fight_turn_ended_observed"
    actor_id: int


class FightDiscoveryObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_discovery_observed"] = "fight_discovery_observed"
    fight_instance_id: int
    leader_actor_id: int
    origin_world_entity_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    team_position_cells: tuple[int, ...] = ()
    presentation_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class FightJoinPresentationObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_join_presentation_observed"] = "fight_join_presentation_observed"
    fight_instance_id: int
    presentation_id: int
    leader_actor_id: int
    world_map_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    join_anchor_cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class FightJoinLifecycleObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_join_lifecycle_observed"] = "fight_join_lifecycle_observed"
    fight_instance_id: int
    joinable: bool
    phase: Literal["PRESENTED", "BOUNDARY_CLOSED"]
    presentation_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class LegalPlacementCellsObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["legal_placement_cells_observed"] = "legal_placement_cells_observed"
    defender_cells: tuple[int, ...] = ()
    challenger_cells: tuple[int, ...] = ()
    complete_snapshot: bool = True


class FighterReadyObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fighter_ready_observed"] = "fighter_ready_observed"
    actor_id: int
    ready: bool


class FightTurnOrderObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_turn_order_observed"] = "fight_turn_order_observed"
    actor_ids: tuple[int, ...] = ()
    complete_snapshot: bool = True


class SideRelationObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["side_relation_observed"] = "side_relation_observed"
    actor_id: int
    relation: Literal["ALLY_SIDE", "ENEMY_SIDE", "UNKNOWN"]


class SummonCountObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["summon_count_observed"] = "summon_count_observed"
    actor_id: int
    count: int = Field(ge=0)


class SpellLoadoutObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["spell_loadout_observed"] = "spell_loadout_observed"
    actor_id: int
    spell_ids: tuple[int, ...] = ()
    slot_numbers: tuple[int, ...] = ()
    complete_snapshot: bool = True


class SpellPropertyModifierObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["spell_property_modifier_observed"] = "spell_property_modifier_observed"
    actor_id: int
    spell_id: int
    property_code: int
    raw_value: int | None = None
    removed: bool = False


class WorldTransitionDirectionObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["world_transition_direction_observed"] = "world_transition_direction_observed"
    actor_id: int
    direction: Literal["RIGHT", "BOTTOM", "LEFT", "TOP"]


class FightMapContextObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["fight_map_context_observed"] = "fight_map_context_observed"
    map_id: int
    world_x: int | None = None
    world_y: int | None = None


class ChallengeLifecycleObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["challenge_lifecycle_observed"] = "challenge_lifecycle_observed"
    challenge_id: int
    phase: Literal["OFFERED", "ACTIVATED", "TARGET_UPDATED", "FAILED_OR_INVALIDATED"]
    runtime_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    target_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    target_cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class ActorLookObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["actor_look_observed"] = "actor_look_observed"
    actor_id: int
    raw_payload_sha256: str




class ActorCharacteristicObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["actor_characteristic_observed"] = "actor_characteristic_observed"
    actor_id: int
    characteristic_id: int
    total_value: int

class ShieldChangedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["shield_changed_observed"] = "shield_changed_observed"
    actor_id: int
    current_shield: int = Field(ge=0)


class ShieldAbsorbedObserved(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    kind: Literal["shield_absorbed_observed"] = "shield_absorbed_observed"
    actor_id: int
    amount: int = Field(ge=0)
    source_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


CanonicalEvent = Annotated[
    Union[
        WorldMapObserved,
        WorldActorPositionObserved,
        MonsterGroupObserved,
        MonsterGroupSnapshotObserved,
        LocalPlayerObserved,
        SpellCooldownSnapshotObserved,
        FightLifecycleObserved,
        FightActorObserved,
        FightActorRosterObserved,
        FightStatsObserved,
        FightTurnObserved,
        ActorStatesObserved,
        SpellCastObserved,
        DisplacementObserved,
        HealthChangedObserved,
        ActorDeathObserved,
        ActorEffectsObserved,
        FightMovementObserved,
        ResourceChangedObserved,
        VitalityChangedObserved,
        SummonCreatedObserved,
        MonsterGroupMovedObserved,
        WorldEntityRemovedObserved,
        FightRoundObserved,
        FightTurnEndedObserved,
        FightDiscoveryObserved,
        FightJoinPresentationObserved,
        FightJoinLifecycleObserved,
        LegalPlacementCellsObserved,
        FighterReadyObserved,
        FightTurnOrderObserved,
        SideRelationObserved,
        SummonCountObserved,
        SpellLoadoutObserved,
        SpellPropertyModifierObserved,
        WorldTransitionDirectionObserved,
        FightMapContextObserved,
        ChallengeLifecycleObserved,
        ActorLookObserved,
        ActorCharacteristicObserved,
        ShieldChangedObserved,
        ShieldAbsorbedObserved,
    ],
    Field(discriminator="kind"),
]
_EVENT_ADAPTER = TypeAdapter(CanonicalEvent)


class CanonicalEventEnvelope(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    contract: ContractVersion
    identity: EventIdentity
    provenance: EventProvenance
    event: CanonicalEvent


def parse_canonical_event(payload: object) -> CanonicalEventEnvelope:
    return CanonicalEventEnvelope.model_validate(payload)

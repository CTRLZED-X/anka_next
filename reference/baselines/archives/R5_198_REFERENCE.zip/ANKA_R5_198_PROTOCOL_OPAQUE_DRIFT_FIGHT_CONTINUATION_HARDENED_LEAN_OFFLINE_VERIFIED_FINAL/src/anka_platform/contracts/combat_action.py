from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class ImpactRequirement:
    """One actor/effect obligation that justified a planned combat action.

    The contract is neutral: deterministic planning can create it and latest-state
    admission/execution can consume it without importing the FightAI package.
    """

    actor_id: int
    effect_orders: tuple[int, ...] = ()
    role: str = "AFFECTED"

    def fingerprint(self) -> tuple:
        return (int(self.actor_id), tuple(int(v) for v in self.effect_orders), str(self.role))

    def to_payload(self) -> dict[str, object]:
        return {
            "actor_id": int(self.actor_id),
            "effect_orders": [int(v) for v in self.effect_orders],
            "role": str(self.role),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "ImpactRequirement":
        if not isinstance(payload, Mapping):
            raise ValueError("impact requirement must be a mapping")
        orders = payload.get("effect_orders", [])
        if not isinstance(orders, list):
            raise ValueError("impact requirement effect_orders must be a list")
        actor_id = payload.get("actor_id")
        if isinstance(actor_id, bool) or not isinstance(actor_id, int):
            raise ValueError("impact requirement actor_id must be an integer")
        role = payload.get("role", "AFFECTED")
        if not isinstance(role, str) or not role.strip():
            raise ValueError("impact requirement role must be a non-empty string")
        try:
            normalized_orders = tuple(int(value) for value in orders)
        except (TypeError, ValueError) as exc:
            raise ValueError("impact requirement effect_orders must contain integers") from exc
        return cls(actor_id=int(actor_id), effect_orders=normalized_orders, role=str(role))


@dataclass(frozen=True, slots=True)
class ActionIntent:
    """Semantic impact contract shared by planner, admission and execution."""

    required_impacts: tuple[ImpactRequirement, ...] = ()

    def fingerprint(self) -> tuple:
        return tuple(item.fingerprint() for item in self.required_impacts)

    def to_payload(self) -> dict[str, object]:
        return {"required_impacts": [item.to_payload() for item in self.required_impacts]}

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "ActionIntent":
        if not isinstance(payload, Mapping):
            raise ValueError("action_intent must be a mapping")
        required = payload.get("required_impacts")
        if not isinstance(required, list):
            raise ValueError("action_intent.required_impacts must be a list")
        return cls(required_impacts=tuple(ImpactRequirement.from_payload(item) for item in required))

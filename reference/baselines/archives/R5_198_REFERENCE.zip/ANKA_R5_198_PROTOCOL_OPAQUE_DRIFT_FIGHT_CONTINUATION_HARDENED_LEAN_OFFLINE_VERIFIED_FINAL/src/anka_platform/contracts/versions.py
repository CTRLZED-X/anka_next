from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator


CANONICAL_CONTRACT_MAJOR = 1
CANONICAL_CONTRACT_MINOR = 0


class ContractVersion(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    major: int = Field(ge=1)
    minor: int = Field(ge=0)

    @model_validator(mode="after")
    def _supported_major(self) -> "ContractVersion":
        if self.major != CANONICAL_CONTRACT_MAJOR:
            raise ValueError(
                f"unsupported canonical contract major {self.major}; "
                f"expected {CANONICAL_CONTRACT_MAJOR}"
            )
        return self

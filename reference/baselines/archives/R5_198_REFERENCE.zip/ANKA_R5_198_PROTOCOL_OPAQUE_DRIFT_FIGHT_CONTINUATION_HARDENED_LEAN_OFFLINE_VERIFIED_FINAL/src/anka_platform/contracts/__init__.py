"""Stable ANKA consumer-facing contracts."""

from anka_platform.contracts.correlation import CorrelationContext, correlation_mapping
from anka_platform.contracts.failure_registry import (
    ControlDisposition,
    FailureDomain,
    FailureSeverity,
    FailureSpec,
    FailureTerminality,
    RetryDisposition,
    failure_spec,
    known_failure_codes,
    require_failure_spec,
)
from anka_platform.contracts.versions import CANONICAL_CONTRACT_MAJOR, CANONICAL_CONTRACT_MINOR

__all__ = [
    "CANONICAL_CONTRACT_MAJOR",
    "CANONICAL_CONTRACT_MINOR",
    "ControlDisposition",
    "CorrelationContext",
    "FailureDomain",
    "FailureSeverity",
    "FailureSpec",
    "FailureTerminality",
    "RetryDisposition",
    "correlation_mapping",
    "failure_spec",
    "known_failure_codes",
    "require_failure_spec",
]

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from anka_platform.contracts.common import SemanticValue
from anka_platform.contracts.versions import ContractVersion


class SnapshotCompleteness(str, Enum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    UNKNOWN = "UNKNOWN"


class CanonicalMonsterMemberSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    monster_id: int
    level: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class CanonicalMonsterGroupSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    group_id: int
    cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    members: tuple[CanonicalMonsterMemberSnapshot, ...] = ()
    member_ids: tuple[int, ...] = ()

    @model_validator(mode="before")
    @classmethod
    def _normalize_members(cls, data):
        if not isinstance(data, dict):
            return data
        normalized = dict(data)
        members = tuple(normalized.get("members") or ())
        member_ids = tuple(int(value) for value in (normalized.get("member_ids") or ()))
        if members and not member_ids:
            derived = []
            for member in members:
                if isinstance(member, CanonicalMonsterMemberSnapshot):
                    derived.append(int(member.monster_id))
                elif isinstance(member, dict) and "monster_id" in member:
                    derived.append(int(member["monster_id"]))
            normalized["member_ids"] = tuple(derived)
        elif member_ids and not members:
            normalized["members"] = tuple({"monster_id": value} for value in member_ids)
        elif members and member_ids:
            derived = tuple(
                int(member.monster_id) if isinstance(member, CanonicalMonsterMemberSnapshot) else int(member["monster_id"])
                for member in members
            )
            if derived != member_ids:
                raise ValueError("canonical monster members and member_ids disagree")
        return normalized


class CanonicalEffectSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    effect_id: int
    effect_instance_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    source_spell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    state_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    source_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    remaining_turns: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    stack_count: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)




class CanonicalCharacteristicSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    characteristic_id: int
    total_value: int

class CanonicalCooldownSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    spell_id: int
    remaining_turns: int = Field(ge=0)


class CanonicalSpellPropertyModifierSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    spell_id: int
    property_code: int
    raw_value: int


class CanonicalChallengeSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")
    challenge_id: int
    phase: str
    runtime_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    target_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    target_cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)


class CanonicalActorObservationRevisions(BaseModel):
    """Canonical sequence where each decision-critical actor field was last observed.

    These are evidence watermarks only. They never predict a value; they let
    runtime code prove that a live field was refreshed after a physical action.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    team_revision: int = Field(default=0, ge=0)
    cell_revision: int = Field(default=0, ge=0)
    hp_revision: int = Field(default=0, ge=0)
    max_hp_revision: int = Field(default=0, ge=0)
    ap_revision: int = Field(default=0, ge=0)
    mp_revision: int = Field(default=0, ge=0)
    range_bonus_revision: int = Field(default=0, ge=0)
    # Resource-specific evidence watermarks. Generic FightStats snapshots update
    # the value watermarks above, while explicit ResourceChanged events update
    # both. Execution uses these to distinguish a causally observed spend from a
    # later stale/repeated stats snapshot that happens to carry the old value.
    ap_resource_revision: int = Field(default=0, ge=0)
    mp_resource_revision: int = Field(default=0, ge=0)
    range_resource_revision: int = Field(default=0, ge=0)
    alive_revision: int = Field(default=0, ge=0)
    states_revision: int = Field(default=0, ge=0)
    effects_revision: int = Field(default=0, ge=0)
    cooldowns_revision: int = Field(default=0, ge=0)
    characteristics_revision: int = Field(default=0, ge=0)
    summoner_revision: int = Field(default=0, ge=0)
    creature_revision: int = Field(default=0, ge=0)
    creature_grade_revision: int = Field(default=0, ge=0)
    actor_type_revision: int = Field(default=0, ge=0)
    static_id_revision: int = Field(default=0, ge=0)
    level_revision: int = Field(default=0, ge=0)
    grade_revision: int = Field(default=0, ge=0)
    ready_revision: int = Field(default=0, ge=0)
    side_relation_revision: int = Field(default=0, ge=0)
    summon_count_revision: int = Field(default=0, ge=0)
    loadout_revision: int = Field(default=0, ge=0)
    modifiers_revision: int = Field(default=0, ge=0)
    shield_revision: int = Field(default=0, ge=0)
    look_revision: int = Field(default=0, ge=0)


class CanonicalCastSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    caster_actor_id: int
    spell_id: int
    target_cell_id: SemanticValue[int]
    # Preserve actor identity at the exact observation moment. A target can move
    # later, so cell identity alone is insufficient for max-casts-per-target.
    target_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    grade_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    round: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    turn_index: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    observed_revision: int = Field(default=0, ge=0)


class CanonicalActorSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    actor_id: int
    team_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    max_hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    eroded_hp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    ap: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    mp: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    range_bonus: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    alive: SemanticValue[bool] = Field(default_factory=SemanticValue[bool].not_observed)
    actor_type: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    static_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    level: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    state_ids: tuple[int, ...] = ()
    states_complete: bool = False
    effects: tuple[CanonicalEffectSnapshot, ...] = ()
    effects_complete: bool = False
    cooldowns: tuple[CanonicalCooldownSnapshot, ...] = ()
    characteristics_total: tuple[CanonicalCharacteristicSnapshot, ...] = ()
    cooldowns_complete: bool = False
    summoner_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    creature_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    creature_grade: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    placement_ready: SemanticValue[bool] = Field(default_factory=SemanticValue[bool].not_observed)
    side_relation: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    summon_count: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    live_spell_loadout: tuple[int, ...] = ()
    live_spell_slots: tuple[int, ...] = ()
    spell_property_modifiers: tuple[CanonicalSpellPropertyModifierSnapshot, ...] = ()
    shield_points: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    look_payload_sha256: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    observed: CanonicalActorObservationRevisions = Field(default_factory=CanonicalActorObservationRevisions)

    @property
    def characteristics(self) -> tuple[CanonicalCharacteristicSnapshot, ...]:
        """Backward-compatible read-only alias for pre-R5.61 callers."""
        return self.characteristics_total


class CanonicalWorldSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    completeness: SnapshotCompleteness
    map_id: SemanticValue[int]
    world_x: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    world_y: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    player_cell_id: SemanticValue[int]
    player_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    monster_groups: tuple[CanonicalMonsterGroupSnapshot, ...] = ()
    monster_groups_complete: bool = False
    last_transition_direction: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    last_transition_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    last_transition_revision: int = Field(default=0, ge=0)


class CanonicalFightSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    present: bool
    fight_instance_id: int | None = None
    completeness: SnapshotCompleteness
    fight_id: SemanticValue[int]
    map_id: SemanticValue[int]
    phase: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    fight_type: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    round: SemanticValue[int]
    turn_index: SemanticValue[int]
    active_actor_id: SemanticValue[int]
    # Persistent world MapId captured at the fight-generation entry boundary.
    # This is deliberately separate from ``map_id`` (the semantic/tactical
    # fight MapId) and remains available to bind Mapuse geometry even when the
    # fight map has no standalone geometry definition.
    origin_world_map_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    origin_world_entity_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    initiating_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    coordinate_x: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    coordinate_y: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_fight_instance_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_leader_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_origin_world_entity_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_team_position_cells: tuple[int, ...] = ()
    discovered_presentation_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_world_map_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_join_anchor_cell_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    discovered_joinable: SemanticValue[bool] = Field(default_factory=SemanticValue[bool].not_observed)
    discovered_join_lifecycle: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    legal_placement_defender_cells: tuple[int, ...] = ()
    legal_placement_challenger_cells: tuple[int, ...] = ()
    turn_order: tuple[int, ...] = ()
    challenges: tuple[CanonicalChallengeSnapshot, ...] = ()
    actors: tuple[CanonicalActorSnapshot, ...] = ()
    # ``actors`` is an accumulated set of actor facts and is therefore not a
    # completeness authority.  These fields preserve the latest certified
    # packet-level roster boundary (R4 ``kkr`` today) for identity checks.
    actor_roster_ids: tuple[int, ...] = ()
    actor_roster_complete: bool = False
    actor_roster_observed_revision: int = Field(default=0, ge=0)
    actor_roster_source: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    confirmed_casts_this_turn: tuple[CanonicalCastSnapshot, ...] = ()
    confirmed_casts_this_global_turn: tuple[CanonicalCastSnapshot, ...] | None = None
    # Fight-persistent successful cast ledger. This is evidence, not prediction;
    # it survives turn boundaries so recast intervals can be derived even when a
    # newer live cooldown snapshot has not yet arrived.
    confirmed_casts_this_fight: tuple[CanonicalCastSnapshot, ...] = ()
    # Lifecycle watermarks used by combat-readiness.  AP/MP can be delivered
    # immediately before TURN_STARTED, so the valid turn-start resource window
    # begins at ACTIVE for the first turn and at the previous TURN_ENDED for
    # later handoffs.  These fields keep that causal boundary explicit instead
    # of inferring it from packet ordering at the execution layer.
    fight_active_observed_revision: int = Field(default=0, ge=0)
    last_turn_ended_revision: int = Field(default=0, ge=0)
    last_turn_ended_actor_id: int | None = None
    last_turn_ended_round: int | None = None
    last_turn_ended_turn_index: int | None = None
    # Turn-specific AP/MP freshness boundary. This is frozen when a genuine
    # semantic turn starts so an older TURN_ENDED watermark cannot accidentally
    # authorize resources after a missed handoff event.
    turn_resource_floor_revision: int = Field(default=0, ge=0)
    turn_resource_floor_basis: str | None = None
    turn_observed_revision: int = Field(default=0, ge=0)

    @classmethod
    def absent(cls) -> "CanonicalFightSnapshot":
        return cls(
            present=False,
            fight_instance_id=None,
            completeness=SnapshotCompleteness.COMPLETE,
            fight_id=SemanticValue.not_observed("no active fight"),
            map_id=SemanticValue.not_observed("no active fight"),
            phase=SemanticValue.not_observed("no active fight"),
            fight_type=SemanticValue.not_observed("no active fight"),
            round=SemanticValue.not_observed("no active fight"),
            turn_index=SemanticValue.not_observed("no active fight"),
            active_actor_id=SemanticValue.not_observed("no active fight"),
            actors=(),
            actor_roster_ids=(),
            actor_roster_complete=False,
            actor_roster_observed_revision=0,
            actor_roster_source=SemanticValue.not_observed("no active fight"),
            confirmed_casts_this_turn=(),
            confirmed_casts_this_global_turn=(),
            confirmed_casts_this_fight=(),
            fight_active_observed_revision=0,
            last_turn_ended_revision=0,
            last_turn_ended_actor_id=None,
            last_turn_ended_round=None,
            last_turn_ended_turn_index=None,
            turn_resource_floor_revision=0,
            turn_resource_floor_basis=None,
            turn_observed_revision=0,
        )


class CanonicalSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")

    contract: ContractVersion
    revision: int = Field(ge=0)
    world: CanonicalWorldSnapshot
    fight: CanonicalFightSnapshot
    # Ownership-grade account-local identity. New protocol decoders must not put
    # provisional correlation evidence in this field. Older snapshots remain
    # readable through the authority helper's legacy compatibility rule.
    local_player_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    local_player_identity_source: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    local_player_identity_rank: int = Field(default=0, ge=0)
    local_player_identity_observed_revision: int = Field(default=0, ge=0)
    # Diagnostic-only candidate identity. JPQ->JPW/JPO transition correlation is
    # stored here until stronger account-local evidence (JYM/JVA/KSN/KTH) exists.
    provisional_local_player_actor_id: SemanticValue[int] = Field(default_factory=SemanticValue[int].not_observed)
    provisional_local_player_identity_source: SemanticValue[str] = Field(default_factory=SemanticValue[str].not_observed)
    provisional_local_player_identity_rank: int = Field(default=0, ge=0)
    provisional_local_player_identity_observed_revision: int = Field(default=0, ge=0)

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ProjectionStatus(str, Enum):
    READY = "READY"
    NOT_READY = "NOT_READY"
    STALE = "STALE"
    MAP_MISMATCH = "MAP_MISMATCH"
    CELL_UNAVAILABLE = "CELL_UNAVAILABLE"
    BRIDGE_UNAVAILABLE = "BRIDGE_UNAVAILABLE"
    SOURCE_UNVERIFIED = "SOURCE_UNVERIFIED"
    OUTSIDE_VIEWPORT = "OUTSIDE_VIEWPORT"
    ENTITY_MISMATCH = "ENTITY_MISMATCH"


class ScreenPoint(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    x: int
    y: int


class ProjectionRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    map_id: int
    cell_id: int
    map_revision: int = Field(ge=0)
    runtime_generation: int = Field(ge=0)
    purpose: str = "ANKA_SCREEN_PROJECTION"
    target_entity_id: int | None = None


class ProjectionResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    status: ProjectionStatus
    map_id: int
    cell_id: int
    map_revision: int = Field(ge=0)
    runtime_generation: int = Field(ge=0)
    purpose: str = "ANKA_SCREEN_PROJECTION"
    target_entity_id: int | None = None
    entity_anchor_verified: bool = False
    entity_anchor_cell_id: int | None = None
    entity_nearest_cell_id: int | None = None
    exact_cell_anchor_verified: bool = False
    exact_cell_anchor_hierarchy: str | None = None
    exact_cell_anchor_planar_error: float | None = Field(default=None, ge=0)
    statically_walkable: bool | None = None
    projectable: bool | None = None
    verified_by_dofus_picker: bool | None = None
    verified_by_runtime_grid: bool | None = None
    coordinate_space: str | None = None
    source_client_width: int | None = Field(default=None, gt=0)
    source_client_height: int | None = Field(default=None, gt=0)
    point: ScreenPoint | None = None
    client_point: ScreenPoint | None = None
    safe_points: tuple[ScreenPoint, ...] = ()
    safe_client_points: tuple[ScreenPoint, ...] = ()
    target_hierarchy: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    diagnostics: dict | None = None
    detail: str | None = None

    @model_validator(mode="after")
    def _point_matches_status(self) -> "ProjectionResult":
        if self.status is ProjectionStatus.READY and (self.point is None or self.client_point is None):
            raise ValueError("READY projection requires paired screen/client points")
        if self.status is not ProjectionStatus.READY and (
            self.point is not None
            or self.client_point is not None
            or self.safe_points
            or self.safe_client_points
        ):
            raise ValueError("non-READY projection must not carry screen/client points")
        if len(self.safe_points) != len(self.safe_client_points):
            raise ValueError("safe screen/client point collections must have equal length")
        return self

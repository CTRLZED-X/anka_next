from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class CorrelationContext:
    """Immutable cross-layer identity for one causal operation.

    R5.175 introduces this as the typed boundary contract while retaining
    Mapping compatibility at legacy call sites.  Unknown metadata is preserved
    in ``extras`` so migration can be incremental without silently dropping
    evidence or authority tokens.
    """

    session_id: str | None = None
    run_id: str | None = None
    request_id: str | None = None
    script_name: str | None = None
    account_id: str | None = None
    operation_id: str | None = None
    runtime_generation: int | None = None
    extras: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    _KNOWN_KEYS = frozenset({
        "session_id", "run_id", "request_id", "script_name",
        "account_id", "operation_id", "runtime_generation",
    })

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | "CorrelationContext" | None) -> "CorrelationContext":
        if isinstance(value, cls):
            return value
        raw = dict(value or {})
        extras = {key: val for key, val in raw.items() if key not in cls._KNOWN_KEYS}
        generation = raw.get("runtime_generation")
        try:
            normalized_generation = int(generation) if generation is not None else None
        except (TypeError, ValueError):
            normalized_generation = None
        return cls(
            session_id=_text(raw.get("session_id")),
            run_id=_text(raw.get("run_id")),
            request_id=_text(raw.get("request_id")),
            script_name=_text(raw.get("script_name")),
            account_id=_text(raw.get("account_id")),
            operation_id=_text(raw.get("operation_id")),
            runtime_generation=normalized_generation,
            extras=MappingProxyType(extras),
        )

    @property
    def has_authority_identity(self) -> bool:
        return any(value not in (None, "") for value in (
            self.session_id, self.run_id, self.request_id, self.script_name,
        ))

    def as_dict(self) -> dict[str, Any]:
        result = dict(self.extras)
        for key in self._KNOWN_KEYS:
            value = getattr(self, key)
            if value is not None:
                result[key] = value
        return result

    def with_updates(self, **updates: Any) -> "CorrelationContext":
        merged = self.as_dict()
        merged.update(updates)
        return self.from_mapping(merged)


def _text(value: object) -> str | None:
    token = str(value or "").strip()
    return token or None


def correlation_mapping(value: Mapping[str, Any] | CorrelationContext | None) -> dict[str, Any]:
    return CorrelationContext.from_mapping(value).as_dict()

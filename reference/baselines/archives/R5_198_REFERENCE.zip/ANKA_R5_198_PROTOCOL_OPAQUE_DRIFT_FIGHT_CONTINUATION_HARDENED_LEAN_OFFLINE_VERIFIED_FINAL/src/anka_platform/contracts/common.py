from __future__ import annotations

from enum import Enum
from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict, model_validator


T = TypeVar("T")


class ValueStatus(str, Enum):
    KNOWN = "KNOWN"
    UNKNOWN = "UNKNOWN"
    NOT_OBSERVED_YET = "NOT_OBSERVED_YET"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    UNSUPPORTED_BY_ACTIVE_ADAPTER = "UNSUPPORTED_BY_ACTIVE_ADAPTER"


class SemanticValue(BaseModel, Generic[T]):
    """A value whose observation certainty is explicit.

    This prevents consumers from interpreting an absent/unknown value as a valid
    numeric zero, false boolean, or empty collection.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    status: ValueStatus
    value: T | None = None
    detail: str | None = None

    @model_validator(mode="after")
    def _validate_status_value(self) -> "SemanticValue[T]":
        if self.status is ValueStatus.KNOWN and self.value is None:
            raise ValueError("KNOWN semantic value requires value")
        if self.status is not ValueStatus.KNOWN and self.value is not None:
            raise ValueError("non-KNOWN semantic value must not carry value")
        return self

    @classmethod
    def known(cls, value: T) -> "SemanticValue[T]":
        return cls(status=ValueStatus.KNOWN, value=value)

    @classmethod
    def unknown(cls, detail: str | None = None) -> "SemanticValue[T]":
        return cls(status=ValueStatus.UNKNOWN, detail=detail)

    @classmethod
    def not_observed(cls, detail: str | None = None) -> "SemanticValue[T]":
        return cls(status=ValueStatus.NOT_OBSERVED_YET, detail=detail)

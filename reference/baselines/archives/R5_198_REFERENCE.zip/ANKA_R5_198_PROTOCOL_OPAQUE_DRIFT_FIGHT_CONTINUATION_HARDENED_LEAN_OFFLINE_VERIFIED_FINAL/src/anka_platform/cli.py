from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from anka_platform.config import PlatformConfigError, load_platform_config
from anka_platform.control_plane import resolve_control_plane_endpoint
from anka_platform.readiness import assess_readiness
from anka_platform.project_root import resolve_project_root
from anka_platform.calibration.service import InteractiveCalibrator
from anka_platform.calibration.store import CalibrationStore


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="anka", description="ANKA local platform")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("readiness", "start"):
        sub = subparsers.add_parser(command)
        sub.add_argument("--config", default="config.yaml", type=Path)
    debug = subparsers.add_parser("debug")
    debug_sub = debug.add_subparsers(dest="debug_command", required=True)
    export = debug_sub.add_parser("export")
    export.add_argument("--last", action="store_true", help="export the latest local debug bundle")
    export.add_argument("--config", default="config.yaml", type=Path)
    calibrate = subparsers.add_parser("calibrate")
    calibrate.add_argument("target", choices=("shared-ui","spells","spell-anchors","phase-button","export-shared","spell-bar","spell-slot","end-turn","choose-challenge","ready","join-fight","directions","direction"))
    calibrate.add_argument("--config", default="config.yaml", type=Path)
    calibrate.add_argument("--profile", default=None)
    calibrate.add_argument("--window-title", default="Dofus")
    calibrate.add_argument("--slot", type=int, default=None)
    calibrate.add_argument("--direction", choices=("RIGHT","BOTTOM","LEFT","TOP"), default=None)
    calibrate.add_argument("--output", type=Path, default=Path("shared_ui_calibration_export.yaml"))
    return parser


def _load_and_print(config_path: Path):
    try:
        config = load_platform_config(config_path)
    except PlatformConfigError as exc:
        print(f"CONFIG_ERROR={exc}")
        return None, 2
    report = assess_readiness(config)
    print(f"ACTIVE_PROTOCOL={config.protocol.active_adapter}")
    print(f"CANONICAL_CONTRACT_VERSION={config.protocol.canonical_contract_version}")
    print(f"PHASE1_READY={'YES' if report.phase1_ready else 'NO'}")
    print(f"AUTOMATION_READY={'YES' if report.automation_ready else 'NO'}")
    for layer in report.layers:
        print(f"LAYER {layer.name} {layer.state.value} {layer.detail}")
    for check in report.checks:
        print(f"CHECK {check.name} {check.state.value} {check.detail}")
    return config, 0 if report.phase1_ready else 2


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "debug":
        try:
            config = load_platform_config(args.config)
        except PlatformConfigError as exc:
            print(f"CONFIG_ERROR={exc}")
            return 2
        from anka_platform.observability.exporter import DebugBundleExporter
        runtime_dir = config.runtime.data_directory
        account_dbs = {}
        if config.party.enabled:
            for account in config.party.accounts:
                candidate=runtime_dir / "accounts" / account.account_id / "anka.db"
                if candidate.is_file():
                    account_dbs[account.account_id]=candidate
        legacy_db = runtime_dir / "anka.db"
        if account_dbs:
            leader_id=str(config.party.leader_account_id)
            db=account_dbs.get(leader_id) or next(iter(account_dbs.values()))
        else:
            db=legacy_db
        if not db.exists():
            print(f"DEBUG_ERROR=runtime database does not exist: {db}")
            return 2
        bundle = DebugBundleExporter(
            db, runtime_dir / "debug", source_root=resolve_project_root(config_path=args.config),
            account_db_paths=account_dbs,
        ).export_latest()
        print(f"DEBUG_BUNDLE={bundle}")
        return 0
    if args.command == "calibrate":
        if args.target == "export-shared":
            try:
                output = CalibrationStore(args.config).export_profile("shared", args.output)
            except ValueError as exc:
                print(f"CALIBRATION_ERROR={exc}")
                return 2
            print(f"CALIBRATION_EXPORT={output}")
            return 0
        effective_profile = args.profile
        if effective_profile is None and args.target in {"spells", "spell-bar", "spell-slot", "directions", "shared-ui"}:
            effective_profile = "shared"
        calibrator = InteractiveCalibrator(args.config, profile_name=effective_profile, title_contains=args.window_title)
        if args.target == "shared-ui": calibrator.calibrate_shared_ui()
        elif args.target == "spells": calibrator.calibrate_spell_bar()
        elif args.target == "spell-anchors": calibrator.calibrate_spell_anchors()
        elif args.target == "phase-button": calibrator.calibrate_phase_button()
        elif args.target == "spell-bar": calibrator.calibrate_spell_bar()
        elif args.target == "spell-slot":
            if args.slot is None:
                print("CALIBRATION_ERROR=--slot is required for spell-slot")
                return 2
            calibrator.calibrate_spell_slot(args.slot)
        elif args.target == "directions": calibrator.calibrate_directions()
        elif args.target == "direction":
            if args.direction is None:
                print("CALIBRATION_ERROR=--direction is required for direction")
                return 2
            calibrator.calibrate_direction(args.direction)
        else:
            key={"end-turn":"END_TURN","choose-challenge":"CHOOSE_CHALLENGE","ready":"READY","join-fight":"JOIN_FIGHT"}[args.target]
            calibrator.calibrate_control(key)
        print("CALIBRATION_SAVED=YES")
        return 0

    config, code = _load_and_print(args.config)
    if config is None or code != 0:
        return code
    if args.command == "readiness":
        return code

    from anka_platform.web.app import create_app
    import uvicorn
    base=resolve_control_plane_endpoint(args.config).base_url
    print(f"DASHBOARD1={base}/dashboard1")
    print(f"DASHBOARD2={base}/dashboard2")
    print(f"SCRIPT_STUDIO={base}/dashboard3")
    uvicorn.run(create_app(config, config_path=args.config), host=config.web.host, port=config.web.port, log_level="info")
    return 0


def entrypoint() -> None:
    raise SystemExit(main())


if __name__ == "__main__":
    entrypoint()

"""ANKA local platform orchestration package.

The platform owns runtime orchestration and adapters. It may depend on
``anka_game_kernel``; the Kernel must never depend on this package.
"""

__version__ = "0.1.0a146"

@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

rem R5.120: normal run is passive until the operator presses Launch in Script Studio.
rem Deep certification remains available only through explicit flags below.
if /I "%~1"=="--cert-only" goto :controlled_certification
if /I "%~1"=="--campaign" goto :controlled_campaign

echo ========================================
echo ANKA NORMAL SCRIPT STUDIO RUN
echo ========================================
echo This command does NOT run Windows live certification and does NOT intentionally control Dofus before Script Studio Launch.
echo Starting the passive control plane and Script Studio...
echo.
call "%~dp0start.bat"
exit /b %ERRORLEVEL%

:controlled_certification
echo ========================================
echo ANKA EXPLICIT CONTROLLED CERTIFICATION
echo ========================================
echo WARNING: this mode WILL control Dofus and MAY start a real fight.
echo Use normal run_anka.bat or start.bat if you only want Script Studio.
echo.
call "%~dp0start.bat"
if errorlevel 1 exit /b %ERRORLEVEL%
echo ANKA_SERVER_OWNERSHIP=HANDLED_BY_SERVER_SUPERVISOR
call "%~dp0certify_windows.bat" --force
set "CERT_RC=%ERRORLEVEL%"
if not "%CERT_RC%"=="0" (
  echo CERTIFICATION=FAILED
  call :best_effort_debug
  exit /b %CERT_RC%
)
echo CAMPAIGN_RUN=SKIPPED_CERT_ONLY
echo SUCCESS_DEBUG_BUNDLE=%~dp0runtime\certification\last_success_debug.zip
exit /b 0

:controlled_campaign
echo ========================================
echo ANKA EXPLICIT CERTIFICATION CAMPAIGN
echo ========================================
echo WARNING: this mode WILL control Dofus and starts controlled live interactions.
echo For ordinary Script Studio use, run run_anka.bat without flags.
echo.
call "%~dp0start.bat"
if errorlevel 1 exit /b %ERRORLEVEL%
echo ANKA_SERVER_OWNERSHIP=HANDLED_BY_SERVER_SUPERVISOR
call "%~dp0certify_windows.bat" --force
set "CERT_RC=%ERRORLEVEL%"
if not "%CERT_RC%"=="0" (
  echo CERTIFICATION=FAILED
  call :best_effort_debug
  exit /b %CERT_RC%
)
echo CONFIGURED_CAMPAIGN_CERTIFICATION=STARTING
".venv\Scripts\python.exe" -m anka_platform.certification.windows_campaign_runner --config config.yaml --runtime-directory runtime
set "CAMPAIGN_RC=%ERRORLEVEL%"
if not "%CAMPAIGN_RC%"=="0" (
  echo CAMPAIGN_RUN=FAILED
  call :best_effort_debug
  exit /b %CAMPAIGN_RC%
)
echo CAMPAIGN_RUN=COMPLETED
if exist "%~dp0runtime\certification\last_campaign_success_debug.zip" (
  echo SUCCESS_DEBUG_BUNDLE=%~dp0runtime\certification\last_campaign_success_debug.zip
) else if exist "%~dp0runtime\certification\last_success_debug.zip" (
  echo SUCCESS_DEBUG_BUNDLE=%~dp0runtime\certification\last_success_debug.zip
)
exit /b 0

:best_effort_debug
if exist "%~dp0runtime\certification\last_failure_debug.zip" (
  echo AUTO_DEBUG_BUNDLE=%~dp0runtime\certification\last_failure_debug.zip
  exit /b 0
)
if exist "%~dp0runtime\certification\last_campaign_debug.zip" (
  echo AUTO_DEBUG_BUNDLE=%~dp0runtime\certification\last_campaign_debug.zip
  exit /b 0
)
call "%~dp0debug.bat" >nul 2>nul
if exist "%~dp0runtime\debug\latest_debug.path" (
  set /p "LATEST_DEBUG_BUNDLE="<"%~dp0runtime\debug\latest_debug.path"
  if defined LATEST_DEBUG_BUNDLE echo AUTO_DEBUG_BUNDLE=!LATEST_DEBUG_BUNDLE!
)
if not defined LATEST_DEBUG_BUNDLE (
  if not exist "%~dp0runtime\startup" mkdir "%~dp0runtime\startup" >nul 2>nul
  ".venv\Scripts\python.exe" -m anka_platform.startup_debug --config config.yaml --output runtime\startup\last_startup_debug.zip >nul 2>nul
  if exist "%~dp0runtime\startup\last_startup_debug.zip" echo AUTO_DEBUG_BUNDLE=%~dp0runtime\startup\last_startup_debug.zip
)
exit /b 0

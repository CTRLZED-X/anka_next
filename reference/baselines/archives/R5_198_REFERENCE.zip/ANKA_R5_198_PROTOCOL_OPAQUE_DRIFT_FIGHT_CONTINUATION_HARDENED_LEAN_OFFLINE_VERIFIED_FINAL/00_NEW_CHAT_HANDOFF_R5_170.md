# New Chat Handoff — R5.170

Current workspace: **ANKA R5.170 — Protocol Schema-Drift Fail-Closed Hardening**.

Read in this order:

1. `R5_170_PROTOCOL_SCHEMA_DRIFT_FAIL_CLOSED_HARDENING.md`
2. `R5_169_MULTI_ACCOUNT_JOIN_PROTOCOL_COMPLETION.md`
3. `R5_168_NEW_PROTOCOL_3_6_12_16_INTEGRATION.md`
4. `PROTOCOL_UPGRADE_GUIDE.md`
5. `PROJECT_STATUS.json`
6. `PROJECT_CONTEXT.json`
7. `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, `LIVE_ACCEPTANCE.md`

## Baseline that must be preserved

R5.168/R5.169 already integrate the evidence-backed Dofus 3.6.12.16 decoder behind a revision-local adapter and complete CRA-leader -> ENU-follower fight joining. Do not rebuild the protocol layer from scratch and do not leak wire names into Kernel, FightAI, party policy, campaign logic or physical input.

The historical `dofus_3_6_10_10` adapter remains registered and unchanged at its wire boundary.

## R5.170 change

R5.170 closes silent protocol-drift paths:

- unknown `jsq` action ids are `ProtocolSchemaDriftError`;
- unknown/ambiguous `jtk` characteristic oneof branches are `ProtocolSchemaDriftError`;
- genuinely unclassified outer wire types become a sticky protocol-health fault (known opaque compatibility traffic remains allowed);
- schema drift is sticky for the live runtime generation and exported in capture status;
- the physical-input `RuntimeHealthFence` now consumes active transform error, decoder-ready and frame-desync health.

Do not weaken this into "ignore and continue" unless new controlled evidence proves the wire schema and state authority.

## Current protocol evidence status

`dofus_3_6_12_16` still has full required canonical event/semantic/critical-field reference coverage in the retained evidence. The independent live-truth certificate remains `INSUFFICIENT_EVIDENCE` only because five requirements require ORACLE-strength proof:

- world map;
- local actor;
- fight actor cell;
- current AP;
- current MP.

The decoder fields are implemented and cross-flow replay-tested. Do not promote them to ORACLE without packet-aligned independent evidence.

## Next step

Run controlled Windows/Dofus acceptance using the normal workflow (`setup.bat` once, then `start.bat` -> Script Studio -> Launch). Collect packet-aligned oracle evidence for the five remaining proof gates. If the runtime raises protocol schema drift, stop physical automation, preserve the debug bundle/capture, reverse-engineer the new action/shape, add evidence-backed mapping/tests, then restart with a new adapter revision/certification.

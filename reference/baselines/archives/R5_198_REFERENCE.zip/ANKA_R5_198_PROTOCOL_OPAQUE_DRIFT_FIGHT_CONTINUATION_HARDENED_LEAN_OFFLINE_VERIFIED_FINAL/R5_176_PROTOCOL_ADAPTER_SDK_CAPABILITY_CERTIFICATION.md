# R5.176 — Protocol Adapter SDK & Capability Certification

## Purpose

R5.176 turns the protocol boundary from a versioned monolithic decoder into a capability-oriented adapter SDK while preserving the existing `ProtocolAdapter -> CanonicalEvent` contract. The goal is to make a Dofus protocol change a localized adapter/certification task instead of a reason to modify campaign, FightAI, Kernel, projection or physical execution.

## 1. Active adapter decomposed behind the stable facade

`Dofus361216Adapter` remains the registered public adapter but is now a small facade plus common transform/context helpers. Wire behavior is split into version-local capability modules:

- `world_identity`;
- `fight_state`;
- `resources_effects`;
- `combat_actions`;
- `fight_lifecycle`.

`ProtocolHandlerRegistry.from_modules()` owns deterministic wire dispatch and records module/capability ownership. The active adapter facade is no longer the ~2,000-line wire-handler monolith.

## 2. One explicit mutable protocol context

All cross-handler inference state is owned by `Dofus361216RuntimeContext`. Capability handlers remain behavior modules and use explicit context-backed fields. This prevents a future module from introducing a second map/fight/identity/resource shadow authority.

## 3. Capability-scoped exact-build certification

`ProtocolCapabilityBuildCertification` records exact client builds and evidence for each canonical capability. Whole-adapter `certified_client_builds` remains for compatibility, but SDK adapters must provide explicit per-capability rows.

The active 3.6.12.16 adapter has explicit exact-build certification rows for every declared capability, backed by the retained controlled/extended replay corpus.

## 4. Positive live compatibility is not certification

For a newer Dofus build, runtime capture now records canonical event kinds and typed transform-failure capabilities. `build_protocol_compatibility_report()` therefore distinguishes:

- `CERTIFIED_FOR_BUILD`;
- `OBSERVED_COMPATIBLE_UNCERTIFIED`;
- `UNPROVEN_ON_OBSERVED_BUILD`;
- `DRIFT_OR_TRANSFORM_FAILURE`;
- `BUILD_UNKNOWN`;
- `UNSUPPORTED_BY_ADAPTER`.

Positive live evidence can prove that one capability still works on a newer build without falsely certifying negative/absence semantics for that build.

## 5. Drift localization

Version-local handler bindings carry capability ownership. When older handler code raises a typed transform error without capability metadata, the adapter enriches the error from the owning binding before it crosses the protocol boundary. A future `jsq` drift therefore becomes a `SPELL_CAST` capability failure instead of an anonymous global transform failure.

Physical automation remains fail-closed on active schema drift; R5.176 localizes the engineering/debugging repair boundary, not the safety fence.

## 6. Automatic protocol-upgrade work list

`build_protocol_upgrade_report()` converts compatibility evidence into bounded adapter work:

- affected canonical capability;
- owning handler module(s);
- exact certification state;
- observed canonical evidence;
- typed transform-failure count;
- next controlled evidence to capture.

Party preflight includes this report so one runtime/debug package can identify which protocol capability needs new evidence or decoder work.

## 7. Executable SDK architecture checks

SDK-enabled manifests declare `handler_sdk_version >= 1`. Foundation verification requires:

- a composed `ProtocolHandlerRegistry`;
- at least one capability module;
- all module/binding capabilities to exist in the manifest;
- every declared capability to have module ownership;
- every declared capability to have an explicit build-certification row.

The older 3.6.10.10 adapter remains a supported legacy SDK-version-0 adapter; it is not silently rewritten.

## Safety invariants preserved

- Raw wire names remain below `anka_platform.protocol`.
- Canonical State remains the only gameplay truth consumed by higher layers.
- Positive compatibility evidence never becomes an exact-build negative-evidence certificate automatically.
- Active schema drift remains fail-closed for physical automation.
- No FightAI/Kernel/campaign policy is changed by a protocol adapter update.

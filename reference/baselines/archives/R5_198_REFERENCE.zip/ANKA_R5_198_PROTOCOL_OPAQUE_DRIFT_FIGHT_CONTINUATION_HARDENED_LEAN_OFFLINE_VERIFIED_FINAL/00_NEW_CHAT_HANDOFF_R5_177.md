# ANKA R5.177 handoff

Current checkpoint: **R5.177 Diagnostics V2 & Root-Cause Foundation**.

Start with:

1. `R5_177_DIAGNOSTICS_V2_ROOT_CAUSE_FOUNDATION.md`
2. `docs/architecture/DIAGNOSTICS_V2.md`
3. `docs/architecture/PROTOCOL_ADAPTER_SDK.md`
4. `docs/architecture/FAILURE_AUTHORITY_AND_TRACEABILITY.md`
5. `ARCHITECTURE.md`
6. `DEBUGGING.md`
7. `TESTING.md`
8. `LIVE_ACCEPTANCE.md`

R5.177 preserves the verified R5.176 protocol SDK and R5.175/R5.174 authority foundations. Diagnostics V2 is read-only and may not send input, mutate control authority, mutate canonical state, or advance campaign state.

When investigating a new live incident, read `analysis/DIAGNOSIS_V2_READ_ME_FIRST.txt` first, then `analysis/diagnostics_v2.json` and `analysis/root_cause_graph_v2.json`. Use the collector files to determine whether missing data means empty/not-applicable or a collector failure.

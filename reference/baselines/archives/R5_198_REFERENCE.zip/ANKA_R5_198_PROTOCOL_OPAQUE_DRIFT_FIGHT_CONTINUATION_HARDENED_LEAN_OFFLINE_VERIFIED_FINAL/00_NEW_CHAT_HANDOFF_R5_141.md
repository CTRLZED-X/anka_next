# ANKA Platform R5.141 — New Chat Handoff

## Current checkpoint

`ANKA_PLATFORM_R5_141_SPELL_TARGET_INTERACTION_ACTION_INTENT_SEQUENCE_PLANNING_HARDENING_WINDOWS_LIVE_CANDIDATE`

- Offline verification: **PASS — frozen-tree verification complete**.
- Windows/Dofus live acceptance: **PENDING**.
- Final production release: **NO**.
- Behavioral parent: R5.140.
- Sealed runtime identity remains R5.115 / platform `0.1.0a122`.
- Kernel remains `0.1.0a58`; R5.141 does not change Kernel mechanics files.

## Read first

1. `00_NEW_CHAT_HANDOFF_R5_141.md`
2. `R5_141_SPELL_TARGET_INTERACTION_ACTION_INTENT_SEQUENCE_PLANNING_HARDENING.md`
3. `PROJECT_STATUS.json`
4. `PROJECT_CONTEXT.json`
5. `verification/R5_141_OFFLINE_VERIFICATION.md`
6. `R5_140_COMBAT_FRAME_FEASIBILITY_RECOVERY_TACTICAL_FOUNDATION_HARDENING.md`
7. `ARCHITECTURE.md`
8. `DEBUGGING.md`
9. `LIVE_ACCEPTANCE.md`

## Triggering live evidence

`runtime(20260926-231620)`, fight 478. Enu's final Bêche des Anciens attempt used cast CellId 141 from cell 101 with intended enemy -1 on cell 170. Cell 141 is real and Kernel-valid; PRE_TARGET certified the impact. The physical slot and target clicks were sent, but no semantic cast request/server-confirmed cast followed. Earlier empty-cell Bêche casts succeeded in the same fight. Do **not** add cell 141, spell 13367 or fight 478 exceptions.

## R5.141 changes

- production spell target clicks require the exact rendered Unity `cell::<id>` anchor;
- projection/debug evidence preserves anchor identity plus walkability/projectability flags;
- FightAI CASTs carry ActionIntent required enemy/ally effect orders through latest-state admission;
- malformed non-empty ActionIntent fails closed;
- support AoE candidate generation includes empty cells around allies;
- same-session negative cast semantics may be learned only after 3 exact server-confirmed CAST↔`jrj` correlations for the same spell/client/version;
- missing PO/range remains UNKNOWN but is explicitly counted in candidate diagnostics;
- bounded two-ply sequence valuation compares CAST/MOVE first actions and legal continuations;
- physical execution remains one primitive -> settle -> replan.

## Important unresolved boundary

Authoritative live Range/PO may still be absent on the observed client. Never restore `missing range_bonus -> 0`. If the next runtime reports large `range_evidence_starvation_count`, investigate a certified client/protocol combat-stat observation source.

## Windows live procedure

Because `unity_bridge/AutomaticMapAdapter.cs` changed, close Dofus and run `install_bridge.bat` before the first R5.141 live test. Require the bridge compile/install/byte-verification path to succeed. Then open both clients, run `start.bat`, require normal live preflight readiness, Launch once, and do not manually join/Ready/move/cast. Preserve the first autonomous failure package.

## Diagnostic priorities for a suspicious CAST

```text
CombatDecisionFrame
 -> candidate + ActionIntent
 -> Kernel cast/effect feasibility
 -> PRE_SLOT
 -> slot click
 -> PRE_TARGET ActionIntent revalidation
 -> exact rendered cell-anchor projection
 -> target click
 -> outbound semantic request
 -> server cast/consequences
 -> settlement/recovery
```

Distinguish: cell exists, movement-walkable, spell-semantically legal, and client-interaction verified. They are not interchangeable.

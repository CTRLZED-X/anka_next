# R5.171 — Unity Bridge Runtime-Reflection Hardening

## Root cause

R5.170's bridge project and `BUILD_BRIDGE.bat` required two Dofus-specific generated interop assemblies by filename: `Core.dll` and `Ankama.Dofus.Core.World.dll`. The bridge source did not directly use `Ankama.Dofus.Core.World.dll`; it used `CustomGridGenerator` from the Dofus runtime. Current BepInEx interop generation can legitimately expose a different assembly split, so the installer failed before compilation even though all stable BepInEx/Unity dependencies were present.

This was an architectural portability bug, not evidence that the local BepInEx installation was necessarily incomplete.

## R5.171 repair

- Removed compile-time references to every Dofus-specific interop assembly filename.
- `AuthoritativeCellPositionSource` now stores a stable `UnityEngine.Component` and resolves `Core.Features.Roleplay.World.GridGenerator.CustomGridGenerator` by full runtime type name across loaded assemblies.
- Live component discovery prefers the resolved full runtime type and still inspects reflected static accessors. If a client update moves the class to a different namespace/assembly, a live component named `CustomGridGenerator` can be considered, but it must pass the same semantic converter probe before it is cached or trusted.
- Converter discovery remains semantic: instance `Vector3(Int32)` methods are probed across all 560 cell IDs and must satisfy the existing >=500 finite / >=500 distinct-position checks.
- Existing actor-to-cell validation and fail-closed coordinate readiness remain unchanged.
- Runtime type resolution is cached only after success; an early unresolved state is retried later rather than permanently cached as failure.
- `BUILD_BRIDGE.bat` now requires only stable BepInEx/Unity interop files.
- `runtime/bridge_environment.json` is written before build and records stable dependencies, optional game-specific assembly presence, the complete interop DLL filename inventory, SDKs and hashes/versions where available.
- `runtime/bridge_install_attempt.log` captures the complete setup bridge build/install console output.
- `runtime/startup/setup_failure_debug.zip` is attempted automatically on setup failure once the Python environment is available, and embeds both `projection/bridge_environment.json` and `projection/bridge_install_attempt.log`.
- A new install attempt invalidates any old `runtime/bridge_install.json` before compilation, so failed setup evidence cannot inherit stale successful bridge authority.
- Bridge binary identity was incremented to plugin version 2.2.73.

## Safety preserved

R5.171 does not replace the cell algorithm with guessed geometry. If the runtime type cannot be found, no trustworthy `Vector3(Int32)` converter exists, the 560-cell probe is structurally weak, actor-cell associations disagree, or projection cannot be validated, the bridge remains not ready and physical execution stays fail-closed.

## Live status

This repair addresses the reported setup blocker. Windows/Dofus live acceptance still needs to run. Protocol live-truth certification also retains the five independent ORACLE evidence requirements already documented by R5.170.

# R5.194 — Protocol Startup + Diagnostic Hardening

## Why this release exists

The 2026-10-15 CRA+ENU live run did not reach a worker. Script Studio surfaced `PENDING_LAUNCH_STALLED` / `WORLD_STATE_CONVERGENCE_NOT_SAFE_YET`, but the lower-layer cause in the runtime package was `PROTOCOL_UNCLASSIFIED_ACTIVE` on both required accounts. The exact current-build wire identity was `hmp`, server-to-client, payload `10e601` (four observations total). ANKA correctly failed closed and sent no physical input.

R5.194 repairs that observed classification gap without assigning unsupported gameplay meaning to `hmp`, and hardens the startup state machine so future lower-layer failures are identified immediately rather than hidden behind a generic convergence timeout.

## Root causes repaired

1. **Exact-build catalog gap.** `hmp|server_to_client` was absent from the `dofus_3_7_10_10` catalog. It is now catalogued from hash-bound current-build evidence. It has no canonical handler and therefore grants no state-mutation authority. Because only payload `10e601` is evidenced, the opaque classification is fingerprint-constrained; a different future `hmp` payload fails closed instead of inheriting unsupported harmlessness.
2. **Generic pending-Launch timeout masked a sticky safety fence.** Startup now centrally classifies whether a blocker can recover merely by waiting. Protocol unknown/schema/frame/context failures and Canonical-store fencing are non-recoverable waits and trigger immediate terminal diagnostics rather than a blind 20-second stall.
3. **Root-cause attribution stopped at the application wrapper.** Startup diagnostics now promote exact protocol, framing, runtime-context, or Canonical-state causes ahead of `PENDING_LAUNCH_*` wrappers.
4. **Preflight/runtime handoff race was mislabeled terminal.** If readiness changes between passive assessment and guarded worker reservation, the frozen Launch intent remains `WAITING`, authorization stays valid, and the next tick re-evaluates current readiness. A genuine worker-start failure remains terminal.
5. **Distributed startup policy drift.** Startup blocker domain, bootstrap disposition, wait recoverability, and recovery hints are owned by one registry. Unknown blocker codes fail closed until explicitly classified.
6. **Diagnostic/performance noise.** Projection refresh is skipped when an upstream non-projection hard blocker already makes startup unsafe.
7. **Exporter complexity regression.** Startup diagnosis was extracted to a dedicated observability module, keeping the main exporter within engineering guardrails.
8. **Watchdog callback failure could strand Launch.** A failing stall/diagnostic callback was previously marked handled before terminalization succeeded. The watchdog now retains bounded callback-failure evidence and retries on the next poll.
9. **Stale watchdog diagnostics could contradict a winning worker start.** If a worker wins the launch transition after a stale WAITING sample, the watchdog now honors `ALREADY_STARTED_OR_TERMINAL` and does not emit a false `FAILED_TO_START` incident.
10. **Generic launch ValueError could desynchronize lifecycle state.** Non-preflight launch errors now use the same atomic terminal transition as the watchdog rather than clearing only a subset of pending/authorization state.

## Evidence boundary

The current runtime ZIP SHA-256 is `eaf065ab0a967ba60f70caa6e2f20381abca7a01db72e7c125bcf328ba31be5c`. The incident raw capture hash is `c304364592d3954ef4171c7c81fd0f0d3771ad09fc6a62b297cd36c07a3b50a4`; the 172-row bounded protocol window hash is `c8a629fdfa70e222c0d65885621eb5d9f9cf8b534f79d1f8cd62e34b7fc775e3`.

Offline replay/classification of all 172 captured protocol-window rows against the updated adapter produces **0 unclassified rows**. `hmp` remains catalog-only: no canonical/gameplay semantics were inferred.

## Safety preserved

- Unknown messages still fail closed.
- Schema drift still fails closed.
- No new physical-input bypass exists.
- No current-build outbound End Turn opcode is claimed proven.
- The four current live-scenario evidence gaps remain explicit: placement→Ready, Ready→first turn, End Turn→next owner, and fight end→world re-entry.
- Windows/Dofus live acceptance remains pending until a fresh R5.194 run.

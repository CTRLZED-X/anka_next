# Historical project material

This directory contains cumulative historical narratives. Historical material can explain why an invariant exists, but it is never the current runtime/configuration authority.

Current authority order is documented in `PROJECT_CONTEXT.json` and `docs/CURRENT.md`.

# Live-decoding independent oracle format

The ORACLE layer exists to prove that Canonical State agrees with a source that did **not** obtain its semantic values from ANKA Canonical State or from ProjectionSync payloads derived from Canonical State.

A versioned `LIVE_DECODING_EVIDENCE.json` package that declares `oracle_snapshots` must also declare `oracle_provenance` with:

- `source_kind`: `MANUAL_OBSERVATION`, `INDEPENDENT_RUNTIME_INSTRUMENTATION`, or `INDEPENDENT_EXTERNAL_SOURCE`;
- `collector_id`: stable identity of the independent collector/workflow;
- `alignment_method`: `PCAP_PACKET_INDEX`;
- `canonical_independent`: `true`.

Do **not** mark the normal ANKA projection bridge observation stream as an independent oracle. ProjectionSync is populated from Canonical State and is therefore circular evidence for MapId/ActorId/CellId/AP/MP certification.

Each non-empty JSONL row in `oracle_snapshots.jsonl` must be one strict JSON object:

```json
{
  "snapshot_id": "unique-id",
  "received": {
    "pcap_packet_index": 1234
  },
  "snapshot": {
    "member_id": "CRA",
    "map_id": 123456789,
    "is_my_turn": true,
    "self": {
      "actor_id": 111111,
      "cell_id": 321,
      "hp": 2000,
      "max_hp": 2100,
      "ap": 7,
      "mp": 3
    },
    "actors": [
      {"actor_id": 222222, "cell_id": 211}
    ]
  }
}
```

`actors` is optional. It contains independently observed non-local actors used to prove target movement/displacement CellId truth. An actor in `actors` must not duplicate `self.actor_id`.

## Structural rules

1. `snapshot_id` must be unique and non-empty.
2. `received.pcap_packet_index` must be a positive **JSON integer** inside the supplied capture. It refers to the capture-wide packet record number, not “Nth decoded Dofus message”.
3. `snapshot.member_id` must map to exactly one account through `oracle_member_id` in the evidence manifest.
4. Every declared account must map to a unique oracle member when oracle snapshots are present.
5. `is_my_turn`, when present, must be a real JSON boolean.
6. `map_id`, `actor_id`, `cell_id`, `hp`, `max_hp`, `ap` and `mp`, when present, must be real JSON integers (not booleans or numeric strings).
7. At least one comparable semantic field must be present.
8. AP/MP are certification-comparable only for rows where the independent oracle marks `is_my_turn=true`.
9. Duplicate JSON object keys, non-finite numbers, unknown evidence-manifest **or nested ORACLE** keys, non-string `snapshot_id`/`member_id`, malformed actor records, packet misalignment and circular/unproven provenance are blocking evidence errors.
10. Oracle values never mutate the decoder or Canonical State; they are comparison-only evidence.

## R5.184 transition-proof requirements

A single static matching value is **not** enough for a truth whose contract requires behavior over time.

- **World MapId:** every declared account must have trusted matched snapshots containing at least two distinct MapIds, demonstrating a real map transition.
- **Local ActorId:** every declared account must have a trusted independent actor-identity match.
- **Actor CellId:** every declared account must show at least two distinct trusted matched local CellIds **and** at least one separately identified non-local actor with at least two distinct trusted matched CellIds.
- **Current AP:** every declared account must show, on independently marked owned-turn snapshots, a trusted matched AP sequence containing a loss and a later recovery/reset.
- **Current MP:** every declared account must show, on independently marked owned-turn snapshots, a trusted matched MP sequence containing a loss and a later recovery/reset.

A mismatch blocks that truth. A missing transition remains insufficient evidence. One account can never satisfy another controlled account's proof.

## Transport-integrity requirement

Oracle alignment is only meaningful when the capture itself is structurally and transport-wise trustworthy. R5.184 blocks certification on framing-byte loss after established framing or unresolved TCP reassembly intervals. A bounded capture may end with bytes buffered for the next incomplete frame, and a complete transport frame may contain no Ankama Any envelope; both remain visible diagnostics but are not global blockers by themselves. Packet-bearing unsupported PCAPNG link types, selected-port IPv6/non-IPv4 TCP, selected fragmented IPv4 TCP, malformed block structure, or undefined interfaces fail before comparison.

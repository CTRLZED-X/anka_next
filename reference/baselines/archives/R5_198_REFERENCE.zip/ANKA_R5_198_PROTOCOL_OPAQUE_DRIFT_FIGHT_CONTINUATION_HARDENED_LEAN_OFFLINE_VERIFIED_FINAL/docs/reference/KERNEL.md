# Game Kernel Reference

`src/anka_game_kernel/` is the deterministic mechanics authority.

Current sealed Kernel identity: `0.1.0a57 / R10H Enutrof 22/22 Projection Ready`.

The Kernel owns pure game knowledge such as geometry, range, LoS, spell legality, effect shapes, deterministic movement/displacement, constraints, and supported spell mechanics. It does **not** own Windows, physical input, accounts, campaign lifecycle, packet transport, mutable live state, or orchestration.

Three-source rule:

- Static data owns static game definitions.
- Kernel owns verified deterministic rules/projections.
- Live/canonical state owns server-observed outcomes and facts intentionally not predicted by the Kernel.

Unknown or unsupported mechanics must remain explicit rather than guessed. See `docs/architecture/` for detailed semantic contracts and `src/anka_game_kernel/` + tests as final authority.

# Protocol Evidence Policy — R5.190 Lean Runtime

Raw reverse-engineering evidence is **not shipped inside the runtime project**.

The intended workflow is:

1. Collect PCAPNG/screenshots/debug evidence outside the project.
2. Give that external evidence plus the protocol-adapter template/current adapter to the reverse-engineering workflow.
3. Produce and independently verify a versioned protocol adapter.
4. Install the verified adapter into `src/anka_platform/protocol/adapters/`.
5. Ship only the adapter, its semantic manifest/catalog, and a small hash-bound certification attestation.

The runtime does not need the raw PCAPNG, screenshots, CSV investigations, or old reverse-engineering notes to decode live traffic. The active `dofus_3_7_10_10` adapter carries `certification_attestation.json`, which records the sealed R5.190 certification result and is bound to the attested protocol source files by SHA-256. If any attested protocol file changes, startup certification fails closed until a new adapter is verified and a new attestation is produced.

Historical raw-evidence replay tests are retained as code where useful but are skipped automatically when the external corpus is not present. They can be re-enabled by restoring the matching external evidence corpus for development/re-certification.

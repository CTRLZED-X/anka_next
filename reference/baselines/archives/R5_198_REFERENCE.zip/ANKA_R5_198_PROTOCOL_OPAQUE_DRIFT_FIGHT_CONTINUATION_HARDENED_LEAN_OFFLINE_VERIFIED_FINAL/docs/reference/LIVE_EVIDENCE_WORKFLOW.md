# Bounded live-decoding evidence workflow

Use this only for the controlled live-acceptance evidence run. It does not authorize physical input by itself.

1. Run the normal Windows readiness path (`setup.bat`, then `start.bat`, then passive readiness checks).
2. Capture the bounded CRA/ENU run to a PCAPNG while collecting truly independent oracle observations for the five remaining truths.
3. Run `inspect_live_capture.bat <capture.pcapng> [--port <port> ...]` to inventory exact **raw selected-port TCP flows**, payload bytes and packet ranges. The inventory deliberately does **not** guess CRA/ENU identity.
4. Map every payload-bearing selected-port flow and every newly observed selected-port connection (SYN) to a declared evidence account from out-of-band process/account evidence. A flow that is present but does not decode is still part of completeness and must not be hidden by decoder failure.
5. Copy `docs/reference/LIVE_DECODING_EVIDENCE_TEMPLATE.json` and `docs/reference/LIVE_DECODING_SCENARIO_TEMPLATE.json` into the evidence folder. Fill exact client build, exact flow ownership and only assertions deliberately exercised.
6. Record `oracle_provenance`. The normal Canonical -> ProjectionSync bridge observation stream is not independent and must not be used to certify Canonical truth.
7. Give every declared controlled account a unique `oracle_member_id` and record packet-aligned oracle rows using the strict format in `LIVE_DECODING_ORACLE_FORMAT.md`.
The five current ORACLE-strength targets are world MapId, local actor identity for both controlled accounts, fight actor CellId, current AP, and current MP. R5.184 keeps those five targets but strengthens what counts as independent proof.

8. Deliberately collect the transitions required by the contract, not just static snapshots:
   - MapId before/after a known map transition;
   - independently known local ActorId for CRA and ENU;
   - local CellId before/after movement plus one separately identified target actor before/after movement/displacement;
   - AP baseline -> known AP loss -> later turn reset/recovery;
   - MP baseline -> known MP loss -> later turn reset/recovery.
9. Run `verify_live_decoding.bat <evidence-folder>` from the sealed `.venv`.
10. `READY` is required for protocol promotion. `BLOCKED` means repair the evidence/decoder boundary named by `first_blocking_boundary`. `INSUFFICIENT_EVIDENCE` means collect the emitted missing proof; do not guess or weaken the requirement.

## R5.184 evidence-integrity rules

- **Raw-flow completeness comes before decoding.** Every payload-bearing selected-port TCP flow and every newly observed selected-port SYN must be declared. An undeclared/undecodable lane is a blocking evidence-completeness failure.
- **Packet indexes are capture-wide packet-record indexes.** Every packet record advances the index; packet-bearing unsupported link types fail closed. PCAPNG sections reset interface IDs. EPB, SPB and legacy Packet Block structure is validated.
- **Transport health is part of evidence health.** Dropped framing bytes after established framing or unresolved TCP reassembly gaps block certification. A bounded EOF partial frame and complete non-Any transport frames are reported observations, not corruption by themselves. Selected-port IPv6/non-IPv4 TCP and fragmented selected IPv4 TCP fail closed until the production transport supports them.
- **JSON is strict.** Duplicate keys, non-finite constants, unknown manifest/schema keys and wrong semantic field types fail closed.
- **ORACLE proof is per account and transition-based.** Static equality or a match from only one controlled lane is insufficient.
- **Evidence failure is not decoder failure.** Invalid provenance/alignment/format/completeness is classified as evidence integrity, not silently converted into a protocol mismatch.

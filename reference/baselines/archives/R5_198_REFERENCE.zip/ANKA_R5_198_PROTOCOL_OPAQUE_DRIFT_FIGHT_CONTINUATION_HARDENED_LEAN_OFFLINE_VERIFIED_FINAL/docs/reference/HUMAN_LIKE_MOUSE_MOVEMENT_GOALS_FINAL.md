# Human-Like Mouse Movement — Project-Agnostic Implementation Goal

## Purpose

This document explains the **behavioral goal** for mouse movement.

It does **not** assume any specific project architecture, file names, classes, or current implementation.

The objective is simple:

> Whenever the project needs to move the mouse from one screen coordinate to another, the cursor should travel there through a smooth, continuous, human-like motion instead of instantly jumping from point A to point B.

The same behavior should be used for every coordinate-to-coordinate movement, for example:

```text
current cursor position -> spell icon
spell icon -> target cell
map cell -> spell bar
current cursor -> Ready
current cursor -> End Turn
current cursor -> any UI button
```

The system should also avoid clicking the **exact same pixel every time** when the target is an area such as a map cell or button.

---

# 1. Main objective

Current undesirable behavior:

```text
A ●                         ● B

A ------------------------> B
       instant jump
```

Desired behavior:

```text
A ●
   \
    \__
       \____
            \___
                ● B
```

But the path should remain **mostly direct**.

Human-like does **not** mean making large random curves or shaking the cursor.

A normal result should look approximately like:

```text
A ●────────────────────────────● B
```

with small smooth variation:

```text
A ●─────────╮__________________● B
             ╰─────╯
```

Different movements should not be geometrically identical.

---

# 2. Important factors

Human-like mouse motion is not only about trajectory and velocity.

The movement model should consider all of the following.

## 2.1 Trajectory

The cursor should follow a smooth continuous path from start to destination.

The path should:

- remain mostly straight toward the target
- contain small natural curvature
- never teleport between distant coordinates
- avoid sharp zig-zags
- avoid independent random noise at every point
- always finish inside the intended target

Bad:

```text
A ●─╲╱─╱╲──╲╱╲─╱╲────────● B
```

Good:

```text
A ●────────╮_______________● B
            ╰─────╯
```

---

## 2.2 Velocity

The cursor should not move at one perfectly constant speed.

A normal aimed movement is approximately:

```text
START                     TARGET

slow -> accelerate -> fast -> decelerate -> slow
```

Example spacing at equal time intervals:

```text
A ● •  •    •       •         •      •   •  • ● B
```

The larger gaps in the middle mean higher speed.

---

## 2.3 Acceleration

Velocity should increase smoothly after movement begins and decrease smoothly near the target.

Avoid:

```text
0 px/s
instant jump
900 px/s
instant stop
0 px/s
```

Prefer smooth transitions.

---

## 2.4 Jerk

Jerk is the rate at which acceleration changes.

Very abrupt changes in acceleration make movement look mechanical.

The motion should therefore avoid sudden direction/speed changes and use a smooth profile.

A practical baseline is a minimum-jerk progression such as:

```text
s(t) = 10t³ - 15t⁴ + 6t⁵
```

where:

```text
t = 0   start
t = 1   destination
```

This is only a recommended motion profile, not a requirement that the entire implementation use exactly this formula.

---

# 3. Movement duration

The movement time should depend on the movement itself.

Do not use:

```text
every move = 300 ms
```

A short movement should usually be faster than a movement across most of the screen.

Conceptually:

```text
20 px   -> short duration
150 px  -> moderate duration
700 px  -> longer duration
```

Duration should contain a small amount of controlled variation so repeated identical-distance actions are not perfectly identical.

The variation must remain bounded.

Do not generate arbitrary large random delays.

---

# 4. Distance-sensitive behavior

The motion style should adapt to distance.

## Very short distance

Example:

```text
A ●────● B
```

Use:

- nearly straight movement
- extremely small curvature
- short duration
- no unnecessary correction
- enough intermediate positions to avoid teleporting

Do not generate a giant curve for a 10-pixel movement.

## Medium distance

Use:

- small smooth curvature
- clear acceleration/deceleration
- moderate duration

## Long distance

Use:

- more intermediate coordinates
- slightly more possible curvature
- longer movement duration
- still remain close to the direct A -> B route

Do not allow deviation to grow without a maximum bound.

---

# 5. Target-size behavior

When possible, consider the size of the destination.

Example:

```text
large button
┌──────────────────────┐
│                      │
│          X           │
│                      │
└──────────────────────┘
```

versus:

```text
small target
┌─────┐
│  X  │
└─────┘
```

A small target should normally have:

- a more careful final approach
- smaller allowable endpoint variation
- possibly slightly longer deceleration

A large target allows somewhat more endpoint variation.

---

# 6. Do not always click the exact same pixel

This is an important goal.

Suppose the project already knows that the correct cell center is:

```text
(500, 300)
```

If the cell is larger than one pixel, do not necessarily click exactly:

```text
(500, 300)
```

every single time.

Instead, select a **safe final click position inside the valid clickable area**.

Example:

```text
CELL

        top
         ▲
     ┌─────────┐
     │   •     │
     │ • X  •  │
     │    •    │
     └─────────┘

X = nominal/center coordinate
• = possible safe click positions
```

Different actions may end at:

```text
(499, 302)
(503, 298)
(497, 299)
(501, 301)
```

instead of always:

```text
(500, 300)
```

---

# 7. Safe target-coordinate variation

Endpoint variation must be **safe**.

Do not simply do:

```text
target_x += random(-20, 20)
target_y += random(-20, 20)
```

because that can move the click outside the intended cell/button.

The preferred approach is:

```text
semantic target
      ↓
known clickable region / hitbox
      ↓
create an inner safe region
      ↓
select one point inside that safe region
      ↓
generate mouse trajectory toward that point
```

Example:

```text
FULL CELL

┌────────────────────────┐
│                        │
│    ┌──────────────┐    │
│    │  SAFE AREA   │    │
│    │      •       │    │
│    │   •     •    │    │
│    └──────────────┘    │
│                        │
└────────────────────────┘
```

Do not choose points near the edge unless there is a reason to do so.

---

# 8. Prefer an inner safe zone

If the project knows the target rectangle/polygon, shrink it inward before choosing the final point.

Conceptually:

```text
target region
    ↓
remove edge margin
    ↓
safe interior region
    ↓
sample final coordinate
```

For example:

```text
Original cell

┌────────────────────┐
│ edge               │
│   ┌────────────┐   │
│   │ SAFE ZONE  │   │
│   └────────────┘   │
│               edge │
└────────────────────┘
```

This gives variation without reducing reliability.

---

# 9. Distribution of final click points

Do not use every pixel with equal probability.

Human clicks normally remain concentrated near the intended region.

A better distribution is:

```text
many clicks near center
fewer clicks farther away
almost no clicks close to unsafe edges
```

Conceptually:

```text
        low
         .
      .  .  .
    .  .....  .
   . ..XXXXX.. .
    .  .....  .
      .  .  .
         .
```

A good practical choice is a **bounded/truncated Gaussian-like distribution** around the nominal target center.

Requirements:

- always inside safe region
- usually close to center
- sometimes slightly left/right/up/down
- no extreme outliers
- endpoint variation scales with target size

---

# 10. Avoid repeatedly using the same endpoint

When the same target is selected multiple times, the exact endpoint should not always repeat.

However, do not force every consecutive point to be dramatically different.

Use a small repeat-avoidance rule such as:

```text
if new endpoint is almost identical to previous endpoint:
    optionally draw another safe point
```

The goal is variation, not artificial alternating patterns.

Bad:

```text
left
right
left
right
left
right
```

Good:

```text
slightly left
near center
slightly upper-right
near center
slightly lower-left
```

---

# 11. Trajectory randomness

Randomness should affect the **whole movement**, not every frame independently.

Correct concept:

```text
Before moving:
    choose movement parameters once

Then:
    follow the generated smooth path
```

For example choose once:

```text
curvature amount
curvature direction
small secondary bend
movement duration
speed-profile parameters
optional correction
final safe click point
```

Then freeze those parameters for that movement.

Wrong:

```text
for every mouse event:
    x += random(...)
    y += random(...)
```

That creates jitter.

---

# 12. Smooth lateral deviation

A useful model is to decompose movement into:

```text
forward direction toward destination
+
small perpendicular deviation
```

Example:

```text
                 B ●
                /
             __/
          __/
       __/
A ●___/
```

The lateral deviation should:

```text
start at 0
increase slightly during movement
return to 0 at the chosen endpoint
```

This preserves exact arrival.

A conceptual mathematical model is:

```text
P(t)
=
start
+
forward_progress(t) * direction
+
lateral_deviation(t) * perpendicular_direction
```

with:

```text
lateral_deviation(0) = 0
lateral_deviation(1) = 0
```

---

# 13. Correlated smooth noise

If additional randomness is desired, use **low-frequency correlated variation**.

Do not generate white-noise-like jitter.

Possible implementation ideas include:

- one or two sine components
- spline-based deviation
- correlated noise
- a small randomized Bezier-style bend
- filtered noise

The important property is:

```text
nearby trajectory points should have related deviations
```

not completely independent deviations.

---

# 14. Primary movement + optional correction

Real aimed movement can include a main movement followed by a small final correction.

Support this as an optional behavior.

Example:

```text
A ●
   \
    \________________ P
                      \
                       \ small correction
                        \
                         ● B
```

But:

- do not use it every time
- do not use it for tiny movements
- keep the correction small
- never click before reaching the final valid point
- always finish safely inside the target

---

# 15. Overshoot / undershoot

A very small overshoot or undershoot may occasionally be used as part of a correction model.

But it should be:

- rare
- small
- context-dependent
- completely disabled when unsafe
- followed by an exact safe final arrival

Do not make every movement overshoot.

That creates an obvious artificial pattern.

---

# 16. Intermediate coordinates

The cursor must move through many intermediate coordinates.

Bad:

```text
(100,100)
(800,500)
```

Good:

```text
(100,100)
(107,102)
(116,105)
(128,109)
(143,115)
...
(783,493)
(792,497)
(800,500)
```

The number and spacing of points should depend on:

- distance
- movement duration
- desired update frequency

Do not create thousands of unnecessary events for very short movements.

---

# 17. Sampling timing

Do not only make the spatial path smooth.

The **time** between emitted positions matters too.

The implementation should create a temporal motion profile and sample it over the movement duration.

Conceptually:

```text
trajectory = WHERE
timing     = WHEN
```

Both are needed.

---

# 18. Start position

Each movement should begin from the cursor's **actual current position**.

Do not assume the previous requested target is still the current cursor position.

Concept:

```text
read current mouse position
        ↓
generate path from current position
        ↓
move to selected safe destination
```

---

# 19. Final arrival

Before clicking, the system should have reached the selected safe endpoint.

Conceptually:

```text
MOVE
  ↓
ARRIVE
  ↓
CLICK
```

not:

```text
MOVE + CLICK simultaneously before arrival
```

If the project already has reliable click logic, preserve it and change only the movement that occurs before the click.

---

# 20. Click timing

After arriving, a very small settling interval may exist before clicking.

Mouse down and mouse up are separate events:

```text
arrive
  ↓
small settle
  ↓
mouse down
  ↓
short hold
  ↓
mouse up
```

Do not make the timing identical for every action.

But variation must remain small and bounded.

Do not introduce long random pauses.

---

# 21. Context-sensitive movement

Not all movements should behave exactly the same.

Examples:

## Spell icon -> nearby spell icon

```text
short
fast
almost straight
tiny endpoint variation
```

## Spell bar -> distant map cell

```text
longer
more intermediate positions
clear acceleration/deceleration
small smooth curve
```

## Current cursor -> small button

```text
more careful final approach
smaller endpoint variation
```

## Current cursor -> large cell

```text
slightly more endpoint variation allowed
```

---

# 22. Recommended movement pipeline

The intended conceptual pipeline is:

```text
REQUEST TARGET
      ↓
determine valid target region
      ↓
choose a safe final coordinate inside target
      ↓
read actual current cursor coordinate
      ↓
measure distance and target size
      ↓
choose bounded random movement parameters
      ↓
calculate movement duration
      ↓
generate smooth trajectory
      ↓
generate smooth speed profile
      ↓
sample intermediate coordinates
      ↓
move continuously through them
      ↓
optional tiny final correction
      ↓
arrive at safe final coordinate
      ↓
click
```

---

# 23. Suggested internal model

A project may implement the behavior using one centralized function/service such as:

```text
move_mouse_humanized(
    target_region,
    target_center,
    target_type
)
```

or:

```text
HumanMouse.move_to(...)
HumanMouse.move_and_click(...)
```

The exact names are not important.

The important requirement is:

> The same movement model should be reused everywhere instead of implementing different cursor behavior in many unrelated parts of the project.

---

# 24. Parameters that may vary per movement

A movement plan can contain parameters such as:

```text
start coordinate
selected safe endpoint
distance
target size
duration
peak speed
time of peak speed
curvature direction
curvature amount
secondary deviation
acceleration profile
deceleration profile
correction enabled/disabled
correction size
settling delay
click hold duration
random seed
```

These should be selected within safe bounded ranges.

---

# 25. Seeded randomness

For debugging, each movement may use a random seed.

Then:

```text
same start
same target
same seed
same configuration
```

should reproduce the same movement.

This makes bugs reproducible while still allowing different movements during normal use.

---

# 26. Avoid fixed signatures

Do not make every movement use exactly:

```text
same curve shape
same duration
same peak speed
same acceleration
same endpoint
same correction
same number of samples
```

But also do not make everything completely random.

The goal is:

```text
structured variation
```

not:

```text
chaos
```

---

# 27. Human-like does not mean inaccurate

Accuracy is more important than randomness.

The system must never intentionally create an unsafe click merely to look less repetitive.

Priority:

```text
1. correct target
2. safe endpoint
3. smooth continuous movement
4. natural variation
```

If the valid target is extremely small, reduce or disable endpoint variation.

---

# 28. Example: cell clicking

Suppose the correct game cell has a known clickable polygon.

Do this:

```text
cell polygon
    ↓
create safe inner polygon
    ↓
choose endpoint inside safe polygon
    ↓
generate humanized trajectory
    ↓
arrive
    ↓
click
```

Do NOT do this:

```text
cell center
    ↓
add arbitrary ±15 px
    ↓
hope it is still inside the cell
```

---

# 29. Example: button clicking

Suppose a button occupies:

```text
x = 400..500
y = 600..640
```

Do not always click:

```text
(450,620)
```

Instead create an inner safe rectangle, for example conceptually:

```text
x = 410..490
y = 607..633
```

Then choose a point concentrated around its center.

Possible results:

```text
(448,618)
(454,623)
(443,621)
(451,616)
```

Every point remains safely inside the button.

The exact margins must depend on the actual target geometry.

---

# 30. Example: full movement

Suppose:

```text
current cursor = (200,500)
target cell nominal center = (800,250)
```

Instead of:

```text
jump to (800,250)
click
```

the system might do:

```text
choose safe endpoint = (796,253)

start = (200,500)

generate one movement:
duration = bounded value
curvature = small
velocity = slow -> fast -> slow
endpoint = (796,253)

stream:

(200,500)
(204,499)
(211,496)
(222,492)
(238,486)
...
(760,270)
(779,261)
(790,256)
(796,253)

small settle
mouse down
mouse up
```

Next time the same cell is selected:

```text
endpoint may be (802,248)
```

and the trajectory/timing may also differ slightly.

---

# 31. What NOT to do

Do not use instantaneous cursor teleportation for normal movement.

Do not use a perfectly straight identical path every time.

Do not use constant speed every time.

Do not generate independent random X/Y jitter every frame.

Do not create huge decorative curves.

Do not force overshoot every time.

Do not force correction every time.

Do not click exactly the same pixel every time when a safe clickable area exists.

Do not vary the endpoint outside the known safe target region.

Do not prioritize randomness over accuracy.

Do not use identical duration for all distances.

Do not use random sleeps as the main humanization technique.

Do not let randomness change the actual semantic target.

---

# 32. Recommended first version

Start with a simple, reliable version:

```text
TARGET
    use safe interior click-point variation

PATH
    mostly straight
    small smooth perpendicular deviation

SPEED
    minimum-jerk / smooth bell-shaped velocity

DURATION
    dependent on distance
    optionally target-size-aware

RANDOMNESS
    parameters chosen once per movement
    bounded
    reproducible with seed

CORRECTION
    optional
    small
    not used on every movement

EXECUTION
    continuous intermediate coordinates

CLICK
    only after arrival
```

Do not begin with an unnecessarily complicated biomechanical model.

Make the design modular so a more sophisticated trajectory or velocity model can be substituted later.

---

# 33. Validation checklist

The implementation should be considered successful when all of these are true:

```text
[ ] Mouse no longer teleports between distant coordinates.

[ ] Movement contains enough intermediate coordinates to appear continuous.

[ ] Paths remain mostly direct.

[ ] Paths contain small smooth variation.

[ ] There is no random per-frame jitter.

[ ] Velocity is not perfectly constant.

[ ] Movement accelerates and decelerates smoothly.

[ ] Short moves behave differently from long moves.

[ ] Movement duration generally increases with distance.

[ ] Target size can influence final precision when known.

[ ] The same target does not always use exactly the same pixel.

[ ] Endpoint variation stays inside a safe target region.

[ ] Small targets automatically use less endpoint variation.

[ ] Random movement parameters are chosen once per movement.

[ ] Every movement finishes at its selected safe endpoint.

[ ] Optional corrections are small and not always used.

[ ] Clicking happens after arrival.

[ ] Repeated movements are similar in purpose but not mathematically identical.

[ ] Accuracy remains more important than variation.

[ ] The behavior is centralized and reusable for every coordinate-to-coordinate move.
```

---

# 34. Final behavioral goal

The project should move from this:

```text
CURRENT COORDINATE
        ↓
instant jump
        ↓
EXACT SAME TARGET PIXEL
        ↓
click
```

to this:

```text
CURRENT REAL CURSOR POSITION
        ↓
identify safe target area
        ↓
choose slightly varied safe endpoint
        ↓
generate one coherent movement plan
        ↓
smooth mostly-straight trajectory
        +
natural velocity
        +
smooth acceleration/deceleration
        +
bounded duration variation
        +
small correlated trajectory variation
        ↓
continuous intermediate cursor positions
        ↓
optional tiny correction
        ↓
arrive safely inside target
        ↓
click
```

The final principle is:

> **Humanize the movement from coordinate to coordinate without changing the intended target.**

The destination may vary slightly **inside the known safe clickable area**, while the trajectory, velocity, acceleration, timing, and optional correction vary smoothly and within controlled bounds.

The result should look like a person intentionally moving the mouse toward a target — not a teleport, not a perfect mathematical robot, and not random shaking.

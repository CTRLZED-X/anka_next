# ADR 0001 — Modular Monolith and Immutable SessionPlan

**Status:** Accepted for R5.96.

ANKA remains one local modular process rather than being split into microservices. A launch is compiled into an immutable `SessionPlan` before automation starts. The plan resolves mission, accounts, leader, required/optional membership, active/passive control, policies, route/target parameters, stop conditions and protocol identity.

This keeps local operation fast and debuggable while preventing mutable UI choices or global constants from silently changing a running session. The compiled plan is persisted in session forensics and is the runtime configuration authority.

# ADR 0002 — Canonical State, Game Kernel and Strategy Are Separate Authorities

**Status:** Accepted for R5.96.

ANKA uses three different authorities:

1. **Canonical State** — confirmed live truth from the active protocol adapter.
2. **ANKA Game Kernel** — deterministic Dofus mechanics and legality.
3. **Policies/TeamStrategy** — replaceable tactical/strategic preference.

No layer may substitute for another. FightAI must not guess missing live values. The Game Kernel must not own windows/accounts/live packets. Protocol adapters must not decide tactics. Unknown/partial/conflicting live semantics fail closed where the requested action depends on them.

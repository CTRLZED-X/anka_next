# ADR 0003 — Single Physical Execution Authority

**Status:** Accepted for R5.96.

Platform Core and policies produce semantic intent. Only the execution boundary may select/focus a Dofus client, project a CellId to screen coordinates, send physical input, settle the request and report its result.

`ExecutionCoordinator` is the typed routing façade for new orchestration. The proven lower-level `ExecutionService`, input arbiter, projection and window driver remain intact for the first R5.96 live acceptance run. Their later decomposition must be behavior-preserving and test-driven.

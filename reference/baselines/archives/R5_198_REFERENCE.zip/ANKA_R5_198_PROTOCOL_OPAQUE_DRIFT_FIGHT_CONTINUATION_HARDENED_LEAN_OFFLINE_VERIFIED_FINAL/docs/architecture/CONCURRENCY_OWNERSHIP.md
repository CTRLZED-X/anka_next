# Concurrency and Mutable-State Ownership

## Purpose

ANKA combines capture threads, pending-Launch convergence, worker supervision, party reconciliation,
projection refresh, physical-input arbitration and asynchronous incident export. Correct local locks are
not enough unless mutable-state ownership and lock ordering are explicit.

## Ownership rules

- `ControlAuthorityStore` owns authorization state.
- session/campaign lifecycle state has one parent lifecycle owner; workers do not create a second authority.
- `ExecutionLifecycleGate` serializes the complete operation lifecycle for one account but never authorizes input.
- `ExecutionService._lock` owns mutable per-account execution state and settlement fences.
- `InputArbiter` owns cross-account physical UI exclusivity.
- Canonical State mutation occurs through the canonical event/store boundary.
- incident records are copied into shared state; a mutable local record must never be published and then
  modified outside its protecting lock.
- diagnostic collection is read-only with respect to execution authority.
- runtime-generation replacement invalidates stale runtime facades before they may perform refresh/action work.

## Supported lock order

For physical execution the supported order is:

```text
per-account ExecutionLifecycleGate
  -> per-account ExecutionService state lock
    -> shared InputArbiter lease
      -> input-driver internal synchronization
```

The state lock is released before result observability/incident export callbacks run. The lifecycle gate
remains held until that post-result phase completes, so another account-local action cannot overtake a
critical failure before synchronous control fencing has run.

Diagnostics/status readers may acquire their own small snapshot locks and may read the ExecutionService
state lock; they never acquire input authority.

## Lock/callback rules

1. Do not call filesystem/network/debug-export callbacks while holding the ExecutionService state lock.
2. Do not hold an incident/state lock while performing filesystem/network/process work.
3. Publish complete immutable/copy snapshots to readers rather than partially initialized mutable records.
4. Temporary files used by concurrent incidents must be incident-unique.
5. Shutdown/terminalization must be idempotent.
6. A stale runtime generation must fail closed instead of racing a new generation.
7. Same-thread re-entry into the execution lifecycle is a programming error and fails explicitly.
8. Read multi-field arbiter state through `InputArbiter.snapshot()` rather than independent properties.

## Required race scenarios

Regression suites should cover at least:

- Launch versus Stop;
- terminal startup failure versus late convergence success;
- diagnostic export versus shutdown;
- two simultaneous incidents;
- projection refresh versus runtime-generation replacement;
- CRA and ENU simultaneous physical-input requests;
- account-local second action versus first action result/incident processing;
- observability readiness read versus execution result publication;
- worker exit/restart versus session terminalization.

R5.175 fixed incident-publication/crash-envelope ownership. R5.178 additionally formalizes execution lifecycle
serialization, atomic arbiter diagnostics, operation-phase tracing and post-result lock separation. This document
is the concurrency authority for future changes.

# Declarative Spell Mechanics

## Purpose

Static `Spells.json` / `SpellLevels.json` remains authoritative for spell identity and cast rules. It does not contain the complete per-spell effect graph. Verified mechanics therefore enter through a separate, versioned `SpellMechanicsPack` instead of being hard-coded into spell-specific Python classes.

## Three effect concepts

These are intentionally distinct:

```text
EffectDefinition
    dictionary meaning/metadata for one effect ID

SpellEffectOccurrence
    one ordered configured effect inside one spell grade branch

ActiveEffectInstance
    caller-owned runtime snapshot of an effect currently active on an actor
```

They must never be substituted for one another.

## Mechanics Pack schema

R7/R8 uses spell-mechanics schema version `1`. A source pack contains:

```text
schema_version
pack_version
game_version
source provenance
spells[]
  spell_id
  grades[]
    grade
    normal_effects: null | [] | [occurrences...]
    critical_effects: null | [] | [occurrences...]
    cast_rule_override: null | {verified supplemental fields}
```

Branch semantics are strict:

- `null` = branch mechanics are unknown/not supplied;
- `[]` = branch is verified to contain no effects;
- non-empty list = verified ordered canonical occurrences.

Each file is SHA-256 fingerprinted and provenance is attached to every canonical spell/grade/effect occurrence.

## Effect occurrence

An occurrence preserves:

- spell/grade/branch backreference;
- contiguous zero-based order;
- semantic `MechanicKey`;
- typed mechanic parameter spec;
- optional effect dictionary ID;
- optional canonical AoE;
- optional canonical target semantics;
- explicit area anchor (`TARGET_CELL` or `CASTER_CELL`);
- optional duration/delay/stack-limit/probability;
- provenance;
- explicit unresolved semantic labels.

Missing area/target semantics remain unknown. They are never defaulted to POINT/all targets.

## Typed parameter specs

R7 includes declarative specs for:

- damage;
- heal;
- shield;
- push;
- pull;
- caster-relative recoil;
- teleport marker;
- swap marker;
- apply state;
- remove state;
- AP/MP/range/characteristic change;
- referenced-spell base-damage change.

A spec describes data only. It does not imply that an implementation exists. Damage/heal/shield remain unregistered and unsupported until their formulas are verified.

## Canonical values

`AmountSpec` represents integer fixed/interval absolute values or integer basis-point percentages tied to an explicit reference. `ProbabilitySpec` uses integer basis points (`0..10000`). The Kernel never chooses a random roll from an interval during deterministic prediction.

## Overlay authority

`SpellMechanicsOverlay` validates mechanics against canonical Static spell definitions. It rejects unknown spell IDs/grades, incompatible known game versions, and broken effect/state references when those registries are available.

The raw Static `SpellGradeDefinition` object is preserved exactly. Static remains the base cast-rule source. When current verified evidence proves that the supplied export omits or contradicts a specific cast field, a mechanics grade may carry a narrow explicit `SpellCastRuleOverride`. The overlay exposes that resolved value through `ResolvedSpellGradeView.effective_grade`; `static_grade` is never mutated. R8C supports only `cast_in_diagonal`, and no override is inferred from effect names, historical data, or missing values.

## Public access

```python
mechanics_pack = load_spell_mechanics_pack("verified_mechanics.json")
kernel = GameKernel.load(knowledge_pack, spell_mechanics=mechanics_pack)
view = kernel.spell_mechanics_overlay.require_grade(spell_id, grade)
```

The loader is strict JSON in R7. Additional source adapters may be added later but must normalize into the same canonical models.

## R8A reusable lifecycle/anchor additions

The first real spell integration demonstrated that an occurrence can be centred on the caster even when the cast itself targets another occupied cell. `EffectAreaAnchor` therefore belongs to the generic occurrence model, not to any Cra spell. The immediate resolver uses the caller-owned caster cell only when `CASTER_CELL` is declared; missing caster position remains incomplete.

`max_stacks` is retained as optional declarative lifecycle metadata. It does not itself implement refresh/stack scheduling. Likewise `SpellBaseDamageChangeEffectSpec` stores the affected spell ID and amount but has no spell-specific calculator. Until generic modifier lifecycle/application rules are verified, readiness correctly marks that mechanic prediction-unsupported.

## Bundled verified corpus

The package can ship a curated verified mechanics resource without shipping raw game datasets. `load_bundled_spell_mechanics_pack()` loads this strict schema through package resources. It is intentionally opt-in when constructing `GameKernel`: automatically applying the corpus to arbitrary caller-supplied Static/game versions could silently mix versions. Overlay validation remains the authority that checks spell/grade compatibility.

## R8C verified cast-rule overlay and recoil additions

Flèche Vagabonde demonstrated that a current client rule can be directly evidenced while the supplied Static snapshot contains an older/incomplete field. The Kernel therefore separates **raw source truth** from **verified resolved truth** instead of modifying source records. `SpellCastRuleOverride` is intentionally narrow and provenance-bound to the mechanics pack; only fields required by real evidence should be added.

`RecoilEffectSpec` is the generic inverse-target displacement concept: it moves the caster away from the selected cast target/reference cell. The ordered resolver delegates aligned recoil to the existing `DisplacementService`, so blockers and map boundaries have one authority. Exact diagonal odd-distance forced movement is not generalized from historical behavior and remains unsupported until verified.

## R8D ordered teleport addition

Pas Chassé proves the reusable distinction between the actor affected by a relocation and the selected cast destination. A self-teleport occurrence therefore uses `CASTER_CELL` + `SELF` to identify the affected actor, while the explicit cast target cell is passed to the generic relocation authority as the destination.

`MechanicKey.TELEPORT` is now a supported ordered-resolver adapter for exactly one eligible actor. It delegates to `TeleportService`/`TeleportSpec` rather than duplicating walkability, fight-walkability, or occupancy rules. Successful relocation is projected immutably through `FightProjectionService`. Multi-target teleport sequencing remains unsupported.

Pas Chassé also confirms a `TURN_START` + positive-delay MP modifier. The occurrence is fully representable (`trigger`, `delay_turns`, `duration_turns`) but the immediate resolver still refuses to execute it. One verified spell is not used to invent global delayed-effect scheduling, refresh, or expiration semantics.

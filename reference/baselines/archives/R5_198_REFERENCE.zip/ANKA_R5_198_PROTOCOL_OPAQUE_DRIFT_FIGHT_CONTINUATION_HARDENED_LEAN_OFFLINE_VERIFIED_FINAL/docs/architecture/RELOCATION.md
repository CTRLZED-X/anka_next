# Teleport and Swap Primitives

Teleport behavior varies by mechanic, so `TeleportSpec` makes destination rules explicit:

- require static walkability;
- require fight-walkability;
- require an unoccupied destination.

`TeleportService` evaluates those rules against a static map plus an optional caller-owned `FightContext`. It returns typed deterministic/incomplete results and never moves an actor itself.

`SwapService` is a pure position projection: when both actor cells and map cell definitions are known, it returns each actor's destination as the other's current cell. Spell-specific state/target restrictions remain outside this primitive.

# Semantic Mechanic Registry

`MechanicRegistry` is the central semantic dispatch boundary for reusable mechanics.

It uses typed `MechanicKey` values rather than raw strings. Supported keys resolve to the same authoritative service instances already exposed by `GameKernel` (for example push/pull -> `DisplacementService`, apply/remove-state -> `StateService`).

Known semantic families such as damage/heal/shield exist as keys but are intentionally unregistered until their implementations are verified. `require(...)` raises `UnsupportedMechanicError` rather than silently falling back.

Future effect normalization should produce semantic mechanic keys/bindings and dispatch through this registry instead of creating per-spell engines or scattered string switches.

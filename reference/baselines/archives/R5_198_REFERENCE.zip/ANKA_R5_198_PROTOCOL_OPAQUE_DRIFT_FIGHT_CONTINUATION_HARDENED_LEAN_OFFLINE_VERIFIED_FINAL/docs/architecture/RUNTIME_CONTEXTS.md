# Caller-Owned Runtime Contexts

The Kernel defines runtime value shapes but never owns the live state.

`ActorState` is immutable and can carry:

- signed runtime actor identity;
- team identity;
- current cell;
- HP/AP/MP snapshots;
- active state IDs;
- characteristic values supplied by the caller;
- per-spell cooldown snapshots;
- alive status;
- summon/summoner relationship.

`FightContext` is an immutable snapshot containing actor values, round number, active actor identity, and optional canonical `map_id`. It derives actor lookup views without polling, mutation, networking, or reduction. `occupied_cells` is a complete frozenset only when every potentially-live actor position is known; otherwise it is `None`, preserving UNKNOWN occupancy rather than silently treating missing actors as absent.

This preserves the dependency rule:

```text
future live reducer -> construct ActorState/FightContext -> call Kernel
```

Never the reverse.

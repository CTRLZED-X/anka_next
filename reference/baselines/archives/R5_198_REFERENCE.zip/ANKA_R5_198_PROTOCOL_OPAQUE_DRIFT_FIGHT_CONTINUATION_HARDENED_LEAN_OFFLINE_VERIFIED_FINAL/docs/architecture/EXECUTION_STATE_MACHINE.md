# Execution State-Machine and Serialization Authority

## Purpose

R5.178 preserves one physical-input authority while separating three different concurrency concerns that
must not be conflated:

1. `ExecutionLifecycleGate` serializes the **complete per-account operation lifecycle**, including the
   short post-result control/diagnostic phase. It is serialization only; it does not authorize input.
2. `ExecutionService._lock` protects mutable execution state and the decision/send/settlement critical
   section. External observability callbacks do not run while this lock is held.
3. `InputArbiter` serializes physical UI ownership **across accounts**. It is the only cross-account input
   lease and remains independent from control authorization.

`ControlAuthorityStore` remains the authority that decides whether physical control is permitted.

## Runtime operation contract

Public runtime operation names are registered in `execution/operation_contracts.py`. Each immutable
`RuntimeOperationSpec` owns:

- the private `ExecutionService` handler;
- the operation domain;
- request decoration rules;
- combat-result normalization policy.

Adding an operation must update the registry and its contract tests instead of adding another dispatch
branch in the public facade.

## Lifecycle phases

The diagnostic `ExecutionOperationTracker` publishes these phases:

```text
CREATED
  -> START_OBSERVABILITY / AUTHORIZATION     (window/heartbeat boundaries)
  -> WAITING_EXECUTION_LOCK
  -> EXECUTING
  -> RESULT_OBSERVABILITY
  -> COMPLETED
```

Normal registered runtime actions start at `CREATED -> WAITING_EXECUTION_LOCK` because authorization and
action-start journaling currently occur inside the serialized execution half. The tracker is read-only and
never grants authority.

A runtime/debug package can therefore distinguish:

- waiting for the per-account state lock;
- executing/settling an action;
- waiting inside result/incident observability;
- completed execution;
- cross-account input-lease contention.

## Lock and callback order

For one account, the supported order is:

```text
ExecutionLifecycleGate
    -> ExecutionService state lock
        -> shared InputArbiter lease (only around physical UI sequence)
            -> input-driver internal synchronization
    <- release ExecutionService state lock
    -> result observability / incident trigger
<- release ExecutionLifecycleGate
```

Important rules:

- no filesystem/network/debug-export callback while `ExecutionService._lock` is held;
- a second operation cannot overtake result observability, so a critical result can fence control before
  the next account action begins;
- status/readiness readers may acquire the state lock while result observability runs;
- cross-account UI sequences remain serialized by `InputArbiter`;
- same-thread re-entry into the lifecycle gate is rejected explicitly rather than deadlocking;
- diagnostics read atomic `InputArbiter.snapshot()` and execution concurrency snapshots; they cannot send
  input or mutate execution state.

## Why there are two per-account locks

Using only the state lock caused observability/control-fencing callbacks to participate in the mutable-state
lock order. Releasing it before callbacks removed that inversion, but by itself could allow the next action
to overtake a critical result. The lifecycle gate solves that second problem without making diagnostics a
state owner.

The state lock is therefore narrow and mutation-oriented; the lifecycle gate is broad and sequencing-oriented.

## Regression invariants

R5.178 tests enforce that:

- all supported runtime operations are registered and map to real handlers;
- result observability can read execution readiness from another thread without deadlock;
- another action waits while the previous action is in result observability;
- `InputArbiter` exposes one atomic ownership snapshot and reports waiters;
- an in-flight operation is visible to Diagnostics V2 even before a final action row exists;
- same-thread lifecycle re-entry fails explicitly;
- existing execution semantics continue to pass the retained execution suite.

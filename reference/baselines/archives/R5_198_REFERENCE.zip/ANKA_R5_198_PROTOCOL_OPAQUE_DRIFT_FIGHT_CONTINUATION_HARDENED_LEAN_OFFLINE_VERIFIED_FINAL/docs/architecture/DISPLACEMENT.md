# Displacement, Push/Pull, and Collision Boundary

`DisplacementService` owns forced-movement path resolution, not damage.

The low-level `resolve_path(...)` accepts an explicit ordered path of canonical four-neighbor cells and evaluates each step against:

- static walkability;
- fight-walkability restrictions;
- caller-supplied runtime occupancy;
- available static map definitions.

It never mutates actors or the map.

Aligned `plan_push(...)` and `plan_pull(...)` derive straight four-neighbor paths from source/target geometry. Non-aligned source/target relationships remain `UNSUPPORTED` until their exact Dofus semantics are verified. `resolve_push(...)` / `resolve_pull(...)` compose those plans with blocker resolution.

Map edges are represented as a typed `MAP_BOUNDARY` blocker. No synthetic off-map cell IDs are created.

`CollisionService` converts a resolved forced movement into structural collision facts: moved distance, remaining requested distance, blocker source/cell, and certainty. It deliberately does **not** calculate pushback/collision damage.

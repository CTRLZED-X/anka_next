# Active Status Semantics

R6C adds detailed caller-owned runtime status snapshots without changing the Kernel boundary. The Kernel can reason about active state/effect identity, optional source actor/spell, and normalized remaining duration, but it never owns the live reducer that refreshes those values.

## Runtime instances

`ActiveStateInstance` and `ActiveEffectInstance` are immutable snapshot records:

- semantic `StateId` / `EffectId`;
- optional `source_actor_id`;
- optional `source_spell_id`;
- optional `turns_remaining`.

Known `turns_remaining` must be at least 1 because the record describes an instance that is active in the current snapshot. `None` means the duration was not observed/normalized.

The term "turns" is a normalized duration counter supplied by the caller. R6C does not claim which raw protocol event decrements that counter. Live adapters/reducers must establish that from verified evidence.

## Unknown versus empty

Detailed snapshots use three distinct states:

```text
active_states = None   -> detailed state snapshot unknown
active_states = ()     -> detailed snapshot known and empty
active_states = (...)  -> detailed active instances known
```

The same rule applies to `active_effects`.

`ActorState.active_state_ids` remains the compatibility/coarse presence view used by state criteria. When detailed states are supplied and the coarse set is unknown, `ActorState` derives the ID set. If both are supplied they must agree.

## Duration forecasting

A single active instance can answer `active_after_ticks(n)`:

- `n == 0`: active now;
- known remaining duration: active iff `turns_remaining > n`;
- unknown remaining duration at `n > 0`: unknown.

`GameKernel.status_queries` exposes this through state/effect presence, remaining-turn, and future-activity queries.

## Duplicate instances

Multiple detailed instances with the same state/effect ID are allowed because the Kernel must not assume that the game cannot stack, refresh, replace, or preserve separate sources.

R6C therefore does not collapse duplicate durations with `min`, `max`, `sum`, or last-write-wins. Queries that require one aggregated remaining duration become incomplete and report an `instance_aggregation` missing semantic.

## Effect boundary

Runtime `ActiveEffectInstance` is not a spell effect definition and does not imply effect magnitude. The supplied Static `Effects.json` remains a dictionary of effect definitions only. R6C stores runtime effect identity/source/duration when a caller has already normalized them; it does not decode raw effect arguments or calculate their impact.

## State engine boundary

The existing `StateService` remains the authority for pure coarse apply/remove set projections. It is intentionally not extended to refresh or stack timed instances because those update rules are spell/effect-specific and not yet verified.

## Non-goals

R6C does not implement effect magnitude, stacking/refresh rules, dispels, duration decrement scheduling, spell effect-instance decoding, damage/heal/shield formulas, packet parsing, execution, or an external bot runtime dependency.

# Static Canonical Catalog

The combined Knowledge Pack now normalizes the following user-supplied static files into immutable registries:

- `Breeds.json` → `kernel.classes`;
- `Spells.json` + `SpellLevels.json` → `kernel.spells`;
- `SpellStates.json` → `kernel.states`;
- `Effects.json` → `kernel.effects`;
- `SpellVariants.json` → `kernel.spell_variants`;
- `Monsters.json` → `kernel.monsters`;
- `SuperAreas.json` → `kernel.super_areas`;
- `Areas.json` → `kernel.areas`;
- `SubAreas.json` → `kernel.sub_areas`;
- `MapPositions.json` → `kernel.map_locations` for the active Mapuse working set.

Every registry stores canonical immutable definitions; raw source field names remain inside the source adapters. Cross-file references are validated before exposure.

## Active map locations

The complete `MapPositions.json` source contains `worldMap=-1` sentinels and several references to a subarea absent from the supplied `SubAreas.json`. The Kernel therefore does not pretend the whole file is globally clean. It normalizes only maps in the active `Mapuse` set, validates their subarea references, and represents `worldMap=-1` explicitly as `world_map_id=None`.

This preserves the user's workflow: adding a map to Mapuse selects the tactical map and activates its static world-location normalization without hard-coded map IDs.

## Current monster boundary

The supplied `Monsters.json` supports canonical monster identity plus grade/level ladders. It does not provide the complete grade stats, resistances, spellbooks, or special mechanics required for full monster combat simulation. Those fields remain future source-adapter work rather than inferred values.

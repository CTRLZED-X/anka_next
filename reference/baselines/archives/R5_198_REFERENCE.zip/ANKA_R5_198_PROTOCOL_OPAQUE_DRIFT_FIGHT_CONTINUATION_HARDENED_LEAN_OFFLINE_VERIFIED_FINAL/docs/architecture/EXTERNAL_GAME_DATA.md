# External Game Data Startup

## Purpose

`GameKernel.start()` is the ANKA runtime filesystem entry point for the caller-owned `Static` and `Mapuse` directories. It does not introduce a second normalization path: after preflight validation, it delegates to the existing combined Knowledge Pack builder.

## ANKA project defaults

```text
Static: <project>\gamedata\Static
Mapuse: <project>\gamedata\Mapuse
```

The directory names/paths are integration configuration only. The Kernel does not import, call, or depend on AnkaBot.

## Public API

```python
from anka_game_kernel import GameKernel

kernel = GameKernel.start()
```

For explicit configuration:

```python
from anka_game_kernel import ExternalGameDataConfig, GameKernel

kernel = GameKernel.start(
    ExternalGameDataConfig(
        static_directory=r"C:\GameData\Static",
        mapuse_directory=r"C:\GameData\Mapuse",
        static_source_version="static-current",
        mapuse_source_version="mapuse-current",
        pack_version="runtime-pack-v1",
        game_version=None,
    )
)
```

Environment overrides:

```text
ANKA_KERNEL_STATIC_DIR
ANKA_KERNEL_MAPUSE_DIR
ANKA_KERNEL_STATIC_SOURCE_VERSION
ANKA_KERNEL_MAPUSE_SOURCE_VERSION
ANKA_KERNEL_PACK_VERSION
ANKA_KERNEL_GAME_VERSION
```

## Preflight contract

Before normalization starts, the configuration validates:

1. `Static` exists and is a directory.
2. `Mapuse` exists and is a directory.
3. All Static files consumed by the current canonical loaders exist.
4. `Mapuse` contains at least one `map_*.json` file, matching the actual map loader contract.

Current required Static inputs are:

```text
Areas.json
Breeds.json
CompanionSpells.json
Companions.json
Effects.json
MapPositions.json
MonsterRaces.json
MonsterSuperRaces.json
Monsters.json
SpellLevels.json
SpellStates.json
SpellVariants.json
Spells.json
SubAreas.json
SuperAreas.json
```

Missing inputs raise `ExternalGameDataError` before a partial Knowledge Pack can become public.

If reading, JSON parsing, strict source validation, normalization, or canonical registry construction fails, `GameKernel.start()` raises `ExternalGameDataError` with the configured Static and Mapuse paths and preserves the original exception as the cause.

## Data flow

```text
caller-owned Static directory
             +
caller-owned Mapuse directory
             |
             v
ExternalGameDataConfig validation
             |
             v
existing source loaders
             |
             v
existing normalization
             |
             v
canonical KnowledgePack
             |
             v
GameKernel
             |
             +--> registries
             +--> geometry / casting / movement / fight queries
             +--> spell overlay / readiness / effect resolver
```

Raw JSON is never exposed as the mechanic API and is not duplicated inside the Kernel package.

## Ownership boundary

The Kernel owns validation, normalization, immutable canonical definitions, registries, and deterministic mechanics. The ANKA caller owns the filesystem locations and updates the external data in place.

This startup feature does **not** add packet decoding, live listeners, AnkaBot execution, Lua execution, browser automation, mutable live fight ownership, or AI strategy.

# Fight Cast Evaluation

## Purpose

`FightService.evaluate_cast(...)` is the first high-level deterministic fight composition in the Kernel. It answers:

> Given a static cast-rule bundle plus an explicit caller-owned fight snapshot, do the currently implemented cast-legality rules prove this cast legal, illegal, incomplete, or unsupported?

It does **not** reimplement the underlying mechanics. It composes the existing authoritative services for:

1. cast availability: AP, cast counts, cooldown, and canonical state criterion;
2. range/alignment;
3. line of sight when the spell requires it;
4. target-cell free/taken constraints.

Effect applicability is intentionally separate. An effect target mask describes whether a particular effect applies to a particular actor class; it is not automatically a rule forbidding the spell from being cast on the target cell.

## Canonical inputs

`CastEvaluationSpec` contains reusable static rules:

- `availability: CastAvailabilitySpec`;
- `range: RangeSpec`;
- `target_cell: TargetCellSpec`;
- `requires_line_of_sight: bool`.

`CastEvaluationContext` contains caller-owned runtime/static references needed for one evaluation:

- canonical `MapDefinition`;
- caster `CellId`;
- target `CellId`;
- nested `CastAvailabilityContext`;
- range bonus;
- optional immutable occupied-cell snapshot.

`occupied_cells=None` means the runtime occupancy snapshot is unknown. It never means that the fight contains no occupants.

## Composition rule

All applicable component services are evaluated through their own public mechanic implementations. The fight facade does not copy AP arithmetic, range math, LoS tracing, or target-cell rules.

The aggregate result keeps each component result so callers can explain *why* a cast succeeded or failed.

### Deterministic failure dominance

A known independent illegality is enough to prove the whole cast illegal.

For example, if the target is deterministically outside maximum range while the AP snapshot is missing, the overall result is still:

```text
certainty = DETERMINISTIC
legal = False
failed_stages = (RANGE,)
```

The missing AP value cannot make an out-of-range cast legal.

The same principle applies when another independent component is unsupported. A deterministic range or availability failure remains a deterministic cast failure even if arbitrary-angle LoS cannot yet be evaluated.

## Indeterminate results

When no component proves the cast illegal:

- any required `UNSUPPORTED` component makes the aggregate result `UNSUPPORTED`;
- otherwise missing caller-owned inputs are merged in stable pipeline order and return `DETERMINISTIC_IF_CONTEXT_COMPLETE`;
- otherwise every implemented constraint is deterministic and satisfied, so the cast is `DETERMINISTIC` and legal.

The result never converts unsupported or missing information into a guessed boolean.

## Pipeline stages

`CastEvaluationStage` identifies only stages that deterministically failed:

- `AVAILABILITY`;
- `RANGE`;
- `LINE_OF_SIGHT`;
- `TARGET_CELL`.

Multiple independent failures may be reported in that stable order.

## Public API

```python
result = kernel.fight.evaluate_cast(spec, context)

if result.legal is True:
    ...
elif result.legal is False:
    print(result.failed_stages)
else:
    print(result.certainty, result.missing_inputs)
```

The caller remains responsible for obtaining and owning current AP, cooldowns, cast counters, states, occupancy, positions, and all other live fight state.

## Explicitly outside this slice

This composition does not yet decide:

- arbitrary-angle Dofus2 LoS;
- effect damage/healing/shields;
- push/pull/teleport/collision;
- summon limits unless represented by a future verified mechanic;
- state application/removal lifecycle;
- tackle/dodge;
- spell execution;
- strategy or candidate scoring.

Future mechanics can be composed into the same result pipeline only after they have an independent canonical implementation and verified tests.

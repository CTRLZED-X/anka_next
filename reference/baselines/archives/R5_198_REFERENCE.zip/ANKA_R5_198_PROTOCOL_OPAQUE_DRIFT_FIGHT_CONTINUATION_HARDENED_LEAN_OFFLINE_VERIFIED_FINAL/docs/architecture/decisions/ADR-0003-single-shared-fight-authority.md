# ADR-0003: Single Shared Fight Authority

**Status:** Accepted

## Decision

A party fight has one shared orchestration authority. Per-account lanes remain isolated sources/executors, but they do not run independent fight loops. Shared fight state determines the active actor, maps it to the owning account, then dispatches that account's selected policy.

## Consequences

Adding accounts must extend party/session composition, not create another fight manager loop. Non-party turns are observed without invoking account policy. One combat step authorizes at most one semantic/physical action.

# ADR-0001: Modular-Monolith Platform Core

**Status:** Accepted for staged migration

## Decision

ANKA will remain one local modular application. The new Platform Core is an architectural boundary composed of small typed modules, ports and state machines. It must not become one global `PlatformKernel` god object and it must not be split into microservices.

## Consequences

Missions and Script Studio compose sessions through public core contracts. Infrastructure such as protocol adapters, window input, capture and web UI stays behind adapters. Existing runtime paths remain available until replacement paths prove parity.

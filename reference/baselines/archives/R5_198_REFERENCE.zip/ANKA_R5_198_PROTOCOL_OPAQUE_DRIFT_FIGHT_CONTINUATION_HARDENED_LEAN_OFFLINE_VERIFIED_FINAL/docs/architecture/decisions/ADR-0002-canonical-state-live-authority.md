# ADR-0002: Canonical State Is Live Authority

**Status:** Accepted

## Decision

Confirmed Canonical State remains the only live gameplay truth used for automation decisions. Execution results are evidence about an attempted action; they do not directly rewrite live gameplay state.

## Consequences

Policies reason from canonical snapshots. After accepted physical actions, orchestration waits for canonical progress/settlement before re-planning. Protocol-specific representations must be translated before they reach the Platform Core.

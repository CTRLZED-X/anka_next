# Pre-Spell Decision Semantics — R8E V2

## Purpose

The pre-spell decision layer supplies generic immutable semantics needed by real spell declarations without embedding live runtime ownership or spell-specific engines. R8E retains the R7/R8 models and corrects their authority/readiness interpretation under the V2 rule: deterministic-first projection, live-authoritative runtime truth.

## 1. Canonical semantic characteristics

`CharacteristicKey` and `SemanticCharacteristics` provide sparse semantic combat values when raw source IDs are not authoritative in the supplied Static corpus. Missing semantic values remain `None`, never zero. AP/MP/PO, lock/dodge, shields, and elemental resistances remain in their established canonical homes rather than being duplicated.

## 2. Actor taxonomy

`ActorKind` identifies player/monster/companion/other/unknown identity. `SummonKind` is orthogonal and applies only when `summoned=True`. `ActorState` may carry the matching canonical class/monster/companion identity reference; contradictory combinations fail validation.

## 3. Rich effect targeting

`EffectTargetSpec` composes the existing self/team/summon classes with optional actor-kind and summon-kind restrictions. Missing taxonomy required by a filter produces an incomplete result; it is never widened to all actors.

## 4. Conditions

`EffectConditionSpec` provides a small canonical condition language for state presence/absence, actor kind, and summoned/not-summoned predicates over caster or target. `ALL`/`ANY` preserve deterministic dominance while otherwise keeping missing context incomplete.

## 5. Trigger, delay, probability, and lifecycle authority

`SpellEffectOccurrence` represents immediate and non-immediate triggers, delay, probability, duration, stacking metadata, and provenance without creating a scheduler.

R8E distinguishes three cases:

- immediate deterministic mechanics may be projected when a verified generic authority exists;
- server-side random activation emits `RANDOM_OUTCOME` and is not rolled locally;
- selected future resource/status/modifier lifecycle effects may emit `STATUS_LIFECYCLE` when the structure is verified but the future authoritative state is intentionally left to live observation.

A future positional effect is not automatically reduced to `STATUS_LIFECYCLE`; if exact positional timing/geometry is required and unsupported, it remains an actual unsupported blocker.

## 6. Caller-owned turn/action history and hypothetical composition

`FightContext.current_turn` holds immutable caller-owned `TurnActionHistory` with `CastRecord` and `MovementRecord` values.

The Kernel does not own confirmed history. For hypothetical decision making, R8E may create a new projected history:

- legal spell cast -> own AP spend + new hypothetical `CastRecord`;
- deterministic movement -> own MP spend + new hypothetical `MovementRecord`;
- sequential callers may feed the projected context into the next hypothetical query so AP/MP and cast counters compose.

This projected history is conditional on action execution and is never server-confirmed truth.

## 7. Declarative modifier homes

Canonical parameter specs exist for AP/MP/range/characteristic changes and spell-base-damage modifiers. Their structural presence does not imply that the Kernel should reproduce final live outcomes.

By current policy:

- dodgeable AP/MP removal result is live-authoritative;
- characteristic/spell-base-damage modifier lifecycle may be structurally known while live/runtime lifecycle remains required;
- fixed guaranteed resource changes are projected only when exact generic application/lifecycle rules are verified and the project has not delegated them to live authority.

No spell-specific shortcut is allowed.

## 8. Typed live-observation requirements

`LiveRequirementKind` and `LiveObservationRequirement` make intentional live authority machine-readable. They identify semantic outcome type and optional actor/spell/effect occurrence traceability but contain no packet/network/waiting behavior.

The Kernel says "this outcome requires live observation". The future runtime layer decides how to obtain and reconcile it.

## 9. Spell readiness diagnostics

`GameKernel.spell_readiness` now separates:

- `structurally_ready`: verified mechanics have a canonical representation;
- `projection_ready`: every deterministic outcome the Kernel intentionally owns is correctly projectable;
- `live_requirements`: known outcomes deliberately delegated to live observation;
- `unsupported_blockers`: known required deterministic mechanics not yet supported;
- `unknown_blockers`: rules/values not sufficiently verified.

`prediction_ready` is retained only as a compatibility alias for `projection_ready`.

A damage spell does not need a final damage calculator to be projection-ready. Damage/HP may be valid live requirements. Unknown directional AoE or unsupported deterministic displacement remains a true blocker.

## 10. Cast area and effect AoE

Cast-target cells and effect cells are always distinct canonical concepts.

`FightService.legal_target_cells_for_grade(...)` evaluates legal targets from Static/effective cast rules and caller context. Effect AoE is resolved only after selecting one legal target. Missing caster context returns unknown legal-cell collections (`None`), not a fake empty set.

## 11. Current generic readiness boundaries

The Kernel still does not claim complete support for:

- arbitrary-angle Dofus LoS outside the verified straight/diagonal subset;
- all modern AoE/oriented-zone primitives;
- every special target-mask predicate;
- multi-target displacement interaction/sequencing;
- diagonal odd-distance forced-movement traversal/collision semantics;
- rich universal status stack/refresh/dispel scheduling;
- summon stat/spellbook semantics;
- exact final live-authoritative damage/heal/shield/AP/MP/collision outcomes.

The last category is intentionally live-required, not an implementation defect. The others remain UNKNOWN/UNSUPPORTED according to evidence.

## 12. Permanent integration rule

For every real spell:

1. resolve current identity/grades from Static;
2. preserve Static-owned cast truth;
3. research and encode only verified missing effect-graph/mechanic facts;
4. keep normal/critical branches and occurrence order explicit;
5. keep cast area separate from effect AoE;
6. route each occurrence through one generic mechanic authority;
7. classify outputs as deterministic / live-required / unknown / unsupported;
8. run readiness per grade/branch;
9. add regression coverage;
10. never backfill unknown grades from historical versions.

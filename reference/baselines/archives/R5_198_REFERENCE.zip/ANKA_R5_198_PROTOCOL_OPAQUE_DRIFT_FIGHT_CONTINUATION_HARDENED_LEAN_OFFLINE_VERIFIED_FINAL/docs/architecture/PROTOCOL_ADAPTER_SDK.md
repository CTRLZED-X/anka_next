# Protocol Adapter SDK Boundary — R5.192

## Goal

A Dofus protocol update is localized above the canonical-event boundary. Campaign, FightAI, Kernel, projection and physical execution do not know raw wire names or packet shapes.

```text
wire bytes
   ↓
framing / classification
   ↓
version-local capability handler modules
   ↓
version-local ProtocolAdapter facade + runtime context
   ↓
CanonicalEventEnvelope
   ↓
Canonical State
   ↓
World / Fight / AI / Execution
```

## Concrete-version isolation

A concrete package `adapters/dofus_X/` may import shared generic protocol SDK primitives, but it must not import/subclass `adapters/dofus_Y/`. Every current adapter owns its own facade, runtime context, handler registry, capability declaration and wire catalog. This lets historical adapters remain frozen while a new client build evolves independently.

`verify_protocol_upgrade_contract.py` statically enforces this rule for the active adapter.

## Handler SDK and runtime context

`ProtocolHandlerRegistry` composes immutable capability modules. Each module declares the canonical capabilities and wire bindings it owns. One version-local mutable runtime context owns inferred identity, fight generation, map/resource shadows, effects and pending causal requests.

Decoder state is staged, not canonical truth. One raw-message transformation is transactional:

```text
checkpoint adapter context
        ↓
transform raw message
        ↓
canonical event batch
        ↓
atomic CanonicalStateStore transaction
        ↓
SUCCESS → keep adapter context
FAILURE → rollback canonical transaction + restore adapter context
```

Typed transform issues remain `SCHEMA_DRIFT`, `MALFORMED_PAYLOAD`, `UNSUPPORTED_SEMANTIC` or `ADAPTER_INTERNAL_ERROR`; higher layers do not infer control semantics from exception text.

## Semantic execution boundary

Execution asks for stable operations such as `MOVE_REQUEST`, `CAST_REQUEST`, `READY_REQUEST`, `END_TURN_REQUEST` and `WORLD_ATTACK_REQUEST`. The selected adapter owns the raw message mapping. Observability may render both semantic and active raw name, but must resolve that mapping dynamically from the active manifest.

The union of registered raw wire names is forbidden in generic Python source outside the protocol package. This prevents stale historical vocabulary from misleading future debugging or protocol integration.

## Certification layers

R5.192 separates four complementary layers:

1. **Capability declaration** — what canonical semantics the adapter claims to support.
2. **Current-build evidence provenance** — which supplied current-build artifacts/hashes support each capability and whether support is `VERIFIED` or `PARTIAL`.
3. **Scenario contract** — cross-capability/event-ordering behavior required by the automation chain.
4. **Hash-bound attestation** — binds the released adapter files to the certified implementation.

Historical captures remain regression evidence. They do not by themselves create current-build provenance.

## Required scenario layer

The adapter contract must cover the automation-critical relationships:

- world-to-fight entry;
- party create/join;
- world/fight MapId separation;
- placement-to-Ready;
- Ready-to-first-turn;
- movement-to-CellId/MP;
- cast-to-AP/damage/cooldown;
- End Turn-to-next-owner;
- fight-end-to-world re-entry.

This exists because individual capability coverage cannot prove event-order/state-reducer integration. A scenario may remain explicitly live-pending; that limitation is reported rather than hidden.

## Static game-data compatibility

Network protocol and static mechanics data are independent authorities. `gamedata/COMPATIBILITY.json` records whether the bundled static pack is usable for the current client build/scope. A new Dofus update may require a protocol adapter update, a static-data update, both, or neither.

## Installation boundary

Normal R5.192 setup installs ANKA non-editably. `runtime_install_contract.py` binds the installed distribution to the exact runtime source/protocol tree. If GPT integrates a new adapter after setup, `start.bat` blocks until setup is rerun; the new source cannot be silently ignored by stale site-packages code.

## Safe upgrade workflow

1. preserve the historical adapter;
2. create the current version-local package;
3. decode only evidence-supported semantics;
4. attach current-build provenance and scenario evidence;
5. record static-data compatibility;
6. keep generic layers wire-agnostic;
7. run protocol-upgrade + SDK + historical regression gates;
8. regenerate attestation;
9. rerun setup to bind the installed runtime;
10. run one bounded Windows/Dofus acceptance fight.

Capability/scenario isolation localizes maintenance; it does not weaken physical-input safety. Drift or insufficient authority may still fence automation globally until truth is known safe.

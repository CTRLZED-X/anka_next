# R5.180 Transactional Live Truth Architecture

## Goal

The live decoder, Canonical State journal and in-memory projection must advance as one coherent logical history. A disk/reducer/decoder failure must never leave one layer ahead of another or be misdiagnosed as the wrong subsystem.

## Transaction boundary

```text
raw protocol message
        ↓
check Canonical Store write health
        ↓
checkpoint version-local adapter runtime context
        ↓
transform raw message
        ↓
canonical event batch
        ↓
reduce full batch in memory
        ↓
BEGIN IMMEDIATE
        ↓
insert canonical journal rows
write terminal-fight evidence
write due checkpoints
        ↓
COMMIT
        ↓
publish in-memory canonical snapshot
```

The adapter's transformed inference state becomes accepted only when the Canonical State batch commits successfully.

## Failure semantics

### Adapter transform failure

Restore the adapter checkpoint. Canonical State is unchanged. The failure remains protocol-owned.

### Adapter checkpoint/restore failure

The decoder context cannot be proven coherent. Halt ingestion and fence live control through runtime health/preflight.

### Reducer or canonical sequence failure

No SQLite mutation is attempted because the full batch is reduced before `BEGIN IMMEDIATE`. Restore adapter context, report canonical reducer/sequence ownership, and halt ingestion.

### Persistence failure before commit

Rollback the transaction, restore adapter context and fence the store. Even when rollback succeeds, the current store instance stays fenced because the failure boundary must be explicit and recovery should replay durable state from a fresh connection.

### Commit acknowledgement ambiguity

If SQLite may have committed but the caller receives an exception, the process must not guess. Keep the in-memory snapshot at the pre-transaction revision, fence the store, close/reopen, then rebuild from the durable journal/checkpoint history.

## Recovery contract

A fenced store does not accept more canonical writes. Live ingestion checks the fence before adapter classification/transform. The safe recovery boundary is reopen/replay (or rebuilding the account lane/runtime generation) so the durable journal determines the single authoritative revision before processing new packets.

## Failure attribution

Do not collapse these domains into `PROTOCOL_TRANSFORM_FAILURE`:

- `PROTOCOL_CONTEXT_CHECKPOINT_FAILURE`;
- `PROTOCOL_CONTEXT_RECOVERY_FAILURE`;
- `CANONICAL_REDUCER_FAILURE`;
- `CANONICAL_SEQUENCE_ERROR`;
- `CANONICAL_PERSISTENCE_FAILURE`;
- `CANONICAL_STORE_FENCED`.

Diagnostics and readiness consumers should preserve the first broken owner and treat protocol-context/canonical durability fences as higher severity than ordinary recoverable transform errors.

## Protocol-change resilience

Versioned adapters remain replaceable behind `ProtocolAdapter` and `CanonicalEventEnvelope`. SDK-enabled adapters with mutable inference state must implement transactional context checkpoint/restore hooks. A Dofus wire change should modify the owning versioned capability module/certificate, not Campaign, FightAI, Kernel or Execution.

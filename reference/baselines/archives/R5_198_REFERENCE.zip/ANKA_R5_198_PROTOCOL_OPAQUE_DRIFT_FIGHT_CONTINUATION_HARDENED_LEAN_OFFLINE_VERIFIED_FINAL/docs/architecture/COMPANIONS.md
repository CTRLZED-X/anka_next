# Companion Static Knowledge

The supplied `Companions.json` and `CompanionSpells.json` form a clean cross-referenced source:

- companion identity/name;
- companion-spell link IDs;
- canonical spell IDs for each link;
- grade-by-level thresholds.

The adapter validates that every companion-spell references an existing companion and canonical spell, and that each companion's listed link IDs exactly match the records in `CompanionSpells.json`.

This is definition knowledge only. It does not invent companion runtime stats or AI behavior.

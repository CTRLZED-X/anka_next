# Diagnostics V2 Architecture

R5.177 introduces a read-only diagnostic architecture that sits beside the existing observability exporter without becoming a second execution/control authority.

## Goals

Diagnostics must answer, from one incident package:

1. Which system boundary broke first?
2. Which component owns that boundary?
3. Which later failures are consequences rather than independent causes?
4. Which evidence sections are complete, partial, empty, not applicable, or failed?
5. Is the package itself sufficient to diagnose the identified failure domain?

## Read-only authority

`anka_platform.observability.diagnostics_v2` may read already-captured facts and failure metadata. It must not import or call physical execution, campaign mutation, control-plane mutation, Canonical State mutation, or Party runtime mutation APIs.

The architecture tests enforce this import boundary.

## Immutable diagnostic snapshot

`DiagnosticSnapshot` is the hand-off contract from the legacy exporter to Diagnostics V2. It contains already-collected evidence only: session, control authority, startup preflight, capture/protocol evidence, canonical events, projection evidence, execution actions, diagnostic events, campaign/runtime status, environment/release identity, the legacy root candidate, and the existing action boundary trace.

This allows the exporter to be migrated incrementally without rewriting all collection logic in one release.

## Independent collectors

The default collectors are:

- `session`
- `control_authority`
- `startup`
- `capture_protocol`
- `canonical_state`
- `projection`
- `execution`
- `party_campaign`
- `environment`

Each collector returns a stable `CollectorResult` with status, detail, duration, payload, and collector-local error type. A collector exception is contained and recorded as `FAILED`; it never aborts the rest of the incident bundle.

Collector states are:

- `COMPLETE` — evidence was collected normally.
- `EMPTY` — collection succeeded and the observed set is legitimately empty.
- `PARTIAL` — evidence exists but is incomplete/degraded.
- `NOT_APPLICABLE` — this subsystem was not reached for the incident scope.
- `FAILED` — this collector itself failed.

`EMPTY` and `NOT_APPLICABLE` are intentionally distinct from missing/failed evidence.

## Normalized boundary graph

Diagnostics V2 normalizes heterogeneous failure/boundary vocabulary into this causal lifecycle:

1. `SESSION_CONTROL_AUTHORITY`
2. `CLIENT_PROCESS_IDENTITY`
3. `CAPTURE_TRANSPORT`
4. `PROTOCOL_TRANSFORM`
5. `CANONICAL_STATE`
6. `STARTUP_BOOTSTRAP`
7. `PROJECTION_INTERACTION_AUTHORITY`
8. `CAMPAIGN_LIFECYCLE`
9. `FIGHT_DECISION`
10. `ACTION_ADMISSION`
11. `PHYSICAL_INPUT_DELIVERY`
12. `CLIENT_SEMANTIC_ACCEPTANCE`
13. `CANONICAL_SETTLEMENT`

Each `BoundaryObservation` is `PROVEN`, `BLOCKED`, `UNKNOWN`, or `NOT_APPLICABLE` and records owner, failure code, evidence, and sources.

The typed Failure Registry remains the authority for the failure code's default domain, owner, and boundary. Diagnostics V2 may combine that authority with runtime boundary evidence but must not invent gameplay semantics from raw protocol data.

## Root-cause graph

`build_root_cause_graph()` produces:

- a primary root boundary/failure/owner/confidence;
- normalized observations;
- ordered lifecycle nodes/edges;
- downstream consequences that were not reached or could not be proven after the root boundary;
- evidence gaps.

The graph preserves the old causal/root files for backward compatibility; it is an additional normalized interpretation, not a replacement of evidence.

## Root evidence contract

For the identified failure domain, Diagnostics V2 declares the collector set required to diagnose that class of failure. It then reports `COMPLETE`, `PARTIAL`, or `INSUFFICIENT` root evidence.

Examples:

- protocol failure: capture/protocol + canonical + environment;
- input/execution failure: control + projection + execution + canonical;
- startup failure: session + control + startup + capture/protocol + environment.

This makes “one package is enough” an executable contract rather than a hope.

## Bundle artifacts

R5.177 adds:

- `analysis/diagnostics_v2.json`
- `analysis/root_cause_graph_v2.json`
- `analysis/boundary_observations_v2.jsonl`
- `analysis/DIAGNOSIS_V2_READ_ME_FIRST.txt`
- `analysis/collectors/<collector>.json`
- `analysis/collectors/README.txt`

Legacy evidence remains unchanged so older diagnosis tooling continues to work.

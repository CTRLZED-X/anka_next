# Spell Rule Compiler

`SpellRuleCompiler` is the boundary between canonical static spell grades and the generic cast-mechanic specs.

It translates a `SpellGradeDefinition` into:

- `CastAvailabilitySpec`;
- `RangeSpec`;
- `TargetCellSpec`;
- the grade's line-of-sight requirement.

It does not implement any spell-specific mechanics and does not reinterpret raw source values.

## Fail-closed source anomalies

Compilation returns `UNSUPPORTED` instead of a cast spec when the source grade contains a value whose semantics are not yet verified. Current examples are:

- `max_cast_per_turn == -1`;
- `initial_cooldown == -1`;
- `max_range < min_range`.

On the current `Static(2)` archive, 34,428 of 34,445 attached grades compile deterministically. The remaining 17 are exactly the known source anomalies: 10 range inversions, 4 unresolved initial cooldown values, and 3 unresolved per-turn limit values.

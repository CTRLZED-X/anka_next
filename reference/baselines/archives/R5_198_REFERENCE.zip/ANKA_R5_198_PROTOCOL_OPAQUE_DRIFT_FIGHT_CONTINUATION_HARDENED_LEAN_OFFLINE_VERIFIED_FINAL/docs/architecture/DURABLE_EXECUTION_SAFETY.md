# Durable execution safety — R5.182

`CanonicalStateStore` owns semantic truth. `ExecutionSafetyStore` owns only unresolved physical-action obligations.

For a game-affecting physical send, the safe ordering is:

1. verify control/runtime/projection preconditions;
2. commit `prepared_input_json` durably;
3. only then invoke the input driver;
4. if delivery is `NOT_SENT`, remove/restore the previous prepared obligation;
5. if delivery may have occurred, retain the prepared obligation until canonical success or another durable uncertainty/settlement/world-interaction obligation replaces it;
6. on any safety persistence failure, roll back SQLite, mark that store instance `FENCED`, and refuse later physical sends.

A restart that discovers a prepared input treats it as unresolved physical action and fails closed. A waiter may never steal a lifecycle/input lease from a stuck owner.

# Canonical Combat Actor Semantics

## Purpose

The Kernel needs a stable combat-actor vocabulary for deterministic decision making, while the live decoder/reducer remains outside the Kernel and owns freshness. R6B therefore separates volatile actor state from additional semantic combat characteristics.

## Runtime ownership

`ActorState` is an immutable caller-owned snapshot. It contains volatile values such as current HP/AP/MP, team, cell, active state IDs, cooldowns, summon relationship, and alive status. `cooldowns_complete` records whether the supplied cooldown tuple is a complete current snapshot: an absent spell is known ready only when this flag is true; otherwise absence stays unknown.

`ActorCombatStats` is an optional nested semantic profile containing additional observed combat characteristics:

- current shield HP;
- maximum AP and MP;
- current range bonus (PO modifier);
- lock and dodge;
- AP-loss and MP-loss resistance;
- fixed critical-damage resistance;
- fixed pushback-damage resistance;
- semantic visibility (`True`, `False`, or unknown `None`);
- per-element percent/fixed resistance records;
- observed melee/ranged/weapon/spell damage-received modifiers.

Unknown is not zero. Every field may be absent when the caller has not proven/observed it.

## Elements

The canonical elemental vocabulary is:

- neutral;
- earth;
- fire;
- water;
- air.

`ElementalResistance` stores optional percent and fixed values for exactly one element. Negative values are preserved because a source may represent vulnerability/reduction effects with signed modifiers. R6B performs no cap or damage calculation.

## Query facade

`GameKernel.actor_queries` exposes read-only `ActorQueryService` operations over a `FightContext`:

- `health_percent`;
- `effective_health` (`current_hp + known shield_hp` only);
- `resource_snapshot` (current/max AP/MP and range bonus);
- `elemental_resistance`;
- `lock_dodge`;
- `summon_count`.

Results use the Kernel's certainty model. If required state is missing, results use `DETERMINISTIC_IF_CONTEXT_COMPLETE` and enumerate exact missing semantic inputs.

## Cast-query integration

R6B closes an R6A fail-open edge for modifiable spell range. When a spell grade has `range_modifiable=True` and no explicit `range_bonus` override is supplied, `FightQueryService` now reads `ActorCombatStats.range_bonus`.

If that semantic value is unknown, cast legality is incomplete rather than assuming zero PO. Non-modifiable spells safely use zero range bonus because the spell rule ignores the value. Explicit caller overrides remain supported for hypothetical planning.

## Summons

`ActorState.summoned` and `summoner_id` remain caller-owned facts. `ActorQueryService.summon_count` counts live matching summons already present in the supplied snapshot. Unknown summon relationships make the result incomplete instead of silently reducing the count.

## Explicit non-goals

R6B does not provide:

- damage, healing, or shield formulas;
- PvP resistance selection/caps;
- tackle/lock probability;
- AP/MP removal probability;
- visibility/invisibility decoding from protocol numeric states;
- raw `CharacteristicId` to semantic-stat mapping without verified evidence;
- mutable actor reducers;
- packet decoding/capture;
- bot/executor/runtime integration.

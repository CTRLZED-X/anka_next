# Fight Projection and Ordered Effect Resolution — R8E V2

## Purpose

The Kernel models hypothetical same-turn and same-cast consequences without owning mutable live truth. R8E preserves the R7/R8 immutable projection architecture and applies the V2 authority rule:

- project verified deterministic outcomes that the Kernel intentionally owns;
- represent intentionally server/live-authoritative outcomes as typed `LiveObservationRequirement` values;
- never reproduce those live-authoritative final numerical outcomes locally;
- keep UNKNOWN and UNSUPPORTED distinct from LIVE_REQUIRED.

## Three authorities

### Static authority

External Static/Mapuse owns game-definition facts already present there, including spell identity/grades, AP cost, base range, range-modifiable flags, line/diagonal flags, LoS, cast limits, cooldowns, target-cell occupancy rules, state criteria, and map definitions.

`SpellMechanicsPack` must not become a second Static database. It supplies only verified effect-graph/mechanic information Static does not sufficiently provide.

### Kernel authority

The Kernel owns pure verified semantics such as cast legality, range/geometry, AoE, targeting, ordered effect sequencing, deterministic displacement/teleport where verified, own AP/MP spend, cast/movement history, cooldown projection where exact semantics are available, and immutable hypothetical contexts.

### Live authority

The current project deliberately takes these final runtime outcomes from live/server observation by default:

- exact final damage and HP after damage;
- exact healing and HP after healing;
- exact shield amount/remaining;
- dodgeable/random AP removal result;
- dodgeable/random MP removal result;
- collision/pushback damage;
- server-side random outcomes;
- lifecycle outcomes intentionally delegated to live state.

The Kernel retains structural/base metadata and emits typed requirements. It does not add final damage/heal/shield/dodge/collision calculators.

## Projection

`FightProjection` contains:

- the original caller-owned `FightContext` (`base_context`);
- the current hypothetical `FightContext`;
- ordered deterministic `ProjectionChange` records.

R8E projection changes include:

- `CellProjectionChange`;
- `StateProjectionChange`;
- `APProjectionChange`;
- `MPProjectionChange`;
- `TurnHistoryProjectionChange`;
- `CooldownProjectionChange`.

`FightProjectionService` always returns new immutable snapshots. The caller-owned input context is never mutated.

## Accepted hypothetical cast projection

`GameKernel.action_projection.project_spell_cast(...)` performs this pure flow:

1. resolve Static grade plus verified overlay;
2. evaluate cast legality using the supplied caller snapshot;
3. fail closed when legality is illegal/incomplete/unknown/unsupported;
4. spend the caster's own AP deterministically;
5. append a hypothetical `CastRecord` to the supplied current-turn history;
6. project the known cooldown after cast when the caller supplied either an explicit spell cooldown entry or a complete cooldown snapshot;
7. select the caller-requested NORMAL/CRITICAL branch;
8. resolve ordered `SpellEffectOccurrence` values;
9. compose deterministic effect changes;
10. collect typed live requirements;
11. return a new hypothetical context.

This result means "if this action is accepted/executed under this supplied context". It never means the server has confirmed the projected state.

## Movement projection

`GameKernel.movement_projection.project_move_to(...)` uses the verified movement/path authority to project:

- path legality;
- final cell;
- own MP spend;
- a `MovementRecord`;

while preserving the original context. Unknown current MP/history stays incomplete; MP is never invented or allowed to go negative.

## Ordered effect resolver

`GameKernel.effect_resolver.resolve(...)` receives explicit canonical occurrences plus caster, selected target cell, map definition, and caller-owned fight context.

For each occurrence, in order, it:

1. validates trigger/delay/probability authority;
2. requires explicit effect AoE; unknown area never becomes POINT;
3. resolves the area anchor and canonical affected cells;
4. requires explicit target semantics; unknown targeting never becomes everyone;
5. evaluates conditions against the current projected context;
6. identifies eligible actors;
7. either projects a verified deterministic mechanic or emits typed live requirements;
8. carries deterministic changes forward before resolving the next occurrence.

A live-required numerical effect does not invent local state mutation and does not automatically block a later independent deterministic effect.

Example:

```text
effect 0 = DAMAGE
    -> base/source metadata retained
    -> HP unchanged locally
    -> DAMAGE_AMOUNT + HP_AFTER_DAMAGE requirements

effect 1 = PUSH
    -> deterministic destination projected if supported/context-complete
    -> collision damage requirement emitted if collision occurs
```

## Typed live requirements

`LiveObservationRequirement` carries:

- `LiveRequirementKind`;
- optional actor ID;
- optional source spell ID;
- optional effect order;
- optional semantic reason.

It deliberately carries no protocol ID, packet type, subscription, waiting, acknowledgement, or reconciliation behavior.

R8E kinds currently include damage, HP-after-damage, heal, HP-after-heal, shield amount/remaining, AP/MP change result, collision damage, random outcome, and status lifecycle.

## Deterministic resolver support

Currently projected through existing generic authorities when context is sufficient:

- single-target aligned PUSH;
- single-target aligned PULL;
- aligned caster RECOIL;
- one-actor TELEPORT to the explicit selected target cell;
- coarse APPLY_STATE;
- coarse REMOVE_STATE.

Known blockers remain explicit for mechanics such as multi-target displacement sequencing, diagonal recoil traversal, arbitrary unsupported relocation relations, and rich lifecycle semantics not delegated to live authority.

## Live-authoritative resolver support

Structurally known occurrences can successfully emit live requirements for:

- `DAMAGE`;
- `HEAL`;
- `SHIELD`;
- dodgeable `AP_CHANGE`;
- dodgeable `MP_CHANGE`;
- random effect activation;
- selected non-immediate resource/status lifecycle effects;
- characteristic/spell-base-damage modifier lifecycle;
- collision damage after deterministic push/recoil collision geometry.

These are not treated as missing numerical calculators.

## Cast area versus effect AoE

These remain two independent canonical concepts:

- cast area = cells the spell may legally target;
- effect AoE = cells affected after one legal target is selected.

`FightService.legal_target_cells_for_grade(...)` enumerates cast targets only from cast rules. It never consults effect AoE. When the caster snapshot itself is missing, legal-cell collections remain `None` rather than silently becoming empty.

## Readiness

R8E readiness reports:

- `structurally_ready`;
- `projection_ready`;
- `live_requirements`;
- `unsupported_blockers`;
- `unknown_blockers`.

`prediction_ready` remains only a compatibility alias for `projection_ready`.

A spell can therefore be structurally/projection ready while still requiring live damage/HP/heal/shield values. Conversely, unknown geometry or an unsupported deterministic displacement rule remains a real blocker.

## Fail-closed invariants

- UNKNOWN != zero/false/empty/POINT;
- LIVE_REQUIRED != UNKNOWN;
- LIVE_REQUIRED != UNSUPPORTED;
- unknown area != POINT;
- unknown target != everyone;
- incomplete cast-area collections are not exposed as verified empty collections;
- live-authoritative damage/heal/shield does not mutate local HP;
- dodgeable AP/MP outcomes do not mutate local resources;
- collision damage is never calculated;
- caller-owned state is never mutated;
- no runtime/network/executor/reconciliation/AI behavior enters the Kernel.

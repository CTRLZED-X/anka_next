# State Criteria

## Purpose

The state-criteria layer converts the static `SpellLevels.statesCriterion` source syntax into a canonical typed expression tree, then evaluates that tree only against caller-owned active-state snapshots.

Raw source syntax is **not** part of the cast mechanic API. Source parsing lives in `anka_game_kernel.normalization.state_criteria`; the canonical expression types live in `anka_game_kernel.domain.state_criteria`.

## Evidence-backed source grammar

A prior audited static-data snapshot from this project contained 34,822 `SpellLevels` records and 2,414 non-empty state criteria; all 2,414 were parsed by its strict state-criterion implementation. These counts document the audited snapshot; they are not re-enumerated from a newer source blob by this Kernel module. The observed grammar is:

```text
HS=<state_id>
HS!<state_id>
&
|
(...)
```

Representative observed expressions:

```text
HS!7
HS=64
HS!60&HS!61
HS=3360|HS=3589
(HS=3360|HS=3589)&HS!7
```

Semantics:

- `HS=<id>`: the caster must have state `<id>`;
- `HS!<id>`: the caster must not have state `<id>`;
- `&`: all child criteria must hold;
- `|`: at least one child criterion must hold;
- parentheses provide grouping.

Mixed `&` and `|` at the same expression level are rejected. Parentheses must make the grouping explicit.

## Canonical model

Normalization produces only typed domain objects:

- `StatePresentCriterion(StateId(...))`
- `StateAbsentCriterion(StateId(...))`
- `AllStateCriteria(...)`
- `AnyStateCriteria(...)`

The raw `HS` prefix and source operators do not leak into the casting service.

Empty criteria, the source literal `null`, and a deserialized null value normalize to no state restriction.

## Fail-closed policy

Unknown or malformed syntax raises `ValueError` during normalization. The Kernel does not trim, reinterpret, invent precedence for, or silently ignore unsupported expressions.

Examples rejected intentionally include:

- mixed ungrouped `HS=1|HS=2&HS!3`;
- unbalanced or empty parentheses;
- empty boolean operands;
- unknown prefixes;
- invalid/non-positive state IDs;
- whitespace not present in the observed grammar;
- unknown literals such as `true`.

A future source build that introduces new syntax therefore requires an explicit normalizer update and regression evidence rather than silently changing cast semantics.

## Runtime ownership

The evaluator accepts an immutable `frozenset[StateId]` supplied by the caller. It does not discover, cache, poll, or mutate active states.

State duration, effect duration, state application/removal, packet decoding, and current-fight state ownership are outside this layer.

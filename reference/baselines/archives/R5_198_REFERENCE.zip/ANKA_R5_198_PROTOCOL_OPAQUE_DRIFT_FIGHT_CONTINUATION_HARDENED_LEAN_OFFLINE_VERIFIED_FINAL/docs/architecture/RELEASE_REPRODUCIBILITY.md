# R5.179 Release / Reproducibility Architecture

R5.179 changes release engineering, not fight/runtime authority.

## Authority split

- `pyproject.toml`: supported dependency ranges and package metadata.
- `requirements/anka-constraints.txt`: exact dependency versions selected for the release.
- `requirements/DEPENDENCY_BASELINE.json`: machine-readable expected environment.
- `PROJECT_STATUS.json`: compact current release state only.
- `docs/history/PROJECT_HARDENING_HISTORY.md`: cumulative historical narrative.
- `PROJECT_CONTEXT.json`: current document/source/test map.
- `verification/CURRENT_TEST_GATE.json`: release test gate.
- `PACKAGE_MANIFEST.json`: exact immutable delivery inventory.

## Rules

1. Setup installs through the exact constraint set; it must not silently upgrade pip/dependencies to whatever is newest on that day.
2. Setup verifies the resulting environment against the dependency baseline and persists an observed record.
3. A package cannot be sealed if checkpoint, platform version, current docs, test gate, verification report, dependency baseline or constraints disagree.
4. Runtime code must not depend on historical release prose.
5. Current machine state stays small; history belongs under `docs/history/`.
6. Windows/Dofus live acceptance remains a separate evidence boundary from offline reproducibility.

# State Transition Engine

`StateService` applies a canonical `StateTransitionSpec` to an immutable `ActorState` snapshot and returns a pure delta:

- before state set;
- after state set;
- states added;
- states removed.

The input actor is never mutated. Applying an already-active state and removing an absent state are idempotent at this set-transition layer.

Duration, stacking, incompatibilities, dispel rules, and special state semantics are not guessed here. They require separately verified definitions/rules.

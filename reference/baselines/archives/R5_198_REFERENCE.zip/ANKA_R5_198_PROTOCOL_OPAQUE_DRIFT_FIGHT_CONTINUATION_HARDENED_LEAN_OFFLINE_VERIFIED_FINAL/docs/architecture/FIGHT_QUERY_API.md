# Fight Query API

## Purpose

`FightQueryService` is the Kernel's read-only decision-query facade over canonical map mechanics plus a caller-owned immutable `FightContext` snapshot.

It exists so a future planner/AI can ask high-value questions without duplicating geometry, movement, LoS, targeting, or cast-rule logic and without depending on any external bot runtime.

The API was coverage-inspired by useful read/evaluate methods documented by AnkaBot's `fightAction`, `fightCharacter`, and fight entity objects. Those external names are reference points only. Production Kernel code contains no AnkaBot import, bridge, probe, runtime call, or execution dependency.

## Boundary

The Kernel answers questions. It does not execute actions.

Allowed:

- distance and adjacency;
- line/diagonal relationships;
- static fight walkability;
- caller-supplied occupancy/free-cell queries;
- entity lookup over a `FightContext` snapshot;
- nearest ally/enemy selection;
- shortest paths and MP-bounded reachable cells;
- verified LoS evaluation;
- spell-grade cast legality from the current cell;
- hypothetical post-move cast legality.

Excluded:

- moving a character;
- casting a spell;
- ending a turn;
- placement selection;
- changing AP/MP/PO to compensate for stale live state;
- owning or refreshing fight state;
- packet/network/UI operations;
- strategy or target scoring.

## API mapping

| External documented idea | Kernel-native capability | Status |
| --- | --- | --- |
| distance between cells | `FightQueryService.distance` | deterministic |
| adjacent cells | `FightQueryService.adjacent_cells` | deterministic |
| hand-to-hand relation | `FightQueryService.is_hand_to_hand` | deterministic |
| aligned cells | `FightQueryService.cells_aligned` | deterministic |
| diagonal cells | `FightQueryService.cells_in_diagonal` | deterministic |
| walkable cell | `FightQueryService.is_walkable` | deterministic when the map cell is supplied |
| free cell | `FightQueryService.is_free_cell` | deterministic over supplied snapshot |
| fighter on cell | `FightQueryService.fighter_at` | deterministic over supplied snapshot |
| all entities / count | `entities` / `entities_count` | deterministic over supplied snapshot |
| current turn/round information | `current_round` + `active_actor` | caller-owned snapshot |
| nearest enemy | `nearest_enemy` | fail-closed |
| nearest ally | `nearest_ally` | fail-closed |
| shortest path | `shortest_path` | deterministic/incomplete result |
| shortest path with avoid cells | `shortest_path(..., avoid_cells=...)` | deterministic/incomplete result |
| reachable cells ignoring fighters | `reachable_cells(..., ignore_actors=True)` | deterministic/incomplete result |
| reachable cells considering fighters | `reachable_cells(..., ignore_actors=False)` | deterministic/incomplete result |
| line of sight | `line_of_sight` | verified straight/diagonal subset; arbitrary angle remains unsupported |
| can cast from current cell | `evaluate_grade_cast_from_cell` | composed canonical result |
| can cast after hypothetical move | `evaluate_grade_cast_after_move` | composed canonical result; does not prove the move is reachable |
| cross/lozenge/diagonal area helpers | existing `AoEService.cells(AreaSpec(...))` | deterministic for supported shapes |
| spell zone | no spell-ID shortcut yet | blocked on verified effect-instance/AoE mechanics |
| square area helper | no canonical square primitive yet | deferred until exact semantics are verified |
| state duration remaining | no duration query yet | caller state currently stores active state IDs, not durations |
| state mutation/debug overrides | existing pure state transitions only | external runtime mutation intentionally excluded |
| cast/move/placement action | none | intentionally outside Kernel |

## Reachable-cell semantics

The canonical movement primitive uses four-neighbor fight movement and a caller-supplied step budget.

`reachable_cells` includes the actor's origin at distance zero. Other cells are included only when their shortest canonical path length is `<= current_mp`. Results are ordered by shortest distance and then cell ID.

When `ignore_actors=False`, every other active actor cell is blocked. When `ignore_actors=True`, actor occupancy is ignored but static fight walkability is still enforced.

This primitive does not yet account for tackle/lock, portals, special states, MP-loss-on-tackle, or other mechanics that are not verified in the Kernel.

## Nearest-actor semantics

Nearest ally/enemy uses canonical cell distance and deterministic tie breaking:

1. distance;
2. cell ID;
3. actor ID.

Dead actors are ignored. If the source actor's team/cell is unknown, or another potentially matching live actor has unknown team/cell data that could change the nearest result, the query returns `DETERMINISTIC_IF_CONTEXT_COMPLETE` with explicit missing inputs instead of guessing.

## Hypothetical post-move cast semantics

`evaluate_grade_cast_after_move` relocates only the caster in the occupancy snapshot:

- old caster cell becomes free;
- hypothetical launch cell becomes occupied by the caster;
- all other actor occupancy is preserved.

It then delegates to the existing authoritative `FightService.evaluate_grade_cast` pipeline. It does not check whether the launch cell can actually be reached. A planner should first enumerate `reachable_cells`, then evaluate candidate casts from those cells.

## Actor-state coverage inspired by entity documentation

The current caller-owned `ActorState` already covers several high-value fight fields exposed by external entity APIs:

- actor ID;
- team ID;
- cell ID;
- current HP / max HP;
- current AP / MP;
- active states;
- summoned flag / summoner ID;
- generic characteristic values;
- spell cooldown snapshots;
- alive/dead state.

Useful additional actor semantics documented externally—such as shield points, maximum AP/MP, level, class/breed, lock/tackle/dodge values, elemental resistances, and other characteristics—are candidates for later canonical snapshot enrichment, but only with stable semantic IDs/contracts. They are not hard-coded from external field names in this layer.

# Failure Authority and Traceability

## Purpose

R5.175 makes failure semantics a project contract rather than a collection of local string lists.
The authority is `anka_platform.contracts.failure_registry`.

A component may discover or emit a failure, but it must not invent independent global policy for that
failure.  Retry, control fencing, coarse ownership, terminality and diagnostic vocabulary come from the
central registry.  Context-sensitive components may refine a decision only when they have additional
structured evidence (for example, a specific pending transaction that can be reconciled safely).

## Invariants

1. Every literal production `failure_code` must be registered before release.
2. Unknown future failures fail closed at control/startup boundaries and remain visible in diagnostics.
3. Observability uses the same vocabulary as execution/control; it does not maintain a second enum.
4. Retry policy and control disposition are separate concepts.
5. A timeout never proves that physical input was sent.
6. A human-readable error message is not a machine contract.
7. Failure attribution is evidence, not blame.  Boundary/owner values identify the component responsible
   for proving the next invariant.

## Failure contract

Each registered code has:

- domain;
- severity;
- retry disposition;
- control disposition;
- terminality;
- default boundary;
- default owner.

The release architecture verifier scans production source and rejects literal failure codes missing from
this registry.  This is the project-wide generalization of the R5.174 startup blocker registry.

## Correlation

Cross-boundary operations should use immutable `CorrelationContext` rather than mutable dictionaries.
The context carries session/run/request/operation/account/runtime-generation identity while retaining
backward-compatible extra metadata during migration.

Correlation identity must never be reconstructed from display text or log strings.

## Migration rule

Existing large components may continue returning dictionaries while they are characterized and migrated,
but new cross-layer contracts should prefer typed immutable models.  Do not perform a mass rewrite of
ExecutionService solely to adopt the new types; move one boundary at a time behind existing regression
coverage.

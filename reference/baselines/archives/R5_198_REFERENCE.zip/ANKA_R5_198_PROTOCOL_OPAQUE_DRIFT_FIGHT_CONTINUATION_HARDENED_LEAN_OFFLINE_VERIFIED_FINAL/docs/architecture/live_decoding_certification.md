# Protocol-Independent Live-Decoding Certification Architecture

## Goal

The verifier answers one stable question across current and future Dofus wire protocols:

> Does this exact decoder/profile/evidence set provide the complete canonical live truth and outbound request causality that the current ANKA runtime can rely on?

The reference is **protocol-independent**. Raw message names, protobuf field numbers and client-build layouts are versioned implementation details behind the adapter/wire-profile boundary.

## Stable reference surfaces

`protocol/live_decoding_reference.py` is the authoritative, versioned reference. It explicitly classifies the complete Canonical Event union and binds the reference hash to:

- every canonical event kind in Canonical Contract v1;
- the decision-critical fields that must be proven KNOWN for each event;
- every `ProtocolCapability`;
- every stable outbound `ProtocolWireSemantic`;
- reducer disposition, consumers and a controlled capture recipe.

`docs/reference/LIVE_DECODING_REFERENCE_V1.json` is the immutable JSON snapshot of that code-defined reference. Tests require exact equality. A new canonical event/capability/wire semantic cannot silently become optional: reference self-validation fails until it is consciously classified.

Reference roles:

- `REQUIRED`: needed by current control/runtime truth. Fresh exact-build evidence must semantically verify it before `READY`.
- `ALTERNATE`: supported canonical carrier whose absence alone is not authorizing/blocking because another required carrier owns the current truth.
- `AUXILIARY`: diagnostic/forensic truth not currently used to authorize control decisions. It remains visible in full-reference coverage.

## Production boundary

`PCAP/live TCP -> stream reconstruction -> framing -> versioned adapter/wire profile -> Canonical Events -> Canonical State -> world/party/fight/FightAI/admission/execution`

Protocol changes may alter the left side. They must preserve the stable canonical meaning on the right unless the Canonical Contract itself intentionally evolves.

## Certification layers

The command does not use a single packet-count percentage. It evaluates independent gates:

1. capture/TCP/framing replay integrity;
2. raw-wire classification and transform integrity;
3. exact client-build/profile identity;
4. protocol-boundary isolation (no raw wire identity leaking into control code);
5. complete Live Truth Contract requirements;
6. complete protocol-independent reference event presence;
7. critical-field availability for every REQUIRED reference event;
8. controlled canonical value assertions from scenario manifests;
9. outbound wire semantic assertions;
10. independent Canonical State oracle comparisons where an oracle is available;
11. regression replay against retained historical evidence.

`READY` requires all blocking gates to pass. A high percentage never overrides a blocker.

## Coverage meanings

- `required_live_truth_coverage_pct`: current downstream requirements verified at their required proof level.
- `required_reference_event_coverage_pct`: REQUIRED canonical event kinds observed.
- `required_reference_semantic_coverage_pct`: REQUIRED canonical events observed **and all their decision-critical fields proven KNOWN**.
- `required_reference_critical_field_coverage_pct`: field-level completeness across REQUIRED reference events.
- `all_reference_*`: full inventory including ALTERNATE/AUXILIARY entries; these remain diagnostic and may be below 100% while runtime authorization is still possible.
- `evidence_coverage_pct`: how much of the downstream contract was actually exercised/proven by the active evidence.

## Controlled scenario evidence

`LIVE_DECODING_EVIDENCE.json` may point to a scenario manifest. See `docs/reference/LIVE_DECODING_SCENARIO_TEMPLATE.json`.

A scenario can declare:

- `expected_event_kinds` — events that must occur;
- `expected_wire_semantics` — controlled outbound requests that must have passing packet/field assertions;
- `canonical_assertions` — expected canonical values, optionally scoped to one account and requiring one or more matches.

Example: a controlled cast can assert that the replay emits `spell_cast_observed` with the known `spell_id` and `target_cell_id`. This prevents a false green where fields are merely populated but mapped to the wrong meaning.

If a declared event/assertion fails, the verifier treats it as a positive integration divergence, not as generic “missing evidence”.

## Fresh-evidence isolation

When one or more fresh evidence folders are supplied, current-build certification uses **only those fresh captures** for current-build event/field/semantic proof. Retained/bundled evidence remains a regression gate and cannot fill a missing truth for the new build.

Multiple captures may be unioned only when adapter id, exact observed client build and decoder identity agree. This lets a controlled evidence campaign exercise the full reference across several fights/world scenarios without mixing incompatible protocols.

## GPT diagnostic

`runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json` is intentionally GPT-oriented. It includes the first violated boundary, exact gap type, reference/requirement row, missing critical fields, evidence locators, first replay/scenario failure, likely owner paths, falsification direction and capture recipe.

GPT rules are fail-closed:

- `NOT_EVIDENCED`: collect the prescribed evidence before inventing a mapping.
- `REFERENCE_CRITICAL_FIELD_GAP`: event exists but field authority/proof is incomplete; trace the field before downstream edits.
- scenario assertion/event mismatch: trace the first decoder/reducer divergence in the declared controlled scenario.
- implementation/schema/boundary failures: fix the owner boundary and add a deterministic regression.

Generated artifacts live under `runtime/live_decoding/`, outside the immutable package manifest.

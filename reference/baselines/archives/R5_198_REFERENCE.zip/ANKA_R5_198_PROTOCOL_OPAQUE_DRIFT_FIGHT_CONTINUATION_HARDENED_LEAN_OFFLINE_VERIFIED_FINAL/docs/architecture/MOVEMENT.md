# Movement primitives

The movement layer is a deterministic, side-effect-free fight-grid primitive. It does not move a client and does not own actor state.

## Supported subset

`MovementService.shortest_path(...)` currently evaluates:

- canonical four-neighbor Dofus grid adjacency;
- static `walkable` cells;
- static `non_walkable_during_fight` restrictions;
- an explicit caller-owned runtime `occupied_cells` snapshot;
- shortest unweighted paths via BFS.

Returned paths include both the start and target cells. `step_count` is therefore `len(path) - 1`.

## Certainty boundary

A statically illegal target can be rejected without runtime occupancy. Otherwise occupancy must be supplied explicitly.

If a path is found in a partial map definition, that path is still valid. If no path is found from a partial map definition, the result is incomplete rather than a false deterministic `NO_PATH`, because omitted cells could contain a route.

## Explicitly out of scope

This layer does not yet model:

- MP budgets;
- tackle/lock/dodge;
- movement-zone penalties;
- portals;
- special states that modify movement;
- push/pull/forced displacement;
- path strategy or destination scoring;
- execution through AnkaBot or any client API.

Those concerns must be separate mechanics or caller-owned runtime inputs. The Kernel remains deterministic and pure.

## High-level tackle safety gate

`MovementService` remains a pure geometric path primitive and intentionally does not implement tackle/lock formulas. `MovementProjectionService` adds a conservative fight-safety gate: if a verified path departs from a cell adjacent to a known enemy, the action projection returns `UNSUPPORTED`, `legal=None`, and `projection_complete=False` without spending MP or moving the actor. This prevents Fight AI from treating geometric reachability as full action reachability while exact current tackle semantics remain unverified.

# Static Spell Canonicalization

## Scope

The current static spell adapter consumes the user-supplied `Spells.json` and `SpellLevels.json` files and produces immutable `SpellDefinition` / `SpellGradeDefinition` objects. Source JSON is an ingestion format only; consumers use `kernel.spells`.

## Provenance

Spell-level and spell-definition provenance remains record-aware on canonical definitions. The Knowledge Pack manifest intentionally deduplicates that into file-level fingerprints so tens of thousands of records do not duplicate identical source hashes.

## Real-data findings from `Static(2)`

The current user-supplied archive validates into:

- 17,114 canonical spells;
- 34,445 attached spell grades;
- 378 raw `SpellLevels` rows that are not referenced by `Spells.json`;
- 10 grades where the source has `range < minRange`;
- 7 fields using an unresolved raw `-1` sentinel (`initialCooldown` or `maxCastPerTurn`);
- 2,390 attached grades with parsed state criteria;
- 1,499 attached grades marked `canSummon`.

These conditions are surfaced as diagnostics. The loader does not reinterpret or repair source values silently.

## ID boundary

The current source proves that zero is a valid value for at least `SpellId`, `StateId`, and `EffectId`. For example, spell ID 0 is `Coup de poing`. Canonical ID validation therefore preserves zero where the source demonstrates it.

## Integrity rules

The adapter rejects:

- missing referenced spell levels;
- spell-level backreferences to the wrong spell;
- dictionary keys that disagree with record IDs;
- duplicate grade numbers inside one spell;
- malformed state-criterion syntax.

Unreferenced spell-level rows are not promoted into active spell grades because the canonical relationship is defined by `Spells.json`. They remain visible in `SpellKnowledgeDiagnostics`.

## Knowledge Pack integration

`build_kernel_knowledge_pack(...)` combines:

- every active `Mapuse/map_*.json`;
- `Spells.json`;
- `SpellLevels.json`;

into one deterministic manifest and immutable map/spell registries. Rebuilding from identical inputs produces the same content hash.

## Current boundary

This source does not yet provide the complete ordered effect-instance graph needed for full spell execution semantics. In particular, the inspected export does not expose all target-mask, zone, argument, damage/heal, duration, push/pull, trigger, or summon-instance details. Those must be added through later source adapters/normalizers without inventing them inside spell policy code.

# R5.126 — Fight Lifecycle Monotonicity Root Cause and Hardening

## Live evidence

Source incident: `runtime(20260920-225212)`.

The first fight reached the required preparation and combat boundaries successfully:

```text
CRA joined/placed/Ready
ENU joined/placed/Ready
        ↓
preparation COMPLETE
        ↓
CRA ACTIVE → move/end-turn
        ↓
ENU ACTIVE → move/end-turn
        ↓
normal cross-client TURN_ENDED/TURN_STARTED propagation skew
        ↓
SharedFight = PARTIAL (volatile turn fields)
        ↓
BUG: FightWorkflow classified PREPARATION_REQUIRED
        ↓
prepare_fight_step re-entered after combat movement
        ↓
cached placement cells invalidated
        ↓
PLACEMENT_BLOCKED
        ↓
BUG: mutable COMPLETE stage overwritten
        ↓
PREPARATION_TIMEOUT
```

The physical-input ledger contains the CRA activation/actions, then the ENU activation/actions, and no later CRA activation. The canonical stream later reaches the next CRA turn. Therefore the observed Sosoking window remaining focused was not a failure of `activate_window`; the owner-activation path was never reached because lifecycle ownership had already regressed into preparation.

## Root causes

### 1. PARTIAL was overloaded

`SharedFightManager` intentionally returns `PARTIAL` while volatile fields such as `round`, `turn_index`, and `active_actor_id` propagate between required clients. `FightWorkflow` did not distinguish normal ACTIVE turn-stream convergence from incomplete pre-fight entry and sent both cases toward preparation.

### 2. Preparation completion was represented by mutable stage text

`PartyMissionController.preparation_complete_for()` depended on `self._preparation["stage"] == "COMPLETE"`. A later erroneous call could replace that string with `PLACEMENT_BLOCKED`, revoking an already-earned exact-generation fact.

### 3. Inspect → action used multiple independent observations

`FightWorkflow.inspect()` classified one `SharedFightView`, then `prepare_fight_step()` independently rebuilt the barrier. A transient frame could therefore authorize a different phase owner to run on a newer frame. R5.126 makes PARTIAL input-free and generation-fences preparation.

### 4. No parent invariant detected ACTIVE → preparation

The campaign watchdog eventually reported `PREPARATION_TIMEOUT`, hiding the first invalid transition. R5.126 keeps an independent ACTIVE-generation history and fails immediately if the impossible regression returns.

### 5. Latent duplicate END_TURN after revision churn

Once lifecycle remains ACTIVE through handoff, post-END_TURN protocol traffic can advance canonical revision before the turn key changes. The old combat guard allowed a new decision on any revision change. R5.126 latches accepted `END_TURN` as terminal for the exact turn key.

## Safety model after R5.126

```text
PREPARATION (exact fight N)
        ↓ COMPLETE latch
ACTIVE (fight N) ───────────────┐
        ↓                       │
PARTIAL volatile handoff        │ no input / observe only
        ↓                       │
CONSISTENT next turn            │
        ↓                       │
turn owner resolution           │
        ↓                       │
activate exact owner window     │
        ↓                       │
combat action                   │
        ↓                       │
END_TURN accepted ──────────────┤ no more actions for same turn key
        ↓                       │
next exact turn key ────────────┘ reset turn-local latch
```

For one exact fight generation, `ACTIVE -> ENTRY_BARRIER/CHALLENGE/PLACEMENT/READY` is forbidden. A future violation becomes `FIGHT_LIFECYCLE_PHASE_REGRESSION` with first missing boundary `FIGHT_PHASE_MONOTONICITY` instead of waiting for a generic timeout.

## Changed runtime owners

- `src/anka_platform/core/fight/workflow.py`
  - exact-generation ACTIVE latch;
  - PARTIAL handoff is observation-only;
  - pre-ACTIVE PARTIAL is observation-only;
  - exact generation passed into preparation;
  - lifecycle evidence attached to ACTIVE classification.
- `src/anka_platform/party/mission.py`
  - independent preparation-completion set;
  - COMPLETE stage cannot be downgraded;
  - completed preparation is idempotent/no-input;
  - regression attempts retained in bounded diagnostics.
- `src/anka_platform/core/fight/controller.py`
  - accepted END_TURN terminal latch for the exact turn key.
- `src/anka_platform/campaign/runtime.py`
  - parent ACTIVE-generation invariant tripwire;
  - per-account fight phase/actor/round/turn observation evidence.
- `src/anka_platform/party/shared_fight.py`
  - production-shaped lanes cannot call an all-unknown exact fight generation CONSISTENT.

No Game Kernel mechanics, protocol semantics, canonical contract major, Script Studio frontend delivery, startup ownership, or physical-input authority contract was changed.

## Next live acceptance

Use the same CRA/ENU mission. The critical acceptance point is the first ENU → CRA handoff:

1. ENU `END_TURN` is accepted once.
2. Temporary turn-stream skew may report ACTIVE convergence wait, but never PLACEMENT/READY.
3. No preparation physical input occurs.
4. When the next CRA turn becomes CONSISTENT, `PartyCombatController` resolves CRA and calls the correlated CRA `activate_window` before any action.
5. If another issue remains, one runtime/debug package must contain the first invariant, per-account turn frame, physical-input ledger, and exact campaign failure rather than only a later watchdog timeout.

# Documentation

The active project-level documentation is intentionally kept at repository root:

- `00_START_HERE.md`
- `PROJECT_STATUS.json`
- `ARCHITECTURE.md`
- `TESTING.md`
- `DEBUGGING.md`
- `DEVELOPMENT_RULES.md`
- `LIVE_ACCEPTANCE.md`

`docs/architecture/` and `docs/adr/` contain stable semantic/design references that remain useful for implementation work. `docs/reference/` contains compact subsystem reference notes.

Historical per-release notes, verification reports, dated implementation plans, and superseded handoffs are intentionally not shipped in the active GPT workspace.

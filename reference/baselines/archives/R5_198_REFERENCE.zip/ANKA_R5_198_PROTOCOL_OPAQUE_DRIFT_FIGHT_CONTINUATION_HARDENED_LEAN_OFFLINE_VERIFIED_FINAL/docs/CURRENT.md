> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# Current ANKA documentation — R5.198

**R5.198 — Protocol Opaque Drift / Fight Continuation Hardening** is the current candidate. The supplied R5.197 live run proved startup, fight entry, placement/Ready, CRA turn ownership, physical CAST delivery, and authoritative CAST settlement. The subsequent stop came from newly observed opaque `icl`/`icw` traffic activating the generic unclassified-protocol health fence.

R5.198 admits only those exact observed fingerprints as zero-event catalog traffic and preserves fail-closed behavior for every changed variant. Incident replay now treats raw PCAP and persisted Canonical journals as separate evidence authorities, allowing exact byte proof and exact live-frame reassessment without overclaiming either source.

R5.197 control-plane takeover and R5.196 turn/handoff simulation remain inherited current behavior.

Read `../00_NEW_CHAT_HANDOFF_R5_198.md`, `../R5_198_PROTOCOL_OPAQUE_DRIFT_FIGHT_CONTINUATION_HARDENING.md`, `../WINDOWS_LIVE_RUNBOOK.md`, and `../LIVE_ACCEPTANCE.md` before changing runtime behavior.

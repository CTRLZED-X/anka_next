# R5.181 — Windows Setup & Live Readiness Hardening

R5.181 is a narrow live-readiness release over the sealed R5.180 transactional foundation. It fixes a real Windows setup defect discovered during pre-live acceptance: normal `setup.bat` installed the `dev` extra, so an unavailable `pytest` download could block a machine that only needed ANKA runtime/capture dependencies.

## Changes

- normal setup installs `.[capture]`, never `.[dev,capture]`;
- `requirements/DEPENDENCY_BASELINE.json` is now the exact **live/runtime** baseline;
- optional test tooling is isolated behind `setup_dev.bat`, `anka-dev-constraints.txt`, and `DEV_DEPENDENCY_BASELINE.json`;
- pip operations are bounded with explicit retry/timeout settings;
- normal setup treats pip as installer tooling and does not force a network downgrade of pip itself;
- dependency failure runs `tools/dependency_network_probe.py` using only Python stdlib, so DNS failure can be diagnosed even when ANKA is not installed;
- setup diagnostics and status wording identify R5.181 rather than stale R5.179 contracts.

## Preserved foundations

R5.180 Canonical State transactions, decoder-context rollback symmetry, protocol isolation, ExecutionService authority, InputArbiter ownership, strict configuration, and fail-closed recovery are unchanged.

## Live status

Offline verification must pass before this candidate is considered ready for a bounded Windows live acceptance. Real Windows dependency installation, bridge load and Dofus behavior remain environment-specific acceptance gates.

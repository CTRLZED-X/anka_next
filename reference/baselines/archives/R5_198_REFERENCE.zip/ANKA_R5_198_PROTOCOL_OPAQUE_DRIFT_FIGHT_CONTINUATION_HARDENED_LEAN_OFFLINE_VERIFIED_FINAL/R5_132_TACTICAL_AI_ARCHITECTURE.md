# R5.132 Ranged-Control Tactical AI Foundation

## Purpose

R5.132 adds an **opt-in, deterministic, explainable tactical layer** for the Cra + Enutrof level-200 ranged-control team while preserving the R5.131 runtime, Canonical State, Kernel, control-authority, and ExecutionService boundaries. The implementation was informed by the separately inspected `SUFOKIA_DUO_AI_v0.3.10_ACCEPTANCE` reference project, but its AnkaBot/Lua runtime, duplicate combat state, hard-coded route/runtime, and physical execution stack are **not** embedded in ANKA.

## Ownership boundary

```text
Canonical State (live truth)
        |
        v
Kernel (legality + verified mechanics)
        |
        v
R5.132 tactical layer
  - TacticalFightState
  - enemy capability evidence
  - team threat / safe-state analysis
  - RANGED_CONTROL team plan
  - Kernel-derived spell features
  - explainable candidate scoring
  - bounded move->cast lookahead
  - END_TURN certification
  - FRONT_GUARD passive policy
  - coordinated team placement
        |
        v
ONE primitive FightDecision
        |
        v
PartyCombatController
        |
        v
ExecutionService (sole physical-input authority)
        |
        v
Canonical settlement -> replan
```

The tactical layer may rank only actions admitted by Kernel legality/effect resolution. Capability knowledge and learned/live evidence can affect tactical priority but can never make an illegal action legal. The planner emits one primitive action at a time and replans from newer Canonical State after settlement.

## Opt-in policy stack

Legacy defaults remain available and unchanged. The new mission `sufokia_farm_tactical_v1` selects the mission policy set `tactical_ranged_control_v1` and team strategy `ranged_control_v1`. Session compilation resolves:

- ACTIVE members -> `tactical_v1` unless an explicit account/session override exists;
- PASSIVE members -> `front_guard_v1` unless explicitly overridden;
- explicit UI/account policy choices retain precedence;
- legacy `r594_normal` and `normal_farm` remain no-override compatibility policy sets.

This is a compilation/defaulting contract only. It does not create a second execution authority.

## Cra / Enutrof roles

The team planner assigns semantic roles from account class + control mode:

- Cra -> `CRA_RANGED_CONTROL_DAMAGE`: ranged damage, AoE, finishing, displacement/kiting, and safe-range preservation.
- Enutrof -> `ENU_WATER_MP_CONTROL`: MP/control priority, threat denial, Water damage when control is sufficient, and ranged formation support.
- Other PASSIVE accounts -> `FRONT_GUARD`: never cast; normally END_TURN; move only when the certified reachable move improves geometric interception/protection of the core.

The shared plan can identify a primary target, priority threat, control target, finisher target, protected actor, tactical mode, desired range, and per-enemy capability evidence.

## Tactical state and safe-state analysis

`fight_ai/tactical/state.py` merges the newest actor observations from required account snapshots into a deterministic team view. Threat and safe-state modules derive conservative pressure, pincer/formation evidence, and shared target priorities. Unknown data remains unknown; generic fallback reach is conservative and does not claim spell legality.

## Kernel-derived spell features

`KernelSpellFeatureCatalog` derives tactical semantics from the existing verified spell-mechanics corpus rather than duplicating spell meaning in YAML. All configured Cra and Enutrof spells are already represented in that corpus at their configured grades. Tactical features include verified damage/control/displacement/AoE/state/summon/heal semantics where the Kernel knows them.

## Candidate planner

`tactical_v1` evaluates Kernel-certified CAST, MOVE, and END_TURN candidates with explicit score components. Important properties:

- empty target cells may be considered for AoE;
- movement compares projected enemy pressure, not merely nearest-enemy distance;
- the planner is role- and tactical-mode-aware;
- diagnostic-only measurements cannot influence ranking unless a score term is explicitly registered;
- END_TURN is certified against material current actions and bounded move->cast follow-ups;
- move->cast lookahead is deliberately small, deadline-aware, and auditable;
- lookahead never executes a speculative sequence: only the MOVE is emitted, settlement occurs, then the planner runs again.

## Enemy capability knowledge

`fight_ai/data/enemy_capabilities_sufokia.yaml` packages the four evidence-backed Sufokia capability profiles imported conceptually from the reference project. The catalog supports effective reach, threat multipliers, exact-range hazards, phases, and provenance. Unknown monsters use the generic fallback model. Capability evidence affects tactical scoring/placement only and never overrides Kernel legality.

## Coordinated team placement

`RangedControlTeamPlacementPlanner` plans one non-conflicting formation for the required party instead of greedily choosing each account independently. It favors spaced Cra/Enu core positions and forward passive guards where useful. `PartyMissionController` still owns the actual placement sequence and verifies each planned cell against current Canonical placement truth before physical input. If a planned assignment is no longer legal/free, the path fails closed rather than guessing.

## Fight Intelligence

R5.132 adds stable per-session streams used by future debug-driven AI improvement:

- `fight_ai/DECISION_TRACES.jsonl`
- `fight_ai/CANDIDATES.jsonl`
- `fight_ai/COUNTERFACTUALS.jsonl`
- `fight_ai/TEAM_PLANS.jsonl`
- `fight_ai/TACTICAL_CONTEXT.jsonl`
- `fight_ai/TEAM_THREAT_MATRIX.jsonl`
- `fight_ai/ACTION_OUTCOMES.jsonl`
- `fight_ai/MOVEMENT_OUTCOMES.jsonl`
- `fight_ai/TARGET_HISTORY.jsonl`
- `fight_ai/ENEMY_RESPONSE_DELTAS.jsonl`
- `fight_ai/OBSERVED_EFFECTS.jsonl`
- `fight_ai/ENEMY_MEMORY_UPDATES.jsonl`
- `fight_ai/TACTICAL_ANOMALIES.jsonl`
- `fight_ai/REPLAY.jsonl`

Some streams are intentionally empty until the corresponding live evidence/learning phase is implemented. The stable file presence lets future tooling evolve without changing the bundle contract every release.

Current anomaly derivation includes bounded-planning truncation, END_TURN certification contradictions, blocked tactical decisions, and unsettled/failed physical outcomes. Candidate traces retain the strongest rejected alternatives so future debugging can compare the selected action with realistic counterfactuals.

## Offline replay

`TacticalReplayRunner` is pure verification: it reconstructs the certified Canonical snapshot, combat profile, objective, and expected primitive decision from a fight trace and reruns `tactical_v1` offline. It has no execution authority and cannot send input. Live failures can therefore become deterministic regression fixtures without requiring repeated Dofus fights for every planner edit.

## Explicitly deferred

R5.132 does **not** claim universal level-200 zone mastery. It establishes the architecture and first Sufokia evidence pack. The following require later evidence-backed work:

- broader per-zone/per-monster capability packs;
- execution-authoritative post-action consequence scoring across full fights;
- confidence-weighted persistent enemy learning beyond the packaged capability catalog;
- controlled Enutrof summon turns (requires an explicit controlled-actor ownership model);
- larger multi-enemy/live acceptance and tuning of tactical weights;
- automatic promotion of real fight incidents into permanent replay fixtures.

## Live acceptance boundary

Offline tests prove contracts and preservation, not Dofus tactical quality. The first live acceptance should use the opt-in tactical mission and prove: correct policy-set compilation; Cra/Enu shared objectives; bounded decision latency; no illegal/duplicate physical actions; front guards never cast; placement assignments remain legal; fight-intelligence files are sufficient to reconstruct each critical decision; and legacy `sufokia_farm` remains unchanged when the tactical mission is not selected.

# R5.169 — Multi-Account Join Protocol Completion

## Purpose

R5.169 completes the missing two-account Dofus 3.6.12.16 fight-entry path using the simultaneous CRA+ENU capture `both_accounts_join_3_6_12_16.pcapng`, then hardens the surrounding identity/request causality so the new decoder can feed the existing Canonical State, Kernel, FightAI, party and execution layers without introducing protocol-revision logic above the adapter boundary.

The architecture remains:

`TCP -> framing/Any extraction -> revision adapter -> canonical events/state -> existing downstream layers`

No new 3.6.12.16 wire name is a FightAI, Kernel, party-policy, or physical-input policy dependency.

## Multi-account findings integrated

The simultaneous capture contains two independent game connections, three CRA world-attack requests, but only two authoritative fights. This proves outbound world attack traffic is request evidence only; canonical fight state starts only from server fight-entry authority.

For both successful fights the ENU follower observes server discovery/presentation, sends an exact join request carrying the fight id and CRA leader id, then receives the matching authoritative fight-entry boundary. R5.169 therefore enables `FIGHT_JOIN` and `JOIN_FIGHT_REQUEST` for `dofus_3_6_12_16` with exact request correlation rather than raw message-name matching.

The capture also corrects a dangerous solo-capture interpretation: the fight-entry relation's first actor field is the initiating/leader actor, not universally the local player. On the ENU connection that field is CRA. Local principal identity is instead proven from socket-local evidence such as world movement/name, placement request, spellbar principal identity, or locally initiated attack causality.

## Live state truth validated

The new capture was replayed together with the retained CRA/ENU captures and the protocol dictionary. R5.169 regression locks concrete trajectories instead of only checking that event families exist:

- CRA/ENU bootstrap: 2047/2045 HP, 7 AP, 3 MP respectively;
- authoritative placement cells and actor ids on both sockets;
- CRA movement `286 -> 271 -> 257 -> 270`, MP `3 -> 0`;
- CRA Tirs Eloignes AP `7 -> 6`, then two 3-AP actions `6 -> 3 -> 0`;
- ENU movement and MP gain/consumption in fight 130;
- ENU current/max HP erosion path `2045/2045 -> 2017/2043 -> 1984/2040`;
- identical shared cast, displacement, death, turn and AP/MP/range trajectories on both client connections;
- exact effect-instance removal and spell-property modifier cleanup;
- summon-controlled caster identity remains distinct from the account principal.

`iib` is now decoded as cross-account absolute party HP/max-HP evidence. It is used to seed player HP baselines but deliberately does not mutate active-fight HP because controlled packet ordering shows it can arrive before the matching authoritative damage consequence; this avoids double application.

## Tirs Eloignes / spell-range confirmation

The simultaneous capture contains a direct CRA Tirs Eloignes cast (`32465`) followed by 68 spell-property additions: two range properties for 34 spells. This includes Flèche Massacrante (`32457`) even though Massacrante itself still lacks a direct successful cast in the earlier all-spell capture. The result confirms the range-modifier mechanism is generic and is not implemented as a per-spell exception.

## Causality hardening added during final audit

The combined capture exposed several retry/identity races that are now closed:

- follower join execution searches the bounded request window for the exact fight/leader payload, so a newer unrelated/manual join request cannot erase valid proof of the transaction;
- world-attack execution performs the same exact-target bounded search before treating a newer different attack as a mismatch;
- world movement identity bootstrap tracks queued destination cells rather than a single boolean, so interleaved monster movement cannot consume the local-player causality edge;
- map-transition identity bootstrap is closed by authoritative map arrival when the own socket receives no transition-direction broadcast, preventing a much later other-player transition from being reused;
- pending attack/join/world-movement causality is generation-scoped and cleared at authoritative fight boundaries;
- Ready correlation still requires the positive boolean value, because an empty Ready-family packet is observed before a later true Ready in the controlled follower flow;
- the live-decoding verifier now resolves the workspace-selected active adapter from project metadata when both old and new adapters are registered, while the generic registry continues to fail closed on an ambiguous default.

## Auxiliary protocol coverage recovered during the final audit

The final comparison against the old adapter and the canonical reference also promoted the new challenge lifecycle instead of leaving it as raw diagnostics: `ktm` is OFFERED, `ktl` is ACTIVATED, `kth` carries target updates, and `ktk` carries the result. Failed challenges map to the existing canonical FAILED phase; successful results remain diagnostic because canonical reference v1 intentionally has no SUCCEEDED phase. This raises full canonical event/semantic reference coverage without inventing a phase that downstream code does not define.

`jte` remains a classified local-control/UI-ready marker. It is deliberately not made a second turn authority because `jvj` already owns TURN_START and the downstream controller uses canonical turn ownership. Likewise, `jug`, `jqh`, `jsy`, `jst`, `jtd` and similar high-frequency sequence/acknowledgement traffic remain raw diagnostics until independent evidence establishes a state transition they uniquely own.

## Evidence-driven authority rules

R5.169 keeps one authority per state transition:

- server movement/push/teleport destination wins over prediction;
- `jti` is a complete cooldown snapshot;
- exact effect deletion is owned by the effect-removal message and cannot be inferred from causal action ids alone;
- authoritative server cast identity owns the actual caster, which is essential for ENU controlled summons;
- AP/MP/range absolute characteristic snapshots reconcile action consequences rather than being double-applied;
- max HP is seeded from observed absolute/bootstrap authorities and erosion consequences; the adapter no longer invents a max-HP mutation from hypothetical characteristic ids never observed in any supplied `jtk` sample;
- full world snapshots reconcile removed monster groups;
- client requests never create fight/cell/Ready authority by themselves.

## Reverse-engineering limits retained

All canonical semantics required by the current protocol-independent live-decoding reference are now present, including follower join. High-frequency acknowledgement/sequence families remain classified and retained raw when they have no independently established canonical state authority. This is intentional: assigning state semantics to an acknowledgement family without evidence is more dangerous than leaving it diagnostic.

Two per-spell evidence holes remain explicit: CRA Flèche Massacrante and ENU Maladresse do not have direct successful casts in the supplied original spell captures. The generic cast decoder, spellbar and property-modifier mechanisms do not depend on per-spell hardcoding.

The certification system still reports five ORACLE-strength proof gaps (world map, local actor, actor cell, AP and MP). Their decoder fields and cross-flow trajectories are implemented and regression-tested; the remaining limitation is independent packet-aligned oracle strength. The supplied UI screenshots corroborate 7 AP / 3 MP and starting HP but are not falsely promoted to timestamp-aligned packet oracles.

## Release disposition

Offline multi-account protocol integration: **complete and verified**.

Windows/Dofus live acceptance: **PENDING**. The remaining certification result is `INSUFFICIENT_EVIDENCE`, not a known missing follower-join or core fight-state decoder. Live testing should therefore remain controlled/fail-closed until the independent ORACLE proof requirements are satisfied or the acceptance policy is deliberately revised with equivalent evidence.

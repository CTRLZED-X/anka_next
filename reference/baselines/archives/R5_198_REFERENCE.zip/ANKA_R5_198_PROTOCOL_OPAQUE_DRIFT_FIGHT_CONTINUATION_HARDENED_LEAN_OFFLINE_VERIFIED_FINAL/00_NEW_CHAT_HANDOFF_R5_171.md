# New Chat Handoff — R5.171

Current workspace: **ANKA R5.171 — Unity Bridge Runtime-Reflection Hardening**.

Start from R5.171, not R5.170. The reported setup failure was caused by a stale bridge build requirement for `BepInEx\interop\Ankama.Dofus.Core.World.dll`. R5.171 removes Dofus-specific compile-time assembly-name dependencies entirely. `CustomGridGenerator` is found at runtime by full type name/reflection and must still pass the existing 560-cell semantic and actor-cell validation gates.

Normal operator flow remains `setup.bat` once, then `start.bat` -> Script Studio -> Launch. If setup fails after the Python environment is available, collect `runtime/startup/setup_failure_debug.zip`; it now contains `projection/bridge_environment.json` with the exact local BepInEx/interop inventory.

Do not weaken projection validation to make the bridge appear ready. Do not restore compile-time `Core.dll` / `Ankama.Dofus.Core.World.dll` requirements. The next live milestone is: rerun setup on Windows, start Dofus, verify bridge health/discovery, then continue controlled live acceptance and protocol ORACLE evidence collection.

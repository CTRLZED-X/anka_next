# R5.170 — Protocol Schema-Drift Fail-Closed Hardening

## Purpose

R5.170 keeps the evidence-backed Dofus 3.6.12.16 integration and multi-account join chain from R5.168/R5.169, then closes a full-chain safety gap discovered during the post-integration audit: protocol transform health existed in capture/runtime diagnostics, but the final physical-input `RuntimeHealthFence` did not consume the active transform-error latch. A decoder failure could therefore be visible to diagnostics/continuity while the execution boundary still looked fresh enough to admit input.

This milestone also hardens two revision-local decoder surfaces against silent protocol drift:

- a newly observed `jsq` fight-action id outside the explicitly supported action inventory is now a `ProtocolSchemaDriftError` instead of classified zero-event success;
- a newly encoded `jtk` characteristic composition branch is now schema drift instead of falling through to an incorrect zero value;
- a completely new outer wire type that is not in the revision manifest/known opaque compatibility catalog is now sticky protocol drift instead of harmless-looking diagnostic traffic.

The architecture remains unchanged:

`TCP -> framing/Any extraction -> revision adapter -> canonical state -> Kernel/FightAI -> ExecutionService`

No Dofus 3.6.12.16 wire identifier is introduced above the protocol boundary.

## Why this change is necessary

R5.169 correctly decodes every `jsq` action id observed across the retained CRA, ENU and simultaneous captures. Before R5.170, however, an unknown future action id reached the final `return ()` path. That was conservative with respect to mutation, but it could hide a protocol change that actually carried a decision-critical state consequence.

Similarly, `_new_characteristic_total()` understands all 1,123 `jtk` rows in the controlled corpus, whose oneof composition branches are exactly 1, 3 or 5. Before R5.170, a future unrecognized branch could produce a zero characteristic and overwrite authoritative AP/MP/range/shield state.

R5.170 changes these cases from "unknown but apparently healthy" into explicit protocol-schema drift.

## Decoder hardening

### Explicit `jsq` action inventory

The new adapter now has one `_SUPPORTED_JSQ_ACTIONS` inventory combining:

- canonically mutating action families (cast, push, teleport, damage, heal, death, summon, look change);
- reference-only causal/action ids whose state authority is elsewhere (`jtk`, `juu`, etc.);
- stable generic action semantics already supported by the project dictionary.

The three retained 3.6.12.16 captures contain 980 `jsq` messages spanning 33 distinct action ids, and every one is covered by the explicit inventory.

An action outside that set raises `ProtocolSchemaDriftError`. This does **not** invent its meaning and does not mutate state.

### Characteristic composition drift

For `jtk`, controlled evidence shows exactly one length-delimited composition branch per current-stat row: branch 1, 3 or 5. R5.170 now:

- rejects unknown length-delimited composition branches;
- rejects ambiguous multiple known composition branches;
- keeps genuinely empty composition as zero for compatibility with the documented zero case;
- re-raises schema drift through fighter/summon optional parsing instead of swallowing it as ordinary missing optional data.

This prevents a new AP/MP encoding from silently becoming AP=0/MP=0.

## Runtime health integration

`LiveTransportRuntime` already maintained `last_error`. R5.170 makes schema drift a sticky runtime-generation condition and exposes:

- `protocol_schema_drift_active`;
- `protocol_schema_drift_count`;
- `last_protocol_schema_drift_detail`;
- monotonic/UTC timestamps and age.

Ordinary transform failures retain the existing recovery behavior: later healthy canonical progress can clear the active error. `ProtocolSchemaDriftError` does not auto-clear on unrelated canonical traffic. The selected protocol implementation must be investigated/updated and a fresh runtime started.

## Physical-input fail-closed boundary

`RuntimeHealthFence`, which is passed directly to `ExecutionService`, now blocks physical automation when:

- `protocol_decoder_ready` is explicitly false;
- `last_error` reports an active protocol transform failure;
- framing has dropped bytes in the active capture generation;
- a truly unclassified outer wire message was observed.

The new blockers are:

- `PROTOCOL_DECODER_NOT_READY`
- `PROTOCOL_TRANSFORM_ACTIVE`
- `PROTOCOL_UNCLASSIFIED_ACTIVE`
- `PROTOCOL_FRAME_DESYNC_ACTIVE`

Known revision-owned opaque compatibility traffic is still permitted through the explicit compatibility catalog; only a wire type outside both the adapter classification and that catalog raises the sticky unclassified guard.

This aligns the final input boundary with the capture/runtime and campaign-continuity safety model. Fresh packets alone can no longer make execution READY while the decoder is actively unhealthy.

## Packaging portability

The delivery `config.yaml` no longer contains a developer-machine absolute `Maps` fallback path. The current four-map square is already present under bundled `gamedata/Mapuse`; `maps_directory` is therefore `null` by default and remains an optional fallback for operators who later add maps outside the bundled route. This keeps readiness portable across extraction locations instead of blocking on a nonexistent workstation path.

## Evidence and compatibility

The retained CRA, ENU and simultaneous 3.6.12.16 captures replay without schema-drift failures. Historical 3.6.10.10 adapter code remains unchanged.

The live-decoding certificate remains `INSUFFICIENT_EVIDENCE`, not `BLOCKED`: required semantic/reference coverage remains 100%, while the same five ORACLE-strength proof gaps remain for world map, local actor, actor cell, current AP and current MP. R5.170 does not falsify those evidence gates.

The two spell-specific evidence limitations remain explicit: successful direct casts are still absent for CRA Flèche Massacrante and ENU Maladresse in the retained original spell captures. Generic cast/property decoding is not hardcoded per spell.

## Release disposition

- New-protocol integration: retained and hardened.
- Multi-account follower join: retained.
- Protocol schema drift: now explicit and fail-closed at physical input.
- Offline verification: required before packaging and recorded separately.
- Windows/Dofus live acceptance: **PENDING**.

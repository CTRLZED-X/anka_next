# R5.165 Live-Truth, Ready Recovery & Trajectory Hardening

## Incident authority

R5.165 is driven by `runtime(20261004-222408).zip` and the user-supplied `TrajectoryLab_v2` reference.

The terminal incident occurred while preparing fight instance `613`, after the campaign had successfully launched and completed prior fights. The causal terminal code was `READY_REQUEST_RETRY_EXHAUSTED` at boundary `FIGHT_READY_REQUEST` for CRA.

The evidence does **not** prove a total internet outage. Both account sockets remained established, capture continued, and ENU successfully emitted `jyo` and received Ready acknowledgement. However, CRA's server-to-client gameplay flow exhibited a short directional live-truth stall: the relevant `jyk` broadcast reached ENU at approximately `22:09:47.634` and CRA at approximately `22:09:51.932`, about 4.3 seconds later. R5.164's broad continuity threshold was much longer than this, so the Ready-specific retry budget could expire before transport continuity was classified.

At the same time, CRA's Ready mouse transactions were physically completed at the calibrated control but produced no observed outbound `jyo`. Therefore the durable repair must handle **both** transient per-client inbound lag and client/UI Ready delivery misses without assuming one caused the other.

## Root-cause repairs

### 1. Directional live-truth health

`RuntimeHealthFence` now identifies and latches a primary gameplay flow independently for server→client and client→server directions. Account-wide packet freshness is no longer enough to hide a stale inbound gameplay stream when outgoing traffic remains fresh.

The flow latch is conservative:

- short stalls do not switch to a noisy auxiliary socket;
- a replacement flow is admitted only after the latched flow is materially stale/terminal and another flow is demonstrably fresh;
- historical FIN/RST counters on a reused TCP 4-tuple do not mark a new SYN generation terminal;
- current-generation control timestamps remain visible in diagnostics.

### 2. Short per-client continuity holds

CampaignRuntime adds two early directional continuity gates:

- `SERVER_TO_CLIENT_READY_STALL` after a Ready click is semantically proven absent;
- `SERVER_TO_CLIENT_ACTION_STALL` while an exact campaign transaction is waiting for semantic/settlement evidence.

These blockers are transient continuity conditions, not permission to retry. While active:

- physical child workflows do not advance;
- the campaign watchdog is suspended;
- recovery requires a continuous healthy stability interval;
- possibly-sent/unknown actions remain observe-only;
- prolonged or hard failures still fail closed.

### 3. Bounded Ready soft recovery

The original three Ready attempts remain the normal path. If repeated input-free protocol probes positively prove that no `READY_REQUEST` was emitted, R5.165 permits up to two additional recovery attempts by default.

Each recovery episode requires:

1. semantic proof that the previous Ready request is absent;
2. no active directional live-truth stall;
3. a no-input cooldown;
4. normal window re-arming;
5. a click-free pointer excursion away from the control and exact re-entry to the calibrated Ready endpoint;
6. another semantic Ready re-admission before the click.

No recovery click is authorized when the Ready request is observed or unknown. The maximum remains bounded and exhaustion is explicit as `READY_RECOVERY_EXHAUSTED`.

### 4. General recovery policy

R5.165 does not pretend that arbitrary client process restart/login is safe. There is no certified restart/relogin authority in the current architecture, and restarting during an uncertain send could duplicate or corrupt an action. The recovery hierarchy is therefore:

- transient live-truth stall → hold and resume after stability;
- certainly-not-sent / semantically-absent Ready → bounded soft recovery;
- uncertain/possibly-sent action → observe only;
- confirmed reconnect → rebind to fresh transport generation;
- prolonged continuity loss or hard identity/protocol fault → fail closed with complete evidence.

A future automatic process restart must be implemented as its own certified lifecycle boundary, not as an exception handler side effect.

## TrajectoryLab_v2 verification

R5.165 does not copy TrajectoryLab_v2 byte-for-byte. The comparison found that its useful spatial characteristics are:

- approximately seven correlated lateral knots for medium/long motion;
- irregularity around 0.62;
- occasional stronger local corrections;
- endpoint tapering;
- two low-amplitude tapered micro-wobble frequencies.

Production pointer motion now ports those spatial characteristics more closely while preserving ANKA safety properties that are stronger than the lab:

- monotonic minimum-jerk along-chord progression;
- exact certified endpoint arrival;
- bounded maximum emitted step;
- safe-endpoint selection only from caller-certified points;
- foreground/interference checks;
- distance-banded curvature so short corrections are not exaggerated.

The lab's per-sample forward-jitter expression is deliberately not copied because its random frequency is resampled inside the point loop, which is less smoothly correlated and less predictable than ANKA's minimum-jerk forward profile.

A 300-seed deterministic comparison at a ~700 px chord shows the production profile at a median **5 lateral direction changes**, about **14 px** maximum lateral deviation and about **1.0045** tortuosity. A direct statistical port of TrajectoryLab_v2's default spatial generator on the same chord is about **5 direction changes**, **12.2 px** median maximum lateral deviation and **1.0039** tortuosity. The shapes are therefore deliberately similar rather than byte-identical. ANKA becomes more conservative again on very long paths because it retains an absolute safety cap, and it keeps minimum-jerk monotonic forward progression instead of the lab's per-sample forward jitter.

## Forensic improvements

A new `analysis/live_transport_recovery_health.json` report records only causally useful continuity transitions, affected accounts, primary directional flows, Ready/pending-action transport gates, thresholds and recovery policy.

`analysis/action_convergence_health.json` schema v2 now groups passive settlement polling by transaction lineage. Multiple normal launch transactions are no longer collapsed into one apparent mission-long loop. Actual repeated pre-input blockers remain separately classified as retry thrash.

Campaign runtime status retains the current action transaction on the hot path without rebuilding full action history, allowing short transport gates to correlate the exact owner/account/action cheaply.

## Configuration defaults

- Ready inbound stall suspicion: `3.25 s`
- General pending-action inbound stall suspicion: `5.0 s`
- Continuity recovery stability: `2.0 s`
- Continuity hold timeout: `600 s`
- Normal Ready attempts: `3`
- Extra Ready recovery attempts: `2`
- Ready recovery cooldown: `3.0 s`
- Ready recovery pointer excursion: `42 px`

These are evidence-driven bounded defaults, not generic timeout inflation.

## Live acceptance criteria

The next controlled run should prove:

1. transient per-client inbound lag produces `CONTINUITY/HOLD` rather than a premature Ready/action terminal failure;
2. automation resumes only after healthy stability;
3. a Ready click with proven absent `jyo` can recover through the bounded soft-recovery path;
4. observed/unknown Ready sends never receive a blind duplicate click;
5. a genuine reconnect can switch the directional primary flow without inheriting historical FIN/RST terminality;
6. mission counting and terminal fight cleanup from R5.164 remain intact;
7. one debug package contains transport-recovery, action-convergence, pointer, campaign and control-authority evidence sufficient for diagnosis.

Windows/Dofus live acceptance remains **PENDING** until these are proven on the real client.

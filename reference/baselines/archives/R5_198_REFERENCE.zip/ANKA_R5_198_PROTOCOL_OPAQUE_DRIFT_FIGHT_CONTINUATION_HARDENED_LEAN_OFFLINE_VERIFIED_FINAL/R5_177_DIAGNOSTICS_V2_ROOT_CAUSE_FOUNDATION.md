# R5.177 — Diagnostics V2 & Root-Cause Foundation

R5.177 is a behavior-preserving observability/diagnosability release over R5.176. It does not change physical-input authority, startup authorization, Canonical State, Kernel legality, FightAI policy, or the public protocol adapter contract.

The release adds a read-only Diagnostics V2 layer with independently bounded collectors, explicit collector completeness, a normalized lifecycle boundary graph, project Failure Registry integration, downstream-consequence classification, and a root-evidence sufficiency contract.

The intent is that a future runtime package can state both **what broke first** and **whether the package contains enough evidence to diagnose that failure class**. “No execution occurred” is represented as `NOT_APPLICABLE`, not as missing evidence; a collector failure is isolated from all other collectors and from bundle completion.

See `docs/architecture/DIAGNOSTICS_V2.md` and `DEBUGGING.md`.

Windows/Dofus live acceptance remains pending.

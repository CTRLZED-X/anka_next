# ANKA Platform R5.138 — New Chat Handoff

## 1. Purpose of this handoff

This file is the authoritative human-readable handoff for continuing ANKA Platform work in a new ChatGPT conversation without rediscovering the project from scratch.

Current checkpoint:

`ANKA_PLATFORM_R5_138_TACTICAL_IMPACT_GEOMETRY_CAST_TARGET_INTEGRITY_HARDENING_WINDOWS_LIVE_CANDIDATE`

Current status:

- Offline/systemic verification: **PASS**.
- Windows/Dofus live acceptance for R5.138: **PENDING**.
- Final production release: **NO**. This is still a live candidate.
- Primary triggering runtime: `runtime(20260926-130218)`.
- Sealed behavioral parent: R5.137.
- Sealed historical runtime identity remains R5.115 / platform `0.1.0a122` by design; the current workspace checkpoint is R5.138.
- Kernel version: `0.1.0a58`, checkpoint `R10I Runtime Spell Readiness Contracts`.

The next chat should read, in order:

1. `00_NEW_CHAT_HANDOFF_R5_138.md`
2. `R5_138_TACTICAL_IMPACT_GEOMETRY_CAST_TARGET_INTEGRITY_HARDENING.md`
3. `PROJECT_STATUS.json`
4. `PROJECT_CONTEXT.json`
5. `verification/R5_138_RUNTIME_20260926_130218_ROOT_CAUSE.md`
6. `verification/R5_138_OFFLINE_VERIFICATION.md`
7. `ARCHITECTURE.md`
8. `DEBUGGING.md`
9. `WINDOWS_LIVE_RUNBOOK.md`

Do not start by rewriting the architecture. First preserve the current invariants and use new live evidence to justify further changes.

---

## 2. Project goal

ANKA is an independent Windows/Dofus multi-account automation platform. It must control a team reliably across world navigation and fights while remaining deterministic, fail-closed, diagnosable, and safe against stale state or uncertain physical input.

The immediate live goal is:

- Cra `Curseni` is the leader and active combat controller.
- Enutrof `Sosoking` is a required active combat controller.
- Both accounts must enter the same fight, place, Ready, fight cooperatively, finish the fight, return to world, continue the route, and repeat until the configured stop condition.
- Default tactical mission: `sufokia_farm_tactical_v1`.
- Default route start: `[7, -12]`.
- Direction cycle: `R D L U`, looped.
- Target groups: 6–8 monsters.
- Default run budget: 5 attempts / 5 target wins, stop on loss or unknown.

Longer-term goal: support robust multi-account teams and arbitrary level-200 areas, with Cra+Enu as the tactical core and optional passive/front-guard accounts later.

---

## 3. Non-negotiable architecture

ANKA is **independent**. External projects/documentation may be used only as conceptual/mechanics references. Do not add a runtime dependency on Ankabot or any other bot framework.

The major authority split is:

```text
Network / client evidence
        ↓
Canonical State per account
        ↓
party/team synchronization
        ↓
FightAI / strategy proposes ONE primitive action
        ↓
Kernel evaluates deterministic mechanics + legality
        ↓
FightActionAdmissionService revalidates latest state
        ↓
ExecutionService — sole physical-input authority
        ↓
Canonical settlement / packet causality
        ↓
replan
```

Important invariants:

- Canonical State is live semantic truth.
- Kernel is deterministic mechanics/legality, not a live-state owner.
- FightAI proposes actions; it does not own physical input.
- `ExecutionService` is the only component allowed to create physical input.
- Every primitive action must settle before the next primitive action is planned/executed.
- Unknown evidence is not converted into optimistic truth.
- Cross-account Canonical revision numbers must never be globally ordered; revisions are lane-local.
- Preparation-only causal identity may never leak into ACTIVE combat authority.
- No tactical spell/cell incident may be fixed by hard-coded spell IDs or cell IDs in generic runtime logic.

---

## 4. Important current files / hotpaths

### Application and orchestration

- `src/anka_platform/application/service.py`
- `src/anka_platform/core/session_compiler.py`
- `src/anka_platform/campaign/runtime.py`
- `src/anka_platform/core/fight/workflow.py`
- `src/anka_platform/party/mission.py`

### Party / fight entry / identity

- `src/anka_platform/local_fighter_identity.py`
- `src/anka_platform/party/shared_fight.py`
- `src/anka_platform/core/fight/entry_coordinator.py`
- `src/anka_platform/core/fight/controller.py`

### FightAI

- `src/anka_platform/core/fight/decision_service.py`
- `src/anka_platform/fight_ai/tactical_policy.py`
- `src/anka_platform/fight_ai/tactical/`
- `src/anka_platform/fight_ai/telemetry/`

### Kernel / mechanics

- `src/anka_game_kernel/mechanics/aoe/service.py`
- `src/anka_game_kernel/mechanics/targeting/service.py`
- `src/anka_game_kernel/mechanics/casting/service.py`
- `src/anka_game_kernel/mechanics/fight/service.py`
- `src/anka_platform/integration/kernel_context.py`

### Execution / admission

- `src/anka_platform/execution/fight_action_admission.py`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/execution/transactions.py`
- `src/anka_platform/execution/control_authority.py`

### Protocol / Canonical / projection

- `src/anka_platform/protocol/adapters/dofus_3_6_10_10/r4.py`
- `src/anka_platform/contracts/canonical_state.py`
- `src/anka_platform/live_state/`
- `src/anka_platform/projection/`

### Diagnostics

- `src/anka_platform/observability/exporter.py`
- `src/anka_platform/observability/run_store.py`
- `DEBUGGING.md`

---

## 5. Current team / configuration

`config.yaml` currently defines:

- leader account: `cra`
- Cra character: `Curseni`
- Enu character: `Sosoking`
- both roles: `ACTIVE_CONTROLLER`
- both required: `true`
- Cra activation hotkey: F7
- Enu activation hotkey: F8
- web host: `127.0.0.1`
- web port: `8000`
- Dofus protocol adapter: `dofus_3_6_10_10`
- game version: `3.6.10.10`
- decision budget: 3.0 seconds
- max combat actions per turn: 12

The configured Cra combat profile contains 22 enabled spells and the Enu profile contains 22 enabled spells.

R5.136 audited all 44 configured selected grades through the generic readiness/mechanics pipeline. Do not reintroduce spell-specific legality branches.

---

## 6. Release history that matters now

### R5.132 — tactical architecture

Introduced the current tactical Cra/Enu architecture, team strategy, candidate scoring, shared target selection, telemetry/replay foundations, and primitive-action replanning.

### R5.133 — generic level-200 tactical hardening

Generalized tactical reasoning beyond zone-specific assumptions, improved threat/capability reasoning and fight diagnostics.

### R5.134 — team observation synchronization

Fixed cross-account synchronization semantics. Revisions are lane-local. Team actions require semantic epoch convergence rather than choosing whichever lane has the larger revision number.

### R5.135 — spell readiness + action admission

Triggered by a real illegal second `Tirs Éloignés` attempt.

Systemic fixes included:

- fight-persistent confirmed spell-use history;
- recast interval / multi-turn cooldown derivation;
- initial cooldown;
- per-turn and global-turn usage;
- per-target usage with frozen target actor identity;
- configured/verified grade provenance;
- latest-state PRE_SLOT/PRE_TARGET Kernel admission;
- client-local cast rejection causality using capture-covered negative evidence;
- exact action quarantine/replan;
- failure-path FightAI diagnostics.

### R5.136 — all-spell Range/PO readiness

Audited all 44 configured Cra+Enu selected grades and fixed live Range/PO propagation. Explicit protocol characteristic 19 is used as observed range bonus; missing evidence remains UNKNOWN rather than being assumed zero.

### R5.137 — fight-entry local identity causal hardening

Triggered by `runtime(20260926-113645)`: Enu entered but nothing happened.

Root cause: Cra's fight-local identity packet arrived too late; entry convergence waited through almost the whole placement timer, so no placement/Ready occurred before Dofus auto-started combat.

Systemic repair:

- exact-generation preparation identity bridge from confirmed launch/join/world-local identity;
- actor must be positively present in the exact fight;
- canonical fight-local identity remains stronger;
- disagreement becomes hard conflict;
- preparation bridge is prohibited from ACTIVE combat authority;
- one-snapshot-per-account preparation decisions;
- improved preparation root-cause diagnostics.

### R5.138 — tactical impact geometry + cast target integrity

Triggered by `runtime(20260926-130218)`, fight 93.

This is the current checkpoint.

---

## 7. R5.138 live findings and root causes

### A. Round-4 confirmed AoE model contradiction

Cra used `Carreaux Destructeurs` on cell 411 while FightAI intended enemy `-3` on cell 397.

Server evidence confirmed the cast and AP consumption, but no enemy consequence occurred. Cra then directly cast `Flèche de Recul` on cell 397 and killed the target.

Root cause: the generic Kernel `FORK` area primitive was modeled as a lateral T. Real Dofus fork geometry is the selected cell plus three forward-oriented prongs relative to caster → selected cell.

This was fixed in the **generic AoE primitive**, not with a Carreaux spell-ID exception.

### B. Round-5 cast timeout / semantic target integrity

Cra was on cell 453. Enemy `-5` was on cell 400. FightAI selected `Flèche Ralentissante` on empty cell 412 because the real size-2 cone could affect the intended enemy.

Important: supplied evidence does **not** prove cell 412 is non-walkable. Static map/projection says it is projectable/walkable. Do not add a fake non-walkable rule based on appearance.

The real defect was that FightAI's intended `target_actor_id=-5` was lost before execution admission. Old admission could prove that cell 412 was castable, but could not prove that the intended actor remained semantically affected at click time. The click then produced no confirmed semantic cast request and ended as uncertain/timeout.

R5.138 preserves target actor identity and requires Kernel-certified effect eligibility at both admission gates.

---

## 8. R5.138 systemic changes

1. **Generic FORK geometry corrected**
   - forward directional three-prong geometry;
   - correct orientation and map-edge clipping;
   - real round-4 cells retained as regression fixtures.

2. **Semantic target actor propagation**
   - FightAI target actor survives controller → execution.

3. **PRE_SLOT + PRE_TARGET target-impact admission**
   - if FightAI names a target actor, Kernel must certify that actor in effect `eligible_actor_ids`;
   - deterministic absence => REJECTED / no click;
   - unresolved semantics => UNKNOWN / no click.

4. **Geometry-only actor fallback removed**
   - an actor occupying an AoE cell is not automatically treated as effect-eligible.

5. **Targeting dependency minimization**
   - Kernel no longer asks for summon status when the effect target spec does not distinguish summon vs non-summon for the resolved team side.

6. **Cast causality hardened**
   - exact target projection/click evidence is retained;
   - client-local rejection requires repeated same-generation capture-covered negative evidence;
   - incomplete evidence remains UNCERTAIN.

7. **Failure-path FightAI telemetry recovered**
   - the action that transitions ACTIVE → FAILED/UNCERTAIN must remain in Fight Intelligence even if the normal recorder step is bypassed.

8. **Immediate move reversal guard**
   - same-turn A→B→A oscillation is quarantined/replanned.

9. **Enemy-benefit safety**
   - a cast proven to grant enemy AP/MP/range/heal/shield benefit is a hard blocker, not merely a scoring penalty.

10. **Decision-budget reserve**
    - expensive reachability/candidate work is not started inside the protected deadline tail.

---

## 9. Current verification state

The final R5.138 candidate is offline verified.

Important completed verification includes:

- Package manifest integrity.
- Full Python compilation.
- R5.138 current-release suite.
- Directly affected AoE/targeting/Carreaux/Massacrante/Ralentissante/controller/admission/cast-causality/tactical-safety tests.
- Parent release-lineage checks.
- Broad execution, party, core-fight, protocol, projection, observability, scripting and historical hardening suites were run in bounded completed groups during R5.138 verification.

See:

- `verification/R5_138_OFFLINE_VERIFICATION.md`
- `PROJECT_STATUS.json`
- `tests/r5138/`

Do not treat aggregate commands that merely timed out as passes; only explicit completed bounded summaries count.

---

## 10. What still needs to be done

### A. Mandatory: fresh Windows/Dofus R5.138 live acceptance

This is the next task. Offline testing cannot prove real UI projection, Dofus client timing, or actual packet/click behavior.

Success criteria for a bounded live run:

```text
Launch once
→ leader creates fight
→ Enu joins
→ party entry converges before placement timeout
→ placement succeeds
→ both Ready
→ FIGHT_ACTIVE
→ FightAI decisions are recorded
→ Cra and Enu both act
→ no false FORK/AoE hit prediction
→ tactical target actor survives to PRE_SLOT/PRE_TARGET
→ no semantic target click if intended actor is not Kernel-certified
→ if client locally rejects a cast and negative evidence is provable, candidate is quarantined and AI replans
→ fight terminates
→ both accounts leave
→ one canonical outcome commit
→ world re-entry
→ next fight starts
→ continue until configured stop condition
```

Do not manually help the automation during acceptance. Manual join/Ready/cast/move would contaminate causal evidence.

### B. Controlled summons are still deliberately conservative

The Kernel knows mechanics for the configured Enu summon spells, but ANKA does not yet have a fully certified live maximum summon-capacity contract. Unknown capacity must remain fail-closed; do not guess a free summon slot.

### C. Generic active-effect lifetime/removal remains conservative

Positive effect evidence exists, but universal effect removal/expiry completeness is not sufficiently certified for every effect. Do not implement a generic “buff absent/present” lifetime heuristic that can suppress useful actions incorrectly.

### D. External Maps directory is still an environment dependency

Current `config.yaml` contains:

`C:/Users/dell/Desktop/ankabot/gamedata/Maps`

ANKA does **not** depend on Ankabot runtime/API; this is simply the current external map-data directory name. On the existing Windows machine it previously supplied missing map files to the validated fallback importer.

For portability, either ensure that directory exists on the live machine or move the same validated Maps dataset to an ANKA-owned location and update `kernel.maps_directory`. Do not remove the fallback unless all needed map data is packaged another way.

### E. Live acceptance of the round-5 client rejection path is still pending

R5.138 proves the intended actor before click and improves cast causality, but only a new real run can show whether the Dofus client still rejects that exact kind of empty-cell AoE click. If it does, preserve the first runtime and inspect projection/cast-causality evidence before changing geometry again.

---

## 11. Exact Windows live-test procedure

Use a fresh extraction of the final R5.138 ZIP. Do not merge it into an older project folder and do not copy old `runtime/` or `.venv` into it.

1. Run `setup.bat` once if needed for this fresh folder.
2. If bridge installation is needed, close Dofus and run `install_bridge.bat`, then reopen Dofus.
3. Open Curseni and Sosoking and let both clients fully load.
4. Put both accounts at the configured start state/map for the mission.
5. Run `start.bat`.
6. Verify the current Script Studio/session plan belongs to **R5.138**, not an older server/process.
7. Run `live_preflight.bat` and require `LIVE_PREFLIGHT=READY_FOR_CONTROLLED_LIVE_TEST`.
8. Confirm both required accounts are detected and bound to the correct windows.
9. Confirm route start/directions, monster range, target wins/max attempts, and tactical mission/policy.
10. Press **Launch exactly once**.
11. Do not manually join, Ready, move, cast, or click a monster to help the run.
12. Let the bounded run continue until success or first autonomous failure.

At the first autonomous failure, do **not** immediately restart. Export/preserve diagnostics first.

---

## 12. What debug evidence to send next

Best artifact: the complete newest runtime/incident ZIP from the R5.138 attempt.

Critical files to inspect first:

```text
analysis/lifecycle_boundary_matrix.json
analysis/lifecycle_transition_trace.json
analysis/control_authority_history.json
analysis/physical_input_ledger.jsonl
analysis/fight_entry_trace.jsonl
analysis/failure_chain.jsonl
analysis/causal_root.json
campaign/runtime.json
campaign/timeline.jsonl
studio/latest_run_session_plan.json
party/preflight.json
party/reconciliation.json
execution/actions_enriched.jsonl
execution/pending_settlement.json
execution/active_fence.json
accounts/cra/canonical_events.jsonl
accounts/enu/canonical_events.jsonl
capture/protocol_window.jsonl
capture/protocol_unknown_inventory.json
fight_ai/DECISION_TRACES.jsonl
fight_ai/TEAM_PLANS.jsonl
fight_ai/CANDIDATES.jsonl
fight_ai/ACTION_OUTCOMES.jsonl
fight_ai/CANONICAL_CONSEQUENCES.jsonl
fight_ai/TACTICAL_ANOMALIES.jsonl
fight_ai/REPLAY.jsonl
```

For a suspicious cast, reconstruct this exact chain:

```text
FightAI candidate
→ intended target_actor_id + target_cell_id
→ Kernel affected_cells
→ Kernel eligible_actor_ids by effect
→ PRE_SLOT admission
→ spell slot projection
→ PRE_TARGET admission
→ exact projected screen/client click point
→ physical input ledger
→ outbound semantic cast request observed? (jrj)
→ server-confirmed cast
→ AP/cooldown/effect/damage consequences
→ settlement outcome
```

Do not infer “bad cell” only from how a Dofus tile looks on screen.

---

## 13. Diagnostic rules for the next chat

When a new live failure arrives:

1. Identify the **first broken lifecycle boundary**, not the last wrapper error.
2. Determine whether physical input was actually sent.
3. If a CAST is involved, separate:
   - planner geometry/semantics,
   - admission legality,
   - projection/click,
   - client semantic request,
   - server confirmation,
   - post-cast consequences.
4. Do not change Kernel mechanics solely because a client click was rejected.
5. Do not call a cell non-walkable from appearance; require Static/Mapuse/protocol/projection evidence.
6. Do not compare Cra revision numbers against Enu revision numbers as if globally ordered.
7. Do not use a preparation causal identity for ACTIVE combat.
8. Do not count a spell use until authoritative cast evidence confirms it.
9. Preserve actor identity for per-target usage; cell identity is not stable after movement.
10. Any fix should be generic to the mechanics/contract family unless evidence proves a spell-specific exception really exists.

---

## 14. Development / packaging rules

- Windows + VS Code target environment.
- Deliver one ZIP with exactly one top-level project folder.
- Do not package `runtime/`, `.venv`, caches, or unrelated temporary data.
- Rebuild `PACKAGE_MANIFEST.json` with `tools/build_package_manifest.py` after any immutable file changes.
- Verify the package manifest before delivery.
- Compile source/tests.
- Run the relevant current-release suite and the affected parent regression suites.
- Independently extract the final ZIP and repeat manifest/context/current-release checks against the extracted bytes.
- Keep `offline_verified=false` while code is changing; set it true only after the frozen-tree verification passes.
- Keep Windows/Dofus live acceptance `PENDING` until a fresh live run proves it.

---

## 15. Most important current status statement

R5.138 has a strong offline foundation and directly addresses the two failures observed in `runtime(20260926-130218)`:

- the round-4 false Carreaux/FORK impact prediction is fixed generically;
- the round-5 cast path now retains and revalidates the intended target actor semantically instead of validating only the target cell.

However, **R5.138 is not yet live-proven**. The next correct action is a fresh bounded Windows/Dofus run using the final R5.138 ZIP. If it fails, preserve the first complete runtime/debug package and diagnose from that single evidence set before making more changes.

> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# R5.198 bounded Windows/Dofus live acceptance

Use a **fresh R5.198 extraction** and rerun `setup.bat` because protocol/source evidence changed. Require `SETUP=READY` and `ANKA_SERVER=READY` before launching.

Perform one bounded CRA+ENU fight and prove this chain:

`shared fight -> placement -> Ready -> ACTIVE -> CRA first CAST settles -> CRA continues instead of protocol-health stop -> authoritative CRA→ENU handoff -> ENU action/turn -> fight end -> world re-entry`

Any genuinely new or changed protocol payload must still fail closed and be exported with exact evidence. Preserve the generated runtime/debug ZIP if the run stops and replay it offline before patching.

# ANKA R5.153 — New Chat Handoff

This workspace is the **R5.153 Controlled Zone-200 Pilot Evidence & Strategy-Routing Hardening** candidate.

Read first:

1. `R5_153_CONTROLLED_ZONE_200_PILOT_EVIDENCE_ROUTING_HARDENING.md`
2. `FIGHT_POLICY_CHANGE_GUIDE.md`
3. `PROJECT_STATUS.json`
4. `ARCHITECTURE.md`
5. `DEBUGGING.md`
6. `LIVE_ACCEPTANCE.md`

## Current objective

The foundation is frozen by default. R5.153 prepares the first real level-200 pilot and makes the resulting debug package self-routing.

`zone200_pilot.bat` must be used before the pilot. It records the exact config SHA-256 and verifies the bounded 3–5 fight contract plus passive live readiness.

After the run, inspect:

- `pilot/intent.json`
- `analysis/zone_200_encounters.json`
- `analysis/zone_200_readiness.json`
- `analysis/foundation_health.json`
- `fight_ai/FIGHT_SUMMARY.json`
- `fight_ai/DECISION_TRACES.jsonl`
- `fight_ai/ACTION_OUTCOMES.jsonl`
- `fight_ai/ACTION_EFFECTS.jsonl`

If `strategy_iteration.post_run_route` is `FIGHT_AI_TEAM_STRATEGY_ITERATION`, keep foundation layers unchanged by default and improve tactical logic only. If foundation blockers are present, trace the owning contract before changing anything.

R5.153 does **not** claim generic autonomous level-200 readiness. Remaining mechanics/truth gaps stay explicit and fail-closed.

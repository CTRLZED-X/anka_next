# ANKA Platform R5.140 — New Chat Handoff

## 1. Current authority

Current checkpoint:

`ANKA_PLATFORM_R5_140_COMBAT_FRAME_FEASIBILITY_RECOVERY_TACTICAL_FOUNDATION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Current state during freeze:

- offline/systemic verification: **IN PROGRESS** until `PROJECT_STATUS.json` says `offline_verified=true`;
- Windows/Dofus live acceptance: **PENDING**;
- final production release: **NO**;
- behavioral parent: R5.139;
- sealed runtime identity remains R5.115 / platform `0.1.0a122` by design;
- Kernel identity remains `0.1.0a58`, `R10I Runtime Spell Readiness Contracts`.

Read in this order:

1. `00_NEW_CHAT_HANDOFF_R5_140.md`
2. `R5_140_COMBAT_FRAME_FEASIBILITY_RECOVERY_TACTICAL_FOUNDATION_HARDENING.md`
3. `R5_139_CAST_TRANSACTION_UI_NEUTRALITY_PROTOCOL_NEGATIVE_EVIDENCE_HARDENING.md`
4. `PROJECT_STATUS.json`
5. `PROJECT_CONTEXT.json`
6. `verification/R5_140_OFFLINE_VERIFICATION.md` when present/frozen
7. `ARCHITECTURE.md`
8. `DEBUGGING.md`
9. `WINDOWS_LIVE_RUNBOOK.md`

## 2. Triggering live evidence

`runtime(20260926-195951)`, fight 385, is the primary R5.140 evidence package.

The dominant failure was **not** general Dofus input failure:

- Enu successfully executed CAST -> MOVE -> MOVE -> END_TURN.
- Cra's planner repeatedly selected casts that execution admission returned `CAST_ADMISSION_UNKNOWN` **before physical input**.
- the same unchanged/no-input actions were recomputed many times until the turn was effectively consumed; a later repeat escalated to mission failure.

The proven architectural mismatch was that FightAI used peer-certified side/team overlays while latest-state admission could rebuild Kernel context from the weaker local lane. Tactical scoring also ignored normal `absolute` damage magnitude, and MOVE used weaker legality semantics than CAST.

## 3. Non-negotiable architecture

```text
network/client evidence
 -> Canonical State per account
 -> CombatFrameAssembler
 -> immutable CombatDecisionFrame
 -> team/tactical planning
 -> Kernel feasibility
 -> one PrimitiveAction
 -> latest CombatDecisionFrame + same feasibility contract
 -> ExecutionService (sole input authority)
 -> settlement/canonical consequence
 -> replan
```

Rules:

- Canonical State owns observed semantic truth.
- Kernel owns deterministic mechanics/legality, not live ownership.
- FightAI never owns physical input.
- lane revisions are not globally ordered.
- UNKNOWN remains UNKNOWN.
- no next physical primitive while prior input causality/settlement is uncertain.
- END_TURN fallback is allowed only when there is no uncertain physical input and turn/control authority is certified.

## 4. R5.140 changes

### Shared combat frame

`src/anka_platform/core/fight/combat_frame.py`

`CombatFrameAssembler` captures required account lanes once, converges semantic fight epoch, overlays certified peer side/team facts, records revision vector/frame id, and supplies the semantic owner snapshot used by both planning and latest-state admission.

### Typed recovery

`src/anka_platform/core/fight/recovery.py`

No-input admission UNKNOWN is bounded: refresh once, then exclude/quarantine the action for the current turn and replan. Repeated recoverable planner uncertainty can use certified END_TURN. Possible input uncertainty remains fenced.

### MOVE hardening

FightAI MOVE candidates require deterministic Kernel movement projection. Execution performs fresh MOVE admission before input.

### CAST feasibility hard gate

Incomplete effect projections/missing inputs cannot enter the executable tactical score pool. Utility never overrides unknown feasibility.

### Tactical damage

`absolute` damage/lifesteal mechanics now contribute to `base_damage_signal`; Cra/Enu normal damaging spells are no longer valued as zero-magnitude damage.

### Debugging

The runtime now records frame identity/revision vector, recovery directives, decision-stage timings, admission-before-input anomalies, repeated same-frame behavior and corrected admission causal ownership.

## 5. Important hotpaths

Combat semantic frame/recovery:
- `src/anka_platform/core/fight/combat_frame.py`
- `src/anka_platform/core/fight/recovery.py`
- `src/anka_platform/core/fight/decision_service.py`
- `src/anka_platform/core/fight/controller.py`

FightAI:
- `src/anka_platform/fight_ai/tactical_policy.py`
- `src/anka_platform/fight_ai/tactical/`
- `src/anka_platform/fight_ai/telemetry/`

Kernel/admission/execution:
- `src/anka_platform/integration/kernel_context.py`
- `src/anka_platform/execution/fight_action_admission.py`
- `src/anka_platform/execution/service.py`
- `src/anka_game_kernel/mechanics/fight_queries/`
- `src/anka_game_kernel/mechanics/fight/`
- `src/anka_game_kernel/mechanics/movement/`

Team/party:
- `src/anka_platform/party/shared_fight.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/core/fight/team_observation.py`

Diagnostics:
- `src/anka_platform/observability/`
- `DEBUGGING.md`

## 6. Current tactical architecture assessment

Do **not** replace the entire FightAI foundation. Preserve:

- synchronized team observation;
- deterministic Kernel mechanics;
- one-primitive replanning;
- shared focus/threat/protection/formation concepts;
- sole execution authority and settlement.

Future tactical intelligence should build on explicit team intent/outcome modeling, not hard-coded fight scripts. R5.140 focuses first on semantic consistency, feasibility, recovery and damage valuation.

## 7. Next live proof

After final offline freeze, run a fresh extraction. Use normal startup/preflight, Launch exactly once, and do not manually join/Ready/move/cast.

At the first autonomous failure preserve the complete runtime package.

Highest-priority evidence:

- `fight_ai/DECISION_TRACES.jsonl`
- `fight_ai/CANDIDATES.jsonl`
- `fight_ai/ACTION_OUTCOMES.jsonl`
- `fight_ai/TACTICAL_ANOMALIES.jsonl`
- `analysis/physical_input_ledger.jsonl`
- `analysis/failure_chain.jsonl`
- `analysis/causal_root.json`
- `execution/actions_enriched.jsonl`
- Cra/Enu canonical events
- protocol capture window

For a blocked action reconstruct:

```text
combat_frame_id + lane revisions
 -> candidate feasibility
 -> chosen action
 -> latest combat frame
 -> admission result/missing inputs
 -> recovery directive
 -> whether any input was sent
 -> settlement/consequence
```

A no-input admission failure is **not** a settlement failure.

## 8. Deliberate conservative boundaries

- controlled summon maximum capacity remains fail-closed until authoritative live evidence exists;
- generic active-effect expiry/removal remains conservative;
- exact lock/tackle mechanics may still make MOVE UNKNOWN; R5.140 now excludes/falls back instead of pretending geometry alone is enough;
- protocol negative absence remains exact-build qualified per R5.139;
- Windows/Dofus live acceptance remains pending until a fresh R5.140 run proves the redesigned combat boundary.

## 9. Packaging/freeze rules

- one ZIP with exactly one top-level project folder;
- exclude runtime, `.venv`, caches and temporary artifacts;
- rebuild and validate `PACKAGE_MANIFEST.json` after final immutable changes;
- compile source/tests;
- run R5.140 plus affected historical and broad subsystem regressions in bounded completed groups;
- independently extract final ZIP and repeat manifest/context/R5.140/compile checks;
- set `offline_verified=true` only after the frozen tree passes.

## 10. Additional implementation details from final R5.140 hardening

The final implementation goes beyond the initial R5.140 draft in four ways:

1. `CombatDecisionFrame` carries a semantic fingerprint. `FightDecisionService` reassembles a fresh frame after policy computation and returns `DECISION_STALE_COMBAT_FRAME` if decision-critical same-turn semantics changed. Raw revision-only churn is not enough to stale the decision.
2. `src/anka_platform/integration/action_feasibility.py` is the shared CAST/MOVE Kernel projection interpreter used by both tactical planning and latest-state admission. External target impact remains fail-closed. Mechanical legality and generic outcome completeness are separate so legal self/support casts are not accidentally disabled.
3. no-input admission UNKNOWN no longer causes a full tactical recomputation on an unchanged required-lane revision vector. The exact primitive is quarantined for the turn, then the next decision chooses another feasible action or normal END_TURN.
4. candidate/debug evidence now includes a bounded rejection audit plus explicit combat failure classes. This should make a single future runtime package explain not only what FightAI selected but why other generated actions were excluded.

Additional hotpath:

- `src/anka_platform/integration/action_feasibility.py`

When reviewing a future combat stall, compare the planner frame semantic fingerprint with the end-of-policy frame and the latest admission frame before blaming execution or settlement.

# R5.146 — Combat Survivability, Complete Action Coverage, Input Causality & L200 Truth Gates

R5.146 is the systemic successor to R5.145. It is based on the forensic evidence from `runtime(20260928-020313)` and deliberately fixes the **recovery boundary and planner-coverage contract**, rather than patching the one observed ENU END_TURN incident.

## Live failure addressed

In fight 538, round 3, ENU selected END_TURN. The target Dofus HWND was foreground before the click, both mouse DOWN and UP were submitted, but another HWND became foreground during/after the split transaction. Windows therefore classified physical delivery as `UNCERTAIN`. R5.145 correctly prevented an immediate duplicate click, but then converted the uncertainty into terminal fight/campaign failure.

R5.146 separates two concepts that must never be conflated:

* **input quarantine** — no more physical input is allowed while causality is ambiguous;
* **mission termination** — reserved for an actually unrecoverable control/client/fight condition.

Structured CAST/MOVE/END_TURN physical uncertainty now enters passive combat reconciliation. The execution boundary remains fenced, but Canonical/protocol observation continues until fight termination, turn handoff, confirmed action evidence, or other authoritative closure makes the old transaction safe to retire. No speculative retry is introduced.

## Physical-input diagnostics

The Windows split-click transaction now records foreground identity at:

* before mouse DOWN;
* after mouse DOWN;
* before mouse UP;
* after mouse UP;
* after post-click settle.

Unexpected foreground HWNDs receive a best-effort identity snapshot (HWND/title/PID/process creation time when the API exposes it). Diagnostics distinguish mid-click focus loss from complete-click/post-settle focus loss. These classifications are forensic evidence only; they never bypass semantic settlement.

## FightAI coverage contract

The R5.145 runtime proved that a turn could reach `END_TURN` with 7 AP after only 5/22 CRA spells received deep evaluation. R5.146 changes the planner contract:

1. Every enabled spell receives deadline-independent **cheap whole-bar screening** for static tactical features and AP affordability.
2. Expensive cast exploration is breadth-biased: base target exploration is capped to one representative target per spell before deeper sequence work.
3. A reserved coverage-rescue stage revisits any spell still marked `NOT_EVALUATED` before MOVE/sequence depth consumes the tail budget.
4. Telemetry separates `cheap_spell_coverage_*` from deep `spell_coverage_*`/`deep_spell_coverage_*` so 22/22 cheap consideration can never be confused with 22/22 Kernel target simulation.
5. Planner-selected END_TURN with AP remaining is blocked when deep spell coverage is incomplete. The controller is also forbidden from manufacturing a fallback END_TURN for `SPELL_COVERAGE_INCOMPLETE` or an already-expired policy budget; those states remain input-free until authoritative turn/fight progress closes the frame.
6. Low-value MOVE actions outside danger modes are rejected below an execution-risk utility floor, reducing unnecessary physical clicks and reversal churn.

This does **not** claim that strategy is level-200 optimal. It creates a stronger base on which deeper tactical search can be trusted.

## L200 truth correction

The readiness trace now recognizes production `ENEMY_SIDE` (while retaining legacy `ENEMY`) when identifying enemies. This fixes the R5.145 diagnostic defect where a seven-enemy PvM fight could report `enemy_count=0` and hide missing enemy HP/AP/MP/state/effect blockers.

R5.146 still does not invent missing level-200 mechanics. Exact tackle/lock, authoritative summon capacity/lineage, complete state/effect lifecycle, and zone-specific enemy mechanics remain explicit blockers until supported by authoritative evidence.

## Campaign continuity defaults

Both current Sufokia farming missions used by Script Studio now target 5 wins with 10 attempts and do not stop on the first loss or unknown result. This includes alphabetically first/default `sufokia_farm`; the explicitly named `sufokia_farm_legacy` and global legacy `config.yaml` remain strict for compatibility. Outcomes remain accounted honestly; they simply do not automatically terminate the current farming run.

## Preserved safety boundaries

* ExecutionService remains the sole owner of physical input.
* A structured reconciliation state freezes additional physical input until causality closes.
* Window/process/client-generation identity failures that cannot be safely reconciled remain terminal/fail-closed.
* Canonical State and Kernel authority are not weakened.
* No fight ID, incident cell, account HWND, or specific live failure is special-cased.
* The sealed R5.115 runtime diagnostic identity remains unchanged.

## Remaining work before level-200 strategy can be called mature

R5.146 is a fight-foundation milestone, not the final tactical milestone. Future work should deepen enemy live truth, exact tackle/lock, effect/state expiry/removal, summon semantics, verified monster capability packs, charged/burst scheduling, lethal/overkill reasoning, buff timing, control→damage sequencing, and multi-turn CRA↔ENU coordination.

## Acceptance rule

Offline passing is necessary but insufficient. Windows/Dofus live acceptance remains **PENDING** until a fresh extracted package demonstrates multiple fights where temporary focus loss/uncertain combat input does not duplicate input or terminate the mission, and where live FightAI traces show materially improved CRA/ENU action-space coverage.

## Post-implementation full-chain audit

A second audit of the exact packaged R5.146 candidate found and repaired five cross-layer seams before final delivery:

* `SPELL_COVERAGE_INCOMPLETE` could still become controller-forced END_TURN after repeated polls; it now remains input-free even beyond the ordinary blocked-stall count.
* policy budget previously started before objective/profile preparation; the active/passive policy now receives its full configured budget from actual policy start, and an already-expired budget returns `DECISION_BUDGET_UNAVAILABLE` instead of blind END_TURN;
* uncertain CAST reconciliation now receives the same durable `origin_action_id` / observation correlation as MOVE and END_TURN;
* `FIGHT_ACTIVE` watchdog supervision now reserves at least 45 seconds for a passive natural-turn-handoff recovery, so the parent watchdog cannot kill the recovery before the client naturally advances;
* the base target shortlist no longer hard-prioritizes occupied enemy cells ahead of interaction quality, restoring empty-cell AoE opportunities that were already protected by an older regression test.

These are systemic seam corrections; no live fight/account/window identifier is special-cased.

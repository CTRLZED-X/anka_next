# R5.162 — Resource Causality, Pointer Interaction, Ready & Forensic Hardening

## Scope and evidence
This pass is driven by the R5.161 live runtime `runtime(20261003-231729).zip` plus the operator's 43 manually drawn point-to-point mouse trajectories. The supplied run completed **5/5 fights without terminal campaign failure**, so R5.162 does not redesign FightAI or the campaign state machine. It repairs the first remaining causal/interaction boundaries exposed by that successful run.

## Confirmed R5.161 live findings
1. **Stale remaining MP was reusable after a confirmed move.** Two CRA attempts were planned as if 3 MP remained after a one-cell move had already consumed real movement. In both cases the next three-cell click produced no outbound MOVE request. The Kernel/pathfinder were using the value they were given; the unsafe part was settlement accepting a newer same-value MP observation as if the spend had been refreshed.
2. **First Ready remained systematically swallowed.** CRA's first Ready interaction produced no outbound Ready request in all five fights, while the later bounded retry succeeded. The first click occurred more than five seconds after placement, so another blind global delay was not a satisfactory root-cause fix.
3. **Pointer geometry was numerically compliant but visually over-clean.** R5.161 achieved exact arrival, <=24 px emitted steps, and roughly the same maximum chord deviation as the hand-drawn reference, but one coherent arc can still look straight at normal game speed. Maximum deviation alone is therefore not a sufficient human-likeness metric.
4. **Physical evidence needed a stronger ownership boundary.** `debug_status()` is mutable. Each real physical operation must commit its own evidence immediately so later focus, identity, neutralization or settlement work cannot relabel the earlier transaction.

## 1. Causal AP/MP settlement
`CanonicalActorObservationRevisions` now includes resource-specific evidence watermarks (`ap_resource_revision`, `mp_resource_revision`, `range_resource_revision`). Generic fight-stat snapshots update normal value watermarks; explicit `ResourceChangedObserved` events update both the value and resource-specific watermark.

`SettlementRequirement` now supports `RESOURCE_DECREASE`. For AP/MP spending actions, settlement is accepted only after the server-confirmed action revision when either:

- an explicit resource-change event is observed; or
- a newer authoritative AP/MP value is numerically below the pre-action baseline.

A newer generic stats snapshot that merely repeats the old value does **not** settle the action. This directly falsifies the R5.161 CRA `3 MP -> move 1 cell -> still plan 3 cells` failure class.

The rule is enforced in both movement settlement paths:

- normal `move_fight` confirmation/settlement;
- passive `RECONCILING -> TARGET_REACHED/MOVED_TO_OTHER_CELL` recovery.

If position is confirmed but remaining MP is not, execution returns/fences with `COMBAT_MOVE_RESOURCE_PENDING`. Physical retry is forbidden and FightAI cannot spend the stale resource. The legacy typed movement entrypoint now uses the same rule and persists the same unresolved-action fence instead of remaining a weaker second authority. CAST AP settlement uses the same causal resource-decrease contract.

## 2. Pointer Interaction V2
R5.162 intentionally does **not** solve visual straightness by simply maximizing curvature. The operator sample centered near the same ~2% maximum chord-deviation region already reached by R5.161. The missing property was trajectory shape.

V2 therefore keeps the calibrated R5.161 primary bend (about 1.2-3.0% of travel, capped at 16 px for medium/long motion) and adds a small late corrective submovement:

- correction begins at a randomized ~62-78% of normalized progress;
- correction magnitude is bounded by distance, a 5 px hard cap, and the primary bend;
- it usually bends back toward the chord, with a minority of same-side corrections so all paths do not become identical S-curves;
- timing skew, primary bend, secondary bend and correction are selected once per movement;
- there is no per-frame jitter;
- exact target arrival remains a mathematical invariant;
- the actual integer-coordinate path is checked against the 24 px emitted-step safety contract before movement.

Very short corrections remain essentially straight. Diagnostics expose `motion_model_version=2`, the V2 variant name, correction magnitude/start and submovement count.

### Why no arbitrary endpoint jitter or automatic post-click wandering
The Unity projection boundary still certifies exact safe points, not an arbitrary safe interior polygon. Randomly adding +/- pixels to a target can recreate invalid/non-walkable/wrong-cell clicks. R5.162 therefore humanizes the **path**, not the semantic target.

The proposed idea of moving randomly after every successful click was also investigated and is deliberately **not enabled by default** in this release. Unconditional post-click wandering can alter hover/UI state, adds another physical transaction between tightly coupled actions, and is not required by the supplied human trajectory evidence. Existing bounded no-click activity nudges remain available for liveness. If future live evidence shows a clear benefit, post-action relaxation should be introduced as an explicit, fenced interaction phase rather than hidden noise.

## 3. First-Ready interaction priming
The 3.75 s post-placement settle remains unchanged. R5.162 adds a separate first-interaction condition rather than another blind delay:

1. Ready window is already activated and focus-stable by the existing arming state machine.
2. For only the first Ready interaction of the fight, move the pointer to the verified Ready control without clicking.
3. Hold a small default 0.35 s hover-only prime.
4. Re-snapshot Canonical State and re-prove the same fight generation, local actor identity and semantic Ready eligibility.
5. Send exactly one Ready click.

If anything changes during the prime, the click is NOT_SENT and the existing bounded retry path remains authoritative. Priming evidence, placement age and all settle parameters are persisted with the action.

## 4. Immutable physical-boundary evidence
`DofusWindowInputDriver` now commits a separate `last_input_transaction()` snapshot at physical boundaries rather than asking later consumers to trust mutable `debug_status()`. Execution prefers this immutable snapshot immediately after MOVE/CAST/END_TURN/placement/Ready/heartbeat and related pointer sends. UI neutralization (ESC) now commits its own evidence as well.

This is intentionally a compatibility bridge: existing callers still receive the established send-state contract, while completed physical evidence is no longer overwritten by later identity/focus diagnostics. A future fully typed `InputTransactionResult` can be introduced without changing the authority model.

## 5. Failure classification and diagnostics
`COMBAT_MOVE_RESOURCE_PENDING` is a first-class recover-in-place condition. It means:

- the move's physical/semantic consequence is already confirmed;
- remaining MP is not yet causally authoritative;
- input remains fenced;
- physical retry is forbidden;
- passive reconciliation should continue.

The incident exporter classifies this boundary separately from movement-causality failure so one runtime package can distinguish `where did I move?` from `what MP is now safe to spend?`.

## Retained safety invariants
R5.162 does not weaken:

- Canonical State / Kernel / FightAI / Execution ownership boundaries;
- POST_PROJECTION and PRE_DOWN semantic re-admission;
- exact certified projection endpoint validation;
- split-click focus continuity and no-click-after-failure guarantees;
- one unresolved/possibly-sent physical transaction at a time;
- R5.158 HOLD/RECOVERING network continuity;
- R5.157 live-decoding certification and fail-closed unknown truth.

## Known truth gaps not guessed away
Complete level-200 truth still has explicit gaps such as full HP/max-HP coverage, enemy AP/MP coverage, complete effect/state apply-refresh-expire-remove lifecycle, summon capacity and exact tackle/lock semantics. R5.162 does not fabricate those values.

## Next live acceptance
A single controlled R5.162 run should prove:

- no second MOVE can be authorized from a stale same-value remaining-MP observation after a confirmed move;
- a resource-pending move remains input-fenced until authoritative MP evidence or a true turn boundary resolves it;
- medium/long cursor paths visibly contain small coherent curvature plus a late correction while short corrections remain near-direct;
- exact certified endpoints and <=24 px emitted-step safety hold;
- first Ready interaction produces outbound Ready semantics without a blind extra click;
- no click occurs after PRE_DOWN/focus/interference failure;
- physical evidence remains attached to the exact action/phase even after later focus/identity/UI-neutralization work;
- any remaining live problem has one explicit first-missing boundary in the same bundle.

## Status
**OFFLINE VERIFIED CANDIDATE. Windows/Dofus acceptance is PENDING.**

# Dependency reproducibility — R5.189

`anka-constraints.txt` is the exact **live/runtime** dependency-resolution contract used by normal `setup.bat`.
`DEPENDENCY_BASELINE.json` is the machine-readable live/runtime baseline verified after installation.

`anka-dev-constraints.txt` and `DEV_DEPENDENCY_BASELINE.json` belong only to optional `setup_dev.bat`. They add pytest and test-only packages and are not required for `start.bat`, Script Studio, capture, bridge operation, or live Dofus control.

`pip` itself is treated as installer tooling rather than runtime state. R5.189 requires the Python 3.13 virtual environment to have a working pip, but normal setup does not force a network downgrade of pip. The setuptools build backend and all ANKA runtime/capture packages remain exact-version constrained.

This is stronger than the broad compatibility ranges in `pyproject.toml`: those ranges define what ANKA supports, while the constraints define the exact dependency graph tested for this release.

This is **not** a cryptographic wheel lock. Package bytes/hashes are not vendored in this repository. Windows setup records the actually installed runtime versions and baseline hash so diagnostics can prove whether the live environment drifted. If downloads fail, `tools/dependency_network_probe.py` records DNS availability separately from dependency-version drift.

# Optional R5.189 Windows runtime wheelhouse

Normal `setup.bat` remains able to use PyPI with bounded retries. If this directory contains
`WHEELHOUSE_MANIFEST.json` plus every file named by that manifest, setup verifies the SHA-256
hashes and installs the runtime dependency set with `--no-index --find-links`.

The delivery produced in the offline build environment does not invent or relabel Windows
wheels. Populate this directory on any connected trusted build machine with:

    python tools\build_runtime_wheelhouse.py

The builder explicitly downloads **Windows x64 / CPython 3.13** wheels even when run from Linux or macOS; it must never infer the build host platform for this sealed Windows release.

Then reseal the package manifest before distribution.

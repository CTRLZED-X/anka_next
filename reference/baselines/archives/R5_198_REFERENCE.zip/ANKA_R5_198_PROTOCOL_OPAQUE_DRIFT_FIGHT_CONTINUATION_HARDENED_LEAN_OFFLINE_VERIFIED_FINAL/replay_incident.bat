@echo off
setlocal
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"
if "%~1"=="" (
  echo Usage: replay_incident.bat ^<runtime-or-incident.zip^> [output.json]
  exit /b 2
)
if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else (
  set "PY=python"
)
if "%~2"=="" (
  "%PY%" tools\replay_live_incident.py "%~1"
) else (
  "%PY%" tools\replay_live_incident.py "%~1" --output "%~2"
)
exit /b %ERRORLEVEL%

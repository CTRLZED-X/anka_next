# R5.190 New Chat Handoff

## Current authority
- Release: **R5.190**
- Checkpoint: `ANKA_PLATFORM_R5_190_CURRENT_PROTOCOL_FIGHT_CHAIN_HARDENED_WINDOWS_LIVE_CANDIDATE`
- Active adapter: `dofus_3_7_10_10`
- Canonical contract: v1
- Windows/Dofus live acceptance: **PENDING**

Start with `PROJECT_STATUS.json`, this handoff, `R5_190_CURRENT_PROTOCOL_FIGHT_CHAIN_HARDENED.md`, and the current offline verification report.

## Incident that produced this release
In the supplied 2026-10-14 runtime, CRA and ENU entered shared fight instance 165 but stopped in placement. Diagnostics identified `FIGHT_GEOMETRY_UNAVAILABLE`; FightAI decision/candidate logs were empty because tactical planning was never reached.

The pre-fight world map was `190581250`; the tactical fight map was `190712834`. A fight-loading `jow` overwrote the single decoder map slot before `jxi`, and the reducer later rebuilt the fight snapshot and discarded ENU's `iia` `discovered_world_map_id=190581250`. R5.189's geometry resolver then had no surviving authoritative Mapuse binding.

## R5.190 correction
1. Persistent `world.map_id` and tactical `fight.map_id` are separate decoder/canonical concepts.
2. A fight-entry-pending `jow` records tactical loading without mutating persistent world identity; explicit world-transition intent still wins.
3. `jnv` owns fight map context.
4. Same-generation discovery/join facts survive STARTED/PLACEMENT.
5. Fight state captures `origin_world_map_id` at entry, giving the leader an authoritative generation-scoped geometry binding even without follower presentation.
6. Geometry binding fails closed on conflicting origin/join world identities.
7. `dofus_3_7_10_10` is an explicit registered adapter. Historical 3.6.12.16 evidence is used only as same-wire regression evidence.
8. Current R5 `jst` is ACK, not End Turn. Never map it to End Turn. Server `jup` is turn-end truth; inherited `jwo` remains guarded until a clean current End Turn capture isolates the outbound request.

## Important code
- Current adapter: `src/anka_platform/protocol/adapters/dofus_3_7_10_10/`
- Shared hardened decoder: `src/anka_platform/protocol/adapters/dofus_3_6_12_16/`
- Canonical state: `src/anka_platform/contracts/canonical_state.py`
- Reducer: `src/anka_platform/live_state/reducer.py`
- Fight geometry: `src/anka_platform/integration/fight_geometry.py`
- Execution: `src/anka_platform/execution/service.py`
- Party preparation: `src/anka_platform/party/mission.py`
- Diagnostics V2: `src/anka_platform/observability/diagnostics_v2.py`

## Do not regress these rules
- Unknown/unproven wire messages remain non-mutating/fail-closed.
- Do not hardcode tactical->world MapId aliases.
- Do not let fight loading overwrite persistent world identity.
- Do not clear same-generation join evidence merely because placement starts.
- Do not use `jst` as End Turn.
- FightAI never owns physical input or protocol decoding.
- InputArbiter remains the cross-account physical input authority.

## Next live proof
Use a fresh extracted R5.190 package and perform one bounded CRA+ENU fight. On failure, preserve the entire runtime/debug bundle. Diagnose the *first* missing boundary, not the final symptom. Required progression is world -> entry -> geometry -> placement -> Ready -> ACTIVE -> authoritative turn owner -> FightAI -> execution -> settlement.

# R5.138 — Tactical Impact Geometry & Cast Target Integrity Hardening

## Triggering live evidence

Primary evidence: `runtime(20260926-130218)`, fight `93`. This checkpoint treats the operator observations as hypotheses and distinguishes two different defects.

### Round 4 — confirmed Kernel impact-geometry contradiction

Cra cast `Carreaux Destructeurs` (`32459`, configured grade 2) on cell `411` while FightAI intended enemy `-3` on cell `397`. The cast was server-confirmed and AP was consumed, but no enemy damage/displacement/death or target consequence followed. Cra then cast direct `Flèche de Recul` on cell `397` and killed the same enemy.

The previous generic `FORK` area primitive was a T-shaped lateral model. The actual Dofus fork is the selected cell plus three forward-oriented prongs relative to caster -> selected-cell direction. Cell `397` existed only on ANKA's false lateral prong in the failing round-4 state. R5.138 fixes the generic Kernel primitive and retains the real cells as regression evidence. No spell-ID exception is introduced.

### Round 5 — legal-looking empty-cell AoE, lost semantic target identity, then no semantic request

Cra was on cell `453`; enemy `-5` was on cell `400`; FightAI selected `Flèche Ralentissante` on empty cell `412` and recorded target actor `-5`. Static map/projection evidence says `412` is projectable/walkable, and the real size-2 cone from `453` through `412` includes cell `400`. Therefore R5.138 does **not** turn the visual impression of the cell into a fabricated walkability/LoS rule.

The actual integrity defect was that `target_actor_id=-5` was lost before the old execution admission record. R5.137 could prove only that cell `412` was a legal cast cell; it could not prove that the intended enemy was semantically eligible for the spell effects at click time. The later click produced no confirmed cast request and ended as `ACTION_UNCERTAIN`.

R5.138 carries the target actor through controller -> execution and requires Kernel-certified target impact at both admission gates.

## Systemic changes

1. **Generic directional FORK geometry.** `anka_game_kernel` now models the selected cell plus three forward prongs with edge clipping and exact directional orientation.
2. **Semantic target-actor admission.** If FightAI names a target actor, the latest Kernel preview must contain that actor in at least one effect occurrence's `eligible_actor_ids`. Deterministic absence rejects the action; unresolved target semantics return UNKNOWN.
3. **No geometry-only actor inference.** FightAI no longer converts "actor occupies an AoE cell" into "effect applies to actor" when Kernel target semantics are unresolved.
4. **Target identity propagation.** `PartyCombatController` retains `target_actor_id` in the cast payload instead of dropping it before execution.
5. **Two-stage latest-state integrity.** Target impact is revalidated PRE_SLOT and again PRE_TARGET immediately before the semantic cell click.
6. **Exact click/cast causality.** Cast forensics preserve map/cell projection generation, projected screen/client point and capture/request evidence. Negative evidence is anchored to actual observed outbound traffic, not a later moving wall-clock watermark.
7. **Bounded local client-rejection recovery.** Only two same-generation capture-covered no-request samples can establish `CLIENT_CAST_REJECTED`; otherwise the result stays UNCERTAIN.
8. **Immediate move reversal guard.** Exact same-turn A->B->A movement is quarantined and replanned without a second physical move.
9. **Enemy-benefit safety.** A cast proven to grant AP/MP/range/heal/shield benefit to enemies is a hard blocker, not a score penalty that another override can outvote.
10. **Decision-budget reserve.** Expensive reachable-cell search/scoring cannot start inside the reserved deadline tail.
11. **Target-semantic dependency minimization.** Kernel targeting now requests summon status only when the effect specification actually distinguishes summon from non-summon on the resolved team side; this removes false LIVE_REQUIRED results without guessing.
12. **Failure-path FightAI recovery.** If ACTIVE -> FAILED/UNCERTAIN occurs before the normal recorder mirrors the last decision, the exporter recovers that decision and its action outcome from terminal campaign evidence into Fight Intelligence.

## Deliberate non-fixes

- Cell `412` is **not** declared non-walkable from appearance; the supplied evidence does not support that conclusion.
- Empty-cell AoE targeting remains valid. The integrity check is target-actor effect eligibility, not target-cell occupancy.
- Decision-relevant unknown team/summon/effect semantics remain UNKNOWN. R5.138 does not guess missing target attributes. When a target attribute is provably irrelevant to the effect specification (for example both enemy summon and enemy non-summon are allowed), the Kernel no longer asks for that irrelevant input.
- No configured spell ID is hard-coded into generic geometry/admission/policy runtime logic.

## Live acceptance still required

Offline verification can prove the model, invariants, regressions and package integrity. It cannot prove Windows click calibration/client behavior. A fresh R5.138 campaign must still demonstrate that round-4-style FORK misses disappear, tactical target identity survives into both admission gates, local client rejection replans safely when provable, Cra/Enu turns continue, fights terminate, world re-entry succeeds and subsequent fights start.

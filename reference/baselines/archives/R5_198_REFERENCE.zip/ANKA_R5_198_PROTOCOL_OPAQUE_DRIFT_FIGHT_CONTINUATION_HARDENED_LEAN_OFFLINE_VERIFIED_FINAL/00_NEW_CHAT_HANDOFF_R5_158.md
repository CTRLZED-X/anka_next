# NEW CHAT HANDOFF — R5.158

## Current objective

R5.158 hardens the runtime against temporary internet/transport loss without weakening physical-input safety. A temporary loss of required live truth is now a parent-owned continuity state, not gameplay progress.

## Incident evidence that motivated this release

Use `R5_158_LIVE_TRUTH_CONTINUITY_TRANSPORT_RECOVERY_HARDENING.md` as the release delta. The uploaded 2026-10-02 runtime showed:

- fight 691: CRA protocol/canonical truth stalled ~80–83 s; an already-sent CAST was correctly quarantined, but the 45 s campaign watchdog terminated before TCP recovered;
- fight 261: ENU had ~39 s protocol/canonical silence while CRA was ACTIVE and ENU remained PLACEMENT; the 44 s preparation watchdog expired before the old 45/60 s health thresholds could declare staleness.

## New authoritative behavior

1. `CampaignContinuityGuard` classifies required account health before child workflows.
2. Freshness-only loss produces `CONTINUITY/HOLD`; no new physical input is possible and campaign watchdog elapsed time freezes.
3. Fight-only protocol/canonical silence >30 s triggers an early parent continuity hold even before the stricter Execution health thresholds.
4. Recovery requires 2 s continuously healthy truth before the exact same campaign state resumes.
5. Holds are bounded (default 600 s). Exhaustion is `LIVE_TRUTH_CONTINUITY_TIMEOUT`, not `MISSION_TIMEOUT`.
6. Hard runtime/protocol/window-generation faults are never hidden as internet stalls.
7. SYN reconnects reset directional TCP reassembly/frame state.
8. Per-flow capture status exposes sequence gaps/reassembly stalls so one auxiliary flow cannot mask the game flow.

## First files to inspect for any future recurrence

- `campaign/runtime.json` → `continuity`, `campaign_watchdog_hold`, recent steps
- `readiness.json` → each required account `runtime_health`, `capture.flows`
- execution uncertainty/pending settlement state
- `timeline.jsonl` around the first continuity transition
- exact PCAP game flow around that timestamp

## Non-negotiable rules

- Never retry an uncertain physical action solely because internet returned.
- Never clear an Execution uncertainty fence from continuity code.
- Never let continuity hold mutate fight/world lifecycle state.
- Never classify unknown/new health blockers as transient without an explicit rule and regression.
- Never increase mission timeouts as the primary response to network loss.
- POST_FIGHT/outcome/world ordering remains parent-owned.
- Windows/Dofus live acceptance remains PENDING until a real outage/recovery run validates the behavior.

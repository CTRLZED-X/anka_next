# NEW CHAT HANDOFF — R5.154

## Current objective

R5.154 is the foundation candidate for the first controlled level-200 pilot using the **normal operator workflow**:

`setup.bat -> start.bat -> Script Studio -> choose config/accounts -> Launch once`

Do not require `zone200_pilot.bat` for normal operation.

## Why R5.154 supersedes R5.153

`runtime(20261002-095010)` completed 5/5 lower-level fights and showed the combat foundation was broadly healthy, but it exposed three audit contradictions: normal Launch did not preserve its passive exact-generation safety proof in the zone-200 report; safe quarantine of unattributed traffic was treated as capture corruption; and SessionRunStore repeatedly opened forensic files on the hot path, with several >4s stalls observed. R5.154 repairs those without changing FightAI or physical execution semantics.

The uploaded run is **not** zone-200 evidence: all observed enemies were levels 16–20. `analysis/zone_200_encounters.json` correctly rejected it.

## Foundation ownership

- Canonical State: observed game truth only.
- Kernel: deterministic legality/mechanics authority.
- FightAI/TeamStrategy: policy and ranking only.
- PartyCombatController/campaign/workflow: orchestration and confirmed turn history.
- ExecutionService: sole physical-input authority and transaction settlement.
- ControlAuthority/window identity: physical authorization.
- Observability/exporter: evidence only; never execution authority.

The architecture guard must continue to prevent `fight_ai` from importing execution, Windows, party/campaign orchestration, scripting or web/session-control layers.

## New R5.154 evidence

Inspect these first in the next runtime ZIP:

1. `analysis/zone_200_pilot_contract.json`
2. `analysis/zone_200_encounters.json`
3. `analysis/zone_200_readiness.json`
4. `certification/launch_windows_process_attestation.json`
5. `party/reconciliation.json`
6. `analysis/foundation_health.json`
7. `fight_ai/FIGHT_SUMMARY.json`
8. `fight_ai/DECISION_TRACES.jsonl`
9. `fight_ai/CANDIDATES.jsonl`
10. `fight_ai/ACTION_OUTCOMES.jsonl`
11. `fight_ai/ACTION_EFFECTS.jsonl`
12. execution transaction / physical-input ledger evidence when a physical action is disputed.

## Capture interpretation

Quarantined unattributed traffic is containment, not corruption, when all required account flows are positively bound and generation mismatch remains zero. Never route quarantined traffic into Canonical State just to make readiness green.

## Launch interpretation

Normal Launch safety is proven by passive exact-generation process/window/input attestation sampled at Launch. Deep Windows certification remains optional release evidence and must not be required every time Dofus restarts.

## First real level-200 pilot

Use the normal Script Studio configuration with:

- target wins: 3–5;
- max attempts: <=5 and >= target wins;
- stop on loss: true;
- stop on unknown: true;
- no manual combat assistance.

After the run, do not tune strategy until `zone_200_encounters.json` proves actual level-200 evidence. A lower-zone win streak is not level-200 evidence.

## Change routing after the pilot

If foundation evidence is clean and actual level-200 fights are present, freeze foundation layers by default and work in FightAI/TeamStrategy/evidence-backed combat knowledge. Do not modify ExecutionService, window control, campaign/session lifecycle or transaction settlement merely because a tactical choice was poor.

Generic autonomous level-200 competence is not yet certified. Exact tackle/lock, complete effect lifecycle, comprehensive dynamic enemy resources, summon semantics and unknown monster-specific mechanics remain explicit truth gaps.

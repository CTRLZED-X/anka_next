# ANKA R5.192 — New-chat handoff

## Current authority

R5.192 is the current lean candidate. Read `R5_192_PROTOCOL_UPGRADE_SETUP_RESILIENCE_FOUNDATION.md`, `PROJECT_STATUS.json`, `docs/CURRENT.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, `WINDOWS_LIVE_RUNBOOK.md`, and `LIVE_ACCEPTANCE.md` before changing runtime behavior.

## Preserved runtime foundation

R5.190 fixed the observed fight-entry geometry failure by separating persistent world MapId from tactical fight MapId and preserving same-generation origin/join evidence. R5.191 added deterministic verification and engineering/failure-boundary guardrails. R5.192 does not rewrite FightAI, party control, Kernel mechanics or physical-input ownership.

## R5.192 setup delta

Normal `setup.bat` is non-editable and establishes `ANKA_PROJECT_ROOT`. The installed runtime is hash-bound to the exact source/protocol tree. `start.bat` blocks if source/protocol code changed after installation. Optional `setup_dev.bat` uses setuptools compat editable mode. VS Code analysis is explicitly pointed at `src` and excludes `.venv`/runtime/game-data surfaces to reduce language-server churn.

## R5.192 protocol-upgrade delta

The current `dofus_3_7_10_10` adapter is self-contained and no longer derives implementation/capability ownership from `dofus_3_6_12_16`. Raw wire vocabulary is confined to protocol packages; generic diagnostics resolve wire names dynamically from semantic operations.

A protocol update must pass `tools/verify_protocol_upgrade_contract.py`: current config identity, version-local isolation, raw-wire isolation, current-build evidence provenance, cross-capability scenarios, game-data compatibility and hash-bound attestation. Historical evidence remains regression support, not a substitute for exact-current evidence.

## Known current-build limits

Outbound exact-current End Turn request identity is still not independently proven. Effects and shield semantics retain partial-evidence limitations. Do not invent mappings to make a live run progress.

## Next live proof

One CRA+ENU fight only:

`world -> shared fight -> geometry -> placement -> Ready -> ACTIVE -> turn owner -> FightAI -> physical action -> authoritative settlement -> next owner/fight end -> world re-entry`

If setup or protocol integration changes, rerun `setup.bat` before `start.bat`.

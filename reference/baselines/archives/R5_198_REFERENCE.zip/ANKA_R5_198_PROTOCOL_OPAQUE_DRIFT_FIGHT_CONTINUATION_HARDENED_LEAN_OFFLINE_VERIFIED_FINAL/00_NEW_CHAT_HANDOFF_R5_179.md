# ANKA R5.179 new-chat handoff

Current checkpoint: **R5.179 Release & Reproducibility Foundation**.

Start with `docs/CURRENT.md`, `PROJECT_STATUS.json`, `R5_179_RELEASE_REPRODUCIBILITY_FOUNDATION.md`, `docs/architecture/RELEASE_REPRODUCIBILITY.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, and `LIVE_ACCEPTANCE.md`.

R5.179 changes release/configuration reproducibility only. Runtime behavior is based on the offline-verified R5.178 execution/concurrency foundation. The normal Windows path is still fresh extraction -> `setup.bat` -> `start.bat` -> Script Studio Apply -> Launch.

Setup now resolves through exact release constraints and verifies/persists the observed dependency baseline. If that check fails, do not bypass it: preserve the setup diagnostic so dependency/environment drift can be distinguished from ANKA runtime bugs.

Windows/Dofus live acceptance is **PENDING**.

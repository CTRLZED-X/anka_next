@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

if not exist ".venv\Scripts\python.exe" (
  echo CERTIFICATION=BLOCKED
  echo ERROR: Python environment is missing. Run setup.bat once with Dofus closed.
  exit /b 2
)
if not exist "config.yaml" (
  echo CERTIFICATION=BLOCKED
  echo ERROR: config.yaml is missing.
  exit /b 2
)

echo ========================================
echo ANKA WINDOWS LIVE CERTIFICATION
echo ========================================
echo WARNING: THIS COMMAND IS CONTROL-CAPABLE.
echo It WILL move/click Dofus and MAY start a real fight.
echo It is NOT part of normal Script Studio startup.
echo Use start.bat or run_anka.bat without flags for passive startup.
echo.
echo Required before starting:
echo   - Open and fully load every Dofus client required by the current configuration.
echo   - Put required accounts in the configured starting state/route when the selected mission requires it.
echo   - ANKA server is running on the host/port configured in config.yaml.
echo   - The configured UI calibration profiles match the current client layout.
echo   - Certification resolves required accounts from config.yaml; no character name or map is hard-coded here.
echo.

".venv\Scripts\python.exe" -m anka_platform.certification.windows_runner --config config.yaml %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo CERTIFICATION=FAILED
  echo Fix the blocker above. If generated, send runtime\certification\last_failure_debug.zip for inspection.
  exit /b %RC%
)

echo.
echo CERTIFICATION=SUCCESS
exit /b 0

# New Chat Handoff — R5.176

Current workspace: **ANKA R5.176 — Protocol Adapter SDK & Capability Certification**.

R5.176 builds directly on the verified R5.175 failure/traceability foundation. It preserves R5.174/R5.175 startup, control and physical-input semantics while making protocol evolution more modular and diagnosable.

## R5.176 invariants

- `ProtocolAdapter -> CanonicalEventEnvelope` remains the public protocol boundary;
- raw Dofus wire names remain inside the protocol package;
- the active 3.6.12.16 adapter uses handler SDK version 1;
- its handler logic is split into `world_identity`, `fight_state`, `resources_effects`, `combat_actions`, and `fight_lifecycle` modules;
- all handler modules share one `Dofus361216RuntimeContext` mutable authority;
- every declared active-adapter capability has an explicit exact-build capability certificate;
- newer builds may be `OBSERVED_COMPATIBLE_UNCERTIFIED` capability by capability, but positive evidence never certifies negative/absence semantics;
- typed transform failures are localized to the owning capability wherever the handler registry can prove ownership;
- `protocol_upgrade` diagnostics identify affected capability/module and required next evidence;
- SDK-enabled adapters fail architecture verification if a capability is unowned or lacks explicit certification;
- active protocol/schema drift remains fail-closed for physical input;
- R5.175 project-wide failure registry, immutable correlation context, crash envelope and diagnostic completeness remain mandatory;
- bridge contract remains **4**, plugin **2.2.75**;
- Windows/Dofus live acceptance remains **PENDING**.

Read `R5_176_PROTOCOL_ADAPTER_SDK_CAPABILITY_CERTIFICATION.md` and `docs/architecture/PROTOCOL_ADAPTER_SDK.md` before editing protocol adapters.

# R5.159 — Smooth Pointer Motion & Safe Endpoint Hardening

Status: **offline verified; Windows/Dofus live acceptance pending**.

## Goal

R5.159 replaces production cursor teleportation with one centralized physical pointer-motion authority while preserving the existing semantic action, projection, calibration, window identity, input arbitration, settlement, and uncertainty contracts.

The project-agnostic behavioral source is retained at `docs/reference/HUMAN_LIKE_MOUSE_MOVEMENT_GOALS_FINAL.md`.

## Architecture

```text
existing semantic target / calibrated point / projected cell
  -> optional caller-certified safe endpoint candidates
  -> DofusWindowInputDriver
  -> PointerMotionService
       -> read actual current cursor position
       -> distance-sensitive duration
       -> minimum-jerk forward progress
       -> bounded low-frequency perpendicular deviation
       -> intermediate absolute cursor positions
       -> foreground + interference checks
       -> exact final-arrival verification
  -> existing hover/focus checks
  -> mouse DOWN / hold / UP
```

`NativeWin32Api` remains a dumb OS primitive. `PointerMotionService` is the only production trajectory authority above raw `SetCursorPos` / `SetPhysicalCursorPos`.

## Motion model

- actual current cursor position is the trajectory start;
- minimum-jerk progression `10t^3 - 15t^4 + 6t^5` provides slow -> fast -> slow velocity;
- duration increases with distance but is bounded to preserve turn liveness and minimize semantic TOCTOU exposure;
- one or two low-frequency perpendicular bends are sampled once per movement;
- no independent per-frame X/Y jitter;
- exact requested endpoint is preserved by construction;
- zero-distance movement emits no redundant cursor travel;
- a per-movement seed is emitted in diagnostics for reproducibility.

## Safe endpoint policy

R5.159 never invents clickable geometry.

- point-only spell slots/buttons/directions continue to use the exact calibrated point;
- bridge-projected cells may expose paired `safe_screen_points` / `safe_client_points`;
- only those bridge-certified candidates may be varied;
- selection is center-biased and repeat-avoidance is weak/bounded, never forced;
- entity-anchor targeting keeps its exact verified entity point rather than cell-safe alternatives.

Arbitrary `target +/- random pixels` is forbidden.

## Fail-closed movement safety

Before mouse DOWN:

- the target HWND must remain foreground throughout movement;
- unexpected external cursor displacement aborts with `INPUT_CURSOR_INTERFERENCE`;
- inability to read the real cursor aborts with `INPUT_CURSOR_POSITION_UNAVAILABLE`;
- a failed OS move aborts with `INPUT_CURSOR_MOVE_FAILED`;
- focus loss aborts with `INPUT_FOREGROUND_LOST_DURING_MOVE`;
- final position must equal the selected endpoint or movement aborts with `INPUT_CURSOR_ARRIVAL_MISMATCH`.
- physical-pixel mode never falls back to logical cursor reads/writes when DPI-aware physical APIs are unavailable.

If movement fails, mouse DOWN is never sent. Existing post-DOWN uncertainty handling remains unchanged.

## Diagnostics

`DofusWindowInputDriver.debug_status()` now carries bounded movement evidence including:

- motion profile;
- actual start / target / final cursor positions;
- distance;
- planned and actual duration;
- sample/emission counts;
- motion seed;
- primary/secondary lateral amplitudes;
- exact-arrival result;
- safe endpoint candidate/selection evidence when applicable.

No huge per-point trajectory is written into normal runtime logs.

## Preserved boundaries

R5.159 does **not** change FightAI, Kernel mechanics, Canonical State semantics, action selection, target-cell legality, projection admission, protocol decoding, action settlement, InputArbiter ownership, R5.158 network-continuity behavior, or R5.157 live-decoding certification.

## Live acceptance

A Windows/Dofus run must still prove:

1. no visible teleportation on normal long-distance moves;
2. exact reliable spell/button/cell clicks;
3. smooth short and long trajectories;
4. safe projected-cell endpoint variation only inside bridge-proven candidates;
5. focus loss/interference prevents clicking;
6. multi-account handoff remains serialized;
7. R5.158 continuity HOLD/RECOVERING behavior remains intact under network stalls.

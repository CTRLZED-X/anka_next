# New Chat Handoff — R5.172

Current workspace: **ANKA R5.172 — Projection / Entity Resolution Hardening**.

Start from R5.172, not R5.171. The October 11 R5.171 live run proved that protocol/capture/map/grid/camera/bridge setup were healthy but Launch was globally blocked by historical `entity_character_<id>` actor-anchor assumptions. R5.172 separates projection geometry authority from entity interaction authority.

Startup now certifies the runtime 560-cell converter against exact active rendered `GraphicCells/cell::<id>` anchors. Concrete EntityId interaction is resolved only when an action requires it and remains fail-closed if the signed EntityId, canonical CellId, live visual hierarchy, exact cell anchor and viewport cannot be associated unambiguously.

Important R5.172 invariants:

- never restore `entity_character_<id>` as a global startup prerequisite;
- negative world-group IDs are valid identities;
- inactive Resources objects cannot establish actor or cell authority;
- no entity-target click may fall back to a ground cell;
- CRA/ENU bridge discovery files are process-scoped by PID and debug bundles retain all candidates;
- stale discovery evidence must be marked stale by payload timestamp/process identity;
- projection refresh during pending Launch is input-free and rate-limited;
- entity-resolution timeouts are distinct from bridge disappearance;
- R5.170 protocol drift fail-closed rules and R5.171 runtime-reflection portability remain mandatory.

For a live failure, send the generated runtime/latest debug bundle. R5.172 is specifically designed so an unresolved current Dofus entity layout produces fresh scene/component/candidate evidence from one run.

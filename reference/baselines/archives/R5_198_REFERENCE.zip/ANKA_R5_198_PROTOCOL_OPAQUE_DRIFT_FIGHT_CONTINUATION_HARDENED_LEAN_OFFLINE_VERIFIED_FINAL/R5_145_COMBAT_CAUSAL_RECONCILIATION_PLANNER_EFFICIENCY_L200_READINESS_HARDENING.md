# R5.145 — Combat Causal Reconciliation, Planner Efficiency & L200 Readiness Hardening

## Why this milestone exists

R5.144 materially improved live combat: the supplied `runtime(20260927-211946)` completed fights 519, 520 and 521, and CRA/ENU used substantially more of their configured spell bars. Fight 522 still terminated the campaign when ENU sent a physical MOVE click toward cell 176 but Canonical State did not confirm the target cell inside the settlement budget. The result became `UNCERTAIN`, then `COMBAT_FAILED`.

The core R5.145 rule is therefore:

> A local combat timeout is not automatically a mission failure. If physical input is certainly SENT but its semantic/server outcome is not yet known, stop producing new input, preserve the campaign, and passively reconcile authoritative evidence. Only genuinely uncertain physical input or broken control/window/generation identity remains a hard fence.

R5.145 also addresses live planner waste, state-readiness gaps and the dormant enemy-capability integration that would otherwise make level-200 strategy unreliable.

## 1. MOVE causal reconciliation

A fight MOVE whose click is certainly `SENT` but whose target cell is not yet confirmed now returns `RECONCILING / COMBAT_MOVE_CAUSALITY_PENDING`, not terminal `UNCERTAIN`.

The execution service retains the exact transaction context and permits no new physical input while it is unresolved. Passive reconciliation can close the action when authoritative evidence proves one of:

- target cell reached;
- actor moved to another authoritative cell (for example a shortened/altered move);
- newer evidence proves no movement occurred;
- same-session capture evidence proves no semantic movement request was emitted;
- turn advanced;
- fight ended or changed.

A physically `UNCERTAIN` send is **not** placed on this path. It remains `ACTION_UNCERTAIN_FENCE`.

Reconciled moves are first-class consumed actions. A move to an unexpected authoritative cell is not treated as a free retry.

## 2. END_TURN causal reconciliation

The same principle now protects END_TURN. A certainly-sent END_TURN click with no confirmed turn boundary becomes `COMBAT_END_TURN_CAUSALITY_PENDING` and is passively reconciled from turn/fight evidence and same-session semantic `jvv` evidence.

When repeated certified evidence proves that the client ignored two END_TURN clicks in the same turn, the controller stops clicking and waits for authoritative automatic handoff. This prevents a local UI problem from becoming an input loop.

## 3. Unified non-success action contract

Every non-successful CAST/MOVE/END_TURN result is normalized to a structured diagnostic contract containing, where applicable:

- `failure_code`;
- `physical_send_state`;
- `safe_replan`;
- `reconciliation_required`;
- `first_missing_boundary`;
- `likely_owner`;
- operation identity.

Unknown/non-classified results use `COMBAT_ACTION_UNCLASSIFIED` rather than disappearing into a generic runtime failure.

Incident capture remains separate from control fencing. Structured MOVE/END_TURN reconciliation does not revoke ControlAuthority; uncertain physical input still does.

## 4. Turn/campaign liveness

The fight controller polls pending causal reconciliation before asking FightAI for another action. While evidence is unresolved it returns `WAIT / COMBAT_ACTION_RECONCILING`, with an evolving progress token that includes Canonical revision, semantic-send state and negative-evidence sample count.

The exact semantic action remains quarantined while pending. On safe closure, the controller either consumes the confirmed action, quarantines a proven rejected/no-op action and replans, or advances naturally into the newer turn/fight state.

This is deliberately different from "ignore uncertainty and continue clicking". New physical input stays blocked until causality is safe.

## 5. Planner efficiency and movement quality

The live run showed many movements with no immediate safety/threat/team-pressure improvement and repeated reversal replans. R5.145 makes movement value marginal to the current cell rather than rewarding absolute destination safety already owned by the actor.

A MOVE with **no marginal tactical value** is hard-rejected. Formation, range-fit, pincer reduction, safety improvement and team-reply improvement still count as legitimate value. The controller also preserves the same-turn move-chain cycle guard, preventing immediate revisit/reversal loops.

The cast stage reserves a deterministic tail for movement/selection and explicitly distinguishes base-cast-stage budget exhaustion from whole-decision exhaustion. Configured spells are evaluated in priority order with bounded target previews; if budget expires after material candidates already exist, the planner chooses the best certified candidate instead of throwing away remaining AP with END_TURN.

## 6. Local HP/max-HP identity-race repair

R4 `krk` is certified account-local owned-character HP/max-HP evidence. The adapter previously dropped a `krk` packet if it arrived before strong local actor identity. That can explain a whole fight with missing local HP/max HP even though the packet existed.

R5.145 buffers pre-identity `krk` evidence and flushes it only after a HYDRATED-or-stronger local actor identity is certified. It never binds the buffered values to a weak transition/world identity.

The decoder hash change is recorded by `verification/r5_145_decoder_delta_certification.json`, chained to the retained R4/R5.136 certificate rather than rewriting historical evidence.

## 7. Explicit L200 combat-truth readiness

Every FightAI decision now includes a `combat_truth` readiness summary. It reports missing local/enemy HP/max HP, AP/MP, summon capacity, state/effect completeness, enemy static identity and the known exact tackle/lock limitation.

No missing value is inferred from equipment or role configuration. Session/fight summaries aggregate these blockers so a runtime bundle directly states why level-200 tactical reasoning is incomplete.

R5.145 also reports suspicious effect-payload growth (large retained effect count or repeated semantic signatures). It **does not** deduplicate or expire canonical effects heuristically; removal/expiry semantics remain fail-closed until protocol evidence certifies them.

## 8. Production enemy-capability activation

The bundled enemy capability catalog existed previously but production `ranged_control_v1` constructed the strategy with an empty catalog. R5.145 loads `EnemyCapabilityCatalog.bundled()` in production.

The active source/mode remains recorded in team-plan evidence. Unknown enemies still use the bounded fallback; no monster mechanic is invented.

## 9. CRA + ENU coordination contract

`TeamFightPlan` now carries explicit `coordination_intents`. For an active CRA+ENU core these include shared focus, ranged-backline preservation, ENU control creating CRA attack windows, CRA exploiting controlled targets and preservation of partner reply geometry. Danger/setup/burst modes add corresponding multi-turn intent tags.

These are planning/telemetry contracts only. They do not bypass the Kernel, Canonical State, admission, or ExecutionService. Their purpose is to make the team brain replaceable/evolvable for level-200 strategy without coupling it to physical execution.

## 10. Problems & health deduplication

Recovering a previously failed backend session no longer creates a second synthetic UI Problem card for the same terminal root. The backend problem remains the causal card; the banner remains operator context.

## Fail-closed boundaries intentionally preserved

R5.145 does **not** guess:

- physically uncertain input outcome;
- unknown enemy absolute HP/max HP/AP/MP when no certified baseline exists;
- arbitrary effect expiry/removal;
- unknown summon capacity;
- exact tackle/lock mechanics;
- unregistered level-200 monster mechanics;
- live AP/MP/PO from equipment builds.

These remain explicit readiness blockers rather than fabricated tactical truth.

## Live acceptance

R5.145 is an offline-verified candidate only after all release gates complete. Windows/Dofus acceptance remains **PENDING** until a fresh run proves at minimum:

1. a sent/unconfirmed MOVE enters reconciliation and the campaign survives to a safe closure/next turn;
2. a sent/unconfirmed END_TURN cannot cause a click loop or immediate mission death;
3. physically uncertain input still fences;
4. local HP/max HP appears when the `krk`/identity race occurs;
5. no-value MOVE is not selected over END_TURN;
6. decision-budget exhaustion does not discard material certified actions;
7. the production team plan reports a non-empty bundled enemy-capability source when known static IDs exist;
8. one multi-fight lower-zone soak continues without mission-blocking local combat failures.

Level-200 tactical readiness is **not** claimed until the runtime `l200_readiness_blockers` are sufficiently cleared and zone-specific live acceptance succeeds.

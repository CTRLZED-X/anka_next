# R5.157 — Protocol-Independent Live-Decoding Reference

## Objective

R5.157 hardens R5.156 so `verify_live_decoding.bat` is not merely a checker for the current hand-written requirement list. It introduces one explicit, versioned, protocol-independent reference for the complete live-decoding surface ANKA currently exposes and consumes.

The reference is stable across Dofus wire changes. A future adapter may decode different raw names/fields, but it must still prove the same canonical meanings before the exact build can become `READY`.

## Authoritative reference

Source authority:

- `src/anka_platform/protocol/live_decoding_reference.py`
- immutable snapshot: `docs/reference/LIVE_DECODING_REFERENCE_V1.json`

The reference explicitly covers **all 42 Canonical Contract v1 event kinds**, all **24 `ProtocolCapability` values**, and all **6 stable outbound `ProtocolWireSemantic` values**. Every canonical event has an explicit role, consumer set, capture recipe, reducer disposition and decision-critical field set.

A test requires the reference to exactly equal the canonical union. Adding a new canonical event without classifying it makes reference validation fail rather than silently treating the event as optional.

## Stronger READY semantics

R5.156 could still false-green in two important ways:

1. an event could exist while decision-critical fields were never known;
2. a field could be populated but mapped to the wrong meaning.

R5.157 closes both.

`READY` now requires every REQUIRED reference semantic to be exercised by fresh exact-build evidence and all of its critical fields to be proven KNOWN. Controlled scenario manifests can additionally assert expected canonical values, so a known controlled cast can prove the decoded spell/cell meaning rather than only the existence of a `spell_cast_observed` object.

Coverage is intentionally split into event presence, semantic coverage and critical-field coverage. A high event percentage cannot hide partial field semantics.

## Scenario assertions

Evidence packages can point to `LIVE_DECODING_SCENARIO.json`. See `docs/reference/LIVE_DECODING_SCENARIO_TEMPLATE.json`.

The scenario supports:

- `expected_event_kinds`
- `expected_wire_semantics`
- `canonical_assertions`

A canonical assertion names an event, optional account, expected field/value mapping and minimum match count. Failed controlled expectations make replay fail closed and are surfaced to GPT as the first scenario divergence.

## GPT debug

`runtime/live_decoding/LIVE_DECODING_GPT_DEBUG.json` remains GPT-oriented. R5.157 adds explicit reference gaps such as:

- `REFERENCE_EVIDENCE_GAP`
- `REFERENCE_EXPECTED_EVENT_MISSING`
- `REFERENCE_CRITICAL_FIELD_GAP`
- reference-integrity defects

The debug tells GPT whether to collect evidence, trace a field authority, repair a decoder mapping, fix reducer semantics or fix the reference itself. Missing evidence must never trigger speculative protocol implementation.

## Current retained baseline

The retained historical evidence predates R5.157 field-level reference statistics. It therefore remains deliberately non-READY and now exposes more proof gaps than the old R5.156 three-gap summary. That is expected: R5.157 is a stronger verifier, not a regression in decoding.

The correct way to establish a current-protocol golden baseline is to capture controlled exact-build evidence that exercises the complete REQUIRED reference and its scenario assertions, then run:

```bat
verify_live_decoding.bat <evidence-folder> [more-evidence-folders...]
```

Only `status=READY` authorizes treating that exact code/build/evidence subject as fully certified for the current ANKA live-decoding reference.

Windows/Dofus live acceptance for the broader runtime remains pending.

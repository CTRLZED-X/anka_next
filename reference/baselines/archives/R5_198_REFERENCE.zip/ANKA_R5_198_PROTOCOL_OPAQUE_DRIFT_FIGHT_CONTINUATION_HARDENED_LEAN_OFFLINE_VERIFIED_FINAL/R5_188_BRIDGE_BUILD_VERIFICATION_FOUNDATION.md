# R5.188 — Bridge Build Verification Foundation

**Status:** **OFFLINE VERIFIED** for the R5.188 scope. Windows/Dofus live acceptance remains pending until the real Windows bridge build/install and bounded live run succeed.

## Why this release exists

The first real R5.187 Windows setup reached the .NET compiler and failed in `unity_bridge/RuntimeSceneScanner.cs` because `FindFightEntryTarget()` still referenced deleted locals `launchHierarchy` and `launchWorld`. The R5.186 refactor had renamed the optional exact-cell outputs to `optionalLaunchCellWorld` and `optionalLaunchCellHierarchy`, but the diagnostics object was not updated. Python-only offline tests could not compile the BepInEx bridge and therefore missed the defect.

## Root-cause repair

- `FindFightEntryTarget()` now captures the optional exact-cell lookup result in `optionalLaunchCellResolved`.
- Diagnostics use `optionalLaunchCellHierarchy` / `optionalLaunchCellWorld` only when that lookup succeeded.
- The runtime-grid spatial authority and entity-subtree safety rules from R5.186 are preserved. Literal `cell::<id>` objects remain optional corroboration only.
- `tools/verify_unity_bridge_source.py` adds a stdlib-only structural/rename/safety preflight and explicitly rejects the exact stale-local regression.
- `tools/verify_release_integrity.py` now runs that bridge-source preflight, so package sealing cannot report READY when the known source contract is broken.
- `setup.bat` runs the bridge-source preflight before creating/installing the live environment and stores `runtime/environment/bridge_source_preflight.json`.
- Setup debug export includes that record, while the real Windows `dotnet build` remains the final bridge compilation authority.

## Preserved foundations

R5.188 does not change the active `dofus_3_6_12_16` protocol adapter, FightAI, Kernel, Canonical contract, execution-safety authority, or R5.186 entity-resolution/control fixes. Bridge plugin identity remains `2.2.76`, contract 4, projection authority `ENTITY_SUBTREE_RUNTIME_GRID_V3`; the corrected source hash is sealed in `unity_bridge/PROVENANCE.json`.

## Next live step

Use a fresh R5.188 extraction with Dofus closed and run `setup.bat`. `BRIDGE_SOURCE_PREFLIGHT=READY` must appear before dependency installation, and the later real bridge `.NET` compilation/install must also succeed. Only after the complete setup is green should `start.bat` and a small bounded CRA+ENU run be attempted.

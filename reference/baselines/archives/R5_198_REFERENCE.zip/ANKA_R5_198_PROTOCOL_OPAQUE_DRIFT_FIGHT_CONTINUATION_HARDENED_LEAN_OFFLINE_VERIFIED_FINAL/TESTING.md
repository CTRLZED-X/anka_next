> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# R5.198 current testing contract

`tests/r5198` proves exact `icl`/`icw` opaque fingerprints classify with zero Canonical mutation, changed payload/direction variants remain fail-closed, current release identity is coherent, and the zero-input systemic suite includes the new protocol-drift scenario.

The current gates also retain R5.197 startup/takeover, R5.196 turn-handoff, protocol, Canonical, reliability, execution, FightAI, projection, diagnostics, and replay coverage. Protocol upgrade contract, engineering guardrails, release integrity, dependency baselines, and package-manifest validation remain mandatory before packaging.

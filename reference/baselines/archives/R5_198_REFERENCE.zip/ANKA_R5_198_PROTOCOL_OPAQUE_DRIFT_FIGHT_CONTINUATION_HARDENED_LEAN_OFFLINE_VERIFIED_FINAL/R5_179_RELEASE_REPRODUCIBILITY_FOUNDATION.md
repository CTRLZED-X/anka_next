# R5.179 — Release & Reproducibility Foundation

R5.179 is intentionally a release-engineering foundation over R5.178. It does not change FightAI, Canonical State semantics, protocol wire decoding, projection authority, or physical-input behavior.

## Structural changes

- current machine state is compact; cumulative hardening history moved to `docs/history/PROJECT_HARDENING_HISTORY.md`;
- exact dependency resolution is defined by `requirements/anka-constraints.txt` and checked against `requirements/DEPENDENCY_BASELINE.json`;
- `setup.bat` no longer performs an unpinned `pip --upgrade`; it installs the release-pinned toolchain/dependencies and writes an observed dependency record;
- `docs/CURRENT.md` is the human current-document index;
- `verification/BEHAVIORAL_TEST_GROUPS.json` provides behavior-oriented navigation across the historical release test archive;
- `tools/verify_release_integrity.py` cross-checks release identity, project context, test gate, dependency baseline, current docs and status compactness before sealing.

## Preserved safety

R5.178 execution lifecycle serialization, R5.177 Diagnostics V2, R5.176 protocol capability isolation, R5.175 failure authority, R5.174 startup fail-stop, strict projection/entity proof and the single physical-input authority are unchanged.

Windows/Dofus live acceptance remains **PENDING**.

# NEW CHAT HANDOFF — R5.159

Current workspace: **R5.159 Smooth Pointer Motion & Safe Endpoint Hardening**.

Read in this order:

1. `PROJECT_STATUS.json`
2. `R5_159_SMOOTH_POINTER_MOTION_SAFE_ENDPOINT_HARDENING.md`
3. `R5_158_LIVE_TRUTH_CONTINUITY_TRANSPORT_RECOVERY_HARDENING.md`
4. `R5_157_PROTOCOL_INDEPENDENT_LIVE_DECODING_REFERENCE.md`
5. `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`

R5.159 changes only the physical pointer-delivery boundary. FightAI/Kernel/Canonical/projection legality and semantic target decisions remain unchanged.

Production cursor motion authority is `src/anka_platform/execution/pointer_motion.py`, consumed by `DofusWindowInputDriver` in `src/anka_platform/execution/windows.py`.

Important invariants:

- no production cursor teleportation for Native Win32 movement;
- movement starts from the actual cursor position;
- minimum-jerk slow -> fast -> slow progression;
- bounded smooth lateral variation, never per-frame jitter;
- exact final endpoint verification before DOWN;
- focus loss or external cursor interference blocks before DOWN;
- endpoint variation is allowed only among caller-certified safe points;
- point-only calibrated controls remain exact;
- R5.158 continuity and uncertainty fences are unchanged.

Windows/Dofus live acceptance remains **PENDING**.

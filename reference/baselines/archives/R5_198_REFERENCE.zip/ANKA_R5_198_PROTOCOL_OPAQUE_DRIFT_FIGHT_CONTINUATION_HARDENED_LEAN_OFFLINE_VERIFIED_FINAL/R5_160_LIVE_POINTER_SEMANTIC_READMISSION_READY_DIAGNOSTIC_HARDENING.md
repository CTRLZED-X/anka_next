# R5.160 — Live Pointer Semantic Re-admission, Ready & Diagnostic Hardening

Status: **offline verified source tree; Windows/Dofus live acceptance pending**.

## Evidence source

R5.160 is driven by the Windows/Dofus runtime captured in `runtime(20261003-124729).zip`. That run completed the mission at **5/5 wins**, so this release does not reinterpret a successful campaign as a global combat failure. It addresses repeated reliability and evidence-quality defects exposed inside that successful run.

Confirmed live findings:

- pointer humanization was active and reliable: 75 observed movements arrived successfully with no focus/interference/arrival failures;
- R5.159 movement scheduling accumulated per-sample overhead, making actual motion roughly 20% slower than the plan on average;
- all 35 combat heartbeats used the same roughly 1,035 px corner sweep, creating unnecessary long and repetitive pointer travel;
- all five fights showed the same first-CRA-Ready pattern: first click produced no outbound READY request, later retry succeeded;
- one MOVE was safely blocked only because the global Canonical revision changed from admission to final send even though the action-relevant semantics remained valid;
- the incident exporter incorrectly promoted that recovered fail-closed MOVE block into a terminal campaign failure even though no semantic input was sent and the campaign later reached the target wins;
- projected cell endpoint variation remained unavailable because the Unity bridge exposed only one certified exact anchor per cell. R5.160 does not invent unsafe geometry.

## 1. Semantic re-admission instead of revision equality

A Canonical revision is an event/evidence watermark, not an action-authorization token. Unrelated effect/provenance observations may legitimately advance it.

R5.160 therefore removes raw revision equality as MOVE/CAST authorization. The execution chain now performs fresh semantic admission at the boundaries that matter:

```text
PRE_TARGET admission
  -> projection
  -> POST_PROJECTION semantic re-admission
  -> smooth pointer travel
  -> exact pointer arrival
  -> PRE_DOWN semantic guard
  -> mouse DOWN only if still authorized
```

For MOVE this rechecks fight/map/turn/local-actor identity and Kernel movement admission. For CAST it rechecks fight/map/turn/local actor, spell/action admission, client-interaction admissibility and current projection evidence.

Harmless revision churn may proceed. A real map, turn, actor, AP/MP, legality, projection or certified-endpoint change still fails closed before DOWN.

## 2. Smooth-pointer TOCTOU closure

R5.159 correctly revalidated before pointer delivery, but smooth movement adds a physical travel interval between that check and mouse DOWN. R5.160 adds a caller-owned `pre_down_guard` to the final split-click transaction.

The guard runs **after exact pointer arrival and hover, immediately before DOWN**. A failure produces `NOT_SENT`; there is no semantic click to reconcile.

The selected safe endpoint is also part of this guard. If future projection code provides several certified safe cell points and the chosen point ceases to be certified during pointer travel, the click is blocked as stale. This closes a latent endpoint-selection race before endpoint variation becomes common.

## 3. Pointer timing quality

R5.159 removed duplicate rounded integer coordinates, then evenly rescheduled the remaining points. That partially flattened the intended slow -> fast -> slow temporal profile on shorter moves.

R5.160 keeps each emitted unique point's original normalized trajectory time and schedules against absolute deadlines rather than sleeping a relative interval after every OS cursor write.

This prevents OS/Python per-sample overhead from accumulating into motion duration and retains the minimum-jerk temporal shape after integer-coordinate deduplication.

The planner also supports one bounded coherent timing-asymmetry parameter per movement. It is movement-level variation, not per-frame jitter.

## 4. Heartbeat quality

The old turn-activity heartbeat moved the cursor to a fixed client corner. In the live run this produced 35 repeated screen-crossing movements.

R5.160 replaces production heartbeat travel with a small bounded relative nudge inside the currently bound Dofus client. It sends no click. If the cursor is outside the Dofus client, the heartbeat is skipped instead of reclaiming the mouse through a long sweep.

This keeps the heartbeat's liveness purpose without turning it into a repeated large pointer signature or unnecessary TOCTOU delay.

## 5. Ready UI quiescence

The five-of-five first-CRA-Ready miss pattern is treated as evidence of a UI/lifecycle stabilization boundary rather than as random click failure.

After placement convergence, R5.160 requires an additive Ready settle window:

```text
ready_control_settle_seconds = 1.0
ready_ui_quiescence_seconds = 1.25
---------------------------------
effective Ready control settle = 2.25 s
```

Existing focus-stability and Ready retry/causality logic remains intact. This is a bounded pre-interaction quiescence period, not a larger generic mission timeout.

## 6. Recovered anomaly vs terminal failure

A fail-closed action that sent no semantic input, explicitly permits replan, and is later recovered must not become the campaign's terminal root cause.

R5.160 centralizes this classification in campaign disposition and reuses it in the forensic exporter. Recovered admission/projection blocks remain visible under `analysis/recovered_anomalies.json`, but they do not turn a successful `TARGET_WINS_REACHED` campaign into `FAILURE_OBSERVED`.

The R5.159 live operations database was re-exported with this logic and now reports PASS with the recovered MOVE block retained as an anomaly rather than a terminal failure.

## 7. Pointer-motion health artifact

The forensic exporter now emits a compact pointer-motion health artifact rather than requiring GPT to mine the full diagnostics stream.

It summarizes:

- movement count and failures;
- exact-arrival percentage;
- distance distribution;
- planned/actual durations and timing ratio/overrun;
- sample counts;
- lateral amplitudes and timing skew;
- endpoint candidate/variation availability;
- heartbeat strategy and nudge distances;
- per-operation movement statistics.

When the bridge exposes only one safe point, diagnostics explicitly report that certified endpoint variation is unavailable rather than pretending humanized target variation occurred.

## 8. Preserved foundations

R5.160 does not redesign FightAI, Kernel mechanics, Canonical State ownership, protocol decoding, R5.158 network continuity, R5.157 live-decoding certification, or the R5.159 centralized pointer authority.

Global Canonical revision remains a valid evidence watermark. It is simply no longer misused as a complete MOVE/CAST authorization condition.

## Live acceptance still required

Offline verification cannot prove the live client behavior. The next controlled Windows/Dofus run should verify:

1. first Ready requests are no longer systematically missed;
2. harmless Canonical churn does not create false MOVE/CAST admission blocks;
3. a real turn/map/legality change during pointer travel blocks before DOWN;
4. pointer actual/planned timing is materially closer than the R5.159 ~1.20 ratio;
5. heartbeat uses small relative nudges instead of fixed long sweeps;
6. recovered no-input anomalies do not become terminal incident roots;
7. 5-fight campaign continuity and multi-account handoff remain intact.

# R5.149 — Transaction Authority, Strict Result Contracts, Single Lifecycle Owner & Verification Hardening

R5.149 is a behavior-preserving foundation milestone over R5.148. It was driven by an independent audit of the exact R5.148 ZIP, which found that the new typed contracts were useful but did not yet enforce several cross-layer invariants strongly enough.

## Primary objective

A local combat anomaly must not become a silent second action, a wrong-action reconciliation, an infinite wait, or a mission-terminal failure because two layers interpreted the same raw result differently. Current combat infrastructure must fail closed on contradictory ownership and malformed result contracts while preserving safe, proven replanning.

## Transaction authority

`ExecutionService` remains the sole physical-input authority. `PartyCombatController` may hold only a turn-local projection of an unresolved transaction. Those two views are required to correlate exactly.

A current `PendingCombatTransaction` binds:

- `origin_action_id`;
- owning account lane;
- fight generation;
- operation kind;
- origin/target cells when relevant.

While a current transaction is pending, `WAITING`, `RETAINED`, or `RECONCILED` evidence must carry the exact correlation. Missing/wrong action id, wrong account, wrong fight generation, an orphan execution transaction, or a reconciliation-hook exception is an authority error. It cannot be interpreted as `CLEAR` permission for another click.

## Strict execution-result contract

Raw execution mappings normalize through `CombatActionOutcome`, but R5.149 validates combinations before assigning a safe phase.

Contradictions such as:

- `CONFIRMED` plus `INPUT_UNCERTAIN`;
- `CONFIRMED` plus physical `NOT_SENT`;
- accepted status plus semantic uncertainty;
- unknown physical-send tokens;

become `CONTRACT_VIOLATION` and fail closed rather than being resolved by field-precedence rules.

R5.149 also adds a distinct safe semantic-rejection state. A target click may have been physically `SENT` while the certified protocol evidence proves that no semantic cast left the client. When UI neutralization, `safe_replan`, and quarantine proof are all present, `CLIENT_CAST_REJECTED` becomes `SEMANTIC_REJECTED_SAFE`: the spell/action may be quarantined and FightAI may replan without treating the event as physical uncertainty or terminating the fight.

## Admission UNKNOWN evidence

R5.148 separated combat semantics from provenance revisions, but admission-UNKNOWN recovery still used raw revision churn as its retry trigger. R5.149 stores a decision-semantic fingerprint for the waiting admission. Unrelated packet/revision activity no longer releases the wait; a relevant semantic frame change does.

## Fight lifecycle authority

`FightWorkflow` now exposes a typed `FightGenerationLifecycleStatus` with typed `FightPartialClassification` (`ENTRY_JOINING` / `EXIT_SETTLING`). `CampaignRuntimeController` consumes this classification instead of independently interpreting ad-hoc PARTIAL strings. One compatibility normalization path remains for historical test façades.

This does not create a new physical-action owner. Campaign still owns campaign progression; FightWorkflow owns fight-generation classification/workflow state; PartyMissionController owns entry mechanics; PartyCombatController owns turn orchestration; ExecutionService owns physical input.

## Current policy preflight

Runtime-checkable Protocol membership alone does not prove a callable has the correct signature. R5.149 therefore validates the call shape of policies selected into the current `SessionPlan` before session arming:

- active FightPolicy and passive policy support the current `planner_context` contract;
- team strategy binds its current team-objective call shape;
- placement strategy binds its current placement call shape.

Historical/direct compatibility invocation remains isolated from the current live-session preflight.

## Verification authority

`gpt_verify.bat quick` and `gpt_verify.bat full` now run an explicit current-workspace gate from `verification/CURRENT_TEST_GATE.json` through `tools/gpt_current_verify.py`.

Frozen historical release-number assertions remain useful for certifying their original artifacts, but they are no longer mixed into the current workspace baseline. A future GPT/developer can therefore run the advertised current verifier and distinguish a real functional regression from an archival identity assertion.

Timed-out aggregate commands are never counted as passing evidence; suites are rerun in bounded groups.

## Authority split to preserve

```text
protocol/canonical state = observed live truth
Kernel                  = deterministic mechanics/legality
FightAI                  = replaceable proposal/planning brain
FightWorkflow            = fight-generation lifecycle classification/workflow
PartyCombatController    = turn orchestration + turn-local transaction projection
ExecutionService         = sole physical-input / durable transaction authority
CampaignRuntimeController= campaign progression/outcome/re-entry
observability            = evidence only, never permission
```

## Explicit non-goals / remaining level-200 blockers

R5.149 does not solve or claim:

- exact tackle/lock mechanics;
- authoritative effect/state apply-refresh-stack-expire-remove lifecycle;
- complete enemy dynamic HP/max-HP/AP/MP truth;
- complete summon capacity/lineage semantics;
- verified capability packs for arbitrary level-200 zones;
- universal advanced FightAI strategy.

Those remain future mechanics/evidence work after Windows/Dofus live acceptance of the foundation.

## Acceptance principle

The current foundation must satisfy all of the following without strategy-specific patches:

1. one unresolved physical transaction can never coexist with permission for a second action;
2. reconciliation can affect only the exact action/account/fight that produced it;
3. contradictory execution fields are rejected as a contract violation;
4. proven client-local semantic rejection can safely replan without being confused with uncertain physical input;
5. irrelevant evidence revision churn cannot release an admission wait;
6. PARTIAL fight state has one typed generation classification;
7. malformed selected policy call signatures fail before the live session arms;
8. the advertised current verification command is green on the exact delivered current workspace.

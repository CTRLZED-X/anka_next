# NEW CHAT HANDOFF — R5.160

Current workspace: **R5.160 Live Pointer Semantic Re-admission, Ready & Diagnostic Hardening**.

Read in this order:

1. `PROJECT_STATUS.json`
2. `R5_160_LIVE_POINTER_SEMANTIC_READMISSION_READY_DIAGNOSTIC_HARDENING.md`
3. `R5_159_SMOOTH_POINTER_MOTION_SAFE_ENDPOINT_HARDENING.md`
4. `R5_158_LIVE_TRUTH_CONTINUITY_TRANSPORT_RECOVERY_HARDENING.md`
5. `R5_157_PROTOCOL_INDEPENDENT_LIVE_DECODING_REFERENCE.md`
6. `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`

R5.160 is based on the live R5.159 run that reached **5/5 wins** but exposed five systemic quality/reliability issues: revision-equality false admission blocks, a smooth-pointer pre-DOWN TOCTOU interval, repeated first-CRA-Ready misses, long fixed heartbeat sweeps, and forensic misclassification of recovered fail-closed actions.

Important invariants:

- `ExecutionService` still owns physical semantic action delivery;
- MOVE/CAST safety is determined by fresh action semantics, not raw Canonical revision equality;
- MOVE/CAST are re-admitted after projection and immediately before mouse DOWN;
- pointer motion remains centralized in `execution/pointer_motion.py` and `execution/windows.py`;
- selected projected safe endpoints must still be certified at pre-DOWN time;
- Ready gets bounded post-placement UI quiescence before first interaction;
- heartbeat is a small relative no-click nudge, never a mandatory long corner sweep;
- fail-closed `NOT_SENT` actions that safely replan are recovered anomalies, not terminal campaign failures;
- R5.158 continuity and R5.157 live-decoding certification remain retained.

Windows/Dofus live acceptance remains **PENDING**.

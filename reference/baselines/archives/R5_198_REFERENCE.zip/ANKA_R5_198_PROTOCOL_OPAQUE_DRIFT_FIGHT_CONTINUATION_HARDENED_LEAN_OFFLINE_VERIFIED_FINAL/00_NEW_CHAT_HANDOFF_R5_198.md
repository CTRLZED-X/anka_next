# ANKA R5.198 — New Chat Handoff

R5.198 is the current fight-continuation/protocol-drift hardening candidate. It inherits R5.197 safe Windows control-plane takeover and R5.196 turn-handoff/systemic simulation.

## Failure that triggered R5.198

The 2026-10-16 R5.197 live runtime entered the fight with both accounts and CRA successfully cast its first spell. That CAST settled from authoritative protocol evidence. Immediately afterward, both gameplay flows observed a new server wire `icw`; the generic fail-closed drift policy correctly marked protocol health unclassified, but because the adapter catalog did not yet know this exact non-mutating traffic, the condition became a sticky global runtime-health blocker and stopped the mission before CRA could continue its turn. The capture also contained one earlier unknown `icl` wire.

## R5.198 repair

- `icl` and `icw` are admitted only by exact server-to-client payload fingerprints (direction + size + SHA-256).
- They produce zero Canonical mutations and receive no invented gameplay semantics.
- Any variant remains unclassified and fail-closed.
- Complete mapped gameplay PCAP replay is used for decoder proof.
- Durable per-account Canonical journals are used separately for exact live-revision reconstruction.
- Incident replay reassesses the original blocked frame after protocol repair.
- The zero-input simulator includes exact opaque-drift positive and negative cases.

## First files for future debugging

1. `PROJECT_STATUS.json`
2. `R5_198_PROTOCOL_OPAQUE_DRIFT_FIGHT_CONTINUATION_HARDENING.md`
3. `src/anka_platform/protocol/adapters/dofus_3_7_10_10/wire_catalog.json`
4. `src/anka_platform/protocol/adapters/dofus_3_7_10_10/evidence_provenance.json`
5. `src/anka_platform/simulation/incident_replay.py`
6. `src/anka_platform/simulation/systemic_suite.py`
7. `tests/r5198/`
8. `verification/R5_198_OFFLINE_VERIFICATION.md`

## Next live acceptance

The next bounded run should prove that the same fight can continue after CRA's first settled CAST, then reach further CRA actions and the authoritative CRA→ENU handoff. Any genuinely new/changed protocol traffic must still fail closed and be exported with its exact raw evidence.

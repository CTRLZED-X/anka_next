# ANKA R5.184 — Complete New-Chat Handoff

**Release:** R5.184 — Multi-Account Evidence Completeness Foundation  
**Date:** 2026-10-14  
**Status:** **OFFLINE VERIFIED**  
**Windows / Dofus live acceptance:** **PENDING**

R5.184 preserves the R5.183/R5.182 runtime authority model. It fixes evidence-certification false-green paths found by independently re-inspecting the delivered R5.183 artifact.

## What R5.184 changes

1. **Raw selected-port completeness:** every payload-bearing TCP flow and every newly observed SYN on the selected Dofus server ports must be declared in the evidence package, even when that flow fails Dofus framing/decoding. Undeclared selected traffic is blocking evidence incompleteness.
2. **Per-account ORACLE identity:** if ORACLE snapshots are supplied, every declared account must have a unique `oracle_member_id`.
3. **Per-account transition proof:** MapId / CellId / AP / MP ORACLE proof must demonstrate the transition required by the live-truth contract for every controlled account. Local ActorId must independently match per account.
4. **CellId proof includes another actor:** local movement alone is insufficient; at least one separately identified non-local actor must also show an independently matched CellId transition per declared account.
5. **Strict ORACLE types:** packet indexes and semantic numeric fields must be real JSON integers; `is_my_turn` must be a real JSON boolean. Malformed values cannot contribute proof.
6. **Strict evidence JSON:** duplicate keys, non-finite constants and unknown certification keys fail closed.
7. **True capture-wide packet alignment:** all PCAPNG packet records advance the packet number. Packet-bearing unsupported link types fail closed rather than disappearing from completeness evidence. Multi-section interface identity, EPB/SPB/legacy Packet Block structure and captured lengths are validated.
8. **Transport integrity:** dropped framing bytes or unresolved TCP reassembly gaps block replay/oracle certification instead of being silently ignored.
9. **Same-packet message integrity:** packet-index assertions evaluate all decoded messages carried by a packet; earlier same-packet messages are not overwritten.
10. **Release verification surface:** resumable PASS evidence is bound to operational scripts, missions, profiles, Unity bridge sources, docs/reference material and game/static data in addition to source/tests/tools/configuration.

11. **Transport equivalence is explicit:** selected-port IPv6/non-IPv4 TCP and selected fragmented IPv4 traffic fail closed until the live runtime supports them; unsupported packet-bearing PCAPNG link types cannot be silently ignored.
12. **Acquisition resync is separate from established corruption:** bytes discarded before a flow's first valid message are diagnostic acquisition evidence; later framing drops remain a safety blocker.
13. **Bounded EOF is not corruption by itself:** terminal partial-frame bytes and complete non-Any frames are reported but do not globally invalidate earlier packet-aligned evidence.
14. **Nested ORACLE rows are strict:** identifiers are real strings and unknown keys at every nested layer are evidence-format errors.

## Non-negotiable architecture

Canonical State remains semantic truth. Projection is geometry/UI evidence, not semantic truth. `ExecutionService` remains the sole public physical-input authority; `InputArbiter` remains the cross-account lease. Protocol wire semantics stay inside the versioned adapter. Unknown safety state fails closed.

## Current live status

Offline regression/architecture verification is authoritative in `verification/R5_184_OFFLINE_VERIFICATION.md`. Windows/Dofus compatibility is still not established by offline tests. With no new independent live evidence, live-truth certification remains at the inherited incomplete baseline with five ORACLE gaps: world MapId, local ActorId, actor CellId, current AP and current MP.

## Next live workflow

Use a fresh R5.184 extraction. Close Dofus and run `setup.bat`, then `start.bat`. Perform a small bounded CRA+ENU run. Before certification, inventory the capture with `inspect_live_capture.bat` and explicitly map **every raw payload-bearing selected-port flow and every newly observed selected-port connection (SYN)** to a declared account using out-of-band process/account evidence.

Collect independent packet-aligned ORACLE evidence for both controlled accounts:

- two known MapIds spanning a real map transition;
- independently known CRA and ENU ActorIds;
- local CellId before/after movement plus a separately identified target actor before/after movement/displacement;
- AP baseline, AP loss after a known-cost action and later turn reset/recovery;
- MP baseline, MP loss after movement and later turn reset/recovery.

Preserve the incident/debug bundle on any failure and diagnose the first proven boundary divergence. Do not patch FightAI/protocol speculatively and do not weaken the ORACLE contract just to turn the certificate green.

Do not claim unattended/zone-200 readiness until bounded live acceptance, the five ORACLE proofs, fight correctness and recovery tests are all demonstrated.

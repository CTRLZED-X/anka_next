> **Current release: R5.184 — Multi-Account Evidence Completeness Foundation.** Windows/Dofus live acceptance remains pending.

# R5.184 development rule

Never make live certification green by omitting a selected Dofus flow, aggregating ORACLE proof across controlled accounts, or accepting structurally ambiguous PCAPNG. Fail closed and repair the evidence package/source first.

# R5.162 resource / pointer / Ready invariants

- A confirmed resource-spending action may remain **confirmed but unsettled**. Never authorize another decision from stale AP/MP merely because a newer packet repeated the old number.
- Resource settlement must be causally after the server-confirmed action: explicit AP/MP change evidence or a newer authoritative numeric decrease from the pre-action baseline.
- Production and compatibility execution APIs must share the same pending-settlement fence; no weaker second path is allowed.
- Pointer humanization changes path geometry, never semantic target identity. Exact certified endpoints, PRE_DOWN admission, focus continuity and <=24 px emitted steps remain hard safety contracts.
- Human-like motion means coherent ballistic travel plus bounded correction, not frame jitter, arbitrary zig-zag, or anti-detection tuning.
- Do not add random endpoint offsets until projection can certify a safe interior/multiple safe points.
- First Ready priming is hover-only, one time per fight/account interaction, followed by semantic re-authorization; never replace it with blind repeated clicks.
- Historical physical evidence must come from immutable transaction snapshots, not later mutable driver status.

---

# R5.161 pointer/Ready/forensic invariants

- Human-like motion means smooth aimed movement, not noisy wandering: minimum-jerk forward progress plus bounded low-frequency coherent curvature; never frame-by-frame random jitter.
- Medium/long path curvature may vary, but semantic target identity and exact certified endpoint must not.
- `max_step_pixels` is a physical path safety contract. If the bounded plan cannot satisfy it, fail before moving the cursor; do not silently emit a larger jump.
- Store pointer diagnostics at the send boundary. Never reconstruct an earlier click from mutable driver state after focus checks, ESC neutralization or settlement polling.
- A PRE_DOWN-blocked CAST target may have valid trajectory evidence even though mouse DOWN was correctly NOT_SENT; preserve both facts.
- Ready timing is lifecycle state, not an arbitrary sleep inside the input driver. Keep post-placement settle, window arming, physical send, outbound READY_REQUEST and Ready acknowledgement as separate observable boundaries.
- Do not remove the bounded Ready retry merely because timing is increased; semantic confirmation remains authoritative.
- Do not tune motion for anti-detection or evasion. Reliability, exact targeting and diagnosability outrank visual variation.

---

# R5.159 pointer-delivery invariants

- Production Native Win32 cursor travel is centralized through `PointerMotionService`; higher layers never implement their own trajectories.
- Semantic target selection is unchanged by motion humanization. Point-only verified targets remain exact.
- Endpoint variation is permitted only from caller-certified safe geometry/points; arbitrary random pixel offsets are forbidden.
- Movement begins from the actual cursor position in the same coordinate space as delivery and must prove exact arrival before DOWN.
- Physical-pixel mode never falls back to logical screen coordinates.
- Focus loss, external cursor interference or motion failure blocks before DOWN; post-DOWN uncertainty remains governed by the existing split-click transaction.
- Do not tune pointer randomness for anti-detection/evasion. Variation exists only as bounded motion behavior while reliability remains the priority.

---

# R5.149 transaction-authority invariants

- A controller-owned pending combat transaction plus no matching ExecutionService transaction is an authority mismatch, never permission for new input.
- Current reconciliation requires exact action id, account lane and fight generation; missing or mismatched correlation fails closed.
- Raw execution-result fields must form a valid contract. A success status cannot override physical/semantic uncertainty, NOT_SENT or a failure code.
- Certified client-local semantic rejection may replan only with proven no semantic cast, UI neutralization, safe-replan authorization and quarantine.
- Admission UNKNOWN is released by relevant semantic evidence, not by arbitrary revision-watermark churn.
- FightWorkflow is the typed authority for current fight-generation PARTIAL classification; campaign code consumes that classification.
- A selected current policy must bind to the current call signature before the session arms.
- `gpt_verify.bat quick/full` validate the current workspace gate; frozen historical release identity assertions are not mixed into current functional readiness.

---

# R5.148 combat-foundation invariants

- FightAI is a replaceable planner. Neutral `core/fight` and `core/ports` must not import concrete FightAI implementations.
- Controller/recovery behavior consumes typed planner/action contracts; human-readable reason strings are diagnostics for current producers, not control semantics.
- Observability is injected/read-only and may never authorize input.
- Evidence provenance/version churn is not automatically a semantic combat-state change.
- Reconciliation must correlate the exact `origin_action_id`; never apply evidence from another physical transaction.
- New dataclass extension fields must not be inserted into a historical positional-constructor prefix. Prefer keyword-only/new tail fields or explicit compatibility migration.

---

# R5.135 combat-legality invariants

A tactical decision is a proposal, never permission to click. Every production CAST must pass latest-state readiness and exact Kernel admission immediately before physical input. Absence from a live snapshot may mean zero only when that snapshot is proven complete **and fresh for the relevant evidence**. Confirmed use is recorded only from authoritative observed execution, never from planner intent. Unknown grade, target identity, summon capacity, state completeness, modifier arithmetic or packet coverage must not be guessed into legality.

---

# ANKA Platform — Development Rules

## Before changing code

1. Read `00_START_HERE.md`.
2. Route the symptom with `DEBUGGING.md`.
3. Identify one owning subsystem in `ARCHITECTURE.md`.
4. Reproduce the first missing boundary with a deterministic/adversarial regression.
5. Change the owner, not the visible symptom.

## Preserve

- default physical control = `DISARMED`;
- explicit, exclusive control permits;
- exact session/run correlation for normal campaign input;
- parent-owned startup/campaign lifecycle;
- observation-only pending Launch convergence;
- `WorldWorkflow` / `FightWorkflow` ownership;
- `FightEntryCoordinator` as observation/control-plane phase model only, never a physical-action owner;
- `ExecutionService` as sole physical-input authority;
- canonical-state live authority;
- pure deterministic Kernel;
- exact generation/process identity with UNAVAILABLE distinct from proven replacement;
- domain-spanning causal transactions across WORLD→FIGHT;
- final in-lease revalidation before physical input;
- fail-closed settlement/retry safety;
- forward-compatible thin `scripts/campaign_runtime.py`;
- generic configuration with no character/map/budget hard-coding in platform runtime code;
- bounded hot-path diagnostics: no per-request full forensic traversal, expanding-history serialization, or full-recorder rewrite;
- one authoritative `config.web` control-plane endpoint across normal Windows tooling;
- safe startup ownership: unknown/foreign port owners are never terminated, and ANKA replacement uses positive identity + process-generation evidence.
- Script Studio frontend integrity: one exact UI build identity, self-styled dashboard HTML, and non-stale static delivery across release handovers.

## Never fix a live issue by

- allowing setup/start/passive preflight to click Dofus;
- letting a second control request silently replace the current owner;
- letting stale terminal events disarm another run;
- duplicating campaign state in the worker;
- adding arbitrary sleeps instead of proving settlement;
- increasing watchdog timeouts to mask scheduler/diagnostic overhead;
- collecting full mission/campaign/account forensic histories on every worker request;
- blindly retrying join/launch/Ready clicks;
- treating successful SendInput as semantic success;
- guessing missing protocol/canonical evidence;
- weakening process-generation fences;
- treating previous-session bridge semantics as current truth;
- allowing normal world routing during unresolved fight entry;
- changing Kernel/FightAI when evidence places failure upstream;
- fixing `PORT_BLOCKED` by killing arbitrary PIDs/process names rather than proving the configured-port owner;
- reintroducing independent hard-coded control-plane ports in batch scripts or certification tools.

## Change workflow

```text
runtime/source evidence
  → first missing boundary
  → adversarial regression
  → owner-side fix
  → focused tests
  → adjacent tests
  → current release + historical contract gates
  → collection / compile / context
  → full repository run
  → clean package manifest + extracted ZIP verification
  → Windows/Dofus live acceptance
```

## Documentation rule

Update the compact current layer instead of creating another pile of handoffs:

- `PROJECT_STATUS.json`
- `PROJECT_CONTEXT.json` when routing changes
- `00_START_HERE.md`
- `ARCHITECTURE.md`
- `TESTING.md`
- `DEBUGGING.md`
- `DEVELOPMENT_RULES.md`
- `LIVE_ACCEPTANCE.md`
- `WINDOWS_LIVE_RUNBOOK.md`

## R5.126 monotonic fight rules

- Never reopen challenge/placement/Ready after preparation completed for the same exact `fight_instance_id`.
- Never use an all-present `PARTIAL` shared-fight observation as authority for physical input. Observe until convergence.
- Once `END_TURN` is accepted, the exact turn key is terminal; only a new `(fight, round, turn_index, active_actor)` key may authorize another combat action.
- Preserve independent parent tripwires even when lower-level prevention exists. Defense in depth is intentional for live multi-account races.

## R5.160 pointer/action authorization rule

Do not use global Canonical revision equality as a substitute for semantic MOVE/CAST authorization. Re-read the newest Canonical State and rerun the owning action-admission/projection rules at the actual physical-input boundary. For smooth pointer clicks, caller-owned authorization must be checked immediately before mouse DOWN. A bridge-certified safe endpoint must still be certified at that boundary.


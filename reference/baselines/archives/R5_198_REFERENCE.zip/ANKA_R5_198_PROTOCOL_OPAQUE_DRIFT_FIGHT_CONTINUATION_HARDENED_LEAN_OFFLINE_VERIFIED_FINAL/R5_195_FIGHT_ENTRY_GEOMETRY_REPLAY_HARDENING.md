# ANKA R5.195 — Fight Entry Geometry + Incident Replay Hardening

**Status:** offline-verification candidate; Windows/Dofus bounded live acceptance pending.

## Why R5.195 exists

The 2026-10-15 CRA+ENU runtime entered the same fight (`fight_instance_id=279`) on both clients and then stopped during PLACEMENT before any placement input was sent. The server declared cells including `317`, `330`, and `439` legal for the current fight, while packaged Mapuse `3.6.10.10` marked those cells non-walkable during fight. R5.194 incorrectly treated that static walkability drift as proof that the complete fight geometry was invalid.

R5.195 repairs the authority model instead of whitelisting those cells. Static Mapuse remains topology/floor/LoS geometry; current-fight canonical legal-placement evidence may override stale static walkability only inside that exact fight generation. The global Kernel map is never mutated.

## Root causes repaired

1. **Geometry authority conflation.** Static walkability and current server placement legality were treated as the same authority.
2. **Characteristic ID 0 boundary crash.** Current fight bootstrap characteristics can carry characteristic `0`; Kernel context construction previously rejected it before FightAI could run.
3. **Two divergent placement implementations.** The synchronous path used the joint CRA+ENU placement plan, but production `prepare_fight_step()` could calculate the plan and then fall back to independent placement.
4. **Cross-account reducer skew.** Placement planning could consume different placement generations from CRA and ENU.
5. **Transient local-placement truth becoming terminal.** Unknown local cell/side could reach target validation and look like a permanent illegal-placement failure.
6. **Placement authority leaking into ACTIVE combat.** A server cell proven legal for fight placement could remain overlaid as combat-walkable after the fight left `PLACEMENT`, incorrectly influencing movement/LoS/FightAI. Live placement walkability overrides are now phase-scoped and disappear outside `PLACEMENT`.
7. **Retryable geometry convergence mislabeled as terminal.** A temporary same-generation geometry gap could still surface as `FIGHT_GEOMETRY_UNAVAILABLE`, allowing campaign disposition to terminate an input-free recoverable state. R5.195 introduces typed `FIGHT_GEOMETRY_PENDING` end to end; only a proven contradiction remains terminal.
8. **Placement pointer-travel TOCTOU.** Placement legality/projection were validated before smooth cursor travel, leaving a window where the fight phase, local side, occupancy, or Unity projection generation could change before mouse DOWN. R5.195 revalidates all of those immediately at the physical-send boundary and returns retryable `NOT_SENT` evidence on drift.
9. **Release-gate attestation resume hole.** The release gate hashed source/tests/config but not immutable current-release incident attestations consumed by those tests. A changed attestation could therefore leave an old resumed PASS row reusable. Current incident attestations and other immutable certification inputs are now part of the gate surface while mutable generated gate reports remain excluded.
10. **FightAI composite-service rebuild amplification.** `NormalPolicy` resolved the composite `kernel.spell_decisions` service inside the enabled-spell loop. With the production CRA profile this could rebuild/revalidate the same immutable spell service graph up to 22 times in one planner invocation, unnecessarily consuming turn budget and amplifying host-load jitter. R5.195 resolves that service once per planner invocation and the quick gate now includes the normal-policy bounded-decision regression.
11. **Verification-harness synthetic startup race.** The escaped-descendant cleanup regression gave its synthetic process only one second to spawn and publish a PID. Under a loaded full gate the verifier could time out before the test precondition existed, producing a false release failure. The sub-second timeout-bound test remains strict; the descendant-cleanup test now gives the synthetic setup a separate scheduler margin so it tests cleanup rather than process-start latency.

## Structural changes

- `integration/fight_geometry.py` now separates semantic fight identity, static geometry identity, and fight-scoped live walkability authority.
- `KernelContextAdapter`, Projection observation, FightAI, and Execution admission consume the same fight-scoped geometry overlay.
- `PartyMissionController` routes synchronous and step-driven preparation through shared team-placement helpers.
- A cross-account placement convergence barrier requires one complete fight/map/placement frame and resolved local placement cell/side before input.
- Placement-derived walkability overrides exist only during `PLACEMENT`; ACTIVE combat falls back to independently proven/static movement geometry instead of carrying placement legality forward.
- Geometry convergence has a dedicated `FIGHT_GEOMETRY_PENDING` non-terminal contract across Execution, failure registry, campaign disposition, and PartyMission; true contradictions remain `FIGHT_GEOMETRY_UNAVAILABLE`.
- `FightPlacementPreDownGuard` closes the placement pointer-travel TOCTOU window by rechecking fight generation/phase/map/local identity/side/occupancy plus projection generation immediately before mouse DOWN. Production Windows guarded-click paths execute this check after pointer arrival and before button delivery.
- Release-gate verification-surface hashing now includes immutable incident attestations/certification inputs that release tests consume, preventing stale `--resume` PASS evidence after those inputs change.
- FightAI `NormalPolicy` now reuses one immutable `SpellDecisionService` per decision instead of reconstructing the composite spell-service graph once per configured spell; a regression test enforces the one-resolution contract and the quick release gate exercises it.

## Offline incident replay

R5.195 adds `anka_platform.simulation.incident_replay` and `tools/replay_live_incident.py`.

A runtime ZIP, incident ZIP, or extracted incident can be replayed with **zero physical input** through:

`captured protocol -> current adapter -> Canonical reducer -> shared fight -> geometry -> Kernel context -> Projection observation -> joint placement -> synthetic preparation -> first active FightAI -> first-action Kernel admission`

Synthetic boundaries are labeled explicitly. They validate ANKA logic from the captured authoritative starting state; they do not claim to predict Dofus server replies, Unity rendering, HWND focus/timing, or physical input acceptance.

### Exact runtime(20261015-174148) shadow result

- 172 captured protocol messages replayed;
- CRA and ENU reconstruct fight `279` / semantic fight map `190711808`;
- static walkability conflicts: `317`, `330`, `439`;
- joint placement plan: `cra -> 216`, `enu -> 242`;
- synthetic preparation reaches both Ready acknowledgements and ACTIVE without input;
- first synthetic active owner: CRA actor `496260153637`;
- real `tactical_v1` FightAI result: `MOVE` to cell `202`, reason `TACTICAL_KITE_REPOSITION`;
- real `FightActionAdmissionService`: `ADMITTED`, path `[216, 202]`, one step.

## Evidence limits / next live boundary

The supplied runtime ends while fight 279 is still in PLACEMENT. Therefore actual placement click acceptance, server Ready acknowledgement, first live ACTIVE turn, live action settlement, End Turn handoff, and fight-end/world re-entry remain Windows/Dofus acceptance boundaries.

R5.195 is designed so future runtime bundles can be replayed offline first and expose the next deterministic layer without requiring a new setup/start/launch cycle for every software-only defect.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

if not exist ".venv\Scripts\python.exe" (
  echo DEV_SETUP=BLOCKED
  echo ERROR: Run setup.bat first. Developer/test tooling is optional and is never required for live operation.
  exit /b 2
)

echo ========================================
echo ANKA OPTIONAL DEVELOPER/TEST SETUP
echo ========================================
echo This command installs pytest and test-only dependencies.
echo Developer editable mode uses setuptools compat/path-based .pth for Pylance stability.
echo It is NOT required for start.bat, Script Studio, capture, bridge operation, or live Dofus control.
echo.

.venv\Scripts\python.exe tools\verify_release_integrity.py --sealed --json-output runtime\environment\release_integrity.json
if errorlevel 1 (
  echo DEV_SETUP=BLOCKED
  echo ERROR: Release metadata is internally inconsistent. Run a fresh verified release.
  exit /b 2
)

.venv\Scripts\python.exe -m pip install --disable-pip-version-check --retries 2 --timeout 45 --no-build-isolation -c "requirements\anka-dev-constraints.txt" --config-settings editable_mode=compat -e ".[dev,capture]"
set "ANKA_DEV_INSTALL_RC=%ERRORLEVEL%"
if exist "build" rmdir /s /q "build" >nul 2>nul
for /d %%D in ("src\*.egg-info") do if exist "%%~fD" rmdir /s /q "%%~fD" >nul 2>nul
if not "%ANKA_DEV_INSTALL_RC%"=="0" (
  echo DEV_DEPENDENCIES=FAILED
  if not exist "runtime\environment" mkdir "runtime\environment" >nul 2>nul
  .venv\Scripts\python.exe tools\dependency_network_probe.py --output runtime\environment\dev_dependency_network.json
  exit /b 1
)

.venv\Scripts\python.exe -m anka_platform.setup_verify dependency-baseline --baseline requirements\DEV_DEPENDENCY_BASELINE.json --output runtime\environment\dev_dependency_baseline.json
if errorlevel 1 (
  echo DEV_DEPENDENCY_BASELINE=FAILED
  exit /b 1
)

echo DEV_DEPENDENCIES=READY
echo DEV_DEPENDENCY_BASELINE=READY
.venv\Scripts\python.exe tools\runtime_install_contract.py write --root "%ANKA_PROJECT_ROOT%" --record runtime\environment\runtime_install_contract.json --mode DEVELOPER_EDITABLE_COMPAT
if errorlevel 1 (
  echo RUNTIME_INSTALL_CONTRACT=FAILED
  exit /b 1
)
echo RUNTIME_INSTALL_CONTRACT=READY
exit /b 0

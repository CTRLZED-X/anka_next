# R5.154 — Normal Launch Attestation, Capture Containment & Diagnostic I/O Hardening

## Why this release exists

R5.154 is a systemic hardening pass driven by `runtime(20261002-095010)`. The latest authoritative incident completed 5/5 fights with no terminal campaign failure, but it was a lower-level Sufokia run (observed enemy levels 16–20), not level-200 evidence. The run was strong enough to expose three remaining foundation inconsistencies before the first real level-200 pilot.

R5.154 deliberately does **not** tune FightAI or TeamStrategy and does not change physical CAST/MOVE/END_TURN execution semantics.

## Live findings

### Healthy foundation evidence

- campaign completed 5 wins / 0 losses / 0 unknowns;
- ControlAuthority remained armed until normal run completion;
- both required CRA/ENU client generations remained verified;
- capture generation mismatches: 0;
- FightAI outcomes remained correlated to fight identity;
- action-effect evidence covered every settled CAST in the exported run;
- one client-local CAST rejection was safely classified before semantic `jrj`, UI-neutralized, replanned and recovered without mission failure;
- repeated MOVE decisions are policy choices, not cell-by-cell executor clicking; confirmed same-turn movement history remains visible to FightAI;
- level-200 encounter validation correctly rejected the lower-level run.

### Foundation contradictions found

1. **Normal Launch safety proof was not preserved correctly.**
   The normal Script Studio launch path already performs passive exact-generation window/process/input readiness attestation, but the zone-200 readiness report was still treating the separate deep Windows certification campaign as mandatory launch evidence. This made the normal workflow launch successfully while the later audit claimed launch certification was not proven.

2. **Safe capture quarantine was misclassified as corruption.**
   The run had `generation_mismatch_count=0`, four positively bound flows for two required accounts, and 28 segments from an unattributed third flow deliberately quarantined before Canonical State. The old readiness rule treated any quarantine as capture failure even though quarantine is the correct containment behavior.

3. **Diagnostic file opening could block the combat request thread.**
   Slow-request stack evidence showed three >4s samples inside repeated `Path.open("a")` operations in `SessionRunStore`. Full evidence must remain durable, but reopening every JSONL/log file for every action is unnecessary hot-path latency.

4. **The bounded pilot proof depended on an optional helper rather than the actual launched SessionPlan.**
   The user’s authoritative workflow is normal `setup.bat -> start.bat -> Script Studio -> Launch`. The debug bundle must prove the actual stop contract regardless of whether `zone200_pilot.bat` was used.

## Repairs

### Per-run normal-launch attestation is now first-class evidence

Script Studio launch checkpoints preserve both:

- optional deep Windows certification snapshot; and
- passive exact-generation process/window/input attestation sampled at Launch.

The exporter writes:

- `certification/launch_windows_process_attestation.json`
- `checkpoints/launch_windows_process_attestation.json`

`analysis/zone_200_readiness.json` uses the passive launch attestation as the normal per-run safety authority whenever it is present. The separate deep certification campaign remains useful release evidence but is not required every time Dofus creates a new process generation.

A failed launch-time process attestation remains a hard blocker even if an old deep certificate exists.

### Capture quarantine is correctly interpreted

For current bundles exposing `bound_flow_count`, controlled-pilot capture integrity now requires:

- `generation_mismatch_count == 0`; and
- enough positively bound flows to cover every required account.

Unattributed traffic that stays quarantined is recorded as `capture_quarantine_contained=true` rather than treated as Canonical corruption.

Generation mismatch remains a hard blocker. Older bundles without `bound_flow_count` retain the previous stricter fallback for retrospective compatibility.

### Forensic streams reuse open handles

`SessionRunStore` opens append-only JSONL/log handles once per run, writes and flushes every row, and closes handles at run finish.

This preserves immediate incident-export visibility while removing the observed repeated file-open penalty. Late records retain a lazy-reopen fallback for historical tolerance.

### Normal Script Studio SessionPlan proves the pilot budget

Every debug bundle now exports:

`analysis/zone_200_pilot_contract.json`

The contract is derived from `studio/latest_run_session_plan.json`, not from an operator label. A first controlled pilot is considered bounded when the launched plan has:

- target wins between 3 and 5;
- max attempts between target wins and 5;
- stop on loss enabled;
- stop on unknown enabled;
- at least one active account with an explicit FightAI policy.

Encounter identity remains separate and must still be proven by `analysis/zone_200_encounters.json`.

`zone200_pilot.bat` may remain as an optional developer/preflight helper, but it is **not** the normal operator workflow.

## Correct operator workflow

Normal operation remains:

1. `setup.bat` after a fresh install/update as required;
2. `start.bat`;
3. open/select the Dofus clients and configuration in Script Studio;
4. press Launch once.

For the first real level-200 pilot, use the normal configuration surface to set:

- `target_wins`: 3–5;
- `max_attempts`: no more than 5;
- `stop_on_loss`: true;
- `stop_on_unknown`: true.

No separate BAT is required for the evidence contract.

## Zone-200 verdict

R5.154 is intended to be the first candidate whose **foundation** is ready for a controlled level-200 pilot under the normal launch workflow.

It does **not** claim generic autonomous level-200 tactical mastery. The following truth gaps remain explicit/fail-closed until evidence certifies them:

- exact tackle/lock mechanics;
- complete generic effect apply/refresh/stack/expire/remove lifecycle;
- comprehensive enemy dynamic HP/max-HP/AP/MP truth;
- complete local HP/max-HP/state/effect truth in every frame;
- summon capacity/lineage semantics;
- monster-specific mechanics not represented by certified Kernel/static knowledge;
- protocol-version drift semantics that are not explicitly decoded.

These are not reasons to keep redesigning execution/session architecture. They are the truths the controlled level-200 pilot is supposed to expose safely.

## Future GPT modification rule

After a real level-200 bundle:

- if launch/process/capture/transaction/correlation/diagnostic contracts are clean, freeze the foundation by default;
- improve FightAI/TeamStrategy, policy configuration and evidence-backed combat knowledge;
- change Kernel mechanics only when the bundle proves the missing deterministic rule and its evidence source;
- change ExecutionService/session/campaign/window/input ownership only when a foundation contract itself is proven to have failed.

See `FIGHT_POLICY_CHANGE_GUIDE.md`.

## Verification status

The source/package verification record is authoritative in `verification/R5_154_OFFLINE_VERIFICATION.md` and `PROJECT_STATUS.json`. Timed-out aggregate commands are never counted as passes; the same targets are rerun in bounded groups.

Windows/Dofus live acceptance of R5.154 remains pending until the next normal-workflow run produces launch attestation and, for the milestone goal, actual level-200 encounter evidence.

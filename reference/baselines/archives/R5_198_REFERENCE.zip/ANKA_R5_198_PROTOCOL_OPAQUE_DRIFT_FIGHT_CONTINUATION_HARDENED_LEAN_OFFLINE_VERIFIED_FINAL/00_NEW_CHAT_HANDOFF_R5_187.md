# ANKA R5.187 — New Chat Handoff

**Release:** R5.187 — Release Identity & Setup Coherence Foundation  
**Date:** 2026-10-14  
**Status:** **OFFLINE VERIFIED**

Start with `PROJECT_STATUS.json`, `R5_187_RELEASE_IDENTITY_SETUP_COHERENCE_FOUNDATION.md`, the current offline verification report, `ARCHITECTURE.md`, `DEBUGGING.md`, `WINDOWS_LIVE_RUNBOOK.md` and `LIVE_ACCEPTANCE.md`.

R5.187 exists because the delivered R5.186 Windows setup installed `anka-platform 0.1.0a134` but the packaged dependency baseline still expected `0.1.0a133`. The release checker had not bound dependency-baseline project identity to the actual platform identity.

R5.187 preserves all R5.186 runtime fixes and adds build-time, pre-install and post-install release/dependency coherence checks. Do not modify protocol/FightAI for this setup incident.

The next valid live step after offline verification is a fresh Windows extraction, Dofus closed, `setup.bat`, require all setup authorities READY, then `start.bat` and one small bounded CRA+ENU acceptance.

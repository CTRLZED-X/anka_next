# R5.187 — Release Identity & Setup Coherence Foundation

**Status:** **OFFLINE VERIFIED**

## Why this release exists

R5.186 correctly bumped the project/runtime package to `0.1.0a134`, but its packaged live and developer dependency baselines still expected `0.1.0a133`. Windows setup therefore installed the correct editable package and then rejected it as dependency drift. The offline release checker missed that exact field because it intentionally skipped `anka-platform` when validating constraint-managed third-party packages.

R5.187 fixes the failure class systemically rather than only changing one JSON value.

## Hardening

- Live and developer baselines are bound to the exact current platform version.
- Release integrity compares `pyproject.toml`, runtime `__version__`, `RELEASE_MANIFEST.json`, both dependency baselines, current release identity and bridge source provenance.
- `setup.bat` runs sealed stdlib-only release-integrity validation before project dependency installation.
- Dependency-baseline validation rejects self-inconsistent project-version metadata before installed-package comparison.
- Setup writes a release-integrity evidence record for diagnostics.
- Package-manifest sealing refuses a release-incoherent tree.
- Setup/developer scripts no longer carry stale hard-coded release-number messages.
- Bridge provenance is refreshed and hash-verified against the delivered bridge source.

The active protocol adapter remains `dofus_3_6_12_16`; R5.186 entity-resolution, control-ownership, focus recovery and diagnostic-causality repairs are unchanged.

# New Chat Handoff — R5.175

Current workspace: **ANKA R5.175 — Contracts, Failure Authority & Traceability Foundation**.

R5.175 is a structural hardening release built on R5.174.  It does not intentionally change tactical behavior or
weaken physical-input safety.  Its purpose is to make future faults and protocol upgrades contained, typed and
traceable.

## R5.175 invariants

- one project-wide failure vocabulary/metadata authority lives in `anka_platform.contracts.failure_registry`;
- a new literal production failure code that is not registered is an architecture-verification failure;
- retry policy, control fencing and diagnostic attribution do not maintain independent global string whitelists;
- `CorrelationContext` is the immutable authority identity contract for session/run/request/operation/account and
  runtime-generation correlation, with mapping compatibility during migration;
- protocol transform problems are typed (`SCHEMA_DRIFT`, `MALFORMED_PAYLOAD`, `UNSUPPORTED_SEMANTIC`,
  `ADAPTER_INTERNAL_ERROR`) and carry adapter/capability/wire-semantic evidence;
- the active adapter dispatches via the reusable version-local `ProtocolHandlerRegistry`; raw wire semantics remain
  inside the protocol package;
- a minimal crash envelope is persisted synchronously before heavy debug-bundle export;
- diagnostic bundles expose the central failure registry and per-section completeness rather than treating empty
  evidence as collector failure;
- incident shared state is published by copy and crash-envelope temp files are incident-unique;
- runtime debug evidence includes an environment/dependency fingerprint;
- R5.174 startup blocker authority, live-shaped startup regression, terminal fail-stop/disarm, structural runtime-grid
  projection and strict entity interaction proof remain mandatory;
- bridge contract remains **4**, plugin **2.2.75**; R5.175 changes Python contracts/diagnostics, not bridge ABI;
- Windows/Dofus live acceptance remains **PENDING**.

Read `R5_175_CONTRACTS_FAILURE_TRACEABILITY_FOUNDATION.md` plus
`docs/architecture/FAILURE_AUTHORITY_AND_TRACEABILITY.md`, `PROTOCOL_ADAPTER_SDK.md`, and
`CONCURRENCY_OWNERSHIP.md` before changing these boundaries.

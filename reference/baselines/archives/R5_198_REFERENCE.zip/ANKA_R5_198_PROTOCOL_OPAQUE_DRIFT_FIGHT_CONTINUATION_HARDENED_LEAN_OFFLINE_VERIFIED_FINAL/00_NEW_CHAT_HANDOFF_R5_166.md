# ANKA R5.166 — New Chat Handoff

## Current authority

Workspace checkpoint: `ANKA_PLATFORM_R5_166_ACTIVE_EXECUTION_CONTINUITY_READY_EFFICIENCY_FORENSIC_HARDENING_WINDOWS_LIVE_CANDIDATE`.

Start with this file, then read `PROJECT_STATUS.json`, `PROJECT_CONTEXT.json`, `R5_166_ACTIVE_EXECUTION_CONTINUITY_READY_EFFICIENCY_FORENSIC_HARDENING.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, `TESTING.md`, and `LIVE_ACCEPTANCE.md`.

The sealed runtime diagnostic identity remains R5.115 / platform `0.1.0a122`. The workspace Kernel remains R10J / `0.1.0a59`.

## Live evidence that created R5.166

`runtime(20261005-001617).zip` is the first current-line run to complete the requested campaign cleanly: five attempts, five confirmed wins, terminal `TARGET_WINS_REACHED`, no sixth fight, no terminal exception, no stale execution fence, and normal control disarm only after successful completion.

The run also exposed two quality defects that were masked by success:

1. Campaign continuity treated the historical `latest_action_transaction` as if it were an active unresolved transaction. An old ENU Ready `SENT` record survived deep into combat and caused many false `SERVER_TO_CLIENT_ACTION_STALL` HOLD episodes during otherwise ordinary quiet/reassembly periods.
2. `analysis/live_transport_recovery_health.json` could not reliably reconstruct the actual continuity episodes because CampaignRuntime status did not expose the retained health/history authority and the exporter counted state rows rather than recovery episodes.

CRA's first Ready interaction also produced no outbound Ready request in all five fights, while the semantic-proven later attempt succeeded. R5.166 deliberately preserves the existing independent-account Ready progression: while CRA is in an input-free semantic retry grace, ENU may still make safe Ready progress. Another CRA click remains forbidden until protocol evidence again proves request absence.

## R5.166 invariants

1. Campaign transport continuity depends on `ExecutionService.continuity_pending_status()`, not historical action telemetry.
2. Only a genuinely unresolved settlement/uncertainty/world/join transaction can activate the generic pending-action transport gate in production lanes.
3. Historical `latest_action_transaction` remains diagnostic history only; it cannot freeze a real PartyLane.
4. A short fresh TCP reassembly gap is not by itself a continuity outage. Reassembly must remain materially stale before it can trigger an early HOLD.
5. Ready recovery preserves independent-account progress: a lane waiting on a no-input semantic retry probe does not block another required account from making safe Ready progress; duplicate clicks remain evidence-gated.
6. `live_transport_recovery_health.json` reports actual episodes and retained state transitions separately and exposes lifetime episode count even when bounded history rotates.
7. Follower join settlement remains continuity-protected even while the follower is still canonically WORLD; the join ledger is the authority.
8. Ready-request-sent/ACK-pending waits are directionally continuity-protected without authorizing duplicate input.
9. Successful multi-fight accounting remains exact: a confirmed fifth win stops at five and no sixth launch is permitted.
10. Pointer motion remains the R5.165 TrajectoryLab-v2-safe correlated-knot/minimum-jerk profile; the successful run showed no motion failures and does not justify extra randomness or slower motion.

## Primary hotpaths

- `src/anka_platform/campaign/runtime.py`
- `src/anka_platform/execution/service.py`
- `src/anka_platform/party/mission.py`
- `src/anka_platform/observability/exporter.py`
- `src/anka_platform/scripting/supervisor.py`
- `tests/r5166/test_r5166_systemic_hardening.py`

## Next stage

The runtime foundation is suitable for a **controlled** level-200 pilot. Tactical/combat-truth gaps remain explicitly separate from foundation reliability. For the first level-200 pilot, use a bounded plan (`max_attempts == target_wins`, `stop_on_loss=true`, `stop_on_unknown=true`) so strategy failures cannot turn into an uncontrolled long run.

R5.166 itself still requires Windows/Dofus live acceptance because its continuity/Ready-efficiency refinements were produced after the successful R5.165 live run.

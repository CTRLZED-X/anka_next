# ANKA Platform R5.142 — Combat Action Contract, Quarantine & Turn-Liveness Hardening

Checkpoint: `ANKA_PLATFORM_R5_142_COMBAT_ACTION_CONTRACT_QUARANTINE_TURN_LIVENESS_HARDENING_WINDOWS_LIVE_CANDIDATE`

Offline verification: **PASS**. Windows/Dofus live acceptance: **PENDING**.

## Why R5.142 exists

`runtime(20260927-121856)`, fight 502, proved that CRA did not fail because FightAI had no idea what to do. FightAI selected a plausible Carreaux Destructeurs cast (spell 32459, grade 2, cell 185, enemy -2) and built a valid typed `ActionIntent`. No physical input was sent. The action became malformed only after crossing an internal software boundary: generic `dataclasses.asdict()` preserved nested tuples while `ExecutionService` expected a list-shaped wire payload. PRE_SLOT therefore returned `ACTION_INTENT_MALFORMED`.

The same live run exposed a second, older defect: quarantine identity was independently rebuilt with `repr(action_intent)`, so it did not equal `FightDecision.fingerprint()`. The same action was selected 14 unique times on the exact same semantic frame until the parent FIGHT_ACTIVE watchdog expired. The terminal `MISSION_TIMEOUT` was a wrapper symptom, not the first broken boundary.

R5.142 fixes these failure classes generically. It does not add spell 32459, cell 185, enemy -2 or fight 502 branches.

## 1. Canonical FightDecision / ActionIntent codec

Internal combat transport no longer relies on generic `dataclasses.asdict()` as a schema. `ImpactRequirement`, `ActionIntent` and `FightDecision` expose explicit encode/decode contracts with stable JSON-safe list representation, strict validation and round-trip tests.

A non-empty malformed intent fails closed as `INVALID_COMBAT_ACTION_CONTRACT`; it is never silently weakened and never reclassified as missing live Dofus evidence.

## 2. One canonical ActionKey

FightAI selection, DecisionService quarantine, controller anti-loop checks and tests now derive action identity from the same semantic `FightDecision` representation. No layer uses `repr(action_intent)` or invents its own fingerprint. This repairs both R5.141 nested-intent quarantine and the historical `None` versus `'None'` mismatch.

## 3. Recovery postcondition

Quarantine is no longer trusted as a fire-and-forget side effect. The controller remembers canonical quarantined ActionKeys for the current semantic turn. If a resolver returns an already-quarantined action again, that is `RECOVERY_INVARIANT_VIOLATION`; the action is not executed and the controller uses the certified END_TURN fallback when input causality is clean.

## 4. Local software failures are not live-state uncertainty

`INVALID_COMBAT_ACTION_CONTRACT` is classified as `INVALID_FIGHT_AI_DECISION`, not `TEMPORARY_STATE_UNCERTAINTY`. With `physical_send_state=NOT_SENT` and `semantic_cast_send_state=NOT_SENT`, recovery excludes the action immediately. Waiting for Canonical/network evidence cannot repair a Python schema mismatch.

Uncertain physical input remains a hard fence and is never hidden by this recovery.

## 5. Turn-liveness containment

The controller tracks safe recoveries during a turn. Multiple different recoverable/no-input failures are bounded; once the configured recovery budget is exhausted, the next primitive is a certified END_TURN rather than allowing the parent 30-second campaign watchdog to become the turn-control mechanism.

The bounded no-input admission-UNKNOWN refresh also counts toward turn recovery. If an unchanged-frame candidate cannot be quarantined by the resolver, ANKA schedules END_TURN instead of re-entering the same loop.

## 6. Movement uncertainty semantics

Paths that cannot be certified because exact tackle/lock mechanics are unsupported now carry `mechanic:tackle_lock` and `KERNEL_MOVE_TACKLE_UNSUPPORTED` instead of an empty generic `KERNEL_MOVE_INDETERMINATE`. R5.142 does not guess tackle/dodge outcomes; exact mechanics remain future work.

## 7. Diagnostics and forensic trust

- Fight summaries count unique `decision_id` values separately from raw trace-record count, so failure-path preservation does not double-count decisions.
- Repeated same-frame action diagnostics escalate at streaks 2/3/5/10 instead of firing only once.
- `INVALID_COMBAT_ACTION_CONTRACT` maps to `COMBAT_ACTION_CONTRACT / FIGHT_DECISION_CODEC`, preventing a later generic campaign timeout from hiding the first meaningful failure.
- Runtime release identity now exposes sealed compatibility Kernel identity separately from workspace Kernel identity. Historical R5.115 compatibility metadata is preserved; current source/runtime expectation is `0.1.0a58 / R10I`.

## 8. Remaining action-space limits

R5.142 deliberately does not invent live Range/PO or tackle mechanics. The triggering run still showed major tactical starvation: 16 Cra spell queries depended on unknown `range_bonus`, and many moves were rejected because tackle/lock semantics are not yet deterministic. Those are the next mechanics/state-completeness priorities after orchestration reliability is live-proven.

## 9. Preserved invariants

- ExecutionService is the sole physical-input authority.
- One primitive settles before the next primitive input.
- R5.141 exact rendered fight-cell interaction, ActionIntent semantics and bounded sequence planning remain intact.
- R5.140 shared CombatDecisionFrame and latest-state feasibility remain intact.
- UNKNOWN never becomes optimistic TRUE.
- Any possible/uncertain physical input remains fenced.
- No incident spell/cell/fight hardcoding is introduced.

## 10. Mandatory live acceptance

A fresh autonomous run must prove that the fight-502 family is gone:

```text
CRA turn starts
 -> FightAI produces typed decision + ActionIntent
 -> transport codec round-trips unchanged
 -> latest-state admission sees the same intent
 -> if action fails locally before input, canonical ActionKey is quarantined
 -> same ActionKey cannot reappear that turn
 -> alternative candidate is used, or certified END_TURN preserves the fight
 -> ENU/enemy/next CRA turns continue
 -> no FIGHT_ACTIVE watchdog is required to terminate a recoverable turn defect
```

Also inspect live Range/PO starvation and `KERNEL_MOVE_TACKLE_UNSUPPORTED` counts. Windows/Dofus acceptance remains pending until this behavior is proven on the real client.

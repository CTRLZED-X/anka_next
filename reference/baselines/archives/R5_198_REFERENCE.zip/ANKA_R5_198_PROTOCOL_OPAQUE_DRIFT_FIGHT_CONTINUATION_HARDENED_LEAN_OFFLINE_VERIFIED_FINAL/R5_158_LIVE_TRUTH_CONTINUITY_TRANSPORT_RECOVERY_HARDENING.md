# R5.158 — Live-Truth Continuity & Transport Recovery Hardening

## Evidence and root cause

R5.158 is driven by `runtime(20261002-225132)`, which contained two independent `MISSION_TIMEOUT` incidents.

- Fight 691 failed in `FIGHT_ACTIVE` after CRA stopped producing useful protocol messages for ~80 s and canonical events for ~83 s. CRA already had a certainly-sent CAST awaiting server confirmation. Execution correctly quarantined input, but the parent campaign watchdog continued consuming its 45 s gameplay budget and killed the mission a few seconds before the game TCP flow resumed.
- Fight 261 failed in `FIGHT_PREPARATION` at 44 s. CRA had reached ACTIVE while ENU remained canonically in PLACEMENT despite confirmed Ready. At export ENU had ~39 s of protocol/canonical silence—below the historical 45/60 s health thresholds—so the old stale gate could not fire before the shorter preparation watchdog.

The root architectural defect was therefore not simply a timeout value. **Input safety understood stale/uncertain truth; campaign continuity did not.** A recoverable transport outage was allowed to consume a gameplay-progress watchdog.

## Parent-owned continuity state

`CampaignRuntimeController` now owns `CampaignContinuityGuard`. It classifies required-lane passive health before any child World/Fight workflow is allowed to run.

Freshness-only loss becomes `CONTINUITY/HOLD`:

- no child workflow is called;
- no new physical input can be produced;
- the exact campaign/fight state stays intact;
- `CampaignEngine` freezes watchdog elapsed time;
- existing Execution uncertainty remains quarantined and durable;
- after health returns, a continuous stabilization window is required before the hold is released;
- on release, the phase-start clock is shifted by the exact held duration, preserving only the gameplay time that was consumed before the outage.

Hard blockers such as window-generation replacement, current-session capture mismatch or active protocol transform failure are **not** classified as internet. They fail explicitly as `LIVE_TRUTH_RUNTIME_HEALTH_BLOCKED`.

A continuity outage longer than the configured bounded hold fails as `LIVE_TRUTH_CONTINUITY_TIMEOUT`, not generic `MISSION_TIMEOUT`. The default hold ceiling is 600 s. This is deliberate: after a very long disconnect ANKA must not assume the same game/fight generation still exists forever.

## Early fight-only continuity suspicion

Formal Execution freshness limits remain independent and unchanged. R5.158 adds a stricter parent-only fight continuity threshold (`live_truth_continuity_suspect_seconds`, default 30 s) so a 44–45 s fight watchdog cannot expire before a 45/60 s stale-health gate.

While a fight generation is parent-owned, a required account whose protocol-message or canonical progress age exceeds this threshold is treated as a temporary continuity suspect. The parent holds progression but does not change the strict Execution health contract. World idleness is not affected by this early threshold.

## TCP reconnect generation hardening

Live capture now preserves TCP SYN/RST/FIN metadata even when those packets contain no payload. A new SYN resets the directional TCP reassembler and length-prefixed frame decoder for that 4-tuple. This prevents a reconnect that reuses an endpoint tuple with a new TCP sequence space from remaining trapped behind the old connection's expected sequence number.

Offline PCAP replay follows the same generation-reset rule, preserving the production/replay transport boundary.

## Per-flow forensic diagnostics

`LiveTransportRuntime.status()` now exposes each observed directional flow separately, including:

- connection generation/reset counters;
- segment and payload counts;
- last segment / contiguous-byte / protocol-message ages;
- expected TCP sequence;
- pending interval count and bytes;
- first missing gap size;
- duplicate/overlap counts;
- frame buffer and dropped-byte counts;
- explicit `reassembly_stalled` classification.

This closes the diagnostic ambiguity seen in the incident where account-wide segment freshness was ~1.8 s because another port remained active while the actual game flow on port 5555 had stopped progressing.

## Configuration

Under `reliability`:

```yaml
live_truth_recovery_stability_seconds: 2.0
live_truth_continuity_suspect_seconds: 30.0
live_truth_continuity_hold_timeout_seconds: 600.0
```

These values govern parent continuity only. They do not bypass ExecutionService freshness, window identity, projection, semantic settlement or uncertainty fences.

## Safety invariants

R5.158 does **not** retry uncertain physical input merely because connectivity returned. It resumes the same parent lifecycle only after authoritative live truth becomes healthy and stable. Existing uncertain CAST/MOVE/END_TURN transactions remain subject to their normal reconciliation before any new input.

POST_FIGHT settlement and world re-entry remain parent-owned and unchanged; if the fight ends during an outage, the recovered canonical edge is processed before any world action.

Windows/Dofus live acceptance remains pending until this continuity behavior is exercised on the real client.

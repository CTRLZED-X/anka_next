# New chat handoff — R5.151

## Read first

1. `R5_151_LATENCY_RECONCILIATION_FOUNDATION_READINESS_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `ARCHITECTURE.md`
5. `DEVELOPMENT_RULES.md`
6. `DEBUGGING.md`
7. `TESTING.md`

## Architecture rule

Keep these authorities separate:

- Canonical State = observed game truth.
- Kernel = deterministic legality/mechanics.
- FightAI/TeamStrategy = replaceable policy only.
- PartyCombatController/FightWorkflow/CampaignRuntimeController = orchestration, liveness and recovery ownership.
- ExecutionService = sole physical-input and short-horizon settlement authority.
- Outer workflow/campaign watchdogs = eventual terminality for a causally known transaction that is merely waiting for delayed authoritative confirmation.

A short confirmation timeout after input was definitely sent is **not** by itself permission to resend and is **not** by itself a reason to globally disarm control. Structured latency becomes passive reconciliation; contradictory or unstructured uncertainty remains fail-closed.

## Future FightAI work

`anka_platform.fight_ai` is architecture-fenced from execution, Windows/input, campaign, scripting, party orchestration and web/session control. Future policy may consume stable combat/Kernel/team/history contracts and return typed FightDecision/PlannerResult only. Do not solve strategy problems by editing ExecutionService or lifecycle code unless new evidence proves a foundation defect.

The R5.150 movement seam is verified live: later planner slices see confirmed prior movement. Remaining multi-MOVE turns are policy choices. Execution clicks the selected final destination once; it does not walk by clicking each path cell.

## Debug workflow

Start with `analysis/foundation_health.json`, campaign status/runtime, `analysis/control_authority_history.json`, transaction observations, `fight_ai/DECISION_TRACES.jsonl`, `fight_ai/CANDIDATES.jsonl`, `fight_ai/ACTION_OUTCOMES.jsonl`, and enriched execution actions. For latency incidents distinguish structured `*_CAUSALITY_PENDING` from generic uncertainty and check whether the transaction was reconciled before the outer watchdog.

## Current live status

R5.150 live evidence proved the foundation's policy-history/forensic improvements but exposed a latency-handling contradiction: delayed CAST/world confirmation could trigger incident-driven global control disarm. R5.151 repairs this offline. The required next step is one fresh R5.151 Windows/Dofus live validation. General arbitrary level-200 readiness is not yet claimed; see the R5.151 report for remaining truth gaps.

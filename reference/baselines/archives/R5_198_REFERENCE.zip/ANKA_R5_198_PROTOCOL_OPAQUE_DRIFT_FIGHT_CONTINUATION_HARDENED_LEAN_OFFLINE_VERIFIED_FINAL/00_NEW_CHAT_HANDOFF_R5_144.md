# New-chat handoff — R5.144

## Current candidate

`ANKA_PLATFORM_R5_144_FIGHT_FOUNDATION_STATE_INTERACTION_TEAM_AI_HARDENING_WINDOWS_LIVE_CANDIDATE`

Runtime sealed diagnostic identity remains R5.115 / platform `0.1.0a122`. Workspace Kernel remains `0.1.0a58` / `R10I Runtime Spell Readiness Contracts`. Do not rewrite the sealed compatibility identity.

## What R5.144 adds over R5.143

R5.143 fixed the mission-terminal failure-disposition contradiction and contains pre-input FightAI defects. R5.144 preserves that work and hardens the remaining fight-state / action-selection foundation:

- synchronized local actor IDs certify CRA/ENU as PLAYER/non-summon in the decision frame,
- bounded safe client-validation probe for unknown baseline Range and negative-only state criteria,
- probe assumptions round-trip through FightDecision and are independently reproduced at admission,
- safe-probe metadata cannot bypass ActionKey quarantine,
- Kernel-legal empty AoE centres prefer fight-walkable physical click anchors,
- ActionIntent required impacts may stay certified even when unrelated outcome projection is live-required,
- mechanics-driven offensive buff/trade-off utility activates spells such as Tirs Puissants without spell-ID hardcoding,
- Tirs Éloignés maximum-range gain and minimum-range dead-zone are scored separately,
- Sentinelle reveal effects no longer create fake focus-fire targets,
- MP steal is material control,
- CRA water/earth and ENU water build affinities are explicit profile configuration rather than source-code role constants,
- R5.143 per-spell dispositions and mission-liveness semantics remain in force.

## Do not regress these safety boundaries

- Canonical State remains semantic truth.
- Kernel remains mechanics authority.
- FightAI never sends physical input.
- ExecutionService remains the sole physical-input authority.
- Safe probe may resolve only strict UNKNOWN; it never overrides strict REJECTED.
- Never invent live AP/MP/PO or use DofusLab equipment totals as legality truth.
- Unknown summon capacity remains UNKNOWN.
- Controlled summons remain unsupported until summon-turn ownership exists end-to-end.
- Unknown state valence and unsupported tackle/lock remain fail-closed.
- Uncertain physical input/control identity remains mission-fencing even though recoverable no-request cast rejection does not.

## Supplied build intent

The supplied CRA build is Water/Earth oriented and the supplied ENU build is Water/Wisdom/MP-control oriented. R5.144 uses only the element affinity as static tactical preference. It does not import equipment totals into live state.

## Current strategy status

The lower-zone CRA+ENU foundation is ready for live validation, but this is not a claim that level-200 strategy is complete. Enemy-specific mechanics, rich state semantics, summon ownership and complex multi-turn mixed trade-offs remain future strategy work after live stability is proven.

## First files to inspect after a live run

1. `summary.json` / causal root / ControlAuthority history.
2. `fight_ai/DECISION_TRACES.jsonl` and per-spell dispositions.
3. candidate rejections for Range/state/summon/resource evidence.
4. action admission basis and probe assumptions at PRE_SLOT/PRE_TARGET.
5. ActionKey quarantine and recovery directive after any rejected cast.
6. physical-input ledger + semantic request settlement.
7. CRA/ENU team frame, target and turn handoff.

## Live acceptance

Windows/Dofus live acceptance is still **PENDING**. Do not mark the project final/proven until a fresh extracted package completes the bounded autonomous acceptance described in `LIVE_ACCEPTANCE.md` and `R5_144_FIGHT_FOUNDATION_STATE_INTERACTION_TEAM_AI_HARDENING.md`.

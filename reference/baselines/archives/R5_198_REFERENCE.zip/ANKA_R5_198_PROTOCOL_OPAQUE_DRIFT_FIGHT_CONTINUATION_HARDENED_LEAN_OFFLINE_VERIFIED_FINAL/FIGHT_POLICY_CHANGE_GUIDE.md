
## R5.167 replaceable-policy contract

Production policy selection is release-neutral through `build_default_policy_registry()`. Runtime foundation packages must not import concrete `anka_platform.fight_ai` modules. Concrete policies and FightAI telemetry are wired only at product/application composition.

The preferred active-policy signature is:

`decide(kernel, snapshot, local_actor_id, profile, *, planner_context: PlannerInvocationContext) -> FightDecision`

The policy receives: the deterministic Kernel; one immutable CanonicalSnapshot containing fight actors/state; the authoritative local actor ID; the configured combat profile; and a core-owned planner context with deadline, team objective, excluded/quarantined fingerprints, confirmed same-turn execution history and combat-truth availability. That is the supported strategy input surface; a replacement strategy should not reach into ExecutionService, campaign, party internals or Windows input for extra state.

To replace FightAI: implement the core port, register the implementation in policy composition, add deterministic policy tests, run `tools/verify_foundation_architecture.py`, then run the current release gate. Execution remains the independent legality/client-interaction/latest-state/physical-input authority, so a policy cannot bypass final admission.

# Fight Policy / Team Strategy Change Guide

This file exists so a future GPT/developer can improve combat logic without reopening runtime foundations.

## R5.155 target-interaction rule

A future policy must treat `Kernel legal` and `client executable` as different facts. Policies may reason about empty AoE anchors, but should use the shared client-interaction contract and must never bypass latest-state admission. Even if a future policy is wrong, ExecutionService independently prevents empty positively non-walkable target clicks. Do not move this UI/client rule into the deterministic Kernel.

## Default rule

Treat the foundation as frozen unless the debug bundle proves a foundation contract violation. A poor tactical choice is **not** permission to patch execution, turn ownership, Canonical State or Windows input.

## Safe strategy surface

Normal strategy work belongs in:

- `src/anka_platform/fight_ai/`
- a new implementation of core `FightPolicy` / `TeamStrategy` ports
- tactical profile/configuration and evidence-backed enemy knowledge
- tests under `tests/fight_ai/` plus a release-specific strategy regression suite

The planner receives a core-owned `PlannerInvocationContext` containing deadline, team objective, quarantined-action fingerprints, confirmed same-turn execution history and structured combat-truth availability.

## Foundation boundaries that must remain unchanged by default

Do not modify these merely to make a strategy pass:

- `src/anka_platform/execution/`
- physical Windows/input delivery
- ControlAuthority or input leases
- `PartyCombatController` transaction ownership/reconciliation
- campaign/session lifecycle
- world/fight workflow state machines
- protocol generation binding
- Canonical State truth semantics

If a change here is genuinely necessary, first prove the violated contract from one debug bundle and add a regression at the owning layer.

## One-bundle strategy iteration workflow

1. Run several bounded fights with no manual combat input.
2. Export one runtime/debug ZIP.
3. Start with:
   - `analysis/zone_200_readiness.json`
   - `analysis/foundation_health.json`
   - `fight_ai/FIGHT_SUMMARY.json`
   - `fight_ai/DECISION_TRACES.jsonl`
   - `fight_ai/ACTION_OUTCOMES.jsonl`
   - `fight_ai/ACTION_EFFECTS.jsonl`
   - `fight_ai/CANDIDATES.jsonl`
   - `fight_ai/COUNTERFACTUALS.jsonl`
   - per-account `canonical_events.jsonl`
4. Separate foundation failures from tactical mistakes.
5. For tactical mistakes, reproduce the decision from replay/trace and change only policy/team logic.
6. Add deterministic regression tests for the bad decision and desired behavior.
7. Run FightAI + core integration + current release gate before live testing.

## Evidence discipline

Never convert UNKNOWN into a convenient value. In particular, do not guess:

- enemy max HP/AP/MP,
- tackle/lock outcome,
- effect expiry/removal/stack semantics,
- summon capacity,
- unknown target-state requirements,
- unknown protocol messages.

Use `combat_truth` in `PlannerInvocationContext` to branch conservatively when information is incomplete.

## Action-effect interpretation

`ACTION_EFFECTS.jsonl` may attribute vitality only when an explicit protocol `source_actor_id` proves the local actor caused it inside the bounded post-cast window. Other observations in that window are evidence, not guaranteed causality.

## Minimum architecture checks for a new policy

- implement the core `FightPolicy` or `TeamStrategy` port;
- register it in product composition, not the core registry implementation;
- never import execution/campaign/party/scripting/web from `fight_ai`;
- return only core `FightDecision` values;
- rely on Kernel/latest-state admission for legality;
- preserve one-primitive settlement/replan behavior;
- never send physical input from a policy.

## R5.154 routing rule

When `analysis/zone_200_readiness.json` is foundation-clean and `analysis/zone_200_encounters.json` proves real level-200 encounters, foundation layers are frozen by default. Tactical quality changes belong in FightAI/TeamStrategy/policy configuration and evidence-backed combat knowledge. `analysis/zone_200_pilot_contract.json` proves whether the normal launched SessionPlan was safely bounded; it does not grant mechanic authority.

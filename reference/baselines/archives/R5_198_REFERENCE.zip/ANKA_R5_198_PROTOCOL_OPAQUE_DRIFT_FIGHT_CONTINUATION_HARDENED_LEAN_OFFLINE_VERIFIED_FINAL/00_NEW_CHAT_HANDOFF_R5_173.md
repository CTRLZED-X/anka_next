# New Chat Handoff — R5.173

Current workspace: **ANKA R5.173 — Startup / Protocol / Projection Foundation Hardening**.

R5.173 starts from R5.172 and the failed live runtime `runtime(20261012-112152)`. The visible symptom was “Launch does nothing,” but the root failure occurred before CampaignRuntime/FightAI/input: the guarded world bootstrap required a current-session canonical event even though that bootstrap exists to obtain the first canonical MapId. At the same time, projection was globally blocked by literal Unity `GraphicCells/cell::<id>` names even though the bridge had already structurally verified the complete 560-cell runtime grid.

## R5.173 invariants

- first-map bootstrap may relax **only** `CANONICAL_STATE_NOT_CURRENT_SESSION` and `CAPTURE_NO_CANONICAL_EVENTS`; schema drift, stale traffic, process mismatch, window mismatch, capture errors and other health failures still block;
- a stalled or crashing pending Launch ends as `FAILED_TO_START`, consumes authorization and disarms physical control before the final diagnostic package is exported;
- startup diagnostic projection refresh is allowed while Canonical MapId is unknown and never sends game input;
- the complete, structurally verified **runtime grid** is cell-projection authority; literal `cell::<id>` objects are optional corroborating evidence, not a naming single point of failure;
- entity actions remain strict: signed TargetEntityId, canonical CellId, live entity visual proof, nearest runtime-grid CellId and current process/map generation must agree; there is no blind entity→ground fallback;
- protocol changes stay isolated in versioned adapters/manifests; runtime diagnostics explicitly show observed client build vs certified adapter builds and explain classified traffic that produced zero canonical events;
- bridge binary identity is contract **4**, plugin **2.2.75**, projection authority `STRUCTURAL_RUNTIME_GRID_V2`; stale R5.172 bridge install records must fail setup verification.

Windows/Dofus live acceptance remains **PENDING**. If Launch still cannot converge, use the automatically generated runtime/debug package; do not manually bypass a safety fence.

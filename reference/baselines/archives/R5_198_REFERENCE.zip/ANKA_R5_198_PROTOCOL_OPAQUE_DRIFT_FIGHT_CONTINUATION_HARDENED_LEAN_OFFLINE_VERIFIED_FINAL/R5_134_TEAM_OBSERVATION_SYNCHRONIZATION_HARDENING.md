# R5.134 Team Observation Synchronization Hardening

Status: **offline candidate; Windows/Dofus live acceptance pending.**

R5.134 is a narrow pre-live hardening successor to R5.133. It does not redesign the tactical algorithms or physical-input path. It fixes one shared-state correctness flaw discovered during the final R5.133 audit: Canonical `revision` counters are local to each account reducer and are therefore not chronological values that may be compared across Cra and Enu lanes.

## Correct synchronization contract

Before tactical team planning, every required lane must agree on the same semantic fight epoch:

- exact `fight_instance_id`;
- exact map;
- `ACTIVE` phase;
- round;
- turn index;
- active actor.

If any required field is unknown or contradictory, the decision service returns `WAIT / TEAM_OBSERVATION_NOT_CONVERGED`. No tactical fallback action is authorized.

## Actor authority

Cra's local actor state is authoritative on the Cra lane. Enutrof's local actor state is authoritative on the Enutrof lane. Passive required accounts likewise own their own local actor state.

For shared/non-owned actors such as enemies, R5.134 reconciles decision-critical fields across the coherent lanes. Contradictory known values (for example different enemy cells or HP) are a convergence failure rather than an invitation to choose whichever lane has the numerically larger revision.

Cross-account revision values are retained for diagnostics only.

## Adaptive memory

`EnemyBehaviorMemory` no longer chooses a peer snapshot by maximum Canonical revision. Confirmed-cast learning uses the synchronized active-owner lane. If that authority is unavailable, cast learning is skipped rather than guessed.

## Diagnostics

Team plans now expose:

- `CANONICAL_ACCOUNT` — the active-owner lane used as the decision watermark;
- `CANONICAL_REVISION` — meaningful only inside that lane;
- `LANE_REVISIONS` — diagnostic per-account revision values with no cross-lane ordering semantics;
- `TEAM_EPOCH` — semantic synchronized fight identity/turn tuple.

## Live acceptance

The next controlled live test should prove:

1. `sufokia_farm` selects the R5.133 generic tactical stack;
2. Cra and Enu produce one shared `TEAM_EPOCH` before every tactical action;
3. ordinary lane skew produces bounded `TEAM_OBSERVATION_NOT_CONVERGED` waits, not generic independent decisions or physical input;
4. local Cra/Enu HP/cell state follows its owner lane even when the peer lane has a numerically larger revision;
5. once lanes converge, decision latency remains within the existing budget and multi-fight continuation remains intact.

R5.134 preserves all R5.133 generic-zone boundaries: controlled summons and certified guaranteed-kill sequencing remain deliberately unsupported until their evidence/ownership contracts are strong enough.

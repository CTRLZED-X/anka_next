# ANKA R5.191 — New-chat handoff

## Current authority

R5.191 is the current lean offline candidate. Start with this file, `R5_191_VERIFICATION_FAILURE_BOUNDARY_FOUNDATION.md`, `PROJECT_STATUS.json`, `docs/CURRENT.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, `WINDOWS_LIVE_RUNBOOK.md`, and `LIVE_ACCEPTANCE.md`.

## Runtime baseline inherited from R5.190

The active Dofus adapter is `dofus_3_7_10_10`. R5.190 fixed the observed fight-entry failure by separating persistent `world.map_id` from tactical `fight.map_id`, preserving same-generation join/origin world evidence, and binding fight geometry per fight generation. FightAI was not the root cause of that incident; placement was blocked earlier by lost geometry authority.

The lean package intentionally contains no raw PCAPNG/screenshots/evidence directories. Protocol adapters carry small hash-bound certification attestations; new raw evidence is supplied externally when reverse engineering is needed.

## R5.191 delta

R5.191 changes engineering verification, not combat semantics:

- release-gate surface hashes are cached safely while the complete immutable file signature is unchanged;
- additions/removals/size/mtime changes force a fresh full content SHA-256;
- critical large modules now have executable complexity ceilings;
- existing silent broad-exception sinks in critical modules are explicitly dispositioned, and any new/unreviewed sink fails verification;
- these guardrails are part of release-integrity and architecture verification.

## Next work

The next structural milestone should reduce risk inside large controllers incrementally using characterization tests and small extractions; do not rewrite `ExecutionService` wholesale. Protocol gaps such as exact current-build outbound End Turn should only change when new controlled evidence proves them.

## Live status

Offline foundation verification may be READY while Windows/Dofus live acceptance remains PENDING. The next live acceptance remains one bounded CRA+ENU fight proving:

`world -> shared fight -> geometry -> placement -> Ready -> ACTIVE -> turn owner -> FightAI -> one physical action -> authoritative settlement`

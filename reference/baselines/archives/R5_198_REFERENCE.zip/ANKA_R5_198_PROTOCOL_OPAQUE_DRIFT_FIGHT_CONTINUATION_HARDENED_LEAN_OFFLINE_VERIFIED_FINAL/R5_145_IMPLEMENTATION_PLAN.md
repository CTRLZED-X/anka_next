# R5.145 Implementation Plan

## Milestone
COMBAT CAUSAL RECONCILIATION / PLANNER EFFICIENCY / L200 READINESS HARDENING

## Source evidence
R5.144 live runtime `runtime(20260927-211946)` completed fights 519, 520 and 521, then stopped in fight 522 after a fight MOVE click was physically SENT but the target cell was not server-confirmed before the bounded confirmation window expired.

## Non-negotiable safety rule
Never convert an unresolved physical action into a speculative retry or END_TURN. Preserve the physical-input fence while passively observing authoritative Canonical State. Resume only after the old action can be causally reconciled or the fight/turn has authoritatively advanced such that no duplicate same-turn action can occur.

## Workstreams

### A. Combat action causal reconciliation (P0)
1. Introduce a structured `COMBAT_MOVE_CAUSALITY_PENDING` result for a SENT move that lacks target confirmation.
2. Persist enough uncertainty context to reconcile without new input: fight instance, actor, origin cell, target cell, basis revision and turn evidence.
3. Add passive reconciliation:
   - fresh actor cell == target -> confirmed move;
   - fresh actor cell == origin -> move rejected/not applied, safe to replan if still same turn;
   - fresh actor cell is another cell -> reconcile actual position and replan;
   - turn owner changed -> old move transaction is closed and next turn may continue;
   - fight ended/changed -> transaction is retired from terminal authoritative truth;
   - no fresh evidence -> stay in RECOVERING/WAIT with physical input fenced.
4. PartyCombatController polls reconciliation before FightAI and never calls execution while a combat transaction is unresolved.
5. Campaign disposition treats RECONCILING/WAIT as non-terminal.
6. Hard uncertainty remains fail-closed when physical send itself is UNCERTAIN.

### B. Structured failure/diagnostic contract (P0)
1. Every non-success combat result exposes failure_code, physical_send_state, causal boundary, likely owner and reconciliation evidence where relevant.
2. Ensure pending/reconciled combat action rows are present in action diagnostics.
3. Add failure attribution for combat movement causality.
4. Deduplicate UI/root problem reporting through causal/root identity where feasible without changing operator safety.

### C. Planner efficiency and movement quality (P1)
1. Score movement by marginal improvement from the current cell, not absolute safety/range fit alone.
2. Strengthen no-value movement penalty, MP reserve and distance cost when already safe.
3. Preserve hard retreat/pincer modes where movement is necessary.
4. Always evaluate spells in configured tactical priority order.
5. When the deadline is reached after material candidates exist, choose the best certified candidate rather than END_TURN.
6. Add a bounded degraded candidate path so significant AP is not discarded solely because expensive lookahead exhausted the budget.
7. Keep immediate reverse-move quarantine and expose it clearly in diagnostics.

### D. Combat truth and effect lifecycle (P1/P2)
1. Do not invent HP/AP/MP/range/summon truth.
2. Add instrumentation that distinguishes missing baseline evidence from carried-forward/partial effect evidence.
3. Bound duplicate tactical effect payload growth only where identity proves exact duplicate observations; never merge distinct effect instances heuristically.
4. Keep unsupported tackle/lock fail-closed and make it an explicit L200 readiness blocker until mechanics are certified.

### E. Enemy capability activation (P1)
1. Production `ranged_control_v1` must load the bundled capability catalog instead of `EMPTY`.
2. Preserve generic fallback for unknown static IDs.
3. Expose catalog source/profile availability in team-plan diagnostics.
4. Capability data remains advisory and can never authorize Kernel legality or physical input.

### F. L200 FightAI architecture (P2)
1. Preserve modular Kernel -> candidate -> scoring -> sequence -> decision boundaries.
2. Keep build affinity as strategy-only configuration.
3. Add/prepare multi-turn team intent fields without coupling execution to a single TacticalPolicy implementation.
4. Do not claim full L200 readiness until HP/effects/summons/tackle and enemy mechanics have live evidence.

## Release gates
- injected SENT-but-unconfirmed MOVE -> controller WAIT/RECOVERING, never immediate COMBAT_FAILED;
- fresh target/origin/other-cell/turn-change/fight-end evidence each reconciles correctly;
- physical send state UNCERTAIN still fences;
- planner movement regression: zero-marginal move loses to END_TURN when already safe and no future/formation benefit exists;
- deadline regression: existing material CAST is selected rather than END_TURN;
- production registry uses non-empty bundled enemy catalog;
- R5.140-R5.145 recent lineage passes;
- execution, party, protocol, live_state, observability, FightAI and scripting critical suites pass in bounded groups;
- final ZIP has one top-level folder, immutable manifest valid, fresh-extraction R5.145 gate passes.

# R5.169 New-Chat Handoff

## Current workspace

This workspace is **R5.169 — Multi-Account Join Protocol Completion** for Dofus 3.6.12.16.

Start with:

1. `R5_169_MULTI_ACCOUNT_JOIN_PROTOCOL_COMPLETION.md`
2. `src/anka_platform/protocol/adapters/dofus_3_6_12_16/evidence/MULTI_ACCOUNT_JOIN_INVESTIGATION.md`
3. `verification/R5_169_OFFLINE_VERIFICATION.md`
4. `verification/r5_169_live_decoding/LIVE_DECODING_REPORT.md`
5. `PROTOCOL_UPGRADE_GUIDE.md`

Active adapter: `dofus_3_6_12_16`.

## What R5.169 adds over R5.168

The simultaneous CRA+ENU PCAP closes the missing follower fight-entry path. `hnl`/`iia` establish discovery/presentation, the ENU client request carries exact fight+leader identity, and matching server fight entry closes the join boundary. The active manifest now exposes `FIGHT_JOIN` and exact `JOIN_FIGHT_REQUEST` correlation.

The capture also proves that fight-entry actor field 1 is the initiating leader, not universally the socket-local player. Pre-fight HP and local identity were hardened accordingly. Cross-account party HP (`iib`) is decoded as an absolute baseline/cross-check without becoming a second active-fight damage reducer.

Concrete AP/MP/HP/cell trajectories are replay-tested on both sockets. Tirs Eloignes is directly observed and confirms generic range-property updates, including updates for Massacrante. The final old/new semantic audit also promotes challenge lifecycle decoding (`ktm` OFFERED, `ktl` ACTIVATED, `kth` target update, `ktk` result) while keeping `jte` and unproven sequence/ack families diagnostic rather than creating competing state authorities.

## Important invariants

Do not bind local identity from follower fight-entry leader fields. Do not create canonical fight state from an outbound attack request. Do not accept Ready by wire-name presence only. Do not let party HP plus damage consequences double-apply. Do not move 3.6.12.16 wire names into FightAI/Kernel/execution policy.

Request causality is bounded and exact: join uses fight+leader, world attack uses target group, movement uses target cell, and transient identity latches are cleared at authoritative map/fight boundaries.

## Current certification status

Offline functional integration is verified. The protocol-independent required reference has 100% required event presence, semantic coverage and critical-field coverage. The live-decoding certificate remains `INSUFFICIENT_EVIDENCE` only because five requirements demand independent ORACLE-strength proof: world map, local actor, actor cell, current AP and current MP.

The project must not report full Windows/Dofus live acceptance while that certificate is not READY.

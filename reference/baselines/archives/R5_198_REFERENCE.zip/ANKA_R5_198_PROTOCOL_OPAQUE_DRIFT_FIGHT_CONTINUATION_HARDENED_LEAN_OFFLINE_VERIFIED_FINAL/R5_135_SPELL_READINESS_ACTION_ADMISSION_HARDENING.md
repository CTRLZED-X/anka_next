# R5.135 — Spell Readiness, Action Admission & Cast Causality Hardening

Checkpoint: `ANKA_PLATFORM_R5_135_SPELL_READINESS_ACTION_ADMISSION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus tactical live acceptance: **PENDING**

## Why this checkpoint exists

Fight 343 exposed a systemic combat-legality defect rather than a single-spell bug. Cra successfully cast `Tirs Éloignés` (spell 32465), whose selected Static grade has a two-own-turn recast interval, then the tactical planner selected the same spell again before a newer cooldown snapshot had arrived. The second physical interaction produced no matching outbound semantic cast request, after which execution timed out fail-closed.

The defect was at the live-evidence/Kernel boundary: a cooldown snapshot that had once been complete was still treated as current after a newer confirmed cast changed readiness. R5.135 therefore does **not** special-case spell 32465. It builds one ANKA-native readiness/admission system for cooldowns, initial cooldown, per-turn limits, per-target limits, state requirements, AP, summon-slot uncertainty, target identity, range modifiers and exact pre-input Kernel legality.

ANKA remains independent. External bot documentation and the inspected SUFOKIA project were used only as design/behavior references. No external bot runtime, API, state machine, execution path or dependency is imported.

## Authoritative flow

```text
Canonical owner-lane state
    + fight-persistent confirmed cast ledger
    + configured/verified spell grade provenance
    + Static/Kernel cast rules
    + fresh live cooldown/effect/modifier evidence
        ↓
LiveSpellReadinessService
        ↓
KernelContextAdapter
        ↓
FightActionAdmissionService
        ↓
ExecutionService PRE_SLOT admission
        ↓
slot selection
        ↓
ExecutionService PRE_TARGET admission on newest Canonical snapshot
        ↓
physical target click
        ↓
client semantic-request evidence
        ↓
server/canonical settlement
        ↓
replan
```

No new component owns physical input. `ExecutionService` remains the sole physical-input authority.

## Implemented systemic repairs

### Fight-persistent cast evidence

`CanonicalCastSnapshot` now preserves the target actor identity frozen at observation time, round, turn index and observed revision. `CanonicalFightSnapshot.confirmed_casts_this_fight` survives turn boundaries while per-turn/global counters continue to reset at their semantic boundaries.

This prevents a moving monster from erasing per-target history and prevents a valid cast from becoming unconfirmable merely because the server advanced the active actor before the next execution poll.

### Provenance-aware readiness

`LiveSpellReadinessService` combines live cooldown evidence with newer confirmed casts and Kernel/Static rules. A complete cooldown snapshot is authoritative only for evidence at or before that snapshot. If a newer cast exists, R5.135 derives the recast interval from the confirmed cast and selected verified grade until a newer cooldown snapshot supersedes it.

Initial cooldown is derived from Static only when the selected grade and fight round are known. Unknown evidence stays `UNKNOWN`; it is never converted to ready.

### Per-target usage correctness

Per-target accounting uses the actor occupying the clicked target cell in the latest Canonical state and compares it to actor identities frozen on previous cast records. If a prior same-spell cast lacks target identity, positive per-target constraints fail closed instead of under-counting usage.

### Planner grade provenance without corrupting Canonical truth

The wire cast observation deliberately does not claim a Static grade ID when the protocol only exposes a spell level. The tactical planner and action-admission path may therefore pass the configured/verified combat-profile grade as **planner/admission provenance**. This does not rewrite Canonical packet truth.

### Two-stage action admission

Every correlated production CAST is fully revalidated twice:

1. `PRE_SLOT` against the newest Canonical snapshot before selecting the spell slot;
2. `PRE_TARGET` after slot selection and immediately before clicking the target.

Both stages run readiness plus exact Kernel cast preview. REJECTED/UNKNOWN admission produces no target click. Missing grade cannot bypass admission.

### Cast rejection causality

A physical click with no server confirmation is not automatically called a client rejection. `CLIENT_CAST_REJECTED` requires two consecutive negative-evidence samples with continuous capture coverage for the exact client-process generation and no matching outbound semantic cast request. If a semantic request is observed, or coverage/generation proof is incomplete, execution remains `UNCERTAIN` and fails closed.

### Certified live spell-range modifiers

R5.135 transports only range-modifier arithmetic certified by both live evidence and verified Kernel mechanics. The fight-343 `Tirs Éloignés` modifier pair is supported. Unknown modifier arithmetic marks only the affected spell's range as unknown; it never guesses or disables unrelated spells.

### Unknown enemy movement resources

Current MP remains Canonical/Kernel `UNKNOWN` when not observed. Tactical threat scoring can use a separately certified MP capacity characteristic when available; generic advisory priors never become movement legality.

### Failure-path telemetry

The tactical decision that causes a workflow to leave ACTIVE is now persisted. Readiness/admission evidence, failure reason, physical-send state and settlement can therefore be correlated from one runtime package.

## Preserved architecture

- Canonical State remains live semantic truth.
- Lane-local revisions are never numerically ordered across accounts.
- The active actor's owner lane remains authoritative for local actor facts.
- Kernel remains deterministic mechanics/legality; it does not own packet timing or live mutable evidence.
- Tactical policy proposes actions but cannot physically execute them.
- `ExecutionService` remains the only physical-input authority.
- Uncertain semantic sends remain fail-closed.
- Controlled summons remain deferred until summon capacity and controlled-turn ownership are authoritative.

## R5.135 offline regression gates

The current working tree has passed the R5.135 release tests in bounded groups: **37/37**.

Preserved parent/system gates rerun after the hardening changes:

- R5.132 tactical parent: **36/36**
- R5.133 generic tactical parent: **78/78**
- R5.134 synchronization parent: **6/6**
- architecture + core fight: **65/65**
- live state: **30/30**
- integration: **14/14**
- changed Kernel casting/turn-history tests: **44/44**
- FightAI files: **15/15**
- execution/input files: verified in bounded batches; slow runtime-action simulations were individually executed rather than counting aggregate timeouts

Aggregate suites can exceed the command execution ceiling. Timeout-only progress is never counted as a pass.

## Required Windows/Dofus acceptance

A fresh tactical campaign must prove:

1. after a successful Tirs Éloignés cast, a same-turn/recast-interval repeat is rejected locally before target input;
2. readiness evidence reports live cooldown revision, latest confirmed cast revision and derived source;
3. Enu per-target control keeps the same monster identity after movement;
4. a state change between slot selection and target click is caught by `PRE_TARGET` admission;
5. proven local client rejection can safely quarantine/replan, while ambiguous packet evidence remains fail-closed;
6. failed tactical decisions are present in Fight Intelligence and the cast causal trace;
7. no regression occurs in Cra/Enu semantic-epoch synchronization or multi-account control ownership.

Until that controlled run succeeds, Windows/Dofus tactical live acceptance remains **PENDING**.


## Deferred / intentionally unsupported

- Unverified dynamic cooldown-modifier semantics are not inferred. Fresh authoritative live cooldown evidence supersedes static derivation; new modifier semantics require explicit certification before use.
- Summon-capacity admission remains `UNKNOWN` unless an authoritative capacity source is available; ANKA does not guess summon limits.
- Controlled summon turns remain deferred to a later actor-generic control checkpoint.

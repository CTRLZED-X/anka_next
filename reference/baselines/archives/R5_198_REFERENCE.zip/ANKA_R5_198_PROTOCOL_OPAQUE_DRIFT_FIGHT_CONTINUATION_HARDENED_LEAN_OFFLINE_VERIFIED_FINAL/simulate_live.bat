@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%CD%\src"
if "%~1"=="" (
  python tools\run_systemic_simulation.py --output runtime\systemic_simulation_report.json
) else (
  python tools\run_systemic_simulation.py --incident "%~1" --output runtime\systemic_simulation_report.json
)
exit /b %ERRORLEVEL%

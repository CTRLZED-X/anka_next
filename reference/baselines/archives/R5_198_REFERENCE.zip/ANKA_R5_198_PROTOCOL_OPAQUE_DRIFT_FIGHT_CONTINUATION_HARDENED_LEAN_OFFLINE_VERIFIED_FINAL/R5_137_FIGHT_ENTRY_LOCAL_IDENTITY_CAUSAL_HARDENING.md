# R5.137 — Fight Entry Local-Identity Causal Hardening

## Incident basis

Primary evidence: `runtime(20260926-113645)` / fight instance `435`.

Observed live sequence:

1. CRA launched the fight successfully; the exact launch receipt bound `leader_actor_id=496260153637` to fight generation `435`.
2. ENU joined successfully; the follower join was canonically confirmed.
3. Both actors were already positively present in the fight observations.
4. ENU had a canonical fight-local `local_player_actor_id`, but CRA did not. CRA's fight-local identity arrived later through `jva`, after the placement timer had already auto-started combat.
5. `SharedFightManager` therefore remained `PARTIAL` for roughly 34 seconds and the parent `FightWorkflow` never entered placement/Ready.
6. No placement or Ready physical input was sent. FightAI never ran (`decision_count=0`).
7. Once combat auto-started, identity finally converged, but preparation was now incomplete and the parent correctly stopped with `PREPARATION_AUTO_STARTED_INCOMPLETE`.

The visible symptom "Enu entered and then nothing happened" was therefore **not** an Enu join failure and **not** a tactical AI failure. The root cause was an over-strict preparation identity dependency on a late fight-local identity packet.

## Root architectural defect

R5.136 had one identity source for entry composition: `CanonicalSnapshot.local_player_actor_id`. That is the strongest source and remains authoritative, but it can arrive later than other exact causal evidence already owned by ANKA.

Waiting longer is not a valid fix because the placement timer is external and bounded. Reducing the barrier would also be unsafe because ANKA must never infer a local fighter from team order or "the only ally".

R5.137 introduces a narrow **PREPARATION-only local-fighter identity contract**.

## Identity authority contract

For one exact fight generation:

1. Canonical fight-local identity is strongest.
2. If it is still unknown, an exact launch/join receipt or canonical world-local actor may bridge PREPARATION only when that exact actor is positively present in the current fight observations.
3. A receipt from another fight generation is never reusable.
4. A causal hint for an actor not positively present is not enough.
5. If later Canonical fight-local identity disagrees with the causal identity, the state becomes `LOCAL_FIGHTER_IDENTITY_CONFLICT` and input is blocked.
6. Causal identity can authorize only entry/placement/Ready preparation. It can never authorize combat CAST/MOVE/END_TURN.

No identity is inferred from team order, actor sign, class, placement cell, or uniqueness among allies.

## Same-frame convergence

Entry composition previously could read one account multiple times during one logical barrier evaluation. R5.137 captures one immutable Canonical snapshot per account and uses that frame consistently for:

- exact fight generation,
- fight presence,
- actor positive presence,
- local identity resolution,
- placement/Ready acknowledgement,
- shared-fight composition.

This closes a mixed-revision TOCTOU class while retaining independent latest-state revalidation immediately before physical placement/Ready input.

## Parent/child lifecycle integration

The fix is wired at every relevant preparation boundary:

- `FightWorkflow` parent entry view,
- `PartyMissionController.fight_entry_barrier`,
- team placement planning,
- `place_fighter`,
- Ready probe/send,
- final Ready/active-turn barrier,
- Script Host party snapshot/entry lifecycle.

`PartyCombatController` deliberately remains on strict `SharedFightManager(...).view()` with no preparation hints.

## Execution safety

`ExecutionService` independently resolves and rechecks preparation identity immediately before input. Wrong generation, absent actor, or identity conflict returns BLOCKED with no click. The preparation hint is ignored by combat operations.

## Diagnostics hardening

The live bundle had enough evidence to diagnose the failure, but it required manual reconstruction:

- `causal_root.json` correctly identified `FIGHT_PREPARATION / PARTY_MISSION`;
- `failure_chain.jsonl` listed later `SCRIPT_EXCEPTION` wrappers first;
- the non-action `boundary_trace` was empty;
- the entry trace did not record local identity source changes within the same high-level phase.

R5.137 therefore:

- includes local actor id/source in the fight-entry trace;
- records blocker-signature changes even when phase is unchanged;
- puts the proven campaign/lifecycle root before wrapper failures in the failure chain;
- emits a lifecycle missing-boundary record for non-action causal roots.

## Hidden cases covered proactively

The regression set covers:

- delayed leader `jva` (the real fight-435 shape),
- delayed follower `jva`,
- launch receipt bridge,
- join/world-local bridge,
- missing actor positive presence,
- stale previous-generation receipt,
- later Canonical identity conflict,
- wrong-generation Ready hint,
- placement revalidation,
- combat rejection of preparation hints,
- one-snapshot-per-lane entry composition,
- diagnostic blocker changes inside one phase,
- failure-chain root prioritization.

## Preserved boundaries

R5.137 does **not** change:

- R5.136 all-spell readiness/range logic,
- Kernel mechanics/version,
- protocol semantics,
- tactical Cra/Enu policy,
- single physical-input authority,
- strict combat local-identity authority,
- outcome settlement rules.

Windows/Dofus live acceptance remains **PENDING** until a fresh R5.137 run proves placement/Ready starts before the external placement timer and the fight proceeds into tactical turns.

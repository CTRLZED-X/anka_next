# Script Roles

The scripts directory intentionally contains different execution roles. Do not treat every script as a production campaign owner.

| Script | Role |
|---|---|
| `campaign_runtime.py` | **Production / SESSION_ONLY.** Thin worker that calls parent-owned `party_campaign_step()` and renders status. It must not own campaign lifecycle. |
| `certify_party_single_fight.py` | Manual Windows/Dofus certification utility. |
| `certify_party_world_loop.py` | Manual Windows/Dofus world-loop certification utility. |
| `party_square_6_8_five_fights.py` | Legacy compatibility/regression script. Do not copy its ownership model into production runtime. |
| `square_6_8_frozen_arrow.py` | Reference/sample behavior used by regression coverage. |

Production changes should normally target the parent runtime/workflow owners in `src/anka_platform/`, not add orchestration to scripts.

"""Finite Windows certification: one synchronized four-map party loop."""

ANKA_REQUIREMENTS = {"party_mode": True}
ANKA_EXPLICIT_SUCCESS = True

ACTIVE_ACCOUNTS = ("cra", "enu")
PATROL = (190580738, 190581250, 190581251, 190580739)


def _value(raw):
    if isinstance(raw, dict) and raw.get("status") == "KNOWN":
        return raw.get("value")
    return None


def _account_map(context, account_id):
    snapshot = context.snapshot(account_id)
    if (snapshot.get("fight") or {}).get("present"):
        return None
    return _value((snapshot.get("world") or {}).get("map_id"))


def _fail(context, code, detail=""):
    message = f"CERT_WORLD_LOOP=FAIL code={code}"
    if detail:
        message += f" detail={detail}"
    context.log(message)


def main(context):
    maps = {account_id: _account_map(context, account_id) for account_id in ACTIVE_ACCOUNTS}
    if any(value is None for value in maps.values()):
        _fail(context, "MAP_UNKNOWN_OR_FIGHT_PRESENT", str(maps))
        return
    if len(set(int(value) for value in maps.values())) != 1:
        _fail(context, "PARTY_MAP_DIVERGENCE", str(maps))
        return
    start_map = int(maps[ACTIVE_ACCOUNTS[0]])
    if start_map not in PATROL:
        _fail(context, "MAP_OUTSIDE_PATROL", str(start_map))
        return

    start_index = PATROL.index(start_map)
    targets = [PATROL[(start_index + offset) % len(PATROL)] for offset in range(1, len(PATROL) + 1)]
    current = start_map
    for target in targets:
        watchdog = context.mission_phase("CERT_WORLD_TRANSITION", key=f"{current}->{target}")
        if isinstance(watchdog, dict) and str(watchdog.get("status")) == "TIMEOUT":
            _fail(context, "MISSION_TIMEOUT", f"{current}->{target}")
            return
        result = context.party_change_map(int(target))
        status = str((result or {}).get("status") or "UNKNOWN") if isinstance(result, dict) else "UNKNOWN"
        if status not in {"CONFIRMED", "SETTLED"}:
            _fail(context, status or "TRANSITION_NOT_CONFIRMED", str((result or {}).get("detail") if isinstance(result, dict) else result))
            return
        confirmed = {account_id: _account_map(context, account_id) for account_id in ACTIVE_ACCOUNTS}
        if any(value is None or int(value) != int(target) for value in confirmed.values()):
            _fail(context, "POST_TRANSITION_MAP_MISMATCH", str(confirmed))
            return
        context.log(f"CERT_WORLD_STEP=PASS from={current} to={target}")
        current = int(target)

    if current != start_map:
        _fail(context, "DID_NOT_RETURN_TO_START", f"start={start_map} current={current}")
        return
    context.log("CERT_WORLD_LOOP=PASS")
    succeed=getattr(context,"succeed",None)
    if callable(succeed):
        succeed("CERT_WORLD_LOOP_PASS")

"""Reference script: four-map patrol + conservative Frozen Arrow FightAI.

The script contains policy only. All legality/mechanics questions are delegated
through the parent runtime to the Kernel. Physical actions are requested through
typed parent operations and must be confirmed by newer canonical state.
"""

ANKA_REQUIREMENTS = {
    "spell_slots": [2],
    "controls": ["READY", "END_TURN"],
    "directions": ["RIGHT", "BOTTOM", "LEFT", "TOP"],
}

PATROL = (190580738, 190581250, 190581251, 190580739)
FROZEN_ARROW_SPELL_ID = 32435
FROZEN_ARROW_GRADE = 3


def _value(raw):
    if isinstance(raw, dict) and raw.get("status") == "KNOWN":
        return raw.get("value")
    return None


def _next_map(current):
    try:
        index = PATROL.index(int(current))
    except (ValueError, TypeError):
        return PATROL[0]
    return PATROL[(index + 1) % len(PATROL)]


def _handle_action_result(context, label, result):
    if not isinstance(result, dict):
        return "CONTINUE"
    status = str(result.get("status") or "")
    detail = str(result.get("detail") or "")
    if status == "UNCERTAIN":
        context.log(f"{label}: UNCERTAIN; execution is fenced; stop this run: {detail}")
        return "STOP"
    if status in {"BLOCKED", "CONFIRMED_UNSETTLED"}:
        context.log(f"{label}: {status}; waiting for live state: {detail}")
        context.wait(0.5)
        return "WAIT"
    return "CONTINUE"


def _candidate_group(world):
    if not world.get("monster_groups_complete"):
        return None
    candidates = []
    for group in world.get("monster_groups", []):
        size = len(group.get("member_ids") or [])
        cell = _value(group.get("cell_id"))
        if 6 <= size <= 8 and cell is not None:
            candidates.append(group)
    if not candidates:
        return None
    return sorted(candidates, key=lambda item: (len(item.get("member_ids") or []), int(item["group_id"])), reverse=True)[0]


def _enemy_targets(snapshot, local_actor_id):
    fight = snapshot.get("fight") or {}
    actors = fight.get("actors") or []
    local = next((a for a in actors if int(a.get("actor_id", -1)) == int(local_actor_id)), None)
    if local is None:
        return []
    local_team = _value(local.get("team_id"))
    if local_team is None:
        return []
    result = []
    for actor in actors:
        if int(actor.get("actor_id", -1)) == int(local_actor_id):
            continue
        if _value(actor.get("alive")) is False:
            continue
        team = _value(actor.get("team_id"))
        cell = _value(actor.get("cell_id"))
        if team is None or cell is None or team == local_team:
            continue
        result.append((int(actor["actor_id"]), int(cell)))
    return result


def main(context):
    ready_attempted_fight = None
    while True:
        snapshot = context.snapshot()
        fight = snapshot.get("fight") or {}
        if not fight.get("present"):
            ready_attempted_fight = None
            world = snapshot.get("world") or {}
            group = _candidate_group(world)
            if group is not None:
                context.log(f"launching group {group['group_id']} size={len(group.get('member_ids') or [])}")
                result = context.launch_fight(int(group["group_id"]))
                if _handle_action_result(context, "launch_fight", result) == "STOP":
                    return
                context.wait(0.2)
                continue
            current_map = _value(world.get("map_id"))
            target_map = _next_map(current_map)
            context.log(f"patrol map {current_map} -> {target_map}")
            result = context.change_map(target_map)
            if _handle_action_result(context, "change_map", result) == "STOP":
                return
            context.wait(0.2)
            continue

        fight_instance_id = fight.get("fight_instance_id")
        active_actor = _value(fight.get("active_actor_id"))
        local_actor = _value(snapshot.get("local_player_actor_id")) or _value((snapshot.get("world") or {}).get("player_actor_id"))
        if active_actor is None:
            if fight_instance_id is not None and fight_instance_id != ready_attempted_fight:
                ready_attempted_fight = fight_instance_id
                context.log("fight placement: Ready")
                result = context.ready_fight()
                if _handle_action_result(context, "ready_fight", result) == "STOP":
                    return
            context.wait(0.2)
            continue
        if local_actor is None or int(active_actor) != int(local_actor):
            context.wait(0.2)
            continue

        for _enemy_id, target_cell in _enemy_targets(snapshot, local_actor):
            analysis = context.analyze_cast(FROZEN_ARROW_SPELL_ID, FROZEN_ARROW_GRADE, int(local_actor), target_cell)
            if analysis.get("legal") is True and analysis.get("projection_complete") is True:
                context.log(f"casting Frozen Arrow on cell {target_cell}")
                result = context.cast_spell(FROZEN_ARROW_SPELL_ID, target_cell, 2)
                if _handle_action_result(context, "cast_spell", result) == "STOP":
                    return
                break
        else:
            context.log("no safe Frozen Arrow cast; ending turn")
            result = context.end_turn()
            if _handle_action_result(context, "end_turn", result) == "STOP":
                return
        context.wait(0.2)

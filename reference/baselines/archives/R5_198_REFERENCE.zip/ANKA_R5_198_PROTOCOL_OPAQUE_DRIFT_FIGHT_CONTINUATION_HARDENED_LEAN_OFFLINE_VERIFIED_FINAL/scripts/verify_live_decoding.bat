@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%\src;%CD%"
python tools\verify_live_decoding.py %*
exit /b %ERRORLEVEL%

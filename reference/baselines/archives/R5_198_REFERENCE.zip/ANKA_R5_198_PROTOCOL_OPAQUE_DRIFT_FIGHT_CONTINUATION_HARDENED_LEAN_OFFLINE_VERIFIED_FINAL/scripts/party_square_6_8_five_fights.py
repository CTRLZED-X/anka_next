"""R5.59 reference party run: Cra leader + Enutrof active controller.

This worker owns orchestration only. Canonical state, Kernel FightAI decisions,
projection, focus and physical input remain in the parent runtime. Optional
configured/open accounts are passive and end their turns immediately.
"""

from anka_platform.scripting.combat_loop import prepare_step_terminal_failure, should_prepare_fight
from anka_platform.scripting.world_search import WorldSearchWatch
from anka_platform.scripting.wait_backoff import StableWaitBackoff
from anka_platform.core.fight.lifecycle import PartyFightLifecycleState, PartyFightLifecycleTracker

ANKA_LAUNCH_MODE = "LEGACY_COMPATIBILITY"
ANKA_REQUIREMENTS = {"party_mode": True, "windows_certification": True}
# Production completion is valid only after the campaign explicitly reaches its
# configured success condition.  Any other normal return is a supervisor-level
# failure (MISSION_EXIT_WITHOUT_SUCCESS) instead of a false COMPLETED run.
ANKA_EXPLICIT_SUCCESS = True

# Setup validates these IDs from the configured world-coordinate patrol:
# [7,-12] -> [8,-12] -> [8,-11] -> [7,-11] -> return.
PATROL = (190580738, 190581250, 190581251, 190580739)
MIN_MONSTERS = 6
MAX_MONSTERS = 8
MAX_ATTEMPTS = 5
TARGET_WINS = 5
MAX_JOIN_ACQUIRE_POLLS = 120
MAX_WORLD_SEARCH_SECONDS = 180.0
WORLD_SEARCH_LOG_INTERVAL_SECONDS = 5.0


def _value(raw):
    if isinstance(raw, dict) and raw.get("status") == "KNOWN":
        return raw.get("value")
    return None


def _next_map(current, patrol=PATROL):
    patrol = tuple(int(item) for item in patrol) or PATROL
    try:
        index = patrol.index(int(current))
    except (ValueError, TypeError):
        return patrol[0]
    if len(patrol) == 1:
        return None
    return patrol[(index + 1) % len(patrol)]


def _candidate_groups(world, min_monsters=MIN_MONSTERS, max_monsters=MAX_MONSTERS):
    if not world.get("monster_groups_complete"):
        return []
    candidates = []
    for group in world.get("monster_groups") or []:
        size = len(group.get("member_ids") or [])
        cell = _value(group.get("cell_id"))
        if int(min_monsters) <= size <= int(max_monsters) and cell is not None:
            candidates.append(group)
    return sorted(
        candidates,
        key=lambda item: (len(item.get("member_ids") or []), int(item["group_id"])),
        reverse=True,
    )


def _candidate_group(world, min_monsters=MIN_MONSTERS, max_monsters=MAX_MONSTERS):
    candidates = _candidate_groups(world, min_monsters=min_monsters, max_monsters=max_monsters)
    return candidates[0] if candidates else None


def _should_try_next_launch_candidate(result):
    if not isinstance(result, dict):
        return False
    status = str(result.get("status") or "UNKNOWN")
    detail = str(result.get("detail") or "")
    # Candidate failover is safe only for an explicitly pre-send HUD rejection.
    # TARGET_MOVING / UNCERTAIN / TIMEOUT and all unknown outcomes remain fail-closed.
    return status == "BLOCKED" and "PROJECTION_UI_OCCLUDED" in detail


def _handle_action_result(context, label, result):
    if not isinstance(result, dict):
        context.log(f"{label}: INVALID_RESULT; stop run rather than advance without authority")
        _fail(context, "ACTION_INVALID_RESULT", label)
        return "STOP"
    status = str(result.get("status") or "UNKNOWN")
    detail = str(result.get("detail") or "")
    if status in {"BLOCKED", "CONFIRMED_UNSETTLED", "IN_PROGRESS", "RETRYABLE"}:
        retry = result.get("retry_allowed") if isinstance(result, dict) else None
        attempt = result.get("attempt_index") if isinstance(result, dict) else None
        retry_after = result.get("retry_after_seconds") if isinstance(result, dict) else None
        try:
            wait_seconds = max(0.05, min(10.0, float(retry_after))) if retry_after is not None else 0.35
        except (TypeError, ValueError):
            wait_seconds = 0.35
        context.log(
            f"{label}: {status}; waiting for authoritative state: {detail} "
            f"retry_allowed={retry} attempt={attempt} retry_after_s={retry_after}"
        )
        context.wait(wait_seconds)
        return "WAIT"
    if status in {"CONFIRMED", "SETTLED", "SENT"}:
        return "CONTINUE"
    context.log(f"{label}: {status}; stop run rather than risk advancing without authority: {detail}")
    failure_code = str(result.get("failure_code") or f"ACTION_{status}")
    _fail(context, failure_code, f"{label}: {detail}")
    return "STOP"


def _fail(context, code, detail=""):
    """Fail structurally when supported, while preserving lightweight tests."""
    fail = getattr(context, "fail", None)
    if callable(fail):
        fail(str(code), str(detail or ""))
    return None


def _launch_context_from_result(result):
    if not isinstance(result,dict):
        return None
    required = (
        "fight_instance_id",
        "origin_world_entity_id",
        "launch_map_id",
        "launch_cell_id",
    )
    if any(result.get(key) is None for key in required):
        return None
    # This is an authoritative launch receipt produced only after launch
    # confirmation.  Preserve every correlation field; do not rediscover known
    # fight identity from later asynchronous snapshots.
    receipt = {
        "fight_instance_id": int(result["fight_instance_id"]),
        "origin_world_entity_id": int(result["origin_world_entity_id"]),
        "launch_map_id": int(result["launch_map_id"]),
        "launch_cell_id": int(result["launch_cell_id"]),
        "confirmed_revision": int(result.get("confirmed_revision") or 0),
    }
    if result.get("leader_actor_id") is not None:
        receipt["leader_actor_id"] = int(result["leader_actor_id"])
    return receipt



def _terminal_stop_reason(outcome, *, wins, attempts):
    if outcome == "LOSS":
        return "LOSS_CONFIRMED"
    if outcome != "WIN":
        return "OUTCOME_UNKNOWN"
    if wins >= TARGET_WINS:
        return "TARGET_WINS_REACHED"
    if attempts >= MAX_ATTEMPTS:
        return "MAX_ATTEMPTS_REACHED"
    return None






def _join_acquire_poll_limit(context):
    """Keep the historical 120-poll floor but scale with the frozen mission watchdog.

    The parent mission timeout is SessionPlan-derived from party size and action
    timings.  A fixed worker-side ceiling must never fire earlier than that
    authoritative budget for larger configured parties.
    """
    try:
        status = context.mission_status() or {}
        timeout = float(status.get("phase_timeout_seconds") or 0.0)
    except Exception:
        timeout = 0.0
    # Join wait loops sleep up to 0.5 s. Add a small scheduling margin so the
    # parent watchdog, not a legacy local constant, remains the final authority.
    scaled = int(timeout / 0.5) + 10 if timeout > 0 else 0
    return max(MAX_JOIN_ACQUIRE_POLLS, scaled)


def _required_join_targets(party, required_accounts=("cra", "enu")):
    required = set(party.get("required_accounts") or required_accounts)
    present = set(party.get("present_accounts") or ())
    return tuple(sorted(required - present))


def _join_discovery_matches(snapshot, reference):
    fight = (snapshot or {}).get("fight") or {}
    expected = (
        ("discovered_fight_instance_id", "fight_instance_id"),
        ("discovered_leader_actor_id", "leader_actor_id"),
        ("discovered_origin_world_entity_id", "origin_world_entity_id"),
    )
    for field, key in expected:
        if key not in reference:
            return False
        observed = _value(fight.get(field))
        if observed is None or int(observed) != int(reference[key]):
            return False
    # Scripts own correlation only.  Target readiness (protocol presentation or
    # exact live bridge proof) is owned by ExecutionService so missing ijr does
    # not prevent the safe bridge recovery path from being attempted.
    return True


def _manual_join_wait(context, party):
    missing = _required_join_targets(party)
    if not missing:
        return False
    fight_instance_id = party.get("fight_instance_id")
    for account_id in missing:
        context.log(
            f"FIVE_FIGHT_JOIN_MANUAL_REQUIRED account={account_id} "
            f"fight_instance_id={fight_instance_id}"
        )
    context.wait(0.25)
    return True


def _fight_reference(leader_snapshot, leader_account_id="cra", launch_context=None):
    fight = leader_snapshot.get("fight") or {}
    world = leader_snapshot.get("world") or {}
    launch_context = launch_context or {}
    instance = launch_context.get("fight_instance_id")
    if instance is None:
        instance = fight.get("fight_instance_id")
    leader_actor_id = launch_context.get("leader_actor_id")
    if leader_actor_id is None:
        leader_actor_id = _value(leader_snapshot.get("local_player_actor_id")) or _value(world.get("player_actor_id"))
    origin_world_entity_id = launch_context.get("origin_world_entity_id")
    if origin_world_entity_id is None:
        origin_world_entity_id = _value(fight.get("origin_world_entity_id"))
    if None in (instance, leader_actor_id, origin_world_entity_id):
        return None
    reference = {
        "leader_account_id": str(leader_account_id),
        "fight_instance_id": int(instance),
        "leader_actor_id": int(leader_actor_id),
        "origin_world_entity_id": int(origin_world_entity_id),
    }
    fight_id = _value(fight.get("fight_id"))
    map_id = _value(fight.get("map_id"))
    if fight_id is not None:
        reference["fight_id"] = int(fight_id)
    if map_id is not None:
        reference["map_id"] = int(map_id)
    if launch_context.get("launch_map_id") is not None and launch_context.get("launch_cell_id") is not None:
        reference["launch_map_id"] = int(launch_context["launch_map_id"])
        reference["launch_cell_id"] = int(launch_context["launch_cell_id"])
    if launch_context.get("confirmed_revision") is not None:
        reference["launch_confirmed_revision"] = int(launch_context["confirmed_revision"])
    return reference


def _snapshot_required(context, required_accounts):
    return {account_id: context.snapshot(account_id) for account_id in required_accounts}


def _complete_party_fight_evidence(snapshots, required_accounts):
    """Return a complete same-generation party snapshot for outcome evidence.

    This evidence lifecycle is intentionally separate from the edge snapshot used
    to notice fight->world transitions.  It is only a worker-side fallback; the
    parent host can upgrade it to CanonicalStateStore's durable terminal snapshot.
    """
    if set(snapshots) != set(required_accounts):
        return None, None
    fight_ids = set()
    for account_id in required_accounts:
        fight = (snapshots.get(account_id) or {}).get("fight") or {}
        if not bool(fight.get("present")) or fight.get("fight_instance_id") is None:
            return None, None
        fight_ids.add(int(fight["fight_instance_id"]))
    if len(fight_ids) != 1:
        return None, None
    return dict(snapshots), next(iter(fight_ids))


def _world_workflow_inspect(context):
    """Return shared world lifecycle intent when the parent runtime provides it.

    Legacy/manual worker contexts may not expose the R5.96 world workflow RPC;
    those contexts continue through the proven local compatibility path below.
    """
    inspect = getattr(context, "party_world_workflow_inspect", None)
    return inspect() if callable(inspect) else None


def _world_workflow_step(context):
    """Advance one parent-owned world lifecycle step when available.

    The worker no longer needs to reconstruct which map/convergence action the
    parent WorldWorkflow intended.  Older/manual contexts keep the compatibility
    path and return ``None`` here.
    """
    step = getattr(context, "party_world_workflow_step", None)
    return step() if callable(step) else None


def _world_workflow_tick(context):
    """Take one world observation/action decision without worker-side TOCTOU.

    Production contexts expose ``party_world_workflow_step``.  Calling it once
    gives the parent one coherent inspect->decision->action tick.  Pure inspect
    is retained only for legacy/manual harnesses that cannot execute the shared
    parent workflow.
    """
    step = getattr(context, "party_world_workflow_step", None)
    if callable(step):
        return step(), True
    return _world_workflow_inspect(context), False


def _fight_workflow_step(context, current_by_account, party):
    """Use the shared FightWorkflow when available; preserve legacy test/manual contexts.

    Production ScriptRuntimeHost exposes ``party_fight_workflow_step``.  Older
    developer contexts predate that RPC, so this adapter reproduces the proven
    preparation-vs-combat guard only when the workflow façade is unavailable.
    """
    workflow_step = getattr(context, "party_fight_workflow_step", None)
    if callable(workflow_step):
        return workflow_step()

    active_actor_id = party.get("active_actor_id") if isinstance(party, dict) else None
    if should_prepare_fight(current_by_account, active_actor_id=active_actor_id):
        action = context.party_prepare_fight_step()
        stage = str((action or {}).get("stage") or "ENTRY_BARRIER")
        state = {
            "CHALLENGE": "CHALLENGE",
            "CHALLENGE_BLOCKED": "CHALLENGE",
            "PLACEMENT": "PLACEMENT",
            "PLACEMENT_BLOCKED": "PLACEMENT",
            "READY_SEND": "READY",
            "READY_BARRIER": "READY",
            "READY_BLOCKED": "READY",
            "COMPLETE": "READY",
        }.get(stage, "ENTRY_BARRIER")
        return {"state": state, "action": action, "reason": "LEGACY_PREPARATION_COMPAT"}

    combat_step = getattr(context, "party_combat_step", None)
    if not callable(combat_step):
        # Minimal legacy harnesses used to model ACTIVE turn-handoff gaps with
        # snapshots only.  Preserve the safe WAIT semantics instead of re-entering
        # preparation or inventing an action.
        action = {"status": "WAIT", "reason": "TURN_HANDOFF_ACTIVE_PHASE"}
    else:
        action = combat_step()
    return {
        "state": "ACTIVE",
        "action": action,
        "reason": str((action or {}).get("reason") or "LEGACY_COMBAT_COMPAT"),
        "progress_token": (action or {}).get("progress_token") if isinstance(action, dict) else None,
    }


def _session_party(context):
    provider = getattr(context, "session_plan", None)
    plan = provider() if callable(provider) else {}
    plan = plan or {}
    required = tuple(str(item) for item in (plan.get("required_account_ids") or ("cra", "enu")))
    active = tuple(str(item) for item in (plan.get("active_account_ids") or required))
    leader = str(plan.get("leader_account_id") or (required[0] if required else "cra"))
    if leader not in required:
        required = (leader,) + tuple(item for item in required if item != leader)
    patrol = tuple(int(item) for item in (plan.get("route_map_ids") or PATROL))
    min_monsters = int(plan.get("target_min_monsters") if plan.get("target_min_monsters") is not None else MIN_MONSTERS)
    max_monsters = int(plan.get("target_max_monsters") if plan.get("target_max_monsters") is not None else MAX_MONSTERS)
    return leader, required, active, patrol, min_monsters, max_monsters


def _mission_gate(context, phase, *, key=None):
    result = context.mission_phase(phase, key=key)
    if isinstance(result, dict) and str(result.get("status")) == "TIMEOUT":
        context.log(
            f"mission watchdog timeout phase={result.get('phase')} "
            f"elapsed={result.get('elapsed_seconds')}s code={result.get('failure_code')}"
        )
        _fail(
            context,
            str(result.get("failure_code") or "MISSION_TIMEOUT"),
            f"phase={result.get('phase')} key={result.get('key')} elapsed={result.get('elapsed_seconds')}s",
        )
        return False
    return True


def _mission_stopped(context):
    status = context.mission_status()
    reason = (status or {}).get("stop_reason") if isinstance(status, dict) else None
    if reason:
        budget = (status or {}).get("budget") or {}
        wins = budget.get("wins")
        attempts = budget.get("attempts")
        context.log(
            f"run stopped: {reason} "
            f"wins={wins}/{budget.get('target_wins')} "
            f"attempts={attempts}/{budget.get('max_attempts')}"
        )
        if reason == "TARGET_WINS_REACHED":
            context.log(f"FIVE_FIGHT_RUN=PASS wins={wins} attempts={attempts}")
            succeed = getattr(context, "succeed", None)
            if callable(succeed):
                succeed("TARGET_WINS_REACHED")
        else:
            context.log(f"FIVE_FIGHT_RUN=FAIL reason={reason} wins={wins} attempts={attempts}")
            _fail(context, reason, f"wins={wins} attempts={attempts}")
        return True
    return False


def _parent_step_wait_seconds(action, default=0.15):
    action = action if isinstance(action, dict) else {}
    retry_after = action.get("retry_after_seconds")
    try:
        return max(0.05, min(2.0, float(retry_after))) if retry_after is not None else float(default)
    except (TypeError, ValueError):
        return float(default)


def _run_parent_campaign(context):
    """Run the production campaign as a thin worker over one parent owner.

    The worker intentionally does not snapshot fights, reconstruct launch/join
    identity, resolve outcomes, choose world targets, or own watchdog state. It
    only renders typed parent results into logs and cooperative waits.
    """
    while True:
        if _mission_stopped(context):
            return

        raw = context.party_campaign_step()
        if not isinstance(raw, dict):
            _fail(context, "CAMPAIGN_RUNTIME_INVALID_RESULT", str(raw))
            return
        domain = str(raw.get("domain") or "UNKNOWN")
        state = str(raw.get("state") or "UNKNOWN")
        action = raw.get("action") if isinstance(raw.get("action"), dict) else {}
        reason = str(raw.get("reason") or action.get("reason") or "")

        if domain == "CAMPAIGN":
            if state == "STOPPED":
                # Parent runtime is the terminal authority.  This branch is a
                # defensive race-safe path for callers that poll once more after
                # the budget became terminal between worker status checks.
                _mission_stopped(context)
                return
            if state == "FAILED":
                code = str(action.get("failure_code") or reason or "CAMPAIGN_RUNTIME_FAILED")
                context.log(
                    f"CAMPAIGN_RUNTIME_FAIL code={code} boundary={action.get('first_missing_boundary')} "
                    f"owner={action.get('likely_owner')} detail={action.get('detail') or reason}"
                )
                _fail(context, code, str(action.get("detail") or reason))
                return
            if state == "OUTCOME_COMMITTED":
                budget = action.get("budget") or {}
                context.log(
                    f"PARENT_OUTCOME_COMMITTED fight_instance_id={action.get('fight_instance_id')} "
                    f"outcome={action.get('outcome')} reason={action.get('outcome_reason')} "
                    f"wins={budget.get('wins')}/{budget.get('target_wins')} "
                    f"attempts={budget.get('attempts')}/{budget.get('max_attempts')} "
                    f"evidence_complete={action.get('evidence_complete')}"
                )
                if str(action.get("status") or "") == "STOP":
                    # Render the parent-owned budget/stop reason through the
                    # existing explicit-success contract; never continue into
                    # another world action after a terminal budget decision.
                    _mission_stopped(context)
                    return
                context.wait(0.05)
                continue
            _fail(context, "CAMPAIGN_RUNTIME_UNKNOWN_STATE", f"state={state} reason={reason}")
            return

        if domain == "WORLD":
            if state == "FAILED":
                code = str(action.get("failure_code") or reason or "WORLD_WORKFLOW_FAILED")
                _fail(context, code, str(action.get("detail") or reason))
                return
            status = str(action.get("status") or "WAIT")
            context.log(
                f"PARENT_WORLD state={state} status={status} account={raw.get('account_id') or action.get('account_id')} "
                f"reason={reason} failure_code={action.get('failure_code')} "
                f"target_map={action.get('target_map_id')} target_group={action.get('selected_group_id') or action.get('target_group_id')}"
            )
            if status in {"FAILED", "UNCERTAIN", "TIMEOUT", "INVALID"}:
                # Defensive only: CampaignRuntimeController normally promotes
                # these before they reach the worker.
                code = str(action.get("failure_code") or f"WORLD_ACTION_{status}")
                _fail(context, code, str(action.get("detail") or reason))
                return
            context.wait(_parent_step_wait_seconds(action, 0.12))
            continue

        if domain == "FIGHT":
            if state == "FAILED":
                code = str(
                    action.get("failure_code")
                    or action.get("join_failure_code")
                    or reason
                    or "FIGHT_WORKFLOW_FAILED"
                )
                _fail(context, code, str(action.get("detail") or reason))
                return
            status = str(action.get("status") or "WAIT")
            if state in {"ENTRY_BARRIER", "CHALLENGE", "PLACEMENT", "READY"}:
                context.log(
                    f"PARENT_FIGHT_PREP state={state} status={status} stage={action.get('stage')} "
                    f"account={action.get('account_id')} failure_code={action.get('failure_code')} detail={action.get('detail')}"
                )
            elif state == "JOINING":
                context.log(
                    f"PARENT_FIGHT_JOIN status={status} account={action.get('account_id')} "
                    f"failure_code={action.get('failure_code') or action.get('join_failure_code')} "
                    f"semantic_request={action.get('semantic_request_observed')} detail={action.get('detail')}"
                )
            elif state == "ACTIVE":
                decision = action.get("decision") or {}
                nested = action.get("action_result") or {}
                context.log(
                    f"PARENT_COMBAT status={status} account={action.get('account_id')} reason={action.get('reason')} "
                    f"progress={action.get('progress_token') or raw.get('progress_token')} "
                    f"decision={decision.get('kind')} spell={decision.get('spell_id')} "
                    f"target={decision.get('target_cell_id')} action_status={nested.get('status')}"
                )
            else:
                context.log(f"PARENT_FIGHT state={state} status={status} reason={reason}")

            if status in {"FAILED", "BLOCKED_STALLED"}:
                code = str(action.get("failure_code") or f"FIGHT_{status}")
                _fail(context, code, str(action.get("detail") or action.get("reason") or reason))
                return
            context.wait(_parent_step_wait_seconds(action, 0.10 if state == "ACTIVE" else 0.15))
            continue

        _fail(context, "CAMPAIGN_RUNTIME_UNKNOWN_DOMAIN", f"domain={domain} state={state}")
        return


def main(context):
    reset = context.reset_mission()
    if not isinstance(reset, dict) or str(reset.get("status")) != "RESET":
        context.log("FIVE_FIGHT_RUN=FAIL reason=MISSION_RESET_FAILED")
        _fail(context, "MISSION_RESET_FAILED", str(reset))
        return
    context.log("FIVE_FIGHT_MISSION_RESET=PASS")

    leader_account, required_accounts, active_accounts, patrol_map_ids, target_min_monsters, target_max_monsters = _session_party(context)
    context.log(
        f"SESSION_PARTY leader={leader_account} required={list(required_accounts)} "
        f"active={list(active_accounts)} patrol={list(patrol_map_ids)} target_range={target_min_monsters}-{target_max_monsters}"
    )

    # Production R5.117 path: one parent-owned campaign state machine.
    # The historical worker loop remains below only for legacy/manual contexts
    # that do not expose the new parent campaign RPC.
    if callable(getattr(context, "party_campaign_step", None)):
        context.log("CAMPAIGN_RUNTIME_OWNER=PARENT")
        _run_parent_campaign(context)
        return

    # ``previous_by_account`` is edge-detection state only.  Outcome evidence has
    # a separate lifecycle so preserving a pre-action edge cannot also freeze
    # campaign accounting on stale actor/death facts.
    previous_by_account = None
    terminal_evidence_by_account = None
    terminal_evidence_fight_key = None
    join_wait_key = None
    join_wait_polls = 0
    join_wait_last_status = "NOT_STARTED"
    join_wait_last_code = ""
    join_wait_last_detail = ""
    join_prompted = set()
    launch_context = None
    world_search = WorldSearchWatch(
        timeout_seconds=MAX_WORLD_SEARCH_SECONDS,
        log_interval_seconds=WORLD_SEARCH_LOG_INTERVAL_SECONDS,
    )
    turn_wait = StableWaitBackoff()
    fight_lifecycle = PartyFightLifecycleTracker(required_accounts, leader_account)
    last_lifecycle_signature = None

    while True:
        if _mission_stopped(context):
            return

        current_by_account = _snapshot_required(context, required_accounts)
        leader_snapshot = current_by_account[leader_account]
        fight = leader_snapshot.get("fight") or {}
        current_fighting = any((snap.get("fight") or {}).get("present") for snap in current_by_account.values())
        complete_evidence, complete_evidence_fight_key = _complete_party_fight_evidence(
            current_by_account, required_accounts
        )
        if complete_evidence is not None:
            if terminal_evidence_fight_key != complete_evidence_fight_key:
                terminal_evidence_by_account = None
            terminal_evidence_by_account = complete_evidence
            terminal_evidence_fight_key = complete_evidence_fight_key

        # A partial party fight is not self-describing.  It can be the normal
        # entry window (leader entered, follower must join) or the normal exit
        # window (one account already returned to world).  R5.109 treated every
        # partial view as post-fight and therefore skipped ENU join entirely.
        # Classify it using the exact run-local fight-generation history.
        lifecycle = fight_lifecycle.observe(current_by_account)
        lifecycle_signature = (
            lifecycle.state.value, lifecycle.fight_instance_id,
            lifecycle.present_accounts, lifecycle.missing_accounts,
        )
        if lifecycle_signature != last_lifecycle_signature:
            context.log(
                f"FIGHT_LIFECYCLE state={lifecycle.state.value} "
                f"fight_instance_id={lifecycle.fight_instance_id} "
                f"expected={lifecycle.expected_fight_instance_id} "
                f"present={list(lifecycle.present_accounts)} "
                f"missing={list(lifecycle.missing_accounts)} "
                f"converged_before={lifecycle.converged_before} reason={lifecycle.reason}"
            )
            last_lifecycle_signature = lifecycle_signature

        if lifecycle.state is PartyFightLifecycleState.CONFLICT:
            context.log(f"FIVE_FIGHT_RUN=FAIL reason=FIGHT_LIFECYCLE_CONFLICT detail={lifecycle.reason}")
            _fail(context, "FIGHT_LIFECYCLE_CONFLICT", lifecycle.reason)
            return
        if lifecycle.state is PartyFightLifecycleState.AMBIGUOUS_PARTIAL:
            context.log(f"FIVE_FIGHT_RUN=FAIL reason=FIGHT_LIFECYCLE_AMBIGUOUS detail={lifecycle.reason}")
            _fail(context, "FIGHT_LIFECYCLE_AMBIGUOUS", lifecycle.reason)
            return
        if lifecycle.state is PartyFightLifecycleState.EXIT_SETTLING:
            settlement_key = str(lifecycle.fight_instance_id or ",".join(lifecycle.present_accounts))
            if not _mission_gate(context, "POST_FIGHT", key=settlement_key):
                return
            wait_state = turn_wait.observe("post_fight:" + settlement_key)
            if wait_state.get("log_due"):
                context.log(
                    f"POST_FIGHT_SETTLEMENT_WAIT fighting={list(lifecycle.present_accounts)} "
                    f"required={list(required_accounts)} fight_instance_id={lifecycle.fight_instance_id} "
                    f"poll={wait_state.get('count')} delay_s={wait_state.get('delay_seconds')}"
                )
            context.wait(float(wait_state.get("delay_seconds") or 0.15))
            continue

        # Resolve terminal state from BOTH required account views. The parent
        # coordinator owns team semantics and the RunBudget owns campaign state.
        if previous_by_account is not None:
            previous_fighting = any((snap.get("fight") or {}).get("present") for snap in previous_by_account.values())
            if previous_fighting and not current_fighting:
                outcome_basis = terminal_evidence_by_account or previous_by_account
                terminal = context.party_fight_outcome(outcome_basis)
                outcome = str((terminal or {}).get("outcome") or "UNKNOWN")
                evidence_meta = (terminal or {}).get("terminal_evidence") if isinstance(terminal, dict) else None
                context.log(
                    f"FIGHT_TERMINAL_EVIDENCE outcome={outcome} reason={(terminal or {}).get('reason') if isinstance(terminal, dict) else None} "
                    f"fight_instance_id={terminal_evidence_fight_key} accounts={evidence_meta}"
                )
                recorded = context.record_fight_outcome(outcome)
                budget = (recorded or {}).get("budget") or {}
                context.log(
                    f"fight terminal outcome={outcome} "
                    f"wins={budget.get('wins')}/{budget.get('target_wins')} "
                    f"attempts={budget.get('attempts')}/{budget.get('max_attempts')}"
                )
                fight_lifecycle.note_terminal(lifecycle.fight_instance_id)
                launch_context = None
                join_wait_key = None
                join_wait_polls = 0
                join_prompted.clear()
                terminal_evidence_by_account = None
                terminal_evidence_fight_key = None
                if str((recorded or {}).get("status")) == "STOP":
                    # Reuse the authoritative mission status formatter so the
                    # Windows campaign runner receives the required PASS/FAIL
                    # terminal marker (especially the 5th confirmed win).
                    _mission_stopped(context)
                    return

        if not current_fighting:
            turn_wait.reset()
            search = world_search.observe()
            previous_by_account = current_by_account
            world = leader_snapshot.get("world") or {}
            current_map = _value(world.get("map_id"))
            if search.get("started_now"):
                context.log(f"WORLD_SEARCH_START map_id={current_map} timeout_s={MAX_WORLD_SEARCH_SECONDS}")
            if search.get("log_due"):
                context.log(
                    f"WORLD_SEARCH_PROGRESS elapsed_s={search.get('elapsed_seconds')} "
                    f"map_id={current_map} roster_complete={bool(world.get('monster_groups_complete'))} "
                    f"eligible_groups={len(_candidate_groups(world, target_min_monsters, target_max_monsters))}"
                )
            if search.get("timed_out"):
                # Production world orchestration treats an empty eligible spawn
                # set as a valid waiting condition: restrictive monster filters
                # can legitimately need multiple respawn cycles. Legacy/manual
                # contexts keep their historical bounded fail-safe.
                if callable(getattr(context, "party_world_workflow_inspect", None)):
                    context.log(
                        f"WORLD_SEARCH_STILL_WAITING elapsed_s={search.get('elapsed_seconds')} "
                        f"map_id={current_map} target_range={target_min_monsters}-{target_max_monsters}"
                    )
                    world_search.reset()
                else:
                    context.log(
                        f"FIVE_FIGHT_RUN=FAIL reason=WORLD_SEARCH_TIMEOUT "
                        f"elapsed_s={search.get('elapsed_seconds')} map_id={current_map}"
                    )
                    _fail(context, "WORLD_SEARCH_TIMEOUT", f"elapsed_s={search.get('elapsed_seconds')} map_id={current_map}")
                    return

            # Production takes exactly one parent-owned world step per worker
            # iteration.  Do not inspect in one RPC and execute in a second RPC:
            # canonical/projection state can advance between those calls and make
            # the worker reason about a stale target or transition.  The old pure
            # inspect path is retained only for legacy/manual contexts that do not
            # expose the parent step RPC.
            world_intent, parent_world_step = _world_workflow_tick(context)
            if world_intent is not None:
                world_state = str((world_intent or {}).get("state") or "UNKNOWN")
                world_action = dict((world_intent or {}).get("action") or {})

                if parent_world_step:
                    # ``WorldWorkflow.advance`` owns inspect + decision + at most
                    # one parent mission action atomically from the worker's point
                    # of view.  The worker only interprets its typed disposition.
                    if world_state == "FAILED":
                        failure_code = str(world_action.get("failure_code") or "WORLD_WORKFLOW_FAILED")
                        detail = str((world_intent or {}).get("reason") or world_action.get("reason") or world_action.get("detail") or "")
                        context.log(f"FIVE_FIGHT_RUN=FAIL reason={failure_code} detail={detail}")
                        _fail(context, failure_code, detail)
                        return
                    if world_state in {"WORLD_SETTLING", "OBSERVE_MAP", "WAIT_RESPAWN"}:
                        context.log(f"WORLD_WORKFLOW_WAIT state={world_state} reason={(world_intent or {}).get('reason')}")
                        context.wait(0.3)
                        continue
                    if world_state == "PARTY_CONVERGENCE":
                        target_map = world_action.get("target_map_id")
                        if not _mission_gate(context, "WORLD_CONVERGENCE", key=target_map or current_map):
                            return
                        gate = _handle_action_result(context, "party:converge_world", world_action)
                        if gate == "STOP":
                            return
                        continue
                    if world_state == "TRANSITION":
                        target_map = world_action.get("target_map_id")
                        if not _mission_gate(context, "WORLD_TRANSITION", key=f"{current_map}->{target_map}"):
                            return
                        gate = _handle_action_result(context, "party:change_map", world_action)
                        if gate == "STOP":
                            return
                        continue
                    if world_state == "ACQUIRE_TARGET":
                        target_group_id = world_action.get("selected_group_id") or world_action.get("launch_group_id")
                        if target_group_id is not None and not _mission_gate(context, "LAUNCHING_FIGHT", key=int(target_group_id)):
                            return
                        gate = _handle_action_result(context, f"{leader_account}:world_target_acquire", world_action)
                        if gate == "STOP":
                            return
                        if gate == "CONTINUE":
                            confirmed_launch = _launch_context_from_result(world_action)
                            if confirmed_launch is None:
                                context.log("FIVE_FIGHT_RUN=FAIL reason=MISSING_FINAL_LAUNCH_CONTEXT")
                                _fail(context, "MISSING_FINAL_LAUNCH_CONTEXT", str(world_action))
                                return
                            launch_context = confirmed_launch
                            fight_lifecycle.note_launch(int(confirmed_launch["fight_instance_id"]))
                        continue
                    if world_state == "FIGHT_HANDOFF":
                        context.wait(0.1)
                        continue
                    # SELECT_TARGET/SEARCH_TARGET are inspect-only states. Seeing
                    # one after a production ``advance`` means the parent runtime
                    # could not own the corresponding action; fail closed rather
                    # than falling back to a second worker-side decision path.
                    if world_state in {"SELECT_TARGET", "SEARCH_TARGET"}:
                        context.log(f"FIVE_FIGHT_RUN=FAIL reason=WORLD_PARENT_ACTION_UNAVAILABLE state={world_state}")
                        _fail(context, "WORLD_PARENT_ACTION_UNAVAILABLE", world_state)
                        return
                    context.log(f"FIVE_FIGHT_RUN=FAIL reason=WORLD_WORKFLOW_UNKNOWN_STATE state={world_state}")
                    _fail(context, "WORLD_WORKFLOW_UNKNOWN_STATE", world_state)
                    return

                # Legacy/manual compatibility below consumes pure inspect state
                # and may invoke old worker-side action helpers. Production does
                # not enter this branch.
                if world_state == "FAILED":
                    failure_code = str(world_action.get("failure_code") or "WORLD_WORKFLOW_FAILED")
                    detail = str((world_intent or {}).get("reason") or world_action.get("reason") or "")
                    context.log(f"FIVE_FIGHT_RUN=FAIL reason={failure_code} detail={detail}")
                    _fail(context, failure_code, detail)
                    return
                if world_state == "PARTY_CONVERGENCE":
                    target_map = world_action.get("leader_map_id")
                    if target_map is None:
                        context.log("FIVE_FIGHT_RUN=FAIL reason=WORLD_CONVERGENCE_TARGET_UNKNOWN")
                        _fail(context, "WORLD_CONVERGENCE_TARGET_UNKNOWN")
                        return
                    parent_step = _world_workflow_step(context)
                    convergence = (
                        dict((parent_step or {}).get("action") or {})
                        if parent_step is not None
                        else context.party_change_map(int(target_map))
                    )
                    convergence_gate = _handle_action_result(context, "party:converge_world", convergence)
                    if convergence_gate == "STOP":
                        return
                    context.wait(0.2 if convergence_gate == "CONTINUE" else 0.35)
                    continue
                if world_state in {"WORLD_SETTLING", "OBSERVE_MAP", "WAIT_RESPAWN"}:
                    context.log(f"WORLD_WORKFLOW_WAIT state={world_state} reason={(world_intent or {}).get('reason')}")
                    context.wait(0.3)
                    continue
                if world_state == "SELECT_TARGET":
                    candidates = list(world_action.get("candidate_groups") or [])
                    target_group_id = world_action.get("target_group_id")
                    if target_group_id is None and candidates:
                        target_group_id = candidates[0].get("group_id")
                    if target_group_id is None:
                        context.log("FIVE_FIGHT_RUN=FAIL reason=WORLD_TARGET_UNKNOWN")
                        _fail(context, "WORLD_TARGET_UNKNOWN")
                        return
                    if not _mission_gate(context, "LAUNCHING_FIGHT", key=int(target_group_id)):
                        return
                    context.log(
                        f"Leader {leader_account} acquiring world target group={int(target_group_id)} "
                        f"candidate_count={len(candidates) or 1}"
                    )
                    parent_step = _world_workflow_step(context)
                    if parent_step is not None:
                        result = dict((parent_step or {}).get("action") or {})
                        gate = _handle_action_result(context, f"{leader_account}:world_target_acquire", result)
                        if gate == "STOP":
                            return
                        if gate == "CONTINUE":
                            confirmed_launch = _launch_context_from_result(result)
                            if confirmed_launch is None:
                                context.log("FIVE_FIGHT_RUN=FAIL reason=MISSING_FINAL_LAUNCH_CONTEXT")
                                _fail(context, "MISSING_FINAL_LAUNCH_CONTEXT", str(result))
                                return
                            launch_context = confirmed_launch
                            fight_lifecycle.note_launch(int(confirmed_launch["fight_instance_id"]))
                        context.wait(0.2)
                        continue

                    # Legacy/manual compatibility path when the parent world
                    # workflow step RPC is unavailable. Production never owns
                    # target-candidate iteration in the worker anymore.
                    if not candidates:
                        candidates = [{
                            "group_id": int(target_group_id),
                            "cell_id": world_action.get("target_cell_id"),
                            "monster_count": int(world_action.get("monster_count") or 0),
                        }]
                    for group in candidates:
                        result = context.launch_fight(int(group["group_id"]), account_id=leader_account)
                        if _should_try_next_launch_candidate(result):
                            continue
                        gate = _handle_action_result(context, f"{leader_account}:launch_fight", result)
                        if gate == "STOP":
                            return
                        if gate == "CONTINUE":
                            confirmed_launch = _launch_context_from_result(result)
                            if confirmed_launch is None:
                                _fail(context, "MISSING_FINAL_LAUNCH_CONTEXT", str(result))
                                return
                            launch_context = confirmed_launch
                            fight_lifecycle.note_launch(int(confirmed_launch["fight_instance_id"]))
                        break
                    context.wait(0.2)
                    continue
                if world_state in {"SEARCH_TARGET", "TRANSITION"}:
                    target_map = world_action.get("next_map_id") or world_action.get("target_map_id")
                    if current_map is None or target_map is None:
                        context.log("FIVE_FIGHT_RUN=FAIL reason=WORLD_TRANSITION_TARGET_UNKNOWN")
                        _fail(context, "WORLD_TRANSITION_TARGET_UNKNOWN")
                        return
                    if not _mission_gate(context, "WORLD_TRANSITION", key=f"{current_map}->{target_map}"):
                        return
                    context.log(f"party patrol {current_map} -> {target_map}")
                    parent_step = _world_workflow_step(context)
                    result = (
                        dict((parent_step or {}).get("action") or {})
                        if parent_step is not None
                        else context.party_change_map(int(target_map))
                    )
                    if _handle_action_result(context, "party:change_map", result) == "STOP":
                        return
                    context.wait(0.2)
                    continue
                if world_state == "FIGHT_HANDOFF":
                    context.wait(0.1)
                    continue
                context.log(f"FIVE_FIGHT_RUN=FAIL reason=WORLD_WORKFLOW_UNKNOWN_STATE state={world_state}")
                _fail(context, "WORLD_WORKFLOW_UNKNOWN_STATE", world_state)
                return

            # Legacy/manual compatibility path when the parent world workflow RPC
            # is unavailable. Production ScriptRuntimeHost always takes the path above.
            # A partial previous transition must converge every required account
            # before any new monster group is selected/launched. Calling the parent
            # synchronizer with the leader's current MapId is a no-op for accounts
            # already there and moves only followers that are behind.
            if current_map is not None:
                convergence = context.party_change_map(current_map)
                convergence_gate = _handle_action_result(context, "party:converge_world", convergence)
                if convergence_gate == "STOP":
                    return
                if convergence_gate == "WAIT":
                    continue

            if not world.get("monster_groups_complete"):
                context.log(f"WORLD_ROSTER_INCOMPLETE map_id={current_map}; waiting for authoritative group snapshot")
                context.wait(0.3)
                continue

            candidates = _candidate_groups(world, target_min_monsters, target_max_monsters)
            if candidates:
                for group in candidates:
                    if not _mission_gate(context, "LAUNCHING_FIGHT", key=int(group["group_id"])):
                        return
                    size = int(group.get("monster_count") or len(group.get("member_ids") or []))
                    context.log(f"Leader {leader_account} launching group {group['group_id']} size={size}")
                    result = context.launch_fight(int(group["group_id"]), account_id=leader_account)
                    if _should_try_next_launch_candidate(result):
                        context.log(
                            f"Leader launch candidate {int(group['group_id'])} blocked by HUD before input; "
                            f"trying next eligible {target_min_monsters}-{target_max_monsters} group"
                        )
                        continue
                    gate = _handle_action_result(context, f"{leader_account}:launch_fight", result)
                    if gate == "STOP":
                        return
                    if gate == "CONTINUE":
                        confirmed_launch=_launch_context_from_result(result)
                        if confirmed_launch is None:
                            context.log("FIVE_FIGHT_RUN=FAIL reason=MISSING_FINAL_LAUNCH_CONTEXT")
                            _fail(context, "MISSING_FINAL_LAUNCH_CONTEXT", str(result))
                            return
                        launch_context = confirmed_launch
                        fight_lifecycle.note_launch(int(confirmed_launch["fight_instance_id"]))
                    break
                context.wait(0.2)
                continue

            if current_map is None:
                context.log(f"Leader {leader_account} world MapId unknown; waiting")
                context.wait(0.3)
                continue
            target_map = _next_map(current_map, patrol_map_ids)
            if target_map is None:
                context.log(f"WORLD_SINGLE_MAP_WAIT_RESPAWN map_id={current_map}")
                context.wait(0.3)
                continue
            if not _mission_gate(context, "WORLD_TRANSITION", key=f"{current_map}->{target_map}"):
                return
            context.log(f"party patrol {current_map} -> {target_map}")
            result = context.party_change_map(target_map)
            if _handle_action_result(context, "party:change_map", result) == "STOP":
                return
            context.wait(0.2)
            continue

        world_search.reset()
        party = context.party_snapshot()
        fight_key = party.get("fight_instance_id") or fight.get("fight_instance_id") or "unknown"
        if party.get("status") == "CONFLICT":
            context.log(f"shared fight conflict: {party.get('detail')}")
            _fail(context, "SHARED_FIGHT_CONFLICT", str(party.get("detail") or ""))
            return

        join_targets = _required_join_targets(party, required_accounts)
        parent_fight_workflow = callable(getattr(context, "party_fight_workflow_step", None))
        if join_targets and not parent_fight_workflow:
            reference = _fight_reference(leader_snapshot, leader_account, launch_context)
            if reference is None:
                previous_by_account = current_by_account
                context.log("fight reference incomplete; waiting before join")
                # The authoritative launch receipt should make this path rare,
                # but keep it bounded by the parent watchdog if upstream evidence
                # is genuinely incomplete.
                fallback_join_key = str((launch_context or {}).get("fight_instance_id") or fight_key)
                if not _mission_gate(context, "FIGHT_JOINING", key=fallback_join_key):
                    return
                context.wait(0.2)
                continue
            current_join_key = str(reference["fight_instance_id"])
            if current_join_key != join_wait_key:
                join_wait_key = current_join_key
                join_wait_polls = 0
                join_wait_last_status = "NOT_STARTED"
                join_wait_last_code = ""
                join_wait_last_detail = ""
                context.mission_phase("FIGHT_JOINING", key=current_join_key)
            if not _mission_gate(context, "FIGHT_JOINING", key=current_join_key):
                return
            join_wait_polls += 1
            join_poll_limit = _join_acquire_poll_limit(context)
            if join_wait_polls > join_poll_limit:
                context.log(
                    f"FIVE_FIGHT_RUN=FAIL reason=JOIN_ACQUIRE_TIMEOUT fight_instance_id={current_join_key} "
                    f"polls={join_wait_polls - 1} last_status={join_wait_last_status} "
                    f"last_code={join_wait_last_code} last_detail={join_wait_last_detail}"
                )
                _fail(
                    context,
                    "JOIN_ACQUIRE_TIMEOUT",
                    f"fight_instance_id={current_join_key} last_status={join_wait_last_status} last_code={join_wait_last_code} last_detail={join_wait_last_detail}",
                )
                return
            undiscovered = [
                account_id for account_id in join_targets
                if not _join_discovery_matches(current_by_account.get(account_id) or {}, reference)
            ]
            if undiscovered:
                join_wait_last_status = "DISCOVERY_WAIT"
                join_wait_last_code = "DISCOVERY_NOT_READY"
                join_wait_last_detail = f"accounts={','.join(undiscovered)}"
                if join_wait_polls == 1 or join_wait_polls % 10 == 0:
                    context.log(
                        f"FIVE_FIGHT_JOIN_ACQUIRE_WAIT fight_instance_id={current_join_key} "
                        f"poll={join_wait_polls}/{join_poll_limit} status={join_wait_last_status} "
                        f"failure_code={join_wait_last_code} detail={join_wait_last_detail}"
                    )
                previous_by_account = current_by_account
                context.wait(0.5)
                continue

            blocked_wait = False
            for account_id in join_targets:
                result = context.join_fight(reference, account_id=account_id)
                status = str((result or {}).get("status") or "UNKNOWN") if isinstance(result, dict) else "INVALID"
                detail = (result or {}).get('detail') if isinstance(result, dict) else result
                failure_code = str((result or {}).get("join_failure_code") or "") if isinstance(result, dict) else ""
                retry_allowed = bool((result or {}).get("retry_allowed")) if isinstance(result, dict) else False
                join_method = str((result or {}).get('join_method') or 'UNKNOWN') if isinstance(result, dict) else 'UNKNOWN'
                if status == "CONFIRMED":
                    fight_lifecycle.note_join_confirmed(account_id, int(reference["fight_instance_id"]))
                    context.log(
                        f"FIVE_FIGHT_JOIN_AUTO_CONFIRMED account={account_id} "
                        f"fight_instance_id={current_join_key} method={join_method}"
                    )
                    continue
                if status == "WINDOW_CLOSED" or failure_code == "WINDOW_CLOSED":
                    context.log(
                        f"FIVE_FIGHT_RUN=FAIL reason=JOIN_WINDOW_CLOSED account={account_id} "
                        f"fight_instance_id={current_join_key} detail={detail}"
                    )
                    _fail(context, "JOIN_WINDOW_CLOSED", f"account={account_id} fight_instance_id={current_join_key} detail={detail}")
                    return
                if status == "JOIN_SETTLING":
                    join_wait_last_status = status
                    join_wait_last_code = failure_code or "JOIN_SETTLING"
                    join_wait_last_detail = str(detail or "")
                    context.log(
                        f"FIVE_FIGHT_JOIN_SETTLING account={account_id} fight_instance_id={current_join_key} "
                        f"poll={join_wait_polls}/{join_poll_limit} method={join_method} "
                        f"request_observed={(result or {}).get('semantic_request_observed') if isinstance(result, dict) else None} "
                        f"transition={(result or {}).get('context_transition_map_id') if isinstance(result, dict) else None} "
                        f"detail={join_wait_last_detail}"
                    )
                    blocked_wait = True
                    break
                if status in {"TARGET_MISS", "NO_INTERACTION", "UNCERTAIN", "TIMEOUT", "INVALID"}:
                    context.log(
                        f"FIVE_FIGHT_RUN=FAIL reason=JOIN_{status} account={account_id} "
                        f"fight_instance_id={current_join_key} detail={detail}"
                    )
                    _fail(context, f"JOIN_{status}", f"account={account_id} fight_instance_id={current_join_key} detail={detail}")
                    return
                if status in {"RETRYABLE", "BLOCKED"} and retry_allowed:
                    join_wait_last_status = status
                    join_wait_last_code = failure_code or "WAITING_TARGET_PROOF"
                    join_wait_last_detail = str(detail or "")
                    context.log(
                        f"FIVE_FIGHT_JOIN_ACQUIRE_WAIT account={account_id} fight_instance_id={current_join_key} "
                        f"poll={join_wait_polls}/{join_poll_limit} status={status} "
                        f"failure_code={join_wait_last_code} method={join_method} "
                        f"readiness={(result or {}).get('join_readiness_source') if isinstance(result, dict) else None} "
                        f"presentation={(result or {}).get('protocol_presentation_ready') if isinstance(result, dict) else None} "
                        f"detail={join_wait_last_detail}"
                    )
                    blocked_wait = True
                    break
                context.log(
                    f"FIVE_FIGHT_RUN=FAIL reason=JOIN_{status} account={account_id} "
                    f"fight_instance_id={current_join_key} detail={detail}"
                )
                _fail(context, f"JOIN_{status}", f"account={account_id} fight_instance_id={current_join_key} detail={detail}")
                return

            if blocked_wait:
                previous_by_account = current_by_account
                context.wait(0.5)
                continue
            previous_by_account = current_by_account
            continue
        join_wait_key = None
        join_wait_polls = 0
        join_wait_last_status = "NOT_STARTED"
        join_wait_last_code = ""
        join_wait_last_detail = ""

        workflow = _fight_workflow_step(context, current_by_account, party)
        workflow_state = str((workflow or {}).get("state") or "UNKNOWN")
        step_result = (workflow or {}).get("action") or {}

        if workflow_state in {"ENTRY_BARRIER", "CHALLENGE", "PLACEMENT", "READY"}:
            result = step_result
            barrier = (result or {}).get("fight_entry_barrier") if isinstance(result, dict) else None
            if isinstance(barrier, dict):
                context.log(
                    f"FIGHT_ENTRY_BARRIER status={barrier.get('status')} "
                    f"fight_instance_id={barrier.get('fight_instance_id')} accounts={barrier.get('accounts')}"
                )
            preparation = (result or {}).get("preparation") if isinstance(result, dict) else None
            if isinstance(preparation, dict):
                context.log(
                    f"FIGHT_PREP_TRACE fight_instance_id={preparation.get('fight_instance_id')} "
                    f"stage={preparation.get('stage')} age_ms={preparation.get('age_ms')} "
                    f"timings={preparation.get('stage_timings_ms')} "
                    f"ready_attempts={preparation.get('ready_attempts')}"
                )
                for action in list(preparation.get("step_actions") or []):
                    context.log(
                        f"FIGHT_PREP_ACTION account={action.get('account_id')} "
                        f"action={action.get('action')} status={action.get('status')} "
                        f"attempt={action.get('attempt_index')} "
                        f"semantic_request={action.get('semantic_request_observed')} "
                        f"retry_allowed={action.get('retry_allowed')} "
                        f"failure_code={action.get('failure_code')} detail={action.get('detail')}"
                    )
            prep_status = str((result or {}).get("status") or "UNKNOWN")
            terminal_prepare_failure = prepare_step_terminal_failure(result)
            if terminal_prepare_failure is not None:
                context.log(
                    f"FIVE_FIGHT_RUN=FAIL reason={terminal_prepare_failure} "
                    f"stage={(result or {}).get('stage')} detail={(result or {}).get('detail')}"
                )
                _fail(context, terminal_prepare_failure, f"stage={(result or {}).get('stage')} detail={(result or {}).get('detail')}")
                return
            # Keep the script watchdog as an outer guard only.  The mission
            # controller is evaluated first so semantic preparation failures
            # (for example READY_ACK_TIMEOUT) are exported instead of being
            # overwritten by a generic MISSION_TIMEOUT/PLACEMENT symptom.
            if not _mission_gate(context, "FIGHT_PREPARATION", key=fight_key):
                return
            if prep_status not in {"IN_PROGRESS", "CONFIRMED", "BLOCKED"}:
                context.log(f"party:fight_workflow preparation: {prep_status}; stop fail-closed")
                _fail(context, "PREPARATION_INVALID_STATUS", prep_status)
                return
            previous_by_account = _snapshot_required(context, required_accounts)
            context.wait(0.15)
            continue

        if workflow_state == "JOINING":
            if not _mission_gate(context, "FIGHT_JOINING", key=fight_key):
                return
            join_status = str((step_result or {}).get("status") or "UNKNOWN")
            context.log(
                f"PARENT_FIGHT_JOIN state={workflow_state} status={join_status} "
                f"account={(step_result or {}).get('account_id')} "
                f"failure_code={(step_result or {}).get('failure_code') or (step_result or {}).get('join_failure_code')} "
                f"attempt={(step_result or {}).get('physical_join_attempt')} "
                f"semantic_request={(step_result or {}).get('semantic_request_observed')} "
                f"detail={(step_result or {}).get('detail')}"
            )
            previous_by_account = current_by_account
            retry_after = (step_result or {}).get("retry_after_seconds")
            try:
                join_wait = max(0.1, min(2.0, float(retry_after))) if retry_after is not None else 0.2
            except (TypeError, ValueError):
                join_wait = 0.2
            context.wait(join_wait)
            continue
        if workflow_state in {"TERMINAL_DETECTED", "NO_FIGHT"}:
            previous_by_account = current_by_account
            context.wait(0.1)
            continue
        if workflow_state == "FAILED":
            context.log(f"FIVE_FIGHT_RUN=FAIL reason=FIGHT_WORKFLOW_FAILED detail={(workflow or {}).get('reason')}")
            _fail(context, "FIGHT_WORKFLOW_FAILED", str((workflow or {}).get("reason") or ""))
            return
        if workflow_state != "ACTIVE":
            context.log(f"FIGHT_WORKFLOW_WAIT state={workflow_state} reason={(workflow or {}).get('reason')}")
            previous_by_account = current_by_account
            context.wait(0.15)
            continue

        combat = step_result
        combat_status = str((combat or {}).get("status") or "UNKNOWN")
        progress_token = str((combat or {}).get("progress_token") or (workflow or {}).get("progress_token") or f"{fight_key}:waiting")
        if not _mission_gate(context, "FIGHT_ACTIVE", key=progress_token):
            return
        decision = (combat or {}).get("decision") or {}
        action_result = (combat or {}).get("action_result") or {}
        if combat_status == "WAIT":
            if str((combat or {}).get("reason") or "") == "TURN_HANDOFF_ACTIVE_PHASE":
                context.log(f"TURN_HANDOFF_WAIT fight_instance_id={fight_key} progress={progress_token}")
            wait_state = turn_wait.observe(f"combat:{(combat or {}).get('reason')}:{progress_token}")
            if wait_state.get("log_due"):
                context.log(
                    f"COMBAT_WAIT account={(combat or {}).get('account_id')} "
                    f"reason={(combat or {}).get('reason')} progress={progress_token} "
                    f"poll={wait_state.get('count')} delay_s={wait_state.get('delay_seconds')}"
                )
            previous_by_account = current_by_account
            context.wait(float(wait_state.get("delay_seconds") or 0.15))
            continue
        turn_wait.reset()
        context.log(
            f"COMBAT_STEP status={combat_status} account={(combat or {}).get('account_id')} "
            f"reason={(combat or {}).get('reason')} progress={progress_token} "
            f"decision={decision.get('kind')} spell={decision.get('spell_id')} "
            f"target={decision.get('target_cell_id')} action_status={action_result.get('status')}"
        )
        if combat_status in {"FAILED", "BLOCKED", "BLOCKED_STALLED"}:
            context.log(
                f"FIVE_FIGHT_RUN=FAIL reason=COMBAT_{combat_status} "
                f"detail={(combat or {}).get('reason')} account={(combat or {}).get('account_id')}"
            )
            _fail(context, f"COMBAT_{combat_status}", f"detail={(combat or {}).get('reason')} account={(combat or {}).get('account_id')}")
            return
        # Preserve the pre-action fighting snapshot. A terminal CAST/END_TURN can
        # settle the fight before this RPC returns; re-snapshotting here would
        # erase the fighting->world edge and undercount the campaign.
        previous_by_account = current_by_account
        context.wait(0.15)
        continue

"""Finite Windows certification: exactly one Cra+Enu controlled fight.

The follower join is attempted only after exact R4 discovery identifies
Curseni's fight. ExecutionService then focuses Sosoking, resolves the follower-
verified JOIN_FIGHT control associated with that exact protocol-discovered fight, and waits for
exact placement/fight confirmation. Ground-cell fallback is forbidden; the live Unity
fight-entry object is secondary diagnostics/fallback only when calibration is unavailable. Once both required accounts observe the fight, the existing party
Ready barrier, FightAI, projection and execution authorities are used.
"""

from anka_platform.scripting.combat_loop import prepare_step_terminal_failure, should_prepare_fight
from anka_platform.scripting.world_search import WorldSearchWatch
from anka_platform.scripting.wait_backoff import StableWaitBackoff
from anka_platform.core.fight.lifecycle import PartyFightLifecycleState, PartyFightLifecycleTracker

ANKA_REQUIREMENTS = {"party_mode": True}
ANKA_EXPLICIT_SUCCESS = True

CRA_ACCOUNT = "cra"
ENU_ACCOUNT = "enu"
ACTIVE_ACCOUNTS = (CRA_ACCOUNT, ENU_ACCOUNT)
PATROL = (190580738, 190581250, 190581251, 190580739)
MIN_MONSTERS = 6
MAX_MONSTERS = 8
MAX_FIGHTS = 1
MAX_WORLD_SEARCH_STEPS = 8
MAX_JOIN_ACQUIRE_POLLS = 120
MAX_WORLD_SEARCH_SECONDS = 120.0
WORLD_SEARCH_LOG_INTERVAL_SECONDS = 5.0


def _value(raw):
    if isinstance(raw, dict) and raw.get("status") == "KNOWN":
        return raw.get("value")
    return None


def _candidate_groups(world):
    if not world.get("monster_groups_complete"):
        return []
    candidates = []
    for group in world.get("monster_groups") or []:
        size = len(group.get("member_ids") or [])
        cell = _value(group.get("cell_id"))
        if MIN_MONSTERS <= size <= MAX_MONSTERS and cell is not None:
            candidates.append(group)
    return sorted(
        candidates,
        key=lambda item: (len(item.get("member_ids") or []), int(item["group_id"])),
        reverse=True,
    )


def _candidate_group(world):
    candidates = _candidate_groups(world)
    return candidates[0] if candidates else None


def _should_try_next_launch_candidate(result):
    if not isinstance(result, dict):
        return False
    status = str(result.get("status") or "UNKNOWN")
    detail = str(result.get("detail") or "")
    # Candidate failover is safe only for an explicitly pre-send HUD rejection.
    # TARGET_MOVING / UNCERTAIN / TIMEOUT and all unknown outcomes remain fail-closed.
    return status == "BLOCKED" and "PROJECTION_UI_OCCLUDED" in detail


def _next_map(current):
    try: index=PATROL.index(int(current))
    except (TypeError,ValueError): return None
    return PATROL[(index+1)%len(PATROL)]


def _required_join_targets(party):
    required=set(party.get("required_accounts") or ACTIVE_ACCOUNTS)
    present=set(party.get("present_accounts") or ())
    return tuple(sorted(required-present))


def _join_discovery_matches(snapshot, reference):
    fight = (snapshot or {}).get("fight") or {}
    expected = (
        ("discovered_fight_instance_id", "fight_instance_id"),
        ("discovered_leader_actor_id", "leader_actor_id"),
        ("discovered_origin_world_entity_id", "origin_world_entity_id"),
    )
    for field, key in expected:
        if key not in reference:
            return False
        observed = _value(fight.get(field))
        if observed is None or int(observed) != int(reference[key]):
            return False
    # Scripts own correlation only.  Target readiness (protocol presentation or
    # exact live bridge proof) is owned by ExecutionService so missing ijr does
    # not prevent the safe bridge recovery path from being attempted.
    return True


def _fight_reference(cra_snapshot, launch_context=None):
    fight=cra_snapshot.get("fight") or {}
    world=cra_snapshot.get("world") or {}
    launch_context=launch_context or {}
    instance=launch_context.get("fight_instance_id")
    if instance is None:
        instance=fight.get("fight_instance_id")
    leader=(
        launch_context.get("leader_actor_id")
        or
        _value(cra_snapshot.get("local_player_actor_id"))
        or _value(world.get("player_actor_id"))
        or _value(fight.get("initiating_actor_id"))
    )
    origin=launch_context.get("origin_world_entity_id")
    if origin is None:
        origin=_value(fight.get("origin_world_entity_id"))
    if None in (instance,leader,origin):
        return None
    reference={
        "fight_instance_id":int(instance),
        "leader_actor_id":int(leader),
        "origin_world_entity_id":int(origin),
    }
    if launch_context.get("launch_map_id") is not None and launch_context.get("launch_cell_id") is not None:
        reference["launch_map_id"]=int(launch_context["launch_map_id"])
        reference["launch_cell_id"]=int(launch_context["launch_cell_id"])
    return reference



def _finish(context,outcome):
    outcome=str(outcome or "UNKNOWN")
    if outcome == "WIN":
        context.log("CERT_SINGLE_FIGHT=PASS outcome=WIN")
        succeed=getattr(context,"succeed",None)
        if callable(succeed):
            succeed("CERT_SINGLE_FIGHT_WIN")
        return True
    context.log(f"CERT_SINGLE_FIGHT=FAIL outcome={outcome}")
    return False


def _handle_action_result(context,label,result):
    if not isinstance(result,dict):
        context.log(f"CERT_SINGLE_FIGHT=FAIL code={label}:INVALID_RESULT")
        return "STOP"
    status=str(result.get("status") or "UNKNOWN")
    detail=str(result.get("detail") or "")
    if status in {"BLOCKED","CONFIRMED_UNSETTLED"}:
        context.wait(0.25)
        return "WAIT"
    if status in {"CONFIRMED","SETTLED","SENT"}:
        return "CONTINUE"
    context.log(f"CERT_SINGLE_FIGHT=FAIL code={label}:{status} detail={detail}")
    return "STOP"


def _launch_context_from_result(result):
    if not isinstance(result,dict):
        return None
    required=("fight_instance_id","origin_world_entity_id","launch_map_id","launch_cell_id")
    if any(result.get(key) is None for key in required):
        return None
    receipt={
        "fight_instance_id":int(result["fight_instance_id"]),
        "origin_world_entity_id":int(result["origin_world_entity_id"]),
        "launch_map_id":int(result["launch_map_id"]),
        "launch_cell_id":int(result["launch_cell_id"]),
        "confirmed_revision":int(result.get("confirmed_revision") or 0),
    }
    if result.get("leader_actor_id") is not None:
        receipt["leader_actor_id"]=int(result["leader_actor_id"])
    return receipt



def _snapshots(context):
    return {account_id:context.snapshot(account_id) for account_id in ACTIVE_ACCOUNTS}


def main(context):
    previous=None
    fight_started=False
    world_steps=0
    join_acquire_polls=0
    join_acquire_last_status="NOT_STARTED"
    join_acquire_last_code=""
    join_acquire_last_detail=""
    launch_context=None
    world_search=WorldSearchWatch(
        timeout_seconds=MAX_WORLD_SEARCH_SECONDS,
        log_interval_seconds=WORLD_SEARCH_LOG_INTERVAL_SECONDS,
    )
    turn_wait = StableWaitBackoff()
    fight_lifecycle = PartyFightLifecycleTracker(ACTIVE_ACCOUNTS, CRA_ACCOUNT)
    last_lifecycle_signature = None

    while True:
        current=_snapshots(context)
        current_fighting=any((snap.get("fight") or {}).get("present") for snap in current.values())
        previous_fighting=bool(previous and any((snap.get("fight") or {}).get("present") for snap in previous.values()))
        lifecycle=fight_lifecycle.observe(current)
        lifecycle_signature=(lifecycle.state.value,lifecycle.fight_instance_id,lifecycle.present_accounts,lifecycle.missing_accounts)
        if lifecycle_signature != last_lifecycle_signature:
            context.log(
                f"CERT_FIGHT_LIFECYCLE state={lifecycle.state.value} "
                f"fight_instance_id={lifecycle.fight_instance_id} expected={lifecycle.expected_fight_instance_id} "
                f"present={list(lifecycle.present_accounts)} missing={list(lifecycle.missing_accounts)} "
                f"converged_before={lifecycle.converged_before} reason={lifecycle.reason}"
            )
            last_lifecycle_signature=lifecycle_signature
        if lifecycle.state is PartyFightLifecycleState.CONFLICT:
            context.log(f"CERT_SINGLE_FIGHT=FAIL code=FIGHT_LIFECYCLE_CONFLICT detail={lifecycle.reason}")
            return
        if lifecycle.state is PartyFightLifecycleState.AMBIGUOUS_PARTIAL:
            context.log(f"CERT_SINGLE_FIGHT=FAIL code=FIGHT_LIFECYCLE_AMBIGUOUS detail={lifecycle.reason}")
            return
        if lifecycle.state is PartyFightLifecycleState.EXIT_SETTLING:
            wait_state=turn_wait.observe(f"post_fight:{lifecycle.fight_instance_id}")
            if wait_state.get("log_due"):
                context.log(
                    f"CERT_POST_FIGHT_SETTLEMENT_WAIT fight_instance_id={lifecycle.fight_instance_id} "
                    f"present={list(lifecycle.present_accounts)} missing={list(lifecycle.missing_accounts)} "
                    f"poll={wait_state.get('count')} delay_s={wait_state.get('delay_seconds')}"
                )
            previous=current
            context.wait(float(wait_state.get("delay_seconds") or 0.15))
            continue

        if fight_started and previous_fighting and not current_fighting:
            terminal=context.party_fight_outcome(previous)
            outcome=str((terminal or {}).get("outcome") or "UNKNOWN")
            context.record_fight_outcome(outcome)
            fight_lifecycle.note_terminal(lifecycle.fight_instance_id)
            _finish(context,outcome)
            return

        cra=current[CRA_ACCOUNT]
        if not current_fighting:
            turn_wait.reset()
            search=world_search.observe()
            world=cra.get("world") or {}
            current_map=_value(world.get("map_id"))
            if search.get("started_now"):
                context.log(f"CERT_WORLD_SEARCH_START map_id={current_map} timeout_s={MAX_WORLD_SEARCH_SECONDS}")
            if search.get("log_due"):
                context.log(
                    f"CERT_WORLD_SEARCH_PROGRESS elapsed_s={search.get('elapsed_seconds')} "
                    f"map_id={current_map} roster_complete={bool(world.get('monster_groups_complete'))} "
                    f"eligible_groups={len(_candidate_groups(world))}"
                )
            if search.get("timed_out"):
                context.log(
                    f"CERT_SINGLE_FIGHT=FAIL code=WORLD_SEARCH_TIMEOUT "
                    f"elapsed_s={search.get('elapsed_seconds')} map_id={current_map}"
                )
                return
            if current_map is None or int(current_map) not in PATROL:
                context.log(f"CERT_SINGLE_FIGHT=FAIL code=WORLD_MAP_NOT_CERTIFIED value={current_map}")
                return
            convergence=context.party_change_map(int(current_map))
            convergence_gate=_handle_action_result(context,"party:converge",convergence)
            if convergence_gate == "STOP": return
            if convergence_gate == "WAIT":
                previous=current
                continue
            if not world.get("monster_groups_complete"):
                context.log(f"CERT_WORLD_ROSTER_INCOMPLETE map_id={int(current_map)}; waiting for authoritative group snapshot")
                previous=current; context.wait(0.3); continue
            candidates=_candidate_groups(world)
            if candidates:
                for group in candidates:
                    result=context.launch_fight(int(group["group_id"]),account_id=CRA_ACCOUNT)
                    if _should_try_next_launch_candidate(result):
                        context.log(
                            f"CERT_LAUNCH_CANDIDATE_SKIPPED group_id={int(group['group_id'])} "
                            "reason=PROJECTION_UI_OCCLUDED input_sent=false"
                        )
                        continue
                    gate=_handle_action_result(context,"cra:launch_fight",result)
                    if gate == "STOP": return
                    if gate == "CONTINUE":
                        confirmed_launch=_launch_context_from_result(result)
                        if confirmed_launch is None:
                            context.log("CERT_SINGLE_FIGHT=FAIL code=cra:launch_fight:MISSING_FINAL_LAUNCH_CONTEXT")
                            return
                        fight_started=True
                        launch_context=confirmed_launch
                        fight_lifecycle.note_launch(int(confirmed_launch["fight_instance_id"]))
                        context.log(f"CERT_FIGHT_LAUNCH=PASS group_id={int(group['group_id'])} cell_id={launch_context['launch_cell_id']}")
                    break
                previous=current; context.wait(0.2); continue
            if world_steps >= MAX_WORLD_SEARCH_STEPS:
                context.log("CERT_SINGLE_FIGHT=FAIL code=NO_ELIGIBLE_6_8_GROUP")
                return
            target=_next_map(current_map)
            if target is None:
                context.log("CERT_SINGLE_FIGHT=FAIL code=PATROL_ROUTE_UNKNOWN")
                return
            result=context.party_change_map(int(target))
            if _handle_action_result(context,"party:search_transition",result) == "STOP": return
            world_steps += 1
            previous=current; context.wait(0.2); continue

        world_search.reset()
        party=context.party_snapshot()
        if party.get("status") == "CONFLICT":
            context.log(f"CERT_SINGLE_FIGHT=FAIL code=SHARED_FIGHT_CONFLICT detail={party.get('detail')}")
            return
        missing=_required_join_targets(party)
        if missing:
            join_acquire_polls += 1
            if join_acquire_polls > MAX_JOIN_ACQUIRE_POLLS:
                context.log(
                    f"CERT_SINGLE_FIGHT=FAIL code=JOIN_ACQUIRE_TIMEOUT polls={join_acquire_polls - 1} "
                    f"last_status={join_acquire_last_status} last_code={join_acquire_last_code} "
                    f"last_detail={join_acquire_last_detail}"
                )
                return
            reference=_fight_reference(cra,launch_context)
            if reference is None:
                previous=current; context.wait(0.5); continue
            undiscovered=[
                account_id for account_id in missing
                if not _join_discovery_matches(current.get(account_id) or {}, reference)
            ]
            if undiscovered:
                join_acquire_last_status="DISCOVERY_WAIT"
                join_acquire_last_code="DISCOVERY_NOT_READY"
                join_acquire_last_detail=f"accounts={','.join(undiscovered)}"
                if join_acquire_polls == 1 or join_acquire_polls % 10 == 0:
                    context.log(
                        f"CERT_JOIN_ACQUIRE_WAIT fight_instance_id={reference['fight_instance_id']} "
                        f"poll={join_acquire_polls}/{MAX_JOIN_ACQUIRE_POLLS} status={join_acquire_last_status} "
                        f"failure_code={join_acquire_last_code} detail={join_acquire_last_detail}"
                    )
                previous=current; context.wait(0.5); continue
            for account_id in missing:
                result=context.join_fight(reference,account_id=account_id)
                status=str((result or {}).get("status") or "UNKNOWN") if isinstance(result,dict) else "INVALID"
                detail=(result or {}).get('detail') if isinstance(result,dict) else result
                failure_code=str((result or {}).get("join_failure_code") or "") if isinstance(result,dict) else ""
                retry_allowed=bool((result or {}).get("retry_allowed")) if isinstance(result,dict) else False
                join_method=(result or {}).get('join_method') if isinstance(result,dict) else None
                if status == "CONFIRMED":
                    fight_lifecycle.note_join_confirmed(account_id, int(reference["fight_instance_id"]))
                    context.log(
                        f"CERT_JOIN_AUTO_CONFIRMED account={account_id} "
                        f"fight_instance_id={reference['fight_instance_id']} method={join_method}"
                    )
                    continue
                if status == "WINDOW_CLOSED" or failure_code == "WINDOW_CLOSED":
                    context.log(
                        f"CERT_SINGLE_FIGHT=FAIL code={account_id}:JOIN_WINDOW_CLOSED "
                        f"detail={detail}"
                    )
                    return
                if status == "JOIN_SETTLING":
                    join_acquire_last_status=status
                    join_acquire_last_code=failure_code or "JOIN_SETTLING"
                    join_acquire_last_detail=str(detail or "")
                    context.log(
                        f"CERT_JOIN_SETTLING account={account_id} fight_instance_id={reference['fight_instance_id']} "
                        f"poll={join_acquire_polls}/{MAX_JOIN_ACQUIRE_POLLS} method={join_method} "
                        f"request_observed={(result or {}).get('semantic_request_observed') if isinstance(result,dict) else None} "
                        f"transition={(result or {}).get('context_transition_map_id') if isinstance(result,dict) else None} "
                        f"detail={join_acquire_last_detail}"
                    )
                    previous=current; context.wait(0.5); break
                if status in {"TARGET_MISS","NO_INTERACTION","UNCERTAIN","TIMEOUT","INVALID"}:
                    context.log(
                        f"CERT_SINGLE_FIGHT=FAIL code={account_id}:JOIN_{status} "
                        f"detail={detail}"
                    )
                    return
                if status in {"RETRYABLE","BLOCKED"} and retry_allowed:
                    join_acquire_last_status=status
                    join_acquire_last_code=failure_code or "WAITING_TARGET_PROOF"
                    join_acquire_last_detail=str(detail or "")
                    context.log(
                        f"CERT_JOIN_ACQUIRE_WAIT account={account_id} fight_instance_id={reference['fight_instance_id']} "
                        f"poll={join_acquire_polls}/{MAX_JOIN_ACQUIRE_POLLS} status={status} "
                        f"failure_code={join_acquire_last_code} method={join_method} "
                        f"readiness={(result or {}).get('join_readiness_source') if isinstance(result,dict) else None} "
                        f"presentation={(result or {}).get('protocol_presentation_ready') if isinstance(result,dict) else None} "
                        f"detail={join_acquire_last_detail}"
                    )
                    previous=current; context.wait(0.5); break
                context.log(
                    f"CERT_SINGLE_FIGHT=FAIL code={account_id}:JOIN_{status} "
                    f"detail={detail}"
                )
                return
            else:
                previous=current; context.wait(0.25); continue
            continue
        join_acquire_polls=0
        join_acquire_last_status="NOT_STARTED"
        join_acquire_last_code=""
        join_acquire_last_detail=""

        active_actor=party.get("active_actor_id")
        if active_actor is None:
            if not should_prepare_fight(current, active_actor_id=active_actor):
                previous=current
                wait_state=turn_wait.observe(f"handoff:{party.get('fight_instance_id')}")
                if wait_state.get("log_due"):
                    context.log(
                        f"CERT_TURN_HANDOFF_WAIT fight_instance_id={party.get('fight_instance_id')} "
                        f"poll={wait_state.get('count')} delay_s={wait_state.get('delay_seconds')}; "
                        "fight remains ACTIVE while awaiting next TURN_STARTED"
                    )
                context.wait(float(wait_state.get("delay_seconds") or 0.15))
                continue
            result=context.party_prepare_fight_step()
            barrier=(result or {}).get("fight_entry_barrier") if isinstance(result,dict) else None
            if isinstance(barrier,dict):
                context.log(
                    f"CERT_FIGHT_ENTRY_BARRIER status={barrier.get('status')} "
                    f"fight_instance_id={barrier.get('fight_instance_id')} accounts={barrier.get('accounts')}"
                )
            preparation=(result or {}).get("preparation") if isinstance(result,dict) else None
            if isinstance(preparation,dict):
                context.log(
                    f"CERT_PREP_TRACE fight_instance_id={preparation.get('fight_instance_id')} "
                    f"stage={preparation.get('stage')} age_ms={preparation.get('age_ms')} "
                    f"timings={preparation.get('stage_timings_ms')}"
                )
                for action in list(preparation.get("step_actions") or []):
                    context.log(
                        f"CERT_PREP_ACTION account={action.get('account_id')} "
                        f"action={action.get('action')} status={action.get('status')}"
                    )
            prep_status=str((result or {}).get("status") or "UNKNOWN")
            terminal_prepare_failure=prepare_step_terminal_failure(result)
            if terminal_prepare_failure is not None:
                context.log(
                    f"CERT_SINGLE_FIGHT=FAIL code={terminal_prepare_failure} "
                    f"stage={(result or {}).get('stage')} detail={(result or {}).get('detail')}"
                )
                return
            if prep_status not in {"IN_PROGRESS","CONFIRMED","BLOCKED"}:
                context.log(f"CERT_SINGLE_FIGHT=FAIL code=PREPARE_STEP_{prep_status}")
                return
            if prep_status == "CONFIRMED":
                context.log(f"CERT_PLACEMENT_READY=PASS cells={(result or {}).get('placement_cells') if isinstance(result,dict) else None}")
            previous=_snapshots(context); context.wait(0.15); continue
        combat=context.party_combat_step()
        combat_status=str((combat or {}).get("status") or "UNKNOWN")
        progress_token=str((combat or {}).get("progress_token") or f"{party.get('fight_instance_id')}:waiting")
        watchdog=context.mission_phase("FIGHT_ACTIVE",key=progress_token)
        if isinstance(watchdog,dict) and str(watchdog.get("status")) == "TIMEOUT":
            context.log(
                f"CERT_SINGLE_FIGHT=FAIL code=MISSION_TIMEOUT phase=FIGHT_ACTIVE "
                f"elapsed={watchdog.get('elapsed_seconds')} progress={progress_token}"
            )
            return
        decision=(combat or {}).get("decision") or {}
        action_result=(combat or {}).get("action_result") or {}
        if combat_status == "WAIT":
            wait_state=turn_wait.observe(f"combat:{(combat or {}).get('reason')}:{progress_token}")
            if wait_state.get("log_due"):
                context.log(
                    f"CERT_COMBAT_WAIT account={(combat or {}).get('account_id')} "
                    f"reason={(combat or {}).get('reason')} progress={progress_token} "
                    f"poll={wait_state.get('count')} delay_s={wait_state.get('delay_seconds')}"
                )
            previous=current
            context.wait(float(wait_state.get("delay_seconds") or 0.15))
            continue
        turn_wait.reset()
        context.log(
            f"CERT_COMBAT_STEP status={combat_status} account={(combat or {}).get('account_id')} "
            f"reason={(combat or {}).get('reason')} progress={progress_token} "
            f"decision={decision.get('kind')} spell={decision.get('spell_id')} "
            f"target={decision.get('target_cell_id')} action_status={action_result.get('status')}"
        )
        if combat_status in {"FAILED","BLOCKED","BLOCKED_STALLED"}:
            context.log(
                f"CERT_SINGLE_FIGHT=FAIL code=COMBAT_{combat_status} "
                f"detail={(combat or {}).get('reason')} account={(combat or {}).get('account_id')}"
            )
            return
        # Preserve the pre-action fighting snapshot so a terminal action that
        # already advanced Canonical State to world mode cannot erase the
        # fight-present edge before the next loop observes it.
        previous=current; context.wait(0.15); continue

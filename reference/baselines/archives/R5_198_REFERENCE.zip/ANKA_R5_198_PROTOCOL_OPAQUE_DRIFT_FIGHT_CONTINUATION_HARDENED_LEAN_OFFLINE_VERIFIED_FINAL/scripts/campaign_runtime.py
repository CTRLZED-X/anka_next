"""Generic production campaign worker for ANKA.

This worker is intentionally thin. The parent CampaignRuntimeController owns
campaign budget, world/fight lifecycle, target acquisition, follower joining,
preparation, combat progression, terminal evidence, outcome accounting,
post-fight reentry, watchdogs, recovery and causality.

The worker owns only cooperative polling/log rendering and explicit terminal
success/failure signalling to ScriptSupervisor. It contains no map IDs, account
names, monster ranges, win counts, or fight mechanics.
"""

ANKA_LAUNCH_MODE = "SESSION_ONLY"
ANKA_REQUIREMENTS = {"party_mode": True, "windows_certification": True}
ANKA_EXPLICIT_SUCCESS = True


def _fail(context, code: str, detail: str = "") -> None:
    fail = getattr(context, "fail", None)
    if callable(fail):
        fail(str(code), str(detail or ""))
        return
    raise RuntimeError(f"{code}: {detail}" if detail else str(code))


def _wait_seconds(action: dict, *, default: float) -> float:
    retry_after = action.get("retry_after_seconds") if isinstance(action, dict) else None
    if retry_after is None:
        return float(default)
    try:
        return max(0.05, min(2.0, float(retry_after)))
    except (TypeError, ValueError):
        return float(default)


def _finish_from_action(context, action: dict, *, fallback_reason: str = "CAMPAIGN_STOPPED") -> bool:
    """Finish from the authoritative parent step without a second status RPC.

    CampaignRuntimeController already fences stopped budgets before every step and
    returns the stop_reason + budget in its terminal action.  R5.121 nevertheless
    issued a separate party_mission_status RPC before every campaign step and again
    on terminal outcome, doubling hot-loop RPC volume and amplifying diagnostics
    overhead.  The thin worker must consume the parent result it already has.
    """
    reason = str(action.get("stop_reason") or fallback_reason or "CAMPAIGN_STOPPED")
    budget = dict(action.get("budget") or {})
    context.log(
        "CAMPAIGN_STOP "
        f"reason={reason} "
        f"wins={budget.get('wins')}/{budget.get('target_wins')} "
        f"attempts={budget.get('attempts')}/{budget.get('max_attempts')}"
    )
    if reason == "TARGET_WINS_REACHED":
        context.succeed("TARGET_WINS_REACHED")
        return True
    _fail(
        context,
        reason,
        f"wins={budget.get('wins')} attempts={budget.get('attempts')}",
    )
    return True


def _render_campaign(context, raw: dict, action: dict, state: str, reason: str) -> bool:
    if state == "STOPPED":
        return _finish_from_action(context, action, fallback_reason=reason)
    if state == "FAILED":
        code = str(action.get("failure_code") or reason or "CAMPAIGN_RUNTIME_FAILED")
        context.log(
            "CAMPAIGN_RUNTIME_FAIL "
            f"code={code} boundary={action.get('first_missing_boundary')} "
            f"owner={action.get('likely_owner')} detail={action.get('detail') or reason}"
        )
        _fail(context, code, str(action.get("detail") or reason))
        return True
    if state == "OUTCOME_COMMITTED":
        budget = dict(action.get("budget") or {})
        context.log(
            "CAMPAIGN_OUTCOME "
            f"fight={action.get('fight_instance_id')} outcome={action.get('outcome')} "
            f"reason={action.get('outcome_reason')} "
            f"wins={budget.get('wins')}/{budget.get('target_wins')} "
            f"attempts={budget.get('attempts')}/{budget.get('max_attempts')} "
            f"evidence_complete={action.get('evidence_complete')}"
        )
        if str(action.get("status") or "") == "STOP":
            return _finish_from_action(context, action, fallback_reason=reason)
        context.wait(0.02)
        return False
    _fail(context, "CAMPAIGN_RUNTIME_UNKNOWN_STATE", f"state={state} reason={reason}")
    return True


def _render_world(context, raw: dict, action: dict, state: str, reason: str) -> bool:
    status = str(action.get("status") or "WAIT")
    context.log(
        "CAMPAIGN_WORLD "
        f"state={state} status={status} account={raw.get('account_id') or action.get('account_id')} "
        f"reason={reason} failure_code={action.get('failure_code')} "
        f"target_map={action.get('target_map_id')} "
        f"target_group={action.get('selected_group_id') or action.get('target_group_id')}"
    )
    if state == "FAILED" or status in {"FAILED", "UNCERTAIN", "TIMEOUT", "INVALID"}:
        code = str(action.get("failure_code") or reason or f"WORLD_ACTION_{status}")
        _fail(context, code, str(action.get("detail") or reason))
        return True
    context.wait(_wait_seconds(action, default=0.08))
    return False


def _render_fight(context, raw: dict, action: dict, state: str, reason: str) -> bool:
    status = str(action.get("status") or "WAIT")
    context.log(
        "CAMPAIGN_FIGHT "
        f"state={state} status={status} account={raw.get('account_id') or action.get('account_id')} "
        f"reason={reason} failure_code={action.get('failure_code') or action.get('join_failure_code')} "
        f"progress={action.get('progress_token') or raw.get('progress_token')}"
    )
    if state == "FAILED" or status in {"FAILED", "BLOCKED_STALLED"}:
        code = str(
            action.get("failure_code")
            or action.get("join_failure_code")
            or reason
            or f"FIGHT_{status}"
        )
        _fail(context, code, str(action.get("detail") or action.get("reason") or reason))
        return True
    context.wait(_wait_seconds(action, default=0.06 if state == "ACTIVE" else 0.10))
    return False



def _render_progress(context, raw: dict, action: dict, domain: str, state: str, reason: str) -> bool:
    """Forward-compatible renderer for parent-owned lifecycle phases.

    The worker must never enumerate the parent's internal lifecycle domains.
    Adding STARTUP/TRANSITION/PREPARATION/POST_FIGHT phases is a parent concern;
    the worker only needs a stable terminal-vs-progress disposition.
    """
    status = str(action.get("status") or "WAIT")
    context.log(
        "CAMPAIGN_PROGRESS "
        f"domain={domain} state={state} status={status} "
        f"account={raw.get('account_id') or action.get('account_id')} "
        f"reason={reason} failure_code={action.get('failure_code')} "
        f"boundary={action.get('first_missing_boundary')} owner={action.get('likely_owner')}"
    )
    if state == "FAILED" or status in {"FAILED", "UNCERTAIN", "TIMEOUT", "INVALID", "BLOCKED_STALLED"}:
        code = str(action.get("failure_code") or reason or f"CAMPAIGN_{domain}_{status}")
        _fail(context, code, str(action.get("detail") or action.get("reason") or reason))
        return True
    context.wait(_wait_seconds(action, default=0.08))
    return False

def main(context) -> None:
    # The parent activates the immutable SessionPlan and resets campaign state
    # before this worker starts. Keeping reset ownership out of the worker removes
    # a startup race where stale state could exist between Launch and the first
    # worker RPC, and prevents arbitrary scripts from deciding when a campaign is
    # reset.
    plan = context.session_plan() or {}
    context.log(
        "CAMPAIGN_RUNTIME_OWNER=PARENT "
        f"session_id={plan.get('session_id')} leader={plan.get('leader_account_id')} "
        f"required={list(plan.get('required_account_ids') or ())} "
        f"active={list(plan.get('active_account_ids') or ())} "
        f"route={list(plan.get('route_map_ids') or ())} "
        f"target={plan.get('target_min_monsters')}-{plan.get('target_max_monsters')}"
    )

    while True:
        raw = context.party_campaign_step()
        if not isinstance(raw, dict):
            _fail(context, "CAMPAIGN_RUNTIME_INVALID_RESULT", str(raw))
            return
        domain = str(raw.get("domain") or "UNKNOWN")
        state = str(raw.get("state") or "UNKNOWN")
        action = dict(raw.get("action") or {}) if isinstance(raw.get("action"), dict) else {}
        reason = str(raw.get("reason") or action.get("reason") or "")

        if domain == "CAMPAIGN":
            if _render_campaign(context, raw, action, state, reason):
                return
            continue
        if domain == "WORLD":
            if _render_world(context, raw, action, state, reason):
                return
            continue
        if domain == "FIGHT":
            if _render_fight(context, raw, action, state, reason):
                return
            continue
        # Every non-terminal parent phase is intentionally forward compatible.
        # R5.119 crashed here when the parent correctly introduced TRANSITION /
        # LEADER_ENTRY_PENDING. Never make the thin worker a second lifecycle
        # state machine again.
        if _render_progress(context, raw, action, domain, state, reason):
            return

# R5.186 — Entity Resolution, Control Atomicity & Diagnostic Causality Foundation

**Status:** **OFFLINE VERIFIED** — Windows/Dofus live acceptance pending  
**Protocol:** `dofus_3_6_12_16` unchanged by explicit project assumption and current world-navigation evidence.

## Why R5.186 exists

The R5.185 live run proved that startup bootstrap and direct CRA/ENU window activation progressed: both accounts performed the RIGHT bootstrap transition and established the expected world MapId. The run then stalled before fight entry because Unity entity projection repeatedly resolved independent monster groups to the shared `/entities` parent at world `(0,0)`, nearest CellId 328, while Canonical State correctly reported their real cells. Execution correctly refused the unsafe click, but world acquisition retried the same deterministic mismatch until a generic mission timeout.

## Systemic repairs

1. **Entity identity cannot collapse to shared ancestors.** Exact current-build roots named `Entity <signed-id>` are recognized, and visual refinement is restricted to the proven entity itself or descendants. `/entities` can never be a target anchor.
2. **Runtime-grid validation remains authoritative.** Canonical EntityId→CellId and the live Unity anchor's nearest runtime-grid CellId must agree before a click. Missing `cell::<id>` objects are reported as unavailable rather than fabricated as zero-distance evidence.
3. **Bounded systemic projection failure.** Three identical all-target, input-free entity mismatches terminate with `PROJECTION_ENTITY_RESOLUTION_SYSTEMIC_FAILURE` owned by `UNITY_ENTITY_RESOLVER`, rather than looping until `MISSION_TIMEOUT`.
4. **Atomic worker/control ownership.** ScriptSupervisor reserves the run ID and Control Authority binds to it before the worker process starts. A session permit with `run_id=null` cannot authorize physical execution.
5. **Consistent focus recovery.** `WINDOW_FOCUS_FAILED` is bounded/recoverable only when HWND/PID identity remains valid and physical input is proven `NOT_SENT`; identity changes remain hard failures.
6. **Diagnostic causality and generation integrity.** Recovered focus anomalies no longer outrank a later precise terminal projection failure, while already precise lower-layer roots remain preserved. Bridge discovery must match process and map/coordinate generation to be authoritative; stale discovery is retained only as historical evidence.
7. **Bridge identity bump.** Coordinate Bridge `2.2.76`, contract 4, projection authority `ENTITY_SUBTREE_RUNTIME_GRID_V3` prevents setup from silently reusing the resolver-bugged binary.
8. **Current-build entity compatibility.** Exact roots named `Entity <signed-id>` are supported for both monsters and players. Exact-name discovery scans the Unity scene once per resolution pass, preserves uniqueness, and falls back to reflective discovery only when exact identity is unavailable.
9. **Fight-entry projection uses the verified runtime grid.** Fight entry no longer requires literal `cell::<id>` GameObjects. Current actor roots named `Entity <signed-id>` are excluded from join-target candidates so a player/monster object cannot be mistaken for the fight-entry interaction.
10. **Release-context coherence.** Integrity verification checks the current-release test hotpath as well as release/checkpoint/version/gate metadata.

## Next live acceptance

Use a fresh R5.186 extraction and run `setup.bat` with Dofus closed so bridge `2.2.76` is built/installed and its identity record is refreshed. Do not run AutoHotkey for normal switching. Run one small CRA+ENU mission. The critical acceptance path is: bootstrap MapId → current monster entity root → runtime-grid CellId agreement → at most one world-target click → fight entry. If entity interaction still cannot be proven, the run must stop quickly with the precise projection failure and a current-generation discovery bundle.

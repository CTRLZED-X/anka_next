# ANKA Platform R5.141 — Spell-Target Interaction, ActionIntent & Sequence Planning Hardening

Checkpoint: `ANKA_PLATFORM_R5_141_SPELL_TARGET_INTERACTION_ACTION_INTENT_SEQUENCE_PLANNING_HARDENING_WINDOWS_LIVE_CANDIDATE`

Offline verification: **PASS — FROZEN TREE VERIFIED**. Windows/Dofus live acceptance: **PENDING**.

## Why R5.141 exists

`runtime(20260926-231620)` exposed a different boundary from the R5.140 planner/admission mismatch. In fight 478, Enu selected Bêche des Anciens from cell 101 onto CellId 141 to affect enemy -1 on cell 170. The evidence proves CellId 141 existed, the Kernel generated/admitted it, PRE_TARGET certified the intended enemy impacts, the bridge geometrically projected it, and both slot/target clicks were sent. No semantic CAST request or server-confirmed cast followed. Earlier Bêche casts onto empty cells succeeded in the same fight.

Therefore R5.141 does **not** ban cell 141, empty-cell AoE, or Bêche des Anciens. It separates four contracts: map-cell existence, movement legality, spell semantic targetability/effects, and live client spell-cell interactability.

## 1. Exact rendered fight-cell interaction

For production `SPELL_TARGET_CLICK`, the Unity bridge now resolves the exact rendered `GraphicCells/cell::<id>` object and projects that object directly. Python preserves anchor hierarchy, planar error, static walkability, projectability, picker/runtime-grid flags and diagnostics. A Kernel-legal cast whose rendered cell anchor cannot be verified is blocked **before target click** as `SPELL_TARGET_INTERACTION_UNVERIFIED`, neutralized safely after slot selection, quarantined for the current turn, and may replan.

Static walkability is diagnostic only here: R5.141 does not invent a rule that every legal spell target must be movement-walkable.

## 2. ActionIntent / Expected impact

FightAI now preserves the Kernel-certified actor/effect orders that materially justified a CAST. `ActionIntent.required_impacts` can represent enemy impacts and ally benefits. The serialized intent travels decision -> controller -> execution -> PRE_SLOT/PRE_TARGET admission. Latest-state Kernel feasibility must still prove those exact actor/effect obligations; malformed non-empty intent fails closed.

This closes the support-spell gap where a cast could score because it buffed/healed an ally but admission only revalidated general cell legality.

## 3. Support AoE target generation

For heal/shield/AP/MP/range-support AoE, interesting empty cast cells are generated around allies as well as enemies. The planner no longer assumes support must target the ally's occupied cell directly. Kernel effect eligibility remains the authority.

## 4. Same-session cast rejection certification

R5.139 correctly refused to use absence of `jrj` as negative evidence on an uncertified newer client build. R5.141 keeps that rule, but may certify **one spell on one exact client instance/version in the current session** after at least three server-confirmed casts each correlate with the exact outbound `jrj(spell_id,target_cell)` payload under continuous capture. Only then may later capture-covered absence for that same spell/client context classify `CLIENT_CAST_REJECTED` and recover safely. Another spell, client instance or restarted session remains uncertified.

## 5. Range/PO evidence starvation remains fail-closed

The triggering runtime showed many Cra/Enu spells excluded because `combat_stats.range_bonus` was not observed. R5.141 does **not** assume missing PO is zero. Candidate diagnostics now export `missing_input_counts` and `range_evidence_starvation_count` so one debug package clearly shows action-space collapse. A future authoritative client/protocol combat-stat source is still required to solve missing PO itself.

## 6. Bounded two-ply sequence valuation

The old planner only explored the top two standalone MOVE candidates for `MOVE -> CAST`, and only when no material direct CAST existed. R5.141 adds a strict-budget generalized two-ply evaluator over several accepted first CASTs and MOVEs. It can value:

- `CAST -> CAST`
- `CAST -> MOVE`
- `MOVE -> CAST`
- `MOVE -> MOVE`

Only deterministic/projection-complete first primitives are expanded. The best legal continuation contributes bounded `future_value` to the first primitive. Execution still sends **only the first primitive**, waits for authoritative settlement, captures a new CombatDecisionFrame and replans. This is receding-horizon planning, not a scripted combo executor.

The search is intentionally bounded (branch caps, preview cap and sub-deadline). It is an initial generic sequence foundation, not exhaustive minimax or arbitrary-depth brute force.

## 7. Diagnostics

R5.141 preserves in candidate/runtime evidence:

- ActionIntent actor/effect obligations;
- exact rendered cell-anchor hierarchy and diagnostics;
- static walkability versus projectability versus interaction verification;
- same-session negative-semantics certification provenance/proof count;
- Range/PO missing-input counts;
- two-ply sequence routes, first action, best continuation and sequence score;
- specific `SPELL_TARGET_INTERACTION_UNVERIFIED` classification before input.

## 8. Preserved invariants

- ExecutionService remains sole physical-input authority.
- one physical primitive settles before the next; multi-action planning never becomes multi-click execution.
- UNKNOWN never becomes optimistic TRUE.
- uncertain physical input remains fenced and cannot be hidden by END_TURN.
- shared CombatDecisionFrame and typed R5.140 recovery remain authoritative.
- R5.139 slot UI-neutralization and fresh PRE_TARGET projection remain mandatory.
- no incident spell/cell/fight ID branch is introduced.

## 9. Windows bridge gate

The Unity bridge C# source changed. This Linux workspace has no supported C# compiler, so offline Python/source tests cannot claim DLL compilation. Before R5.141 live acceptance, close Dofus and run `install_bridge.bat`; require its normal compile and byte-verification success, then reopen Dofus.

## 10. Live acceptance focus

A fresh autonomous run must demonstrate:

```text
Kernel-legal target
 -> exact rendered fight-cell interaction verified
 -> PRE_TARGET ActionIntent still satisfied
 -> click/semantic/server outcome settles
 -> if proven local rejection occurs, quarantine/replan safely
 -> bounded sequence valuation improves movement/cast choices
 -> no unsafe fallback after uncertain physical input
 -> fight terminates and mission continues
```

Also inspect `range_evidence_starvation_count`. If many spells remain unavailable because PO is absent, preserve that evidence and solve the observation source rather than assuming zero.

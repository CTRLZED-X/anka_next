# Protocol Upgrade Guide — R5.193

> R5.193 preserves the R5.192 protocol semantics and upgrade contract. The additional requirement is install coherence: after a candidate adapter is activated, rerun `setup.bat` so the non-editable site-packages payload is rebound to the exact source/protocol release; `start.bat` will fail closed if this step was skipped.

## Objective

A Dofus protocol update must be contained inside a versioned protocol package while Canonical State, Kernel, FightAI, party/campaign orchestration and physical execution keep their stable semantic contracts. A new adapter is not accepted merely because individual messages decode.

## Non-negotiable boundaries

Raw message names, packet/field layouts, request wire bindings, slot dialects, version-local decoder state and transform logic belong under `src/anka_platform/protocol/adapters/<adapter_id>/`.

Generic `live_state`, `execution`, `party`, `campaign`, `fight_ai`, projection and observability code uses canonical events or `ProtocolWireSemantic`. Generic diagnostics may display the active raw name only by resolving it dynamically from the selected manifest.

A concrete adapter package may use shared generic protocol SDK primitives, but it must **not import, subclass or delegate to another concrete version adapter**. Historical adapters are frozen replay authorities.

## Evidence classes

Keep these distinct:

1. **Historical regression evidence** — proves behavior that older certified adapters must continue to reproduce.
2. **Current-build positive evidence** — proves a semantic occurred on the current client build.
3. **Current-build negative evidence** — only proves absence/negative semantics when the controlled observation is strong enough for that claim.
4. **Scenario evidence** — proves important relationships across multiple capabilities and event orderings.
5. **Bounded live acceptance** — proves the installed Windows/client/bridge/runtime chain rather than only offline decoding.

Historical captures can protect compatibility; they do not independently grant exact-current certification.

## Required adapter package

For the active current adapter keep together:

- `adapter.py`;
- version-local runtime `context.py`;
- capability-owned handler modules;
- `manifest.py` with explicit capabilities/build identity;
- `wire_catalog.json`;
- `evidence_provenance.json`;
- `scenario_contract.json`;
- `certification_attestation.json`.

`verify_protocol_upgrade_contract.py` verifies this boundary before release/startup.

## Upgrade procedure

1. Identify the observed client build from runtime/debug evidence.
2. Preserve the old adapter unchanged.
3. Use the evidence package to determine what actually changed; do not assume the version string means every semantic changed.
4. Create a **new version-local adapter package** when the client build requires a new active adapter. Shared generic SDK helpers are allowed; importing another concrete adapter package is not.
5. Implement only evidence-supported wire semantics. Unknown/ambiguous messages remain unclassified or typed drift; do not invent values to keep automation moving.
6. Record current-build provenance per declared capability. Mark incomplete semantics `PARTIAL`; never promote them to `VERIFIED` merely because a historical capture passes.
7. Fill the required scenario contract, including at minimum:
   - world -> fight entry;
   - leader creates / follower joins;
   - persistent world MapId vs tactical fight MapId;
   - placement -> Ready;
   - Ready -> first turn owner;
   - movement -> CellId/MP;
   - cast -> AP/damage/cooldown;
   - End Turn -> next owner;
   - fight end -> world re-entry.
8. Record static game-data compatibility for the current client build separately from network protocol compatibility.
9. Before activation, verify the staged adapter independently with:
   `python tools/verify_protocol_upgrade_contract.py --adapter-id <new_adapter_id> --candidate`
   This validates isolation, provenance, scenario coverage, static-data compatibility and attestation without changing the live `config.yaml`.
10. Only after the candidate reports `READY`, update `config.yaml` and `config.yaml.example` together and add one explicit registry registration. Regenerate the current adapter attestation hashes if its bound files changed.
11. Run `python tools/verify_protocol_upgrade_contract.py` again in release mode. It must return `READY` with configuration coherence before release sealing.
12. Run R5 current tests, protocol/live-state tests, historical replay regressions, architecture checks and the complete current release gate.
13. Rerun `setup.bat` so the non-editable installed runtime is bound to the new source/protocol fingerprint. `start.bat` will intentionally reject stale installed code.
14. Perform one bounded CRA+ENU live acceptance fight before expanding workload.

## Current live-pending rule

A scenario containing `PENDING` is explicitly not exact-current live proof. It may be offline/historical/current-server-authority verified enough to keep the adapter structurally usable, but the pending limitation must remain visible in release/debug evidence.

For the current 3.7.10.10 adapter, the exact outbound End Turn request remains unproven. `jst` is ACK evidence; server `jup` is completion authority. Do not remap End Turn without controlled current-build evidence.

## Fail-closed rules

- Unknown wire data remains unknown/unclassified.
- Typed schema drift is never silently converted to an empty-success event.
- A protocol update cannot bypass Canonical State or modify FightAI/Execution merely to accommodate raw packet changes.
- Protocol state mutation is transactional with canonical persistence and rollback.
- Raw wire names outside the protocol boundary fail the upgrade contract.
- A changed protocol/source tree after setup fails the runtime-install contract until setup is rerun.
- Static game-data compatibility and protocol compatibility are separate gates.

## Expected normal change surface

Usually changed: one new versioned adapter package, evidence/scenario/attestation metadata, protocol tests, registry/config/release metadata.

Usually unchanged: `anka_game_kernel` mechanics, FightAI policy, party/campaign state machines, ExecutionService semantic actions, Windows input and pointer motion.

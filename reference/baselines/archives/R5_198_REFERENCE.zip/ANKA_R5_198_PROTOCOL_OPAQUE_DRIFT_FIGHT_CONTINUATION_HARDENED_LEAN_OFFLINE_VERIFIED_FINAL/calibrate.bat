@echo off
setlocal
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"
if "%~1"=="" (
  echo ANKA CLICK CALIBRATION - defaults already loaded; no F8 needed
  echo.
  echo CATEGORY 1 - SPELL SLOTS 1 TO 22
  echo   calibrate.bat spells --window-title Curseni
  echo   Go to Dofus and CLICK slot 1, 2, 3 ... 22 in order.
  echo   A short beep confirms every detected click.
  echo.
  echo CATEGORY 2 - PHASE BUTTON
  echo   calibrate.bat phase-button --window-title Curseni
  echo   CLICK the shared Challenge / Ready / End Turn position once.
  echo   A short beep confirms detection.
  echo.
  echo CATEGORY 3 - MAP DIRECTIONS
  echo   calibrate.bat directions --window-title Curseni
  echo   CLICK in this order: RIGHT, BOTTOM, LEFT, TOP.
  echo   A short beep confirms every detected click.
  echo.
  echo AFTER ALL THREE CATEGORIES
  echo   calibrate.bat export-shared
  echo   Creates: shared_ui_calibration_export.yaml
  exit /b 2
)
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m anka_platform.cli calibrate %* --config config.yaml
) else (
  py -3.13 -m anka_platform.cli calibrate %* --config config.yaml
)

# ANKA R5.185 — New Chat Handoff

**Current candidate:** R5.185 — Startup / Launch / Window Ownership Foundation  
**Protocol:** continue using `dofus_3_6_12_16`; the current-client map-transition evidence is compatible.  
**Windows/Dofus acceptance:** PENDING until the repaired first Launch is exercised.

Read `PROJECT_STATUS.json`, `R5_185_STARTUP_LAUNCH_WINDOW_OWNERSHIP_FOUNDATION.md`, `verification/R5_185_OFFLINE_VERIFICATION.md`, `ARCHITECTURE.md`, `DEBUGGING.md`, and `WINDOWS_LIVE_RUNBOOK.md`.

## Incident that triggered R5.185

R5.184 launched a worker under `RUNTIME_REQUIRED` because Canonical MapId had not yet been established. The worker then immediately ran steady-state continuity, classified `CANONICAL_STATE_NOT_CURRENT_SESSION` as a hard failure, and terminated before `_startup_bootstrap_step()` could run. No FightAI decision, combat click, or AutoHotkey switch caused the failure.

## New invariants

- The bootstrap exception is narrow and owned by the centralized startup blocker registry.
- A new blocker appearing between passive recovery approval and worker creation cancels Launch.
- Recovery authorization is preserved in incident evidence under `recovery`.
- Normal window switching never assumes `window.ahk` is running; exact HWND/PID activation is primary.
- Runtime/package/release platform versions must match.
- Do not modify the protocol adapter without new evidence proving semantic drift.

## Next action

After offline verification is green, perform one small Windows CRA+ENU Launch from the configured bootstrap start. Do not run AutoHotkey. Send the full runtime/debug package regardless of whether the run succeeds.

# R5.191 — Verification and Failure-Boundary Foundation

## Objective

R5.191 preserves the R5.190 current-protocol/fight-entry behavior and strengthens the engineering foundation used for every later milestone. It does not change live combat policy or invent new protocol semantics.

## Changes

### Deterministic release-gate surface caching

`tools/gpt_current_verify.py` still binds resumable PASS evidence to the complete immutable verification surface, but it no longer rereads all source/static game data after every individual test target when nothing changed. The first call computes the content SHA-256. Later calls compare the complete sorted path/size/nanosecond-mtime signature. Any ordinary mutation, addition or removal invalidates the cache and forces a fresh content digest before PASS evidence can be reused.

Generated reports/runtime cache and `PACKAGE_MANIFEST.json` remain outside the immutable surface exactly as before.

### Engineering guardrails

`verification/ENGINEERING_GUARDRAILS.json` and `tools/verify_engineering_guardrails.py` make two previously informal risks executable:

- the largest runtime modules have explicit current-state line/function/broad-exception ceilings so future changes cannot silently increase concentration of complexity;
- critical execution/state/observability modules have an exact allowlist for existing silent broad-exception sinks. New `except Exception: pass` sinks or relocated/unreviewed sinks fail verification.

Bare `except:` is forbidden in guarded critical modules.

These are containment budgets, not claims that the current module sizes are ideal. Future extraction work should reduce the budgets rather than raise them casually.

### Release integration

Engineering guardrails run from both `verify_release_integrity.py` and `verify_architecture_baseline.py`. A violation therefore blocks release sealing and architecture verification instead of remaining a documentation-only concern.

## Preserved R5.190 behavior

- active protocol adapter: `dofus_3_7_10_10`;
- historical `dofus_3_6_12_16` replay authority remains intact;
- persistent world MapId and tactical fight MapId remain separate;
- same-generation fight-entry evidence remains preserved;
- fight geometry remains generation-scoped and fail-closed;
- `jst` remains ACK/non-End-Turn evidence;
- raw protocol evidence remains external in the lean package.

## What R5.191 deliberately does not do

R5.191 does not split `ExecutionService`, rewrite PartyMissionController, change tactical scoring, or guess unknown current-build protocol messages. Those changes require separate characterization/evidence milestones so the verified live chain is not destabilized by a broad refactor.

## Acceptance

Offline acceptance requires:

1. R5.191 tests proving the surface cache reuses unchanged hashes and invalidates after mutation.
2. R5.191 tests proving a new silent broad-exception sink is rejected.
3. Engineering guardrails PASS.
4. Release integrity READY.
5. Architecture verification PASS.
6. Current quick-gate targets PASS or be individually accounted for with no failed assertion.
7. Package manifest VALID after sealing.

Windows/Dofus live acceptance remains pending and still requires the bounded CRA+ENU end-to-end fight from R5.190.

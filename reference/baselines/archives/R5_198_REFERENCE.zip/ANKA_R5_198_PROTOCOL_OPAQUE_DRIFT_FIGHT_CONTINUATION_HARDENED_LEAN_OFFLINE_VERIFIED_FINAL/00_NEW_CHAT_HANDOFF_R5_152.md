# ANKA R5.152 — New Chat Handoff

## Start here

This workspace is the **R5.152 Zone-200 Foundation Readiness, Action-Effect Forensics & Hot-Path Hardening** candidate.

Read, in order:

1. `R5_152_ZONE_200_FOUNDATION_READINESS_ACTION_EFFECT_FORENSICS_HARDENING.md`
2. `FIGHT_POLICY_CHANGE_GUIDE.md`
3. `PROJECT_STATUS.json`
4. `PROJECT_CONTEXT.json`
5. `ARCHITECTURE.md`
6. `DEBUGGING.md`
7. `TESTING.md`
8. `LIVE_ACCEPTANCE.md`

The sealed runtime compatibility identity remains unchanged. `PROJECT_STATUS.json` is the current workspace authority.

## Why R5.152 exists

R5.151 completed the supplied live campaign `runtime(20261001-233620)` with **5 wins / 0 losses / 0 unknowns** and no terminal campaign failure. That is strong runtime/orchestration evidence, but it is not proof of arbitrary level-200 tactical competence.

The readiness audit found four remaining foundation-quality gaps worth fixing before a controlled zone-200 pilot:

- future strategy analysis could see what was cast but could not reliably measure cast effectiveness because absolute HP snapshots are incomplete;
- combat-truth availability was implicit rather than a stable planner-neutral contract;
- stable Windows identity checks could repeatedly pay for full desktop enumeration on the hot path;
- full FightAI traces/replay were synchronously duplicated to disk and could block live turn processing.

R5.152 repairs those gaps without moving execution authority into FightAI.

## Architecture invariants

- Canonical State owns observed game truth.
- Kernel owns deterministic mechanics/legality.
- FightAI/TeamStrategy own policy only.
- `PartyCombatController` owns turn and transaction orchestration.
- `ExecutionService` owns physical input.
- ControlAuthority/window identity/campaign/session lifecycle remain foundation concerns.
- A strategy policy may not import execution, campaign, party orchestration, scripting or web/session-control layers.
- UNKNOWN combat truth may not be converted into a guessed value.

## R5.152 additions

- core `CombatTruthAvailability` in every planner context;
- event-backed `fight_ai/ACTION_EFFECTS.jsonl` with explicit-source vitality attribution only;
- `analysis/zone_200_readiness.json` separating controlled-pilot foundation readiness from generic autonomous zone-200 certification;
- dedicated launch-time Windows certification checkpoint/export;
- direct stable `HWND -> PID -> creation-time` continuity proof before expensive `EnumWindows` fallback;
- compact generic decision stream; replay derived at export instead of synchronously duplicated on the combat hot path;
- partial effect observations revoke `effects_complete` rather than carrying historical completeness forward;
- explicit `FIGHT_POLICY_CHANGE_GUIDE.md` for future strategy-only iterations.

## Evidence from the supplied R5.151 live run

- 5/5 campaign wins, no terminal failure;
- 133 FightAI action outcomes, 0 missing fight identity;
- 83 settled CAST outcomes;
- retrospective R5.152 action-effect derivation covers 83/83 casts and observes 3,399 enemy damage plus 407 enemy max-HP loss using explicit local source IDs;
- one confirmed multi-MOVE turn remains; confirmed prior-move history was present, so this is a policy choice, not path-cell clicking/history loss;
- 18 stale-frame replans;
- 93 effect-payload expansion anomalies; max effect payload 87, max semantic multiplicity 34;
- all 1,236 live effect observations were partial;
- enemy static IDs were complete but enemy max HP/AP/MP were not generally available;
- adapter/client version drift is guarded (`3.6.10.10` vs `3.6.12.16`); six unclassified `ilv`/`ilz` messages were preserved without semantics;
- CRA first Ready interaction still often has no semantic request; bounded second attempt succeeds and is fully diagnosed;
- R5.151 latency reconciliation was not naturally exercised in this successful run, so its live certification remains pending.

## Readiness interpretation

Do **not** say “generic autonomous level-200 ready” from this lower-zone run.

The intended next milestone is a **controlled R5.152 zone-200 pilot candidate**. `analysis/zone_200_readiness.json` must prove the foundation gate for that exact run. Generic autonomous readiness remains false until diverse level-200 encounters and remaining combat-truth blockers are actually certified.

Remaining explicit blockers include exact tackle/lock, generic effect/state lifecycle, comprehensive enemy max-HP/AP/MP truth, summon capacity/lineage, unknown monster-specific mechanics, and broad zone-200 tactical validation.

## Future strategy workflow

For a tactical-quality issue, start with one debug package and inspect:

- `analysis/zone_200_readiness.json`
- `analysis/foundation_health.json`
- `fight_ai/FIGHT_SUMMARY.json`
- `fight_ai/DECISION_TRACES.jsonl`
- `fight_ai/ACTION_OUTCOMES.jsonl`
- `fight_ai/ACTION_EFFECTS.jsonl`
- `fight_ai/CANDIDATES.jsonl`
- `fight_ai/COUNTERFACTUALS.jsonl`
- per-account `canonical_events.jsonl`

If the foundation gate is clean, keep modifications inside FightAI/TeamStrategy/profile/knowledge unless evidence proves a foundation contract violation.

## Verification rule

Only completed bounded test runs count. Timed-out aggregate commands never count as passes. After metadata is frozen, verify the source tree, rebuild `PACKAGE_MANIFEST.json`, package one top-level folder, fresh-extract the exact ZIP, and rerun context/manifest/compile/current-gate checks from that extraction.

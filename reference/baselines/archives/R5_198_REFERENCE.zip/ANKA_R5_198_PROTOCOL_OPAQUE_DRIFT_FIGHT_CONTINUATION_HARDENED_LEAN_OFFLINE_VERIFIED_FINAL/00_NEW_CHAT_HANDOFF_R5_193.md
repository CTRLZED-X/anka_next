# ANKA R5.193 — New-chat handoff

## Current authority

R5.193 is the current lean candidate. Read `R5_193_SETUP_INSTALL_DIAGNOSTIC_HARDENING.md`, `PROJECT_STATUS.json`, `docs/CURRENT.md`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, `WINDOWS_LIVE_RUNBOOK.md`, and `LIVE_ACCEPTANCE.md` before changing runtime behavior.

## Preserved runtime foundation

R5.190 fixed the observed world/fight geometry identity failure. R5.191 strengthened deterministic verification and engineering/failure-boundary guardrails. R5.192 made normal setup non-editable and the current protocol adapter version-local/evidence-scenario-gated. R5.193 does not rewrite protocol decoding, FightAI, Kernel, party coordination or physical-input execution.

## R5.193 incident and repair

The Windows setup incident occurred after the wheel and dependencies were successfully installed. The next Python command lost its `--record` argument because the batch file forwarded a quoted `%~dp0` path ending in `\` before additional CLI arguments. The earlier setup-environment recorder used the same unsafe form and did not produce its expected artifact.

All top-level Windows launchers now normalize `ANKA_PROJECT_ROOT` through `%CD%` after changing into the project directory. Runtime-install binding no longer passes the unsafe root argument form.

## Installed-runtime truth

`runtime_install_contract.py` schema 2 compares source runtime payload with the package actually installed in the active interpreter. `start.bat` blocks if either the source changed after setup or site-packages does not exactly represent the source runtime payload.

## Diagnostics

Setup persists stage/log evidence throughout dependency installation and contract checks. A stdlib-only fallback creates a setup debug ZIP even if ANKA cannot import. Setup also reports current/stale/unresolved port-8000 ownership without mutating processes; start remains the replacement/adoption authority.

The incident evidence contained an older R5.185 ANKA server on port 8000. R5.193 makes that condition explicit before launch instead of burying it in low-level network diagnostics.

## Protocol-upgrade contract

The R5.192 protocol replacement architecture remains authoritative: candidate adapter -> staged isolation/provenance/scenario/static-data verification -> activation -> setup/install fingerprint -> start-time verification. Do not bypass those gates when integrating a future protocol.

## Next proof

First rerun `setup.bat` on Windows. If setup succeeds, run `start.bat`. Then perform one bounded CRA+ENU fight proving the complete world -> fight -> placement -> Ready -> turn -> FightAI -> physical action -> authoritative settlement path. Preserve the generated runtime/debug package from any failure.

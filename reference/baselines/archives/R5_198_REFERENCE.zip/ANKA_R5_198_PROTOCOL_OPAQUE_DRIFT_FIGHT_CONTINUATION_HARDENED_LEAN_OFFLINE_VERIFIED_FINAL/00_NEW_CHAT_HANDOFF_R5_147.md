# ANKA R5.147 — New-chat handoff

## Current candidate

`ANKA_PLATFORM_R5_147_TURN_LIVENESS_PROGRESSIVE_SPELL_PLANNING_INACTIVITY_DEFENSE_ACTION_ECONOMY_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus live acceptance: **PENDING**. Offline success is not live certification.

## Triggering evidence

`runtime(20260929-151057)` plus the Dofus **Inactivité** popup. CRA correctly owned its turn but repeatedly returned `SPELL_COVERAGE_INCOMPLETE`, restarted the same expensive search and produced no CAST/MOVE/END_TURN for roughly full-turn intervals. ENU continued acting. R5.146's safety gate prevented an unjustified END_TURN but accidentally created a planner-progress deadlock.

## R5.147 changes

- progressive spell coverage across semantically identical frames;
- harmless raw revision churn no longer resets coverage;
- real AP/MP/position/state/effect/objective/quarantine changes invalidate stale progress;
- candidate-first exact-cell Kernel legality instead of whole-map-first legality per spell;
- correctness-preserving free-cell mobility/summon and AoE target proposals;
- protected early MOVE planning budget;
- tactical-mode-aware spell ordering;
- one non-click `TURN_ACTIVITY_HEARTBEAT` per certified controlled turn;
- heartbeat obeys ControlAuthority, window identity, arbiter, pending-settlement and uncertainty fences;
- planner-degraded recovery replans progressively; only proven no-progress/time exhaustion may use a certified turn-only END_TURN liveness fuse, never mission death;
- serial low-value movement receives additional execution-complexity cost;
- progressive search resumes inside a large per-spell target surface as well as across spell slots, preventing one teleport/summon/free-cell spell from restarting forever.

## Kernel workspace identity

The sealed runtime compatibility identity remains unchanged. The workspace Kernel becomes `0.1.0a59 / R10J Single-Cell Cast Decision Query` because R5.147 adds an exact one-target legality query used by candidate-first FightAI.

## Important non-change

There is no blind coordinate click for the Dofus inactivity modal. The current bridge cannot yet certify that modal's semantic identity strongly enough. Prevention is implemented through actual planner liveness plus the safe cursor heartbeat.

## First files to read

1. `R5_147_TURN_LIVENESS_PROGRESSIVE_SPELL_PLANNING_INACTIVITY_DEFENSE_ACTION_ECONOMY_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `src/anka_platform/fight_ai/tactical_policy.py`
5. `src/anka_game_kernel/mechanics/fight_queries/spell_decisions.py`
6. `src/anka_platform/core/fight/controller.py`
7. `src/anka_platform/core/fight/recovery.py`
8. `src/anka_platform/execution/service.py`
9. `tests/r5147/`

## Next live evidence to inspect

For every controlled turn capture turn key, heartbeat result, planner slice identity, cumulative spell dispositions, candidate-first query counts, first material game action latency, MOVE/cast selection, END_TURN certification, uncertainty fence state and authoritative handoff. At the first failure preserve the complete runtime/debug package.

## Offline verification status

R5.147 is **offline verified** and Windows/Dofus live acceptance remains **PENDING**. The current milestone suite is 11/11 PASS; architecture/contracts 57/57; FightAI+core 64/64; execution 131/131; application 50/50; party 89/89; scripting 172/172; protocol+live-state 112/112; projection 29/29; missions 4/4. Bounded web groups completed 43/43; `tests/web/test_party_app.py` exceeded the available command timeout and is explicitly not counted as passing evidence. See `verification/R5_147_OFFLINE_VERIFICATION.md` for the full bounded verification record and remaining live/L200 limitations.

# R5.174 — Startup Authority / Protocol Foundation Hardening

## Why this release exists

The R5.173 live run `runtime(20261012-175827)` again stalled for about 20 seconds before worker start. R5.173 had already fixed the first startup circular dependency and correctly failed-stop/disarmed, but the same bootstrap-expected facts were represented in several blocker collections and interpreted by more than one hand-maintained whitelist. `CANONICAL_STATE_NOT_CURRENT_SESSION`, `CAPTURE_NO_CANONICAL_EVENTS`, and `PROJECTION_RUNTIME_GRID_UNVERIFIED` were therefore tolerated in one branch and rejected in another.

R5.174 removes that architectural failure mode instead of adding another local exception.

## 1. Central startup blocker authority

`anka_platform.party.startup_policy` is the authority for startup blocker semantics. Each registered blocker has a domain and a bootstrap disposition. Expected bootstrap gaps are explicitly distinguished from hard blockers. Unknown future blockers are never silently ignored: they fail closed and are reported as unclassified.

This prevents a new blocker from being added to projection/runtime health without every startup consumer understanding its meaning.

## 2. Explicit startup phases

Startup convergence now reports typed phases such as binding, passive capture, initial-canonical-map acquisition, bootstrap eligibility, runtime required, projection synchronization and ready. The system reasons positively about what is required at each stage instead of subtracting unrelated negative blocker strings from several nested structures.

The guarded initial world-map bootstrap may tolerate only the evidence it is explicitly designed to create. Normal physical execution remains subject to the stronger readiness fences.

## 3. Real-incident regression

A distilled fixture from `runtime(20261012-175827)` is committed under `tests/r5174/fixtures/`. It contains the actual two-account blocker shape: healthy bindings/classified traffic, zero current-session canonical events, unknown initial MapId, projection waiting on canonical truth, and world bootstrap READY.

The required outcome is `RUNTIME_REQUIRED`. This prevents the exact R5.173 “Launch does nothing” state from returning unnoticed.

## 4. Stable diagnostic facade

`PartyRuntimeManager` now exposes input-free projection-authority refresh and delegates only to the current healthy runtime generation. Missing/stale/faulted generations return an unavailable diagnostic result rather than allowing stale evidence to look authoritative.

## 5. One-package root-cause diagnostics

Preflight exports structured startup blocker facts and the central policy classification. The root-cause analyzer recognizes bootstrap-policy disagreement and unclassified blocker codes. A future unknown blocker is surfaced as `STARTUP_BLOCKER_UNCLASSIFIED` rather than degrading into a generic pending-Launch timeout.

Pending-Launch status also records the latest startup phase/recovery code so a terminal stall explains where convergence stopped.

## 6. Protocol upgrade isolation

The active wire adapter remains versioned and isolated. R5.174 adds a canonical-capability compatibility report derived from adapter manifests and observed client build. Exact certified build, unknown build and version-drift states are explicit. Under build drift, declared capabilities are `UNPROVEN_ON_OBSERVED_BUILD` until evidence certifies them; a single unproven capability does not require changes to FightAI, Kernel or campaign orchestration.

Classified traffic that has not yet mutated Canonical State remains distinguishable from transform/schema drift. Exact-build negative semantic evidence is not reused across an uncertified client build.

## 7. What is deliberately unchanged

- ControlAuthority and physical-input ownership;
- normal ExecutionService readiness/admission/settlement fences;
- Kernel legality authority;
- FightAI decision authority boundaries;
- R5.173 structural runtime-grid projection authority and strict entity interaction proof;
- bridge contract 4 / plugin 2.2.75;
- canonical contract major 1.

## Live acceptance

Offline verification cannot prove Windows process timing, BepInEx/IL2CPP loading, or the compatibility of Dofus 3.7.8.7 with every 3.6.12.16 adapter capability. Windows/Dofus live acceptance therefore remains pending. The next run should either reach the launched runtime/bootstrap path or stop safely with a centrally classified first broken boundary.

# R5.166 Active Execution Continuity, Ready Efficiency & Forensic Hardening

## Live-run verdict

Authority: `runtime(20261005-001617).zip` produced by R5.165.

The run completed normally:

- `attempts = 5`
- `wins = 5`
- `losses = 0`
- `unknowns = 0`
- terminal reason `TARGET_WINS_REACHED`
- no sixth fight
- no terminal exception
- no residual execution fence/world interaction at completion
- control authority disarmed only because the script reached `COMPLETED`

This proves the R5.164 fight-accounting repair and the R5.165 recovery model are operational on the real client. R5.166 is a quality/authority cleanup driven by defects visible inside that successful run.

## Root cause 1 — historical action telemetry became runtime authority

`CampaignEngine.latest_action_transaction` is a historical record. In the live run the latest campaign-level action remained an ENU `ready_fight_send` with status `SENT` long after Ready had settled and combat was active. R5.165's generic pending-action continuity gate interpreted that record as a currently pending action.

Whenever ENU's inbound gameplay stream was briefly quiet or had a small reassembly gap, the parent therefore created `SERVER_TO_CLIENT_ACTION_STALL`, producing 53 continuity episodes and about 169 seconds of campaign watchdog hold time across the run. Many of those were not genuine network outages.

### Repair

ExecutionService now exposes a read-only `continuity_pending_status()` authority. It reports only genuinely unresolved durable execution obligations:

- resource/action settlement still awaiting authoritative evidence;
- combat uncertainty/reconciliation still fenced;
- pending world interaction settlement;
- current-generation follower join settlement.

Production PartyLanes use this live execution authority exclusively. `latest_action_transaction` remains diagnostic telemetry and cannot hold production continuity. A narrow legacy/test façade without ExecutionService retains an explicit compatibility fallback only so historical unit façades remain meaningful.

## Root cause 2 — momentary TCP reordering was treated as an outage

The live trace contained cases where `reassembly_stalled=true` with only a small gap and sub-second contiguous/message age. This can occur during ordinary packet reordering. R5.165 considered the boolean stall sufficient to HOLD when a pending action gate was active.

### Repair

Directional continuity now distinguishes:

- semantic message staleness beyond the configured threshold; and
- a **persistent** reassembly gap whose contiguous-progress age exceeds a material fraction of that threshold.

A fresh sub-second gap does not freeze the campaign. A persistent gap can still trigger earlier than full message-age expiry, preserving safe detection of real degraded live truth.

## Ready quality — preserve safe independent progress

CRA's first Ready click produced no outbound Ready request in all five fights. Physical evidence, focus identity and pointer arrival were valid; a later semantically authorized attempt succeeded each time. There is still no evidence that blindly increasing delays, adding click noise, or pinning the foreground to CRA would eliminate this Dofus/UI behavior safely.

A compatibility audit proved that pinning CRA during its input-free retry grace is counterproductive: the existing state machine intentionally allows ENU to make independent Ready progress while CRA waits for the delayed protocol probe. R5.166 therefore preserves that behavior. The duplicate-click invariant is unchanged: another CRA click is authorized only after the probe again proves request absence.

R5.166 additionally protects both Ready-request absence waits and Ready-acknowledgement waits with directional continuity HOLD semantics, so a real inbound stall pauses the relevant timeout rather than turning transport delay into a false Ready failure.

## Diagnostics

CampaignRuntime status now exports `live_transport_health` with retained continuity transitions and latest per-account runtime health.

`analysis/live_transport_recovery_health.json` schema v2 separates:

- lifetime recovery episode count;
- retained reconstructed episodes;
- recovered retained episodes;
- bounded raw state transitions;
- per-account directional flows;
- Ready transport gate;
- active execution obligation / pending-action transport gate.

This fixes the R5.165 debug defect where the report said zero episodes while the flight recorder/campaign watchdog showed many HOLD/RECOVERING cycles.

The `party_campaign_step` slow-warning floor is 6 seconds. The successful run had legitimate blocking confirmation/settlement calls up to about 5.72 seconds; warning at 4 seconds generated noise without indicating a deadline failure. The RPC deadline remains 15 seconds, so genuinely abnormal long calls remain visible.

## Pointer/mouse verdict

No R5.166 geometry change is made. The live R5.165 evidence contained 314 pointer motion samples and no pointer-motion failures. Typical cast motion was about 175 ms median over roughly 365 px median distance with approximately five correlated lateral direction changes; exact endpoint and bounded-step contracts held.

The active profile remains `TRAJECTORYLAB_V2_SAFE_CORRELATED_KNOTS_V2`: similar spatial behavior to the user-supplied TrajectoryLab_v2, but with ANKA minimum-jerk monotonic progression, exact certified endpoint arrival, focus/interference checks and no uncertified random click offset.

`NO_CERTIFIED_ALTERNATIVE_POINTS` remains an intentional safety limitation: the runtime will not invent coordinate variation outside caller-certified hit regions.

## Remaining issues separated by ownership

### Foundation

No terminal foundation defect was found in the successful five-fight run after the R5.166 repairs above. Remaining unknown wire messages (`ilv`, `ilz`) are preserved as unclassified evidence and did not violate current gameplay/canonical contracts; no semantic meaning is guessed.

### FightAI / level-200 truth

The bundle explicitly reports combat-truth gaps such as incomplete HP/max-HP, AP/MP, state/effect lifecycle, summon capacity and unsupported exact tackle/lock mechanics. These are not evidence that campaign/runtime/input authority is broken. They are the correct next-stage evidence targets for controlled level-200 development.

The current source default run budget is safe (`5/5`, stop on loss/unknown). The inspected live session was launched with looser overrides (`max_attempts=10`, `stop_on_loss=false`, `stop_on_unknown=false`), so the first controlled level-200 pilot should restore bounded fail-closed stop settings.

## Hidden continuity cases closed during final audit

The final systemic audit found two adjacent cases that could have produced the next live failure even though the five-fight R5.165 run succeeded:

- follower join settlement can be unresolved while the follower is still canonically in WORLD, so continuity authority now reads the generation-scoped join ledger rather than requiring a fight snapshot first;
- a Ready request may already be proven sent while its server acknowledgement is delayed, so the ACK wait receives the same directional live-truth HOLD protection without authorizing another click.

These are authority/transport repairs, not extra retries. Both preserve the existing possibly-sent/observe-only invariant.

## Offline verification result

R5.166 passed the retained R5.157->R5.166 gate (**156 passed, 7 archival metadata skips**), the full execution surface (**133 passed**), party/multi-account (**89 passed**), protocol/live-state/capture (**135 passed**), reliability/observability/diagnostics (**55 passed**), core/integration/FightAI (**79 passed**), scripting (**172 passed**), application/architecture/calibration/certification/contracts/maps/missions/operations/verification (**204 passed**), Windows/platform (**67 passed**), projection/world (**32 passed**), browser (**14 passed**), and critical web runtime/certification tests (**2 passed**). Static validation parsed **948 Python, 45 JSON and 27 YAML files**, and `compileall` passed.

See `verification/R5_166_OFFLINE_VERIFICATION.md` for the verification accounting and the remaining Windows/Dofus live gate.

## Acceptance criteria

R5.166 offline acceptance requires:

1. stale historical action telemetry cannot trigger production continuity HOLD;
2. a real live execution obligation can trigger directional HOLD;
3. fresh small reassembly gaps do not trigger false HOLD;
4. persistent reassembly stalls still trigger the safe continuity path;
5. Ready request/ack waits preserve independent-account progress while directional stalls pause safely and duplicate clicks remain semantic-evidence gated;
6. transport diagnostics report episodes and transitions accurately;
7. retained R5.165 and execution/party/protocol foundations pass;
8. packaged source/context/manifest verify from a fresh extraction.

Windows/Dofus live acceptance remains pending for R5.166.

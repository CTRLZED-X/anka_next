# ANKA R5.197 — New Chat Handoff

R5.197 is the current control-plane startup/takeover hardening candidate. It inherits the R5.196 turn-readiness, exact-PCAP replay, multi-account handoff, and zero-input systemic-simulation work.

## Captured failure that triggered R5.197

The 2026-10-16 startup runtime showed an old ANKA R5.195 server still answering on `127.0.0.1:8000` as PID 9236. R5.196 classified it as `REPLACE` but emitted `STALE_REPLACE_FAILED`. The old process was not actually sent a termination command: HTTP identity success had short-circuited listener discovery, while CIM process metadata was unavailable, leaving the safety gate unable to authorize termination.

## R5.197 repair

- Listener ownership is collected independently from HTTP identity on Windows.
- CIM failure falls back to `Get-Process` process-generation metadata.
- If process metadata is unavailable, stale takeover requires recognized ANKA HTTP identity correlated to the exclusive listening PID and an immediate second correlation before termination.
- PID/listener mismatch, foreign ownership, or server-instance change blocks termination.
- `taskkill` attempt/result/output and post-port ownership are preserved in startup evidence.
- Concurrent stale-replacement/bind races converge by re-observation rather than false failure.
- `/api/meta/server` schema 3 includes `server_instance_id` and `server_started_utc`.
- The systemic zero-input simulator includes takeover-authority safety coverage.

## First files for future debugging

1. `PROJECT_STATUS.json`
2. `R5_197_CONTROL_PLANE_TAKEOVER_HARDENING.md`
3. `src/anka_platform/server_supervisor.py`
4. `src/anka_platform/diagnostics/windows_host.py`
5. `tools/control_plane_preflight.py`
6. `src/anka_platform/web/app.py`
7. `tests/r5197/`
8. `verification/R5_197_OFFLINE_VERIFICATION.md`

## Next live acceptance

Extract into a fresh directory and run `start.bat`. Preserve `runtime/startup/last_startup_debug.zip` if startup does not become READY. The startup test should prove safe stale-control-plane replacement/adoption first; only then continue with the already-bounded CRA+ENU fight acceptance.

# ANKA R5.183 — Complete New-Chat Handoff

**Release:** R5.183 — Live Acceptance Evidence Integrity & Oracle Certification Foundation  
**Date:** 2026-10-14  
**Status:** **OFFLINE VERIFIED**  
**Windows / Dofus live acceptance:** **PENDING**  
**Working rule:** work locally/manual unless explicitly changed; do not use GitHub; do not assume prior conclusions are correct without checking source/evidence.

## 1. Current purpose

R5.183 is the continuation of R5.182. R5.182 established durable physical-input safety, account-correct diagnostics, fail-closed stuck-owner handling, and bounded verification. R5.183 hardens the next boundary: the evidence used to certify real live protocol truth.

The project must not claim live correctness by comparing Canonical State against data that was itself copied from Canonical State through ProjectionSync. ORACLE evidence must be independent and packet-aligned.

## 2. Read first

1. `PROJECT_STATUS.json`
2. `R5_183_LIVE_ACCEPTANCE_EVIDENCE_INTEGRITY_FOUNDATION.md`
3. `verification/R5_183_OFFLINE_VERIFICATION.md`
4. `verification/R5_183_QUICK_GATE.json`
5. `docs/CURRENT.md`
6. `ARCHITECTURE.md`
7. `DEBUGGING.md`
8. `TESTING.md`
9. `WINDOWS_LIVE_RUNBOOK.md`
10. `LIVE_ACCEPTANCE.md`
11. `docs/reference/LIVE_EVIDENCE_WORKFLOW.md`
12. `docs/reference/LIVE_DECODING_ORACLE_FORMAT.md`

Historical release documents are evidence/history; current source, tests and current R5.183 authority win when wording conflicts.

## 3. Identity

- checkpoint: `ANKA_PLATFORM_R5_183_LIVE_ACCEPTANCE_EVIDENCE_INTEGRITY_FOUNDATION_WINDOWS_LIVE_CANDIDATE`
- platform version: `0.1.0a131`
- runtime behavior parent: R5.182
- active adapter: `dofus_3_6_12_16`
- canonical contract major: `1`
- Kernel workspace checkpoint remains the inherited R5.182 Kernel identity.

## 4. Architecture that must be preserved

```text
Operator / Script Studio
  -> SessionPlan / ControlAuthority
  -> Campaign / Party / Fight
  -> FightAI + deterministic Kernel
  -> ExecutionService
  -> ExecutionLifecycleGate
  -> InputArbiter
  -> Windows input

Dofus traffic
  -> capture/TCP reconstruction
  -> versioned protocol adapter
  -> staged adapter context
  -> Canonical event batch
  -> atomic CanonicalStateStore
  -> CanonicalSnapshot
```

Canonical State is semantic truth. A successful click is not semantic success. Projection gives geometry/UI evidence. Raw protocol semantics stay inside the adapter. Unknown safety conditions fail closed.

## 5. R5.183 live-evidence rules

`oracle_snapshots` are accepted only with explicit provenance. The source must be declared Canonical-independent and aligned by positive `pcap_packet_index`. Account `oracle_member_id` mappings must be unique. Invalid/duplicate/unaligned/undeclared/non-comparable rows are evidence-integrity failures.

Normal Canonical -> ProjectionSync bridge observations are **not** independent semantic oracles for MapId, ActorId, CellId, AP or MP. They may still be useful for projection/geometry diagnostics, but they cannot certify the Canonical values they originated from.

Use `inspect_live_capture.bat <capture.pcapng>` to inventory exact flows and packet ranges. The tool deliberately does not infer character/account ownership; bind flows from independent process/account evidence.

## 6. Current certification status

Offline reference/replay coverage remains unchanged by this hardening. The verifier still reports approximately **88.37% required live-truth certification** and the same five independent ORACLE gaps:

1. world MapId;
2. local CRA/ENU actor identity;
3. actor CellId;
4. current AP;
5. current MP.

Do not patch decoder semantics just because those proofs are missing.

## 7. Next Windows workflow

Use a fresh R5.183 extraction. Close Dofus and run `setup.bat`; require Python/dependency/bridge/map/UI/static readiness. Then run `start.bat`, configure Script Studio, Apply once and Launch once.

The acceptance must be small and evidence-producing: required CRA+ENU accounts, known route, bounded attempts/fights, capture enabled, automatic incident preservation, no blind repeated Launch/retries.

After capture:

1. inventory PCAP with `inspect_live_capture.bat`;
2. map flows to accounts from independent evidence;
3. complete `LIVE_DECODING_EVIDENCE.json` from the current template;
4. add independent packet-aligned oracle snapshots and provenance;
5. run `verify_live_decoding.bat <evidence-root>`;
6. if blocked, fix the first reported evidence/runtime boundary rather than weakening certification.

## 8. If a live failure occurs

Preserve the incident/debug bundle. Trace in order:

```text
session/control -> client identity -> capture -> protocol transform
-> Canonical State -> world/fight lifecycle -> decision -> legality/admission
-> durable input preparation -> physical delivery -> semantic acceptance
-> settlement/recovery
```

Find the first proven divergence. Do not diagnose from screenshots alone when canonical/protocol/execution evidence exists.

## 9. Do not redesign without evidence

Do not rewrite FightAI or ExecutionService, replace SQLite, change the Canonical contract, leak protocol structs into higher layers, automatically retry uncertain physical actions, force-release stuck input leases, or accept Canonical-derived projection values as independent ORACLE truth.

## 10. Continuation state

R5.183 is ready for the next **bounded Windows/Dofus evidence-producing acceptance** once setup/readiness is green. It is not claimed bug-free, fully live-certified, unattended-ready, or zone-200 certified. The next useful evidence must come from the real Windows/Dofus boundary.

# ANKA Platform R5.142 — New Chat Handoff

## Current checkpoint

`ANKA_PLATFORM_R5_142_COMBAT_ACTION_CONTRACT_QUARANTINE_TURN_LIVENESS_HARDENING_WINDOWS_LIVE_CANDIDATE`

- Offline verification: **PASS** (frozen-tree verification complete; Windows/Dofus live acceptance remains pending).
- Windows/Dofus live acceptance: **PENDING**.
- Final production release: **NO**.
- Behavioral parent: R5.141.
- Sealed platform identity remains R5.115 / `0.1.0a122` for compatibility.
- Workspace Kernel remains `0.1.0a58 / R10I Runtime Spell Readiness Contracts`.

## Read first

1. `00_NEW_CHAT_HANDOFF_R5_142.md`
2. `R5_142_COMBAT_ACTION_CONTRACT_QUARANTINE_TURN_LIVENESS_HARDENING.md`
3. `PROJECT_STATUS.json`
4. `PROJECT_CONTEXT.json`
5. `verification/R5_142_OFFLINE_VERIFICATION.md`
6. `R5_141_SPELL_TARGET_INTERACTION_ACTION_INTENT_SEQUENCE_PLANNING_HARDENING.md`
7. `ARCHITECTURE.md`
8. `DEBUGGING.md`
9. `WINDOWS_LIVE_RUNBOOK.md`

## Triggering live evidence

`runtime(20260927-121856)`, fight 502. CRA's first turn had a plausible FightAI cast but no physical input occurred. The typed ActionIntent was flattened through `dataclasses.asdict()` and arrived with tuple-shaped nested collections while ExecutionService expected a list-shaped transport schema, producing `ACTION_INTENT_MALFORMED` at PRE_SLOT. Quarantine then failed to exclude the action because DecisionService used a different fingerprint (`repr(action_intent)`) than FightAI. The same semantic cast appeared 14 unique times on the same CombatFrame until the parent mission watchdog expired.

Do not patch Carreaux/spell 32459/cell 185/fight 502 specifically.

## R5.142 changes

- explicit canonical codecs for ImpactRequirement, ActionIntent and FightDecision;
- one semantic ActionKey/fingerprint across FightAI, DecisionService quarantine and controller recovery;
- `INVALID_COMBAT_ACTION_CONTRACT` is an action-level software-contract failure, not live-state uncertainty;
- quarantine has a controller-level postcondition: a quarantined ActionKey cannot be executed again in the same turn;
- repeated safe no-input recoveries are bounded and lead to certified END_TURN before the parent watchdog;
- unresolved physical input still fences and can never be masked by fallback;
- unsupported tackle/lock movement exposes `mechanic:tackle_lock` / `KERNEL_MOVE_TACKLE_UNSUPPORTED`;
- Fight Intelligence summaries deduplicate failure-path copies by decision_id and expose raw trace-record count separately;
- repeated same-frame action anomalies escalate with the streak;
- causal attribution identifies `COMBAT_ACTION_CONTRACT / FIGHT_DECISION_CODEC` before later wrapper timeouts;
- debug release identity distinguishes sealed compatibility Kernel metadata from current workspace Kernel identity.

## Still unresolved

Authoritative live Range/PO remains absent in some captures. Never restore `missing range_bonus -> 0`. Exact tackle/lock mechanics are also still unsupported and remain fail-closed. These affect tactical action-space quality but did not cause fight 502's no-input loop.

## Live focus

The next run should be allowed to continue through recoverable no-input combat defects. A local/action-level failure must capture diagnostics, quarantine the exact ActionKey, choose an alternative or END_TURN, and continue to later actors/turns. Only uncertain physical input, identity/control ambiguity, contradictory fight generation, or other true causality/safety corruption should fence the fight/mission.

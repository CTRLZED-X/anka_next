# ANKA R5.145 — New Chat Handoff

## Current package

Checkpoint: `ANKA_PLATFORM_R5_145_COMBAT_CAUSAL_RECONCILIATION_PLANNER_EFFICIENCY_L200_READINESS_WINDOWS_LIVE_CANDIDATE`.

Start with `00_START_HERE.md`, this handoff, `R5_145_COMBAT_CAUSAL_RECONCILIATION_PLANNER_EFFICIENCY_L200_READINESS_HARDENING.md`, `PROJECT_STATUS.json`, `ARCHITECTURE.md`, `TESTING.md`, `DEBUGGING.md`, and `WINDOWS_LIVE_RUNBOOK.md`.

## Goal

Build a fight foundation where local/recoverable combat faults do not kill the mission, while uncertain physical input remains fail-closed. Once that foundation is proven live, development should primarily improve a modular CRA water/earth + ENU water/MP-control FightAI for eventual level-200 zones.

## Latest live evidence that caused R5.145

`runtime(20260927-211946)` completed fights 519, 520 and 521. Fight 522 failed when ENU sent a MOVE click toward cell 176 but the target cell was not server-confirmed within the settlement budget. R5.144 converted that directly to terminal uncertainty/COMBAT_FAILED.

The same run showed major strategic progress over R5.142 (CRA and ENU each used many more spells) but also exposed movement waste, decision-budget exhaustion, missing HP/max-HP and effect/summon truth, unsupported tackle/lock, and production use of an empty enemy-capability catalog.

## R5.145 changes

- MOVE sent/unconfirmed -> passive causal reconciliation rather than immediate mission death.
- END_TURN sent/unconfirmed -> passive causal reconciliation; repeated proven ignored clicks stop and wait for auto handoff.
- physically uncertain sends remain hard fenced.
- structured non-success combat action contract and forensic attribution.
- exact action quarantine while reconciliation is pending.
- marginal movement scoring and hard rejection of zero-value movement.
- decision tail reserve and material-candidate preservation under budget exhaustion.
- R4 KRK pre-identity HP/max-HP buffering with release-specific decoder certification.
- per-decision and summary L200 combat-truth blocker reporting.
- effect-payload expansion telemetry without unsafe canonical deduplication.
- bundled enemy capability catalog activated in production `ranged_control_v1`.
- explicit CRA/ENU coordination-intent contract in TeamFightPlan.
- duplicate failed-session Problem card removed from Script Studio.

## Important authority boundaries

- Canonical protocol state is semantic truth.
- Kernel is deterministic mechanics authority.
- FightAI may rank only Kernel/Canonical-certified possibilities and never sends input.
- ExecutionService is the only physical-input owner.
- Projection/Unity is geometry/interaction evidence, not semantic truth.
- An uncertain physical send is a safety fence; do not "recover" by blind clicking.
- Equipment/build data can inform strategic affinity, never live AP/MP/PO/HP legality.

## Known remaining fail-closed limitations

Enemy absolute HP/max HP/AP/MP are not universally available from current certified protocol evidence. Effect removal/expiry semantics are incomplete. Summon capacity may be absent until authoritative `jxi` evidence appears. Exact tackle/lock is unsupported. Level-200 monster packs are incomplete beyond bundled/observed capability knowledge. These should be improved from evidence, not guessed.

## Next live test

Use the exact R5.145 package after offline gates are complete. Run a bounded multi-fight lower-zone campaign and export one runtime/debug package. The highest-priority proof is MOVE/END_TURN causal recovery continuing the fight/campaign safely. Then inspect `combat_truth`, candidate dispositions, team-plan capability source, movement decisions and remaining AP at END_TURN before escalating to level-200 zones.

@echo off
setlocal
cd /d "%~dp0"
set "ANKA_PROJECT_ROOT=%CD%"

set "MODE=%~1"
if "%MODE%"=="" set "MODE=quick"

if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else (
  where py >nul 2>nul
  if not errorlevel 1 (
    set "PY=py -3.13"
  ) else (
    set "PY=python"
  )
)

set "PYTHONPATH=%CD%\src;%CD%"

echo GPT_VERIFY_MODE=%MODE%
%PY% tools\gpt_project_context.py --check
if errorlevel 1 exit /b 1

if /I "%MODE%"=="context" exit /b 0

if /I "%MODE%"=="quick" (
  %PY% tools\gpt_current_verify.py quick
  if errorlevel 1 exit /b 1
  echo GPT_VERIFY=SUCCESS
  exit /b 0
)

if /I "%MODE%"=="full" (
  %PY% tools\gpt_current_verify.py full
  if errorlevel 1 exit /b 1
  %PY% -m compileall -q src scripts tools tests
  if errorlevel 1 exit /b 1
  %PY% tools\build_package_manifest.py --verify
  if errorlevel 1 exit /b 1
  echo GPT_VERIFY=SUCCESS
  exit /b 0
)

echo Unknown mode: %MODE%
echo Usage: gpt_verify.bat [context^|quick^|full]
exit /b 2

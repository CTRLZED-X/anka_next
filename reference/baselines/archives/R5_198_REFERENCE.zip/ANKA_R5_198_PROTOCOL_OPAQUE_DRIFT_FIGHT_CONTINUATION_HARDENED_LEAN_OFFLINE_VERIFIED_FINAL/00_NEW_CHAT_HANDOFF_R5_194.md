# ANKA R5.194 — New Chat Handoff

## Current authority

Use R5.194 as the current candidate. The main objective of this release is exact-build protocol/startup reliability and one-shot diagnosability. It inherits the R5.193 setup/install foundation and the R5.192/R5.190 protocol/combat architecture.

The normal chain remains:

`Script Studio -> ApplicationService -> Pending Launch / SessionLifecycle -> CampaignRuntime -> Party/Fight controllers -> FightAI -> ExecutionService/InputArbiter`

Passive live truth remains:

`capture -> versioned protocol adapter -> CanonicalState -> runtime health / controllers / FightAI`, with Unity projection as geometry/UI evidence.

## 2026-10-15 incident and repair

The reported UI error (`PENDING_LAUNCH_STALLED`, `BOOTSTRAP_ELIGIBILITY`, `WORLD_STATE_CONVERGENCE_NOT_SAFE_YET`) was a wrapper. Both CRA and ENU had sticky `PROTOCOL_UNCLASSIFIED_ACTIVE` caused by current-build `hmp|server_to_client` traffic. No physical input was sent.

R5.194 catalogues that exact wire identity from hash-bound evidence but assigns no gameplay/canonical semantics. All 172 rows in the captured startup protocol window classify under the updated adapter offline.

Startup policy now owns wait recoverability centrally. Sticky protocol/canonical safety fences do not spend 20 seconds pretending that time alone can repair them. The UI/checkpoint/incident package carries exact blocker evidence and unknown wire names, and the exporter promotes the true lower-layer cause over a pending-Launch wrapper.

A hidden TOCTOU bug was also repaired: a changed preflight between passive recovery assessment and worker reservation no longer emits `FAILED_TO_START` while leaving the intent pending. It stays guarded `WAITING` and is re-evaluated; genuine worker-start failure is terminal.

Additional systemic hardening found during the audit:

- opaque catalog-only `hmp` acceptance is constrained to the exact observed server→client payload fingerprint; a future payload variant fails closed;
- watchdog callback/terminalization failure is retryable instead of being silently marked handled;
- generic launch errors use the authoritative atomic terminal lifecycle transition;
- a stale watchdog sample cannot publish false `FAILED_TO_START` evidence after the worker has already won the transition.

## Important files

- `R5_194_PROTOCOL_STARTUP_DIAGNOSTIC_HARDENING.md`
- `src/anka_platform/party/startup_policy.py`
- `src/anka_platform/party/startup_convergence.py`
- `src/anka_platform/application/pending_launch.py`
- `src/anka_platform/application/service.py`
- `src/anka_platform/capture/runtime.py`
- `src/anka_platform/observability/startup_diagnosis.py`
- `src/anka_platform/observability/exporter.py`
- `src/anka_platform/web/app.py`
- `src/anka_platform/protocol/adapters/dofus_3_7_10_10/`
- `tests/r5194/`

## Do not weaken these boundaries

Do not give `hmp` semantics unless new evidence proves them. Do not bypass unknown/schema-drift fences. Do not patch Campaign/FightAI/Execution for protocol-version changes. Do not reintroduce local startup blocker whitelists. Do not treat generic pending-Launch errors as root cause when lower-layer evidence exists.

## Next milestone

Install a fresh R5.194 build and perform one bounded CRA+ENU live validation. First prove that Launch passes the former `hmp` classification boundary. Then continue through placement→Ready→first owner/action→End Turn/next owner→fight end→world re-entry. Export one diagnostics package on any failure before changing semantics.

R5.194 is **OFFLINE_VERIFIED**. It is not Windows/Dofus-live-certified; the next milestone is one bounded CRA+ENU live acceptance using this exact package.

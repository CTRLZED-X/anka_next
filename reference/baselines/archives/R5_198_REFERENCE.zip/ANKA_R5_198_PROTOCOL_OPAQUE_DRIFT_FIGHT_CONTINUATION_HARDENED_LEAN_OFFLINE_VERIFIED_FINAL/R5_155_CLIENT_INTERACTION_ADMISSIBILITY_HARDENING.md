# R5.155 — Client Interaction Admissibility Hardening

## Live evidence

`runtime(20261002-134543)` completed 5/5 lower-level fights. A full CAST census found 153 CAST outcomes: 150 successful/settled CASTs on statically walkable target cells, one delayed CAST that later reconciled, and exactly two CRA `CLIENT_CAST_REJECTED` outcomes on empty statically non-walkable cells. The two failures were Flèche de Dispersion (spell 32428 grade 3): fight 844 round 7 cell 324 and fight 845 round 3 cell 301. Both physical target clicks were reported SENT; neither produced the semantic `jrj` request.

The selected cells were deliberate empty AoE anchors, not stale monster cells. Kernel range/LoS/effect geometry considered them legal because the spell does not require a free/taken-cell mechanics target. The missing concept was client interaction admissibility.

## Root cause

The architecture incorrectly treated deterministic mechanics legality as sufficient evidence that a target cell could be physically clicked as a spell target. Walkability had previously been only a tactical preference. This allowed a mechanically valid AoE anchor to cross planning and admission even though the client would not accept the empty non-walkable target surface.

## Repair

- Added `integration/client_interaction.py` as a platform-owned, Kernel-independent interaction contract.
- TacticalPolicy rejects `REJECTED` and `UNKNOWN` interaction surfaces before candidate scoring.
- FightActionAdmissionService revalidates interaction against the latest semantic frame after Kernel feasibility.
- ExecutionService independently rejects an empty positively non-walkable target from the live Unity projection before slot selection and again at final target authorization.
- Verified/direct actor targets remain allowed even on cells unsuitable for movement.
- Empty fight-walkable AoE anchors remain available.
- Added `SPELL_TARGET_EMPTY_NON_WALKABLE` with safe pre-input/post-slot-neutralized recovery semantics.
- `analyze_cast` now exposes `kernel_legal`, `client_interaction` and combined `executable`.
- Foundation health/readiness surfaces client-interaction failures explicitly.

## Other systemic findings repaired

Two recovery END_TURN outcome rows lacked `fight_instance_id` even though the execution ledger had it. Runtime recording now consumes `shared_fight` correlation when present, and export may recover a missing fight identity only through an exact matching `action_id`; no timestamp guessing is allowed.

R5.154 launch process attestation mixed exact process/window/input identity readiness with early Canonical map/projection convergence. R5.155 reports `identity_ready` separately from `world_state_ready`, so the zone-200 audit does not misclassify proven process identity merely because world observation was still converging at Launch.

## Findings intentionally not patched

CRA's first Ready interaction still produces no semantic Ready request in all five observed fights, while the second bounded attempt succeeds after ENU's Ready request. Both attempts use the same verified HWND/PID/generation and identical click coordinates. The current retry is causally safe; the evidence does not yet prove whether the behavior is Dofus ordering/first-interaction semantics or an ANKA ordering defect, so no speculative reorder was introduced.

Multiple same-turn MOVE actions remain policy choices because confirmed movement history is preserved. Exact tackle/lock, complete effect lifecycle, comprehensive enemy dynamic resources, summon semantics and unknown monster-specific mechanics remain explicit combat-truth gaps.

The run was not level-200 evidence: observed enemy levels were 16–20.

## Verification

Final authoritative results are recorded in `verification/R5_155_OFFLINE_VERIFICATION.md` and `PROJECT_STATUS.json`. Timed-out aggregate invocations are never counted as passes. Windows/Dofus live acceptance of R5.155 remains pending until a fresh live run verifies the new interaction fence.

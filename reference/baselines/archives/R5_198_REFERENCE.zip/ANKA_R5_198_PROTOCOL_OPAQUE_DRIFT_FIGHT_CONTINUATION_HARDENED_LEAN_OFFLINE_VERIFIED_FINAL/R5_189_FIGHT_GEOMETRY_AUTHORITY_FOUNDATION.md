# ANKA R5.189 — Fight Geometry Authority Foundation

**Status:** OFFLINE VERIFIED candidate; Windows/Dofus bounded live acceptance pending.

## Why this release exists

The R5.188 live acceptance reached fight PLACEMENT on both CRA and ENU, but the semantic fight MapId (`190711810`) was not available as a standalone Mapuse/Kernel map. The fight had been launched from world map `190581250` at `[8,-12]`, whose 560-cell Unity/static geometry remained valid. Higher layers incorrectly assumed semantic fight identity and geometry identity had to be the same MapId, so placement projection failed repeatedly and Ready/FightAI were never reached.

R5.189 separates those authorities without changing Canonical protocol truth and without creating any global MapId alias.

## Core contract

```text
Canonical semantic fight MapId
        190711810
             │
             │ remains unchanged
             ▼
FightGeometryBinding (fight-instance scoped)
  fight_instance_id = 157
  semantic_map_id    = 190711810
  geometry_map_id    = 190581250
  coordinate         = [8,-12]
  evidence           = same-generation world/coordinate + placement legality
             │
     ┌───────┼────────┐
     ▼       ▼        ▼
Projection Execution Kernel/FightAI
```

A tactical MapId can be reused by another fight at another coordinate; the binding is therefore never written into Kernel maps as a global alias.

## Safety rules

- Prefer a directly loaded semantic geometry only when it already exists and covers required fight cells.
- Same-generation `discovered_world_map_id` may bind geometry, with contradictory coordinates rejected.
- A retained `world.map_id` is weaker and may bind only when fight coordinates and static map coordinates independently agree.
- Every protocol-declared placement cell must exist and be fight-walkable in the chosen geometry.
- Projection, physical execution, Kernel mechanics, FightAI and scripting analysis use the same resolver.
- Repeated input-free placement geometry failures are bounded and attributed to `FIGHT_GEOMETRY_AUTHORITY` rather than allowed to become a generic mission timeout.

## Protocol

The active adapter remains `dofus_3_6_12_16`. R5.189 does not rewrite protocol semantics. The R5.188 live incident decoded fight identity, phase, placement cells, actor identity/stats, ACTIVE, round and turn owner; the first proven divergence was geometry authority.

## Next live boundary

A fresh R5.189 run should now progress through:

`fight entry -> geometry binding -> placement -> Ready -> ACTIVE -> first FightAI decision`

If it does not, preserve the complete runtime/debug package and diagnose the first divergence.

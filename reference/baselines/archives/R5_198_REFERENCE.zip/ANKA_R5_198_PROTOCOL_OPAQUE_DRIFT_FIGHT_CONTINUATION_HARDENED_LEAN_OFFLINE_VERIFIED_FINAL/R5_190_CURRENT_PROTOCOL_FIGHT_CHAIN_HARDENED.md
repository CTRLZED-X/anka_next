# R5.190 — Current Protocol + Fight Chain Hardening

## Objective
R5.190 addresses the 2026-10-14 live incident in which CRA and ENU both entered the same fight but automation stopped before placement/Ready and FightAI never produced a decision.

## Confirmed root cause
The incident stopped at `FIGHT_GEOMETRY_AUTHORITY` with `FIGHT_GEOMETRY_UNAVAILABLE`. The tactical fight MapId replaced the persistent world MapId during the pre-`jxi` load, while the canonical reducer separately discarded the follower's same-generation join presentation. The geometry resolver therefore lost both valid paths to Mapuse geometry.

## Implemented changes
- Added explicit current-build adapter `dofus_3_7_10_10`; the prior `dofus_3_6_12_16` adapter remains registered for historical replay.
- Split decoder runtime identity into persistent world MapId and tactical fight MapId.
- Treat fight-loading `jow` contextually so tactical loading cannot overwrite persistent world identity, including the observed ordering where `jow` precedes `jxi`.
- Use `jnv` as fight-map authority without mutating `world.map_id`.
- Added `origin_world_map_id` to canonical fight state and preserve same-generation discovery/join data across fight lifecycle entry.
- Fight geometry can bind per generation from origin-world or same-generation join-world evidence and fails closed if those authoritative sources contradict.
- Corrected protocol capability ownership for `jnv` to fight identity.
- Current R5 wire contract keeps `jst` as ACK/non-mutating. It is not End Turn. The inherited `jwo` mapping is not granted exact-current negative-evidence certification; server `jup` remains the authoritative turn-end settlement boundary.
- Added regressions reproducing the exact failed semantic entry sequence and current-build protocol selection/compatibility.

## Protocol evidence scope
The supplied R5 reverse-engineering contract reports 22/22 CRA class-spell direct-cast wire coverage and 22/22 ENU class-spell coverage across retained captures, 51/51 matched current outbound spell requests, 16/16 monster HP-to-death replays, 82/82 AP/MP dual-wire reconciliations, 181/181 `jst`→`jsy` ACK correlations, and 36/38 movement requests with authoritative matches (the two unmatched requests remain non-mutating intents).

The adapter remains fail-closed for unresolved protocol-wide behavior. Known evidence gaps include universal exact effect-instance deletion semantics, complete shield absorption edge cases on the current build, challenge/world interaction coverage, login/reconnect coverage, and independent isolation of the current outbound End Turn request. These gaps are not silently invented.

## Live acceptance status
Offline verification can prove code paths, replay behavior, contracts, and regressions, but it cannot prove Windows focus/input, current Unity projection, or a complete real Dofus fight. Windows/Dofus live acceptance therefore remains **PENDING** until a bounded CRA+ENU run completes:

`world -> shared fight -> placement -> Ready -> ACTIVE -> turn owner -> FightAI decision -> physical action -> authoritative settlement`

# ANKA R5.149 — New-chat handoff

## Current candidate

`ANKA_PLATFORM_R5_149_TRANSACTION_AUTHORITY_STRICT_RESULT_CONTRACTS_SINGLE_LIFECYCLE_OWNER_VERIFICATION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Windows/Dofus live acceptance: **PENDING**. Offline verification does not replace live certification.

## Why R5.149 exists

A second audit of the exact R5.148 package found three important invariant holes even though the normal chain and large regression suites were green:

1. controller-side pending transaction state could disagree with ExecutionService and be treated as clear;
2. reconciliation could accept missing action correlation;
3. contradictory raw execution fields such as `CONFIRMED + INPUT_UNCERTAIN/NOT_SENT` could normalize as accepted.

The audit also found that admission UNKNOWN still released on raw revision churn, lifecycle PARTIAL classification was not fully typed between FightWorkflow and CampaignRuntimeController, current policy preflight did not validate callable signatures, and the advertised verifier mixed current functional tests with frozen historical release-identity assertions.

## R5.149 changes

- strict `CombatActionOutcome` contract validation and explicit `CONTRACT_VIOLATION`;
- explicit `SEMANTIC_REJECTED_SAFE` for certified client-local cast rejection with safe replan/quarantine proof;
- exact reconciliation correlation by action id + account lane + fight generation;
- controller/ExecutionService transaction disagreement fails closed instead of becoming `CLEAR`;
- orphan execution transactions and reconciliation-hook exceptions fail closed;
- admission UNKNOWN releases on semantic combat-frame change, not unrelated revision churn;
- typed `FightGenerationLifecycleStatus` / `FightPartialClassification` consumed by the campaign;
- current selected fight/passive/team/placement policy signatures validated before session arming;
- explicit current verification gate in `verification/CURRENT_TEST_GATE.json`;
- `gpt_verify.bat quick/full` uses the current gate instead of frozen historical release-ID assertions.

## Authority split

```text
Canonical/protocol         = observed live truth
Kernel                     = deterministic mechanics
FightAI                    = replaceable planner
FightWorkflow              = fight-generation lifecycle authority
PartyCombatController      = turn orchestration, turn-local transaction projection
ExecutionService           = sole physical-input and durable transaction authority
CampaignRuntimeController  = campaign progression / outcome / re-entry
Observability              = evidence only
```

## First files to read

1. `R5_149_TRANSACTION_AUTHORITY_STRICT_RESULT_CONTRACTS_SINGLE_LIFECYCLE_OWNER_VERIFICATION_HARDENING.md`
2. `PROJECT_STATUS.json`
3. `PROJECT_CONTEXT.json`
4. `src/anka_platform/core/fight/action_outcome.py`
5. `src/anka_platform/core/fight/action_transaction.py`
6. `src/anka_platform/core/fight/controller.py`
7. `src/anka_platform/core/fight/lifecycle.py`
8. `src/anka_platform/core/fight/workflow.py`
9. `src/anka_platform/campaign/runtime.py`
10. `src/anka_platform/core/session_compiler.py`
11. `verification/CURRENT_TEST_GATE.json`
12. `tests/r5149/test_r5149_transaction_contracts.py`

## Current verification

Before packaging, bounded verification completed successfully across current quick gate, core/fight/session/architecture/integration, full Execution, Application, Party/Campaign, Scripting, Protocol/Live State, diagnostics/observability/reliability, FightAI, maps/projection, missions/world, certification/windows/platform, and the full web/control-plane surface in bounded groups.

Never count a timed-out aggregate command as a pass. The exact final ZIP still needs a clean-extraction manifest/context/current-gate/compile check before distribution.

## Live acceptance focus

On the next Windows/Dofus run, verify:

- no second physical action occurs while any transaction is unresolved;
- every reconciliation record carries and matches the current action/account/fight correlation;
- certified `CLIENT_CAST_REJECTED` replans rather than stopping the fight;
- irrelevant evidence traffic does not cause admission retry storms;
- PARTIAL entry/exit handling and post-fight re-entry remain stable across several fights;
- journaled heartbeat/action records remain correlated;
- local planner/execution anomalies do not terminate the campaign unless the typed disposition is genuinely terminal.

## Remaining level-200 blockers

Exact tackle/lock, authoritative state/effect lifecycle, complete enemy dynamic resources, summon semantics, and verified target-zone capability knowledge remain unresolved. Do not mark R5.149 universally level-200 ready.

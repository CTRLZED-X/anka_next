# ANKA Platform R5.143 — Combat Liveness & Failure-Disposition Hardening

Checkpoint: `ANKA_PLATFORM_R5_143_COMBAT_LIVENESS_FAILURE_DISPOSITION_HARDENING_WINDOWS_LIVE_CANDIDATE`

Offline verification: **PASS for the R5.143 affected surface**. Windows/Dofus live acceptance: **PENDING**.

## Why R5.143 exists

`runtime(20260927-172212)` exposed a cross-layer contradiction rather than a simple tactical mistake. ENU's Bêche des Anciens target click was physically sent, but exact-client protocol causality proved that no semantic CAST request left the client. UI neutralization succeeded and `ExecutionService` explicitly returned `safe_replan=true` plus `quarantine_candidate=true`. `TurnRecoveryPolicy` therefore correctly chose same-turn exclusion/replan.

The incident exporter then independently treated the same run-correlated diagnostic as globally terminal and disarmed `ControlAuthority`. The next otherwise-valid combat step failed with `CONTROL_AUTHORITY_DISARMED`, converting a recoverable local cast rejection into a mission-terminal failure.

R5.143 separates **forensic capture** from **control fencing** and adds turn-local containment for FightAI software defects. It preserves all R5.142 action-contract/quarantine invariants and does not weaken uncertain-input fences.

## 1. One explicit incident/control disposition

`src/anka_platform/observability/failure_disposition.py` defines the control consequence of an incident independently from whether the incident deserves a debug bundle:

- `OBSERVE_ONLY`: diagnostic/pre-launch event, no live control mutation.
- `RECOVER_IN_PLACE`: enough evidence exists to continue the current run safely.
- `FENCE_CONTROL`: physical input, client identity, generation, or action causality is not trustworthy.

Unknown run-correlated failures remain fail-closed.

### Certified CLIENT_CAST_REJECTED

`CLIENT_CAST_REJECTED` is recoverable only when all of the following are present together:

- target physical send state is `SENT`;
- semantic CAST send state is `NOT_SENT`;
- exact-client negative semantic causality is certified;
- UI neutralization succeeded;
- producer explicitly sets `safe_replan=true`;
- producer explicitly sets `quarantine_candidate=true`.

If any proof is missing, the same failure code remains a hard control fence.

## 2. Application-level control boundary fixed

The web/app incident callback now applies the disposition instead of disarming simply because an incident has a `run_id`.

A certified rejected cast may therefore:

1. create a full incident/debug record;
2. keep the current run's control permit armed;
3. quarantine the exact ActionKey;
4. replan another action or preserve the turn with END_TURN.

`INPUT_UNCERTAIN`, action settlement uncertainty, exact-window identity loss, control correlation faults, generation faults and similar unsafe conditions continue to disarm synchronously.

The root live failure is protected by direct integration tests against the real `ControlAuthorityStore`, not only unit tests of the classifier.

## 3. FightAI exception containment

FightAI/policy execution occurs before physical input. R5.143 adds a turn-scoped exception boundary around policy resolution:

- unexpected planner exception -> preserve full exception diagnostic;
- do not crash the campaign lifecycle;
- convert the current primitive intent to `RECOVERY_END_TURN_FALLBACK`;
- send END_TURN only through the normal `ExecutionService` control/readiness/settlement gates.

This fallback never bypasses an uncertain-input fence.

## 4. Malformed FightAI decisions are pre-input local failures

R5.143 also validates the policy-output contract before physical execution. Examples now contained at turn scope include:

- CAST missing spell/slot/target fields;
- MOVE missing a target cell;
- invalid field types;
- invalid decision kind / malformed ActionIntent payload.

These defects are classified as `INVALID_FIGHT_AI_DECISION` and degrade to the same safe END_TURN path. They no longer need an outer mission watchdog to terminate the turn.

## 5. Candidate-generation observability

The live run showed that tactical diagnosis was incomplete: a configured spell could disappear without a candidate and without an explicit rejection reason. R5.143 adds per-spell dispositions to the tactical audit.

Every configured spell reached by a candidate cycle now records an outcome such as:

- `CANDIDATE_GENERATED`;
- `REJECTED` with concrete reasons;
- `NOT_EVALUATED` because the decision deadline or preview budget was exhausted.

An empty interesting-target set is now explicit as `NO_INTERESTING_TARGET_CELLS`. This is diagnostic hardening; it does not invent spell utility or relax Kernel legality.

## 6. State-completeness finding from runtime(20260927-172212)

Before strategy tuning, the live state path needs further certification. The run showed widespread `LEGAL_CAST_CELLS_INDETERMINATE` caused primarily by unavailable `combat_stats.range_bonus`, plus incomplete summon/state evidence. Characteristic 19 observations were present only in a form that appears to represent changing effect values for ENU in this run; they are not treated as a fabricated stable equipment baseline.

R5.143 therefore **does not** substitute DofusLab equipment values for live AP/MP/PO legality. Static equipment may later inform strategic affinity, but Kernel legality remains based on authoritative live state.

The configured adapter remains `dofus_3_6_10_10` while the observed client in the supplied run is 3.6.12.16. Protocol/state recertification is the next foundation priority.

## 7. Tactical findings deliberately not patched as weights yet

The runtime confirms severe action-space starvation for CRA and ENU. In particular, support/range/state-dependent spells are frequently unavailable to candidate generation because required live evidence is incomplete. The right next step is to repair/recertify state truth, not raise arbitrary FightAI weights.

The current `TacticalPolicyV1` also remains too monolithic for the final level-200 goal. R5.143 preserves behavior and diagnostics first; the planned next architecture separates team planning, candidate generation, utility, sequence search and a conservative fallback policy so tactical logic can be replaced without changing execution/recovery.

## 8. Preserved safety invariants

- `ExecutionService` remains the only physical-input authority.
- One primitive settles before the next primitive input.
- Canonical State remains semantic truth; Unity/projection remains interaction/geometry evidence.
- Kernel UNKNOWN/UNSUPPORTED never becomes optimistic TRUE.
- A possible or uncertain physical input is never hidden by END_TURN/replan.
- A certified rejected action is quarantined by canonical ActionKey for the current semantic turn.
- Incident capture is not itself proof that control must be revoked.

## 9. Mandatory live acceptance

A fresh Windows/Dofus run must demonstrate the exact corrected liveness chain:

```text
CLIENT_CAST_REJECTED with certified negative semantic causality
 -> incident/debug bundle may be created
 -> ControlAuthority remains armed
 -> exact ActionKey is quarantined
 -> FightAI chooses a different action OR bounded END_TURN fallback
 -> next actor/turn continues
 -> campaign remains alive
```

At the same time, an injected/real uncertain-input or window/control-identity failure must still disarm immediately.

The next runtime should also be used to measure per-spell dispositions and state-evidence starvation before any strategic weight tuning.

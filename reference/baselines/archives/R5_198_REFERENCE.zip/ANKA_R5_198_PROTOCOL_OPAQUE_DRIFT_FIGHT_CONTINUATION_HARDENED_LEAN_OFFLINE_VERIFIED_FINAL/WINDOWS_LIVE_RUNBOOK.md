> **Current release: R5.198** — exact opaque protocol-drift and post-cast fight-continuation hardening.

# R5.198 Windows setup / live-run focus

Use a **fresh R5.198 extraction**; do not overlay an older release.

1. Close Dofus and run `setup.bat`; protocol/source changed from R5.197.
2. Require `SETUP=READY`.
3. Start Dofus clients and run `start.bat`; require `ANKA_SERVER=READY`.
4. Perform one bounded CRA+ENU fight.
5. Confirm CRA's first CAST settles and the mission continues afterward.
6. Continue only through the first CRA→ENU handoff and bounded fight lifecycle.
7. If anything stops, preserve the runtime/debug ZIP and run `simulate_live.bat <zip>` before changing code.

R5.197 safe stale-control-plane takeover remains inherited. R5.198 does not ignore arbitrary new protocol messages: only sealed exact opaque fingerprints are non-blocking.

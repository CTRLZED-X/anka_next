# ANKA R5.188 — Complete New-Chat Handoff

**Release:** R5.188 — Bridge Build Verification Foundation  
**Date:** 2026-10-14  
**Status:** **OFFLINE VERIFIED** for the R5.188 scope; Windows/Dofus live acceptance pending.

## Immediate context

R5.187 fixed release/dependency identity, then the real Windows setup exposed a different defect at bridge compilation: `RuntimeSceneScanner.FindFightEntryTarget()` referenced stale locals `launchHierarchy` and `launchWorld`. R5.188 fixes that C# source defect and adds a release/setup source preflight so the same regression class is blocked before environment mutation.

Preserve all R5.186 entity-resolution, runtime-grid, control-atomicity, focus-recovery and diagnostic-causality repairs. Preserve the R5.187 platform/dependency/release coherence checks. Do not modify protocol or FightAI for this setup incident.

## Normal next step

Fresh extraction → Dofus closed → `setup.bat`. Require `RELEASE_INTEGRITY=READY`, `BRIDGE_SOURCE_PREFLIGHT=READY`, `DEPENDENCY_BASELINE=READY`, successful real bridge `dotnet build`/install/record, patrol-map readiness, UI contract and static readiness. Then run `start.bat` and one small bounded CRA+ENU acceptance. Preserve the complete runtime/debug package on any failure.

The bridge source preflight is intentionally not advertised as a substitute for the Windows compiler. The Windows setup compiler remains the final proof that BepInEx/Unity references and the delivered C# source build together.

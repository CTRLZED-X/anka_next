# ANKA bootstrap incident

**Failure code:** DEPENDENCY_INSTALL_FAILED

**Observed stage:** dependency installation or interpreter setup.

Detailed installer output is stored in the local bootstrap log, not in this sanitized archive.
Reproduce after checking the Python version, network access, package source and permissions.

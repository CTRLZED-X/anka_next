# ANKA diagnostic incident

**Code:** TURN_OWNER_UNPROVEN

**First observed boundary:** coordination.ready_to_first_turn

**Diagnostic status:** UNDETERMINED (hypothesis, not verified root cause).

Synthetic fixture: both Ready reported, but authoritative turn-owner evidence is absent.

The evidence matrix declares absent sections. This foundation release cannot execute or verify Dofus input.
